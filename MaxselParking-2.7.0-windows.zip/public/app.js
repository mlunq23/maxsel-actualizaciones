'use strict';
/* ================= MAXSEL PARKING - interfaz ================= */
const S = { me: null, estado: null, view: 'caja', ultimaImpresion: null };
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n) => '$' + Number(n || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const usd = (n) => 'US$' + Number(n || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const folio = (id) => String(id).padStart(6, '0');
const hora12 = (d) => { d = new Date(d); const h = d.getHours(); return String(h % 12 || 12).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0') + (h < 12 ? ' a.m.' : ' p.m.'); };
const fdt = (ms) => (ms ? new Date(ms).toLocaleDateString('es-MX', { day: '2-digit', month: '2-digit', year: 'numeric' }) + ', ' + hora12(ms) : '—');
const fd = (ms) => (ms ? new Date(ms).toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric' }) : '—');
const tiempo = (min) => { min = Math.max(0, Math.round(min)); const d = Math.floor(min / 1440), h = Math.floor((min % 1440) / 60), m = min % 60; return (d ? d + 'd ' : '') + (h || d ? h + 'h ' : '') + m + 'min'; };
const dateInput = (ms) => { const d = new Date(ms); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const fromDateInput = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d).getTime(); };
const finDia = (ms) => { const d = new Date(ms); d.setHours(23, 59, 59, 999); return d.getTime(); };
const inicioDia = (ms) => { const d = new Date(ms); d.setHours(0, 0, 0, 0); return d.getTime(); };
const can = (p) => S.me && (S.me.usuario.rol === 'admin' || S.me.permisos.includes(p));
const CLIENTE = { normal: 'Cliente', mesero: 'Mesero', pension: 'Pensionado', frecuente: 'Cliente frecuente', empresa: 'Empresa' };
const MARCAS = ['Nissan', 'Chevrolet', 'Volkswagen', 'Toyota', 'Honda', 'Ford', 'Kia', 'Hyundai', 'Mazda', 'Dodge', 'Jeep', 'RAM', 'GMC', 'BMW', 'Mercedes-Benz', 'Audi', 'Seat', 'Renault', 'Mitsubishi', 'Suzuki', 'Chrysler', 'Buick', 'Cadillac', 'Tesla', 'MG', 'BYD', 'Peugeot', 'Fiat', 'Subaru', 'Lexus', 'Acura', 'Infiniti', 'Motocicleta'];
const COLORES = ['Blanco', 'Negro', 'Gris', 'Plata', 'Rojo', 'Azul', 'Verde', 'Café', 'Beige', 'Amarillo', 'Naranja', 'Vino', 'Dorado'];

/* ---------- API ---------- */
async function api(url, opts = {}) {
  const o = { method: opts.method || (opts.body ? 'POST' : 'GET'), headers: { 'Content-Type': 'application/json' } };
  if (opts.body) o.body = JSON.stringify(opts.body);
  const r = await fetch(url, o);
  let data = null;
  try { data = await r.json(); } catch { /* vacío */ }
  if (r.status === 402) { mostrarActivacion(); throw new Error(data?.error || 'Sin licencia'); }
  if (r.status === 401 && !url.endsWith('/login')) { mostrarLogin(); throw new Error(data?.error || 'Sesión expirada'); }
  if (!r.ok) { const e = new Error(data?.error || 'Error ' + r.status); e.status = r.status; throw e; }
  return data;
}
const post = (url, body = {}) => api(url, { method: 'POST', body });

/* ---------- UI básicos ---------- */
function toast(msg, tipo = '') {
  const t = document.createElement('div');
  t.className = 'toast ' + tipo; t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(() => t.remove(), tipo === 'bad' ? 6000 : 3500);
}
const errToast = (e) => {
  toast(e.message || String(e), 'bad');
  // El servidor dice que no hay turno abierto (ej. se cerró en otra computadora): se abre sola la ventana de "Abrir turno"
  if (e && e.status === 409 && /abrir turno/i.test(e.message || '') && S.me && !$('#modals .vc-bg'))
    recargarMe().then(() => { if (!S.me.turno && !$$('#modals h3').some((h) => h.textContent === 'Abrir turno')) abrirTurnoModal(); }).catch(() => {});
};
const ventanaDeCaptura = (el) => !!el.querySelector('input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=file]),select,textarea');
function avisarVentana(caja) { if (!caja) return; caja.classList.remove('avisa'); void caja.offsetWidth; caja.classList.add('avisa'); }
(() => { const st = document.createElement('style'); st.textContent = '@keyframes avisa{0%,100%{transform:translateX(0)}20%{transform:translateX(-9px)}40%{transform:translateX(9px)}60%{transform:translateX(-6px)}80%{transform:translateX(6px)}}.avisa{animation:avisa .35s ease;outline:3px solid #2563eb}'; document.head.appendChild(st); })();
function modal(html, { cls = '', onClose } = {}) {
  const bg = document.createElement('div');
  bg.className = 'modal-bg';
  bg.innerHTML = `<div class="modal ${cls}">${html}</div>`;
  $('#modals').appendChild(bg);
  const m = { el: bg.firstElementChild, close() { bg.remove(); document.removeEventListener('keydown', onKey, true); onClose && onClose(); focusScan(); } };
  // 2.4.1: tocar fuera de una ventana de captura NO la cierra; Esc solo la cierra si no se ha escrito nada.
  bg.addEventListener('input', () => { m.sucio = true; });
  bg.addEventListener('mousedown', (e) => {
    if (e.target !== bg) return;
    if (!ventanaDeCaptura(bg)) return m.close();
    e.preventDefault(); avisarVentana(m.el);
  });
  const onKey = (e) => {
    if (e.key !== 'Escape' || $('#modals').lastElementChild !== bg) return;
    e.stopPropagation();
    if (m.sucio) { avisarVentana(m.el); toast('Para cerrar sin guardar use el botón Cancelar'); return; }
    m.close();
  };
  document.addEventListener('keydown', onKey, true);
  $$('[data-close]', bg).forEach((b) => b.addEventListener('click', () => m.close()));
  setTimeout(() => { const f = $('[autofocus]', bg) || $('input:not([type=hidden]):not([readonly]), select', bg); f && f.focus(); f && f.select && f.select(); }, 30);
  return m;
}
function confirmar(texto, { ok = 'Aceptar', peligro = false } = {}) {
  return new Promise((resolve) => {
    const m = modal(`<div class="hd"><h3>Confirmar</h3></div><div class="bd"><p>${texto}</p></div>
      <div class="ft"><button class="btn" data-no>Cancelar</button><button class="btn ${peligro ? 'bad' : 'pri'}" data-si autofocus>${ok}</button></div>`, { onClose: () => resolve(false) });
    $('[data-no]', m.el).onclick = () => m.close();
    $('[data-si]', m.el).onclick = () => { resolve(true); m.close(); };
  });
}
function pedirTexto(titulo, label, { ok = 'Aceptar', peligro = false } = {}) {
  return new Promise((resolve) => {
    let val = null;
    const m = modal(`<div class="hd"><h3>${titulo}</h3></div><form class="bd grid"><label class="f">${label}<input name="t" required autofocus></label></form>
      <div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn ${peligro ? 'bad' : 'pri'}" data-si>${ok}</button></div>`, { onClose: () => resolve(val) });
    const go = (e) => { e && e.preventDefault(); const v = $('[name=t]', m.el).value.trim(); if (!v) return; val = v; m.close(); };
    $('form', m.el).onsubmit = go; $('[data-si]', m.el).onclick = go;
  });
}
function formData(root) {
  const o = {};
  for (const el of $$('[name]', root)) {
    if (el.type === 'checkbox') { if (el.dataset.group) { (o[el.dataset.group] ||= []); if (el.checked) o[el.dataset.group].push(el.name); } else o[el.name] = el.checked; }
    else if (el.type === 'radio') { if (el.checked) o[el.name] = el.value; }
    else if (el.type === 'number') o[el.name] = el.value === '' ? '' : Number(el.value);
    else o[el.name] = el.value;
  }
  return o;
}
function ticketHTML(lines) {
  if (!lines || !lines.length) return '<p class="muted small">Sin impresiones todavía.</p>';
  return '<div class="ticket-prev">' + lines.map((l) => `<div class="${l.b ? 'b ' : ''}${l.big ? 'big ' : ''}${l.cut ? 'cut ' : ''}${l.meta ? 'meta ' : ''}${l.barcode ? 'bc' : ''}">${esc(l.t) || '&nbsp;'}</div>`).join('') + '</div>';
}
function manejarImpresion(imp, etiqueta) {
  if (!imp) return;
  S.ultimaImpresion = imp.preview;
  const box = $('#ultimaImp'); if (box) box.innerHTML = ticketHTML(imp.preview);
  if (!imp.ok) toast('No se pudo imprimir: ' + imp.error, 'bad');
  else if (imp.simulado) toast((etiqueta || 'Ticket') + ' generado (impresora no configurada: vea la vista previa)', 'warn');
  else if (etiqueta) toast(etiqueta + ' impreso', 'ok');
}
function verTicket(imp) { modal(`<div class="hd"><h3>Vista previa del ticket</h3><button class="btn sm" data-close>✕</button></div><div class="bd">${ticketHTML(imp?.preview)}</div>`); }
// Exporta a Excel (.xlsx). cols: [[campo|función, 'Título', 'dinero'|'entero'|'texto'?], ...]
function hojaExcel(nombre, filas, cols, titulo) {
  const tipo = (c, f0) => c[2] || (typeof (typeof c[0] === 'function' ? c[0](f0 || {}) : (f0 || {})[c[0]]) === 'number' ? 'decimal' : 'texto');
  return { nombre, titulo: titulo || nombre, subtitulo: S.me.config.empresa_nombre + (S.repData ? ' · ' + fdt(S.repData.desde) + ' a ' + fdt(S.repData.hasta) : ''),
    columnas: cols.map((c) => ({ t: c[1], ancho: Math.max(10, c[1].length + 2), tipo: tipo(c, filas[0]) })),
    filas: filas.map((f) => cols.map((c) => { const v = typeof c[0] === 'function' ? c[0](f) : f[c[0]]; return v == null ? '' : v; })) };
}
function csv(nombre, filas, cols) { descargarExcel(nombre + '.xlsx', [hojaExcel(nombre, filas, cols)]); }

/* ---------- Pantalla del cliente (segundo monitor) ---------- */
let pantallaTimer = null;
function pantalla(estado, datos = {}, volverEn = 0) {
  clearTimeout(pantallaTimer);
  fetch('/api/pantalla', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ estado, ...datos }) }).catch(() => {});
  if (volverEn) pantallaTimer = setTimeout(() => pantalla('espera'), volverEn);
}

/* ---------- Licencia ---------- */
async function mostrarActivacion() {
  if (!$('#activar').classList.contains('hidden')) return;
  $('#app').classList.add('hidden'); $('#login').classList.add('hidden'); $('#modals').innerHTML = '';
  $('#activar').classList.remove('hidden');
  try {
    const e = await (await fetch('/api/licencia/estado')).json();
    $('#codEquipo').textContent = e.codigoEquipo;
    $('#huellaLic').textContent = e.huella ? 'Huella: ' + e.huella : '';
    $('#motivoLic').textContent = e.motivo || '';
  } catch { /* */ }
}
$('#copiarCod').onclick = () => { navigator.clipboard?.writeText($('#codEquipo').textContent); toast('Código copiado', 'ok'); };
$('#actForm').onsubmit = async (e) => {
  e.preventDefault();
  try {
    const r = await fetch('/api/licencia/activar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ clave: e.target.clave.value }) });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error);
    $('#activar').classList.add('hidden'); toast('¡Sistema activado!', 'ok'); iniciar();
  } catch (err) { $('#motivoLic').textContent = err.message; }
};

/* ---------- Sesión ---------- */
function mostrarLogin() {
  S.me = null;
  $('#activar').classList.add('hidden');
  $('#app').classList.add('hidden'); $('#login').classList.remove('hidden');
  $('#modals').innerHTML = '';
  setTimeout(() => $('#loginForm [name=usuario]').focus(), 50);
}
$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = formData(e.target);
  $('#loginErr').classList.add('hidden');
  try { await post('/api/login', f); e.target.reset(); await iniciar(); }
  catch (err) { $('#loginErr').textContent = err.message; $('#loginErr').classList.remove('hidden'); }
});
$('#btnSalir').onclick = async () => { await post('/api/logout').catch(() => {}); mostrarLogin(); };

async function recargarMe() {
  S.me = await api('/api/me'); pintarTop(); iniciarCamaraUSB();
  if ($('#nav')?.children.length) { pintarNav(); $$('#nav a').forEach((a) => a.classList.toggle('on', a.dataset.v === S.view)); }
}

/* ---------- Cámara de entrada ---------- */
const CAM = { stream: null, video: null, error: null, iniciando: false };
async function iniciarCamaraUSB() {
  if (!S.me || S.me.config.camara_tipo !== 'usb' || !(can('ingreso_rapido') || can('ingreso_manual'))) {
    if (CAM.stream) { CAM.stream.getTracks().forEach((t) => t.stop()); CAM.stream = null; CAM.video = null; }
    return;
  }
  if ((CAM.stream && CAM.stream.active) || CAM.iniciando) return;
  CAM.iniciando = true;
  try {
    if (!navigator.mediaDevices?.getUserMedia) throw Object.assign(new Error(), { name: 'Inseguro' });
    CAM.stream = await navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false });
    CAM.video = document.createElement('video'); CAM.video.muted = true; CAM.video.playsInline = true; CAM.video.srcObject = CAM.stream;
    await CAM.video.play(); CAM.error = null;
  } catch (e) {
    CAM.error = e.name === 'NotAllowedError' ? 'Permiso de cámara negado en este navegador' : e.name === 'Inseguro' ? 'La cámara USB sólo funciona en la computadora de la caja (localhost)' : 'No se encontró la cámara USB';
  } finally { CAM.iniciando = false; pintarCamara(); }
}
function capturarUSB() {
  const v = CAM.video; if (!v || !v.videoWidth) return null;
  const c = document.createElement('canvas'), w = Math.min(1280, v.videoWidth);
  c.width = w; c.height = Math.round((w * v.videoHeight) / v.videoWidth);
  c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
  const ctx = c.getContext('2d'); ctx.font = 'bold 22px Arial'; ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.fillRect(0, c.height - 34, 330, 34); ctx.fillStyle = '#fff';
  ctx.fillText(fdt(Date.now()), 10, c.height - 10);
  return c.toDataURL('image/jpeg', 0.72);
}
function pintarCamara() {
  const box = $('#camBox'); if (!box) return;
  const tipo = S.me.config.camara_tipo;
  if (tipo === 'ninguna') { box.closest('.card').classList.add('hidden'); return; }
  box.closest('.card').classList.remove('hidden');
  if (tipo === 'usb') {
    if (CAM.error) { box.innerHTML = `<p class="alert bad small" style="margin:0">${esc(CAM.error)}</p>`; return; }
    if (!CAM.stream) { box.innerHTML = '<p class="muted small">Encendiendo cámara…</p>'; return; }
    box.innerHTML = '<video id="camVivo" muted playsinline autoplay style="width:100%;border-radius:10px;background:#000;aspect-ratio:16/9;object-fit:cover"></video><p class="muted small" style="margin:.3rem 0 0">Se toma una foto en cada entrada.</p>';
    $('#camVivo').srcObject = CAM.stream;
  } else {
    const u = S.ultimaFoto;
    box.innerHTML = u ? `<img src="/api/ticket/${u}/foto?t=${Date.now()}" alt="Última entrada" style="width:100%;border-radius:10px;cursor:zoom-in" onclick="verFoto(${u})"><p class="muted small" style="margin:.3rem 0 0">Última entrada · boleto ${folio(u)}</p>`
      : '<p class="muted small">Cámara IP: la foto se toma sola al registrar cada entrada.</p>';
  }
}
function verFoto(id) {
  modal(`<div class="hd"><h3>📷 Foto de entrada · boleto ${folio(id)}</h3><button class="btn sm" data-close>✕</button></div>
    <div class="bd" style="text-align:center"><img src="/api/ticket/${id}/foto" alt="Foto de entrada" style="max-width:100%;max-height:70vh;border-radius:10px" onerror="this.outerHTML='<p class=muted>Esta entrada no tiene foto (o ya se borró por antigüedad).</p>'"></div>`, { cls: 'wide' });
}
async function iniciar() {
  try { await recargarMe(); } catch { return $('#activar').classList.contains('hidden') ? mostrarLogin() : null; }
  $('#login').classList.add('hidden'); $('#app').classList.remove('hidden');
  const lic = S.me.licencia;
  if (lic && lic.diasRestantes != null && lic.diasRestantes <= 7) toast(`La licencia vence en ${lic.diasRestantes} día(s). Comuníquese con Maxsel.`, 'warn');
  if (can('configuracion') && S.me?.config?.upd_disponible) setTimeout(() => toast(`Hay una versión nueva del sistema (${S.me.config.upd_disponible}). Instálela en Configuración → Actualizaciones.`, 'warn'), 2500);
  pintarNav();
  await refrescarEstado();
  ir(S.view in VISTAS && puedeVer(S.view) ? S.view : 'caja');
  if (!S.me.turno && (can('cobrar') || can('ingreso_rapido') || can('ingreso_manual'))) abrirTurnoModal();
}
setInterval(() => { const r = $('#reloj'); if (r) r.textContent = hora12(Date.now()); }, 1000);
setInterval(() => { if (S.me) refrescarEstado().catch(() => {}); }, 15000);

async function refrescarEstado() {
  S.estado = await api('/api/estado');
  pintarOcupacion();
  if (S.view === 'caja') pintarDentroMini();
  if (S.view === 'dentro') pintarTablaDentro();
}
function pintarTop() {
  $('#empresaNom').textContent = S.me.config.empresa_nombre || 'MAXSEL PARKING';
  $('#userTag').textContent = S.me.usuario.nombre + ' · ' + { admin: 'Administrador', supervisor: 'Supervisor', cajero: 'Cajero' }[S.me.usuario.rol];
  const t = S.me.turno, tag = $('#turnoTag');
  tag.className = 'turno' + (t ? '' : ' no');
  tag.textContent = t ? `Turno ${folio(t.id)} · TC $${t.tipo_cambio}` : 'Sin turno';
  tag.style.cursor = 'pointer';
  tag.onclick = () => (t ? ir('corte') : abrirTurnoModal());
}
function pintarOcupacion() {
  const e = S.estado; if (!e) return;
  const pct = e.capacidad ? Math.min(100, (e.ocupados / e.capacidad) * 100) : 0;
  $('#occ').innerHTML = `
    <span class="pill libre ${e.lleno ? 'lleno' : ''}">${e.lleno ? 'LLENO' : 'Disponibles'} <b>${e.disponibles}</b></span>
    <span class="bar" title="${Math.round(pct)}% ocupado"><i style="width:${pct}%;background-position:${-pct * 2}px 0"></i></span>
    <span class="pill ocup">Ocupados <b>${e.ocupados}</b></span>
    <span class="pill">Capacidad <b>${e.capacidad}</b></span>`;
}

/* ---------- Navegación ---------- */
const VISTAS = {
  caja: { t: 'Caja', ic: '🅿️', render: vistaCaja },
  tienda: { t: 'Venta de productos', ic: '🛒', perm: ['vender_productos'], render: (m) => vistaTienda(m) },
  dentro: { t: 'Vehículos dentro', ic: '🚗', render: vistaDentro },
  clientes: { t: 'Clientes y pensiones', ic: '📇', perm: ['pensiones_cobrar', 'clientes_admin'], render: vistaClientes },
  corte: { t: 'Turno y corte', ic: '💵', render: vistaCorte },
  gastos: { t: 'Gastos', ic: '🧾', perm: ['gastos', 'reportes'], modulo: 'gastos', render: vistaGastos, aviso: 'gastos_fijos' },
  publicidad: { t: 'Publicidad (lonas)', ic: '🪧', perm: ['publicidad'], render: (m) => vistaPublicidad(m), aviso: 'publicidad' },
  reportes: { t: 'Reportes y gráficas', ic: '📊', perm: ['reportes'], render: vistaReportes },
  sep1: { sep: true },
  productos: { t: 'Productos y servicios', ic: '🧽', perm: ['productos_admin'], render: vistaProductos },
  convenios: { t: 'Convenios', ic: '🤝', perm: ['convenios_admin'], render: vistaConvenios },
  tarifas: { t: 'Tarifas', ic: '🏷️', perm: ['tarifas_admin'], render: vistaTarifas },
  config: { t: 'Configuración', ic: '⚙️', perm: ['configuracion'], render: vistaConfig },
  usuarios: { t: 'Usuarios y permisos', ic: '👥', perm: ['usuarios'], render: vistaUsuarios },
  bitacora: { t: 'Bitácora', ic: '📝', perm: ['bitacora'], render: vistaBitacora },
  cuenta: { t: 'Mi contraseña', ic: '🔑', render: vistaCuenta },
};
// Módulos que se venden aparte: se encienden o apagan desde la licencia que entrega Maxsel (las licencias viejas traen todo).
const modOn = (k) => !(S.me && S.me.licencia && S.me.licencia.modulos && S.me.licencia.modulos[k] === false);
const NOMBRE_MOD = { gastos: 'Gastos' };
const avisoSinModulo = (k) => toast(`El módulo de ${NOMBRE_MOD[k] || k} no está incluido en su licencia. Comuníquese con Maxsel.`, 'warn');
const puedeVer = (k) => (!VISTAS[k].modulo || modOn(VISTAS[k].modulo)) && (!VISTAS[k].perm || VISTAS[k].perm.some(can));
function pintarNav() {
  $('#nav').innerHTML = Object.entries(VISTAS).filter(([k, v]) => v.sep || puedeVer(k))
    .map(([k, v]) => (v.sep ? '<div class="sep"></div>' : `<a data-v="${k}"><span>${v.ic}</span>${v.t}${v.aviso && S.me.avisos?.[v.aviso] ? ` <b class="nav-aviso" title="Pendientes por pagar o por vencer">${S.me.avisos[v.aviso]}</b>` : ''}</a>`)).join('');
  $$('#nav a').forEach((a) => (a.onclick = () => ir(a.dataset.v)));
}
function ir(v) {
  if (VISTAS[v] && VISTAS[v].modulo && !modOn(VISTAS[v].modulo)) { avisoSinModulo(VISTAS[v].modulo); v = 'caja'; }
  S.view = v;
  $$('#nav a').forEach((a) => a.classList.toggle('on', a.dataset.v === v));
  $('#main').innerHTML = '';
  Promise.resolve(VISTAS[v].render($('#main'))).catch(errToast);
}
function focusScan() { const s = $('#scan'); if (s && !$('#modals').children.length) s.focus(); }

/* ---------- Atajos de teclado ---------- */
document.addEventListener('keydown', (e) => {
  if (!S.me || $('#app').classList.contains('hidden')) return;
  const enModal = $('#modals').children.length > 0;
  if (e.key === 'F2' && !enModal) { e.preventDefault(); ingresoRapido(); }
  else if (e.key === 'F3' && !enModal) { e.preventDefault(); ingresoManual(); }
  else if (e.key === 'F4' && !enModal) { e.preventDefault(); if (S.view !== 'caja') ir('caja'); setTimeout(focusScan, 50); }
  else if (e.key === 'F8' && !enModal) { e.preventDefault(); boletoPerdido(); }
  else if (e.key === 'F9' && !enModal) { e.preventDefault(); if (can('vender_productos')) ir('tienda'); }
});

/* ---------- Escáner siempre listo ----------
   El lector de códigos escribe como teclado y termina con Enter. Mientras no haya una ventana abierta
   ni se esté escribiendo en otro campo, todo lo que se teclee va al boleto a cobrar. */
const SCAN = { buf: '', t: 0 };
const editable = (el) => el && (el.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName));
document.addEventListener('keydown', (e) => {
  if (!S.me || $('#app').classList.contains('hidden') || $('#modals').children.length) return;
  if (S.view === 'tienda') return; // en la venta de productos el escáner lee productos, no boletos
  if (e.ctrlKey || e.altKey || e.metaKey || /^F\d+$/.test(e.key)) return;
  const scan = $('#scan');
  if (e.target === scan) return; // ya está en el campo del boleto
  if (editable(e.target)) return; // está escribiendo en otro campo
  const ahora = Date.now();
  if (ahora - SCAN.t > 1500) SCAN.buf = '';
  SCAN.t = ahora;
  if (e.key === 'Enter') {
    const v = SCAN.buf.trim(); SCAN.buf = '';
    if (v) { e.preventDefault(); if (scan) scan.value = ''; abrirCobro(v); }
    return;
  }
  if (e.key.length !== 1) return;
  e.preventDefault();
  SCAN.buf += e.key;
  if (scan && !scan.disabled) { scan.value = SCAN.buf; scan.focus(); }
}, true);
// Regresa el cursor al campo del boleto cuando no se está usando otro campo
setInterval(() => {
  if (!S.me || S.view !== 'caja' || $('#modals').children.length) return;
  const a = document.activeElement;
  if (!editable(a) || a.id === 'scan') { const sc = $('#scan'); if (sc && a !== sc && !sc.disabled) sc.focus(); }
}, 800);
window.addEventListener('focus', () => setTimeout(focusScan, 50));

/* ================= TURNO ================= */
// despues: sigue lo que se estaba haciendo al abrir el turno · alCancelar: se cierra la ventana sin abrir turno
function abrirTurnoModal(despues, alCancelar) {
  if (S.me.turno) return ir('corte');
  let abierto = false;
  const m = modal(`<div class="hd"><h3>Abrir turno</h3><button class="btn sm" data-close>✕</button></div>
    <form class="bd grid">
      <p class="muted" style="margin:0">Hola <b>${esc(S.me.usuario.nombre)}</b>. Capture el fondo de caja con el que inicia y el tipo de cambio del dólar para este turno.</p>
      <div class="grid g3">
        <label class="f">Fondo en pesos (MXN)<input name="fondo_pesos" type="number" min="0" step="0.01" value="0" autofocus></label>
        <label class="f">Fondo en dólares (USD)<input name="fondo_usd" type="number" min="0" step="0.01" value="0"></label>
        <label class="f">Tipo de cambio (MXN por 1 USD)<input name="tipo_cambio" type="number" min="0.01" step="0.01" value="${S.me.config.tipo_cambio_default}" required></label>
      </div>
      <div class="ft" style="padding:0;border:0;position:static"><button class="btn" type="button" data-close>Ahora no</button><button class="btn ok big">Abrir turno</button></div>
    </form>`, { onClose: () => { if (!abierto && typeof alCancelar === 'function') alCancelar(); } });
  $('form', m.el).onsubmit = async (e) => {
    e.preventDefault();
    try {
      const r = await post('/api/turno/abrir', formData(e.target)); abierto = true; m.close(); await recargarMe();
      toast(r.cajon && r.cajon.ok && !r.cajon.simulado ? 'Turno abierto: coloque el fondo en el cajón' : 'Turno abierto', 'ok');
      if (r.cajon && !r.cajon.ok) toast('No se pudo abrir el cajón: ' + r.cajon.error, 'bad');
      ir(S.view);
      if (typeof despues === 'function') setTimeout(despues, 150);
    }
    catch (err) { errToast(err); }
  };
}
// Para cobrar se necesita turno: si la caja está cerrada se abre sola la ventana de "Abrir turno" y,
// al abrirlo, sigue el cobro donde se quedó (si la cierra con "Ahora no", no se cobra).
function sinTurno(continuar) {
  if (S.me.turno) return false;
  toast('Su caja está cerrada: abra su turno para continuar', 'warn');
  abrirTurnoModal(continuar); return true;
}
// Igual que sinTurno pero en forma de promesa: true si ya hay turno o se acaba de abrir, false si se canceló
function asegurarTurno() {
  if (S.me.turno) return Promise.resolve(true);
  toast('Su caja está cerrada: abra su turno para poder cobrar', 'warn');
  return new Promise((ok) => abrirTurnoModal(() => ok(true), () => ok(false)));
}

/* ================= CAJA ================= */
function vistaCaja(main) {
  const t = S.me.turno;
  main.innerHTML = `
  <div class="caja">
    <div>
      ${t ? '' : `<div class="alert bad" style="margin-bottom:1rem">No tiene turno abierto. <button class="btn sm ok" id="abrirT">Abrir turno</button></div>`}
      <div class="card">
        <h3>Cobrar boleto</h3>
        <form class="scan" id="scanForm">
           <input id="scan" placeholder="Listo para escanear el boleto…" inputmode="numeric" autocomplete="off" ${can('cobrar') ? '' : 'disabled'}>
          <button class="btn pri big" ${can('cobrar') ? '' : 'disabled'}>Cobrar</button>
        </form>
        <p class="muted small" style="margin:.5rem 0 0">Atajos: <span class="kbd">F2</span> ingreso rápido · <span class="kbd">F3</span> ingreso manual · <span class="kbd">F4</span> cobrar · <span class="kbd">F8</span> boleto perdido</p>
      </div>
      <div class="acciones">
        <button class="btn acc big" id="bRapido" ${can('ingreso_rapido') ? '' : 'disabled'}><span class="ic">⚡</span>Ingreso rápido <span class="kbd">F2</span></button>
        <button class="btn big" id="bManual" ${can('ingreso_manual') ? '' : 'disabled'}><span class="ic">📝</span>Ingreso manual / mesero <span class="kbd">F3</span></button>
        <button class="btn big" id="bPerdido" ${can('boleto_perdido') ? '' : 'disabled'}><span class="ic">🎫</span>Boleto perdido <span class="kbd">F8</span></button>
        ${can('vender_productos') ? '<button class="btn big" id="bVenta"><span class="ic">🛒</span>Venta de productos <span class="kbd">F9</span></button>' : ''}
        ${can('abrir_pluma') ? '<button class="btn big" id="bPluma"><span class="ic">🚧</span>Abrir pluma</button>' : ''}
      </div>
      ${can('vender_productos') && S.me.productos.some((p) => p.rapido) ? `<div class="card" style="margin-top:.8rem;padding:.7rem 1rem"><div class="small muted" style="font-weight:700;margin-bottom:.4rem">COBRO RÁPIDO DE SERVICIOS</div>
        <div class="row" style="gap:.5rem">${S.me.productos.filter((p) => p.rapido).map((p) => `<button class="btn" data-rap="${p.id}" style="flex-direction:column;min-width:120px;padding:.5rem .8rem"><span>${esc(p.nombre)}</span><b>${p.precio_libre ? 'precio libre' : money(p.precio)}</b></button>`).join('')}</div></div>` : ''}
      ${can('ingreso_rapido') ? `<div class="row" style="margin-top:.6rem"><label class="small muted" for="tarRapida" style="font-weight:600">Tarifa del ingreso rápido:</label>
        <select id="tarRapida" style="max-width:320px" ${can('tarifas_admin') ? '' : 'disabled title="Solo un administrador puede cambiarla"'}>${S.me.tarifas.map((t) => `<option value="${t.id}" ${t.id == tarifaRapida() ? 'selected' : ''}>${esc(t.nombre)}</option>`).join('')}</select></div>` : ''}
      <div class="espacios">
        <div class="kpi ok"><div class="l">Disponibles</div><div class="v" id="kDisp">–</div></div>
        <div class="kpi bad"><div class="l">Ocupados</div><div class="v" id="kOcup">–</div></div>
        <div class="kpi"><div class="l">Meseros / Pensión</div><div class="v" id="kMes">–</div></div>
      </div>
      <div class="card" style="margin-top:1rem">
        <div class="row"><h3 class="grow" style="margin:0">Últimas entradas</h3><button class="btn sm" onclick="ir('dentro')">Ver todos</button></div>
        <div class="tbl-wrap" id="dentroMini"></div>
      </div>
    </div>
    <div>
      <div class="card ${S.me.config.camara_tipo === 'ninguna' ? 'hidden' : ''}"><h3>📷 Cámara de entrada</h3><div id="camBox"></div></div>
      <div class="card"><h3>Última impresión</h3><div id="ultimaImp">${ticketHTML(S.ultimaImpresion)}</div></div>
    </div>
  </div>`;
  $('#abrirT') && ($('#abrirT').onclick = abrirTurnoModal);
  $('#scanForm').onsubmit = (e) => { e.preventDefault(); const v = $('#scan').value.trim(); if (v) { $('#scan').value = ''; abrirCobro(v); } };
  $('#bRapido').onclick = ingresoRapido;
  $('#bManual').onclick = ingresoManual;
  $('#bPerdido').onclick = boletoPerdido;
  $('#bPluma') && ($('#bPluma').onclick = abrirPlumaManual);
  $('#bVenta') && ($('#bVenta').onclick = () => ir('tienda'));
  $$('[data-rap]').forEach((b) => (b.onclick = () => ventaRapida(Number(b.dataset.rap))));
  pintarCamara();
  $('#tarRapida') && ($('#tarRapida').onchange = async (e) => { await fijarTarifa('tarifa_rapida_id', e.target.value, 'Ingreso rápido con tarifa'); setTimeout(focusScan, 50); });
  pintarDentroMini();
  focusScan();
}
function pintarDentroMini() {
  const e = S.estado; if (!e || !$('#dentroMini')) return;
  $('#kDisp').textContent = e.disponibles; $('#kOcup').textContent = e.ocupados; $('#kMes').textContent = e.meseros + ' / ' + e.pensionados;
  const ahora = Date.now();
  $('#dentroMini').innerHTML = e.dentro.length ? `<table><thead><tr><th>Boleto</th><th>Placas</th><th>Vehículo</th><th>Tipo</th><th>Entrada</th><th class="num">Tiempo</th><th></th></tr></thead><tbody>
    ${e.dentro.slice(0, 8).map((d) => `<tr><td class="mono">${folio(d.id)}</td><td><b>${esc(d.placas) || '—'}</b></td><td>${esc([d.marca, d.modelo, d.color].filter(Boolean).join(' '))}</td>
    <td>${chipCliente(d)}</td><td>${fdt(d.entrada)}</td><td class="num">${tiempo((ahora - d.entrada) / 60000)}</td>
    <td class="right">${can('cobrar') ? `<button class="btn sm pri" data-cobrar="${d.id}">Cobrar</button>` : ''}</td></tr>`).join('')}</tbody></table>`
    : '<p class="muted">No hay vehículos dentro.</p>';
  $$('[data-cobrar]', $('#dentroMini')).forEach((b) => (b.onclick = () => abrirCobro(b.dataset.cobrar)));
}
const chipCliente = (d) => `<span class="chip ${d.cliente === 'mesero' ? 'warn' : d.cliente === 'pension' ? 'pri' : d.cliente === 'normal' ? '' : 'ok'}">${CLIENTE[d.cliente] || d.cliente}${d.cliente_nombre ? ': ' + esc(d.cliente_nombre) : ''}</span>`;
const tarifaRapida = () => { const c = S.me.config; const v = Number(c.tarifa_rapida_id) || c.tarifa_default_id; return S.me.tarifas.some((t) => t.id == v) ? v : S.me.tarifas[0]?.id; };
// Guarda una tarifa predeterminada (requiere permiso de tarifas)
async function fijarTarifa(clave, id, etiqueta) {
  try { await post('/api/config', { [clave]: Number(id) }); await recargarMe(); toast(`${etiqueta}: ${S.me.tarifas.find((t) => t.id == id)?.nombre || ''}`, 'ok'); return true; }
  catch (e) { errToast(e); return false; }
}

async function abrirPlumaManual() {
  const motivo = await pedirTexto('Abrir pluma manualmente', 'Motivo (queda en bitácora)', { ok: 'Abrir pluma' });
  if (!motivo) return;
  try { const r = await post('/api/pluma', { motivo }); r.ok ? toast(r.simulado ? 'Pluma: relevador no configurado (simulado)' : 'Pluma abierta', r.simulado ? 'warn' : 'ok') : toast(r.error, 'bad'); }
  catch (e) { errToast(e); }
}

/* ---------- Ingresos ---------- */
async function registrarEntrada(body, m) {
  try {
    const foto = S.me.config.camara_tipo === 'usb' ? capturarUSB() : null;
    const r = await post('/api/entrada', body);
    m && m.close();
    if (foto) post(`/api/ticket/${r.ticket.id}/foto`, { imagen: foto }).then(() => { S.ultimaFoto = r.ticket.id; }).catch((e) => toast('No se guardó la foto: ' + e.message, 'warn'));
    else if (S.me.config.camara_tipo === 'usb') toast('Cámara USB: ' + (CAM.error || 'no está lista') + '. La entrada se registró sin foto.', 'warn');
    if (r.foto) { if (r.foto.ok) { S.ultimaFoto = r.ticket.id; pintarCamara(); } else toast(r.foto.error + '. La entrada se registró sin foto.', 'warn'); }
    manejarImpresion(r.impresion, 'Boleto ' + r.folio);
    if (r.aviso) toast(r.aviso, 'bad');
    else if (r.cliente) toast('Entrada de ' + CLIENTE[r.ticket.cliente] + ': ' + r.cliente, 'ok');
    pantalla('entrada', { folio: r.folio, placas: r.ticket.placas, vehiculo: [r.ticket.marca, r.ticket.modelo, r.ticket.color].filter(Boolean).join(' '), entrada: r.ticket.entrada, tarifa: r.tarifa, cliente: r.cliente }, 9000);
    if (r.pluma && !r.pluma.ok) toast(r.pluma.error, 'bad');
    await refrescarEstado();
    return r;
  } catch (e) {
    if (e.status === 409 && /ya están dentro/.test(e.message)) {
      if (await confirmar(esc(e.message) + '<br><br>¿Registrar la entrada de todos modos?', { ok: 'Sí, registrar' })) return registrarEntrada({ ...body, forzar: true }, m);
    } else if (e.status === 423) {
      if (await confirmar(`<b style="color:var(--bad)">⛔ ${esc(e.message)}</b><br><br>¿Dar entrada cobrando la tarifa normal? (la pluma no abre hasta que confirme)`, { ok: 'Sí, entrada con tarifa normal', peligro: true })) return registrarEntrada({ ...body, forzar_vencida: true }, m);
    } else errToast(e);
  }
}
async function ingresoRapido() {
  if (!can('ingreso_rapido') || sinTurno(ingresoRapido)) return;
  if (S.estado?.lleno && !(await confirmar('El estacionamiento está <b>LLENO</b>. ¿Registrar la entrada de todos modos?'))) return;
  registrarEntrada({ modo: 'rapido', cliente: 'normal', tarifa_id: $('#tarRapida')?.value || tarifaRapida() });
}
async function ingresoManual(pre = {}) {
  if (!can('ingreso_manual') || sinTurno(() => ingresoManual(pre))) return;
  let clientes = [];
  try { clientes = (await api('/api/clientes')).filter((c) => c.activo); } catch { /* sin permiso */ }
  const cfg = S.me.config;
  const vehs = clientes.flatMap((c) => c.vehiculos.map((v) => ({ ...v, cli: c })));
  const placaN = (p) => String(p || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const optTar = (sel) => S.me.tarifas.map((t) => `<option value="${t.id}" ${t.id == sel ? 'selected' : ''}>${esc(t.nombre)}</option>`).join('');
  const campos = (pfx) => `<div class="grid g2">
      <label class="f">Placas<input data-k="placas" id="${pfx}placas" style="text-transform:uppercase;font-weight:700"></label>
      <label class="f">Marca<input data-k="marca" list="dlMarcas"></label>
      <label class="f">Modelo<input data-k="modelo"></label>
      <label class="f">Color<input data-k="color" list="dlColores"></label></div>`;
  const m = modal(`<div class="hd"><h3>Ingreso manual de vehículo</h3><button class="btn sm" data-close>✕</button></div>
  <div class="bd grid">
    <div class="seg" id="segCli">
      <button type="button" data-c="normal" class="on">🚗 Cliente normal</button>
      <button type="button" data-c="mesero">🍽️ Mesero</button>
      <button type="button" data-c="registrado">⭐ Cliente registrado</button>
    </div>

    <section data-p="normal" class="grid">
      ${campos('n')}
      <div id="nDet"></div>
      <div class="row" style="align-items:flex-end"><label class="f grow">Tarifa<select id="nTar">${optTar(cfg.tarifa_default_id)}</select></label>
        ${can('tarifas_admin') ? '<button type="button" class="btn sm" id="nFijar" title="Que esta tarifa salga elegida siempre para clientes normales">⭐ Usar siempre para clientes normales</button>' : ''}</div>
      <label class="f">Notas<input id="nNotas" placeholder="Opcional"></label>
    </section>

    <section data-p="mesero" class="grid hidden">
      <input id="mBus" placeholder="🔍 Buscar mesero ya registrado por nombre o placas">
      <div id="mLista" class="tbl-wrap" style="max-height:190px;overflow-y:auto"></div>
      <div id="mSel"></div>
      <div id="mNuevo" class="paybox grid">
        <b class="small">Mesero nuevo (se guarda para la próxima vez)</b>
        <div class="grid g3">
          <label class="f">Nombre del mesero<input id="mNombre"></label>
          <label class="f">Teléfono<input id="mTel"></label>
          <label class="f">Restaurante / notas<input id="mNotas"></label>
        </div>
        ${campos('m')}
      </div>
      <div class="row" style="align-items:flex-end"><label class="f grow">Tarifa<select id="mTar">${optTar(cfg.tarifa_mesero_id)}</select></label>
        ${can('tarifas_admin') ? '<button type="button" class="btn sm" id="mFijar" title="Que esta tarifa salga elegida siempre para meseros">⭐ Usar siempre para meseros</button>' : ''}</div>
    </section>

    <section data-p="registrado" class="grid hidden">
      <input id="rBus" placeholder="🔍 Buscar cliente registrado por placas o nombre">
      <div id="rLista" class="tbl-wrap" style="max-height:300px;overflow-y:auto"></div>
      <div id="rSel"></div>
    </section>

    <datalist id="dlMarcas">${MARCAS.map((x) => `<option value="${x}">`).join('')}</datalist>
    <datalist id="dlColores">${COLORES.map((x) => `<option value="${x}">`).join('')}</datalist>
  </div>
  <div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn acc big" id="bIng">Dar ingreso e imprimir</button></div>`, { cls: 'wide' });
  const P = (n) => $(`[data-p=${n}]`, m.el);
  const leer = (sec) => Object.fromEntries($$('[data-k]', sec).map((i) => [i.dataset.k, i.value.trim()]));
  let modo = 'normal', selMesero = null, selReg = null, detNormal = null;
  const chipTipo = (c) => `<span class="chip ${c.tipo === 'mesero' ? 'warn' : c.tipo === 'pension' ? 'pri' : 'ok'}">${esc(S.me.tiposCliente[c.tipo] || c.tipo)}</span>`;
  const tarjeta = (v) => `<div class="alert ${v.cli.estado === 'vencida' ? 'bad' : 'ok'}">⭐ <b>${esc(v.cli.nombre)}</b> ${chipTipo(v.cli)} · <b class="mono">${esc(v.placas) || 's/placas'}</b> ${esc([v.marca, v.modelo, v.color].filter(Boolean).join(' '))}
    ${v.cli.tipo === 'pension' ? '<br>Pensión ' + v.cli.estado + (v.cli.vigente_hasta ? ' hasta ' + fd(v.cli.vigente_hasta) : '') : ''}${v.cli.dentro ? '<br>Ya tiene ' + v.cli.dentro + ' vehículo(s) dentro' : ''}</div>`;
  const lista = (cont, items, sel, onSel, vacio) => {
    cont.innerHTML = items.length ? `<table><tbody>${items.slice(0, 50).map((v) => `<tr style="${sel && sel.id === v.id ? 'background:#fff4ec' : ''}">
      <td><b>${esc(v.cli.nombre)}</b><div class="small muted">${chipTipo(v.cli)} ${esc(v.cli.telefono || '')}</div></td>
      <td class="mono"><b>${esc(v.placas) || '—'}</b></td><td>${esc([v.marca, v.modelo, v.color].filter(Boolean).join(' '))}</td>
      <td class="right"><button type="button" class="btn sm ${sel && sel.id === v.id ? 'acc' : ''}" data-v="${v.id}">${sel && sel.id === v.id ? 'Elegido' : 'Elegir'}</button></td></tr>`).join('')}</tbody></table>`
      : `<p class="muted small">${vacio}</p>`;
    $$('[data-v]', cont).forEach((b) => (b.onclick = () => onSel(vehs.find((v) => v.id == b.dataset.v))));
  };
  const filtra = (arr, q) => {
    const s = q.trim().toUpperCase(), pn = placaN(q);
    return arr.filter((v) => !s || v.cli.nombre.toUpperCase().includes(s) || (pn && placaN(v.placas).includes(pn)) || (v.marca + ' ' + v.modelo).toUpperCase().includes(s));
  };
  const boton = () => {
    const b = $('#bIng', m.el);
    if (modo === 'mesero') b.textContent = selMesero ? 'Dar ingreso e imprimir' : 'Registrar mesero, dar ingreso e imprimir';
    else if (modo === 'registrado') { b.textContent = 'Dar ingreso e imprimir'; b.disabled = !selReg; return; }
    else b.textContent = 'Dar ingreso e imprimir';
    b.disabled = false;
  };
  // --- Meseros
  const meseros = () => vehs.filter((v) => v.cli.tipo === 'mesero');
  const pintarMeseros = () => lista($('#mLista', m.el), filtra(meseros(), $('#mBus', m.el).value), selMesero, (v) => {
    selMesero = selMesero && selMesero.id === v.id ? null : v;
    $('#mSel', m.el).innerHTML = selMesero ? tarjeta(selMesero) : '';
    $('#mNuevo', m.el).classList.toggle('hidden', !!selMesero);
    if (selMesero) $('#mTar', m.el).value = selMesero.cli.tarifa_id || cfg.tarifa_mesero_id;
    pintarMeseros(); boton();
  }, meseros().length ? 'Ningún mesero coincide. Regístrelo abajo como mesero nuevo.' : 'Todavía no hay meseros registrados. Registre el primero abajo.');
  $('#mBus', m.el).oninput = pintarMeseros;
  // --- Registrados
  const pintarReg = () => {
    const q = $('#rBus', m.el).value;
    lista($('#rLista', m.el), q.trim() ? filtra(vehs, q) : vehs, selReg, (v) => { selReg = v; $('#rSel', m.el).innerHTML = tarjeta(v); pintarReg(); boton(); },
      vehs.length ? 'No se encontró ningún cliente con esa placa o nombre.' : 'No hay clientes registrados. Se dan de alta en "Clientes y pensiones" o como mesero nuevo.');
  };
  $('#rBus', m.el).oninput = pintarReg;
  // --- Normal: si las placas son de un cliente registrado, avisar y usarlo
  const nPl = $('#nplacas', m.el);
  nPl.addEventListener('input', () => {
    detNormal = vehs.find((x) => placaN(x.placas) && placaN(x.placas) === placaN(nPl.value)) || null;
    $('#nDet', m.el).innerHTML = detNormal ? tarjeta(detNormal) + '<p class="small muted" style="margin:.2rem 0 0">Estas placas son de un cliente registrado: entrará con su tarifa.</p>' : '';
  });
  const setModo = (c) => {
    modo = c;
    $$('#segCli button', m.el).forEach((b) => b.classList.toggle('on', b.dataset.c === c));
    ['normal', 'mesero', 'registrado'].forEach((n) => P(n).classList.toggle('hidden', n !== c));
    if (c === 'mesero') { pintarMeseros(); setTimeout(() => $('#mBus', m.el).focus(), 20); }
    if (c === 'registrado') { pintarReg(); setTimeout(() => $('#rBus', m.el).focus(), 20); }
    if (c === 'normal') setTimeout(() => nPl.focus(), 20);
    boton();
  };
  $$('#segCli button', m.el).forEach((b) => (b.onclick = () => setModo(b.dataset.c)));
  const enviar = () => {
    if (modo === 'normal') {
      const d = leer(P('normal'));
      if (detNormal) return registrarEntrada({ modo: 'manual', cliente: 'registrado', vehiculo_id: detNormal.id, notas: $('#nNotas', m.el).value }, m);
      return registrarEntrada({ modo: 'manual', cliente: 'normal', ...d, tarifa_id: $('#nTar', m.el).value, notas: $('#nNotas', m.el).value }, m);
    }
    if (modo === 'mesero') {
      if (selMesero) return registrarEntrada({ modo: 'manual', cliente: 'registrado', vehiculo_id: selMesero.id, tarifa_id: $('#mTar', m.el).value }, m);
      const d = leer($('#mNuevo', m.el));
      const nombre = $('#mNombre', m.el).value.trim();
      if (!nombre) { toast('Escriba el nombre del mesero', 'warn'); return $('#mNombre', m.el).focus(); }
      if (!d.placas) { toast('Escriba las placas del carro del mesero', 'warn'); return $('#mplacas', m.el).focus(); }
      return registrarEntrada({ modo: 'manual', cliente: 'mesero', ...d, tarifa_id: $('#mTar', m.el).value,
        nuevo_mesero: { nombre, telefono: $('#mTel', m.el).value, notas: $('#mNotas', m.el).value } }, m);
    }
    if (!selReg) return toast('Busque y elija al cliente registrado', 'warn');
    registrarEntrada({ modo: 'manual', cliente: 'registrado', vehiculo_id: selReg.id }, m);
  };
  $('#bIng', m.el).onclick = enviar;
  const marcaFija = () => {
    const nf = $('#nFijar', m.el), mf = $('#mFijar', m.el);
    if (nf) nf.classList.toggle('acc', $('#nTar', m.el).value == S.me.config.tarifa_default_id);
    if (mf) mf.classList.toggle('acc', $('#mTar', m.el).value == S.me.config.tarifa_mesero_id);
  };
  $('#nTar', m.el).addEventListener('change', marcaFija); $('#mTar', m.el).addEventListener('change', marcaFija);
  $('#nFijar', m.el) && ($('#nFijar', m.el).onclick = async () => { await fijarTarifa('tarifa_default_id', $('#nTar', m.el).value, 'Clientes normales con tarifa'); marcaFija(); });
  $('#mFijar', m.el) && ($('#mFijar', m.el).onclick = async () => { await fijarTarifa('tarifa_mesero_id', $('#mTar', m.el).value, 'Meseros con tarifa'); marcaFija(); });
  marcaFija();
  m.el.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || e.target.tagName === 'BUTTON') return;
    e.preventDefault();
    if (e.target.id === 'mBus' || e.target.id === 'rBus') {
      // Enter en la búsqueda: si hay un solo resultado, elegirlo
      const btns = $$(`#${e.target.id === 'mBus' ? 'mLista' : 'rLista'} [data-v]`, m.el);
      if (btns.length === 1) btns[0].click();
      return;
    }
    enviar();
  });
  if (pre.modo) setModo(pre.modo); else setModo('normal');
  if (pre.placas) { nPl.value = pre.placas; nPl.dispatchEvent(new Event('input')); }
}
const datosPantallaCobro = (tk, c) => ({ folio: folio(tk.id), placas: tk.placas, vehiculo: [tk.marca, tk.modelo, tk.color].filter(Boolean).join(' '),
  cliente: c.cliente?.nombre || '', tipo: CLIENTE[tk.cliente], entrada: c.entrada, salida: c.salida, tiempo: c.tiempo, tarifa: c.tarifa?.nombre || '',
  subtotal: c.subtotal, descuento: c.descuento, convenio: c.convenio?.nombre || '', cargo_perdido: c.cargo_perdido, extras: c.extras, total: c.total,
  cortesia: c.notas.find((n) => n.startsWith('Cortesía')) || '' });
function selectorExtras(cont, extras, onChange) {
  const prods = S.me.productos;
  const pintar = () => {
    cont.innerHTML = `<div class="row"><select id="selProd" class="grow"><option value="">+ Agregar producto o servicio…</option>${prods.map((p) => `<option value="${p.id}">${esc(p.nombre)} · ${p.precio_libre ? 'precio libre' : money(p.precio)}</option>`).join('')}</select></div>
      ${extras.length ? `<table style="margin-top:.4rem"><tbody>${extras.map((e, i) => `<tr><td>${esc(nombreItem(e))}</td>
        <td style="width:120px"><div class="row" style="gap:.3rem;flex-wrap:nowrap"><button type="button" class="btn sm" data-m="${i}">−</button><b>${e.cantidad}</b><button type="button" class="btn sm" data-p="${i}">+</button></div></td>
        <td class="num">${money(precioItem(e) * e.cantidad)}</td></tr>`).join('')}</tbody></table>` : ''}`;
    $('#selProd', cont).onchange = async (ev) => { const id = Number(ev.target.value); if (!id) return; if (await agregarItem(extras, id)) { pintar(); onChange(); } else ev.target.value = ''; };
    $$('[data-p]', cont).forEach((b) => (b.onclick = () => { extras[b.dataset.p].cantidad++; pintar(); onChange(); }));
    $$('[data-m]', cont).forEach((b) => (b.onclick = () => { const e = extras[b.dataset.m]; if (--e.cantidad <= 0) extras.splice(b.dataset.m, 1); pintar(); onChange(); }));
  };
  pintar();
}
async function abrirCobro(id, opt = {}) {
  if (!can('cobrar') && !can('boleto_perdido')) return;
  if (sinTurno(() => abrirCobro(id, opt))) return;
  const st = { convenio_id: '', tarifa_id: '', perdido: !!opt.perdido, cortesia_para: '', cortesia_motivo: '', perdido_datos: opt.perdido_datos || null, extras: [] };
  let data;
  const cargar = async () => {
    const qs = new URLSearchParams({ convenio_id: st.convenio_id, tarifa_id: st.tarifa_id, perdido: st.perdido ? '1' : '', cortesia_para: st.cortesia_para, extras: JSON.stringify(st.extras) });
    data = await api(`/api/ticket/${encodeURIComponent(id)}?${qs}`);
  };
  try { await cargar(); } catch (e) { errToast(e); return; }
  const tk = data.ticket;
  let cobrado = false;
  const m = modal(`<div class="hd"><h3>${st.perdido ? '🎫 Cobro de boleto PERDIDO' : 'Cobrar boleto'} <span class="mono">${folio(tk.id)}</span></h3><button class="btn sm" data-close>✕</button></div>
    <div class="bd cobro">
      <div>
        <dl class="det" id="det"></dl>
        <div class="grid" style="margin-top:1rem">
          ${can('cambiar_tarifa') ? `<label class="f">Tarifa<select id="selTar"><option value="">Tarifa de entrada (${esc(data.tarifa_entrada)})</option>${S.me.tarifas.map((t) => `<option value="${t.id}">${esc(t.nombre)}</option>`).join('')}</select></label>` : ''}
          ${can('aplicar_convenio') && S.me.convenios.length ? `<label class="f">Convenio con negocio<select id="selConv"><option value="">Sin convenio</option>${S.me.convenios.map((c) => `<option value="${c.id}">${esc(c.nombre)}</option>`).join('')}</select></label>` : ''}
          ${can('cortesia') ? `<label class="check"><input type="checkbox" id="chkCort"> Cortesía (salida sin costo)</label>
            <div id="boxCort" class="hidden grid paybox"><label class="f">¿Para quién es la cortesía?${(S.me.config.cortesia_lista || []).length ? `<select id="cortPara"><option value="">Elija…</option>${S.me.config.cortesia_lista.map((x) => `<option>${esc(x)}</option>`).join('')}</select>` : '<input id="cortPara" placeholder="Nombre de la persona o empresa">'}</label>
            <label class="f">Motivo (opcional)<input id="cortMot" placeholder="Ej. proveedor, socio, compensación"></label>
            <button type="button" class="btn sm pri" id="cortOk">Aplicar cortesía</button>
            <p class="small muted" style="margin:0">La cortesía no entra como dinero en caja; aparece en el corte y en los reportes.</p></div>` : ''}
          ${can('boleto_perdido') && !st.perdido ? '<label class="check"><input type="checkbox" id="chkPerd"> Cobrar como boleto perdido</label>' : ''}
          ${can('vender_productos') && S.me.productos.length ? '<div><div class="small muted" style="font-weight:600;margin-bottom:.25rem">Productos y servicios</div><div id="extras"></div></div>' : ''}
        </div>
        <div id="notas" style="margin-top:.8rem"></div>
      </div>
      <div>
        <div class="muted small">TOTAL A PAGAR</div>
        <div class="total-big" id="total"></div>
        <div id="desg" class="small muted" style="margin:.4rem 0 .8rem"></div>
        <div id="pago"></div>
        <p class="muted small" style="margin-top:.8rem">Presione <span class="kbd">Enter</span> o <span class="kbd">F12</span> para abrir la ventana de cobro (efectivo, dólares, tarjeta, transferencia${S.me.mp_configurado ? ', Mercado Pago' : ''} o mixto).</p>
      </div>
    </div>
    <div class="ft">
      ${can('cancelar_ticket') ? '<button class="btn bad" id="bCancel">Cancelar boleto</button>' : ''}
      <span class="grow"></span>
      <button class="btn" data-close>Cerrar</button>
      <button class="btn ok big" id="bCobrar">Cobrar <span class="kbd">Enter</span></button>
    </div>`, { cls: 'wide', onClose: () => { if (!cobrado) pantalla('espera'); } });
  const pintar = () => {
    const c = data.cotizacion;
    $('#det', m.el).innerHTML = `
      <dt>Boleto</dt><dd class="mono">${folio(tk.id)}</dd>
      <dt>Placas</dt><dd>${esc(tk.placas) || '—'}</dd>
      <dt>Vehículo</dt><dd>${esc([tk.marca, tk.modelo, tk.color].filter(Boolean).join(' / ')) || '—'}</dd>
      <dt>Tipo</dt><dd>${CLIENTE[tk.cliente] || tk.cliente}${c.cliente ? ': ' + esc(c.cliente.nombre) : ''}</dd>
      <dt>Entrada</dt><dd>${fdt(c.entrada)}</dd>
      <dt>Salida</dt><dd>${fdt(c.salida)}</dd>
      <dt>Tiempo</dt><dd>${c.tiempo}</dd>
      <dt>Tarifa</dt><dd>${esc(c.tarifa?.nombre || '—')}</dd>
      <dt>Cálculo</dt><dd class="small">${esc(c.detalle)}</dd>
      ${tk.foto ? `<dt>Foto</dt><dd><img src="/api/ticket/${tk.id}/foto" alt="Foto de entrada" style="max-width:220px;border-radius:8px;cursor:zoom-in" onclick="verFoto(${tk.id})"></dd>` : ''}`;
    $('#total', m.el).textContent = money(c.total);
    $('#desg', m.el).innerHTML = [`Estacionamiento ${money(c.subtotal)}`, c.descuento ? `${st.cortesia_para ? 'Cortesía' : 'Descuento'} −${money(c.descuento)}${c.convenio ? ' (' + esc(c.convenio.nombre) + ')' : ''}` : '',
      c.cargo_perdido ? `Boleto perdido +${money(c.cargo_perdido)}` : '', c.extras_total ? `Productos/servicios +${money(c.extras_total)}` : ''].filter(Boolean).join(' · ');
    $('#notas', m.el).innerHTML = c.notas.map((n) => `<div class="alert ${/VENCIDA/.test(n) ? 'bad' : 'pri'}" style="margin-bottom:.4rem">${esc(n)}</div>`).join('');
    const dp = datosPantallaCobro(tk, c);
    pantalla('cobro', dp);
    if (c.total > 0) {
      $('#pago', m.el).innerHTML = '';
      $('#bCobrar', m.el).innerHTML = 'Cobrar <span class="kbd">Enter</span>';
    } else {
      $('#pago', m.el).innerHTML = '<div class="alert ok">Sin costo: solo registrar la salida.</div>'; $('#bCobrar', m.el).innerHTML = 'Dar salida <span class="kbd">Enter</span>';
    }
    setTimeout(() => { if (!$('#modals .vc-bg') && !['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)) $('#bCobrar', m.el)?.focus(); }, 60);
  };
  const recotizar = async () => { try { await cargar(); pintar(); } catch (e) { errToast(e); } };
  $('#selTar', m.el) && ($('#selTar', m.el).onchange = (e) => { st.tarifa_id = e.target.value; recotizar(); });
  $('#selConv', m.el) && ($('#selConv', m.el).onchange = (e) => { st.convenio_id = e.target.value; recotizar(); });
  $('#chkPerd', m.el) && ($('#chkPerd', m.el).onchange = (e) => { st.perdido = e.target.checked; recotizar(); });
  $('#extras', m.el) && selectorExtras($('#extras', m.el), st.extras, recotizar);
  if ($('#chkCort', m.el)) {
    $('#chkCort', m.el).onchange = (e) => {
      $('#boxCort', m.el).classList.toggle('hidden', !e.target.checked);
      if (e.target.checked) $('#cortPara', m.el).focus(); else { st.cortesia_para = ''; st.cortesia_motivo = ''; recotizar(); }
    };
    const aplicar = () => {
      const para = $('#cortPara', m.el).value.trim();
      if (!para) return toast('Escriba para quién es la cortesía', 'warn');
      st.cortesia_para = para; st.cortesia_motivo = $('#cortMot', m.el).value.trim(); recotizar();
    };
    $('#cortOk', m.el).onclick = aplicar;
    $('#cortPara', m.el).onkeydown = $('#cortMot', m.el).onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); aplicar(); } };
  }
  let enviando = false;
  async function cobrar() {
    if (enviando) return;
    if ($('#chkCort', m.el)?.checked && !st.cortesia_para) return toast('Escriba para quién es la cortesía y presione "Aplicar cortesía"', 'warn');
    const c = data.cotizacion, dp = datosPantallaCobro(tk, c);
    let cobro = null;
    if (c.total > 0) {
      enviando = true;
      cobro = await ventanaCobro({ total: c.total, titulo: 'Cobrar boleto ' + folio(tk.id), detalle: [tk.placas, c.tiempo, c.tarifa?.nombre].filter(Boolean).join(' · '), referencia: folio(tk.id),
        onCambio: (v) => pantalla('cobro', { ...dp, recibido: v.pagado, cambio: v.dif >= 0 ? v.dif : null }) });
      enviando = false;
      if (!cobro) { pantalla('cobro', dp); $('#bCobrar', m.el).focus(); return; }
    }
    enviando = true; $('#bCobrar', m.el).disabled = true;
    try {
      const r = await post(`/api/ticket/${tk.id}/cobrar`, { ...st, ...(cobro ? cobro.valores : {}), salida: c.salida, no_imprimir: cobro ? !cobro.imprimir : false });
      cobrado = true; m.close();
      if (r.pluma && !r.pluma.ok) toast(r.pluma.error, 'bad');
      pantalla('pagado', { ...datosPantallaCobro(tk, r.cotizacion), recibido: r.pago ? r2(r.pago.pesos + r.pago.usd_mxn + r.pago.tarjeta + (r.pago.transferencia || 0)) : 0, cambio: r.pago ? r.pago.cambio : 0 }, 15000);
      await refrescarEstado();
      trasCobro(r, cobro, 'Comprobante', () => post(`/api/ticket/${tk.id}/reimprimir`, { tipo: 'copia' }));
    } catch (e) { errToast(e); enviando = false; $('#bCobrar', m.el).disabled = false; }
  }
  $('#bCobrar', m.el).onclick = cobrar;
  m.el.addEventListener('keydown', (e) => {
    if (e.key === 'F12' || (e.key === 'Enter' && !['cortPara', 'cortMot'].includes(e.target.id) && !(e.target.tagName === 'BUTTON' && e.target.id !== 'bCobrar'))) { e.preventDefault(); e.stopPropagation(); cobrar(); }
  });
  $('#bCancel', m.el) && ($('#bCancel', m.el).onclick = async () => {
    const motivo = await pedirTexto('Cancelar boleto ' + folio(tk.id), 'Motivo de la cancelación', { ok: 'Cancelar boleto', peligro: true });
    if (!motivo) return;
    try { await post(`/api/ticket/${tk.id}/cancelar`, { motivo }); m.close(); toast('Boleto cancelado', 'ok'); refrescarEstado(); } catch (e) { errToast(e); }
  });
  pintar();
}
// Después de cobrar: muestra la impresión (o sólo abre el cajón si eligió "sin imprimir") y el cambio
function trasCobro(r, cobro, etiqueta, imprimirCopia) {
  if (cobro && !cobro.imprimir) {
    if (r.impresion && !r.impresion.ok) toast('No se pudo abrir el cajón: ' + r.impresion.error, 'bad');
    r.preguntar_copia = false; r.impresion = null; r.sinImprimir = true;
  } else manejarImpresion(r.impresion, etiqueta);
  resultadoCobro(r, imprimirCopia);
}
const recibidoTxt = (p) => [p.pesos ? money(p.pesos) : '', p.usd ? usd(p.usd) : '', p.tarjeta ? (p.mp_order_id ? 'Mercado Pago ' : 'tarjeta ') + money(p.tarjeta) : '', p.transferencia ? 'transferencia ' + money(p.transferencia) : ''].filter(Boolean).join(' + ');
function resultadoCobro(r, imprimirCopia) {
  const p = r.pago;
  const m = modal(`<div class="hd"><h3>✅ ${p ? 'Cobro registrado' : 'Salida registrada'}</h3></div>
    <div class="bd center">
      ${p ? `<div class="muted">Cambio a entregar</div><div class="cambio-big" style="font-size:3.2rem">${money(p.cambio)}</div>
      <p class="muted small">Total ${money(p.total)} · Recibido: ${recibidoTxt(p)}</p>`
        : `<p>${r.ticket?.cortesia_para ? 'Cortesía para <b>' + esc(r.ticket.cortesia_para) + '</b>. No entra dinero a caja.' : 'Salida registrada sin costo.'}</p>`}
      ${r.preguntar_copia ? '<p style="font-weight:700">¿Imprimir un segundo ticket como comprobante del cajero?</p>' : ''}
    </div>
    <div class="ft">
      ${r.impresion ? '<button class="btn" id="bVer">Ver ticket</button>' : ''}${r.sinImprimir && imprimirCopia ? '<button class="btn" id="bImpAhora">🖨️ Imprimir comprobante</button>' : ''}<span class="grow"></span>
      ${r.preguntar_copia ? '<button class="btn" data-close autofocus>No</button><button class="btn pri" id="bCopia">Sí, imprimir copia</button>' : '<button class="btn pri" data-close autofocus>Listo</button>'}
    </div>`);
  $('#bVer', m.el) && ($('#bVer', m.el).onclick = () => verTicket(r.impresion));
  $('#bImpAhora', m.el) && ($('#bImpAhora', m.el).onclick = async () => { try { manejarImpresion(await imprimirCopia(), 'Comprobante'); } catch (e) { errToast(e); } m.close(); });
  $('#bCopia', m.el) && ($('#bCopia', m.el).onclick = async () => { try { manejarImpresion(await imprimirCopia(), 'Copia del cajero'); } catch (e) { errToast(e); } m.close(); });
  setTimeout(() => $('[data-close]', m.el)?.focus(), 50);
}

/* ---------- Venta de productos y servicios ---------- */
// Pide el importe de un servicio con precio libre (ej. renta de lona)
function pedirImporte(p) {
  return new Promise((resolve) => {
    const m = modal(`<div class="hd"><h3>${esc(p.nombre)}</h3><button class="btn sm" data-close>✕</button></div>
      <form class="bd grid"><label class="f">Importe a cobrar (MXN)<input name="precio" type="number" min="0.01" step="0.01" required autofocus></label>
      <label class="f">Nota (opcional)<input name="nota" maxlength="40" placeholder="Ej. evento, nombre del cliente"></label>
      <div class="ft" style="padding:0;border:0;position:static"><button type="button" class="btn" data-close>Cancelar</button><button class="btn ok">Agregar</button></div></form>`, { onClose: () => resolve(null) });
    $('form', m.el).onsubmit = (e) => { e.preventDefault(); const d = formData(e.target); const v = Number(d.precio); if (!(v > 0)) return; resolve({ precio: v, nota: d.nota || '' }); m.close(); };
  });
}
const precioItem = (i) => (i.precio != null ? i.precio : (S.me.productos.find((x) => x.id === i.producto_id) || {}).precio || 0);
const nombreItem = (i) => { const p = S.me.productos.find((x) => x.id === i.producto_id) || {}; return p.nombre + (i.nota ? ' (' + i.nota + ')' : ''); };
async function agregarItem(items, id) {
  const p = S.me.productos.find((x) => x.id === id); if (!p) return false;
  if (p.precio_libre) { const r = await pedirImporte(p); if (!r) return false; items.push({ producto_id: id, cantidad: 1, ...r }); return true; }
  const ex = items.find((x) => x.producto_id === id); ex ? ex.cantidad++ : items.push({ producto_id: id, cantidad: 1 });
  return true;
}
const jsonArr = (s) => { try { const a = JSON.parse(s || '[]'); return Array.isArray(a) ? a : []; } catch { return []; } };
/* ---------- Boleto perdido ---------- */
async function boletoPerdido() {
  if (!can('boleto_perdido') || sinTurno(boletoPerdido)) return;
  await refrescarEstado();
  let sel = null;
  const m = modal(`<div class="hd"><h3>🎫 Boleto perdido</h3><button class="btn sm" data-close>✕</button></div>
    <div class="bd grid">
      <p class="muted" style="margin:0">1) Localice el vehículo por placas, marca o color. 2) Capture los datos de quien recoge. 3) Imprima el formato para firma y cobre.</p>
      <input id="bq" placeholder="Buscar placas, marca, color o número de boleto" autofocus>
      <div class="tbl-wrap" style="max-height:220px;overflow-y:auto" id="lst"></div>
      <form id="fp" class="grid hidden">
        <div class="alert pri" id="selInfo"></div>
        <div class="grid g3">
          <label class="f">Nombre completo<input name="nombre" required></label>
          <label class="f">Identificación (tipo y número)<input name="identificacion" placeholder="INE, licencia…"></label>
          <label class="f">Teléfono<input name="telefono"></label>
          <label class="f">Placas<input name="placas" style="text-transform:uppercase"></label>
          <label class="f">Marca<input name="marca"></label>
          <label class="f">Modelo<input name="modelo"></label>
          <label class="f">Color<input name="color"></label>
        </div>
        <p class="small muted" style="margin:0">Cargo por boleto perdido: <b>${money(S.me.config.costo_boleto_perdido)}</b> más el tiempo de estancia.</p>
      </form>
    </div>
    <div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn" id="bForm" disabled>🖨️ Imprimir formato</button><button class="btn ok" id="bCob" disabled>Continuar al cobro</button></div>`, { cls: 'wide' });
  const ahora = Date.now();
  const pintar = () => {
    const s = $('#bq', m.el).value.trim().toUpperCase().replace(/[\s-]/g, '');
    const lista = S.estado.dentro.filter((d) => !s || folio(d.id).includes(s) || (d.placas || '').toUpperCase().replace(/[\s-]/g, '').includes(s) || [d.marca, d.modelo, d.color].join(' ').toUpperCase().includes(s));
    $('#lst', m.el).innerHTML = lista.length ? `<table><thead><tr><th>Boleto</th><th>Placas</th><th>Vehículo</th><th>Entrada</th><th class="num">Tiempo</th><th></th></tr></thead><tbody>
      ${lista.map((d) => `<tr style="${sel && sel.id === d.id ? 'background:#fff3d6' : ''}"><td class="mono">${folio(d.id)}</td><td><b>${esc(d.placas) || '—'}</b></td><td>${esc([d.marca, d.modelo, d.color].filter(Boolean).join(' '))}</td><td>${fdt(d.entrada)}</td><td class="num">${tiempo((ahora - d.entrada) / 60000)}</td><td><button class="btn sm" data-s="${d.id}">Elegir</button></td></tr>`).join('')}</tbody></table>`
      : '<p class="muted">No se encontró ningún vehículo dentro con esos datos.</p>';
    $$('[data-s]', m.el).forEach((b) => (b.onclick = () => elegir(S.estado.dentro.find((d) => d.id == b.dataset.s))));
  };
  const elegir = (d) => {
    sel = d; pintar();
    const f = $('#fp', m.el); f.classList.remove('hidden');
    for (const k of ['placas', 'marca', 'modelo', 'color']) f[k].value = d[k] || '';
    $('#selInfo', m.el).innerHTML = `Boleto <b>${folio(d.id)}</b> · entrada ${fdt(d.entrada)} · ${chipCliente(d)}`;
    $('#bForm', m.el).disabled = false; $('#bCob', m.el).disabled = false;
    f.nombre.focus();
  };
  $('#bq', m.el).oninput = pintar;
  $('#bForm', m.el).onclick = async () => {
    try { manejarImpresion(await post('/api/perdido/formato', { ticket_id: sel.id, datos: formData($('#fp', m.el)) }), 'Formato de boleto perdido'); } catch (e) { errToast(e); }
  };
  $('#bCob', m.el).onclick = () => {
    const datos = formData($('#fp', m.el));
    if (!datos.nombre.trim()) return toast('Capture el nombre de quien recoge el vehículo', 'warn');
    m.close(); abrirCobro(sel.id, { perdido: true, perdido_datos: datos });
  };
  pintar();
}

/* ================= VEHÍCULOS DENTRO ================= */
function vistaDentro(main) {
  main.innerHTML = `<div class="card"><div class="row"><h2 class="grow">Vehículos dentro</h2><input id="fDentro" placeholder="Buscar placas, marca, boleto…" style="max-width:300px"></div>
    <div class="tbl-wrap" id="tDentro"></div></div>`;
  $('#fDentro').oninput = pintarTablaDentro;
  pintarTablaDentro();
}
function pintarTablaDentro() {
  const box = $('#tDentro'); if (!box || !S.estado) return;
  const s = ($('#fDentro').value || '').toUpperCase();
  const ahora = Date.now();
  const lista = S.estado.dentro.filter((d) => !s || [folio(d.id), d.placas, d.marca, d.modelo, d.color, d.pensionado].join(' ').toUpperCase().includes(s));
  box.innerHTML = `<p class="muted small">${lista.length} vehículo(s)</p><table><thead><tr><th>Boleto</th><th>Placas</th><th>Marca</th><th>Modelo</th><th>Color</th><th>Tipo</th><th>Tarifa</th><th>Entrada</th><th class="num">Tiempo</th><th></th></tr></thead><tbody>
    ${lista.map((d) => `<tr><td class="mono">${folio(d.id)}${d.foto ? ` <button class="btn sm ghost" data-foto="${d.id}" title="Ver foto de entrada">📷</button>` : ''}</td><td><b>${esc(d.placas) || '—'}</b></td><td>${esc(d.marca)}</td><td>${esc(d.modelo)}</td><td>${esc(d.color)}</td><td>${chipCliente(d)}</td>
      <td class="small">${esc(d.tarifa || '')}</td><td>${fdt(d.entrada)}</td><td class="num">${tiempo((ahora - d.entrada) / 60000)}</td>
      <td class="right" style="white-space:nowrap">${can('reimprimir') ? `<button class="btn sm" data-re="${d.id}" title="Reimprimir boleto">🖨️</button> ` : ''}${can('cobrar') ? `<button class="btn sm pri" data-co="${d.id}">Cobrar</button>` : ''}</td></tr>`).join('')}</tbody></table>`;
  $$('[data-co]', box).forEach((b) => (b.onclick = () => abrirCobro(b.dataset.co)));
  $$('[data-foto]', box).forEach((b) => (b.onclick = () => verFoto(b.dataset.foto)));
  $$('[data-re]', box).forEach((b) => (b.onclick = async () => { try { manejarImpresion(await post(`/api/ticket/${b.dataset.re}/reimprimir`, { tipo: 'entrada' }), 'Boleto'); } catch (e) { errToast(e); } }));
}

/* ================= CLIENTES (meseros, frecuentes, pensionados) ================= */
async function vistaClientes(main) {
  const lista = await api('/api/clientes');
  let tarifas = S.me.tarifas;
  const chip = { vigente: 'ok', 'por vencer': 'warn', vencida: 'bad', inactivo: '', activo: 'ok' };
  const st = S.cli ||= { filtro: 'todos', q: '' };
  main.innerHTML = `<div class="card">
    <div class="row"><h2 class="grow">Clientes y pensiones</h2><input id="fCli" placeholder="Buscar nombre o placas" style="max-width:260px" value="${esc(st.q)}">
    ${can('clientes_admin') ? '<button class="btn acc" id="nCli">+ Nuevo cliente</button>' : ''}</div>
    <p class="muted small" style="margin:.2rem 0 .6rem">Registre a meseros y clientes frecuentes con todos sus carros. Al escribir sus placas en la entrada, el sistema los reconoce y les aplica su tarifa.</p>
    <div class="grid g4" style="margin:.6rem 0">
      <div class="kpi"><div class="l">Meseros</div><div class="v">${lista.filter((p) => p.activo && p.tipo === 'mesero').length}</div></div>
      <div class="kpi ok"><div class="l">Pensiones vigentes</div><div class="v">${lista.filter((p) => p.estado === 'vigente').length}</div></div>
      <div class="kpi bad"><div class="l">Pensiones vencidas</div><div class="v">${lista.filter((p) => p.tipo === 'pension' && p.estado === 'vencida').length}</div></div>
      <div class="kpi pri"><div class="l">Dentro ahora</div><div class="v">${lista.reduce((s, p) => s + p.dentro, 0)}</div></div>
    </div>
    <div class="seg" id="segF">${[['todos', 'Todos'], ['mesero', 'Meseros'], ['frecuente', 'Frecuentes'], ['pension', 'Pensionados'], ['empresa', 'Empresas']].map(([k, v]) => `<button data-f="${k}" class="${st.filtro === k ? 'on' : ''}">${v}</button>`).join('')}</div>
    <div class="tbl-wrap" style="margin-top:.6rem"><table><thead><tr><th>Nombre</th><th>Tipo</th><th>Vehículos</th><th>Tarifa</th><th>Pensión</th><th></th></tr></thead><tbody id="tCli"></tbody></table></div></div>`;
  const botonPension = (p) => p.tipo !== 'pension' ? `<button class="btn sm" data-c="${p.id}">Hacer pensión</button> `
    : p.estado === 'vigente' ? `<button class="btn sm" data-c="${p.id}" title="Ya está pagada; use esto sólo para adelantar el siguiente periodo">Renovar</button> `
    : p.estado === 'por vencer' ? `<button class="btn sm warn" data-c="${p.id}">Renovar (por vencer)</button> `
    : `<button class="btn sm ok" data-c="${p.id}">Cobrar pensión</button> `;
  const pintar = () => {
    const s = st.q.toUpperCase();
    const fl = lista.filter((p) => (st.filtro === 'todos' || p.tipo === st.filtro) && (!s || (p.nombre + ' ' + p.vehiculos.map((v) => v.placas + ' ' + v.marca + ' ' + v.modelo).join(' ')).toUpperCase().includes(s)));
    $('#tCli').innerHTML = fl.map((p) => `<tr style="${p.activo ? '' : 'opacity:.55'}">
      <td><b>${esc(p.nombre)}</b>${p.dentro ? ` <span class="chip pri">${p.dentro} dentro</span>` : ''}<div class="small muted">${esc(p.telefono)}</div></td>
      <td><span class="chip ${p.tipo === 'mesero' ? 'warn' : p.tipo === 'pension' ? 'pri' : 'ok'}">${esc(S.me.tiposCliente[p.tipo] || p.tipo)}</span></td>
      <td class="small">${p.vehiculos.map((v) => `<div><b class="mono">${esc(v.placas) || 's/placas'}</b> ${esc([v.marca, v.modelo, v.color].filter(Boolean).join(' '))}</div>`).join('') || '<span class="muted">—</span>'}</td>
      <td class="small">${esc(p.tarifa || (p.tipo === 'mesero' ? 'Tarifa de meseros' : 'Por defecto'))}</td>
      <td>${p.tipo === 'pension' || p.vigente_hasta ? `<span class="chip ${chip[p.estado]}">${p.estado}</span>${p.tipo === 'pension' && nombreCat(p.pension_categoria) ? ` <span class="chip">${esc(nombreCat(p.pension_categoria))}</span>` : ''}<div class="small muted">${p.vigente_hasta ? 'hasta ' + fd(p.vigente_hasta) : ''}</div>` : '<span class="muted small">—</span>'}</td>
      <td class="right" style="white-space:nowrap">${can('pensiones_cobrar') && p.activo ? botonPension(p) : ''}${can('clientes_admin') ? `<button class="btn sm" data-e="${p.id}">Editar</button>` : ''} ${p.historial.length ? `<button class="btn sm" data-h="${p.id}">Pagos</button>` : ''}</td></tr>`).join('')
      || '<tr><td colspan="6" class="muted">Sin clientes registrados.</td></tr>';
    $$('[data-c]').forEach((b) => (b.onclick = () => cobrarPension(lista.find((p) => p.id == b.dataset.c))));
    $$('[data-e]').forEach((b) => (b.onclick = () => editarCliente(lista.find((p) => p.id == b.dataset.e))));
    $$('[data-h]').forEach((b) => (b.onclick = () => { const p = lista.find((x) => x.id == b.dataset.h); modal(`<div class="hd"><h3>Pagos de pensión · ${esc(p.nombre)}</h3><button class="btn sm" data-close>✕</button></div><div class="bd tbl-wrap"><table><thead><tr><th>Pagado</th><th>Tipo</th><th>Plan</th><th>Desde</th><th>Hasta</th><th class="num">Monto</th><th></th></tr></thead><tbody>${p.historial.map((h) => `<tr><td>${fdt(h.fecha)}</td><td>${esc(h.categoria || '')}</td><td>${S.me.planes[h.plan]}</td><td>${fd(h.desde)}</td><td>${fd(h.hasta)}</td><td class="num">${money(h.monto)}</td><td>${can('reimprimir') ? `<button class="btn sm" data-r="${h.id}">🖨️</button>` : ''}</td></tr>`).join('')}</tbody></table></div>`);
      $$('[data-r]').forEach((x) => (x.onclick = async () => { try { manejarImpresion(await post(`/api/pension-periodo/${x.dataset.r}/reimprimir`, {}), 'Recibo'); } catch (e) { errToast(e); } })); }));
  };
  $('#fCli').oninput = (e) => { st.q = e.target.value; pintar(); };
  $$('#segF button').forEach((b) => (b.onclick = () => { st.filtro = b.dataset.f; $$('#segF button').forEach((x) => x.classList.toggle('on', x === b)); pintar(); }));
  $('#nCli') && ($('#nCli').onclick = () => editarCliente({ tipo: st.filtro !== 'todos' ? st.filtro : 'mesero', vehiculos: [] }));
  pintar();
}
const catsPension = () => S.me.config.pension_categorias || [];
const planesPension = () => Object.entries(S.me.planes).filter(([k]) => (S.me.config.pension_planes || []).includes(k));
const nombreCat = (id) => (catsPension().find((c) => c.id === id) || {}).nombre || '';
function editarCliente(p) {
  const vehs = (p.vehiculos || []).map((v) => ({ ...v }));
  if (!vehs.length) vehs.push({ placas: '', marca: '', modelo: '', color: '' });
  const m = modal(`<div class="hd"><h3>${p.id ? 'Editar' : 'Nuevo'} cliente</h3><button class="btn sm" data-close>✕</button></div>
    <form class="bd grid" id="fC">
      <div class="grid g2">
        <label class="f">Nombre<input name="nombre" value="${esc(p.nombre || '')}" required autofocus></label>
        <label class="f">Teléfono<input name="telefono" value="${esc(p.telefono || '')}"></label>
        <label class="f">Tipo de cliente<select name="tipo">${Object.entries(S.me.tiposCliente).map(([k, v]) => `<option value="${k}" ${p.tipo === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
        <label class="f">Tarifa especial<select name="tarifa_id"><option value="">${'Automática (meseros: tarifa de meseros)'}</option>${S.me.tarifas.map((t) => `<option value="${t.id}" ${p.tarifa_id === t.id ? 'selected' : ''}>${esc(t.nombre)}</option>`).join('')}</select></label>
        <label class="f" id="lCat">Tipo de pensión<select name="pension_categoria">${catsPension().map((c) => `<option value="${esc(c.id)}" ${p.pension_categoria === c.id ? 'selected' : ''}>${esc(c.nombre)}</option>`).join('')}</select></label>
      </div>
      <label class="f">Notas<input name="notas" value="${esc(p.notas || '')}" placeholder="Ej. restaurante donde trabaja, horario"></label>
      <div class="row"><h4 class="grow" style="margin:0">Vehículos del cliente</h4><button type="button" class="btn sm" id="addV">+ Agregar otro carro</button></div>
      <div id="vehs" class="grid"></div>
      <label class="check"><input type="checkbox" name="activo" ${p.activo === 0 ? '' : 'checked'}> Cliente activo</label>
      <datalist id="dlM3">${MARCAS.map((x) => `<option value="${x}">`).join('')}</datalist><datalist id="dlC3">${COLORES.map((x) => `<option value="${x}">`).join('')}</datalist>
    </form><div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn pri" id="bG">Guardar</button></div>`, { cls: 'wide' });
  const pintarV = () => {
    $('#vehs', m.el).innerHTML = vehs.map((v, i) => v.activo === false ? '' : `<div class="paybox grid g4" style="align-items:end">
      <label class="f">Placas<input data-i="${i}" data-k="placas" value="${esc(v.placas)}" style="text-transform:uppercase;font-weight:700"></label>
      <label class="f">Marca<input data-i="${i}" data-k="marca" value="${esc(v.marca)}" list="dlM3"></label>
      <label class="f">Modelo<input data-i="${i}" data-k="modelo" value="${esc(v.modelo)}"></label>
      <div class="row" style="flex-wrap:nowrap"><label class="f grow">Color<input data-i="${i}" data-k="color" value="${esc(v.color)}" list="dlC3"></label><button type="button" class="btn sm bad" data-q="${i}" title="Quitar">✕</button></div></div>`).join('');
    $$('[data-k]', m.el).forEach((inp) => (inp.oninput = () => { vehs[inp.dataset.i][inp.dataset.k] = inp.value; }));
    $$('[data-q]', m.el).forEach((b) => (b.onclick = () => { const v = vehs[b.dataset.q]; if (v.id) v.activo = false; else vehs.splice(b.dataset.q, 1); pintarV(); }));
  };
  $('#addV', m.el).onclick = () => { vehs.push({ placas: '', marca: '', modelo: '', color: '' }); pintarV(); $$('[data-k=placas]', m.el).pop()?.focus(); };
  pintarV();
  const verCat = () => { $('#lCat', m.el).style.display = $('[name=tipo]', m.el).value === 'pension' ? '' : 'none'; };
  $('[name=tipo]', m.el).onchange = verCat; verCat();
  $('#bG', m.el).onclick = async () => {
    try {
      const d = formData($('#fC', m.el));
      ['placas', 'marca', 'modelo', 'color'].forEach((k) => delete d[k]);
      const r = await post('/api/clientes', { ...d, id: p.id, vehiculos: vehs });
      m.close(); toast('Cliente guardado', 'ok');
      if (!p.id && d.tipo === 'pension' && can('pensiones_cobrar') && await confirmar('¿Cobrar la pensión ahora?', { ok: 'Cobrar' })) {
        const lista = await api('/api/clientes'); ir('clientes'); cobrarPension(lista.find((x) => x.id === r.id));
      } else if (S.view === 'clientes') ir('clientes');
    } catch (e) { errToast(e); }
  };
}
function calcHasta(plan, desde) {
  const d = new Date(desde);
  const sumaMeses = (n) => { const x = new Date(d); x.setMonth(x.getMonth() + n); return x; };
  const fin = { semana: new Date(d.getTime() + 7 * 864e5), quincena: new Date(d.getTime() + 15 * 864e5), mes: sumaMeses(1), trimestre: sumaMeses(3), semestre: sumaMeses(6), anual: sumaMeses(12) }[plan];
  if (!fin) return null;
  fin.setHours(0, 0, 0, 0);
  return fin.getTime() - 1;
}
function cobrarPension(p) {
  if (sinTurno(() => cobrarPension(p))) return;
  const cats = catsPension(), planes = planesPension();
  if (!planes.length) return toast('No hay planes de pensión habilitados. Actívelos en Configuración.', 'warn');
  const cat0 = cats.find((c) => c.id === p.pension_categoria) || cats[0];
  const plan0 = planes.some(([k]) => k === 'mes') ? 'mes' : planes[0][0];
  const precioDe = (catId, plan) => ((cats.find((c) => c.id === catId) || {}).precios || {})[plan] || 0;
  const desde0 = p.vigente_hasta && p.vigente_hasta > Date.now() ? inicioDia(p.vigente_hasta + 1000) : inicioDia(Date.now());
  const m = modal(`<div class="hd"><h3>Cobrar pensión · ${esc(p.nombre)}</h3><button class="btn sm" data-close>✕</button></div>
    <div class="bd cobro">
      <div class="grid">
        <p class="muted small" style="margin:0">Vigencia actual: <b>${p.vigente_hasta ? fd(p.vigente_hasta) : 'sin pensión'}</b> ${p.estado ? `<span class="chip">${p.estado}</span>` : ''}</p>
        <div class="grid g2">
          <label class="f">Tipo de pensión<select id="cat">${cats.map((c) => `<option value="${esc(c.id)}" ${c.id === cat0.id ? 'selected' : ''}>${esc(c.nombre)}</option>`).join('')}</select></label>
          <label class="f">Plan<select id="plan"></select></label>
        </div>
        <div class="grid g2">
          <label class="f">Desde<input type="date" id="desde" value="${dateInput(desde0)}"></label>
          <label class="f">Hasta (incluido)<input type="date" id="hasta"></label>
        </div>
        <label class="f">Monto (MXN)<input type="number" id="monto" min="0" step="0.01"></label>
      </div>
      <div><div class="muted small">TOTAL</div><div class="total-big" id="tot"></div><p class="muted small">Al presionar <b>Cobrar pensión</b> se abre la ventana de cobro.</p></div>
    </div>
    <div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn ok big" id="bC">Cobrar pensión <span class="kbd">F12</span></button></div>`, { cls: 'wide' });
  m.el.addEventListener('keydown', (e) => { if (e.key === 'F12') { e.preventDefault(); e.stopPropagation(); cobrar(); } });
  const pintarPlanes = () => {
    const sel = $('#plan', m.el), actual = sel.value || plan0, cat = $('#cat', m.el).value;
    sel.innerHTML = planes.map(([k, v]) => `<option value="${k}" ${k === actual ? 'selected' : ''}>${v}${precioDe(cat, k) ? ' · ' + money(precioDe(cat, k)) : ''}</option>`).join('');
  };
  pintarPlanes();
  $('#cat', m.el).onchange = () => { pintarPlanes(); upd(true); };
  const upd = (cambioPlan) => {
    const precios = (cats.find((c) => c.id === $('#cat', m.el).value) || {}).precios || {};
    const plan = $('#plan', m.el).value, desde = fromDateInput($('#desde', m.el).value);
    $('#hasta', m.el).disabled = plan !== 'personalizado';
    if (plan !== 'personalizado') $('#hasta', m.el).value = dateInput(calcHasta(plan, desde));
    if (cambioPlan && precios[plan]) $('#monto', m.el).value = precios[plan];
    const monto = Number($('#monto', m.el).value || 0);
    $('#tot', m.el).textContent = money(monto);
  };
  $('#plan', m.el).onchange = () => upd(true);
  $('#desde', m.el).onchange = () => upd(false);
  $('#monto', m.el).onchange = () => upd(false);
  async function cobrar() {
    const plan = $('#plan', m.el).value, categoria = $('#cat', m.el).value;
    const desde = fromDateInput($('#desde', m.el).value), hasta = finDia(fromDateInput($('#hasta', m.el).value));
    const monto = Number($('#monto', m.el).value || 0);
    if (!(monto > 0)) return toast('Indique el monto', 'warn');
    if (!(hasta > desde)) return toast('Revise las fechas', 'warn');
    const cobro = await ventanaCobro({ total: monto, titulo: 'Cobrar pensión', detalle: `${p.nombre} · ${$('#cat', m.el).selectedOptions[0]?.textContent || ''} · ${$('#plan', m.el).selectedOptions[0]?.textContent.split(' · ')[0] || ''}`, referencia: 'PEN' + p.id });
    if (!cobro) return;
    try {
      const r = await post(`/api/clientes/${p.id}/cobrar`, { plan, categoria, desde, hasta, monto, ...cobro.valores, no_imprimir: !cobro.imprimir });
      m.close();
      trasCobro(r, cobro, 'Recibo de pensión', () => post(`/api/pension-periodo/${r.periodo_id}/reimprimir`, { copia: true }));
      if (r.hasta || hasta) toast('Pensión pagada · vigente hasta ' + new Date(r.hasta || hasta).toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric' }), 'ok');
      await recargarMe().catch(() => {});
      if (S.view === 'clientes') ir('clientes');
    } catch (e) { errToast(e); }
  }
  $('#bC', m.el).onclick = cobrar;
  upd(true);
}

/* ================= TURNO Y CORTE ================= */
async function vistaCorte(main) {
  await recargarMe();
  const t = S.me.turno;
  if (!t) {
    main.innerHTML = `<div class="card"><h2>Turno</h2><p>No tiene un turno abierto.</p><button class="btn ok big" id="ab">Abrir turno</button></div>${S.ultimoCorte ? corteHTML(S.ultimoCorte) : ''}`;
    $('#ab').onclick = abrirTurnoModal;
    $('#verCorteTk') && ($('#verCorteTk').onclick = () => verTicket(S.ultimoCorte.impresion));
    return;
  }
  main.innerHTML = `<div class="grid g2" style="align-items:start">
    <div class="card">
      <h2>Turno ${folio(t.id)}</h2>
      <dl class="det"><dt>Cajero</dt><dd>${esc(S.me.usuario.nombre)}</dd><dt>Apertura</dt><dd>${fdt(t.apertura)}</dd>
      <dt>Fondo inicial MXN</dt><dd>${money(t.fondo_pesos)}</dd><dt>Fondo inicial USD</dt><dd>${usd(t.fondo_usd)}</dd><dt>Tipo de cambio</dt><dd>$${t.tipo_cambio}</dd></dl>
      ${can('movimientos') ? `<div class="row" style="margin-top:1rem"><button class="btn" id="bRet">➖ Retiro de efectivo</button><button class="btn" id="bIngr">➕ Ingreso de efectivo</button></div>` : ''}
    </div>
    <div class="card">
      <h2>Cerrar turno · declaración a ciegas</h2>
      <p class="muted small" style="margin-top:0">Cuente todo el dinero de la caja y escriba los totales. El sistema compara después contra lo registrado.</p>
      <form id="fCorte" class="grid">
        <label class="f">Total en efectivo en pesos (MXN), incluido el fondo de caja<input name="decl_pesos" type="number" min="0" step="0.01" required autofocus style="font-size:1.4rem;font-weight:700"></label>
        <div class="grid g2">
          <label class="f">Total en dólares (USD), incluido el fondo<input name="decl_usd" type="number" min="0" step="0.01" value="0" required></label>
          <label class="f">Total vouchers de tarjeta (MXN)<input name="decl_tarjeta" type="number" min="0" step="0.01" value="0" required></label>
        </div>
        <label class="f">Notas<input name="notas" placeholder="Opcional"></label>
        <button class="btn bad big">Cerrar turno e imprimir corte</button>
      </form>
    </div></div>`;
  const mov = async (tipo) => {
    const m = modal(`<div class="hd"><h3>${tipo === 'retiro' ? 'Retiro' : 'Ingreso'} de efectivo</h3><button class="btn sm" data-close>✕</button></div>
      <form class="bd grid"><div class="grid g2"><label class="f">Moneda<select name="moneda"><option>MXN</option><option>USD</option></select></label>
      <label class="f">Monto<input type="number" name="monto" min="0" step="0.01" required autofocus></label></div><label class="f">Motivo<input name="motivo" required></label></form>
      <div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn pri" id="bOk">Registrar</button></div>`);
    $('#bOk', m.el).onclick = async () => { try { await post('/api/turno/movimiento', { tipo, ...formData($('form', m.el)) }); m.close(); toast('Movimiento registrado', 'ok'); } catch (e) { errToast(e); } };
  };
  $('#bRet') && ($('#bRet').onclick = () => mov('retiro'));
  $('#bIngr') && ($('#bIngr').onclick = () => mov('ingreso'));
  $('#fCorte').onsubmit = async (e) => {
    e.preventDefault();
    const d = formData(e.target);
    if (!(await confirmar(`Va a cerrar el turno declarando <b>${money(d.decl_pesos)}</b> en pesos, <b>${usd(d.decl_usd)}</b> en dólares y <b>${money(d.decl_tarjeta)}</b> en tarjeta.<br><br>Una vez cerrado no podrá modificarse.`, { ok: 'Cerrar turno', peligro: true }))) return;
    try {
      const r = await post('/api/turno/cerrar', d);
      manejarImpresion(r.impresion, 'Corte de caja');
      S.ultimoCorte = { ...r.corte, impresion: r.impresion };
      await recargarMe(); ir('corte');
    } catch (err) { errToast(err); }
  };
}
function corteHTML(c) {
  const dif = (x, f = money) => (x == null ? '—' : `<span style="color:${x < 0 ? 'var(--bad)' : x > 0 ? 'var(--warn)' : 'var(--ok)'};font-weight:800">${x < 0 ? 'Faltan ' : x > 0 ? 'Sobran ' : 'Cuadra '}${f(Math.abs(x))}</span>`);
  return `<div class="card"><div class="row"><h2 class="grow">Corte del turno ${folio(c.turno.id)}</h2>${c.impresion ? '<button class="btn" id="verCorteTk">Ver ticket</button>' : ''}</div>
    <div class="grid g4">
      <div class="kpi"><div class="l">Entradas</div><div class="v">${c.entradas}</div></div>
      <div class="kpi"><div class="l">Salidas</div><div class="v">${c.salidas}</div></div>
      <div class="kpi"><div class="l">Pensiones cobradas</div><div class="v">${c.pensiones}</div></div>
      <div class="kpi pri"><div class="l">Venta total</div><div class="v">${money(c.venta_total)}</div></div>
    </div>
    <div class="tbl-wrap" style="margin-top:1rem"><table><thead><tr><th></th><th class="num">Declarado</th>${c.oculto ? '' : '<th class="num">Esperado</th><th class="num">Diferencia</th>'}</tr></thead><tbody>
      <tr><td>Efectivo MXN</td><td class="num">${money(c.turno.decl_pesos)}</td>${c.oculto ? '' : `<td class="num">${money(c.esperado_mxn)}</td><td class="num">${dif(c.dif_mxn)}</td>`}</tr>
      <tr><td>Dólares</td><td class="num">${usd(c.turno.decl_usd)}</td>${c.oculto ? '' : `<td class="num">${usd(c.esperado_usd)}</td><td class="num">${dif(c.dif_usd, usd)}</td>`}</tr>
      <tr><td>Tarjeta</td><td class="num">${money(c.turno.decl_tarjeta)}</td>${c.oculto ? '' : `<td class="num">${money(c.tarjeta)}</td><td class="num">${dif(c.dif_tarjeta)}</td>`}</tr>
    </tbody></table></div>
    <p class="small muted">Estacionamiento ${money(c.venta_estacionamiento)} · Pensiones ${money(c.venta_pensiones)} · Productos y servicios ${money(c.venta_productos)}</p>
    ${c.cortesias ? `<h3 style="margin-top:1rem">Cortesías: ${c.cortesias} (${money(c.cortesias_monto)}) <span class="small muted">— no son dinero en caja</span></h3>
      ${tabla(c.lista_cortesias, [{ t: 'Boleto', f: (x) => folio(x.id) }, { t: 'Placas', k: 'placas' }, { t: 'Para quién', k: 'cortesia_para' }, { t: 'Motivo', k: 'cortesia_motivo' }, { t: 'Valor', f: (x) => money(x.subtotal), n: 1 }])}` : ''}
    ${c.oculto ? '<p class="muted small">Su declaración quedó registrada. El supervisor revisará el corte.</p>' : ''}</div>`;
}

/* ================= REPORTES ================= */
function rangoPeriodo(p) {
  const ahora = new Date(), hoy = inicioDia(ahora.getTime());
  if (p === 'hoy') return [hoy, finDia(hoy)];
  if (p === 'ayer') return [hoy - 864e5, hoy - 1];
  if (p === 'semana') { const d = new Date(hoy); const dow = (d.getDay() + 6) % 7; return [hoy - dow * 864e5, finDia(hoy)]; }
  if (p === 'quincena') { const d = new Date(hoy); return [new Date(d.getFullYear(), d.getMonth(), d.getDate() <= 15 ? 1 : 16).getTime(), finDia(hoy)]; }
  if (p === 'mes') return [new Date(ahora.getFullYear(), ahora.getMonth(), 1).getTime(), finDia(hoy)];
  if (p === 'trimestre') { const t = Math.floor(ahora.getMonth() / 3) * 3; return [new Date(ahora.getFullYear(), t, 1).getTime(), finDia(hoy)]; }
  if (p === 'semestre') return [new Date(ahora.getFullYear(), ahora.getMonth() < 6 ? 0 : 6, 1).getTime(), finDia(hoy)];
  if (p === 'anio') return [new Date(ahora.getFullYear(), 0, 1).getTime(), finDia(hoy)];
}
async function vistaReportes(main) {
  const st = S.rep ||= { periodo: 'hoy', tab: 'resumen', desde: dateInput(Date.now()), hasta: dateInput(Date.now()) };
  const periodos = { hoy: 'Hoy', ayer: 'Ayer', semana: 'Semana', quincena: 'Quincena', mes: 'Mes', trimestre: 'Trimestre', semestre: 'Semestre', anio: 'Año', rango: 'Por fechas' };
  main.innerHTML = `<div class="card noprint"><div class="row">
    <h2 class="grow" style="margin:0">Reportes</h2>
    <div class="seg" id="segP">${Object.entries(periodos).map(([k, v]) => `<button data-p="${k}" class="${st.periodo === k ? 'on' : ''}">${v}</button>`).join('')}</div>
  </div>
  <div class="row ${st.periodo === 'rango' ? '' : 'hidden'}" id="rng" style="margin-top:.7rem"><label class="f">Desde<input type="date" id="rD" value="${st.desde}"></label><label class="f">Hasta<input type="date" id="rH" value="${st.hasta}"></label><button class="btn pri" id="rGo" style="align-self:flex-end">Consultar</button></div>
  </div><div id="rep" style="margin-top:1rem"><p class="muted">Cargando…</p></div>`;
  $$('#segP button').forEach((b) => (b.onclick = () => { st.periodo = b.dataset.p; vistaReportes(main); }));
  $('#rGo').onclick = () => { st.desde = $('#rD').value; st.hasta = $('#rH').value; cargar(); };
  async function cargar() {
    const [d, h] = st.periodo === 'rango' ? [fromDateInput(st.desde), finDia(fromDateInput(st.hasta))] : rangoPeriodo(st.periodo);
    try { S.repData = await api(`/api/reportes?desde=${d}&hasta=${h}`); pintarReporte(); } catch (e) { errToast(e); }
  }
  cargar();
}
function barras(datos, etiqueta, valor, { valor2, fmt = money } = {}) {
  if (!datos.length) return '<p class="muted">Sin datos en el periodo.</p>';
  const W = Math.max(600, datos.length * 34), H = 220, pad = 28, max = Math.max(1, ...datos.map((d) => valor(d) + (valor2 ? valor2(d) : 0)));
  const bw = (W - pad * 2) / datos.length;
  return `<div class="tbl-wrap"><svg class="chart" viewBox="0 0 ${W} ${H}" style="min-width:${Math.min(W, 900)}px">${datos.map((d, i) => {
    const v = valor(d), v2 = valor2 ? valor2(d) : 0, h1 = ((H - pad * 2) * v) / max, h2 = ((H - pad * 2) * v2) / max, x = pad + i * bw + bw * 0.15;
    return `<g><title>${esc(etiqueta(d))}: ${fmt(v + v2)}</title><rect class="bar" x="${x}" y="${H - pad - h1}" width="${bw * 0.7}" height="${h1}" rx="3"/>
      ${v2 ? `<rect class="bar2" x="${x}" y="${H - pad - h1 - h2}" width="${bw * 0.7}" height="${h2}" rx="3"/>` : ''}
      <text x="${x + bw * 0.35}" y="${H - 10}" text-anchor="middle">${esc(etiqueta(d))}</text>
      ${v + v2 ? `<text x="${x + bw * 0.35}" y="${H - pad - h1 - h2 - 4}" text-anchor="middle">${fmt === money ? Math.round(v + v2) : v + v2}</text>` : ''}</g>`;
  }).join('')}<line x1="${pad}" x2="${W - pad}" y1="${H - pad}" y2="${H - pad}" stroke="#ccd"/></svg></div>`;
}
function tabla(filas, cols, { foot } = {}) {
  if (!filas.length) return '<p class="muted">Sin registros en el periodo.</p>';
  return `<div class="tbl-wrap" style="max-height:560px;overflow-y:auto"><table><thead><tr>${cols.map((c) => `<th class="${c.n ? 'num' : ''}">${c.t}</th>`).join('')}</tr></thead>
    <tbody>${filas.map((f) => `<tr>${cols.map((c) => `<td class="${c.n ? 'num' : ''}">${c.h ? c.h(f) : esc(c.f ? c.f(f) : f[c.k])}</td>`).join('')}</tr>`).join('')}</tbody>
    ${foot ? `<tfoot><tr>${cols.map((c, i) => `<td class="${c.n ? 'num' : ''}">${i === 0 ? 'Totales' : foot[c.k] ?? ''}</td>`).join('')}</tr></tfoot>` : ''}</table></div>`;
}
const XL = {
  cortesias: [[(x) => folio(x.id), 'Boleto'], [(x) => fdt(x.salida), 'Fecha'], ['placas', 'Placas'], ['marca', 'Marca'], ['modelo', 'Modelo'], ['color', 'Color'], ['cortesia_para', 'Para quién'], ['cortesia_motivo', 'Motivo'], ['usuario_salida', 'Autorizó'], ['subtotal', 'Valor condonado', 'dinero']],
  productos: [['producto', 'Producto / servicio'], ['tipo', 'Tipo'], ['cantidad', 'Cantidad', 'entero'], ['total', 'Total', 'dinero']],
};
function excelCompleto(r) {
  const R = r.resumen, V = r.vehiculos;
  const resumen = [['Venta total', R.total], ['Estacionamiento', R.estacionamiento], ['Pensiones', R.pensiones], ['Productos y servicios', R.productos],
    ['Efectivo MXN (neto)', R.efectivo_mxn], ['Dólares (USD)', R.usd], ['Dólares en pesos', R.usd_mxn], ['Tarjeta', R.tarjeta], ['Mercado Pago', R.mercado_pago], ['Transferencias', R.transferencia], ['Renta de publicidad', R.publicidad],
    ['Entradas', V.entradas], ['Salidas cobradas', V.salidas], ['Boletos perdidos', V.perdidos], ['Cargos por boleto perdido', V.cargo_perdidos],
    ['Cortesías (cantidad)', V.cortesias], ['Cortesías (valor, no es dinero)', V.cortesias_monto], ['Descuentos por convenios', V.descuentos], ['Boletos cancelados', V.cancelados],
    ['Estancia promedio (min)', Math.round(V.estancia_prom)], ['Vehículos dentro ahora', r.dentro.length], ['Gastos', R.gastos], ['Utilidad (venta - gastos)', R.utilidad]].map(([c, v]) => ({ c, v }));
  descargarExcel('reporte_estacionamiento_' + dateInput(r.desde) + '_a_' + dateInput(r.hasta) + '.xlsx', [
    hojaExcel('Resumen', resumen, [['c', 'Concepto'], ['v', 'Valor', 'decimal']], 'Resumen de ventas'),
    hojaExcel('Por día', r.porDia, [['dia', 'Día'], ['cobros', 'Cobros', 'entero'], ['estacionamiento', 'Estacionamiento', 'dinero'], ['pensiones', 'Pensiones', 'dinero'], ['productos', 'Productos', 'dinero'], ['total', 'Total', 'dinero']]),
    hojaExcel('Turnos', r.turnos, [[(x) => folio(x.turno.id), 'Turno'], ['cajero', 'Cajero'], [(x) => fdt(x.turno.apertura), 'Apertura'], [(x) => fdt(x.turno.cierre), 'Cierre'],
      [(x) => x.turno.fondo_pesos, 'Fondo MXN', 'dinero'], ['dentro_al_abrir', 'Dentro al abrir', 'entero'], ['entradas', 'Entraron', 'entero'], ['salidas', 'Salieron', 'entero'], ['dentro_al_cerrar', 'Dentro al cerrar', 'entero'], ['pico', 'Máx. ocupación', 'entero'], ['venta_total', 'Venta', 'dinero'], ['efectivo_mxn', 'Efectivo neto', 'dinero'],
      ['usd', 'USD', 'decimal'], ['tarjeta', 'Tarjeta', 'dinero'], ['cortesias', 'Cortesías', 'entero'], ['cortesias_monto', 'Valor cortesías', 'dinero'], ['esperado_mxn', 'Esperado MXN', 'dinero'],
      [(x) => x.turno.decl_pesos, 'Declarado MXN', 'dinero'], ['dif_mxn', 'Diferencia MXN', 'dinero'], ['dif_usd', 'Diferencia USD', 'decimal'], ['dif_tarjeta', 'Diferencia tarjeta', 'dinero']]),
    hojaExcel('Boletos', r.tickets, [[(x) => folio(x.id), 'Boleto'], ['placas', 'Placas'], ['marca', 'Marca'], ['modelo', 'Modelo'], ['color', 'Color'], [(x) => CLIENTE[x.cliente], 'Tipo'], ['cliente_nombre', 'Cliente registrado'],
      [(x) => fdt(x.entrada), 'Entrada'], [(x) => fdt(x.salida), 'Salida'], ['minutos', 'Minutos', 'entero'], ['tarifa', 'Tarifa'], ['convenio', 'Convenio'], ['subtotal', 'Estacionamiento', 'dinero'],
      ['descuento', 'Descuento/cortesía', 'dinero'], ['cargo_perdido', 'Boleto perdido', 'dinero'], ['extras_total', 'Productos', 'dinero'], ['total', 'Total cobrado', 'dinero'], ['estado', 'Estado'],
      ['cortesia_para', 'Cortesía para'], ['cancel_motivo', 'Motivo cancelación'], ['usuario_entrada', 'Registró'], ['usuario_salida', 'Cobró']]),
    hojaExcel('Cortesías', r.cortesias, XL.cortesias),
    hojaExcel('Productos', r.productos, XL.productos),
    hojaExcel('Pensiones', r.pensionesCobradas, [[(x) => fdt(x.fecha), 'Fecha'], ['nombre', 'Cliente'], ['categoria', 'Tipo de pensión'], [(x) => S.me.planes[x.plan], 'Plan'], [(x) => fd(x.desde), 'Desde'], [(x) => fd(x.hasta), 'Hasta'], ['cajero', 'Cajero'], ['monto', 'Monto', 'dinero']]),
    hojaExcel('Por cajero', r.porCajero, [['cajero', 'Cajero'], ['cobros', 'Cobros', 'entero'], ['efectivo_mxn', 'Efectivo MXN', 'dinero'], ['usd', 'USD', 'decimal'], ['tarjeta', 'Tarjeta', 'dinero'], ['total', 'Total', 'dinero']]),
    hojaExcel('Convenios', r.porConvenio, [['convenio', 'Convenio'], ['n', 'Boletos', 'entero'], ['descuento', 'Descuento', 'dinero'], ['total', 'Cobrado', 'dinero']]),
    hojaExcel('Gastos', r.gastos, [[(x) => fdt(x.fecha), 'Fecha'], ['categoria', 'Tipo'], ['concepto', 'Concepto'], [(x) => (x.origen === 'caja' ? 'De la caja' : 'Fuera de caja'), 'Pagado'], ['usuario', 'Registró'], ['monto', 'Monto', 'dinero']]),
    hojaExcel('Publicidad', r.publicidad, [[(x) => fdt(x.fecha), 'Cobrado'], ['espacio', 'Espacio'], ['cliente', 'Cliente'], ['anuncio', 'Anuncio'], [(x) => fd(x.desde), 'Desde'], [(x) => fd(x.hasta), 'Hasta'], ['cajero', 'Cobró'], ['monto', 'Monto', 'dinero']]),
    hojaExcel('Gastos por tipo', r.gastosPorCategoria, [['categoria', 'Tipo'], ['n', 'Cantidad', 'entero'], ['total', 'Total', 'dinero']]),
    hojaExcel('Movimientos caja', r.movimientos, [[(x) => fdt(x.fecha), 'Fecha'], [(x) => folio(x.turno_id), 'Turno'], ['usuario', 'Usuario'], ['tipo', 'Tipo'], ['moneda', 'Moneda'], ['monto', 'Monto', 'decimal'], ['motivo', 'Motivo']]),
  ]);
}
const sum = (a, k) => a.reduce((s, x) => s + Number(typeof k === 'function' ? k(x) : x[k] || 0), 0);
function pintarReporte() {
  const r = S.repData, st = S.rep, R = r.resumen, V = r.vehiculos;
  const tabs = { resumen: 'Resumen', graficas: '📈 Gráficas', gastos: 'Gastos', publicidad: 'Publicidad', turnos: 'Turnos y cortes', vehiculos: 'Boletos / vehículos', pensiones: 'Pensiones', convenios: 'Convenios y tarifas', cajeros: 'Por cajero', afluencia: 'Afluencia', cortesias: 'Cortesías', productos: 'Productos y servicios', caja: 'Movimientos de caja', dentro: 'Dentro ahora' };
  if (!modOn('gastos')) { delete tabs.gastos; if (st.tab === 'gastos') st.tab = 'resumen'; }
  let html = '', exportar = null;
  const tipoTk = (t) => t.estado === 'cancelado' ? '<span class="chip bad">cancelado</span>' : t.estado === 'dentro' ? '<span class="chip pri">dentro</span>' : t.perdido ? '<span class="chip warn">perdido</span>' : t.cortesia_para ? '<span class="chip">cortesía</span>' : '<span class="chip ok">pagado</span>';
  if (st.tab === 'resumen') {
    const promTk = V.salidas ? (R.estacionamiento / V.salidas) : 0;
    html = `<div class="grid g4">
      <div class="kpi pri"><div class="l">Venta total</div><div class="v">${money(R.total)}</div></div>
      <div class="kpi"><div class="l">Estacionamiento</div><div class="v">${money(R.estacionamiento)}</div></div>
      <div class="kpi"><div class="l">Pensiones</div><div class="v">${money(R.pensiones)}</div></div>
      <div class="kpi"><div class="l">Productos y servicios</div><div class="v">${money(R.productos)}</div><div class="small muted">ticket promedio estac. ${money(promTk)}</div></div>
      <div class="kpi bad"><div class="l">Gastos</div><div class="v">${money(R.gastos)}</div></div>
      <div class="kpi ${R.utilidad >= 0 ? 'ok' : 'bad'}"><div class="l">Utilidad (venta − gastos)</div><div class="v">${money(R.utilidad)}</div></div>
      <div class="kpi"><div class="l">Efectivo MXN (neto)</div><div class="v">${money(R.efectivo_mxn)}</div></div>
      <div class="kpi"><div class="l">Dólares</div><div class="v">${usd(R.usd)}</div><div class="small muted">= ${money(R.usd_mxn)}</div></div>
      <div class="kpi"><div class="l">Tarjeta</div><div class="v">${money(R.tarjeta)}</div><div class="small muted">Mercado Pago: ${money(R.mercado_pago)}</div></div>
      <div class="kpi"><div class="l">Transferencias</div><div class="v">${money(R.transferencia)}</div></div>
      <div class="kpi"><div class="l">Renta de publicidad</div><div class="v">${money(R.publicidad)}</div><div class="small muted">${r.publicidad.length} cobro(s)</div></div>
      <div class="kpi"><div class="l">Estancia promedio</div><div class="v">${tiempo(V.estancia_prom)}</div></div>
      <div class="kpi"><div class="l">Entradas</div><div class="v">${V.entradas}</div></div>
      <div class="kpi"><div class="l">Salidas cobradas</div><div class="v">${V.salidas}</div></div>
      <div class="kpi"><div class="l">Boletos perdidos</div><div class="v">${V.perdidos}</div><div class="small muted">cargos ${money(V.cargo_perdidos)}</div></div>
      <div class="kpi"><div class="l">Cortesías / cancelados</div><div class="v">${V.cortesias} / ${V.cancelados}</div><div class="small muted">cortesías ${money(V.cortesias_monto)} · convenios ${money(V.descuentos)}</div></div>
    </div>
    <div class="card" style="margin-top:1rem"><h3>Ventas por día <span class="small muted">(azul: estacionamiento · amarillo: pensiones)</span></h3>${barras(r.porDia, (d) => d.dia.slice(5).split('-').reverse().join('/'), (d) => d.estacionamiento, { valor2: (d) => d.pensiones })}</div>
    <div class="card"><h3>Por tipo de cliente</h3>${tabla(r.porCliente, [{ t: 'Tipo', f: (x) => CLIENTE[x.cliente] }, { t: 'Salidas', k: 'n', n: 1 }, { t: 'Estancia prom.', f: (x) => tiempo(x.prom), n: 1 }, { t: 'Total', f: (x) => money(x.total), n: 1 }])}</div>`;
    exportar = () => csv('ventas_por_dia', r.porDia, [['dia', 'Día'], ['cobros', 'Cobros'], [(d) => r2(d.estacionamiento), 'Estacionamiento'], [(d) => r2(d.pensiones), 'Pensiones'], [(d) => r2(d.total), 'Total']]);
  } else if (st.tab === 'turnos') {
    const d = (x) => (x == null ? '—' : `<b style="color:${x < 0 ? 'var(--bad)' : x > 0 ? 'var(--warn)' : 'var(--ok)'}">${x > 0 ? '+' : ''}${money(x)}</b>`);
    html = `<div class="card"><h3>Turnos y cortes de caja</h3>${tabla(r.turnos, [
      { t: 'Turno', f: (x) => folio(x.turno.id) }, { t: 'Cajero', k: 'cajero' }, { t: 'Apertura', f: (x) => fdt(x.turno.apertura) }, { t: 'Cierre', h: (x) => (x.turno.cierre ? fdt(x.turno.cierre) : '<span class="chip ok">abierto</span>') },
      { t: 'Fondo', f: (x) => money(x.turno.fondo_pesos), n: 1 }, { t: 'Dentro al abrir', k: 'dentro_al_abrir', n: 1 }, { t: 'Entraron', k: 'entradas', n: 1 }, { t: 'Salieron', k: 'salidas', n: 1 }, { t: 'Dentro al cerrar', k: 'dentro_al_cerrar', n: 1 }, { t: 'Venta', f: (x) => money(x.venta_total), n: 1 },
      { t: 'Efvo esperado', f: (x) => money(x.esperado_mxn), n: 1 }, { t: 'Efvo declarado', f: (x) => (x.turno.decl_pesos == null ? '—' : money(x.turno.decl_pesos)), n: 1 },
      { t: 'Dif. MXN', h: (x) => d(x.dif_mxn), n: 1 }, { t: 'Dif. USD', h: (x) => d(x.dif_usd), n: 1 }, { t: 'Dif. tarjeta', h: (x) => d(x.dif_tarjeta), n: 1 },
      { t: '', h: (x) => (x.turno.cierre ? `<button class="btn sm" data-rc="${x.turno.id}">🖨️</button>` : '') }])}</div>`;
    exportar = () => csv('turnos', r.turnos, [[(x) => folio(x.turno.id), 'Turno'], ['cajero', 'Cajero'], [(x) => fdt(x.turno.apertura), 'Apertura'], [(x) => fdt(x.turno.cierre), 'Cierre'],
      [(x) => x.turno.fondo_pesos, 'Fondo MXN'], [(x) => x.turno.fondo_usd, 'Fondo USD'], [(x) => x.turno.tipo_cambio, 'TC'], ['entradas', 'Entradas'], ['salidas', 'Salidas'], ['venta_total', 'Venta'],
      ['efectivo_mxn', 'Efectivo neto'], ['usd', 'USD'], ['tarjeta', 'Tarjeta'], ['esperado_mxn', 'Esperado MXN'], [(x) => x.turno.decl_pesos, 'Declarado MXN'], ['dif_mxn', 'Dif MXN'],
      ['esperado_usd', 'Esperado USD'], [(x) => x.turno.decl_usd, 'Declarado USD'], ['dif_usd', 'Dif USD'], [(x) => x.turno.decl_tarjeta, 'Declarado tarjeta'], ['dif_tarjeta', 'Dif tarjeta']]);
  } else if (st.tab === 'vehiculos') {
    const f = st.filtroTk || 'todos';
    const lista = r.tickets.filter((t) => f === 'todos' || (f === 'pagados' && t.estado === 'pagado') || (f === 'dentro' && t.estado === 'dentro') || (f === 'cancelados' && t.estado === 'cancelado')
      || (f === 'perdidos' && t.perdido) || (f === 'meseros' && t.cliente === 'mesero') || (f === 'convenio' && t.convenio) || (f === 'cortesias' && t.cortesia_para));
    html = `<div class="card"><div class="row"><h3 class="grow">Boletos (entradas y salidas)</h3><select id="fTk" style="max-width:200px">${['todos', 'pagados', 'dentro', 'cancelados', 'perdidos', 'meseros', 'convenio', 'cortesias'].map((x) => `<option ${x === f ? 'selected' : ''}>${x}</option>`).join('')}</select></div>
      ${tabla(lista, [{ t: 'Boleto', f: (x) => folio(x.id) }, { t: 'Placas', k: 'placas' }, { t: 'Vehículo', f: (x) => [x.marca, x.modelo, x.color].filter(Boolean).join(' ') }, { t: 'Tipo', f: (x) => CLIENTE[x.cliente] },
        { t: 'Entrada', f: (x) => fdt(x.entrada) }, { t: 'Salida', f: (x) => (x.salida ? fdt(x.salida) : '') }, { t: 'Tiempo', f: (x) => (x.minutos != null ? tiempo(x.minutos) : ''), n: 1 },
        { t: 'Tarifa', k: 'tarifa' }, { t: 'Convenio', k: 'convenio' }, { t: 'Desc.', f: (x) => (x.descuento ? money(x.descuento) : ''), n: 1 }, { t: 'Total', f: (x) => (x.estado === 'pagado' ? money(x.total) : ''), n: 1 },
        { t: 'Estado', h: tipoTk }, { t: 'Cobró', k: 'usuario_salida' }, { t: '', h: (x) => (x.estado === 'pagado' && can('reimprimir') ? `<button class="btn sm" data-rt="${x.id}">🖨️</button>` : '') }],
      { foot: { total: money(sum(lista.filter((x) => x.estado === 'pagado'), 'total')), descuento: money(sum(lista, 'descuento')) } })}</div>`;
    exportar = () => csv('boletos', lista, [[(x) => folio(x.id), 'Boleto'], ['placas', 'Placas'], ['marca', 'Marca'], ['modelo', 'Modelo'], ['color', 'Color'], [(x) => CLIENTE[x.cliente], 'Tipo'],
      [(x) => fdt(x.entrada), 'Entrada'], [(x) => fdt(x.salida), 'Salida'], ['minutos', 'Minutos'], ['tarifa', 'Tarifa'], ['convenio', 'Convenio'], ['subtotal', 'Subtotal'], ['descuento', 'Descuento'],
      ['cargo_perdido', 'Cargo perdido'], ['total', 'Total'], ['estado', 'Estado'], ['cortesia_motivo', 'Cortesía'], ['cancel_motivo', 'Motivo cancelación'], ['usuario_entrada', 'Registró'], ['usuario_salida', 'Cobró']]);
  } else if (st.tab === 'pensiones') {
    const ch = { vigente: 'ok', 'por vencer': 'warn', vencida: 'bad' };
    html = `<div class="card"><h3>Pensiones cobradas en el periodo · ${money(sum(r.pensionesCobradas, 'monto'))}</h3>${tabla(r.pensionesCobradas, [{ t: 'Fecha', f: (x) => fdt(x.fecha) }, { t: 'Pensionado', k: 'nombre' },
      { t: 'Tipo', f: (x) => x.categoria || '' }, { t: 'Plan', f: (x) => S.me.planes[x.plan] }, { t: 'Desde', f: (x) => fd(x.desde) }, { t: 'Hasta', f: (x) => fd(x.hasta) }, { t: 'Cajero', k: 'cajero' }, { t: 'Monto', f: (x) => money(x.monto), n: 1 }])}</div>
      <div class="card"><h3>Estado de pensionados</h3>${tabla(r.pensionesEstado, [{ t: 'Pensionado', k: 'nombre' }, { t: 'Teléfono', k: 'telefono' }, { t: 'Vigente hasta', f: (x) => fd(x.vigente_hasta) }, { t: 'Estado', h: (x) => `<span class="chip ${ch[x.estado]}">${x.estado}</span>` }])}</div>`;
    exportar = () => csv('pensiones', r.pensionesCobradas, [[(x) => fdt(x.fecha), 'Fecha'], ['nombre', 'Pensionado'], ['categoria', 'Tipo de pensión'], [(x) => S.me.planes[x.plan], 'Plan'], [(x) => fd(x.desde), 'Desde'], [(x) => fd(x.hasta), 'Hasta'], ['cajero', 'Cajero'], ['monto', 'Monto']]);
  } else if (st.tab === 'convenios') {
    html = `<div class="card"><h3>Uso de convenios</h3>${tabla(r.porConvenio, [{ t: 'Convenio', k: 'convenio' }, { t: 'Boletos', k: 'n', n: 1 }, { t: 'Descuento otorgado', f: (x) => money(x.descuento), n: 1 }, { t: 'Cobrado', f: (x) => money(x.total), n: 1 }])}</div>
      <div class="card"><h3>Ventas por tarifa</h3>${tabla(r.porTarifa, [{ t: 'Tarifa', k: 'tarifa' }, { t: 'Boletos', k: 'n', n: 1 }, { t: 'Total', f: (x) => money(x.total), n: 1 }])}</div>`;
    exportar = () => csv('convenios', r.porConvenio, [['convenio', 'Convenio'], ['n', 'Boletos'], ['descuento', 'Descuento'], ['total', 'Cobrado']]);
  } else if (st.tab === 'cajeros') {
    html = `<div class="card"><h3>Cobros por cajero</h3>${tabla(r.porCajero, [{ t: 'Cajero', k: 'cajero' }, { t: 'Cobros', k: 'cobros', n: 1 }, { t: 'Efectivo MXN', f: (x) => money(x.efectivo_mxn), n: 1 }, { t: 'Dólares', f: (x) => usd(x.usd), n: 1 }, { t: 'Tarjeta', f: (x) => money(x.tarjeta), n: 1 }, { t: 'Total', f: (x) => money(x.total), n: 1 }])}</div>`;
    exportar = () => csv('cajeros', r.porCajero, [['cajero', 'Cajero'], ['cobros', 'Cobros'], ['efectivo_mxn', 'Efectivo MXN'], ['usd', 'USD'], ['tarjeta', 'Tarjeta'], ['total', 'Total']]);
  } else if (st.tab === 'afluencia') {
    const datos = r.entradasHora.map((n, h) => ({ h, n }));
    html = `<div class="card"><h3>Entradas por hora del día</h3>${barras(datos, (d) => d.h + 'h', (d) => d.n, { fmt: (x) => x })}
      <p class="muted small">Hora pico: <b>${datos.reduce((a, b) => (b.n > a.n ? b : a)).h}:00</b>. Útil para planear turnos y personal.</p></div>`;
    exportar = () => csv('afluencia', datos, [['h', 'Hora'], ['n', 'Entradas']]);
  } else if (st.tab === 'cortesias') {
    html = `<div class="card"><h3>Cortesías: ${r.cortesias.length} · valor ${money(sum(r.cortesias, 'subtotal'))} <span class="small muted">(no entran como dinero)</span></h3>${tabla(r.cortesias, [{ t: 'Boleto', f: (x) => folio(x.id) }, { t: 'Fecha', f: (x) => fdt(x.salida) },
      { t: 'Placas', k: 'placas' }, { t: 'Vehículo', f: (x) => [x.marca, x.modelo, x.color].filter(Boolean).join(' ') }, { t: 'Para quién', k: 'cortesia_para' }, { t: 'Motivo', k: 'cortesia_motivo' },
      { t: 'Autorizó', k: 'usuario_salida' }, { t: 'Valor', f: (x) => money(x.subtotal), n: 1 }], { foot: { subtotal: money(sum(r.cortesias, 'subtotal')) } })}</div>`;
    exportar = () => csv('cortesias', r.cortesias, XL.cortesias);
  } else if (st.tab === 'productos') {
    html = `<div class="card"><h3>Productos y servicios vendidos · ${money(R.productos)}</h3>${tabla(r.productos, [{ t: 'Producto / servicio', k: 'producto' }, { t: 'Tipo', k: 'tipo' }, { t: 'Cantidad', k: 'cantidad', n: 1 }, { t: 'Total', f: (x) => money(x.total), n: 1 }])}</div>`;
    exportar = () => csv('productos', r.productos, XL.productos);
  } else if (st.tab === 'graficas') {
    html = '<div id="gWrap"><p class="muted">Cargando gráficas…</p></div>';
  } else if (st.tab === 'gastos') {
    html = `<div class="grid g2"><div class="card"><h3>Gastos por tipo</h3>${Graficas.pastel(r.gastosPorCategoria.map((g) => ({ nombre: g.categoria, valor: g.total })), { centro: 'Gastos' })}</div>
      <div class="card"><h3>Resultado del periodo</h3><dl class="det"><dt>Venta total</dt><dd>${money(R.total)}</dd><dt>Gastos</dt><dd style="color:var(--bad)">−${money(R.gastos)}</dd><dt><b>Utilidad</b></dt><dd><b>${money(R.utilidad)}</b></dd></dl></div></div>
      <div class="card"><h3>Detalle de gastos</h3>${tabla(r.gastos, [{ t: 'Fecha', f: (x) => fdt(x.fecha) }, { t: 'Tipo', k: 'categoria' }, { t: 'Concepto', k: 'concepto' }, { t: 'Pagado', f: (x) => (x.origen === 'caja' ? 'De la caja' : 'Fuera de caja') }, { t: 'Registró', k: 'usuario' }, { t: 'Monto', f: (x) => money(x.monto), n: 1 }], { foot: { monto: money(R.gastos) } })}</div>`;
    exportar = () => csv('gastos', r.gastos, [[(x) => fdt(x.fecha), 'Fecha'], ['categoria', 'Tipo'], ['concepto', 'Concepto'], ['origen', 'Pagado'], ['usuario', 'Registró'], ['monto', 'Monto']]);
  } else if (st.tab === 'publicidad') {
    html = `<div class="card"><h3>Rentas de espacios publicitarios cobradas</h3>${tabla(r.publicidad, [{ t: 'Cobrado', f: (x) => fdt(x.fecha) }, { t: 'Espacio', k: 'espacio' }, { t: 'Cliente', k: 'cliente' }, { t: 'Anuncio', k: 'anuncio' }, { t: 'Desde', f: (x) => fd(x.desde) }, { t: 'Hasta', f: (x) => fd(x.hasta) }, { t: 'Cobró', k: 'cajero' }, { t: 'Monto', f: (x) => money(x.monto), n: 1 }], { foot: { monto: money(R.publicidad) } })}</div>`;
    exportar = () => csv('publicidad', r.publicidad, [[(x) => fdt(x.fecha), 'Cobrado'], ['espacio', 'Espacio'], ['cliente', 'Cliente'], ['anuncio', 'Anuncio'], [(x) => fd(x.desde), 'Desde'], [(x) => fd(x.hasta), 'Hasta'], ['monto', 'Monto']]);
  } else if (st.tab === 'caja') {
    html = `<div class="card"><h3>Retiros e ingresos de efectivo</h3>${tabla(r.movimientos, [{ t: 'Fecha', f: (x) => fdt(x.fecha) }, { t: 'Turno', f: (x) => folio(x.turno_id) }, { t: 'Usuario', k: 'usuario' }, { t: 'Tipo', k: 'tipo' }, { t: 'Moneda', k: 'moneda' }, { t: 'Monto', f: (x) => money(x.monto), n: 1 }, { t: 'Motivo', k: 'motivo' }])}</div>`;
    exportar = () => csv('movimientos', r.movimientos, [[(x) => fdt(x.fecha), 'Fecha'], ['turno_id', 'Turno'], ['usuario', 'Usuario'], ['tipo', 'Tipo'], ['moneda', 'Moneda'], ['monto', 'Monto'], ['motivo', 'Motivo']]);
  } else if (st.tab === 'dentro') {
    const ahora = Date.now();
    html = `<div class="card"><h3>Vehículos dentro en este momento (${r.dentro.length})</h3>${tabla(r.dentro, [{ t: 'Boleto', f: (x) => folio(x.id) }, { t: 'Placas', k: 'placas' }, { t: 'Vehículo', f: (x) => [x.marca, x.modelo, x.color].filter(Boolean).join(' ') }, { t: 'Tipo', f: (x) => CLIENTE[x.cliente] }, { t: 'Entrada', f: (x) => fdt(x.entrada) }, { t: 'Tiempo', f: (x) => tiempo((ahora - x.entrada) / 60000), n: 1 }])}</div>`;
    exportar = () => csv('dentro', r.dentro, [[(x) => folio(x.id), 'Boleto'], ['placas', 'Placas'], ['marca', 'Marca'], ['modelo', 'Modelo'], ['color', 'Color'], ['cliente', 'Tipo'], [(x) => fdt(x.entrada), 'Entrada']]);
  }
  $('#rep').innerHTML = `<div class="card noprint" style="padding:.4rem 1rem 0"><div class="row"><div class="tabs grow" style="margin:0;border:0">${Object.entries(tabs).map(([k, v]) => `<button data-t="${k}" class="${st.tab === k ? 'on' : ''}">${v}</button>`).join('')}</div>
    <div class="row" style="padding-bottom:.4rem"><button class="btn sm" id="xCsv">⬇️ Excel (esta pestaña)</button><button class="btn sm acc" id="xTodo">⬇️ Excel completo</button><button class="btn sm" id="xTk">🧾 Ticket resumen</button><button class="btn sm" id="xPr">🖨️ Imprimir hoja</button></div></div></div>
    <p class="muted small">Periodo: <b>${fdt(r.desde)}</b> a <b>${fdt(r.hasta)}</b></p>${html}`;
  $$('[data-t]', $('#rep')).forEach((b) => (b.onclick = () => { st.tab = b.dataset.t; pintarReporte(); }));
  if (st.tab === 'graficas') cargarGraficas(r, st.periodo);
  $('#fTk') && ($('#fTk').onchange = (e) => { st.filtroTk = e.target.value; pintarReporte(); });
  $('#xCsv').onclick = () => exportar && exportar();
  $('#xTodo').onclick = () => excelCompleto(r);
  $('#xPr').onclick = () => window.print();
  $('#xTk').onclick = async () => { try { manejarImpresion(await post('/api/reportes/imprimir', { desde: r.desde, hasta: r.hasta }), 'Reporte'); if (S.me.config.impresora_tipo === 'ninguna') verTicket({ preview: S.ultimaImpresion }); } catch (e) { errToast(e); } };
  $$('[data-rc]').forEach((b) => (b.onclick = async () => { try { manejarImpresion(await post(`/api/turno/${b.dataset.rc}/reimprimir`), 'Corte'); } catch (e) { errToast(e); } }));
  $$('[data-rt]').forEach((b) => (b.onclick = async () => { try { manejarImpresion(await post(`/api/ticket/${b.dataset.rt}/reimprimir`, { tipo: 'pagado' }), 'Comprobante'); } catch (e) { errToast(e); } }));
}

async function cargarGraficas(r, periodo) {
  const [d2, h2] = Graficas.rangoAnterior(periodo, r.desde, r.hasta);
  try {
    const g = await api(`/api/graficas?desde=${r.desde}&hasta=${r.hasta}&desde2=${d2}&hasta2=${h2}`);
    const w = $('#gWrap'); if (!w) return;
    w.innerHTML = `<p class="muted small" style="margin-top:0">Comparado contra: <b>${fdt(d2)}</b> a <b>${fdt(h2)}</b> · Pase el mouse (o toque) sobre las gráficas para ver los montos.</p>` + Graficas.tablero(g, periodo);
  } catch (e) { const w = $('#gWrap'); if (w) w.innerHTML = `<p class="alert bad">${esc(e.message)}</p>`; }
}

/* ================= GASTOS ================= */
async function vistaGastos(main) {
  const st = S.gas ||= { periodo: 'mes' };
  const periodos = { hoy: 'Hoy', semana: 'Semana', mes: 'Mes', anio: 'Año' };
  const [d, h] = rangoPeriodo(st.periodo);
  const [lista, fijos] = await Promise.all([api(`/api/gastos?desde=${d}&hasta=${h}`), api('/api/gastos-fijos')]);
  const cats = S.me.config.gastos_categorias || [];
  const chipF = { pagado: 'ok', pendiente: '', 'por vencer': 'warn', vencido: 'bad', inactivo: '' };
  const activosF = fijos.filter((g) => g.activo), faltan = activosF.filter((g) => g.estado !== 'pagado');
  const vivos = lista.filter((g) => !g.cancelado);
  const total = vivos.reduce((t, g) => t + g.monto, 0);
  const porCat = Object.values(vivos.reduce((a, g) => { (a[g.categoria] ||= { nombre: g.categoria, valor: 0 }).valor += g.monto; return a; }, {})).sort((a, b) => b.valor - a.valor);
  main.innerHTML = `${can('gastos') ? `<div class="card"><h2 style="margin-top:0">Registrar gasto</h2>
    <form id="fG" class="grid">
      <div class="grid g4">
        <label class="f">Tipo de gasto<select name="categoria">${cats.map((c) => `<option>${esc(c)}</option>`).join('')}<option value="__otra">Otro tipo…</option></select></label>
        <label class="f hidden" id="lOtra">Nombre del nuevo tipo<input name="otra" placeholder="Ej. Pintura, Seguridad"></label>
        <label class="f">Concepto / nota<input name="concepto" placeholder="Ej. recibo CFE octubre, cambio de foco"></label>
        <label class="f">Monto (MXN)<input name="monto" type="number" min="0.01" step="0.01" required></label>
      </div>
      <div class="row" style="gap:1.2rem">
        <label class="check"><input type="radio" name="origen" value="fuera" checked> Pagado fuera de caja (no afecta el corte)</label>
        <label class="check"><input type="radio" name="origen" value="caja"> Pagado con dinero de la caja (se descuenta del efectivo del turno)</label>
        <label class="f" id="lFecha" style="max-width:180px">Fecha<input type="date" name="fecha" value="${dateInput(Date.now())}"></label>
      </div>
      <div><button class="btn pri big">Registrar gasto</button></div>
    </form></div>` : ''}
  <div class="card"><div class="row"><h2 class="grow" style="margin:0">📌 Gastos fijos</h2>${can('gastos') ? '<button class="btn acc" id="nFijo">+ Nuevo gasto fijo</button>' : ''}</div>
    <p class="muted small" style="margin:.3rem 0 .7rem">Renta, luz, agua, internet, sueldos… lo que se paga cada semana, quincena, mes, bimestre o año. El sistema le avisa cuáles faltan por pagar y con un clic registra el pago como gasto.</p>
    ${activosF.length ? `<div class="grid g3" style="margin-bottom:.7rem"><div class="kpi ${faltan.length ? 'bad' : 'ok'}"><div class="l">Faltan por pagar</div><div class="v">${faltan.length}</div><div class="small muted">${money(faltan.reduce((t, g) => t + g.monto, 0))} estimado</div></div>
      <div class="kpi ok"><div class="l">Ya pagados en su periodo</div><div class="v">${activosF.length - faltan.length}</div></div>
      <div class="kpi"><div class="l">Gastos fijos al mes (aprox.)</div><div class="v">${money(activosF.reduce((t, g) => t + g.monto * ({ semanal: 4.33, quincenal: 2, mensual: 1, bimestral: 0.5, anual: 1 / 12 }[g.frecuencia] || 1), 0))}</div></div></div>` : ''}
    <div class="tbl-wrap"><table><thead><tr><th>Gasto</th><th>Tipo</th><th>Cada</th><th>Fecha límite</th><th class="num">Monto</th><th>Estado</th><th></th></tr></thead><tbody>
      ${fijos.map((g) => `<tr style="${g.activo ? '' : 'opacity:.5'}"><td><b>${esc(g.nombre)}</b>${g.notas ? `<div class="small muted">${esc(g.notas)}</div>` : ''}</td><td>${esc(g.categoria)}</td><td>${esc(g.frecuencia_txt)}</td>
        <td class="small">${fd(g.periodo.vence)}<div class="muted">${esc(g.periodo.nombre)}</div></td><td class="num">${money(g.monto)}</td>
        <td><span class="chip ${chipF[g.estado]}">${g.estado}</span>${g.pagado ? `<div class="small muted">${fd(g.pagado.fecha)} · ${money(g.pagado.monto)}</div>` : ''}</td>
        <td class="right" style="white-space:nowrap">${can('gastos') && g.activo && g.estado !== 'pagado' ? `<button class="btn sm ok" data-pf="${g.id}">Pagar</button> ` : ''}${can('gastos') ? `<button class="btn sm" data-ef="${g.id}">Editar</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="7" class="muted">Aún no hay gastos fijos. Agregue la renta, luz, agua, internet…</td></tr>'}
    </tbody></table></div></div>
  <div class="card"><div class="row"><h2 class="grow" style="margin:0">Gastos</h2><div class="seg" id="segG">${Object.entries(periodos).map(([k, v]) => `<button data-p="${k}" class="${st.periodo === k ? 'on' : ''}">${v}</button>`).join('')}</div></div>
    <div class="grid g2" style="margin-top:.8rem;align-items:start">
      <div><div class="kpi bad"><div class="l">Total de gastos</div><div class="v">${money(total)}</div><div class="small muted">${vivos.length} gasto(s)</div></div>
        <div style="margin-top:.8rem">${Graficas.pastel(porCat, { centro: 'Gastos' })}</div></div>
      <div class="tbl-wrap" style="max-height:520px;overflow-y:auto"><table><thead><tr><th>Fecha</th><th>Tipo</th><th>Concepto</th><th>Pagado</th><th class="num">Monto</th><th></th></tr></thead><tbody>
        ${lista.map((g) => `<tr style="${g.cancelado ? 'opacity:.5;text-decoration:line-through' : ''}"><td class="small">${fdt(g.fecha)}</td><td><b>${esc(g.categoria)}</b></td><td class="small">${esc(g.concepto)}<div class="muted">${esc(g.usuario || '')}</div></td>
          <td>${g.origen === 'caja' ? '<span class="chip warn">De caja</span>' : '<span class="chip">Fuera</span>'}</td><td class="num">${money(g.monto)}</td>
          <td>${!g.cancelado && can('gastos') ? `<button class="btn sm bad" data-x="${g.id}" title="Cancelar gasto">✕</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="6" class="muted">Sin gastos en el periodo.</td></tr>'}
      </tbody></table></div></div></div>`;
  $$('#segG button').forEach((b) => (b.onclick = () => { st.periodo = b.dataset.p; vistaGastos(main); }));
  $('#nFijo') && ($('#nFijo').onclick = () => editarGastoFijo({}, () => vistaGastos(main)));
  $$('[data-ef]').forEach((b) => (b.onclick = () => editarGastoFijo(fijos.find((x) => x.id == b.dataset.ef), () => vistaGastos(main))));
  $$('[data-pf]').forEach((b) => (b.onclick = () => pagarGastoFijo(fijos.find((x) => x.id == b.dataset.pf), () => vistaGastos(main))));
  $$('[data-x]').forEach((b) => (b.onclick = async () => {
    if (!(await confirmar('¿Cancelar este gasto?', { ok: 'Cancelar gasto', peligro: true }))) return;
    try { await post(`/api/gastos/${b.dataset.x}/cancelar`); toast('Gasto cancelado', 'ok'); vistaGastos(main); } catch (e) { errToast(e); }
  }));
  const f = $('#fG'); if (!f) return;
  const verOrigen = () => { $('#lFecha').style.display = f.origen.value === 'caja' ? 'none' : ''; };
  $$('[name=origen]', f).forEach((x) => (x.onchange = verOrigen)); verOrigen();
  f.categoria.onchange = () => $('#lOtra').classList.toggle('hidden', f.categoria.value !== '__otra');
  f.onsubmit = async (e) => {
    e.preventDefault();
    const dd = formData(f);
    const categoria = dd.categoria === '__otra' ? String(dd.otra || '').trim() : dd.categoria;
    if (!categoria) return toast('Escriba el nombre del nuevo tipo de gasto', 'warn');
    if (dd.origen === 'caja' && !S.me.turno) return toast('Para pagar de la caja debe tener turno abierto', 'warn');
    try {
      await post('/api/gastos', { categoria, concepto: dd.concepto, monto: Number(dd.monto), origen: dd.origen, fecha: dd.fecha ? fromDateInput(dd.fecha) + 12 * 3600e3 : Date.now() });
      toast(dd.origen === 'caja' ? 'Gasto registrado y descontado del efectivo del turno' : 'Gasto registrado', 'ok');
      await recargarMe(); vistaGastos(main);
    } catch (err) { errToast(err); }
  };
}

const DIAS_SEM = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
const MESES = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
function editarGastoFijo(g, despues) {
  const cats = S.me.config.gastos_categorias || [];
  const m = modal(`<div class="hd"><h3>${g.id ? 'Editar' : 'Nuevo'} gasto fijo</h3><button class="btn sm" data-close>✕</button></div>
    <form class="bd grid" id="fF">
      <div class="grid g2"><label class="f">Nombre<input name="nombre" value="${esc(g.nombre || '')}" placeholder="Ej. Renta del terreno, Luz CFE, Internet" required autofocus></label>
        <label class="f">Tipo de gasto<select name="categoria">${[...new Set([...cats, g.categoria].filter(Boolean))].map((c) => `<option ${c === g.categoria ? 'selected' : ''}>${esc(c)}</option>`).join('')}</select></label></div>
      <div class="grid g4"><label class="f">Monto aproximado<input name="monto" type="number" min="0" step="0.01" value="${g.monto ?? ''}"></label>
        <label class="f">Se paga cada<select name="frecuencia">${[['semanal', 'Semana'], ['quincenal', 'Quincena'], ['mensual', 'Mes'], ['bimestral', 'Dos meses (bimestral)'], ['anual', 'Año']].map(([k, v]) => `<option value="${k}" ${(g.frecuencia || 'mensual') === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
        <label class="f" id="lDia">Día de pago<select name="dia"></select></label>
        <label class="f" id="lMes">Mes<select name="mes_ref">${MESES.map((x, i) => `<option value="${i + 1}" ${(g.mes_ref || 1) == i + 1 ? 'selected' : ''}>${x}</option>`).join('')}</select></label></div>
      <label class="f">Notas<input name="notas" value="${esc(g.notas || '')}" placeholder="Ej. número de servicio, a quién se le paga"></label>
      <label class="check"><input type="checkbox" name="activo" ${g.activo === 0 ? '' : 'checked'}> Activo</label>
    </form><div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn pri" id="gF">Guardar</button></div>`);
  const f = $('#fF', m.el);
  const verFrec = () => {
    const fr = f.frecuencia.value, dia = Number(f.dia.value || g.dia || 1);
    f.dia.innerHTML = fr === 'semanal' ? DIAS_SEM.map((x, i) => `<option value="${i + 1}" ${dia === i + 1 ? 'selected' : ''}>${x}</option>`).join('')
      : Array.from({ length: fr === 'quincenal' ? 15 : 31 }, (_, i) => `<option value="${i + 1}" ${dia === i + 1 ? 'selected' : ''}>${fr === 'quincenal' ? `Día ${i + 1} de cada quincena` : 'Día ' + (i + 1)}</option>`).join('');
    $('#lMes', m.el).style.display = ['anual', 'bimestral'].includes(fr) ? '' : 'none';
    $('#lMes', m.el).firstChild.textContent = fr === 'anual' ? 'Mes en que se paga' : 'Mes del primer bimestre';
  };
  f.frecuencia.onchange = verFrec; verFrec();
  $('#gF', m.el).onclick = async () => { try { await post('/api/gastos-fijos', { ...formData(f), id: g.id }); m.close(); toast('Gasto fijo guardado', 'ok'); await recargarMe(); despues && despues(); } catch (e) { errToast(e); } };
}
function pagarGastoFijo(g, despues) {
  const m = modal(`<div class="hd"><h3>Pagar: ${esc(g.nombre)}</h3><button class="btn sm" data-close>✕</button></div>
    <form class="bd grid" id="fP"><p class="muted small" style="margin:0">${esc(g.categoria)} · ${esc(g.frecuencia_txt)} · ${esc(g.periodo.nombre)} (fecha límite ${fd(g.periodo.vence)})</p>
      <div class="grid g2"><label class="f">Monto pagado<input name="monto" type="number" min="0.01" step="0.01" value="${g.monto || ''}" required autofocus></label>
        <label class="f">Nota (opcional)<input name="concepto" placeholder="Ej. recibo, folio"></label></div>
      <label class="check"><input type="radio" name="origen" value="fuera" checked> Pagado fuera de caja</label>
      <label class="check"><input type="radio" name="origen" value="caja"> Pagado con dinero de la caja (se descuenta del turno)</label>
    </form><div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn ok" id="pF">Registrar pago</button></div>`);
  $('#pF', m.el).onclick = async () => {
    const d = formData($('#fP', m.el));
    if (d.origen === 'caja' && !S.me.turno) return toast('Para pagar de la caja debe tener turno abierto', 'warn');
    try { await post(`/api/gastos-fijos/${g.id}/pagar`, d); m.close(); toast('Pago registrado como gasto', 'ok'); await recargarMe(); despues && despues(); } catch (e) { errToast(e); }
  };
}

/* ================= PUBLICIDAD (renta de espacios / lonas) ================= */
async function vistaPublicidad(main) {
  const lista = await api('/api/publicidad');
  const chip = { rentado: 'ok', 'por vencer': 'warn', vencido: 'bad', libre: 'pri', inactivo: '' };
  const activos = lista.filter((e) => e.activo);
  const admin = S.me.usuario.rol === 'admin' || can('configuracion') || can('productos_admin');
  main.innerHTML = `<div class="card"><div class="row"><h2 class="grow" style="margin:0">🪧 Renta de espacios publicitarios</h2>${admin ? '<button class="btn acc" id="nEsp">+ Nuevo espacio</button>' : ''}</div>
    <p class="muted small" style="margin:.3rem 0 .7rem">Lonas, bardas, espectaculares o pantallas que renta a otros negocios. Cobre la renta, imprima su recibo y el sistema le avisa cuando una renta está por vencer o ya venció.</p>
    <div class="grid g4" style="margin-bottom:.8rem">
      <div class="kpi"><div class="l">Espacios</div><div class="v">${activos.length}</div></div>
      <div class="kpi ok"><div class="l">Rentados</div><div class="v">${activos.filter((e) => ['rentado', 'por vencer'].includes(e.estado)).length}</div></div>
      <div class="kpi warn"><div class="l">Por vencer / vencidos</div><div class="v">${activos.filter((e) => ['por vencer', 'vencido'].includes(e.estado)).length}</div></div>
      <div class="kpi pri"><div class="l">Libres</div><div class="v">${activos.filter((e) => e.estado === 'libre').length}</div><div class="small muted">ingreso mensual posible ${money(activos.reduce((t, e) => t + e.precio_mensual, 0))}</div></div></div>
    <div class="tbl-wrap"><table><thead><tr><th>Espacio</th><th>Medidas</th><th class="num">Precio mensual</th><th>Rentado a</th><th>Vigencia</th><th>Estado</th><th></th></tr></thead><tbody>
    ${lista.map((e) => { const r = e.actual || e.ultima; return `<tr style="${e.activo ? '' : 'opacity:.5'}"><td><b>${esc(e.nombre)}</b><div class="small muted">${esc(e.ubicacion)}</div></td><td>${esc(e.medidas)}</td><td class="num">${money(e.precio_mensual)}</td>
      <td>${r && e.estado !== 'libre' ? `<b>${esc(r.cliente)}</b><div class="small muted">${esc(r.telefono)}${r.anuncio ? ' · ' + esc(r.anuncio) : ''}</div>` : '<span class="muted">—</span>'}</td>
      <td class="small">${e.vigente_hasta && e.estado !== 'libre' ? 'hasta ' + fd(e.vigente_hasta) : '—'}</td><td><span class="chip ${chip[e.estado]}">${e.estado}</span></td>
      <td class="right" style="white-space:nowrap">${e.activo && can('publicidad') ? `<button class="btn sm ${['vencido', 'por vencer'].includes(e.estado) ? 'warn' : e.estado === 'libre' ? 'ok' : ''}" data-c="${e.id}">${e.estado === 'libre' ? 'Rentar' : 'Cobrar renta'}</button> ` : ''}${e.rentas.length ? `<button class="btn sm" data-h="${e.id}">Historial</button> ` : ''}${admin ? `<button class="btn sm" data-e="${e.id}">Editar</button>` : ''}</td></tr>`; }).join('') || '<tr><td colspan="7" class="muted">Agregue sus espacios: por ejemplo "Lona entrada principal", "Barda norte".</td></tr>'}
    </tbody></table></div></div>`;
  $('#nEsp') && ($('#nEsp').onclick = () => editarEspacio({}, () => vistaPublicidad(main)));
  $$('[data-e]').forEach((b) => (b.onclick = () => editarEspacio(lista.find((x) => x.id == b.dataset.e), () => vistaPublicidad(main))));
  $$('[data-c]').forEach((b) => (b.onclick = () => cobrarPublicidad(lista.find((x) => x.id == b.dataset.c), () => vistaPublicidad(main))));
  $$('[data-h]').forEach((b) => (b.onclick = () => {
    const e = lista.find((x) => x.id == b.dataset.h);
    modal(`<div class="hd"><h3>Historial · ${esc(e.nombre)}</h3><button class="btn sm" data-close>✕</button></div><div class="bd tbl-wrap"><table><thead><tr><th>Cobrado</th><th>Cliente</th><th>Anuncio</th><th>Desde</th><th>Hasta</th><th class="num">Monto</th><th></th></tr></thead><tbody>
      ${e.rentas.map((r) => `<tr><td>${fdt(r.fecha)}</td><td>${esc(r.cliente)}<div class="small muted">${esc(r.telefono)}</div></td><td>${esc(r.anuncio)}</td><td>${fd(r.desde)}</td><td>${fd(r.hasta)}</td><td class="num">${money(r.monto)}</td><td>${can('reimprimir') ? `<button class="btn sm" data-r="${r.id}">🖨️</button>` : ''}</td></tr>`).join('')}</tbody></table></div>`, { cls: 'wide' });
    $$('[data-r]').forEach((x) => (x.onclick = async () => { try { manejarImpresion(await post(`/api/publicidad/renta/${x.dataset.r}/reimprimir`, {}), 'Recibo'); } catch (er) { errToast(er); } }));
  }));
}
function editarEspacio(e, despues) {
  const m = modal(`<div class="hd"><h3>${e.id ? 'Editar' : 'Nuevo'} espacio publicitario</h3><button class="btn sm" data-close>✕</button></div>
    <form class="bd grid" id="fE"><div class="grid g2"><label class="f">Nombre<input name="nombre" value="${esc(e.nombre || '')}" placeholder="Ej. Lona entrada principal" required autofocus></label>
      <label class="f">Ubicación<input name="ubicacion" value="${esc(e.ubicacion || '')}" placeholder="Ej. barda que da a la avenida"></label></div>
      <div class="grid g3"><label class="f">Medidas<input name="medidas" value="${esc(e.medidas || '')}" placeholder="Ej. 3 x 2 m"></label>
        <label class="f">Precio mensual (MXN)<input name="precio_mensual" type="number" min="0" step="0.01" value="${e.precio_mensual ?? ''}"></label>
        <label class="f">Orden<input name="orden" type="number" value="${e.orden ?? 0}"></label></div>
      <label class="f">Notas<input name="notas" value="${esc(e.notas || '')}"></label>
      <label class="check"><input type="checkbox" name="activo" ${e.activo === 0 ? '' : 'checked'}> Activo</label></form>
    <div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn pri" id="gE">Guardar</button></div>`);
  $('#gE', m.el).onclick = async () => { try { await post('/api/publicidad', { ...formData($('#fE', m.el)), id: e.id }); m.close(); toast('Espacio guardado', 'ok'); despues && despues(); } catch (er) { errToast(er); } };
}
function cobrarPublicidad(e, despues) {
  if (sinTurno(() => cobrarPublicidad(e, despues))) return;
  const ult = e.actual || e.ultima;
  const renueva = ult && e.estado !== 'libre';
  const desde0 = renueva && ult.hasta > Date.now() - 60 * 864e5 ? inicioDia(ult.hasta + 1000) : inicioDia(Date.now());
  const m = modal(`<div class="hd"><h3>${renueva ? 'Cobrar renta' : 'Rentar'} · ${esc(e.nombre)}</h3><button class="btn sm" data-close>✕</button></div>
    <form class="bd grid" id="fR">
      <div class="grid g2"><label class="f">Cliente / negocio<input name="cliente" value="${esc(renueva ? ult.cliente : '')}" required autofocus></label><label class="f">Teléfono<input name="telefono" value="${esc(renueva ? ult.telefono : '')}"></label></div>
      <label class="f">Anuncio (qué se publica)<input name="anuncio" value="${esc(renueva ? ult.anuncio : '')}" placeholder="Ej. Taquería El Güero"></label>
      <div class="grid g4"><label class="f">Meses<input name="meses" type="number" min="1" max="36" step="1" value="1"></label>
        <label class="f">Desde<input name="desde" type="date" value="${dateInput(desde0)}"></label><label class="f">Hasta (incluido)<input name="hasta" type="date"></label>
        <label class="f">Monto total (MXN)<input name="monto" type="number" min="0.01" step="0.01"></label></div>
      <p class="muted small" style="margin:0">Precio mensual del espacio: <b>${money(e.precio_mensual)}</b>. Puede cambiar el monto si hay descuento.</p>
    </form><div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn ok big" id="bR">Cobrar <span class="kbd">F12</span></button></div>`, { cls: 'wide' });
  const f = $('#fR', m.el);
  const calc = (monto) => {
    const meses = Math.max(1, Math.round(Number(f.meses.value) || 1)), d = new Date(fromDateInput(f.desde.value));
    const h = new Date(d); h.setMonth(h.getMonth() + meses); h.setDate(h.getDate() - 1);
    f.hasta.value = dateInput(h.getTime());
    if (monto) f.monto.value = r2(e.precio_mensual * meses) || '';
  };
  f.meses.oninput = () => calc(true); f.desde.onchange = () => calc(false); calc(true);
  const cobrar = async (forzar) => {
    const d = formData(f), desde = fromDateInput(d.desde), hasta = finDia(fromDateInput(d.hasta)), monto = Number(d.monto || 0);
    if (!String(d.cliente || '').trim()) return toast('Escriba el nombre de quien renta', 'warn');
    if (!(monto > 0)) return toast('Escriba el monto', 'warn');
    if (!(hasta > desde)) return toast('Revise las fechas', 'warn');
    const cobro = forzar && forzar.valores ? forzar : await ventanaCobro({ total: monto, titulo: 'Renta de publicidad', detalle: `${e.nombre} · ${d.cliente} · ${fd(desde)} a ${fd(hasta)}`, referencia: 'PUB' + e.id });
    if (!cobro) return;
    try {
      const r = await post(`/api/publicidad/${e.id}/cobrar`, { ...d, desde, hasta, monto, ...cobro.valores, no_imprimir: !cobro.imprimir, forzar: forzar === true || !!(forzar && forzar.forzar) });
      m.close();
      trasCobro(r, cobro, 'Recibo de publicidad', () => post(`/api/publicidad/renta/${r.renta.id}/reimprimir`, { copia: true }));
      toast(`Renta pagada · vigente hasta ${fd(r.renta.hasta)}`, 'ok');
      await recargarMe(); despues && despues();
    } catch (er) {
      if (er.status === 409 && await confirmar(esc(er.message) + '<br><br>¿Registrar la renta de todos modos?', { ok: 'Sí, registrar' })) return cobrar({ ...cobro, forzar: true });
      errToast(er);
    }
  };
  $('#bR', m.el).onclick = () => cobrar();
  m.el.addEventListener('keydown', (ev) => { if (ev.key === 'F12') { ev.preventDefault(); ev.stopPropagation(); cobrar(); } });
}

/* ================= CONVENIOS ================= */
const TIPO_CONV = { porcentaje: 'Descuento en porcentaje (%)', monto: 'Descuento en pesos ($)', fijo: 'Precio especial fijo ($)', horas: 'Horas gratis', tarifa: 'Usar otra tarifa' };
async function vistaConvenios(main) {
  const [lista, tarifas] = await Promise.all([api('/api/convenios'), api('/api/tarifas')]);
  const desc = (c) => (c.tipo === 'porcentaje' ? c.valor + '% de descuento' : c.tipo === 'monto' ? money(c.valor) + ' de descuento' : c.tipo === 'fijo' ? 'Paga ' + money(c.valor) : c.tipo === 'horas' ? c.valor + ' h gratis' : 'Tarifa: ' + (tarifas.find((t) => t.id === c.tarifa_id)?.nombre || '?'));
  main.innerHTML = `<div class="card"><div class="row"><h2 class="grow">Convenios con negocios</h2><button class="btn acc" id="nC">+ Nuevo convenio</button></div>
    <p class="muted small">El cajero elige el convenio al momento de cobrar (por ejemplo, cuando el cliente presenta el sello del restaurante).</p>
    ${tabla(lista, [{ t: 'Negocio', h: (c) => `<b>${esc(c.nombre)}</b>` }, { t: 'Beneficio', f: desc }, { t: 'Notas', k: 'notas' }, { t: 'Estado', h: (c) => (c.activo ? '<span class="chip ok">activo</span>' : '<span class="chip">inactivo</span>') }, { t: '', h: (c) => `<button class="btn sm" data-e="${c.id}">Editar</button>` }])}</div>`;
  const editar = (c) => {
    const m = modal(`<div class="hd"><h3>${c.id ? 'Editar' : 'Nuevo'} convenio</h3><button class="btn sm" data-close>✕</button></div>
      <form class="bd grid"><label class="f">Nombre del negocio<input name="nombre" value="${esc(c.nombre || '')}" required autofocus></label>
      <div class="grid g2"><label class="f">Tipo de beneficio<select name="tipo">${Object.entries(TIPO_CONV).map(([k, v]) => `<option value="${k}" ${c.tipo === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
      <label class="f" id="bV">Valor<input name="valor" type="number" step="0.01" min="0" value="${c.valor ?? ''}"></label>
      <label class="f hidden" id="bT">Tarifa especial<select name="tarifa_id">${tarifas.map((t) => `<option value="${t.id}" ${c.tarifa_id === t.id ? 'selected' : ''}>${esc(t.nombre)}</option>`).join('')}</select></label></div>
      <label class="f">Notas<input name="notas" value="${esc(c.notas || '')}"></label><label class="check"><input type="checkbox" name="activo" ${c.activo === 0 ? '' : 'checked'}> Activo</label></form>
      <div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn pri" id="g">Guardar</button></div>`);
    const f = $('form', m.el);
    const upd = () => { $('#bT', m.el).classList.toggle('hidden', f.tipo.value !== 'tarifa'); $('#bV', m.el).classList.toggle('hidden', f.tipo.value === 'tarifa'); };
    f.tipo.onchange = upd; upd();
    $('#g', m.el).onclick = async () => { try { await post('/api/convenios', { ...formData(f), id: c.id }); m.close(); await recargarMe(); ir('convenios'); toast('Convenio guardado', 'ok'); } catch (e) { errToast(e); } };
  };
  $('#nC').onclick = () => editar({ tipo: 'porcentaje' });
  $$('[data-e]').forEach((b) => (b.onclick = () => editar(lista.find((c) => c.id == b.dataset.e))));
}

/* ================= TARIFAS ================= */
const MODOS_TARIFA = { hora: 'Por hora (mismo precio cada hora)', escalonada: 'Precio por cada hora (capturado a mano)', bloque: 'Por bloque (12 horas, 1 día, etc.)', fija: 'Precio fijo (eventos, pago único)' };
function descTarifa(t) {
  const esc2 = (() => { try { return JSON.parse(t.escalones || '[]'); } catch { return []; } })();
  if (t.modo === 'fija') return `Precio fijo ${money(t.precio_bloque)}`;
  if (t.modo === 'escalonada') return esc2.map((p, i) => `${i + 1}ª h ${money(p)}`).join(' · ') + ` · después ${money(t.precio_hora_extra)}/h`;
  if (t.modo === 'hora') return `${money(t.precio_hora)}/hora${t.tope ? ' · tope ' + money(t.tope) + '/día' : ''}`;
  return t.excedente === 'bloque' ? `${money(t.precio_bloque)} cada ${t.horas_bloque} h` : `${money(t.precio_bloque)} por ${t.horas_bloque} h + ${money(t.precio_hora_extra)}/h extra`;
}
async function vistaTarifas(main) {
  const lista = await api('/api/tarifas');
  const cfg = S.me.config;
  const opts = (sel, sinSel) => lista.filter((t) => t.activo || t.id == sel).map((t) => `<option value="${t.id}" ${!sinSel || Number(sel) ? (t.id == sel ? 'selected' : '') : ''}>${esc(t.nombre)}${t.activo ? '' : ' (inactiva)'}</option>`).join('');
  main.innerHTML = `<div class="card"><div class="row"><h2 class="grow">Tarifas</h2><button class="btn acc" id="nT">+ Nueva tarifa</button></div>
    <div class="paybox" style="margin:.6rem 0 1rem">
      <b>Tarifa que sale elegida automáticamente</b>
      <p class="muted small" style="margin:.2rem 0 .6rem">El cajero la puede cambiar en cada ingreso si tiene permiso; esto solo decide cuál aparece seleccionada.</p>
      <div class="grid g3">
        <label class="f">🚗 Clientes normales (ingreso manual)<select id="tDef">${opts(cfg.tarifa_default_id)}</select></label>
        <label class="f">⚡ Ingreso rápido (F2)<select id="tRap"><option value="0" ${!Number(cfg.tarifa_rapida_id) ? 'selected' : ''}>La misma que clientes normales</option>${opts(cfg.tarifa_rapida_id, true)}</select></label>
        <label class="f">🍽️ Meseros<select id="tMes">${opts(cfg.tarifa_mesero_id)}</select></label>
      </div>
      <div class="row" style="margin-top:.6rem"><span class="grow"></span><button class="btn pri" id="gPred">Guardar tarifas predeterminadas</button></div>
    </div>
    ${tabla(lista, [{ t: 'Nombre', h: (t) => `<b>${esc(t.nombre)}</b>${t.id == cfg.tarifa_default_id ? ' <span class="chip ok">⭐ normales</span>' : ''}${t.id == (Number(cfg.tarifa_rapida_id) || cfg.tarifa_default_id) ? ' <span class="chip ok">⭐ rápido</span>' : ''}${t.id == cfg.tarifa_mesero_id ? ' <span class="chip warn">⭐ meseros</span>' : ''}` }, { t: 'Tipo', f: (t) => MODOS_TARIFA[t.modo].split(' (')[0] }, { t: 'Cobro', f: descTarifa },
      { t: 'Tolerancia', f: (t) => t.tolerancia_min + ' min' }, { t: 'Estado', h: (t) => (t.activo ? '<span class="chip ok">activa</span>' : '<span class="chip">inactiva</span>') }, { t: '', h: (t) => `<button class="btn sm" data-e="${t.id}">Editar</button>` }])}
    <div class="alert pri" style="margin-top:1rem"><b>Tolerancia:</b> minutos de gracia antes de cobrar la siguiente hora (o el siguiente bloque). Ejemplo con tolerancia de 10 min: 1 h 08 min = 1 hora; 1 h 12 min = 2 horas.<br>
    <b>Precio por cada hora:</b> usted escribe cuánto cuesta la 1ª hora, la 2ª, la 3ª… y cuánto cada hora después.</div></div>`;
  $('#gPred').onclick = async () => {
    try {
      await post('/api/config', { tarifa_default_id: Number($('#tDef').value), tarifa_rapida_id: Number($('#tRap').value), tarifa_mesero_id: Number($('#tMes').value) });
      await recargarMe(); toast('Tarifas predeterminadas guardadas', 'ok'); ir('tarifas');
    } catch (e) { errToast(e); }
  };
  const editar = (t) => {
    let escal = []; try { escal = JSON.parse(t.escalones || '[]'); } catch { /* */ }
    if (!escal.length) escal = [30, 20, 20];
    const m = modal(`<div class="hd"><h3>${t.id ? 'Editar' : 'Nueva'} tarifa</h3><button class="btn sm" data-close>✕</button></div>
      <div class="bd cobro"><form class="grid" id="fT">
        <label class="f">Nombre<input name="nombre" value="${esc(t.nombre || '')}" required autofocus></label>
        <label class="f">Tipo de tarifa<select name="modo">${Object.entries(MODOS_TARIFA).map(([k, v]) => `<option value="${k}" ${t.modo === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
        <div class="grid g2" data-modo="hora"><label class="f">Precio por hora<input name="precio_hora" type="number" step="0.01" min="0" value="${t.precio_hora ?? 20}"></label></div>
        <div class="grid paybox" data-modo="escalonada">
          <div class="row"><b class="grow small">Precio de cada hora</b><button type="button" class="btn sm" id="addH">+ Agregar hora</button></div>
          <div id="escal" class="grid g3"></div>
          <label class="f">Cada hora después de la última<input name="precio_hora_extra" type="number" step="0.01" min="0" value="${t.precio_hora_extra ?? 15}"></label>
        </div>
        <div class="grid g2" data-modo="hora escalonada"><label class="f">Tope por día (0 = sin tope)<input name="tope" type="number" step="0.01" min="0" value="${t.tope ?? 0}"></label></div>
        <div class="grid g2" data-modo="bloque"><label class="f">Horas del bloque<input name="horas_bloque" type="number" step="0.5" min="0.5" value="${t.horas_bloque ?? 12}"></label>
          <label class="f" data-modo="bloque fija">Precio del bloque<input name="precio_bloque" type="number" step="0.01" min="0" value="${t.precio_bloque ?? 0}"></label>
          <label class="f">Al pasar el bloque cobrar<select name="excedente"><option value="hora" ${t.excedente !== 'bloque' ? 'selected' : ''}>Cada hora extra</option><option value="bloque" ${t.excedente === 'bloque' ? 'selected' : ''}>Otro bloque completo</option></select></label>
          <label class="f" id="mX">Precio por hora extra<input id="phx" type="number" step="0.01" min="0" value="${t.precio_hora_extra ?? 0}"></label></div>
        <div class="grid g2" data-modo="fija"><label class="f">Precio fijo<input id="pfija" type="number" step="0.01" min="0" value="${t.precio_bloque ?? 100}"></label></div>
        <div class="grid g3"><label class="f">Tolerancia (min)<input name="tolerancia_min" type="number" min="0" value="${t.tolerancia_min ?? 10}"></label>
          <label class="f">Minutos gratis al inicio<input name="minutos_gratis" type="number" min="0" value="${t.minutos_gratis ?? 0}"></label>
          <label class="f">Orden<input name="orden" type="number" value="${t.orden ?? 0}"></label></div>
        <label class="check"><input type="checkbox" name="es_mesero" ${t.es_mesero ? 'checked' : ''}> Tarifa especial para meseros</label>
        <label class="check"><input type="checkbox" name="activo" ${t.activo === 0 ? '' : 'checked'}> Activa</label>
      </form><div><h4>Simulador</h4><div id="sim" class="tbl-wrap"></div></div></div>
      <div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn pri" id="g">Guardar</button></div>`, { cls: 'xl' });
    const f = $('#fT', m.el);
    const datos = () => {
      const d = formData(f);
      d.escalones = escal.map(Number);
      if (d.modo === 'bloque') d.precio_hora_extra = Number($('#phx', m.el).value || 0);
      if (d.modo === 'fija') d.precio_bloque = Number($('#pfija', m.el).value || 0);
      return d;
    };
    const pintarEsc = () => {
      $('#escal', m.el).innerHTML = escal.map((p, i) => `<label class="f">${i + 1}ª hora<div class="row" style="flex-wrap:nowrap;gap:.3rem"><input type="number" step="0.01" min="0" data-h="${i}" value="${p}">${escal.length > 1 ? `<button type="button" class="btn sm" data-x="${i}">✕</button>` : ''}</div></label>`).join('');
      $$('[data-h]', m.el).forEach((i) => (i.oninput = () => { escal[i.dataset.h] = Number(i.value || 0); upd(); }));
      $$('[data-x]', m.el).forEach((b) => (b.onclick = () => { escal.splice(b.dataset.x, 1); pintarEsc(); upd(); }));
    };
    $('#addH', m.el).onclick = () => { escal.push(escal[escal.length - 1] ?? 0); pintarEsc(); upd(); $$('[data-h]', m.el).pop().focus(); };
    let tm = null;
    const upd = () => {
      const modo = f.modo.value;
      $$('[data-modo]', m.el).forEach((el) => el.classList.toggle('hidden', !el.dataset.modo.split(' ').includes(modo)));
      $('#mX', m.el).classList.toggle('hidden', f.excedente.value === 'bloque');
      clearTimeout(tm);
      tm = setTimeout(async () => {
        try {
          const s = await post('/api/tarifas/simular', datos());
          $('#sim', m.el).innerHTML = `<table><thead><tr><th>Estancia</th><th class="num">Cobro</th><th>Cálculo</th></tr></thead><tbody>${s.map((x) => `<tr><td>${x.tiempo}</td><td class="num"><b>${money(x.monto)}</b></td><td class="small muted">${esc(x.detalle)}</td></tr>`).join('')}</tbody></table>`;
        } catch (e) { $('#sim', m.el).innerHTML = `<p class="muted">${esc(e.message)}</p>`; }
      }, 200);
    };
    f.addEventListener('input', upd); f.addEventListener('change', upd); pintarEsc(); upd();
    $('#g', m.el).onclick = async () => { try { await post('/api/tarifas', { ...datos(), id: t.id }); m.close(); await recargarMe(); ir('tarifas'); toast('Tarifa guardada', 'ok'); } catch (e) { errToast(e); } };
  };
  $('#nT').onclick = () => editar({ modo: 'escalonada' });
  $$('[data-e]').forEach((b) => (b.onclick = () => editar(lista.find((t) => t.id == b.dataset.e))));
}

/* ================= PRODUCTOS Y SERVICIOS ================= */
async function vistaProductos(main) {
  const lista = await api('/api/productos');
  main.innerHTML = `<div class="card"><div class="row"><h2 class="grow">Productos y servicios</h2><button class="btn acc" id="nP">+ Nuevo</button></div>
    <p class="muted small">Lavados, uso de baño, renta de lonas, bebidas… Se venden desde la caja (F9 o botones rápidos) o se agregan al cobrar un boleto.</p>
    ${tabla(lista, [{ t: 'Nombre', h: (p) => `<b>${esc(p.nombre)}</b>${p.rapido ? ' <span class="chip pri">botón rápido</span>' : ''}` }, { t: 'Tipo', k: 'tipo' }, { t: 'Precio', f: (p) => (p.precio_libre ? 'libre' : money(p.precio)), n: 1 },
      { t: 'Estado', h: (p) => (p.activo ? '<span class="chip ok">activo</span>' : '<span class="chip">inactivo</span>') }, { t: '', h: (p) => `<button class="btn sm" data-e="${p.id}">Editar</button>` }])}</div>`;
  $('#nP').onclick = () => editarProducto({ tipo: 'servicio' }, () => ir('productos'));
  $$('[data-e]').forEach((b) => (b.onclick = () => editarProducto(lista.find((p) => p.id == b.dataset.e), () => ir('productos'))));
}
function editarProducto(p, despues) {
  const m = modal(`<div class="hd"><h3>${p.id ? 'Editar' : 'Nuevo'} producto o servicio</h3><button class="btn sm" data-close>✕</button></div>
    <form class="bd grid"><div class="grid g2"><label class="f">Nombre<input name="nombre" value="${esc(p.nombre || '')}" required autofocus></label><label class="f">Código de barras (opcional)<input name="codigo" value="${esc(p.codigo || '')}" placeholder="Escanéelo aquí"></label></div>
    <div class="grid g3"><label class="f">Tipo<select name="tipo"><option value="servicio" ${p.tipo !== 'producto' ? 'selected' : ''}>Servicio</option><option value="producto" ${p.tipo === 'producto' ? 'selected' : ''}>Producto</option></select></label>
    <label class="f">Precio<input name="precio" type="number" step="0.01" min="0" value="${p.precio ?? ''}"></label><label class="f">Orden<input name="orden" type="number" value="${p.orden ?? 0}"></label></div>
    <label class="check"><input type="checkbox" name="precio_libre" ${p.precio_libre ? 'checked' : ''}> Precio libre: el cajero escribe el importe al cobrar (ej. renta de lonas, eventos)</label>
    <label class="check"><input type="checkbox" name="rapido" ${p.rapido ? 'checked' : ''}> Botón de cobro rápido en la pantalla de Caja (ej. uso de baño, lavado)</label>
    <label class="check"><input type="checkbox" name="activo" ${p.activo === 0 ? '' : 'checked'}> Activo</label></form>
    <div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn pri" id="g">Guardar</button></div>`);
  $('#g', m.el).onclick = async () => { try { await post('/api/productos', { ...formData($('form', m.el)), id: p.id }); m.close(); await recargarMe(); toast('Guardado', 'ok'); despues && despues(); } catch (e) { errToast(e); } };
}

/* ================= CONFIGURACIÓN ================= */
async function vistaConfig(main) {
  await recargarMe();
  const c = S.me.config;
  const ck = (k, t) => `<label class="check"><input type="checkbox" name="${k}" ${c[k] ? 'checked' : ''}> ${t}</label>`;
  const inp = (k, t, type = 'text', extra = '') => `<label class="f">${t}<input name="${k}" type="${type}" value="${esc(c[k] ?? '')}" ${extra}></label>`;
  main.innerHTML = `<form id="fCfg">
  <div class="card"><h3>Empresa (encabezado de los tickets)</h3><div class="grid g2">${inp('empresa_nombre', 'Nombre')}${inp('empresa_telefono', 'Teléfono')}${inp('empresa_direccion', 'Dirección')}${inp('empresa_rfc', 'RFC')}</div></div>
  <div class="card"><h3>Estacionamiento</h3><div class="grid g3">${inp('capacidad', 'Número de cajones / espacios', 'number', 'min="0"')}${inp('tipo_cambio_default', 'Tipo de cambio sugerido al abrir turno', 'number', 'step="0.01"')}${inp('costo_boleto_perdido', 'Costo del boleto perdido (MXN)', 'number', 'step="0.01"')}</div>
    <div class="grid" style="margin-top:.6rem">${ck('mostrar_diferencia_cajero', 'Mostrar faltantes/sobrantes a todos los cajeros al cerrar turno (si no, solo a quien tenga el permiso)')}${ck('imprimir_auto', 'Imprimir el ticket automáticamente al cobrar (se quita la opción de "Cobrar sin imprimir")')}${ck('preguntar_copia_cajero', 'Preguntar si se imprime un segundo ticket (copia del cajero) después de cobrar')}</div></div>
  <div class="card"><h3>Textos de los tickets</h3><div class="grid">
    <label class="f">Políticas de la empresa (salen en el boleto de entrada)<textarea name="politicas">${esc(c.politicas)}</textarea></label>
    ${ck('imprimir_politicas', 'Imprimir las políticas en el boleto de entrada (en letra chica). Desactívelo para ahorrar más papel.')}
    <label class="f">Texto de boleto perdido (sale en el boleto de entrada)<input name="boleto_perdido_texto" value="${esc(c.boleto_perdido_texto)}"></label>
    <label class="f">Políticas del formato de boleto perdido (se firma)<textarea name="boleto_perdido_politicas">${esc(c.boleto_perdido_politicas)}</textarea></label>
    ${inp('mensaje_pago', 'Mensaje al final del comprobante de pago')}
    <p class="muted small">Al final de cada ticket sale siempre el logo y la leyenda de Maxsel.</p>
    <label class="f">Contacto de Maxsel al final del ticket (un renglón por línea, ej. WhatsApp, Facebook)<textarea name="maxsel_contacto" rows="2" placeholder="WhatsApp 664 000 0000&#10;facebook.com/maxsel">${esc(c.maxsel_contacto || '')}</textarea></label></div></div>
  <div class="card"><h3>Impresora de tickets 80 mm</h3><div class="grid g3">
    <label class="f" style="grid-column:span 2">Impresora (las que ya están instaladas en Windows)<select id="selImp"><option value="">Cargando impresoras…</option></select></label>
    <label class="f">Corte de papel al terminar<select name="impresora_corte"><option value="parcial" ${c.impresora_corte !== 'total' ? 'selected' : ''}>Corte parcial</option><option value="total" ${c.impresora_corte === 'total' ? 'selected' : ''}>Corte total</option></select></label>
    <label class="f">Marca de la impresora (letras por renglón)<select name="impresora_columnas" id="selCols">${[[42, 'Epson TM-T88 / TM-T20, Bixolon, Star (42)'], [48, 'Genérica 80 mm: Xprinter, 3nStar, EC Line, POS-80 (48)'], [32, 'Impresora de 58 mm (32)'], [56, 'Otra muy ancha (56)']].map(([v, t]) => `<option value="${v}" ${Number(c.impresora_columnas) === v ? 'selected' : ''}>${t}</option>`).join('')}${[42, 48, 32, 56].includes(Number(c.impresora_columnas)) ? '' : `<option value="${esc(c.impresora_columnas)}" selected>Personalizado (${esc(c.impresora_columnas)})</option>`}</select></label>
    <input type="hidden" name="impresora_tipo" value="${esc(c.impresora_tipo === 'usb' ? 'windows' : c.impresora_tipo)}"><input type="hidden" name="impresora_nombre" value="${esc(c.impresora_nombre)}"></div>
    <p class="muted small" id="impAviso" style="margin:.4rem 0 0">Instale primero la impresora en Windows con su driver; después aparece aquí para seleccionarla.</p>
    <div class="row" style="margin-top:.6rem">${ck('abrir_cajon_efectivo', 'Abrir el cajón de dinero al cobrar en efectivo y al abrir turno')}<span class="grow"></span><button type="button" class="btn" data-p="impresora">🖨️ Probar impresión</button> <button type="button" class="btn" data-p="ancho" title="Imprime renglones de 32, 42, 48 y 56 letras para saber cuál le queda a su impresora">📏 Prueba de ancho</button><button type="button" class="btn" data-p="cajon">🗄️ Probar cajón</button></div></div>
  <div class="card"><h3>Pluma / puerta (relevador)</h3><div class="grid g3">
    <label class="f">Tipo de relevador<select name="relay_tipo">${[['ninguno', 'Ninguno'], ['http', 'WiFi/Red: Shelly, ESP32 (HTTP)'], ['serial', 'Relevador USB (puerto COM)']].map(([v, t]) => `<option value="${v}" ${c.relay_tipo === v ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
    ${inp('relay_url', 'URL del relevador (HTTP)')}<label class="f">Método HTTP<select name="relay_metodo">${['GET', 'POST'].map((x) => `<option ${c.relay_metodo === x ? 'selected' : ''}>${x}</option>`).join('')}</select></label>
    ${inp('relay_puerto_com', 'Puerto COM (USB)')}${inp('relay_on_hex', 'Comando encender (hex)')}${inp('relay_off_hex', 'Comando apagar (hex)')}${inp('relay_pulso_ms', 'Duración del pulso (ms)', 'number')}</div>
    <div class="row" style="margin-top:.6rem">${ck('abrir_pluma_al_cobrar', 'Abrir pluma al cobrar')}${ck('abrir_pluma_al_ingresar', 'Abrir pluma al dar ingreso')}<span class="grow"></span><button type="button" class="btn" data-p="pluma">🚧 Probar pluma</button></div>
    <div class="paybox" style="margin-top:.6rem"><b class="small">Control de acceso</b><div class="grid" style="margin-top:.3rem">${ck('bloquear_lleno', 'No dar entrada (ni abrir la pluma) cuando el estacionamiento esté lleno')}${ck('bloquear_pension_vencida', 'Negar el acceso a pensionados con la pensión vencida (el cajero puede autorizar la entrada con tarifa normal)')}</div>
      <p class="muted small" style="margin:.3rem 0 0">Con "Abrir pluma al dar ingreso" la pluma sólo sube cuando el sistema registra la entrada e imprime el boleto. Si no hay boleto, no hay acceso.</p></div>
    <p class="muted small">Shelly Plus 1 (Gen2): <span class="mono">http://IP/rpc/Switch.Set?id=0&amp;on=true&amp;toggle_after=1</span> · Shelly 1 (Gen1): <span class="mono">http://IP/relay/0?turn=on&amp;timer=1</span> · ESP32 Maxsel: <span class="mono">http://IP/abrir?token=SU_TOKEN</span></p></div>
  <div class="card"><h3>📷 Cámara de entrada (foto de cada carro)</h3>
    <p class="muted small" style="margin-top:0">Al registrar cada entrada se toma una foto del carro y se guarda con el boleto. Se ve al cobrar, en "Vehículos dentro" y en los reportes. No lee placas: sólo guarda la foto.</p>
    <div class="grid g3"><label class="f">Tipo de cámara<select name="camara_tipo" id="camTipo">${[['ninguna', 'Sin cámara'], ['ip', 'Cámara IP / DVR (Hikvision, Dahua, etc.)'], ['usb', 'Cámara USB (webcam) en esta computadora']].map(([v, t]) => `<option value="${v}" ${c.camara_tipo === v ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
      ${inp('camara_dias', 'Guardar las fotos (días)', 'number', 'min="1" max="3650"')}</div>
    <div id="camIP" class="grid g3" style="margin-top:.6rem">${inp('camara_url', 'Dirección de la foto (snapshot)')}${inp('camara_usuario', 'Usuario de la cámara')}${inp('camara_password', 'Contraseña de la cámara', 'password')}</div>
    <p class="muted small" id="camAyuda">Hikvision: <span class="mono">http://IP/ISAPI/Streaming/channels/101/picture</span> · Dahua: <span class="mono">http://IP/cgi-bin/snapshot.cgi?channel=1</span> · DVR Hikvision canal 2: <span class="mono">…/channels/201/picture</span></p>
    <div class="row"><button type="button" class="btn" id="bCam">📷 Probar cámara</button><span class="muted small" id="camRes"></span></div><div id="camPrev" style="margin-top:.5rem"></div></div>
  <div class="card"><h3>Cortesías y gastos</h3><div class="grid g2">
    <label class="f">Cortesías permitidas sólo para (una por renglón)<textarea name="cortesia_lista" placeholder="Ej.&#10;Sushi&#10;Hotel">${esc((c.cortesia_lista || []).join('\n'))}</textarea><span class="small muted">Si la deja vacía, el cajero escribe libremente para quién es la cortesía. Si escribe nombres, sólo puede elegir de esta lista.</span></label>
    ${modOn('gastos') ? `<label class="f">Tipos de gasto (uno por renglón)<textarea name="gastos_categorias">${esc((c.gastos_categorias || []).join('\n'))}</textarea></label>` : ''}</div></div>
  <div class="card"><h3>Mercado Pago Point (terminal de tarjeta)</h3><div class="grid g2">${inp('mp_access_token', 'Access Token de producción', 'password')}${inp('mp_terminal_id', 'ID de la terminal')}</div>
    <div class="row" style="margin-top:.6rem"><button type="button" class="btn" id="bTerm">Buscar mis terminales</button><span class="muted small">La terminal debe estar en modo <b>PDV</b> (punto de venta integrado).</span></div><div id="terms"></div></div>
  <div class="card"><h3>Pensiones</h3>
    <p class="muted small" style="margin-top:0">Palomee los planes que maneja: sólo esos aparecen al cobrar una pensión. Agregue los tipos de pensión que necesite (carro, camioneta, carro de hotdog…) cada uno con su precio.</p>
    <div class="row" style="gap:.4rem 1rem;margin-bottom:.7rem">${Object.entries(S.me.planes).map(([k, v]) => `<label class="check"><input type="checkbox" data-plan="${k}" ${(c.pension_planes || []).includes(k) ? 'checked' : ''}> ${v}</label>`).join('')}</div>
    <div class="tbl-wrap"><table id="tCat"></table></div>
    <button type="button" class="btn sm" id="addCat" style="margin-top:.5rem">+ Agregar tipo de pensión</button></div>
  <div class="card"><h3>Pantalla del cliente (segundo monitor)</h3><div class="grid g2">${inp('pantalla_bienvenida', 'Mensaje de bienvenida')}${inp('pantalla_gracias', 'Mensaje al terminar de cobrar')}</div>
    <p class="muted small">Conecte un segundo monitor como <b>pantalla extendida</b> y abra el icono "Maxsel Parking - Pantalla cliente" (se abre solo en el segundo monitor). Ahí el cliente ve su entrada, el tiempo, el total a pagar y su cambio.</p>
    <button type="button" class="btn" onclick="window.open('/pantalla','pantallaCliente','width=1024,height=640')">🖥️ Abrir pantalla del cliente</button></div>
  <div class="card"><h3>Monitoreo por internet (portal del dueño)</h3><div id="redInfo">Cargando…</div></div>
  ${can('configuracion') ? `<div class="card"><div class="row" style="justify-content:space-between;align-items:center;gap:.5rem;flex-wrap:wrap"><h3 style="margin:0">Actualizaciones</h3><button type="button" class="btn pri" id="bUpd">⟳ Buscar actualización</button></div>
    <div id="updInfo" class="muted small" style="margin-top:.5rem">${c.upd_disponible ? `Hay una versión nueva: <b>${esc(c.upd_disponible)}</b>. Toque "Buscar actualización".` : 'Necesita internet. La información del estacionamiento (boletos, pensiones, cortes, licencia y respaldos) no se toca al actualizar.'}</div></div>` : ''}
  <div class="card"><h3>Licencia y respaldos</h3><div id="licInfo"></div>
    <div class="row" style="margin-top:.6rem"><button type="button" class="btn" id="bResp">💾 Hacer respaldo ahora</button><span class="muted small">El sistema guarda solo un respaldo diario (los últimos 30) en la carpeta datos\\respaldos.</span></div></div>
  <div class="card" style="position:sticky;bottom:0"><div class="row"><span class="grow muted small">Los cambios aplican de inmediato a todos los cajeros.</span><button class="btn pri big">Guardar configuración</button></div></div>
  </form>`;
  const lic = S.me.licencia;
  $('#licInfo').innerHTML = `<dl class="det" style="max-width:520px"><dt>Sistema</dt><dd>${esc(S.me.producto)} v${esc(S.me.version)}</dd><dt>Licencia</dt><dd>${lic.desarrollo ? 'Modo desarrollo' : lic.activa ? 'Activa' : 'No activa'}</dd>
    <dt>Cliente</dt><dd>${esc(lic.cliente || '—')}</dd><dt>Vence</dt><dd>${lic.expira ? lic.expira.split('-').reverse().join('/') + ` (${lic.diasRestantes} días)` : 'Permanente'}</dd><dt>Código de equipo</dt><dd class="mono">${esc(lic.codigoEquipo)}</dd>
    <dt>Módulos</dt><dd>${Object.entries(NOMBRE_MOD).map(([k, n]) => `${n}: <b>${modOn(k) ? 'incluido' : 'no incluido'}</b>`).join(' · ')}</dd></dl>
    ${lic.desarrollo ? '' : '<button type="button" class="btn sm" id="bRenov" style="margin-top:.5rem">Renovar / cambiar licencia</button>'}`;
  $('#bRenov') && ($('#bRenov').onclick = () => {
    const m = modal(`<div class="hd"><h3>Renovar licencia</h3><button class="btn sm" data-close>✕</button></div><form class="bd grid"><p class="muted" style="margin:0">Código de equipo: <b class="mono">${esc(lic.codigoEquipo)}</b></p><label class="f">Nueva licencia (PK1-…)<textarea name="clave" required></textarea></label></form><div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn pri" id="bAct">Activar</button></div>`);
    $('#bAct', m.el).onclick = async () => { try { const r = await fetch('/api/licencia/activar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ clave: $('[name=clave]', m.el).value }) }); const d = await r.json(); if (!r.ok) throw new Error(d.error); m.close(); toast('Licencia actualizada', 'ok'); ir('config'); } catch (e) { errToast(e); } };
  });
  // 2.7: oculto, igual que Maxsel Tech: 7 toques seguidos en la versión (al final de Configuración) y contraseña de Maxsel
  // 2.7: versión al final de Configuración (7 toques seguidos abren el reinicio, solo Maxsel)
  {
    let toques = [];
    main.insertAdjacentHTML('beforeend', '<div id="verPie" style="text-align:center;color:var(--muted,#8a8f98);font-size:12.5px;margin:26px 0 10px;user-select:none;cursor:default">Maxsel Parking · Maxsel Sistemas de Punto de Venta</div>');
    api('/api/licencia/estado').then((l) => { const v = $('#verPie'); if (v && l.version) v.textContent = 'Maxsel Parking · versión ' + l.version + ' · Maxsel Sistemas de Punto de Venta'; }).catch(() => {});
    $('#verPie').addEventListener('click', () => {
      const t = Date.now(); toques = toques.filter((x) => t - x < 4000); toques.push(t);
      if (toques.length >= 7) { toques = []; if (can('configuracion')) S.abrirReini(); }
    });
  }
  S.abrirReini = () => {
    const m = modal(`<div class="hd"><h3>🔒 Borrar historial y reiniciar · solo Maxsel</h3><button class="btn sm" data-close>✕</button></div>
      <div class="bd grid">
        <p style="margin:0">Seleccione lo que desea borrar:</p>
        <label class="row" style="gap:.6rem;align-items:flex-start;flex-wrap:nowrap"><input type="checkbox" id="rV" style="width:auto;margin-top:.25rem;flex:none"><span style="flex:1"><b>Historial de cobros y ventas</b><br><span class="small muted">Boletos cobrados, cancelados y perdidos, ventas de productos y servicios, cobros de pensiones, turnos, cortes, entradas y salidas de efectivo. Los reportes quedan en ceros y los turnos vuelven a empezar desde el 1. <b>No</b> borra los carros que siguen dentro, ni clientes, pensiones vigentes, tarifas, convenios o usuarios.</span></span></label>
        <label class="row" style="gap:.6rem;align-items:flex-start;flex-wrap:nowrap"><input type="checkbox" id="rP" style="width:auto;margin-top:.25rem;flex:none"><span style="flex:1"><b>Productos</b><br><span class="small muted">Borra todos los productos del catálogo.</span></span></label>
        <label class="row" style="gap:.6rem;align-items:flex-start;flex-wrap:nowrap"><input type="checkbox" id="rS" style="width:auto;margin-top:.25rem;flex:none"><span style="flex:1"><b>Servicios</b><br><span class="small muted">Borra todos los servicios del catálogo (lavado, etc.).</span></span></label>
        <label class="f">Contraseña de Maxsel<input type="password" id="rPass" autocomplete="off" placeholder="Solo la conoce Maxsel"></label>
        <div class="alert bad small" style="margin:0">Esta acción no se puede deshacer desde la caja. Sólo se puede recuperar con el respaldo automático.</div>
      </div>
      <div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn bad" id="rOk" style="background:var(--bad);color:#fff">Borrar</button></div>`);
    $('#rOk', m.el).onclick = async () => {
      const body = { ventas: $('#rV', m.el).checked, productos: $('#rP', m.el).checked, servicios: $('#rS', m.el).checked, password: $('#rPass', m.el).value };
      if (!body.ventas && !body.productos && !body.servicios) return toast('Seleccione qué desea borrar', 'warn');
      if (!body.password) return toast('Escriba la contraseña de Maxsel', 'warn');
      const lista = [body.ventas && 'el historial de cobros y ventas', body.productos && 'los productos', body.servicios && 'los servicios'].filter(Boolean).join(', ');
      if (!(await confirmar(`¿Seguro que desea borrar <b>${lista}</b>?`, { ok: 'Sí, borrar', peligro: true }))) return;
      try {
        const r = await post('/api/reiniciar', body);
        m.close();
        const nombres = { boletos: 'boletos', pagos: 'cobros', pensiones: 'pagos de pensión', movimientos: 'movimientos de efectivo', turnos: 'turnos', productos: 'productos', servicios: 'servicios' };
        toast('Borrado: ' + Object.entries(r.borrados).map(([k, v]) => `${v} ${nombres[k] || k}`).join(', '), 'ok');
        await recargarMe(); ir('config');
      } catch (e) { errToast(e); }
    };
    setTimeout(() => $('#rV', m.el).focus(), 50);
  };
  const cats = JSON.parse(JSON.stringify(c.pension_categorias || []));
  const planesP = () => Object.entries(S.me.planes).filter(([k]) => k !== 'personalizado');
  const pintarCats = () => {
    const act = $$('[data-plan]').filter((x) => x.checked).map((x) => x.dataset.plan);
    $('#tCat').innerHTML = `<thead><tr><th>Tipo de pensión</th>${planesP().map(([k, v]) => `<th class="num" style="${act.includes(k) ? '' : 'opacity:.4'}">${v}</th>`).join('')}<th></th></tr></thead><tbody>${cats.map((ct, i) => `<tr>
      <td><input data-cn="${i}" value="${esc(ct.nombre)}" placeholder="Ej. Camioneta" style="min-width:150px"></td>
      ${planesP().map(([k]) => `<td><input type="number" step="0.01" min="0" data-ci="${i}" data-cp="${k}" value="${ct.precios?.[k] ?? ''}" style="width:95px;${act.includes(k) ? '' : 'opacity:.4'}"></td>`).join('')}
      <td>${cats.length > 1 ? `<button type="button" class="btn sm bad" data-cx="${i}" title="Quitar">✕</button>` : ''}</td></tr>`).join('')}</tbody>`;
    $$('[data-cn]').forEach((x) => (x.oninput = () => { cats[x.dataset.cn].nombre = x.value; }));
    $$('[data-cp]').forEach((x) => (x.oninput = () => { (cats[x.dataset.ci].precios ||= {})[x.dataset.cp] = Number(x.value || 0); }));
    $$('[data-cx]').forEach((x) => (x.onclick = async () => { if (await confirmar(`¿Quitar el tipo de pensión <b>${esc(cats[x.dataset.cx].nombre)}</b>?`, { ok: 'Quitar', peligro: true })) { cats.splice(x.dataset.cx, 1); pintarCats(); } }));
  };
  $$('[data-plan]').forEach((x) => (x.onchange = pintarCats));
  $('#addCat').onclick = () => { cats.push({ id: '', nombre: '', precios: {} }); pintarCats(); $$('[data-cn]').pop()?.focus(); };
  pintarCats();
  const verCam = () => { const t = $('#camTipo').value; $('#camIP').style.display = $('#camAyuda').style.display = t === 'ip' ? '' : 'none'; $('#bCam').style.display = t === 'ninguna' ? 'none' : ''; };
  $('#camTipo').onchange = verCam; verCam();
  $('#bCam').onclick = async () => {
    $('#camRes').textContent = 'Probando…'; $('#camPrev').innerHTML = '';
    try {
      await post('/api/config', datos()); await recargarMe();
      if ($('#camTipo').value === 'usb') {
        await iniciarCamaraUSB(); await new Promise((r) => setTimeout(r, 600));
        const img = capturarUSB();
        if (!img) throw new Error(CAM.error || 'La cámara USB no está lista');
        $('#camRes').textContent = '✅ Cámara USB funcionando'; $('#camPrev').innerHTML = `<img src="${img}" style="max-width:420px;width:100%;border-radius:10px">`;
      } else {
        const r = await post('/api/prueba/camara');
        if (!r.ok) throw new Error(r.error);
        $('#camRes').textContent = '✅ Cámara IP funcionando'; $('#camPrev').innerHTML = `<img src="${r.imagen}" style="max-width:420px;width:100%;border-radius:10px">`;
      }
    } catch (e) { $('#camRes').textContent = '❌ ' + e.message; }
  };
  // 2.6: actualizar el sistema por internet (igual que Maxsel POS)
  if ($('#bUpd')) $('#bUpd').onclick = async () => {
    const box = $('#updInfo'); box.textContent = 'Buscando…';
    try {
      const v = await api('/api/actualizacion');
      box.innerHTML = v.hay
        ? `<div class="alert ok" style="margin:0"><b>Hay una versión nueva: ${esc(v.disponible)}</b> (tiene la ${esc(v.instalada)}).${v.notas ? `<br>${esc(v.notas)}` : ''}
           <div style="margin-top:.6rem"><button type="button" class="btn pri" id="bUpdOk">Instalar ahora</button></div>
           <div class="small" style="margin-top:.4rem">Tarda menos de un minuto. El sistema se reinicia solo; los demás usuarios deben volver a entrar.</div></div>`
        : `Ya tiene la versión más reciente (<b>${esc(v.instalada)}</b>).`;
      const b = $('#bUpdOk');
      if (b) b.onclick = async () => {
        b.disabled = true; b.textContent = 'Descargando e instalando…';
        try {
          const r = await post('/api/actualizacion/instalar');
          modal(`<div class="hd"><h3>Sistema actualizado</h3></div><div class="bd"><p>Se instaló la versión <b>${esc(r.a)}</b> (antes ${esc(r.de)}).</p>
            <p>${r.servicio ? 'El sistema se está reiniciando. En unos segundos toque "Volver a entrar".' : 'Cierre el sistema y vuelva a abrirlo.'}</p>
            <button class="btn pri" onclick="location.reload()">Volver a entrar</button></div>`);
        } catch (e) { b.disabled = false; b.textContent = 'Instalar ahora'; errToast(e); }
      };
    } catch (e) { box.innerHTML = `<span style="color:var(--bad)">${esc(e.message)}</span>`; }
  };
  $('#bResp').onclick = async () => { try { const r = await post('/api/respaldo'); toast('Respaldo creado: ' + r.archivo, 'ok'); } catch (e) { errToast(e); } };
  if (typeof funnelUI === 'function') funnelUI(); else api('/api/red').then((r) => {
    $('#redInfo').innerHTML = `<p style="margin-top:0">Desde otras computadoras o celulares de este negocio entre a:</p>
      <ul>${r.ips.map((i) => `<li><b class="mono">${i.url}</b> ${i.tailscale ? '<span class="chip ok">Tailscale (remoto)</span>' : '<span class="chip">red local</span>'} · portal: <span class="mono">${i.url}/portal</span></li>`).join('')}</ul>
      ${r.tailscale ? `<div class="alert ok">Acceso remoto listo. Desde cualquier lugar (con Tailscale abierto en su celular o PC) entre a <b class="mono">${r.tailscale.url}/portal</b> para ver reportes, productos, servicios y cajeros.</div>`
        : `<div class="alert">Para ver reportes desde fuera del negocio: instale <b>Tailscale</b> (gratis) en esta computadora y en su celular, entre con la misma cuenta y abra <span class="mono">http://IP-de-Tailscale:${r.puerto}/portal</span>. La IP de Tailscale aparecerá aquí.</div>`}`;
  }).catch(() => { $('#redInfo').textContent = ''; });
  const f = $('#fCfg');
  api('/api/impresoras').then((r) => {
    const sel = $('#selImp'); if (!sel) return;
    const actual = c.impresora_tipo === 'ninguna' ? '' : c.impresora_nombre;
    const lista = r.impresoras.slice();
    if (actual && c.impresora_tipo !== 'ip' && !lista.includes(actual)) lista.unshift(actual);
    sel.innerHTML = '<option value="">Sin impresora (solo vista previa)</option>' + lista.map((n) => `<option ${n === actual && c.impresora_tipo !== 'ip' ? 'selected' : ''}>${esc(n)}</option>`).join('')
      + (c.impresora_tipo === 'ip' ? `<option value="__ip__" selected>Impresora de red ${esc(c.impresora_ip)} (configuración anterior)</option>` : '');
    if (r.aviso) $('#impAviso').textContent = r.aviso;
    else if (!r.impresoras.length) $('#impAviso').textContent = 'No se encontraron impresoras instaladas en Windows.';
    sel.onchange = () => {
      if (sel.value === '__ip__') return;
      f.impresora_tipo.value = sel.value ? 'windows' : 'ninguna';
      f.impresora_nombre.value = sel.value;
      // 2.5.2: elige las letras por renglón según la marca de la impresora
      const n = sel.value.toUpperCase(), sc = $('#selCols');
      const v = /58|PT-?210|GOOJPRT|MTP/.test(n) ? 32 : /EPSON|TM-?T|TM-?M|BIXOLON|SRP|STAR|TSP|CITIZEN|CT-S/.test(n) ? 42 : /XPRINTER|XP-|3NSTAR|RPT|EC-?LINE|EC-?PM|GHIA|NEXTEP|POS-?80|80MM|THERMAL|RECEIPT|HPRT|ZJ-/.test(n) ? 48 : 0;
      if (v && sc) { sc.value = String(v); toast('Letras por renglón según la impresora: ' + v, 'ok'); }
    };
  }).catch(() => {});
  const datos = () => {
    const d = formData(f);
    d.pension_planes = $$('[data-plan]').filter((x) => x.checked).map((x) => x.dataset.plan);
    if (!d.pension_planes.length) throw new Error('Habilite al menos un plan de pensión');
    d.pension_categorias = cats.filter((x) => String(x.nombre || '').trim());
    if (!d.pension_categorias.length) throw new Error('Agregue al menos un tipo de pensión');
    for (const k of ['capacidad', 'tipo_cambio_default', 'costo_boleto_perdido', 'impresora_columnas', 'relay_pulso_ms']) d[k] = Number(d[k] || 0);
    return d;
  };
  f.onsubmit = async (e) => { e.preventDefault(); try { await post('/api/config', datos()); await recargarMe(); await refrescarEstado(); toast('Configuración guardada', 'ok'); } catch (err) { errToast(err); } };
  $$('[data-p]').forEach((b) => (b.onclick = async () => {
    try {
      await post('/api/config', datos());
      const r = await post('/api/prueba/' + b.dataset.p);
      if (b.dataset.p === 'pluma') return r.ok ? toast(r.simulado ? 'Relevador no configurado' : 'Señal enviada a la pluma', r.simulado ? 'warn' : 'ok') : toast(r.error, 'bad');
      manejarImpresion(r, 'Prueba'); if (r.simulado || !r.ok) verTicket(r);
    } catch (e) { errToast(e); }
  }));
  $('#bTerm').onclick = async () => {
    try {
      await post('/api/config', datos());
      const t = await api('/api/mp/terminales');
      $('#terms').innerHTML = t.length ? `<table style="margin-top:.6rem"><thead><tr><th>ID</th><th>Modo</th><th></th></tr></thead><tbody>${t.map((x) => `<tr><td class="mono">${esc(x.id)}</td><td>${esc(x.operating_mode)}</td><td><button type="button" class="btn sm" data-t="${esc(x.id)}">Usar</button></td></tr>`).join('')}</tbody></table>` : '<p class="muted">No se encontraron terminales en la cuenta.</p>';
      $$('[data-t]').forEach((b) => (b.onclick = () => { f.mp_terminal_id.value = b.dataset.t; toast('Terminal seleccionada. Guarde la configuración.', 'ok'); }));
    } catch (e) { errToast(e); }
  };
}

/* ================= USUARIOS ================= */
async function vistaUsuarios(main) {
  const lista = await api('/api/usuarios');
  const ROL = { admin: 'Administrador', supervisor: 'Supervisor / gerente', cajero: 'Cajero' };
  main.innerHTML = `<div class="card"><div class="row"><h2 class="grow">Usuarios y permisos</h2><button class="btn acc" id="nU">+ Nuevo usuario</button></div>
    ${tabla(lista, [{ t: 'Nombre', h: (x) => `<b>${esc(x.nombre)}</b>` }, { t: 'Usuario', k: 'usuario' }, { t: 'Rol', f: (x) => ROL[x.rol] }, { t: 'Permisos', f: (x) => (x.rol === 'admin' ? 'Todos' : x.permisos.length + ' de ' + Object.keys(S.me.catalogoPermisos).length) },
      { t: 'Estado', h: (x) => (x.activo ? '<span class="chip ok">activo</span>' : '<span class="chip">inactivo</span>') }, { t: '', h: (x) => `<button class="btn sm" data-e="${x.id}">Editar</button>` }])}</div>`;
  const editar = (u) => {
    const cat = S.me.catalogoPermisos;
    const m = modal(`<div class="hd"><h3>${u.id ? 'Editar' : 'Nuevo'} usuario</h3><button class="btn sm" data-close>✕</button></div>
      <form class="bd grid"><div class="grid g2">
        <label class="f">Nombre<input name="nombre" value="${esc(u.nombre || '')}" required autofocus></label>
        <label class="f">Usuario (para entrar)<input name="usuario" value="${esc(u.usuario || '')}" required></label>
        <label class="f">Rol<select name="rol">${Object.entries(ROL).filter(([k]) => k !== 'admin' || S.me.usuario.rol === 'admin').map(([k, v]) => `<option value="${k}" ${u.rol === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
        <label class="f">${u.id ? 'Nueva contraseña (dejar vacío para no cambiar)' : 'Contraseña'}<input name="password" type="password" autocomplete="new-password"></label></div>
        <label class="check"><input type="checkbox" name="activo" ${u.activo === 0 ? '' : 'checked'}> Usuario activo</label>
        <div id="pBox"><div class="row"><h4 class="grow" style="margin:0">¿Qué puede hacer?</h4><button type="button" class="btn sm" id="pl">Aplicar permisos típicos del rol</button></div>
        <div class="perms" style="margin-top:.5rem">${Object.entries(cat).map(([k, v]) => `<label class="check"><input type="checkbox" data-group="permisos" name="${k}" ${(u.permisos || []).includes(k) ? 'checked' : ''}> ${v}</label>`).join('')}</div></div>
        <p class="muted small hidden" id="pAdm">El administrador tiene todos los permisos.</p>
      </form><div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn pri" id="g">Guardar</button></div>`, { cls: 'wide' });
    const f = $('form', m.el);
    const upd = () => { const a = f.rol.value === 'admin'; $('#pBox', m.el).classList.toggle('hidden', a); $('#pAdm', m.el).classList.toggle('hidden', !a); };
    f.rol.onchange = upd; upd();
    $('#pl', m.el).onclick = () => { const p = S.me.permisosRol[f.rol.value] || []; $$('[data-group=permisos]', f).forEach((c) => (c.checked = p.includes(c.name))); };
    if (!u.id) $('#pl', m.el).click();
    $('#g', m.el).onclick = async () => { try { await post('/api/usuarios', { ...formData(f), id: u.id }); m.close(); ir('usuarios'); toast('Usuario guardado', 'ok'); } catch (e) { errToast(e); } };
  };
  $('#nU').onclick = () => editar({ rol: 'cajero' });
  $$('[data-e]').forEach((b) => (b.onclick = () => editar(lista.find((x) => x.id == b.dataset.e))));
}

/* ================= BITÁCORA y CUENTA ================= */
async function vistaBitacora(main) {
  const l = await api('/api/bitacora');
  main.innerHTML = `<div class="card"><div class="row"><h2 class="grow">Bitácora (últimos 7 días)</h2><button class="btn sm" id="xb">⬇️ CSV</button></div>
    ${tabla(l, [{ t: 'Fecha', f: (x) => fdt(x.fecha) }, { t: 'Usuario', k: 'usuario' }, { t: 'Acción', h: (x) => `<span class="chip">${esc(x.accion)}</span>` }, { t: 'Detalle', k: 'detalle' }])}</div>`;
  $('#xb').onclick = () => csv('bitacora', l, [[(x) => fdt(x.fecha), 'Fecha'], ['usuario', 'Usuario'], ['accion', 'Acción'], ['detalle', 'Detalle']]);
}
function vistaCuenta(main) {
  main.innerHTML = `<div class="card" style="max-width:460px"><h2>Cambiar mi contraseña</h2><form class="grid" id="fP">
    <label class="f">Contraseña actual<input type="password" name="actual" required></label><label class="f">Nueva contraseña<input type="password" name="nueva" required minlength="4"></label>
    <button class="btn pri">Guardar</button></form></div>`;
  $('#fP').onsubmit = async (e) => { e.preventDefault(); try { await post('/api/cambiar-password', formData(e.target)); e.target.reset(); toast('Contraseña actualizada', 'ok'); } catch (err) { errToast(err); } };
}

iniciar();
