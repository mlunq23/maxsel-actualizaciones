'use strict';
/* Maxsel Parking 2.7 — igual que Maxsel Tech y Maxsel Abarrotes:
 *  · "¿Olvidó su contraseña?" en la pantalla de entrada
 *  · Monitoreo por internet solo con Tailscale Funnel, en pocos pasos y con código QR
 *  (el reinicio oculto con la contraseña de Maxsel está en app.js, al final de Configuración) */

/* ---------- Recuperar contraseña ---------- */
(() => {
  const f = $('#loginForm'); if (!f || $('#lgOlv')) return;
  f.insertAdjacentHTML('beforeend', '<div style="text-align:center;margin-top:.8rem"><a href="#" id="lgOlv" class="small">¿Olvidó su contraseña?</a></div>');
  $('#lgOlv').onclick = (e) => { e.preventDefault(); recuperarVer(); };
})();
function recuperarVer() {
  const u0 = ($('#loginForm [name=usuario]')?.value || '').trim();
  const m = modal(`<div class="hd"><h3>Recuperar contraseña</h3><button class="btn sm" data-close>✕</button></div>
    <form class="bd grid"><div class="alert" style="margin:0">Un <b>administrador</b> puede ponerle contraseña nueva a cualquier usuario. Si nadie recuerda la del administrador, llame a <b>Maxsel</b> (WhatsApp 664 337 5433) para que lo haga con su clave.</div>
      <label class="f">Usuario que olvidó su contraseña<input name="usuario" autocomplete="off" autocapitalize="off" value="${esc(u0)}"></label>
      <label class="f">Contraseña de un administrador (o clave de Maxsel)<input name="autoriza" type="password" autocomplete="off"></label>
      <label class="f">Contraseña nueva<input name="n1" type="password" autocomplete="new-password"></label>
      <label class="f">Repita la contraseña nueva<input name="n2" type="password" autocomplete="new-password"></label>
      <div id="rcErr" class="alert bad hidden"></div></form>
    <div class="ft"><button class="btn" data-close>Cancelar</button><button class="btn pri" id="rcOk">Cambiar contraseña</button></div>`);
  const err = (t) => { const e = $('#rcErr', m.el); e.textContent = t; e.classList.remove('hidden'); };
  const ok = async (ev) => {
    ev && ev.preventDefault();
    const v = (n) => $(`[name=${n}]`, m.el).value;
    if (!v('usuario').trim()) return err('Escriba el usuario');
    if (v('n1').length < 4) return err('La contraseña nueva debe tener al menos 4 caracteres');
    if (v('n1') !== v('n2')) return err('Las contraseñas nuevas no coinciden');
    const b = $('#rcOk', m.el); b.disabled = true;
    try {
      const r = await post('/api/recuperar-contrasena', { usuario: v('usuario'), autoriza: v('autoriza'), nueva: v('n1') });
      m.close(); $('#loginForm [name=usuario]').value = r.usuario; $('#loginForm [name=password]').focus();
      toast('Listo. Entre con la contraseña nueva de ' + r.usuario, 'ok');
    } catch (e) { b.disabled = false; $('[name=autoriza]', m.el).value = ''; err(e.message); }
  };
  $('#rcOk', m.el).onclick = ok; $('form', m.el).onsubmit = ok;
  setTimeout(() => $(u0 ? '[name=autoriza]' : '[name=usuario]', m.el).focus(), 50);
}

/* ---------- Monitoreo por internet (Tailscale Funnel) ---------- */
async function funnelUI(msg) {
  const box = $('#redInfo'); if (!box) return;
  const adm = S.me?.usuario?.rol === 'admin';
  box.innerHTML = '<span class="muted">Revisando Tailscale…</span>';
  let e, red = { ips: [] };
  try { e = await api('/api/funnel'); } catch (er) { e = { error: er.message }; }
  try { red = await api('/api/red'); } catch { /* nada */ }
  if (!$('#redInfo')) return;
  const loc = (red.ips || []).filter((i) => !i.tailscale);
  const portal = e.url ? e.url + 'portal' : '';
  const paso = (n, ok, tit, cuerpo) => `<div style="display:flex;gap:.9rem;align-items:flex-start;padding:.75rem 0;border-top:1px solid var(--line,#e5e7eb)">
      <div style="flex:none;width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;${ok ? 'background:#1a9150;color:#fff' : 'background:#fbe9dd;color:#cd6628'}">${ok ? '✓' : n}</div>
      <div style="flex:1;min-width:0"><b>${tit}</b><div style="margin-top:.25rem">${cuerpo}</div></div></div>`;
  box.innerHTML = `${msg ? `<div class="alert ${msg.bad ? 'bad' : 'ok'}" style="margin-bottom:.6rem">${msg.t}</div>` : ''}
    <p style="margin-top:0">Con <b>Tailscale Funnel</b> el dueño abre una dirección segura (https) en el navegador del celular, <b>sin instalar nada en el teléfono</b> y sin abrir puertos en el módem. Entra al <b>portal</b>: reportes, cortes, productos y cajeros. Cobrar, abrir la pluma o cambiar la configuración solo se hace aquí en la caja.</p>
    ${e.activo && portal ? `<div class="alert ok" style="margin:.4rem 0 .7rem"><b>Listo: el acceso por internet está encendido.</b> Entre con un usuario <b>Administrador</b> o <b>Supervisor</b>.</div>
      <div style="display:flex;gap:1.1rem;align-items:center;flex-wrap:wrap">
        <div style="flex:none;border:1px solid var(--line,#e5e7eb);border-radius:12px;padding:6px;background:#fff;line-height:0">${typeof qrSVG === 'function' ? qrSVG(portal, 5, 2) : ''}</div>
        <div style="flex:1;min-width:240px"><b>Escanee el código con la cámara del celular</b>
          <div class="mono" style="font-size:1.05rem;background:#f3f5f8;border-radius:10px;padding:.7rem;margin-top:.4rem;word-break:break-all">${esc(portal)}</div>
          <div class="row" style="gap:.5rem;margin-top:.6rem;flex-wrap:wrap"><button type="button" class="btn pri" id="fCp">Copiar dirección</button>
            <a class="btn" href="https://wa.me/?text=${encodeURIComponent('Portal del estacionamiento: ' + portal)}" target="_blank" rel="noopener">Mandar por WhatsApp</a>
            ${adm ? '<button type="button" class="btn bad" id="fOff">Apagar acceso por internet</button>' : ''}</div></div></div>
      <p class="muted small">En el celular: ábrala en Chrome o Safari y agréguela a la pantalla de inicio para usarla como app.</p>` : ''}
    ${e.error ? `<div class="alert bad">${esc(e.error)}</div>` : `
    ${paso(1, e.instalado, 'Instalar Tailscale en esta computadora', e.instalado ? 'Ya está instalado.' : 'Es gratis. Descárguelo, instálelo con “Siguiente” y regrese aquí.<div style="margin-top:.5rem"><a class="btn pri" href="https://tailscale.com/download/windows" target="_blank" rel="noopener">Descargar Tailscale</a> <button type="button" class="btn" data-f="re">Ya lo instalé</button></div>')}
    ${paso(2, e.conectado, 'Iniciar sesión en Tailscale', e.conectado ? `Conectado como <b class="mono">${esc(e.nombre)}</b>.` : (e.instalado ? `Use una cuenta de Google o Microsoft del negocio (siempre la misma).<div style="margin-top:.5rem">${adm ? '<button type="button" class="btn pri" data-f="ses">Iniciar sesión</button> ' : ''}<button type="button" class="btn" data-f="re">Ya inicié sesión</button></div>` : 'Primero haga el paso 1.'))}
    ${paso(3, e.activo, 'Encender el acceso por internet', e.activo ? 'Encendido.' : (e.conectado ? (adm ? 'Un solo botón. La primera vez Tailscale le pide permitir “Funnel” en su cuenta: se abre una página, toque <b>Enable</b> y vuelva a tocar este botón.<div style="margin-top:.5rem"><button type="button" class="btn ok" data-f="on">Encender acceso por internet</button></div>' : 'Pídale al administrador que lo encienda.') : 'Primero haga los pasos anteriores.'))}`}
    <div style="border-top:1px solid var(--line,#e5e7eb);margin-top:.4rem;padding-top:.7rem"><b>En el WiFi del negocio</b> (otras cajas, pantalla y celulares conectados al mismo módem):
      <ul style="margin:.4rem 0 0">${loc.map((i) => `<li><b class="mono">${esc(i.url)}</b> · portal: <span class="mono">${esc(i.url)}/portal</span></li>`).join('') || '<li class="muted">Sin red local.</li>'}</ul></div>`;
  $$('[data-f=re]', box).forEach((b) => (b.onclick = () => funnelUI()));
  const ses = $('[data-f=ses]', box); if (ses) ses.onclick = async () => {
    ses.disabled = true; ses.textContent = 'Abriendo…';
    try {
      const r = await post('/api/funnel', { sesion: true });
      if (r.enlace) { window.open(r.enlace, '_blank'); return funnelUI({ t: `Se abrió la página de Tailscale. Inicie sesión y luego toque “Ya inicié sesión”. <a href="${esc(r.enlace)}" target="_blank" rel="noopener">Abrir otra vez</a>` }); }
      funnelUI(r.error ? { t: esc(r.error), bad: true } : undefined);
    } catch (er) { funnelUI({ t: esc(er.message), bad: true }); }
  };
  const cambiar = async (activar, b) => {
    b.disabled = true; b.textContent = activar ? 'Encendiendo… (hasta 30 segundos)' : 'Apagando…';
    try {
      const r = await post('/api/funnel', { activar });
      if (r.habilitar) { window.open(r.habilitar, '_blank'); return funnelUI({ t: `Tailscale pide permitir <b>Funnel</b> en su cuenta (solo la primera vez). Se abrió la página: toque <b>Enable</b> y vuelva a tocar “Encender acceso por internet”. <a href="${esc(r.habilitar)}" target="_blank" rel="noopener">Abrir otra vez</a>` }); }
      funnelUI({ t: activar ? 'Acceso por internet encendido.' : 'Acceso por internet apagado.' });
    } catch (er) { funnelUI({ t: esc(er.message), bad: true }); }
  };
  const on = $('[data-f=on]', box); if (on) on.onclick = () => cambiar(true, on);
  const off = $('#fOff', box); if (off) off.onclick = () => cambiar(false, off);
  const cp = $('#fCp', box); if (cp) cp.onclick = () => { if (navigator.clipboard) navigator.clipboard.writeText(portal).then(() => toast('Dirección copiada', 'ok'), () => prompt('Copie la dirección:', portal)); else prompt('Copie la dirección:', portal); };
}
