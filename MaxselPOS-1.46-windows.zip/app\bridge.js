// Maxsel POS para Windows - conecta la ventana de la caja con el servidor local
// (impresoras, copia de los datos en disco y atención a comanderos y monitor).
(function () {
  'use strict';
  var KEY = 'maxselpos_v1';
  function sx(method, url, body) {
    var x = new XMLHttpRequest();
    try { x.open(method, url, false); x.send(body || null); } catch (e) { return null; }
    return x.status === 200 ? x.responseText : null;
  }
  function msg(t) { try { toast(t); } catch (e) { } }

  // Si el navegador perdió los datos, se recuperan de la copia en disco (C:\MaxselPOS\datos)
  // (con muchos datos ya no caben en localStorage: se le pasan a la app y ella los guarda en IndexedDB)
  try { if (!localStorage.getItem(KEY) && !localStorage.getItem(KEY + '_big')) { var d = sx('GET', '/bridge/db'); if (d) { window.MAXSEL_DISKDB = d; try { localStorage.setItem(KEY, d); } catch (e2) { } } } } catch (e) { }

  window.AndroidBridge = {
    startServer: function () { return 'ok'; },
    getIps: function () { return sx('GET', '/bridge/ips') || ''; },
    deviceName: function () { return 'Caja Windows'; },
    setDisplay: function (json) { try { fetch('/bridge/display', { method: 'POST', body: json }).catch(function () { }); } catch (e) { } },
    deviceId: function () { return sx('GET', '/bridge/deviceid') || ''; },
    listPrinters: function () { try { return JSON.parse(sx('GET', '/bridge/printers') || '[]'); } catch (e) { return []; } },
    // impresora instalada en Windows (USB): se le mandan los datos directo (RAW)
    usbPrint: function (b64) {
      var pr = '';
      try { pr = DB.settings.winPrinter || ''; } catch (e) { }
      if (!pr) return 'Elige la impresora de tickets en Ajustes';
      var r = sx('POST', '/bridge/raw', JSON.stringify({ printer: pr, b64: b64 }));
      return r === null ? 'El servidor no respondió' : r;
    },
    // otra impresora instalada en Windows (comandas de cocina/barra por USB)
    winPrint: function (pr, b64) {
      if (!pr) return 'Elige la impresora de Windows';
      var r = sx('POST', '/bridge/raw', JSON.stringify({ printer: pr, b64: b64 }));
      return r === null ? 'El servidor no respondió' : r;
    },
    // API de Mercado Pago (terminal Point): el servidor local hace la petición HTTPS
    mpHttp: function (id, method, path, body, headers) {
      fetch('/bridge/mp', { method: 'POST', body: JSON.stringify({ method: method, path: path, body: body, headers: JSON.parse(headers || '{}') }) })
        .then(function (r) { return r.json(); })
        .then(function (j) { window.mpCb && window.mpCb(id, j.s || 0, j.t || ''); })
        .catch(function () { window.mpCb && window.mpCb(id, 0, ''); });
    },
    netPrint: function (ip, port, b64, name) {
      fetch('/bridge/net', { method: 'POST', body: JSON.stringify({ ip: ip, port: port, b64: b64, name: name }) })
        .then(function (r) { return r.text(); })
        .then(function (t) { if (t !== 'ok') msg('No se pudo imprimir en ' + name + ' (' + ip + '). ' + t); })
        .catch(function () { msg('No se pudo imprimir en ' + name); });
    }
  };

  // Copia de seguridad en disco cada vez que se guarda algo
  var timer = null;
  function flush() { try { var t = window.MAXSEL_DBTEXT || localStorage.getItem(KEY); if (t) fetch('/bridge/db', { method: 'POST', body: t, keepalive: t.length < 60000 }).catch(function () { setTimeout(flush, 3000); }); } catch (e) { } }
  window.addEventListener('load', function () {
    var orig = window.save;
    if (typeof orig === 'function') window.save = function () { var r = orig.apply(this, arguments); clearTimeout(timer); timer = setTimeout(flush, 800); return r; };
    flush();
    pump();
  });
  window.addEventListener('beforeunload', flush);

  // Atiende las peticiones de comanderos, portal de meseros y monitor
  function pump() {
    fetch('/bridge/next').then(function (r) {
      if (r.status !== 200) return null;
      return r.json();
    }).then(function (j) {
      if (j) {
        var out;
        try { out = window.apiHandle(j.method, j.path, j.query, j.body, j.token); } catch (e) { out = JSON.stringify({ s: 500, b: { error: String(e && e.message || e) } }); }
        fetch('/bridge/reply?id=' + j.id, { method: 'POST', body: out });
      }
      pump();
    }).catch(function () { setTimeout(pump, 2000); });
  }
})();
