// Maxsel POS para Windows - servidor local.
// Sirve la caja (solo en esta computadora), el portal de meseros y el monitor de ventas.
// Los datos los maneja la ventana de la caja; este servidor le pasa las peticiones de
// comanderos y del monitor, guarda copia de los datos en disco e imprime.
'use strict';
const http = require('http'), fs = require('fs'), path = require('path'), os = require('os'), net = require('net');
const https = require('https');
// API de Mercado Pago (terminal Point). MAXSEL_MP_BASE solo se usa para pruebas.
const MP_BASE = process.env.MAXSEL_MP_BASE || 'https://api.mercadopago.com';
function mpRequest(method, p, body, headers) {
  return new Promise(resolve => {
    if (!/^\/[A-Za-z0-9_\-\/.?=&%]*$/.test(p) || p.includes('..')) return resolve({ s: 0, t: '' });
    const u = new URL(MP_BASE + p), mod = u.protocol === 'https:' ? https : http;
    const h = Object.assign({}, headers || {});
    const data = body ? Buffer.from(body, 'utf8') : null;
    if (data) h['Content-Length'] = data.length;
    const rq = mod.request(u, { method, headers: h, timeout: 25000 }, rs => {
      const ch = []; rs.on('data', c => ch.push(c)); rs.on('end', () => resolve({ s: rs.statusCode, t: Buffer.concat(ch).toString('utf8') }));
    });
    rq.on('timeout', () => rq.destroy(new Error('timeout')));
    rq.on('error', e => { log('mercado pago', method, p, e.message); resolve({ s: 0, t: '' }); });
    if (data) rq.write(data);
    rq.end();
  });
}
const { execFile } = require('child_process');

const ROOT = __dirname;                       // C:\MaxselPOS\app
const WEB = path.join(ROOT, 'web');
const DATA = path.join(ROOT, '..', 'datos');  // C:\MaxselPOS\datos (no se borra al actualizar)
const BACK = path.join(DATA, 'respaldos');
const DBFILE = path.join(DATA, 'maxselpos.json');
const PORT = +process.env.MAXSEL_PORT || 8080;
fs.mkdirSync(BACK, { recursive: true });

const log = (...a) => { try { fs.appendFileSync(path.join(DATA, 'registro.log'), new Date().toISOString() + ' ' + a.join(' ') + '\n'); } catch (e) { } };
const isLocal = req => ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress);
const send = (res, st, type, body, extra) => { res.writeHead(st, Object.assign({ 'Content-Type': type, 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type, X-Token' }, extra || {})); res.end(body); };
const json = (res, st, obj) => send(res, st, 'application/json; charset=utf-8', JSON.stringify(obj));

// ---------- relevo: peticiones de comanderos/monitor -> ventana de la caja ----------
let seq = 0, queue = [], waiters = [], lastPoll = 0;
let DISP = { v: 1, s: { stage: 'idle' } };
const dispWaiters = new Set();
const pending = new Map();
function relay(job) {
  return new Promise(resolve => {
    if (Date.now() - lastPoll > 40000) return resolve({ s: 503, b: { error: 'La caja no está abierta. Abre "Maxsel POS" en la computadora de la caja.' } });
    const id = ++seq;
    const timer = setTimeout(() => { pending.delete(id); resolve({ s: 503, b: { error: 'La caja no respondió' } }); }, 15000);
    pending.set(id, { resolve, timer });
    const j = Object.assign({ id }, job);
    const w = waiters.shift();
    if (w) w(j); else queue.push(j);
  });
}
function nextJob(req, res) {
  lastPoll = Date.now();
  const j = queue.shift();
  if (j) return json(res, 200, j);
  let done = false;
  const w = job => { if (done) { queue.unshift(job); return; } done = true; clearTimeout(t); lastPoll = Date.now(); json(res, 200, job); };
  const t = setTimeout(() => { if (done) return; done = true; waiters = waiters.filter(x => x !== w); lastPoll = Date.now(); send(res, 204, 'text/plain', ''); }, 25000);
  req.on('close', () => { if (!done) { done = true; clearTimeout(t); waiters = waiters.filter(x => x !== w); } });
  waiters.push(w);
}

// ---------- utilidades ----------
function readBody(req, max) {
  return new Promise((resolve, reject) => {
    const parts = []; let n = 0;
    req.on('data', c => { n += c.length; if (n > max) { reject(new Error('muy grande')); req.destroy(); } else parts.push(c); });
    req.on('end', () => resolve(Buffer.concat(parts).toString('utf8')));
    req.on('error', reject);
  });
}
function ips() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) for (const a of list || []) if (a.family === 'IPv4' && !a.internal) out.push(a.address);
  return out.join(',');
}
// identificador de la computadora para la licencia (MachineGuid de Windows)
let MID = '';
function machineId() {
  if (MID) return MID;
  try {
    const out = require('child_process').execFileSync('reg', ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'], { encoding: 'utf8', windowsHide: true });
    const m = /MachineGuid\s+REG_SZ\s+([\w-]+)/i.exec(out); if (m) MID = 'windows:' + m[1].toLowerCase();
  } catch (e) { }
  if (!MID) MID = 'host:' + os.hostname() + ':' + (Object.values(os.networkInterfaces()).flat().find(a => a && a.mac && a.mac !== '00:00:00:00:00:00') || {}).mac;
  return MID;
}
function saveDb(text) {
  JSON.parse(text); // valida antes de guardar
  const tmp = DBFILE + '.tmp';
  fs.writeFileSync(tmp, text);
  fs.renameSync(tmp, DBFILE);
  // un respaldo por día, se guardan los últimos 60
  const n = new Date(), day = n.getFullYear() + '-' + String(n.getMonth() + 1).padStart(2, '0') + '-' + String(n.getDate()).padStart(2, '0'), bf = path.join(BACK, 'maxselpos_' + day + '.json');
  if (!fs.existsSync(bf)) {
    fs.copyFileSync(DBFILE, bf);
    const old = fs.readdirSync(BACK).filter(f => f.startsWith('maxselpos_')).sort();
    while (old.length > 60) { try { fs.unlinkSync(path.join(BACK, old.shift())); } catch (e) { } }
  }
}
function netPrint(ip, port, buf) {
  return new Promise(resolve => {
    const s = net.connect({ host: ip, port: port || 9100 });
    let ok = false;
    s.setTimeout(5000, () => { s.destroy(); resolve('Sin respuesta de ' + ip); });
    s.on('connect', () => s.end(buf, () => { ok = true; }));
    s.on('close', () => resolve(ok ? 'ok' : 'No se pudo conectar con ' + ip));
    s.on('error', () => { });
  });
}
const BASC = path.join(ROOT, 'bascula.exe');
// báscula por puerto COM (solo Windows): lee con bascula.exe; una lectura a la vez
let SCALE_Q = Promise.resolve();
function scaleRun(args, ms) {
  const run = () => new Promise(resolve => {
    if (!fs.existsSync(BASC)) return resolve('err Falta bascula.exe; reinstala Maxsel POS|');
    execFile(BASC, args, { timeout: ms, windowsHide: true, encoding: 'utf8' }, (err, out) => resolve(String(out || '').trim() || ('err ' + ((err && err.message) || 'Sin respuesta') + '|')));
  });
  const p = SCALE_Q.then(run, run); SCALE_Q = p.catch(() => { }); return p;
}
function scaleParse(t) {
  const [head, ...rest] = String(t).split('|');
  if (head.startsWith('ok ')) return { ok: true, kg: +head.slice(3), baud: +rest[0] || 0, cmd: rest[1] || '', raw: rest.slice(2).join('|') };
  return { ok: false, error: head.replace(/^err\s*/, '') || 'Error', raw: rest.join('|') };
}
// ---------- actualizaciones por internet ----------
// Baja version.json de github.com/mlunq23/maxsel-actualizaciones (público, solo actualizaciones); el paquete .zip trae MaxselPOS.exe y la carpeta app (sin node.exe).
// La instalación la hace datos\actualizacion\actualizar.js con node (desde 1.31; antes PowerShell, que no arrancaba).
const UPD_KIND = 'pos', UPD_BASE = 'https://raw.githubusercontent.com/mlunq23/maxsel-actualizaciones/main/';
const UPD_DIR = path.join(DATA, 'actualizacion'), UPD_EST = path.join(UPD_DIR, 'estado.json');
function httpsGet(url, max, redirs) {
  return new Promise((resolve, reject) => {
    if (!/^https:\/\/raw\.githubusercontent\.com\/mlunq23\/maxsel-actualizaciones\//.test(url)) return reject(new Error('Dirección no permitida'));
    https.get(url, { timeout: 30000, headers: { 'Cache-Control': 'no-cache', 'User-Agent': 'MaxselPOS' } }, rs => {
      if ([301, 302, 303, 307, 308].includes(rs.statusCode) && rs.headers.location && (redirs || 0) < 4) { rs.resume(); return resolve(httpsGet(new URL(rs.headers.location, url).href, max, (redirs || 0) + 1)); }
      if (rs.statusCode !== 200) { rs.resume(); return reject(new Error('El servidor de Maxsel respondió ' + rs.statusCode)); }
      const ch = []; let n = 0;
      rs.on('data', c => { n += c.length; if (n > max) { rs.destroy(); reject(new Error('Archivo demasiado grande')); } else ch.push(c); });
      rs.on('end', () => resolve(Buffer.concat(ch)));
      rs.on('error', reject);
    }).on('timeout', function () { this.destroy(new Error('Sin respuesta (revisa el internet)')); }).on('error', e => reject(new Error(/ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ENETUNREACH/.test(e.code || '') ? 'Sin internet. Conéctate a internet e intenta de nuevo.' : e.message)));
  });
}
async function updVersion() { return JSON.parse((await httpsGet(UPD_BASE + 'version.json?t=' + Date.now(), 256 * 1024)).toString('utf8')); }
async function updRun() {
  const e = (await updVersion())[UPD_KIND];
  if (!e || !e.win || !e.winSha || !/^[\w.-]+\.zip$/.test(e.win)) throw new Error('No hay paquete de actualización para Windows');
  const zip = await httpsGet(UPD_BASE + e.win, 120 * 1024 * 1024);
  const sha = require('crypto').createHash('sha256').update(zip).digest('hex');
  if (sha !== String(e.winSha).toLowerCase()) throw new Error('El archivo descargado no es válido. Intenta de nuevo.');
  fs.mkdirSync(UPD_DIR, { recursive: true });
  const zf = path.join(UPD_DIR, 'paquete.zip'), js = path.join(UPD_DIR, 'actualizar.js');
  fs.writeFileSync(zf, zip);
  try { fs.unlinkSync(UPD_EST); } catch (x) { }
  try { fs.unlinkSync(path.join(UPD_DIR, 'actualizar.ps1')); } catch (x) { }
  fs.writeFileSync(js, UPD_HELPER, 'utf8');
  const DEST = path.resolve(ROOT, '..'), ver = String(e.ver).replace(/[^\w.]/g, '');
  log('actualizando a la version', ver);
  // node.exe sí arranca en segundo plano (powershell.exe no: se cerraba sin instalar nada)
  const cp = require('child_process').spawn(process.execPath, [js, DEST, zf, UPD_EST, ver, String(process.pid)], { detached: true, stdio: 'ignore', windowsHide: true, cwd: UPD_DIR });
  cp.on('error', er => { log('actualizador', er.message); try { fs.writeFileSync(UPD_EST, JSON.stringify({ done: true, ok: false, ver, error: 'No se pudo iniciar el actualizador (' + er.message + ')' })); } catch (x) { } });
  cp.unref();
  // este servidor se cierra para que se puedan reemplazar sus archivos; el actualizador lo vuelve a abrir
  setTimeout(() => { log('cerrando para actualizar'); process.exit(0); }, 1500);
  return ver;
}
// Programa que instala la actualización (se escribe en datos\actualizacion\actualizar.js y corre con el node.exe de Maxsel).
const UPD_HELPER = String.raw`'use strict';
const fs = require('fs'), path = require('path'), zlib = require('zlib'), cp = require('child_process');
const [DEST, ZIP, EST, VER, PID] = process.argv.slice(2);
const BK = path.join(path.dirname(EST), 'respaldo'), LOG = path.join(DEST, 'datos', 'registro.log');
const sleep = ms => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
function log(m) { try { fs.appendFileSync(LOG, new Date().toISOString() + ' actualizador ' + m + '\r\n'); } catch (e) { } }
function est(ok, msg) { try { fs.writeFileSync(EST, JSON.stringify({ done: true, ok: ok, ver: VER, error: String(msg || '') })); } catch (e) { log('no se pudo escribir estado ' + e.message); } }
function vivo(pid) { try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } }
function reintenta(f) { for (let i = 0; ; i++) { try { return f(); } catch (e) { if (i >= 20) throw e; sleep(700); } } }
function copiar(a, b) { fs.cpSync(a, b, { recursive: true, force: true }); }
function descomprimir(buf, dest) {
  let e = buf.length - 22; while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) throw new Error('El paquete de actualización está dañado');
  const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16);
  const raiz = path.resolve(dest) + path.sep; let k = 0;
  for (let i = 0; i < n; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('El paquete de actualización está dañado');
    const met = buf.readUInt16LE(p + 10), cs = buf.readUInt32LE(p + 20), nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const nom = buf.toString('utf8', p + 46, p + 46 + nl).replace(/\\/g, '/'); p += 46 + nl + xl + cl;
    const d = path.resolve(dest, nom);
    if (!d.startsWith(raiz)) continue;
    if (nom.endsWith('/')) { fs.mkdirSync(d, { recursive: true }); continue; }
    if (buf.readUInt32LE(lo) !== 0x04034b50) throw new Error('El paquete de actualización está dañado');
    const s = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28), raw = buf.subarray(s, s + cs);
    const dat = met === 0 ? raw : met === 8 ? zlib.inflateRawSync(raw) : null;
    if (!dat) throw new Error('Formato de paquete no soportado (' + nom + ')');
    fs.mkdirSync(path.dirname(d), { recursive: true });
    reintenta(() => fs.writeFileSync(d, dat)); k++;
  }
  if (!k) throw new Error('El paquete de actualización viene vacío');
  return k;
}
function arrancar() {
  try { cp.spawn(path.join(DEST, 'node.exe'), [path.join(DEST, 'app', 'server.js')], { cwd: DEST, detached: true, stdio: 'ignore', windowsHide: true }).unref(); }
  catch (e) { log('no se pudo volver a abrir el servidor ' + e.message); }
}
log('instalando la version ' + VER);
const exe = path.join(DEST, 'MaxselPOS.exe');
try {
  const pid = +PID || 0;
  for (let i = 0; i < 40 && pid && vivo(pid); i++) sleep(250);
  if (pid && vivo(pid)) { try { process.kill(pid); } catch (e) { } sleep(1200); }
  fs.rmSync(BK, { recursive: true, force: true }); fs.mkdirSync(BK, { recursive: true });
  copiar(path.join(DEST, 'app'), path.join(BK, 'app'));
  if (fs.existsSync(exe)) fs.copyFileSync(exe, path.join(BK, 'MaxselPOS.exe'));
  const k = descomprimir(fs.readFileSync(ZIP), DEST);
  est(true, ''); log('listo, version ' + VER + ' instalada (' + k + ' archivos)');
} catch (e) {
  log('error ' + e.message);
  try { copiar(path.join(BK, 'app'), path.join(DEST, 'app')); if (fs.existsSync(path.join(BK, 'MaxselPOS.exe'))) fs.copyFileSync(path.join(BK, 'MaxselPOS.exe'), exe); } catch (x) { log('no se pudo regresar el respaldo ' + x.message); }
  est(false, e.message);
}
arrancar();
`;
const RAW = path.join(ROOT, 'rawprint.exe');
function rawPrint(printer, buf) {
  return new Promise(resolve => {
    if (!printer) return resolve('Elige la impresora en Ajustes');
    const f = path.join(os.tmpdir(), 'maxsel_' + Date.now() + '_' + Math.random().toString(36).slice(2) + '.bin');
    fs.writeFileSync(f, buf);
    execFile(RAW, [printer, f], { timeout: 20000, windowsHide: true, encoding: 'utf8' }, (err, out) => {
      try { fs.unlinkSync(f); } catch (e) { }
      const t = String(out || '').trim();
      resolve(t === 'ok' ? 'ok' : (t || (err && err.message) || 'Error al imprimir'));
    });
  });
}
function listPrinters() {
  return new Promise(resolve => {
    execFile(RAW, ['--list'], { timeout: 15000, windowsHide: true, encoding: 'utf8' }, (err, out) => {
      resolve(err ? [] : String(out).split(/\r?\n/).map(s => s.trim()).filter(Boolean));
    });
  });
}
function page(name, inject) {
  let html = fs.readFileSync(path.join(WEB, name), 'utf8');
  if (inject) html = html.replace('<script>', '<script>window.MAXSEL_DESKTOP=true;</script><script src="/bridge.js"></script><script>');
  return html;
}

// ---------- servidor ----------
const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://x'), p = u.pathname;
    if (req.method === 'OPTIONS') return send(res, 204, 'text/plain', '');

    // pantalla del cliente: espera cambios del ticket (respuesta inmediata)
    if (p === '/api/display') {
      const v = +u.searchParams.get('v') || 0;
      if (DISP.v !== v) return json(res, 200, { v: DISP.v, s: DISP.s });
      let done = false;
      const w = () => { if (done) return; done = true; clearTimeout(t); json(res, 200, { v: DISP.v, s: DISP.s }); };
      const t = setTimeout(w, 25000);
      req.on('close', () => { done = true; clearTimeout(t); dispWaiters.delete(w); });
      dispWaiters.add(w);
      return;
    }
    // peticiones de comanderos, portal de meseros y monitor
    if (p.startsWith('/api/')) {
      const body = req.method === 'GET' ? '' : await readBody(req, 4 * 1024 * 1024);
      const r = await relay({ method: req.method, path: p, query: u.search.slice(1), body, token: req.headers['x-token'] || '' });
      return json(res, r.s || 500, r.b);
    }

    // funciones internas, solo desde esta computadora
    if (p.startsWith('/bridge')) {
      if (!isLocal(req)) return send(res, 403, 'text/plain', 'Prohibido');
      switch (p) {
        case '/bridge.js': return send(res, 200, 'application/javascript; charset=utf-8', fs.readFileSync(path.join(ROOT, 'bridge.js')));
        case '/bridge/next': return nextJob(req, res);
        case '/bridge/reply': {
          const id = +u.searchParams.get('id'), body = await readBody(req, 50 * 1024 * 1024), pj = pending.get(id);
          if (pj) { pending.delete(id); clearTimeout(pj.timer); let o; try { o = JSON.parse(body); } catch (e) { o = { s: 500, b: { error: 'Respuesta inválida' } }; } pj.resolve(o); }
          return send(res, 200, 'text/plain', 'ok');
        }
        case '/bridge/display': { const t = await readBody(req, 5 * 1024 * 1024); try { DISP = { v: DISP.v + 1, s: JSON.parse(t) }; } catch (e) { } const ws = [...dispWaiters]; dispWaiters.clear(); ws.forEach(f => f()); return send(res, 200, 'text/plain', 'ok'); }
        case '/bridge/ips': return send(res, 200, 'text/plain', ips());
        case '/bridge/deviceid': return send(res, 200, 'text/plain', machineId());
        case '/bridge/db':
          if (req.method === 'GET') return fs.existsSync(DBFILE) ? send(res, 200, 'application/json', fs.readFileSync(DBFILE)) : send(res, 204, 'text/plain', '');
          saveDb(await readBody(req, 200 * 1024 * 1024)); return send(res, 200, 'text/plain', 'ok');
        case '/bridge/arch': {
          // ventas archivadas por mes: C:\MaxselPOS\datos\archivo\<clave>.json
          const k = String(new URL(req.url, 'http://x').searchParams.get('k') || '').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 120);
          if (!k) return send(res, 400, 'text/plain', 'clave');
          const dir = path.join(DATA, 'archivo'), file = path.join(dir, k + '.json');
          if (req.method === 'GET') return fs.existsSync(file) ? send(res, 200, 'application/json', fs.readFileSync(file)) : send(res, 204, 'text/plain', '');
          const body = await readBody(req, 200 * 1024 * 1024);
          try { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(file + '.tmp', body); fs.renameSync(file + '.tmp', file); } catch (e) { return send(res, 500, 'text/plain', String(e.message)); }
          return send(res, 200, 'text/plain', 'ok');
        }
        case '/bridge/net': { const j = JSON.parse(await readBody(req, 10 * 1024 * 1024)); const r = await netPrint(j.ip, +j.port || 9100, Buffer.from(j.b64, 'base64')); if (r !== 'ok') log('impresora red', j.name, j.ip, r); return send(res, 200, 'text/plain', r); }
        case '/bridge/raw': { const j = JSON.parse(await readBody(req, 10 * 1024 * 1024)); const r = await rawPrint(j.printer, Buffer.from(j.b64, 'base64')); if (r !== 'ok') log('impresora windows', j.printer, r); return send(res, 200, 'text/plain', r); }
        case '/bridge/scale/ports': return json(res, 200, String(await scaleRun(['--list'], 8000)).split(/\r?\n/).map(s => s.trim()).filter(s => /^COM\d+$/i.test(s)));
        case '/bridge/scale/read': { const q = u.searchParams, port = String(q.get('port') || ''); if (!/^COM\d+$/i.test(port)) return json(res, 200, { ok: false, error: 'Elige el puerto de la báscula' }); return json(res, 200, scaleParse(await scaleRun([port, String(+q.get('baud') || 9600), String(q.get('cmd') || 'P').replace(/[^A-Za-z]/g, '').slice(0, 6) || 'P'], 5000))); }
        case '/bridge/scale/detect': { const port = String(u.searchParams.get('port') || ''); if (!/^COM\d+$/i.test(port)) return json(res, 200, { ok: false, error: 'Elige el puerto de la báscula' }); return json(res, 200, scaleParse(await scaleRun([port, 'auto'], 60000))); }
        case '/bridge/update/check': try { return json(res, 200, await updVersion()); } catch (e) { return json(res, 200, { error: e.message }); }
        case '/bridge/update/run': {
          if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'POST' });
          const t = Date.now();
          try { const ver = await updRun(); return json(res, 200, { ok: true, ver, t }); } catch (e) { log('actualizacion', e.message); return json(res, 200, { ok: false, error: e.message }); }
        }
        case '/bridge/update/status': { let o = { done: false }; try { o = JSON.parse(fs.readFileSync(UPD_EST, 'utf8').replace(/^﻿/, '')); } catch (e) { } return json(res, 200, o); }
        case '/bridge/printers': return json(res, 200, await listPrinters());
        case '/bridge/mp': { const j = JSON.parse(await readBody(req, 1024 * 1024)); return json(res, 200, await mpRequest(String(j.method || 'GET').toUpperCase(), String(j.path || ''), j.body || '', j.headers || {})); }
      }
      return send(res, 404, 'text/plain', 'No encontrado');
    }

    // páginas
    if (p === '/caja') {
      if (!isLocal(req)) return send(res, 403, 'text/html; charset=utf-8', '<h2 style="font-family:sans-serif">La caja solo se abre en la computadora de la caja.<br>Meseros: <a href="/meseros">/meseros</a> · Monitor: <a href="/">/</a></h2>');
      return send(res, 200, 'text/html; charset=utf-8', page('index.html', true));
    }
    if (p === '/meseros' || p === '/mesero' || p === '/comandero') return send(res, 200, 'text/html; charset=utf-8', page('index.html', false));
    if (p === '/' || p === '/monitor') return send(res, 200, 'text/html; charset=utf-8', page('monitor.html', false));
    if (p === '/logo.png' || p === '/icono.png') return send(res, 200, 'image/png', fs.readFileSync(path.join(WEB, p.slice(1))));
    if (p === '/cliente' || p === '/pantalla') return send(res, 200, 'text/html; charset=utf-8', page('cliente.html', false));
    if (p === '/kiosko' || p === '/kiosk') return send(res, 200, 'text/html; charset=utf-8', page('kiosko.html', false));
    if (p === '/cocina' || p === '/kds') return send(res, 200, 'text/html; charset=utf-8', page('cocina.html', false));
    return send(res, 404, 'text/plain', 'No encontrado');
  } catch (e) {
    log('error', req.url, e && e.message);
    try { json(res, 500, { error: 'Error interno' }); } catch (x) { }
  }
});
server.on('error', e => { log('no se pudo abrir el puerto', PORT, e.message); process.exit(1); });
server.listen(PORT, '0.0.0.0', () => log('Maxsel POS escuchando en el puerto', PORT));
