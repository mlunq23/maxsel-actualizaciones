// Maxsel Hotel 1.3 — crear, importar y afinar muchas habitaciones de golpe
'use strict';

const refrescarHabs = () => (vista === 'cfg' ? cHabs() : vHab());
const normT = (s) => String(s ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');
const numT = (s) => { const n = parseFloat(String(s ?? '').replace(/[$,\s]/g, '')); return isFinite(n) && n > 0 ? n : 0; };
const enteroT = (s, d) => { const n = parseInt(String(s ?? '').replace(/[^\d]/g, ''), 10); return isFinite(n) ? n : d; };
const pisoAuto = (num) => (/^\d{3,4}$/.test(num) ? String(Math.floor(Number(num) / 100)) : '');
const BASE_HAB = () => ({ nombre: '', clase: 'habitacion', piso: '', camas: { matrimonial: 1 }, recamaras: 1, banos: 1, capacidad: 2, amenidades: ['wifi', 'tv'], precio_rato: 0, precio_noche: 0, precio_dia: 0, precio_semana: 0, precio_mes: 0 });
const sinPrecio = (h) => !ORDEN_MOD.some((m) => h['precio_' + m] > 0);
const PK = () => ORDEN_MOD.map((m) => 'precio_' + m);

// ---------- Lista de habitaciones en Configuración (con los botones nuevos) ----------
async function cHabs() {
  const H = sortH(await GET('/api/habitaciones')); cHabs.l = H;
  const faltan = H.filter(sinPrecio).length;
  $('#cfgc').innerHTML = `<div class="card"><div class="row" style="justify-content:space-between;margin-bottom:10px;flex-wrap:wrap;gap:8px"><h2 style="margin:0">Habitaciones y departamentos · ${H.length}</h2>
      <div class="row" style="flex-wrap:wrap;gap:8px"><button class="btn" onclick="importarModal()">Importar de Excel</button><button class="btn" onclick="loteModal()">Crear varias de golpe</button>${H.length ? '<button class="btn" onclick="editarVarias()">Afinar varias a la vez</button>' : ''}<button class="btn pri" onclick="habModal()">Agregar una o varias</button></div></div>
    ${faltan ? `<div class="aviso bad" style="margin-bottom:10px">${faltan} habitación(es) sin precio: no se pueden rentar hasta ponerles precio. <button class="btn sm" onclick="editarVarias(null,true)">Poner precios</button></div>` : ''}
    <div class="tw"><table><thead><tr><th>Número</th><th>Tipo</th><th>Piso</th><th>Incluye</th>${ORDEN_MOD.map((m) => `<th class="n">${MOD[m].replace('Por ', '')}</th>`).join('')}<th>Estado</th></tr></thead><tbody>
    ${H.map((h) => `<tr class="click" onclick="habModal(${h.id})"><td><b>${esc(h.numero)}</b><div class="sub">${esc(h.nombre || '')}</div></td><td>${CLASE[h.clase] || 'Habitación'}<div class="sub">${esc(unidadDe(h))}</div></td><td>${esc(h.piso || '')}</td><td>${feats(h)}${amenIcons(h)}</td>
      ${PK().map((k) => `<td class="n">${h[k] ? money(h[k]) : '—'}</td>`).join('')}<td>${sinPrecio(h) ? '<span class="pill p-bad">Sin precio</span>' : `<span class="pill s-${h.estado}">${EST[h.estado]}</span>`}</td></tr>`).join('') || '<tr><td colspan="10" class="empty">Agregue sus habitaciones: una por una, varias de golpe o importándolas de Excel.</td></tr>'}</tbody></table></div></div>`;
}

// ---------- Plantilla de "qué incluye" (camas, espacios, amenidades) ----------
function cnt4(id, d, min) { const el = $('#' + id); el.textContent = Math.max(min, Math.min(20, (parseInt(el.textContent) || 0) + d)); }
function plantillaHTML(p, h) {
  const c = (id, label, icon, v, min) => `<div class="contador"><span>${ico(icon)}${label}</span><span class="qty"><button type="button" onclick="cnt4('${id}',-1,${min})">−</button><b id="${id}">${v || 0}</b><button type="button" onclick="cnt4('${id}',1,${min})">+</button></span></div>`;
  return `<div class="lbl">Camas</div><div class="f cont">${Object.keys(CAMA).map((k) => c(p + 'cama_' + k, CAMA[k], 'cama', h.camas[k], 0)).join('')}</div>
    <div class="lbl">Espacios</div><div class="f cont">${c(p + 'R', 'Recámaras / cuartos', 'recamara', h.recamaras, 1)}${c(p + 'B', 'Baños', 'bano', h.banos, 0)}${c(p + 'Cap', 'Capacidad (personas)', 'personas', h.capacidad, 1)}</div>
    <div class="lbl">Qué incluye</div><div class="chipsel">${Object.entries(AMEN).map(([k, n]) => `<label><input type="checkbox" name="${p}A" value="${k}" ${h.amenidades.includes(k) ? 'checked' : ''}>${ico(k)}${n}</label>`).join('')}</div>`;
}
function leerPlantilla(p) {
  const camas = {}; for (const k of Object.keys(CAMA)) { const n = parseInt($('#' + p + 'cama_' + k).textContent) || 0; if (n) camas[k] = n; }
  return { camas, recamaras: parseInt($('#' + p + 'R').textContent) || 1, banos: parseInt($('#' + p + 'B').textContent) || 0, capacidad: parseInt($('#' + p + 'Cap').textContent) || 1,
    amenidades: [...document.querySelectorAll(`input[name=${p}A]:checked`)].map((x) => x.value) };
}
function preciosHTML(p, nota) {
  return `<div class="f">${ORDEN_MOD.map((m) => `<label class="l"><span><i class="dot" style="display:inline-block;width:10px;height:10px;border-radius:50%;background:var(--m-${m});margin-right:6px"></i>${modTxt(m)}</span><input id="${p}${m}" type="number" min="0" step="0.01" placeholder="${nota || ''}"></label>`).join('')}</div>`;
}
const listaCorta = (a) => (a.length > 14 ? a.slice(0, 10).join(', ') + ' … ' + a.slice(-3).join(', ') : a.join(', '));

// ---------- Crear varias de golpe ----------
async function loteModal() {
  const ex = await GET('/api/habitaciones'); loteModal.ex = new Set(ex.map((h) => String(h.numero).toLowerCase()));
  modal('Crear varias habitaciones de golpe', `
    <div class="lbl">¿Cómo están numeradas?</div>
    <div class="seg"><label><input type="radio" name="lM" value="rango" checked onchange="lotePrev()">Números seguidos</label><label><input type="radio" name="lM" value="pisos" onchange="lotePrev()">Por pisos</label><label><input type="radio" name="lM" value="lista" onchange="lotePrev()">Escribirlos</label></div>
    <div id="lmRango" class="f"><label class="l">Desde el número<input id="lD" value="101" oninput="lotePrev()"></label><label class="l">Hasta el número<input id="lH" value="110" oninput="lotePrev()"></label><label class="l">Letra o prefijo (opcional)<input id="lPre" placeholder="Ej. D para D1, D2…" oninput="lotePrev()"></label></div>
    <div id="lmPisos" class="f" hidden><label class="l">Del piso<input id="lP1" type="number" min="0" value="1" oninput="lotePrev()"></label><label class="l">Al piso<input id="lP2" type="number" min="0" value="3" oninput="lotePrev()"></label><label class="l">Habitaciones por piso<input id="lPC" type="number" min="1" value="10" oninput="lotePrev()"></label></div>
    <div id="lmLista" hidden><label class="l">Números (separados por coma o renglón)<textarea id="lL" rows="3" placeholder="101, 102, 103, 2A, 2B, Suite Real" oninput="lotePrev()"></textarea></label></div>
    <div class="f"><label class="l">Tipo<select id="lT"><option value="habitacion">Habitación</option><option value="departamento">Departamento</option><option value="local">Local comercial</option></select></label>
      <label class="l">Unidad de negocio<select id="lU">${unidadesCfg().map((u) => `<option ${u === fUni ? 'selected' : ''}>${esc(u)}</option>`).join('')}</select></label>
      ${puede('autorizar') ? '<label class="l">Precio fijo de visita<input id="lVi" type="number" min="0" step="0.01" placeholder="Igual al general"></label>' : ''}<label class="l">Nombre o descripción (opcional)<input id="lN" placeholder="Sencilla, Doble, Suite…"></label><label class="l" id="lPisoL">Piso<input id="lPiso" placeholder="Automático (101 → piso 1)" oninput="lotePrev()"></label></div>
    <div class="aviso" id="lPrev"></div>
    <div class="card" style="padding:12px"><div class="lbl" style="margin-bottom:6px">Qué incluye cada una (igual para todas; después puede afinar cada una)</div>${plantillaHTML('L', BASE_HAB())}</div>
    <div class="lbl">Precio</div>
    <div class="seg"><label><input type="radio" name="lPr" value="igual" checked onchange="$('#lPrecios').hidden=false">Todas con el mismo precio</label><label><input type="radio" name="lPr" value="cada" onchange="$('#lPrecios').hidden=true">Poner el precio a cada una después</label></div>
    <div id="lPrecios">${preciosHTML('lp_', 'Deje vacío el que no maneje')}</div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" id="lOkB" onclick="loteOk()">Crear</button>`, true);
  lotePrev();
}
function loteNums() {
  const m = document.querySelector('input[name=lM]:checked').value, piso = val('lPiso'), out = [];
  if (m === 'rango') {
    const d = val('lD'), h = val('lH'), pre = val('lPre');
    if (!/^\d+$/.test(d) || !/^\d+$/.test(h)) return { error: 'Escriba números en "Desde" y "Hasta" (sin letras; la letra va en prefijo).' };
    const a = Number(d), b = Number(h), w = d.startsWith('0') ? d.length : 0;
    if (b < a) return { error: '"Hasta" debe ser mayor o igual que "Desde".' };
    if (b - a >= 1000) return { error: 'Máximo 1000 habitaciones por vez.' };
    for (let n = a; n <= b; n++) { const s = String(n).padStart(w, '0'); out.push({ numero: pre + s, piso: piso || (pre ? '' : pisoAuto(s)) }); }
  } else if (m === 'pisos') {
    const p1 = enteroT(val('lP1'), 1), p2 = enteroT(val('lP2'), p1), c = enteroT(val('lPC'), 1);
    if (p2 < p1) return { error: '"Al piso" debe ser mayor o igual que "Del piso".' };
    if ((p2 - p1 + 1) * c > 1000) return { error: 'Máximo 1000 habitaciones por vez.' };
    if (c < 1) return { error: 'Ponga cuántas habitaciones hay por piso.' };
    for (let p = p1; p <= p2; p++) for (let i = 1; i <= c; i++) out.push({ numero: p + String(i).padStart(c > 99 ? 3 : 2, '0'), piso: String(p) });
  } else {
    const vistos = new Set();
    for (const t of val('lL').split(/[\n,;]+/).map((x) => x.trim()).filter(Boolean)) { if (vistos.has(t.toLowerCase())) continue; vistos.add(t.toLowerCase()); out.push({ numero: t.slice(0, 20), piso: piso || pisoAuto(t) }); }
    if (out.length > 1000) return { error: 'Máximo 1000 habitaciones por vez.' };
  }
  return { lista: out };
}
function lotePrev() {
  const m = document.querySelector('input[name=lM]:checked').value;
  $('#lmRango').hidden = m !== 'rango'; $('#lmPisos').hidden = m !== 'pisos'; $('#lmLista').hidden = m !== 'lista'; $('#lPisoL').hidden = m === 'pisos';
  const r = loteNums(), pv = $('#lPrev'), b = $('#lOkB');
  if (r.error) { pv.className = 'aviso bad'; pv.textContent = r.error; b.disabled = true; b.textContent = 'Crear'; return; }
  const nuevas = r.lista.filter((x) => !loteModal.ex.has(x.numero.toLowerCase())), ya = r.lista.filter((x) => loteModal.ex.has(x.numero.toLowerCase()));
  pv.className = 'aviso';
  pv.innerHTML = nuevas.length ? `Se crearán <b>${nuevas.length}</b>: ${esc(listaCorta(nuevas.map((x) => x.numero)))}${ya.length ? `<br>Ya existen y se dejarán igual: ${esc(listaCorta(ya.map((x) => x.numero)))}` : ''}`
    : r.lista.length ? 'Todas esas habitaciones ya existen.' : 'Escriba los números de las habitaciones.';
  b.disabled = !nuevas.length; b.textContent = nuevas.length ? `Crear ${nuevas.length} habitaciones` : 'Crear';
  loteNums.nuevas = nuevas;
}
async function loteOk() {
  const nuevas = loteNums.nuevas || [], pl = leerPlantilla('L'), igual = document.querySelector('input[name=lPr]:checked').value === 'igual';
  const pr = Object.fromEntries(ORDEN_MOD.map((m) => ['precio_' + m, igual ? num('lp_' + m) : 0]));
  if (igual && sinPrecio(pr)) return toast('Ponga al menos un precio, o elija "Poner el precio a cada una después"', true);
  const lista = nuevas.map((x) => ({ ...pl, ...pr, numero: x.numero, piso: x.piso, nombre: val('lN'), clase: val('lT'), unidad: val('lU'), ...($('#lVi') && val('lVi') !== '' ? { precio_visita: val('lVi') } : {}) }));
  const r = await hacer(() => POST('/api/habitaciones/lote', { habitaciones: lista, existentes: 'saltar' }));
  const nums = lista.map((x) => x.numero);
  if (!igual) { toast(`Se crearon ${r.creadas} habitaciones. Ahora ponga el precio de cada una.`); return editarVarias(nums, true); }
  await refrescarHabs();
  modal('Habitaciones creadas', `<p style="margin:0">Se crearon <b>${r.creadas}</b> habitaciones${r.saltadas.length ? ` (se dejaron igual ${r.saltadas.length} que ya existían)` : ''}.</p><p class="sub">Si alguna tiene otras camas, otro precio o incluye algo distinto, puede afinarlas ahora o después en Configuración → Habitaciones.</p>`,
    `<button class="btn" onclick="cerrar()">Listo</button><button class="btn pri" onclick='editarVarias(${JSON.stringify(nums).replace(/'/g, '&#39;')})'>Afinar detalles</button>`);
}

// ---------- Afinar varias a la vez ----------
let ED = null;
async function editarVarias(nums, soloSinPrecio) {
  const H = sortH(await GET('/api/habitaciones'));
  ED = { rows: H.map((h) => ({ ...h, camas: { ...h.camas }, amenidades: [...h.amenidades] })), orig: new Map(H.map((h) => [h.id, JSON.stringify(h)])), sel: new Set(),
    foco: nums ? new Set(nums.map((n) => String(n).toLowerCase())) : soloSinPrecio ? new Set(H.filter(sinPrecio).map((h) => String(h.numero).toLowerCase())) : null, piso: '', q: '' };
  const pisos = [...new Set(H.map((h) => h.piso || ''))].sort((a, b) => a.localeCompare(b, 'es', { numeric: true }));
  modal('Afinar varias habitaciones', `
    <div class="row" style="flex-wrap:wrap;gap:8px"><input id="edQ" placeholder="Buscar número o nombre" style="width:auto;flex:1" oninput="ED.q=this.value;edPintar()">
      <select id="edPi" style="width:auto" onchange="ED.piso=this.value;edPintar()"><option value="">Todos los pisos</option>${pisos.map((p) => `<option value="${esc(p)}">${p ? 'Piso ' + esc(p) : 'Sin piso'}</option>`).join('')}</select>
      <span id="edFoco"></span></div>
    <div class="tw edgrid"><table><thead><tr><th><input type="checkbox" id="edTodas" onchange="edTodas(this.checked)" title="Seleccionar todas las que se ven"></th><th>Número</th><th>Nombre</th><th>Tipo</th><th>Piso</th><th>Incluye</th>${ORDEN_MOD.map((m) => `<th class="n">${MOD[m].replace('Por ', '')}</th>`).join('')}</tr></thead><tbody id="edT"></tbody></table></div>
    <details class="card edlote" open><summary><b>Cambiar a las seleccionadas</b> <span id="edN" class="sub"></span></summary>
      <div class="lbl">Precio (deje vacío el que no quiera cambiar)</div>${preciosHTML('ep_')}<div class="row" style="margin-top:6px"><button class="btn sm pri" onclick="edAplicar('precio')">Poner este precio</button></div>
      <div class="f" style="margin-top:12px"><label class="l">Tipo<select id="edTi"><option value="">Sin cambio</option><option value="habitacion">Habitación</option><option value="departamento">Departamento</option><option value="local">Local comercial</option></select></label>
        <label class="l">Unidad de negocio<select id="edUn"><option value="">Sin cambio</option>${unidadesCfg().map((u) => `<option>${esc(u)}</option>`).join('')}</select></label>
        ${puede('autorizar') ? '<label class="l">Precio fijo de visita<input id="edVi" type="number" min="0" step="0.01" placeholder="Sin cambio"></label>' : ''}<label class="l">Nombre o descripción<input id="edNo" placeholder="Sin cambio"></label><label class="l">Piso<input id="edPs" placeholder="Sin cambio"></label></div>
      <div class="row" style="margin-top:6px"><button class="btn sm pri" onclick="edAplicar('datos')">Poner tipo, unidad, nombre, piso y visita</button></div>
      <div style="margin-top:12px">${plantillaHTML('E', { ...BASE_HAB(), amenidades: [] })}</div>
      <div class="row" style="margin-top:8px;flex-wrap:wrap;gap:8px"><button class="btn sm pri" onclick="edAplicar('camas')">Poner estas camas y espacios</button><button class="btn sm pri" onclick="edAplicar('incluye+')">Agregar lo marcado en "Qué incluye"</button><button class="btn sm" onclick="edAplicar('incluye-')">Quitar lo marcado en "Qué incluye"</button></div>
    </details>`,
  `<button class="btn" onclick="cerrar();refrescarHabs()">Cerrar sin guardar</button><button class="btn pri" id="edG" onclick="edGuardar()">Guardar cambios</button>`, true);
  $('#modal .mbox').classList.add('extra');
  edPintar();
}
function edVisibles() {
  const q = ED.q.trim().toLowerCase();
  return ED.rows.filter((h) => (!ED.foco || ED.foco.has(String(h.numero).toLowerCase()) || ED.foco.has('#' + h.id)) && (!ED.piso || (h.piso || '') === ED.piso) && (!q || (h.numero + ' ' + (h.nombre || '')).toLowerCase().includes(q)));
}
function edPintar() {
  const vis = edVisibles();
  $('#edFoco').innerHTML = ED.foco ? `<span class="pill">Mostrando ${vis.length} habitación(es)</span> <button class="btn sm" onclick="ED.foco=null;edPintar()">Ver todas</button>` : '';
  const inp = (h, k, w, t = 'text') => `<input ${t === 'number' ? 'type="number" min="0" step="0.01"' : ''} value="${esc(h[k] || '')}" style="width:${w}" oninput="edSet(${h.id},'${k}',this.value)">`;
  $('#edT').innerHTML = vis.map((h) => `<tr class="${ED.sel.has(h.id) ? 'sel' : ''} ${edCambio(h) ? 'cambio' : ''}" id="edr${h.id}"><td><input type="checkbox" ${ED.sel.has(h.id) ? 'checked' : ''} onchange="edSel(${h.id},this.checked)"></td>
    <td>${inp(h, 'numero', '80px')}</td><td>${inp(h, 'nombre', '130px')}</td>
    <td><select style="width:auto" onchange="edSet(${h.id},'clase',this.value)"><option value="habitacion">Hab.</option><option value="departamento" ${h.clase === 'departamento' ? 'selected' : ''}>Depto.</option><option value="local" ${h.clase === 'local' ? 'selected' : ''}>Local</option></select>
      <select style="width:auto;margin-top:3px" onchange="edSet(${h.id},'unidad',this.value)">${[...new Set([...unidadesCfg(), unidadDe(h)])].map((u) => `<option ${u === unidadDe(h) ? 'selected' : ''}>${esc(u)}</option>`).join('')}</select></td>
    <td>${inp(h, 'piso', '56px')}</td><td class="edinc" title="${esc(textoCamas(h.camas) + (h.amenidades.length ? ' · ' + h.amenidades.map((a) => AMEN[a]).join(', ') : ''))}">${feats(h)}${amenIcons(h)}</td>
    ${PK().map((k) => `<td class="n">${inp(h, k, '84px', 'number')}</td>`).join('')}</tr>`).join('') || '<tr><td colspan="11" class="empty">No hay habitaciones con ese filtro.</td></tr>';
  $('#edTodas').checked = vis.length > 0 && vis.every((h) => ED.sel.has(h.id));
  edCuenta();
}
function edCambio(h) { const o = JSON.parse(ED.orig.get(h.id)); return ['numero', 'nombre', 'clase', 'unidad', 'precio_visita', 'piso', 'recamaras', 'banos', 'capacidad', ...PK()].some((k) => String(o[k] ?? '') !== String(h[k] ?? '')) || JSON.stringify(o.camas) !== JSON.stringify(h.camas) || JSON.stringify([...o.amenidades].sort()) !== JSON.stringify([...h.amenidades].sort()); }
function edCuenta() {
  const n = ED.sel.size, c = ED.rows.filter(edCambio).length;
  $('#edN').textContent = n ? `(${n} seleccionada${n > 1 ? 's' : ''})` : '(marque las casillas de la tabla)';
  $('#edG').textContent = c ? `Guardar cambios (${c})` : 'Guardar cambios';
}
function edSet(id, k, v) {
  const h = ED.rows.find((x) => x.id === id); h[k] = k.startsWith('precio_') ? (parseFloat(v) || 0) : v;
  $('#edr' + id).classList.toggle('cambio', edCambio(h)); edCuenta();
}
function edSel(id, on) { if (on) ED.sel.add(id); else ED.sel.delete(id); $('#edr' + id)?.classList.toggle('sel', on); $('#edTodas').checked = edVisibles().every((h) => ED.sel.has(h.id)); edCuenta(); }
function edTodas(on) { for (const h of edVisibles()) { if (on) ED.sel.add(h.id); else ED.sel.delete(h.id); } edPintar(); }
function edAplicar(que) {
  const sel = ED.rows.filter((h) => ED.sel.has(h.id));
  if (!sel.length) return toast('Primero marque en la tabla las habitaciones a cambiar', true);
  if (que === 'precio') {
    const p = Object.fromEntries(ORDEN_MOD.map((m) => ['precio_' + m, val('ep_' + m)]));
    if (!Object.values(p).some((v) => v !== '')) return toast('Escriba el precio que quiere poner', true);
    for (const h of sel) for (const [k, v] of Object.entries(p)) if (v !== '') h[k] = parseFloat(v) || 0;
  } else if (que === 'datos') {
    const t = val('edTi'), n = val('edNo'), ps = val('edPs'), un = val('edUn'), vi = val('edVi');
    if (!t && !n && !ps && !un && vi === '') return toast('Elija el tipo o la unidad, o escriba el nombre, el piso o el precio de visita', true);
    for (const h of sel) { if (t) h.clase = t; if (n) h.nombre = n; if (ps) h.piso = ps; if (un) h.unidad = un; if (vi !== '') h.precio_visita = parseFloat(vi) || 0; }
  } else {
    const pl = leerPlantilla('E');
    if (que !== 'camas' && !pl.amenidades.length) return toast('Marque en "Qué incluye" lo que quiere agregar o quitar', true);
    for (const h of sel) {
      if (que === 'camas') Object.assign(h, { camas: { ...pl.camas }, recamaras: pl.recamaras, banos: pl.banos, capacidad: pl.capacidad });
      else if (que === 'incluye+') h.amenidades = [...new Set([...h.amenidades, ...pl.amenidades])];
      else h.amenidades = h.amenidades.filter((a) => !pl.amenidades.includes(a));
    }
  }
  edPintar(); toast(`Listo en ${sel.length} habitación(es). Toque "Guardar cambios" para guardar.`);
}
async function edGuardar() {
  const cambios = ED.rows.filter(edCambio);
  if (!cambios.length) { cerrar(); return refrescarHabs(); }
  if (cambios.some((h) => !String(h.numero).trim())) return toast('Hay una habitación sin número', true);
  await hacer(() => PUT('/api/habitaciones/lote', { habitaciones: cambios }));
  const sp = ED.rows.filter(sinPrecio).length;
  cerrar(); await refrescarHabs();
  toast(`Se guardaron ${cambios.length} habitación(es)` + (sp ? ` · ${sp} siguen sin precio` : ''), !!sp);
}

// ---------- Importar de Excel (.xlsx), CSV o pegado ----------
const COLS_IMP = [
  ['numero', 'Número'], ['nombre', 'Nombre'], ['clase', 'Tipo (Habitación, Departamento o Local)'], ['unidad', 'Unidad de negocio'], ['piso', 'Piso'],
  ...Object.entries(CAMA).map(([k, n]) => ['cama_' + k, 'Camas ' + n.toLowerCase()]),
  ['recamaras', 'Recámaras'], ['banos', 'Baños'], ['capacidad', 'Capacidad'], ['amenidades', 'Incluye'],
  ['precio_rato', 'Precio rato'], ['precio_noche', 'Precio noche'], ['precio_dia', 'Precio día'], ['precio_semana', 'Precio semana'], ['precio_mes', 'Precio mes'], ['precio_visita', 'Precio visita'],
];
function columnaImp(h) {
  const t = normT(h);
  if (!t) return null;
  if (t.includes('visita')) return 'precio_visita';
  if (t.includes('unidad') || t.includes('negocio') || t.includes('seccion') || t.includes('zona')) return 'unidad';
  if (t.includes('precio') || t.includes('tarifa') || ['dia', 'semana', 'mes', 'noche', 'rato', 'pordia', 'porsemana', 'pormes', 'pornoche', 'porrato'].includes(t)) {
    if (t.includes('sem')) return 'precio_semana'; if (t.includes('mes')) return 'precio_mes'; if (t.includes('rato') || t.includes('hora')) return 'precio_rato'; if (t.includes('noche')) return 'precio_noche'; if (t.includes('dia')) return 'precio_dia'; return null;
  }
  if (t.includes('sofa')) return 'cama_sofacama';
  for (const k of Object.keys(CAMA)) if (t.includes(k)) return 'cama_' + k;
  if (t.includes('recamara') || t.includes('cuartos') || t.includes('dormitorio')) return 'recamaras';
  if (t.includes('bano')) return 'banos';
  if (t.includes('capacidad') || t.includes('personas') || t.includes('huespedes')) return 'capacidad';
  if (t.includes('incluye') || t.includes('amenidad') || t.includes('servicio')) return 'amenidades';
  if (t.includes('tipo') || t.includes('clase')) return 'clase';
  if (t.includes('piso') || t.includes('nivel')) return 'piso';
  if (t.includes('nombre') || t.includes('descrip')) return 'nombre';
  if (t.startsWith('num') || t === 'no' || t === 'hab' || t === 'habitacion' || t === 'cuarto' || t === 'depto' || t === 'departamento') return 'numero';
  return null;
}
const SIN_AMEN = { internet: 'wifi', wifi: 'wifi', tele: 'tv', tv: 'tv', television: 'tv', pantalla: 'tv', aire: 'ac', clima: 'ac', minisplit: 'ac', ac: 'ac', abanico: 'ventilador', ventilador: 'ventilador', aguacaliente: 'agua', boiler: 'agua', agua: 'agua',
  cocina: 'cocina', cocineta: 'cocina', refri: 'refri', refrigerador: 'refri', frigobar: 'minibar', minibar: 'minibar', micro: 'micro', microondas: 'micro', jacuzzi: 'jacuzzi', tina: 'jacuzzi', estacionamiento: 'estacionamiento', cochera: 'estacionamiento',
  lavadora: 'lavadora', parrilla: 'parrilla', estufa: 'parrilla', estufaelectrica: 'parrilla', hornilla: 'parrilla', balcon: 'balcon', terraza: 'balcon', mascotas: 'mascotas', mascota: 'mascotas', petfriendly: 'mascotas' };
for (const [k, n] of Object.entries(AMEN)) SIN_AMEN[normT(n)] = k;
const amenDe = (s) => [...new Set(String(s || '').split(/[,;/|\n]+|\s+y\s+/i).map((x) => SIN_AMEN[normT(x)] || Object.entries(SIN_AMEN).find(([t]) => t.length > 3 && normT(x).includes(t))?.[1]).filter(Boolean))];

function leerTexto(t) {
  t = String(t || '').replace(/^﻿/, '');
  const pl = t.split(/\r?\n/)[0] || '', sep = pl.includes('\t') ? '\t' : (pl.split(';').length > pl.split(',').length ? ';' : ',');
  const filas = []; let fila = [], campo = '', comillas = false;
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (comillas) { if (c === '"') { if (t[i + 1] === '"') { campo += '"'; i++; } else comillas = false; } else campo += c; continue; }
    if (c === '"' && campo === '') comillas = true; else if (c === sep) { fila.push(campo); campo = ''; } else if (c === '\n' || c === '\r') { if (c === '\r' && t[i + 1] === '\n') i++; fila.push(campo); filas.push(fila); fila = []; campo = ''; } else campo += c;
  }
  if (campo !== '' || fila.length) { fila.push(campo); filas.push(fila); }
  return filas.filter((f) => f.some((x) => String(x).trim() !== ''));
}
// Lector pequeño de .xlsx (es un .zip con XML adentro): lee la primera hoja
async function leerXlsx(buf) {
  const dv = new DataView(buf), u8 = new Uint8Array(buf), dec = new TextDecoder();
  let e = -1; for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 70000); i--) if (dv.getUint32(i, true) === 0x06054b50) { e = i; break; }
  if (e < 0) throw new Error('El archivo no parece un Excel (.xlsx)');
  const n = dv.getUint16(e + 10, true); let p = dv.getUint32(e + 16, true); const arch = {};
  for (let k = 0; k < n; k++) {
    const met = dv.getUint16(p + 10, true), tam = dv.getUint32(p + 20, true), ln = dv.getUint16(p + 28, true), lx = dv.getUint16(p + 30, true), lc = dv.getUint16(p + 32, true), off = dv.getUint32(p + 42, true);
    arch[dec.decode(u8.subarray(p + 46, p + 46 + ln))] = { met, tam, off }; p += 46 + ln + lx + lc;
  }
  const sacar = async (nombre) => {
    const f = arch[nombre]; if (!f) return null;
    const ini = f.off + 30 + dv.getUint16(f.off + 26, true) + dv.getUint16(f.off + 28, true), datos = u8.subarray(ini, ini + f.tam);
    if (f.met === 0) return dec.decode(datos);
    return await new Response(new Blob([datos]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).text();
  };
  const xml = (s) => new DOMParser().parseFromString(s, 'application/xml');
  const ss = await sacar('xl/sharedStrings.xml'), textos = ss ? [...xml(ss).getElementsByTagName('si')].map((si) => [...si.getElementsByTagName('t')].map((t) => t.textContent).join('')) : [];
  let hoja = 'xl/worksheets/sheet1.xml';
  try {
    const wb = xml(await sacar('xl/workbook.xml')), rid = wb.getElementsByTagName('sheet')[0]?.getAttribute('r:id'), rels = xml(await sacar('xl/_rels/workbook.xml.rels'));
    const t = [...rels.getElementsByTagName('Relationship')].find((r) => r.getAttribute('Id') === rid)?.getAttribute('Target');
    if (t) hoja = t.startsWith('/') ? t.slice(1) : 'xl/' + t.replace(/^\.\//, '');
  } catch { /* se usa sheet1 */ }
  const sh = await sacar(hoja) || await sacar(Object.keys(arch).find((k) => /^xl\/worksheets\/sheet\d+\.xml$/.test(k)));
  if (!sh) throw new Error('No se encontró la hoja en el Excel');
  const filas = [];
  for (const row of xml(sh).getElementsByTagName('row')) {
    const f = [];
    for (const c of row.getElementsByTagName('c')) {
      const ref = c.getAttribute('r') || '', col = [...ref.replace(/\d+/g, '')].reduce((s, ch) => s * 26 + ch.charCodeAt(0) - 64, 0) - 1, t = c.getAttribute('t');
      const v = c.getElementsByTagName('v')[0]?.textContent ?? '';
      f[col >= 0 ? col : f.length] = t === 's' ? textos[Number(v)] ?? '' : t === 'inlineStr' ? [...c.getElementsByTagName('t')].map((x) => x.textContent).join('') : v;
    }
    filas[Number(row.getAttribute('r') || filas.length + 1) - 1] = [...f].map((x) => x ?? '');
  }
  return filas.filter((f) => f && f.some((x) => String(x).trim() !== ''));
}
async function importarModal() {
  importarModal.ex = new Map((await GET('/api/habitaciones')).map((h) => [String(h.numero).toLowerCase(), h]));
  modal('Importar habitaciones de Excel', `
    <p class="sub" style="margin:0">Use una hoja de Excel con una habitación por renglón y los títulos en el primer renglón. Solo el <b>Número</b> es obligatorio; lo que falte se puede afinar después.</p>
    <div class="row" style="flex-wrap:wrap;gap:8px"><button class="btn" onclick="plantillaImp()">Descargar plantilla de Excel</button>
      <label class="btn pri" style="cursor:pointer">Elegir archivo (.xlsx o .csv)<input type="file" accept=".xlsx,.csv,.txt" hidden onchange="archivoImp(this.files[0])"></label></div>
    <label class="l">O copie las celdas en Excel y péguelas aquí<textarea id="iP" rows="4" placeholder="Número	Nombre	Piso	Precio día…" oninput="clearTimeout(importarModal.t);importarModal.t=setTimeout(()=>prevImp(leerTexto(this.value)),300)"></textarea></label>
    <label class="l">Si el número ya existe<select id="iEx" onchange="prevImp()"><option value="saltar">Dejarla como está</option><option value="actualizar">Actualizarla con los datos del Excel</option></select></label>
    <div id="iPrev"></div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" id="iOk" disabled onclick="importarOk()">Importar</button>`, true);
  $('#modal .mbox').classList.add('extra');
}
function plantillaImp() {
  const filas = [COLS_IMP.map((c) => c[1]),
    ['101', 'Sencilla', 'Habitación', 'Hotel', '1', '0', '1', '0', '0', '0', '0', '1', '1', '2', 'WiFi, TV, Aire acondicionado', '250', '450', '550', '3200', '9500'],
    ['102', 'Doble', 'Habitación', 'Hotel', '1', '2', '0', '0', '0', '0', '0', '1', '1', '4', 'WiFi, TV, Agua caliente', '300', '600', '750', '4300', '12500'],
    ['D1', 'Depto. amueblado', 'Departamento', 'Departamentos del callejón', '2', '0', '0', '1', '0', '0', '1', '2', '1', '4', 'WiFi, TV, Cocina, Refrigerador, Estacionamiento', '', '', '', '5500', '15000']];
  const csv = '﻿' + filas.map((f) => f.map((x) => /[",\n]/.test(x) ? `"${x.replace(/"/g, '""')}"` : x).join(',')).join('\r\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' })); a.download = 'plantilla habitaciones Maxsel Hotel.csv'; document.body.appendChild(a); a.click(); a.remove();
  toast('Plantilla descargada (carpeta Descargas). Ábrala con Excel, llénela y guárdela.');
}
async function archivoImp(f) {
  if (!f) return;
  try {
    const filas = /\.xlsx$/i.test(f.name) ? await leerXlsx(await f.arrayBuffer()) : leerTexto(await f.text());
    $('#iP').value = ''; prevImp(filas);
  } catch (e) { toast(e.message || 'No se pudo leer el archivo', true); }
}
function prevImp(filas) {
  if (filas) prevImp.filas = filas;
  filas = prevImp.filas || [];
  const pv = $('#iPrev'), ok = $('#iOk');
  if (!filas.length) { pv.innerHTML = ''; ok.disabled = true; return; }
  let cab = filas[0].map(columnaImp), datos = filas.slice(1);
  if (!cab.includes('numero')) {
    // Sin títulos: si la primera columna parece número de habitación, se toma así
    if (filas[0].length <= 3 && filas.every((f) => String(f[0] || '').trim())) { cab = ['numero', 'nombre', 'piso']; datos = filas; }
    else { pv.innerHTML = '<div class="aviso bad">No encontré la columna <b>Número</b>. Revise que el primer renglón tenga los títulos (use la plantilla).</div>'; ok.disabled = true; return; }
  }
  const actualizar = val('iEx') === 'actualizar', vistos = new Set(), lista = [], errores = [], saltadas = [];
  datos.forEach((f, i) => {
    const r = {}; cab.forEach((k, j) => { if (k && f[j] !== undefined && String(f[j]).trim() !== '') r[k] = String(f[j]).trim(); });
    const numero = (r.numero || '').slice(0, 20);
    if (!numero) { if (Object.keys(r).length) errores.push(`Renglón ${i + 2}: sin número`); return; }
    if (vistos.has(numero.toLowerCase())) { errores.push(`Renglón ${i + 2}: el ${numero} está repetido`); return; }
    vistos.add(numero.toLowerCase());
    const ya = importarModal.ex.get(numero.toLowerCase());
    if (ya && !actualizar) { saltadas.push(numero); return; }
    const h = ya ? { ...ya, camas: { ...ya.camas }, amenidades: [...ya.amenidades] } : { ...BASE_HAB(), piso: pisoAuto(numero) };
    h.numero = numero;
    if (r.nombre !== undefined) h.nombre = r.nombre.slice(0, 60);
    if (r.clase !== undefined) h.clase = normT(r.clase).startsWith('dep') ? 'departamento' : normT(r.clase).startsWith('loc') ? 'local' : 'habitacion';
    if (r.unidad !== undefined) h.unidad = r.unidad.slice(0, 60);
    if (r.precio_visita !== undefined && puede('autorizar')) h.precio_visita = numT(r.precio_visita);
    if (r.piso !== undefined) h.piso = r.piso.slice(0, 20);
    if (cab.some((k) => k && k.startsWith('cama_'))) { h.camas = {}; for (const k of Object.keys(CAMA)) { const n = enteroT(r['cama_' + k], 0); if (n) h.camas[k] = Math.min(n, 20); } }
    if (r.recamaras !== undefined) h.recamaras = Math.max(1, enteroT(r.recamaras, 1));
    if (r.banos !== undefined) h.banos = enteroT(r.banos, 0);
    if (r.capacidad !== undefined) h.capacidad = Math.max(1, enteroT(r.capacidad, 1));
    if (r.amenidades !== undefined) h.amenidades = amenDe(r.amenidades);
    for (const k of PK()) if (cab.includes(k)) h[k] = numT(r[k]);
    h._nuevo = !ya; lista.push(h);
  });
  prevImp.lista = lista;
  const sp = lista.filter(sinPrecio).length, n = lista.filter((h) => h._nuevo).length, a = lista.length - n;
  pv.innerHTML = `<div class="aviso">${lista.length ? `Se ${n ? `crearán <b>${n}</b>` : ''}${n && a ? ' y se ' : ''}${a ? `actualizarán <b>${a}</b>` : ''} habitaciones.` : 'No hay habitaciones nuevas para importar.'}${saltadas.length ? `<br>Ya existen y se dejarán igual: ${esc(listaCorta(saltadas))}` : ''}${sp ? `<br><b>${sp} sin precio</b>: después de importar se las pido para poder rentarlas.` : ''}</div>
    ${errores.length ? `<div class="aviso bad">${errores.slice(0, 8).map(esc).join('<br>')}${errores.length > 8 ? `<br>…y ${errores.length - 8} más` : ''}</div>` : ''}
    ${lista.length ? `<div class="tw" style="max-height:300px"><table><thead><tr><th>Número</th><th>Nombre</th><th>Tipo</th><th>Piso</th><th>Incluye</th>${ORDEN_MOD.map((m) => `<th class="n">${MOD[m].replace('Por ', '')}</th>`).join('')}</tr></thead><tbody>
      ${lista.slice(0, 200).map((h) => `<tr><td><b>${esc(h.numero)}</b>${h._nuevo ? '' : ' <span class="pill">Actualizar</span>'}</td><td>${esc(h.nombre || '')}</td><td>${CLASE_C[h.clase] || 'Hab.'}</td><td>${esc(h.piso || '')}</td><td>${feats(h)}${amenIcons(h)}</td>
        ${PK().map((k) => `<td class="n">${h[k] ? money(h[k]) : '—'}</td>`).join('')}</tr>`).join('')}</tbody></table></div>${lista.length > 200 ? `<div class="sub">…y ${lista.length - 200} más</div>` : ''}` : ''}`;
  ok.disabled = !lista.length; ok.textContent = lista.length ? `Importar ${lista.length} habitaciones` : 'Importar';
}
async function importarOk() {
  const lista = (prevImp.lista || []).map(({ _nuevo, id, estado, nota, activo, estancia, visitantes, reportes, ...h }) => h);
  const r = await hacer(() => POST('/api/habitaciones/lote', { habitaciones: lista, existentes: val('iEx') }));
  const sp = lista.filter(sinPrecio).map((h) => h.numero);
  prevImp.filas = null;
  toast(`Importadas: ${r.creadas} nuevas${r.actualizadas ? `, ${r.actualizadas} actualizadas` : ''}`);
  if (sp.length) return editarVarias(sp, true);
  cerrar(); refrescarHabs();
}
