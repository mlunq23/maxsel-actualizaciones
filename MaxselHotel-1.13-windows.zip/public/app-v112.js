// Maxsel Hotel 1.12 — Comparativo de ventas (línea de tiempo y %) y reglas del depósito en garantía

// ======================================================================
// Reportes: línea de tiempo contra el periodo anterior + lectura breve
// ======================================================================
const dinCorto = (v) => (Math.abs(v) >= 1e6 ? '$' + (v / 1e6).toFixed(1) + 'M' : Math.abs(v) >= 1000 ? '$' + (v / 1000).toFixed(v >= 1e4 ? 0 : 1) + 'k' : '$' + Math.round(v));
const fCorta = (f) => { const d = aF(f); return d ? d.toLocaleDateString('es-MX', { day: 'numeric', month: 'short' }) : ''; };
function flechaPct(v, pts) {
  if (v === null || v === undefined) return '<span class="tdn-c">sin datos antes</span>';
  const s = v > 0 ? 'up' : v < 0 ? 'down' : 'eq';
  return `<span class="tdn-c ${s}">${s === 'up' ? '▲' : s === 'down' ? '▼' : '='} ${v > 0 ? '+' : ''}${v}${pts ? ' pts' : '%'}</span>`;
}
function tendenciaHTML(T) {
  const A = T.actual, B = T.anterior, n = Math.max(A.serie.length, 1);
  const ancho = ($('#main')?.clientWidth || 800) - 40, movil = ancho < 600;
  const W = movil ? 420 : 760, H = movil ? 260 : 230, L = 50, R = 14, Tp = 14, Bt = 30, w = W - L - R, h = H - Tp - Bt; tdnHover.W = W;
  const max = Math.max(1, ...A.serie.map((x) => x.total), ...B.serie.map((x) => x.total));
  const bruto = max / 4, mag = Math.pow(10, Math.floor(Math.log10(bruto))), paso = [1, 2, 2.5, 5, 10].map((k) => k * mag).find((k) => k >= bruto), top = paso * 4;
  const X = (i) => L + (n === 1 ? w / 2 : (i * w) / (n - 1)), Y = (v) => Tp + h - (v / top) * h;
  const linea = (s) => s.map((x, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)},${Y(x.total).toFixed(1)}`).join(' ');
  const grid = [0, 0.25, 0.5, 0.75, 1].map((k) => `<line x1="${L}" x2="${W - R}" y1="${Y(top * k)}" y2="${Y(top * k)}" class="tdn-grid"/><text x="${L - 6}" y="${Y(top * k) + 4}" text-anchor="end" class="tdn-ax">${dinCorto(top * k)}</text>`).join('');
  const cada = Math.max(1, Math.ceil(n / (movil ? 5 : 8))), ultimo = (n - 1) % cada === 0 || (n - 1) % cada >= cada * 0.7;
  const etq = A.serie.map((x, i) => (i % cada === 0 || (i === n - 1 && ultimo) ? `<text x="${X(i)}" y="${H - 8}" text-anchor="middle" class="tdn-ax">${T.gran === 'mes' ? aF(x.desde).toLocaleDateString('es-MX', { month: 'short' }) : fCorta(x.desde)}</text>` : '')).join('');
  const puntos = A.serie.map((x, i) => `<circle cx="${X(i)}" cy="${Y(x.total)}" r="${n > 40 ? 0 : 4}" class="tdn-pa"/>`).join('');
  const zonas = A.serie.map((x, i) => `<rect x="${X(i) - w / n / 2}" y="${Tp}" width="${Math.max(6, w / n)}" height="${h}" fill="transparent" data-i="${i}" onmouseenter="tdnHover(${i})" onmouseleave="tdnHover(-1)" ontouchstart="tdnHover(${i})"/>`).join('');
  const C = T.cambio, t = A.totales;
  const kpi = (nom, val, ch, pts) => `<div class="tdn-k"><span>${nom}</span><b>${val}</b>${flechaPct(ch, pts)}</div>`;
  const unidad = T.gran === 'dia' ? 'por día' : T.gran === 'semana' ? 'por semana' : 'por mes';
  return `<div class="card tdn" style="margin:16px 0"><div class="row" style="justify-content:space-between;align-items:baseline;flex-wrap:wrap;gap:6px">
      <h2 style="margin:0">Comparativo de ventas</h2><span class="sub">Cobrado ${unidad} · ${fd(A.desde)}${A.desde !== A.hasta ? ' al ' + fd(A.hasta) : ''} contra ${fd(B.desde)}${B.desde !== B.hasta ? ' al ' + fd(B.hasta) : ''}</span></div>
    <div class="tdn-ks">${kpi('Total cobrado', money(t.total), C.total)}${kpi('Hospedaje', money(t.hospedaje), C.hospedaje)}${kpi('Tienda', money(t.tienda), C.tienda)}${kpi('Rentas', A.rentas, C.rentas)}${kpi('Ocupación', A.ocupacion + '%', C.ocupacion, true)}${T.anio && T.anio.totales.total > 0 ? kpi('Contra el año pasado', money(T.anio.totales.total), C.anio) : ''}</div>
    <div class="tdn-ley"><span><i class="tdn-sw a"></i>Este periodo</span><span><i class="tdn-sw b"></i>Periodo anterior</span></div>
    <div class="tdn-wrap" id="tdnWrap"><svg viewBox="0 0 ${W} ${H}" class="tdn-svg" role="img" aria-label="Ventas de este periodo contra el anterior">${grid}<line id="tdnCruz" x1="0" x2="0" y1="${Tp}" y2="${Tp + h}" class="tdn-cruz" visibility="hidden"/>
      <path d="${linea(B.serie)}" class="tdn-lb"/><path d="${linea(A.serie)}" class="tdn-la"/>${puntos}${etq}${zonas}</svg><div class="tdn-tip" id="tdnTip" hidden></div></div>
    <div class="lbl" style="margin-top:10px">En pocas palabras</div><ul class="tdn-an">${T.analisis.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>
    <details style="margin-top:6px"><summary class="sub">Ver la tabla</summary><div class="tw" style="max-height:260px"><table><thead><tr><th>Este periodo</th><th class="n">Cobrado</th><th>Periodo anterior</th><th class="n">Cobrado</th><th class="n">Cambio</th></tr></thead><tbody>
      ${A.serie.map((x, i) => { const y = B.serie[i] || { total: 0 }; const c = y.total > 0 ? Math.round(((x.total - y.total) / y.total) * 1000) / 10 : null; return `<tr><td>${fCorta(x.desde)}</td><td class="n">${money(x.total)}</td><td>${y.desde ? fCorta(y.desde) : ''}</td><td class="n">${money(y.total)}</td><td class="n">${c === null ? '—' : (c > 0 ? '+' : '') + c + '%'}</td></tr>`; }).join('')}</tbody></table></div></details></div>`;
}
function tdnHover(i) {
  const T = tdnHover.T, tip = $('#tdnTip'), cruz = $('#tdnCruz'); if (!T || !tip) return;
  if (i < 0) { tip.hidden = true; cruz.setAttribute('visibility', 'hidden'); return; }
  const a = T.actual.serie[i], b = T.anterior.serie[i] || { total: 0 }, r = document.querySelector(`#tdnWrap rect[data-i="${i}"]`), x = Number(r.getAttribute('x')) + Number(r.getAttribute('width')) / 2;
  cruz.setAttribute('x1', x); cruz.setAttribute('x2', x); cruz.setAttribute('visibility', 'visible');
  const c = b.total > 0 ? Math.round(((a.total - b.total) / b.total) * 1000) / 10 : null;
  tip.innerHTML = `<b>${fCorta(a.desde)}</b><div><i class="tdn-sw a"></i>${money(a.total)}</div><div class="sub">hospedaje ${money(a.hospedaje)} · tienda ${money(a.tienda)}</div><div><i class="tdn-sw b"></i>${b.desde ? fCorta(b.desde) + ': ' : ''}${money(b.total)}</div>${c === null ? '' : `<div>${flechaPct(c)}</div>`}`;
  tip.hidden = false;
  const wr = $('#tdnWrap').getBoundingClientRect(), px = (x / (tdnHover.W || 760)) * wr.width;
  tip.style.left = Math.min(Math.max(0, px - 90), wr.width - 190) + 'px';
}
{
  const _vr = vRep;
  vRep = async function () {
    await _vr();
    try {
      const T = await GET(`/api/reporte/tendencia?desde=${rDesde}&hasta=${rHasta}`); tdnHover.T = T;
      if (vista === 'rep' && !$('.tdn')) $('#main .kpis')?.insertAdjacentHTML('afterend', tendenciaHTML(T));
    } catch { /* sin comparativo */ }
  };
}

// ======================================================================
// Depósito en garantía: leyendas en el ticket y plazo para reclamarlo
// ======================================================================
const diasDeposito = () => Math.max(1, Math.floor(Number(CFG.deposito_dias_reclamo) || 7));
const leyendaDeposito = (d) => [
  'Para solicitar la devolución del depósito, será indispensable presentar este comprobante de pago. La devolución se realizará únicamente al concluir la estancia y exclusivamente al titular del contrato.',
  'Si el ticket está roto, borrado o no se puede leer, no se devuelve el depósito.',
  `Tiene ${d?.dias_reclamo || diasDeposito()} días después de desocupar la habitación para reclamarlo. Pasado ese plazo, el depósito ya no se devuelve.`,
];
{
  const _ops = opsDeposito;
  opsDeposito = async function (d, copia) {
    const ops = await _ops(d, copia);
    if (d.tipo !== 'recibido') return ops;
    return [...ops, ['text', '-'.repeat(W())], ['align', 'center'], ['bold', true], ['text', 'IMPORTANTE'], ['bold', false], ['align', 'left'],
      ...leyendaDeposito(d).flatMap((l, i) => { const r = wrapT(l).map((x) => ['text', x]); return i === 0 ? [['bold', true], ...r, ['bold', false]] : r; })];
  };
}
// El recibo en pantalla / hoja carta también lleva las condiciones
{
  const _doc = docConCopia;
  docConCopia = function (cuerpo, formato, titulo, opsFn) {
    if (!/DEPÓSITO EN GARANTÍA/.test(titulo || '') || !docConCopia.dep) return _doc(cuerpo, formato, titulo, opsFn);
    const d = docConCopia.dep; docConCopia.dep = null;
    const ley = leyendaDeposito(d);
    const c2 = (copia) => cuerpo(copia).replace(/<div class="dc-firmas">/, `<div class="dc-cond"><b>IMPORTANTE</b><br><b>${esc(ley[0])}</b><br>${esc(ley[1])}<br>${esc(ley[2])}</div><div class="dc-firmas">`);
    return _doc(c2, formato, titulo, opsFn);
  };
  const _imp = imprimirDeposito;
  imprimirDeposito = async function (id, formato) {
    const d = await GET('/api/depositos/' + id);
    docConCopia.dep = d.tipo === 'recibido' ? d : null;
    return _imp(id, formato);
  };
}
// Al devolver: se avisa hasta cuándo puede reclamarlo
{
  const _lq = liquidarModal;
  liquidarModal = async function (id, alSalir) {
    await _lq(id, alSalir);
    try {
      const e = await GET('/api/estancias/' + id), desde = CFG.deposito_plazo_desde || '9999';
      if (e.titular_deposito && $('#lRe')) { $('#lRe').value = e.titular_deposito; $('#lRe').readOnly = true; $('#lRe').title = 'Solo se devuelve al titular del contrato'; }
      if (e.activa) $('#modal .mbody')?.insertAdjacentHTML('afterbegin', '<div class="aviso">El huésped sigue hospedado: el depósito se devuelve <b>únicamente al concluir la estancia</b> (aquí solo puede retener por daños).</div>');
      if (!e.salida_real || e.salida_real.slice(0, 10) < desde) return;
      const lim = aF(e.salida_real.slice(0, 10)); lim.setDate(lim.getDate() + diasDeposito());
      const limISO = lim.getFullYear() + '-' + String(lim.getMonth() + 1).padStart(2, '0') + '-' + String(lim.getDate()).padStart(2, '0'), vencio = hoyISO() > limISO, txt = lim.toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long' });
      $('#modal .mbody')?.insertAdjacentHTML('afterbegin', vencio
        ? `<div class="aviso" style="border-color:var(--ocup)"><b>Ya pasó el plazo para reclamar el depósito</b> (era hasta el ${txt}). Ya no se devuelve.</div>`
        : `<div class="aviso">Puede reclamar el depósito hasta el <b>${txt}</b>. Pida el ticket del depósito: sin el ticket o si no se puede leer, no se devuelve.</div>`);
    } catch { /* nada */ }
  };
}
// Configuración → Hotel: días para reclamar el depósito
{
  const _ch = cHotel;
  cHotel = async function () {
    await _ch();
    if (YO.rol !== 'admin' || $('#dpCard')) return;
    $('#cfgc .stack')?.insertAdjacentHTML('beforeend', `<div class="card" id="dpCard"><h2>Depósito en garantía</h2>
      <div class="f"><label class="l">Días para reclamarlo después de desocupar<input id="dpD" type="number" min="1" step="1" value="${diasDeposito()}"></label></div>
      <p class="sub">El ticket del depósito dice que sin el ticket (o si no se puede leer) no se devuelve, y cuántos días tiene para reclamarlo. Pasado el plazo, el sistema ya no deja devolverlo y lo pasa solo a "retenido".</p>
      <button class="btn" onclick="dpOk()">Guardar</button></div>`);
  };
}
async function dpOk() { await hacer(() => PUT('/api/config', { deposito_dias_reclamo: String(Math.max(1, Math.floor(num('dpD')) || 7)) }), 'Guardado'); CFG = await GET('/api/config'); }
