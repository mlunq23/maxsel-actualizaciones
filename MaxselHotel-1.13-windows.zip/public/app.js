// Maxsel Hotel — pantalla del sistema
'use strict';
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n) => '$' + (Number(n) || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const aF = (s) => { if (!s) return null; const [f, h = '0:0:0'] = String(s).split(' '); const [y, m, d] = f.split('-').map(Number); const [a, b, c] = h.split(':').map(Number); return new Date(y, m - 1, d, a, b, c || 0); };
const fdt = (s) => { const d = aF(s); return d ? d.toLocaleDateString('es-MX', { day: '2-digit', month: 'short' }) + ' ' + d.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' }) : '—'; };
const fd = (s) => { const d = aF(s); return d ? d.toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'; };
const hoyISO = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const val = (id) => (document.getElementById(id)?.value ?? '').trim();
const num = (id) => parseFloat(val(id)) || 0;

const MOD = { rato: 'Por rato', noche: 'Por noche', dia: 'Por día', semana: 'Por semana', mes: 'Por mes' };
const MODU = { rato: ['rato', 'ratos'], noche: ['noche', 'noches'], dia: ['día', 'días'], semana: ['semana', 'semanas'], mes: ['mes', 'meses'] };
const ORDEN_MOD = ['rato', 'noche', 'dia', 'semana', 'mes'], CORTAS = ['rato', 'noche', 'dia'], LARGAS = ['semana', 'mes'];
const horasRato = () => Number(CFG.horas_rato) || 3;
const modTxt = (m) => (m === 'rato' ? `Por rato (${horasRato()} h)` : MOD[m]);
const EST = { libre: 'Disponible', ocupada: 'Ocupada', limpieza: 'En limpieza', mant: 'Mantenimiento' };
const MET = { efectivo: 'Efectivo', dolares: 'Dólares', tarjeta: 'Tarjeta', transferencia: 'Transferencia', mixto: 'Mixto', habitacion: 'Cargo a habitación' };
const ROL = { admin: 'Administrador', gerente: 'Gerente', recepcion: 'Recepción', monitor: 'Monitoreo (solo ver)', mantenimiento: 'Mantenimiento' };
const unidad = (m, n) => n + ' ' + MODU[m][n === 1 ? 0 : 1];
// 1.8 Tipos de espacio y unidades de negocio
const CLASE = { habitacion: 'Habitación', departamento: 'Departamento', local: 'Local comercial' }, CLASE_C = { habitacion: 'Hab.', departamento: 'Depto.', local: 'Local' };
const unidadesCfg = () => String(CFG.unidades_negocio || 'Hotel').split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
const unidadDe = (h) => h.unidad || (h.clase === 'local' ? (unidadesCfg().find((x) => /local/i.test(x)) || 'Locales comerciales') : (unidadesCfg()[0] || 'Hotel'));
const TIPOS_CARGO = { consumo: 'Consumo', multa: 'Multa', mora: 'Interés moratorio', limpieza: 'Cuota de limpieza', mascota: 'Cuota por mascota', otro: 'Otro cargo' };
const multasCfg = () => String(CFG.multas_lista || '').split(/\r?\n/).map((l) => { const m = l.match(/^(.*?)[:=]\s*\$?\s*([\d.,]+)\s*$/); return m ? { nombre: m[1].trim(), monto: parseFloat(m[2].replace(/,/g, '')) || 0 } : l.trim() ? { nombre: l.trim(), monto: 0 } : null; }).filter(Boolean);

// ---------- Iconos ----------
const P = {
  wifi: '<path d="M2 9a15 15 0 0 1 20 0"/><path d="M5 12.5a10 10 0 0 1 14 0"/><path d="M8.5 16a5 5 0 0 1 7 0"/><circle cx="12" cy="19.5" r=".8"/>',
  tv: '<rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8M12 17v4"/>',
  ac: '<path d="M12 2v20M3.3 7l17.4 10M20.7 7 3.3 17"/><path d="m9 4 3 2 3-2M9 20l3-2 3 2"/>',
  ventilador: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="1.5"/><path d="M12 10.5V4M13.3 12.8l5.6 3.2M10.7 12.8 5.1 16"/>',
  agua: '<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/><path d="M9.5 15a2.5 2.5 0 0 0 2.5 2.5"/>',
  cocina: '<rect x="4" y="10" width="16" height="9" rx="2"/><path d="M2 10h20M9 5.5v2M12 4.5v3M15 5.5v2"/>',
  scan: '<path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/><path d="M7 8v8M10 8v8M13 8v8M16 8v8"/>',
  parrilla: '<rect x="3" y="7" width="18" height="12" rx="2"/><circle cx="8.5" cy="13" r="3"/><circle cx="15.5" cy="13" r="3"/><circle cx="8.5" cy="13" r="1"/><circle cx="15.5" cy="13" r="1"/><path d="M6 4l1 2M12 3.5v2.5M18 4l-1 2"/>',
  local: '<path d="M3 9l1.5-5h15L21 9"/><path d="M3 9a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0"/><path d="M5 12v9h14v-9M10 21v-5h4v5"/>',
  refri: '<rect x="6" y="2" width="12" height="20" rx="2"/><path d="M6 9h12M9 5v2M9 12v3"/>',
  micro: '<rect x="2" y="5" width="20" height="14" rx="2"/><rect x="5" y="8" width="10" height="8" rx="1"/><path d="M18 9v.01M18 12v.01M18 15v.01"/>',
  minibar: '<path d="M8 3h8l-1 7a3 3 0 0 1-6 0z"/><path d="M12 13v7M8 21h8"/>',
  jacuzzi: '<path d="M3 12h18v3a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4z"/><path d="M6 12V6a2 2 0 0 1 4 0M7 19l-1 2M17 19l1 2"/>',
  estacionamiento: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M9 17V7h4a3 3 0 0 1 0 6H9"/>',
  lavadora: '<rect x="4" y="2" width="16" height="20" rx="2"/><circle cx="12" cy="13" r="5"/><path d="M8 6h.01M11 6h.01"/>',
  balcon: '<path d="M3 21h18M5 21v-8h14v8M9 13v8M12 13v8M15 13v8M7 13V6a5 5 0 0 1 10 0v7"/>',
  mascotas: '<circle cx="7" cy="9" r="1.8"/><circle cx="12" cy="6.5" r="1.8"/><circle cx="17" cy="9" r="1.8"/><path d="M8 17c0-3 2-5 4-5s4 2 4 5c0 2-2 2.5-4 2.5S8 19 8 17z"/>',
  cama: '<path d="M3 18v-6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6M3 15h18M3 18v2M21 18v2M6 10V7a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v3"/>',
  recamara: '<path d="M5 21V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v17M3 21h18M15 12h.01"/>',
  bano: '<path d="M4 21V6a3 3 0 0 1 6 0"/><path d="M7 8h7M10 12v1M13 12v1M16 12v1M11.5 15v1M14.5 15v1"/>',
  personas: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 5a3 3 0 0 1 0 6M18 20a6 6 0 0 0-2.5-5"/>',
  edificio: '<rect x="4" y="3" width="16" height="18" rx="1"/><path d="M9 7h.01M15 7h.01M9 11h.01M15 11h.01M9 15h.01M15 15h.01M10 21v-3h4v3"/>',
};
const ico = (k, t) => `<svg class="i" viewBox="0 0 24 24" aria-hidden="true">${P[k] || ''}</svg>`;
const AMEN = { wifi: 'WiFi', tv: 'Televisión', ac: 'Aire acondicionado', ventilador: 'Ventilador', agua: 'Agua caliente', cocina: 'Cocina / cocineta', parrilla: 'Parrilla / estufa eléctrica', refri: 'Refrigerador', micro: 'Microondas', minibar: 'Minibar', jacuzzi: 'Jacuzzi', estacionamiento: 'Estacionamiento', lavadora: 'Lavadora', balcon: 'Balcón', mascotas: 'Acepta mascotas' };
const CAMA = { individual: 'Individual', matrimonial: 'Matrimonial', queen: 'Queen', king: 'King', litera: 'Litera', sofacama: 'Sofá cama' };
const totalCamas = (c) => Object.values(c || {}).reduce((s, n) => s + n, 0);
const textoCamas = (c) => Object.entries(c || {}).map(([k, n]) => n + ' ' + CAMA[k].toLowerCase()).join(', ') || 'Sin camas';
function feats(h) {
  const t = [`<span title="${esc(textoCamas(h.camas))}">${ico('cama')}${totalCamas(h.camas)}</span>`];
  if (h.clase === 'departamento' || h.recamaras > 1) t.push(`<span title="Recámaras">${ico('recamara')}${h.recamaras}</span>`);
  if (h.banos) t.push(`<span title="Baños">${ico('bano')}${h.banos}</span>`);
  t.push(`<span title="Capacidad">${ico('personas')}${h.capacidad}</span>`);
  return `<div class="feats">${t.join('')}</div>`;
}
const amenIcons = (h) => (h.amenidades || []).length ? `<div class="amen">${h.amenidades.map((a) => `<span title="${esc(AMEN[a])}">${ico(a)}</span>`).join('')}</div>` : '';

// ---------- Estado ----------
let fUni = '', tArea = '', YO = null, CFG = {}, vista = 'hab', filtro = 'todas', carrito = [], timer = null, cfgTab = 'hotel';
let rDesde = hoyISO(), rHasta = hoyISO(), hDesde = hoyISO(), hHasta = hoyISO(), hBus = '', qProd = '';
// Permisos del usuario (los da el administrador en Configuración → Usuarios). Acepta varias claves separadas por |
const puede = (r) => {
  if (!YO) return false;
  const P = new Set(YO.permisos || []);
  return String(r).split('|').some((k) => (k === 'operar' ? P.has('registrar') || P.has('caja') : k === 'admin' ? P.has('config') : k === 'mant' ? P.has('mant_reportar') || P.has('mant_atender') : P.has(k)));
};

async function api(metodo, url, body) {
  const r = await fetch(url, { method: metodo, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined, credentials: 'same-origin' });
  let d = {}; try { d = await r.json(); } catch { /* sin cuerpo */ }
  if (r.status === 402) { pantallaLicencia(); throw new Error(d.error); }
  if (r.status === 401 && !url.endsWith('/login')) { YO = null; pantallaLogin(); throw new Error(d.error); }
  if (!r.ok) throw new Error(d.error || 'Error ' + r.status);
  return d;
}
const GET = (u) => api('GET', u), POST = (u, b = {}) => api('POST', u, b), PUT = (u, b) => api('PUT', u, b), DEL = (u) => api('DELETE', u);
async function hacer(fn, ok) { try { const r = await fn(); if (ok) toast(ok); return r; } catch (e) { toast(e.message, true); throw e; } }

function toast(m, bad) { const t = $('#toast'); t.textContent = m; t.className = bad ? 'bad' : ''; t.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => (t.hidden = true), bad ? 4500 : 2600); }
function modal(titulo, cuerpo, pie, ancho) {
  $('#modal').innerHTML = `<div class="mbox ${ancho ? 'ancho' : ''}" role="dialog" aria-modal="true"><header><h3>${titulo}</h3><button onclick="cerrar()" aria-label="Cerrar">×</button></header><div class="mbody">${cuerpo}</div>${pie ? `<footer>${pie}</footer>` : ''}</div>`;
  $('#modal').hidden = false; delete $('#modal').dataset.sucio;
  const f = $('#modal input:not([type=radio]):not([type=checkbox]):not([type=color]),#modal select'); if (f) f.focus();
}
function cerrar() { $('#modal').hidden = true; $('#modal').innerHTML = ''; }
function confirmar(btn, fn) { if (btn.dataset.armado) { fn(); return; } btn.dataset.armado = 1; const t = btn.innerHTML; btn.textContent = '¿Seguro? Toque otra vez'; setTimeout(() => { if (btn.isConnected) { delete btn.dataset.armado; btn.innerHTML = t; } }, 3500); }
// 1.8: tocar fuera de la ventana ya NO la cierra (para no perder lo que se está capturando).
// Esc solo la cierra si no se ha escrito nada; si ya hay datos se cierra con Cancelar o la ×.
$('#modal').addEventListener('input', () => { $('#modal').dataset.sucio = '1'; });
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape' || $('#modal').hidden) return;
  if ($('#modal').dataset.sucio) { toast('Para cerrar sin guardar use el botón Cancelar o la ×'); return; }
  cerrar();
});
$('#modal').addEventListener('click', (e) => { if (e.target.id === 'modal') { const b = $('#modal .mbox'); b?.classList.remove('avisa'); void b?.offsetWidth; b?.classList.add('avisa'); } });

function aplicarColores() {
  const r = document.documentElement.style, D = { rato: '#0d9488', noche: '#4f46e5', dia: '#2563eb', semana: '#e07a10', mes: '#b4237a' };
  for (const m of ORDEN_MOD) r.setProperty('--m-' + m, CFG['color_' + m] || D[m]);
  const C = { libre: [CFG.color_libre, '#1b845a'], limp: [CFG.color_limpieza, '#b77a06'], mant: [CFG.color_mant, '#6550b8'] };
  for (const [k, [v, d]] of Object.entries(C)) { r.setProperty('--' + k, v || d); r.setProperty('--' + k + 'Bg', `color-mix(in srgb, ${v || d} 14%, var(--panel))`); }
  r.setProperty('--porvencer', CFG.color_porvencer || '#ea580c'); r.setProperty('--vencida', CFG.color_vencida || '#c03434');
  document.body.classList.toggle('sin-contratos', CFG.modulo_contratos === '0');
}

// ---------- Acceso ----------
async function inicio() {
  try {
    const l = await GET('/api/licencia/estado');
    if (!l.activa) return pantallaLicencia(l);
    YO = await GET('/api/yo');
    CFG = await GET('/api/config'); aplicarColores();
    marco(); pintarTurno(); ir(vista);
  } catch { /* api ya mostró la pantalla correspondiente */ }
}
function pantallaLogin() {
  clearInterval(timer);
  $('#raiz').innerHTML = `<div class="acceso"><form class="card" id="flog"><img src="logo.png" alt="Maxsel"><h1 style="text-align:center">Maxsel Hotel</h1>
    <label class="l">Usuario<input id="lu" autocomplete="username" autocapitalize="off"></label>
    <label class="l">Contraseña<input id="lp" type="password" autocomplete="current-password"></label>
    <button class="btn pri" style="justify-content:center">Entrar</button><div id="lerr"></div></form></div>`;
  $('#lu').focus();
  $('#flog').onsubmit = async (e) => {
    e.preventDefault();
    try { await POST('/api/login', { usuario: val('lu'), password: $('#lp').value }); inicio(); }
    catch (er) { $('#lerr').innerHTML = `<div class="aviso bad">${esc(er.message)}</div>`; }
  };
}
async function pantallaLicencia(l) {
  clearInterval(timer);
  if (!l) try { l = await (await fetch('/api/licencia/estado')).json(); } catch { l = {}; }
  $('#raiz').innerHTML = `<div class="acceso"><div class="card"><img src="logo.png" alt="Maxsel"><h1 style="text-align:center">Activar el sistema</h1>
    ${l.motivo && l.motivo !== 'Sin licencia' ? `<div class="aviso bad">${esc(l.motivo)}</div>` : ''}
    <p class="sub" style="margin:0">Envíe este código de equipo a Maxsel para recibir su licencia:</p>
    <div class="codigo" id="codeq">${esc(l.codigoEquipo || '')}</div>
    <button class="btn" onclick="copiar('${esc(l.codigoEquipo || '')}')">Copiar código</button>
    <label class="l">Licencia (empieza con HT1-)<textarea id="lic" rows="4" style="font-family:var(--fMono)"></textarea></label>
    <button class="btn pri" style="justify-content:center" onclick="activar()">Activar</button>
    <div class="sub">Huella: <b>${esc(l.huella || '')}</b> · Maxsel Sistemas de Punto de Venta</div></div></div>`;
}
async function activar() {
  try { await POST('/api/licencia/activar', { clave: val('lic') }); toast('Licencia activada'); inicio(); }
  catch (e) { toast(e.message, true); }
}
function copiar(t) {
  (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast('Copiado')).catch(() => {
    const r = document.createRange(); const el = $('#codeq'); if (el) { r.selectNodeContents(el); getSelection().removeAllRanges(); getSelection().addRange(r); } toast('Seleccionado: presione Ctrl+C');
  });
}
async function salir() { try { await POST('/api/logout'); } catch { /* nada */ } YO = null; pantallaLogin(); }

// ---------- Marco ----------
const VISTAS = [['hab', 'Habitaciones'], ['caja', 'Caja', 'caja|cortes'], ['vis', 'Visitantes'], ['tienda', 'Tienda', 'vender'], ['inv', 'Inventario'], ['gastos', 'Gastos', 'gastos|reportes'], ['contratos', 'Contratos'], ['mant', 'Mantenimiento'], ['hues', 'Huéspedes'], ['rep', 'Reportes', 'reportes'], ['cfg', 'Configuración']];
function marco() {
  document.body.classList.toggle('solover', YO.rol === 'monitor');
  $('#raiz').innerHTML = `<div class="app"><aside><div class="brand"><img src="logo.png" alt="Maxsel"><small>Hotel · ${esc(CFG.hotel_nombre)}</small></div>
    <nav class="nav" id="nav"></nav><div id="turnoBar" class="turnoBar"></div><div class="pie"><span>${esc(YO.nombre)} · ${ROL[YO.rol]}</span><button onclick="salir()">Salir</button></div></aside><main id="main"></main></div>`;
  pintarNav();
}
function pintarNav(badge = {}) {
  const lista = YO.rol === 'mantenimiento' ? VISTAS.filter((v) => v[0] === 'mant' || v[0] === 'cfg') : VISTAS.filter((v) => (!v[2] || puede(v[2])) && !(v[0] === 'contratos' && CFG.modulo_contratos === '0'));
  $('#nav').innerHTML = lista.map(([k, n]) => `<button class="${vista === k ? 'on' : ''}" onclick="ir('${k}')">${n}${badge[k] ? `<span class="cnt">${badge[k]}</span>` : ''}</button>`).join('');
}
async function ir(v) {
  vista = v; clearInterval(timer); pintarNav(ir.badge);
  if (YO.rol === 'mantenimiento' && v !== 'cfg') v = vista = 'mant';
  const fn = { hab: vHab, caja: vCaja, vis: vVis, tienda: vTienda, inv: vInv, gastos: vGastos, contratos: vContratos, mant: vMant, hues: vHues, rep: vRep, cfg: vCfg }[v];
  try { await fn(); } catch (e) { if (e.message) $('#main').innerHTML = `<div class="aviso bad">${esc(e.message)}</div>`; }
  if (v === 'hab' || v === 'rep' || v === 'vis' || v === 'mant') timer = setInterval(() => { if ($('#modal').hidden) fn().catch(() => {}); }, 20000);
  if (window.innerWidth < 760) window.scrollTo(0, 0);
}
const cab = (t, s, acc = '') => `<div class="top"><div><h1>${t}</h1>${s ? `<div class="sub">${s}</div>` : ''}</div><div class="row">${acc}</div></div>`;
const sortH = (a) => a.slice().sort((x, y) => String(x.numero).localeCompare(String(y.numero), 'es', { numeric: true }));

// ---------- Habitaciones ----------
let TAB = null;
async function vHab() {
  TAB = await GET('/api/tablero'); CFG = { ...CFG, ...TAB.config }; aplicarColores();
  const UN = [...new Set([...unidadesCfg(), ...TAB.habitaciones.map(unidadDe)])].filter((u) => TAB.habitaciones.some((h) => unidadDe(h) === u));
  if (fUni && !UN.includes(fUni)) fUni = '';
  const H = TAB.habitaciones.filter((h) => !fUni || unidadDe(h) === fUni), c = { todas: H.length, libre: 0, ocupada: 0, limpieza: 0, mant: 0 }; H.forEach((h) => c[h.estado]++);
  ir.badge = { ...(ir.badge || {}), hab: c.ocupada + '/' + c.todas }; pintarNav(ir.badge);
  const st = [['todas', 'Todas'], ['libre', 'Disponibles'], ['ocupada', 'Ocupadas'], ['limpieza', 'En limpieza'], ['mant', 'Mantenimiento']]
    .map(([k, n]) => `<button class="st ${filtro === k ? 'on' : ''}" data-s="${k}" onclick="filtro='${k}';vHab()"><b>${c[k]}</b><span>${n}</span></button>`).join('');
  const lista = sortH(H.filter((h) => filtro === 'todas' || h.estado === filtro));
  const pisos = [...new Set(lista.map((h) => h.piso || ''))].sort((a, b) => a.localeCompare(b, 'es', { numeric: true }));
  const ahora = new Date();
  const tarjetas = (arr) => arr.map((h) => {
    const e = h.estancia; let extra = '', cls = 's-' + h.estado;
    if (h.estado === 'ocupada' && e) {
      const falta = aF(e.salida_prevista) - ahora, tarde = falta < 0;
      const pronto = !tarde && falta <= (LARGAS.includes(e.modalidad) ? (Number(CFG.aviso_dias) || 1) * 86400000 : (Number(CFG.aviso_horas) || 1) * 3600000);
      cls = 'ocupada m-' + e.modalidad + (tarde ? ' vencida' : pronto ? ' porvencer' : '');
      extra = `<span class="who">${esc(e.huesped)}</span><span class="pill mod m-${e.modalidad}">${MOD[e.modalidad]}</span>${pronto ? '<span class="pill pv">Por vencer</span>' : ''}
        <span class="out ${tarde ? 'late' : pronto ? 'pronto' : ''}">${tarde ? 'Salida vencida ' : 'Sale '}${fdt(e.salida_prevista)}</span>
        ${e.cobros_auto > 0 ? `<span class="out" style="color:var(--vencida);font-weight:700">Se cobró ${e.cobros_auto} ${MODU[e.modalidad][e.cobros_auto === 1 ? 0 : 1]} extra</span>` : ''}${e.saldo > 0 ? `<span class="out" style="color:var(--ocup)">Debe ${money(e.saldo)}</span>` : ''}${h.visitantes ? `<span class="out">${h.visitantes} visitante(s)</span>` : ''}`;
    } else extra = `<span class="pill">${EST[h.estado]}</span>${h.estado === 'mant' && h.nota ? `<span class="out">${esc(h.nota)}</span>` : ''}`;
    return `<button class="tag ${cls}" onclick="abrirHab(${h.id})"><div class="cab"><span class="num">${esc(h.numero)}</span><span class="clase ${h.clase === 'departamento' ? 'depto' : h.clase === 'local' ? 'depto local' : ''}">${CLASE_C[h.clase] || 'Hab.'}</span></div>
      ${h.nombre ? `<span class="nom">${esc(h.nombre)}</span>` : ''}${feats(h)}${amenIcons(h)}${extra}${h.reportes ? `<span class="out" style="color:var(--mant);font-weight:700">${ico('llave')} ${h.reportes} reporte(s) de mantenimiento</span>` : ''}</button>`;
  }).join('');
  const cuerpo = lista.length ? pisos.map((p) => `<div class="floor">${pisos.length > 1 || p ? `<h3>${p ? 'Piso ' + esc(p) : 'Sin piso'}</h3>` : ''}<div class="grid">${tarjetas(lista.filter((h) => (h.piso || '') === p))}</div></div>`).join('')
    : `<div class="card empty">${H.length ? 'No hay habitaciones con este estado.' : 'Aún no hay habitaciones. ' + (puede('habitaciones') ? 'Use "Agregar varias habitaciones" o "Importar de Excel" (arriba), o agréguelas en Configuración → Habitaciones.' : 'Pida al administrador que las agregue.')}</div>`;
  $('#main').innerHTML = cab('Habitaciones', esc(CFG.hotel_nombre) + ' · salida ' + esc(CFG.hora_salida) + ' h · se actualiza sola', puede('habitaciones') ? '<button class="btn" onclick="importarModal()">Importar de Excel</button><button class="btn" onclick="loteModal()">Agregar varias habitaciones</button>' : '')
    + (UN.length > 1 ? `<div class="tabs unidades" style="margin-bottom:12px"><button class="${!fUni ? 'on' : ''}" onclick="fUni='';vHab()">Todas</button>${UN.map((u) => `<button class="${fUni === u ? 'on' : ''}" onclick="fUni=this.dataset.u;vHab()" data-u="${esc(u)}">${esc(u)} <small>${TAB.habitaciones.filter((h) => unidadDe(h) === u).length}</small></button>`).join('')}</div>` : '')
    + `<div class="states">${st}</div><div class="leyenda">${ORDEN_MOD.map((m) => `<span><i style="background:var(--m-${m})"></i>${MOD[m]}</span>`).join('')}<span><i style="background:var(--porvencer)"></i>Por vencer</span><span><i style="background:var(--vencida)"></i>Vencida</span></div>` + cuerpo;
}
function abrirHab(id) {
  const h = TAB.habitaciones.find((x) => x.id === id); if (!h) return;
  if (h.estado === 'ocupada' && h.estancia) return verEstancia(h.estancia.id);
  const info = `<div class="row" style="justify-content:space-between"><div>${feats(h)}</div><span class="pill s-${h.estado}">${EST[h.estado]}</span></div>${amenIcons(h)}
    <div class="sub">${esc(textoCamas(h.camas))}${(h.amenidades || []).length ? ' · ' + h.amenidades.map((a) => AMEN[a]).join(', ') : ''}</div>
    <div class="kv">${ORDEN_MOD.filter((m) => h['precio_' + m] > 0).map((m) => `<span>${modTxt(m)}</span><b>${money(h['precio_' + m])}</b>`).join('') || '<span>Sin precios</span><b>—</b>'}</div>`;
  const t = `${CLASE[h.clase] || 'Habitación'} ${esc(h.numero)}${h.nombre ? ' · ' + esc(h.nombre) : ''}`;
  if (h.estado === 'libre') return modal(t, info, `<button class="btn op" onclick="mantNuevo(${id})">Reportar desperfecto</button><button class="btn op" onclick="estado(${id},'limpieza')">Mandar a limpieza</button><button class="btn pri op" onclick="registrar(${id})">Registrar huésped</button>`);
  if (h.estado === 'limpieza') return modal(t, info + '<div class="aviso">Está en limpieza. Márquela lista cuando camarista termine.</div>', `<button class="btn op" onclick="mantNuevo(${id})">Reportar desperfecto</button><button class="btn ok op" onclick="estado(${id},'libre')">Limpia y lista</button>`);
  modal(t, info + `<div class="aviso">En mantenimiento: <b>${esc(h.nota || 'sin detalle')}</b>${h.reportes ? ` · ${h.reportes} reporte(s) abierto(s). Al marcarlos como reparados en Mantenimiento, la habitación se libera sola.` : ''}</div>`, `<button class="btn" onclick="cerrar();ir('mant')">Ver reportes</button><button class="btn op" onclick="estado(${id},'limpieza')">Reparada, pasar a limpieza</button><button class="btn ok op" onclick="estado(${id},'libre')">Reparada y lista</button>`);
}
async function estado(id, e, nota) { await hacer(() => POST(`/api/habitaciones/${id}/estado`, { estado: e, nota }), EST[e]); cerrar(); vHab(); }
function mantModal(id) { modal('¿Qué se necesita reparar?', `<label class="l">Detalle<input id="mn" placeholder="Ej. no enfría el clima"></label>`, `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="estado(${id},'mant',val('mn'))">Mandar a mantenimiento</button>`); }

// Registro del huésped en la habitación
function registrar(id) {
  const h = TAB.habitaciones.find((x) => x.id === id), pr = Object.fromEntries(ORDEN_MOD.map((m) => [m, h['precio_' + m]]));
  const def = ORDEN_MOD.find((m) => pr[m] > 0);
  const opc = (ms) => `<div class="seg">${ms.map((m) => `<label class="m-${m}"><input type="radio" name="rM" value="${m}" ${m === def ? 'checked' : ''} ${pr[m] > 0 ? '' : 'disabled'} onchange="rCalc(${id},1)"><span><i class="dot"></i>${modTxt(m)}</span><small>${pr[m] > 0 ? money(pr[m]) : 'Sin precio'}</small></label>`).join('')}</div>`;
  modal(`Registrar huésped · ${esc(h.numero)}`, `
    <div class="f"><label class="l" style="grid-column:1/-1">Nombre del huésped<input id="rH" autocomplete="off"></label>
      <label class="l">Teléfono<input id="rT" inputmode="tel"></label><label class="l">Identificación<input id="rI" placeholder="INE, pasaporte, licencia…"></label>
      <label class="l">Procedencia<input id="rP" placeholder="Ciudad"></label><label class="l">Placas del vehículo<input id="rV"></label>
      <label class="l">Personas<input id="rN" type="number" min="1" value="1"></label><label class="l" style="grid-column:1/-1">Domicilio (para contrato)<input id="rD" placeholder="Calle, número, colonia, ciudad"></label></div>
    <div class="lbl">Tipo de renta · por horas, noche o día</div>${opc(CORTAS)}<div class="lbl">Larga estancia · semana o mes</div>${opc(LARGAS)}
    <div class="f"><label class="l">Cantidad<input id="rC" type="number" min="1" value="1" oninput="rCalc(${id})"></label><label class="l">Hora de check out<input id="rSal" type="time" oninput="this.dataset.t=1;rCalc(${id})"></label><label class="l">Precio unitario<input id="rU" type="number" min="0" step="0.01" oninput="rCalc(${id})"></label>
      <label class="l">Anticipo / pago<input id="rA" type="number" min="0" step="0.01" oninput="this.dataset.t=1;rCalc(${id})"></label><div class="l">Método de pago${selPago('rF', null, '', 'rA')}</div></div>
    <div class="f"><label class="l">Mascotas${Number(CFG.cuota_mascota) > 0 ? ` (${money(CFG.cuota_mascota)} c/u)` : ''}<input id="rMas" type="number" min="0" max="10" value="0" oninput="rCalc(${id})"></label></div>
    <div class="f"><label class="l">Depósito en garantía<input id="rDep" type="number" min="0" step="0.01" placeholder="0.00"></label><div class="l">Depósito: método de pago${selPago('rDepF', null, '', 'rDep')}</div></div>
    <label class="l">Notas<input id="rO"></label><div class="calc" id="rRes"></div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="rOk(${id})">Registrar entrada</button>`);
  $('#rH').focus(); rCalc(id, 1);
}
const fSal = (d) => d.toLocaleDateString('es-MX', { weekday: 'short', day: '2-digit', month: 'short' }) + ' ' + d.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });
function salidaCalc(m, n, desde) {
  const d = desde ? new Date(desde) : new Date();
  if (m === 'rato') { d.setMinutes(d.getMinutes() + Math.round(horasRato() * 60) * n); return d; }
  if (m === 'dia' && CFG.dia_24h === '1') { d.setDate(d.getDate() + n); return d; }
  if (m === 'noche') { d.setDate(d.getDate() + n); const [a, b] = String(CFG.hora_salida_noche || '12:00').split(':').map(Number); d.setHours(a, b, 0, 0); return d; }
  if (m === 'mes') { const dia = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + n); d.setDate(Math.min(dia, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate())); } else d.setDate(d.getDate() + (m === 'semana' ? 7 : 1) * n);
  const [a, b] = String(CFG.hora_salida || '13:00').split(':').map(Number); d.setHours(a, b, 0, 0); return d;
}
// Salida con la hora de check out que eligieron (igual que el servidor)
function salidaConHora(m, n, hora) {
  const [a, b] = String(hora || '').split(':').map(Number); if (isNaN(a)) return salidaCalc(m, n);
  if (m === 'rato') { const ya = new Date(), d = new Date(); d.setHours(a, b || 0, 0, 0); if (d <= ya) d.setDate(d.getDate() + 1); return d; }
  const d = new Date();
  if (m === 'mes') { const dia = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + n); d.setDate(Math.min(dia, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate())); }
  else d.setDate(d.getDate() + (m === 'semana' ? 7 : 1) * n);
  d.setHours(a, b || 0, 0, 0); return d;
}
function rCalc(id, reset) {
  const h = TAB.habitaciones.find((x) => x.id === id), m = document.querySelector('input[name=rM]:checked')?.value;
  if (!m) { $('#rRes').innerHTML = '<span>Esta habitación no tiene precios.</span>'; return; }
  if (reset) { $('#rU').value = h['precio_' + m]; delete $('#rSal').dataset.t; const lm = $('#rLim'); if (lm && !lm.dataset.toc) lm.checked = lm.dataset.auto === 'todas' || (lm.dataset.auto === 'largas' && LARGAS.includes(m)); }
  const n = Math.max(1, parseInt(val('rC')) || 1), u = num('rU'), lim = $('#rLim')?.checked ? Number(CFG.cuota_limpieza) || 0 : 0, mas = Math.max(0, parseInt(val('rMas')) || 0) * (Number(CFG.cuota_mascota) || 0), tot = n * u + lim + mas;
  if (!$('#rA').dataset.t) $('#rA').value = tot.toFixed(2);
  // Hora de check out: se propone la normal del tipo de renta y el recepcionista la cambia si el huésped sale a otra hora
  let s = salidaCalc(m, n);
  if (!$('#rSal').dataset.t) $('#rSal').value = String(s.getHours()).padStart(2, '0') + ':' + String(s.getMinutes()).padStart(2, '0');
  else s = salidaConHora(m, n, val('rSal'));
  const pend = tot - num('rA');
  $('#rRes').innerHTML = `<span>${unidad(m, n)} × ${money(u)}</span><b>${money(n * u)}</b>${lim ? `<span>Cuota de limpieza</span><b>${money(lim)}</b>` : ''}${mas ? `<span>Cuota por mascota</span><b>${money(mas)}</b>` : ''}<span>Total</span><b class="big">${money(tot)}</b><span>Check out</span><b>${fSal(s)}</b><span>Queda por pagar</span><b style="color:${pend > 0 ? 'var(--ocup)' : 'var(--libre)'}">${money(Math.max(0, pend))}</b>`;
}
async function rOk(id) {
  const m = document.querySelector('input[name=rM]:checked')?.value;
  const r = await hacer(() => POST('/api/estancias', { habitacion_id: id, huesped: val('rH'), telefono: val('rT'), identificacion: val('rI'), procedencia: val('rP'), placas: val('rV'), personas: val('rN'), modalidad: m, cantidad: val('rC'), hora_checkout: $('#rSal').dataset.t ? val('rSal') : '', precio: val('rU'), limpieza: $('#rLim') ? $('#rLim').checked : undefined, mascotas: val('rMas'), pago: val('rA'), ...pagoDe('rF'), notas: val('rO'), domicilio: val('rD'), deposito: val('rDep'), ...pagoDe('rDepF', '_deposito') }), 'Huésped registrado');
  await vHab(); imprimirEstancia(r.id, 'ENTRADA', r.pago);
}

// Cuenta del huésped
async function verEstancia(id) {
  const e = await GET('/api/estancias/' + id), h = e.habitacion, tarde = e.activa && aF(e.salida_prevista) < new Date();
  const dentro = e.visitantes.filter((v) => !v.salida);
  modal(`${CLASE_C[h.clase] || 'Hab.'} ${esc(h.numero)} · Folio ${esc(e.folio)}`, `
    <div class="row"><span class="pill mod m-${e.modalidad}">${MOD[e.modalidad]}</span>${tarde ? '<span class="pill p-bad">Salida vencida</span>' : ''}${!e.activa ? '<span class="pill">Ya salió</span>' : ''}</div>
    ${e.cobros_auto > 0 ? `<div class="aviso bad">No se registró la salida a tiempo: el sistema cobró solo <b>${e.cobros_auto} ${MODU[e.modalidad][e.cobros_auto === 1 ? 0 : 1]}</b> más (${money(e.cobros_auto * e.precio)}). Ya está sumado al saldo.</div>` : ''}
    <div class="kv"><span>Huésped</span><b>${esc(e.huesped)}</b><span>Teléfono</span><span>${esc(e.telefono || '—')}</span><span>Identificación</span><span>${esc(e.identificacion || '—')}</span>
      <span>Procedencia</span><span>${esc(e.procedencia || '—')}</span><span>Placas</span><span class="mono">${esc(e.placas || '—')}</span><span>Personas</span><span>${e.personas}</span>
      <span>Entrada</span><span>${fdt(e.entrada)}</span><span>${e.salida_real ? 'Salió' : 'Check out'}</span><span>${e.salida_real ? fdt(e.salida_real) : fdt(e.salida_prevista)}</span><span>Renta</span><span>${unidad(e.modalidad, e.cantidad)} × ${money(e.precio)}</span>
      ${e.notas ? `<span>Notas</span><span>${esc(e.notas)}</span>` : ''}</div>
    <div><div class="row" style="justify-content:space-between"><div class="lbl">Consumos, multas y cuotas</div>${e.activa && puede('registrar') ? `<button class="btn sm op" onclick="cargoModal(${e.id})">Multa o cargo</button>` : ''}</div>${e.cargos.length ? `<div class="tw"><table><tbody>${e.cargos.map((c) => `<tr><td>${c.tipo && c.tipo !== 'consumo' ? `<span class="pill ct-${c.tipo}">${TIPOS_CARGO[c.tipo] || c.tipo}</span> ` : ''}${c.cantidad > 1 ? c.cantidad + ' × ' : ''}${esc(c.descripcion)}</td><td class="sub">${fdt(c.fecha)}</td><td class="n">${money(c.importe)}</td><td>${e.activa && c.tipo && c.tipo !== 'consumo' && !c.venta_id && puede('autorizar') ? `<button class="btn sm bad" onclick="confirmar(this,()=>cargoQuitar(${c.id},${e.id}))">Quitar</button>` : ''}</td></tr>`).join('')}</tbody></table></div>` : '<div class="sub">Sin consumos ni cargos.</div>'}</div>
    <div><div class="lbl">Pagos</div>${e.pagos.length ? `<div class="tw"><table><tbody>${e.pagos.map((p) => `<tr><td>${fdt(p.fecha)}</td><td>${MET[p.metodo]}</td><td class="sub">${esc(p.nota || '')}</td><td class="n">${money(p.monto)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="sub">Sin pagos.</div>'}</div>
    <div><div class="lbl">Visitantes dentro</div>${dentro.length ? dentro.map((v) => `<div class="row" style="justify-content:space-between"><span>${esc(v.nombre)} <span class="sub">desde ${fdt(v.entrada)}</span></span><button class="btn sm op" onclick="visSalida(${v.id},${e.id})">Registrar salida</button></div>`).join('') : '<div class="sub">Ninguno.</div>'}</div>
    <div class="calc"><span>Hospedaje</span><b>${money(e.total_hospedaje)}</b><span>Consumos y cargos</span><b>${money(e.consumo)}</b><span>Pagado</span><b>${money(e.pagado)}</b><span>Saldo</span><b class="big" style="color:${e.saldo > 0 ? 'var(--ocup)' : 'var(--libre)'}">${money(e.saldo)}</b></div>
    <div class="card" style="padding:12px"><div class="row" style="justify-content:space-between"><div class="lbl">Depósito en garantía</div><div class="row">
      ${e.activa ? `<button class="btn sm op" onclick="depModal(${e.id})">Recibir depósito</button>` : ''}${e.deposito_saldo > 0 ? `<button class="btn sm op" onclick="liquidarModal(${e.id})">Devolver o retener</button>` : ''}</div></div>
      ${e.depositos.length ? `<div class="tw"><table><tbody>${e.depositos.map((d) => `<tr class="click" onclick="imprimirDeposito(${d.id})"><td>${fdt(d.fecha)}</td><td><span class="pill ${d.tipo === 'recibido' ? 'p-ok' : d.tipo === 'retenido' ? 'p-bad' : 'p-warn'}">${{ recibido: 'Recibido', devuelto: 'Devuelto', retenido: 'Retenido' }[d.tipo]}</span></td><td class="sub">${esc(d.motivo || (d.metodo ? MET[d.metodo] : ''))}</td><td class="n">${money(d.monto)}</td></tr>`).join('')}</tbody></table></div>
      <div class="row" style="justify-content:space-between;margin-top:6px"><span class="sub">En resguardo</span><b>${money(e.deposito_saldo)}</b></div>` : '<div class="sub">Sin depósito.</div>'}</div>
    <div class="card solo-contratos" style="padding:12px"><div class="row" style="justify-content:space-between"><div class="lbl">Contrato de arrendamiento</div>${e.contratos.length ? '' : `<button class="btn sm op" onclick="contratoNuevo(${e.id})">Hacer contrato</button>`}</div>
      ${e.contratos.length ? e.contratos.map((c) => `<div class="row" style="justify-content:space-between"><span>Folio ${esc(c.folio)} · ${fd(c.fecha)}</span><button class="btn sm" onclick="verContrato(${c.id})">Ver / imprimir</button></div>`).join('') : '<div class="sub">Sin contrato.</div>'}</div>`,
  (e.activa ? `<button class="btn op" onclick="visModal(${h.id})">Agregar visitante</button><button class="btn op" onclick="editarEst(${e.id})">Editar datos</button><button class="btn op" onclick="cambiarModal(${e.id})">Cambiar habitación</button><button class="btn op" onclick="extModal(${e.id})">Extender / cambiar renta</button><button class="btn op" onclick="pagoModal(${e.id},${e.saldo})">Abono</button><button class="btn op bad" onclick="cargoModal(${e.id})">Multa / cargo</button>` : '')
    + `<button class="btn" onclick="imprimirEstancia(${e.id},'ESTADO DE CUENTA')">Ticket</button>` + (e.activa ? `<button class="btn pri op" onclick="salidaModal(${e.id},${e.saldo})">Registrar salida</button>` : ''), true);
}
async function editarEst(id) {
  const e = await GET('/api/estancias/' + id);
  modal('Editar datos del huésped', `<div class="f"><label class="l" style="grid-column:1/-1">Nombre<input id="eH" value="${esc(e.huesped)}"></label><label class="l">Teléfono<input id="eT" value="${esc(e.telefono || '')}"></label>
    <label class="l">Identificación<input id="eI" value="${esc(e.identificacion || '')}"></label><label class="l">Procedencia<input id="eP" value="${esc(e.procedencia || '')}"></label><label class="l">Placas<input id="eV" value="${esc(e.placas || '')}"></label>
    <label class="l">Personas<input id="eN" type="number" min="1" value="${e.personas}"></label><label class="l" style="grid-column:1/-1">Domicilio<input id="eD" value="${esc(e.domicilio || '')}"></label></div><label class="l">Notas<input id="eO" value="${esc(e.notas || '')}"></label>`,
  `<button class="btn" onclick="verEstancia(${id})">Volver</button><button class="btn pri" onclick="editarOk(${id})">Guardar</button>`);
}
async function editarOk(id) { await hacer(() => PUT('/api/estancias/' + id, { huesped: val('eH'), telefono: val('eT'), identificacion: val('eI'), procedencia: val('eP'), placas: val('eV'), personas: val('eN'), notas: val('eO'), domicilio: val('eD') }), 'Datos guardados'); verEstancia(id); vHab(); }
// Forma de pago. En dólares aparece el campo "Dólares recibidos" (id_u) con la conversión al tipo de cambio del turno.
// modo: '' normal · 'sinusd' dólares sin pedir cuánto (se calcula) · 'sindolar' sin dólares. monto: id del campo con el monto en pesos (o número)
function selPago(id, vacio, modo = '', monto = '') {
  // Cobros: se llena cuánto da el cliente en cada método y se suma
  if (modo === '') return `<input type="hidden" id="${id}" value="mixto" data-monto="${monto}" data-modo="">${mixtoHTML(id)}<small id="${id}_h" class="sub"></small>`;
  // Salidas de dinero (gastos, devoluciones): un solo método
  const ops = ['efectivo', 'dolares', 'tarjeta', 'transferencia'].filter((m) => !(m === 'dolares' && modo === 'sindolar'));
  return `<select id="${id}" onchange="usdHint('${id}')" data-monto="${monto}" data-modo="${modo}">${vacio ? `<option value="">${vacio}</option>` : ''}${ops.map((m) => `<option value="${m}">${MET[m]}</option>`).join('')}</select>
    <input id="${id}_u" type="number" min="0" step="0.01" placeholder="Dólares recibidos (US$)" hidden oninput="usdHint('${id}')"><small id="${id}_h" class="sub"></small>`;
}
// Extender: más tiempo con la misma renta, o cambiar a otra (ej. de día a semana o mes) con los mismos datos del huésped
async function extModal(id) {
  const e = await GET('/api/estancias/' + id), h = e.habitacion;
  const ops = ORDEN_MOD.filter((m) => m === e.modalidad || h['precio_' + m] > 0);
  modal(`Extender o cambiar renta · ${esc(e.huesped)}`, `
    <div class="aviso">Ahora: <b>${MOD[e.modalidad]}</b> · ${unidad(e.modalidad, e.cantidad)} · sale ${fdt(e.salida_prevista)}</div>
    <div class="lbl">Tipo de renta</div>
    <div class="seg">${ops.map((m) => `<label class="m-${m}"><input type="radio" name="xM" value="${m}" ${m === e.modalidad ? 'checked' : ''} onchange="xCalc(1)"><span><i class="dot"></i>${m === e.modalidad ? 'Seguir ' + MOD[m].toLowerCase() : 'Cambiar a ' + MOD[m].toLowerCase().replace('por ', '')}</span><small>${money(m === e.modalidad ? e.precio : h['precio_' + m])}</small></label>`).join('')}</div>
    <div class="f"><label class="l"><span id="xCL">Cantidad</span><input id="xC" type="number" min="1" value="1" oninput="xCalc()"></label><label class="l">Precio unitario<input id="xU" type="number" min="0" step="0.01" oninput="xCalc()"></label>
      <label class="l">Cobrar ahora<input id="xP" type="number" min="0" step="0.01" oninput="this.dataset.t=1"></label></div>
    <div class="l">Método de pago${selPago('xF', null, '', 'xP')}</div>
    <div class="sub">Para cobrar después deje "Cobrar ahora" en 0.</div><div class="calc" id="xRes"></div>`,
  `<button class="btn" onclick="verEstancia(${id})">Volver</button><button class="btn pri" onclick="extOk(${id})">Guardar</button>`);
  xCalc.e = e; xCalc(1);
}
function sumarCalc(e, n) {
  const d = aF(e.salida_prevista);
  if (e.modalidad === 'rato') d.setMinutes(d.getMinutes() + Math.round(horasRato() * 60) * n);
  else d.setDate(d.getDate() + (e.modalidad === 'semana' ? 7 : 1) * n);
  return d;
}
function xCalc(reset) {
  const e = xCalc.e, m = document.querySelector('input[name=xM]:checked').value, cambia = m !== e.modalidad;
  if (reset) { $('#xU').value = cambia ? e.habitacion['precio_' + m] : e.precio; delete $('#xP').dataset.t; }
  const n = Math.max(1, parseInt(val('xC')) || 1), u = num('xU'), imp = u * n;
  $('#xCL').textContent = 'Agregar ' + MODU[m][1];
  if (!$('#xP').dataset.t) $('#xP').value = imp.toFixed(2);
  // La renta nueva empieza donde termina la actual
  const nueva = cambia ? salidaCalc(m, n, aF(e.salida_prevista)) : m === 'mes' ? salidaCalc(m, e.cantidad + n, aF(e.inicio_tramo || e.entrada)) : sumarCalc(e, n);
  $('#xRes').innerHTML = `<span>${unidad(m, n)} × ${money(u)}</span><b class="big">${money(imp)}</b><span>Nueva salida</span><b>${fSal(cambia || u !== e.precio ? salidaCalc(m, n, aF(e.salida_prevista)) : nueva)}</b>
    ${cambia ? `<span>Cambio de renta</span><b>${MOD[e.modalidad]} → ${MOD[m]}</b><span class="sub" style="grid-column:1/-1">Lo ya generado (${money(e.total_hospedaje)}) se conserva; la renta nueva empieza el ${fdt(e.salida_prevista)}.</span>` : ''}`;
  if (typeof refrescarPagos === 'function') refrescarPagos();
}
async function extOk(id) {
  const m = document.querySelector('input[name=xM]:checked').value, cobra = num('xP') > 0;
  const r = await hacer(() => POST(`/api/estancias/${id}/extender`, { cantidad: val('xC'), modalidad: m, precio: val('xU'), pago: val('xP'), ...(cobra ? pagoDe('xF') : { metodo: '' }) }), m !== xCalc.e.modalidad ? 'Renta cambiada a ' + MOD[m].toLowerCase() : 'Estancia extendida');
  if (r?.pago?.cambio > 0) toast('Entregue de cambio ' + money(r.pago.cambio));
  verEstancia(id); vHab(); pintarTurno();
}
function pagoModal(id, saldo) { modal('Recibir anticipo o abono', `<div class="seg"><label><input type="radio" name="aT" value="anticipo" ${saldo > 0 ? '' : 'checked'}>Anticipo</label><label><input type="radio" name="aT" value="abono" ${saldo > 0 ? 'checked' : ''}>Abono a la cuenta</label></div><div class="f"><label class="l">Monto en pesos<input id="aM" type="number" min="0" step="0.01" value="${Math.max(0, saldo).toFixed(2)}" oninput="usdHint('aF')"></label><div class="l">Método de pago${selPago('aF', null, '', 'aM')}</div></div>`, `<button class="btn" onclick="verEstancia(${id})">Volver</button><button class="btn pri" onclick="pagoOk(${id})">Guardar pago</button>`); }
async function pagoOk(id) {
  const tipo = document.querySelector('input[name=aT]:checked').value;
  const r = await hacer(() => POST(`/api/estancias/${id}/pago`, { monto: val('aM'), ...pagoDe('aF'), nota: tipo }), tipo === 'anticipo' ? 'Anticipo recibido' : 'Abono registrado');
  if (r?.cambio > 0) toast('Entregue de cambio ' + money(r.cambio));
  verEstancia(id); vHab(); pintarTurno();
}
function cambiarModal(id) {
  const libres = sortH(TAB.habitaciones.filter((h) => h.estado === 'libre'));
  if (!libres.length) return toast('No hay habitaciones disponibles', true);
  modal('Cambiar de habitación', `<label class="l">Pasar al huésped a<select id="cH">${libres.map((h) => `<option value="${h.id}">${esc(h.numero)} · ${esc(h.nombre || '')}</option>`).join('')}</select></label><div class="sub">La tarifa no cambia. La habitación anterior pasa a limpieza.</div>`,
    `<button class="btn" onclick="verEstancia(${id})">Volver</button><button class="btn pri" onclick="cambiarOk(${id})">Cambiar</button>`);
}
async function cambiarOk(id) { await hacer(() => POST(`/api/estancias/${id}/cambiar`, { habitacion_id: val('cH') }), 'Habitación cambiada'); await vHab(); verEstancia(id); }
function salidaModal(id, saldo) {
  modal('Registrar salida', saldo > 0 ? `<div class="aviso bad">El huésped tiene saldo pendiente.</div><div class="calc"><span>Por cobrar</span><b class="big">${money(saldo)}</b></div><div class="l">Método de pago${selPago('sF', null, '', saldo)}</div>`
    : `<p style="margin:0">La cuenta está pagada${saldo < 0 ? ` (a favor del huésped: ${money(-saldo)})` : ''}. La habitación pasará a <span class="pill s-limpieza">En limpieza</span>.</p>`,
  `<button class="btn" onclick="verEstancia(${id})">Volver</button><button class="btn pri" onclick="salidaOk(${id})">${saldo > 0 ? 'Cobrar y registrar salida' : 'Registrar salida'}</button>`);
}
async function salidaOk(id) {
  const r = await hacer(() => POST(`/api/estancias/${id}/salida`, { ...pagoDe('sF') }), 'Salida registrada · a limpieza'); await vHab(); pintarTurno();
  const e = await GET('/api/estancias/' + id);
  if (e.deposito_saldo > 0) return liquidarModal(id, true);
  imprimirEstancia(id, 'SALIDA', r?.pago);
}

// ---------- Tickets ----------
function lin(a, b) { const w = W(); a = String(a); b = String(b); return a.slice(0, w - b.length - 1).padEnd(w - b.length) + b; }
function encabezado() { const w = W(); return [CFG.hotel_nombre.toUpperCase(), CFG.hotel_direccion, CFG.hotel_telefono ? 'Tel. ' + CFG.hotel_telefono : '', '-'.repeat(w)].filter(Boolean); }
function imprimir(lineas) { imprimirDoc(`<pre class="tk">${esc(lineas.join('\n'))}</pre>`, CFG.ticket_ancho === '80' ? '80' : '58', 'Ticket'); }
async function imprimirEstancia(id, titulo, pago) {
  const e = await GET('/api/estancias/' + id), w = W();
  imprimir([...encabezado(), titulo + '  Folio ' + e.folio, (e.habitacion.clase === 'departamento' ? 'Departamento ' : 'Habitación ') + e.habitacion.numero, 'Huésped: ' + e.huesped,
    'Entrada: ' + fdt(e.entrada), 'Salida:  ' + fdt(e.salida_real || e.salida_prevista), '-'.repeat(w), lin(unidad(e.modalidad, e.cantidad) + ' x ' + money(e.precio), money(e.total_hospedaje)),
    ...e.cargos.map((c) => lin(c.cantidad + ' ' + c.descripcion, money(c.importe))), '-'.repeat(w), lin('TOTAL', money(e.total_hospedaje + e.consumo)), lin('PAGADO', money(e.pagado)), lin('SALDO', money(e.saldo)), ...lineasPago(pago),
    ...(e.deposito ? ['-'.repeat(w), lin('Depósito en garantía', money(e.deposito)), ...(e.deposito_retenido ? [lin('Retenido', money(e.deposito_retenido))] : []), ...(e.deposito_devuelto ? [lin('Devuelto', money(e.deposito_devuelto))] : []), lin('Depósito en resguardo', money(e.deposito_saldo))] : []),
    '', CFG.ticket_pie || '']);
}

// ---------- Visitantes ----------
async function vVis() {
  const d = await GET(`/api/visitantes?desde=${hDesde}&hasta=${hHasta}`);
  const fila = (v, act) => `<tr><td><b>${esc(v.nombre)}</b><div class="sub">${esc(v.identificacion || '')}${v.motivo ? ' · ' + esc(v.motivo) : ''}</div></td><td>${esc(v.numero || '')}</td><td>${esc(v.huesped || '')}</td><td>${fdt(v.entrada)}</td><td>${act ? `<button class="btn sm op" onclick="visSalida(${v.id})">Registrar salida</button>` : fdt(v.salida)}</td></tr>`;
  $('#main').innerHTML = cab('Visitantes', 'Personas que entran a ver a un huésped', `<button class="btn pri op" onclick="visModal()">Registrar visitante</button>`)
    + `<div class="stack"><div class="card"><h2>Dentro ahora · ${d.dentro.length}</h2><div class="tw"><table><thead><tr><th>Visitante</th><th>Hab.</th><th>Visita a</th><th>Entrada</th><th></th></tr></thead><tbody>${d.dentro.map((v) => fila(v, 1)).join('') || '<tr><td colspan="5" class="empty">No hay visitantes dentro.</td></tr>'}</tbody></table></div></div>
    <div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h2 style="margin:0">Ya salieron</h2><div class="row"><input type="date" id="vd" value="${hDesde}" style="width:auto"><input type="date" id="vh" value="${hHasta}" style="width:auto"><button class="btn sm" onclick="hDesde=val('vd');hHasta=val('vh');vVis()">Ver</button></div></div>
    <div class="tw"><table><thead><tr><th>Visitante</th><th>Hab.</th><th>Visita a</th><th>Entrada</th><th>Salida</th></tr></thead><tbody>${d.historial.map((v) => fila(v, 0)).join('') || '<tr><td colspan="5" class="empty">Sin registros en esas fechas.</td></tr>'}</tbody></table></div></div></div>`;
}
async function visModal(habId) {
  if (!TAB) TAB = await GET('/api/tablero');
  const oc = sortH(TAB.habitaciones.filter((h) => h.estado === 'ocupada' && h.estancia));
  if (!oc.length) return toast('No hay habitaciones ocupadas', true);
  modal('Registrar visitante', `<div class="f"><label class="l">Nombre del visitante<input id="vN"></label><label class="l">Identificación<input id="vI" placeholder="INE, licencia…"></label>
    <label class="l">Habitación<select id="vR" onchange="visPrecio()">${oc.map((h) => `<option value="${h.id}" ${h.id === habId ? 'selected' : ''}>${esc(h.numero)} · ${esc(h.estancia.huesped)}</option>`).join('')}</select></label><label class="l">Motivo<input id="vM" placeholder="Opcional"></label>
    <label class="l">Cobro de visita${puede('autorizar') ? '' : ' (precio fijo)'}<input id="vC" type="number" min="0" step="0.01" placeholder="0.00" oninput="usdHint('vPf')" ${puede('autorizar') ? '' : 'readonly'}></label><div class="l">Método de pago${selPago('vPf', null, '', 'vC')}</div></div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="visOk()">Registrar entrada</button>`);
  visPrecio();
}
// Precio fijo de la visita: el de la habitación o el general (solo gerente o administrador lo cambia)
function visPrecio() {
  const h = TAB.habitaciones.find((x) => String(x.id) === val('vR')), v = h && h.precio_visita !== null && h.precio_visita !== undefined ? Number(h.precio_visita) : Number(CFG.precio_visita) || 0;
  $('#vC').value = v ? v.toFixed(2) : ''; if (typeof usdHint === 'function') usdHint('vPf');
}
async function visOk() {
  const cobro = num('vC'), r = await hacer(() => POST('/api/visitantes', { nombre: val('vN'), identificacion: val('vI'), habitacion_id: val('vR'), motivo: val('vM'), cobro: puede('autorizar') ? cobro : undefined, ...pagoDe('vPf') }), 'Visitante registrado');
  cerrar(); ir(vista); pintarTurno();
  if (cobro > 0) { const w = W(), m = val('vPf') || 'efectivo';
    imprimir([...encabezado(), 'COBRO DE VISITA', fdt(new Date().toISOString().slice(0, 19).replace('T', ' ')), '-'.repeat(w), 'Visitante: ' + val('vN'), lin('Visita', money(cobro)), ...lineasPago(r?.pago), '', CFG.ticket_pie || '']); }
}
async function visSalida(id, est) { await hacer(() => POST(`/api/visitantes/${id}/salida`), 'Salida del visitante registrada'); if (est) verEstancia(est); ir(vista); }

// ---------- Tienda ----------
let PRODS = [];
async function vTienda() {
  [PRODS, TAB] = await Promise.all([GET('/api/productos'), GET('/api/tablero')]);
  const ventas = await GET('/api/ventas');
  pintarTienda(ventas);
}
function pintarTienda(ventas) {
  const q = qProd.toLowerCase(), ps = PRODS.filter((p) => (!tArea || (p.area || 'Sin área') === tArea) && (p.nombre + ' ' + (p.codigo || '')).toLowerCase().includes(q));
  const AREAS = [...new Set(PRODS.map((p) => p.area || 'Sin área'))].sort((a, b) => a.localeCompare(b, 'es'));
  const tot = carrito.reduce((s, l) => s + l.cantidad * l.precio, 0), oc = sortH(TAB.habitaciones.filter((h) => h.estado === 'ocupada' && h.estancia));
  $('#main').innerHTML = cab('Tienda', 'Cobre en mostrador o cargue a la cuenta del huésped')
    + `<div class="pos"><div class="card"><div class="scan">${ico('scan')}<input id="qP" placeholder="Escanee el código de barras o escriba para buscar" value="${esc(qProd)}" autocomplete="off"><span class="sub">Listo para escanear</span></div>
      ${AREAS.length > 1 ? `<div class="chips areas"><button class="chip ${!tArea ? 'on' : ''}" onclick="tArea='';pintarTienda(pintarTienda.v)">Todo</button>${AREAS.map((a) => `<button class="chip ${tArea === a ? 'on' : ''}" data-a="${esc(a)}" onclick="tArea=this.dataset.a;pintarTienda(pintarTienda.v)">${esc(a)}</button>`).join('')}</div>` : ''}
      <div class="prods">${ps.map((p) => `<button class="prod" ${p.existencia <= 0 ? 'disabled' : ''} onclick="agregar(${p.id})"><span>${esc(p.nombre)}</span><b>${money(p.precio)}</b><small>${p.existencia <= 0 ? 'Agotado' : 'Quedan ' + p.existencia}</small></button>`).join('') || '<div class="empty">Sin productos.</div>'}</div></div>
    <div class="card"><h2>Cuenta</h2>${carrito.length ? carrito.map((l, i) => `<div class="line"><span>${esc(l.nombre)}<div class="sub">${money(l.precio)} c/u</div></span><span class="qty"><button onclick="cant(${i},-1)" aria-label="Quitar uno">−</button><b>${l.cantidad}</b><button onclick="cant(${i},1)" aria-label="Agregar uno">+</button></span><b class="n">${money(l.cantidad * l.precio)}</b></div>`).join('') : '<div class="empty">Toque un producto o escanee su código.</div>'}
      <div class="total"><span>Total</span><b>${money(tot)}</b></div>
      <div class="stack" style="gap:10px">${oc.length ? `<label class="l">Cobrar<select id="tH" onchange="tCalc()"><option value="">Aquí en caja</option>${oc.map((h) => `<option value="${h.id}">Cargar a la habitación ${esc(h.numero)} · ${esc(h.estancia.huesped)}</option>`).join('')}</select></label>` : ''}
      <div class="l" id="tML">Método de pago${mixtoHTML('tM', 'tCalc()')}</div><div id="tCam" class="sub"></div>
      <button class="btn pri" style="justify-content:center" ${carrito.length ? '' : 'disabled'} onclick="cobrar()">Cobrar ${money(tot)}</button></div></div></div>
    <div class="card" style="margin-top:16px"><h2>Ventas de hoy</h2><div class="tw"><table><thead><tr><th>Folio</th><th>Hora</th><th>Productos</th><th>Pago</th><th class="n">Total</th><th></th></tr></thead><tbody>
    ${ventas.map((v) => `<tr style="${v.cancelada ? 'opacity:.5;text-decoration:line-through' : ''}"><td class="mono">${v.folio}</td><td>${fdt(v.fecha)}</td><td>${v.items.map((i) => i.cantidad + ' ' + esc(i.descripcion)).join(', ')}</td><td>${MET[v.metodo]}${v.numero ? ' ' + esc(v.numero) : ''}</td><td class="n">${money(v.total)}</td><td>${!v.cancelada && puede('cancelar') ? `<button class="btn sm bad" onclick="confirmar(this,()=>cancelarVenta(${v.id}))">Cancelar</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">Aún no hay ventas hoy.</td></tr>'}</tbody></table></div></div>`;
  const qp = $('#qP');
  qp.oninput = () => { qProd = qp.value; const pos = qp.selectionStart; pintarTienda(ventas); const n = $('#qP'); n.focus(); n.setSelectionRange(pos, pos); };
  qp.onkeydown = (e) => { if (e.key === 'Enter') { const p = PRODS.find((x) => x.codigo && x.codigo === qp.value.trim()) || (ps.length === 1 ? ps[0] : null); if (p) { qProd = ''; agregar(p.id); $('#qP').focus(); } } };
  pintarTienda.v = ventas; tCalc();
  const ac = document.activeElement; if (!ac || ac === document.body || ac.tagName === 'BUTTON') $('#qP')?.focus();
}
function agregar(id) { const p = PRODS.find((x) => x.id === id), l = carrito.find((x) => x.producto_id === id); if ((l?.cantidad || 0) >= p.existencia) return toast('No hay más existencia de ' + p.nombre, true); if (l) l.cantidad++; else carrito.push({ producto_id: id, nombre: p.nombre, precio: p.precio, cantidad: 1 }); pintarTienda(pintarTienda.v); }
function cant(i, d) { const l = carrito[i], p = PRODS.find((x) => x.id === l.producto_id); if (d > 0 && l.cantidad >= p.existencia) return toast('No hay más existencia', true); l.cantidad += d; if (l.cantidad <= 0) carrito.splice(i, 1); pintarTienda(pintarTienda.v); }
function tCalc() {
  const hab = val('tH'), tc = tcHoy(), tot = carrito.reduce((s, l) => s + l.cantidad * l.precio, 0), r = sumaMixto('tM');
  $('#tML').hidden = !!hab;
  $('#tCam').textContent = hab ? 'Se suma a la cuenta del huésped' : !r.total ? `Si no escribe nada se cobra ${money(tot)} en efectivo exacto · Dólar a $${tc} (US$${(Math.ceil(tot / tc * 100) / 100).toFixed(2)})`
    : r.total >= tot - 0.009 ? `Pagó con ${money(r.total)} · Cambio: ${money(r.total - tot)}` : `Pagó con ${money(r.total)} · Faltan ${money(tot - r.total)}`;
}
async function cobrar() {
  const hab = val('tH');
  const v = await hacer(() => POST('/api/ventas', { items: carrito, metodo: hab ? 'habitacion' : 'mixto', habitacion_id: hab, partes: hab ? undefined : sumaMixto('tM').partes }), 'Venta registrada');
  carrito = []; await vTienda(); pintarTurno(); const w = W();
  imprimir([...encabezado(), 'VENTA  Folio ' + v.folio, fdt(v.fecha), '-'.repeat(w), ...v.items.map((i) => lin(i.cantidad + ' ' + i.descripcion, money(i.importe))), '-'.repeat(w), lin('TOTAL', money(v.total)),
    ...(hab ? ['Cargado a la habitación ' + v.numero] : lineasPago({ total: v.recibido, usd: v.pago?.usd, tc: v.pago?.tc, cambio: v.cambio })), '', CFG.ticket_pie || '']);
}
async function cancelarVenta(id) { await hacer(() => POST(`/api/ventas/${id}/cancelar`), 'Venta cancelada'); vTienda(); }

// ---------- Inventario ----------
async function vInv() {
  const [ps, mv] = await Promise.all([GET('/api/productos'), GET('/api/movimientos')]); PRODS = ps;
  const valor = ps.reduce((s, p) => s + p.existencia * p.costo, 0);
  const est = (p) => p.servicio ? '<span class="pill">Servicio</span>' : p.existencia <= 0 ? '<span class="pill p-bad">Agotado</span>' : p.existencia <= p.minimo ? '<span class="pill p-warn">Surtir</span>' : '<span class="pill p-ok">Bien</span>';
  const TIPO = { entrada: 'Entrada', venta: 'Venta', ajuste: 'Ajuste', cancelacion: 'Cancelación' };
  const AREAS = [...new Set(ps.map((p) => p.area || 'Sin área'))].sort((a, b) => a.localeCompare(b, 'es')), vis = ps.filter((p) => !tArea || (p.area || 'Sin área') === tArea);
  $('#main').innerHTML = cab('Inventario', ps.length + ' productos · valor a costo ' + money(valor), `<button class="btn" onclick="exportarProductos()">Exportar a Excel</button>${puede('productos') ? '<button class="btn" onclick="importarProductos()">Importar de Excel</button>' : ''}${puede('inventario') ? '<button class="btn op" onclick="entradaModal()">Entrada de mercancía</button>' : ''}${puede('productos') ? '<button class="btn pri" onclick="prodModal()">Nuevo producto</button>' : ''}`)
    + `<div class="stack"><div class="card">${AREAS.length > 1 ? `<div class="chips areas" style="margin-bottom:10px"><button class="chip ${!tArea ? 'on' : ''}" onclick="tArea='';vInv()">Todas las áreas</button>${AREAS.map((a) => `<button class="chip ${tArea === a ? 'on' : ''}" data-a="${esc(a)}" onclick="tArea=this.dataset.a;vInv()">${esc(a)} <small>${ps.filter((p) => (p.area || 'Sin área') === a).length}</small></button>`).join('')}</div>` : ''}<div class="tw"><table><thead><tr><th>Código</th><th>Producto</th><th>Área</th><th class="n">Costo</th><th class="n">Precio</th><th class="n">Existencia</th><th class="n">Mínimo</th><th>Estado</th></tr></thead><tbody>
    ${vis.map((p) => `<tr class="${puede('productos') ? 'click' : ''}" ${puede('productos') ? `onclick="prodModal(${p.id})"` : ''}><td class="mono">${esc(p.codigo || '')}</td><td><b>${esc(p.nombre)}</b></td><td>${esc(p.area || '')}</td><td class="n">${money(p.costo)}</td><td class="n">${money(p.precio)}</td><td class="n"><b>${p.servicio ? '—' : p.existencia}</b></td><td class="n">${p.minimo}</td><td>${est(p)}</td></tr>`).join('') || '<tr><td colspan="8" class="empty">Agregue su primer producto o impórtelos de Excel.</td></tr>'}</tbody></table></div></div>
    <div class="card"><h2>Movimientos recientes</h2><div class="tw"><table><thead><tr><th>Fecha</th><th>Producto</th><th>Tipo</th><th class="n">Cantidad</th><th>Referencia</th><th>Usuario</th></tr></thead><tbody>
    ${mv.map((m) => `<tr><td>${fdt(m.fecha)}</td><td>${esc(m.producto || '—')}</td><td>${TIPO[m.tipo] || m.tipo}</td><td class="n" style="color:${m.cantidad < 0 ? 'var(--ocup)' : 'var(--libre)'}">${m.cantidad > 0 ? '+' : ''}${m.cantidad}</td><td>${esc(m.referencia || '')}</td><td>${esc(m.usuario || '')}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">Sin movimientos.</td></tr>'}</tbody></table></div></div></div>`;
}
function prodModal(id) {
  const p = id ? PRODS.find((x) => x.id === id) : { codigo: '', nombre: '', costo: '', precio: '', existencia: 0, minimo: 3, area: tArea && tArea !== 'Sin área' ? tArea : '' };
  const AR = [...new Set([...String(CFG.tienda_areas || '').split(',').map((x) => x.trim()).filter(Boolean), ...PRODS.map((x) => x.area).filter(Boolean)])];
  modal(id ? 'Editar producto' : 'Nuevo producto', `<div class="f"><label class="l">Código de barras<input id="pC" value="${esc(p.codigo || '')}" placeholder="Escanéelo aquí"></label><label class="l">Nombre<input id="pN" value="${esc(p.nombre)}"></label>
    <label class="l">Departamento / área<input id="pAr" list="pArL" value="${esc(p.area || '')}" placeholder="Bebidas, Botanas…"><datalist id="pArL">${AR.map((a) => `<option value="${esc(a)}">`).join('')}</datalist></label>
    <label class="l">Costo<input id="pCo" type="number" step="0.01" value="${p.costo}"></label><label class="l">Precio de venta<input id="pP" type="number" step="0.01" value="${p.precio}"></label>
    <label class="row" style="font-weight:600;grid-column:1/-1"><input type="checkbox" id="pSv" ${p.servicio ? 'checked' : ''} onchange="$('#pE').disabled=$('#pM').disabled=this.checked"> Es un servicio (no lleva inventario: limpieza, lavandería, planchado…)</label>
    <label class="l">Existencia<input id="pE" type="number" step="any" value="${p.existencia}" ${p.servicio ? 'disabled' : ''}></label><label class="l">Existencia mínima<input id="pM" type="number" step="any" value="${p.minimo}" ${p.servicio ? 'disabled' : ''}></label></div>`,
  `${id ? `<button class="btn bad" onclick="confirmar(this,()=>prodBorrar(${id}))">Eliminar</button>` : ''}<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="prodOk(${id || 0})">Guardar</button>`);
}
async function prodOk(id) { const b = { codigo: val('pC'), nombre: val('pN'), area: val('pAr'), servicio: $('#pSv').checked, costo: val('pCo'), precio: val('pP'), existencia: val('pE'), minimo: val('pM') }; await hacer(() => (id ? PUT('/api/productos/' + id, b) : POST('/api/productos', b)), 'Producto guardado'); cerrar(); vInv(); }
async function prodBorrar(id) { await hacer(() => DEL('/api/productos/' + id), 'Producto eliminado'); cerrar(); vInv(); }
function entradaModal() {
  if (!PRODS.length) return toast('Primero agregue productos', true);
  modal('Entrada de mercancía', `<div class="f"><label class="l">Producto<select id="eP">${PRODS.map((p) => `<option value="${p.id}">${esc(p.nombre)} (hay ${p.existencia})</option>`).join('')}</select></label><label class="l">Cantidad que llegó<input id="eC" type="number" min="1" step="any" value="1"></label>
    <label class="l">Costo unitario<input id="eCo" type="number" step="0.01" placeholder="Igual que antes"></label><label class="l">Proveedor / nota<input id="eN"></label></div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="entradaOk()">Sumar al inventario</button>`);
}
async function entradaOk() { await hacer(() => POST(`/api/productos/${val('eP')}/entrada`, { cantidad: val('eC'), costo: val('eCo'), nota: val('eN') }), 'Entrada registrada'); cerrar(); vInv(); }

// ---------- Huéspedes (historial) ----------
async function vHues() {
  const l = await GET(`/api/estancias?desde=${hDesde}&hasta=${hHasta}&q=${encodeURIComponent(hBus)}`);
  $('#main').innerHTML = cab('Huéspedes', 'Registro de huéspedes por fechas', `<input type="date" id="hd" value="${hDesde}" style="width:auto"><input type="date" id="hh" value="${hHasta}" style="width:auto"><input id="hb" placeholder="Nombre, placas o hab." value="${esc(hBus)}" style="width:170px"><button class="btn" onclick="hDesde=val('hd');hHasta=val('hh');hBus=val('hb');vHues()">Buscar</button>`)
    + `<div class="card"><div class="tw"><table><thead><tr><th>Folio</th><th>Hab.</th><th>Huésped</th><th>Teléfono</th><th>Identificación</th><th>Placas</th><th>Renta</th><th>Entrada</th><th>Salida</th><th class="n">Total</th><th class="n">Saldo</th></tr></thead><tbody>
    ${l.map((e) => `<tr class="click" onclick="verEstancia(${e.id})"><td class="mono">${e.folio}</td><td><b>${esc(e.numero)}</b></td><td>${esc(e.huesped)}${e.personas > 1 ? ` <span class="sub">+${e.personas - 1}</span>` : ''}</td><td>${esc(e.telefono || '')}</td><td>${esc(e.identificacion || '')}</td><td class="mono">${esc(e.placas || '')}</td>
      <td><span class="pill mod m-${e.modalidad}">${unidad(e.modalidad, e.cantidad)}</span></td><td>${fdt(e.entrada)}</td><td>${e.activa ? '<span class="pill s-ocupada">Hospedado</span>' : fdt(e.salida_real)}</td><td class="n">${money(e.total_hospedaje + e.consumo)}</td><td class="n" style="color:${e.saldo > 0 ? 'var(--ocup)' : 'inherit'}">${money(e.saldo)}</td></tr>`).join('') || '<tr><td colspan="11" class="empty">No hubo huéspedes en esas fechas.</td></tr>'}</tbody></table></div></div>`;
}

// ---------- Reportes ----------
async function vRep() {
  const d = await GET(`/api/reporte?desde=${rDesde}&hasta=${rHasta}`), ahora = new Date();
  const H = d.habitaciones, n = H.length, oc = H.filter((h) => h.estado === 'ocupada').length;
  const chips = (s) => { const l = sortH(H.filter((h) => h.estado === s)); return l.length ? `<div class="chips">${l.map((h) => `<span class="chip s-${s}"><b>${esc(h.numero)}</b>${esc(h.nombre || '')}${s === 'mant' && h.nota ? ' · ' + esc(h.nota) : ''}</span>`).join('')}</div>` : '<div class="empty">Ninguna.</div>'; };
  const ESTB = { libre: 'Lista', limpieza: 'A limpieza', mant: 'A mantenimiento' };
  $('#main').innerHTML = cab('Reportes', 'Ingresos del periodo y estado actual del hotel', `<label class="l">Desde<input type="date" id="rd" value="${rDesde}" onchange="rDesde=this.value;vRep()"></label><label class="l">Hasta<input type="date" id="rh" value="${rHasta}" onchange="rHasta=this.value;vRep()"></label><button class="btn" onclick="imprimirCorte()">Imprimir corte</button>`)
    + `<div class="kpis"><div class="kpi"><span>Ocupación ahora</span><b>${n ? Math.round(oc / n * 100) : 0}%</b><div class="sub">${oc} de ${n}${ORDEN_MOD.filter((m) => d.porModalidad[m]).map((m) => ' · ' + d.porModalidad[m] + ' ' + MODU[m][d.porModalidad[m] === 1 ? 0 : 1]).join('')}</div></div>
      <div class="kpi"><span>Cobrado hospedaje</span><b>${money(d.cobrado.hospedaje)}</b><div class="sub">${d.entradas} entradas · ${d.salidas} salidas</div></div>
      <div class="kpi"><span>Cobrado tienda</span><b>${money(d.cobrado.tienda)}</b><div class="sub">más ${money(d.cargosHabitacion)} cargado a habitaciones</div></div>
      <div class="kpi"><span>Total cobrado</span><b>${money(d.cobrado.total)}</b><div class="sub">${Object.entries(d.cobrado.porMetodo).filter(([, v]) => v).map(([k, v]) => MET[k] + ' ' + money(v)).join(' · ') || 'Sin cobros'}</div></div>
      <div class="kpi"><span>Gastos</span><b style="color:var(--ocup)">${money(d.gastos.total)}</b><div class="sub">${d.gastos.n} gasto(s)</div></div>
      <div class="kpi"><span>Efectivo en caja</span><b>${money(efectivoCaja(d))}</b><div class="sub">cobros + depósitos − gastos − devoluciones, en efectivo</div></div>
      <div class="kpi"><span>Depósitos en resguardo</span><b>${money(d.depositos.enGuarda)}</b><div class="sub">${d.mantenimiento.abiertos} reporte(s) de mantenimiento abiertos</div></div></div>
    <div class="stack"><div class="card"><h2>Huéspedes hospedados · ${d.huespedes.length}</h2><div class="tw"><table><thead><tr><th>Hab.</th><th>Huésped</th><th>Teléfono</th><th>Renta</th><th>Entrada</th><th>Salida</th><th class="n">Saldo</th></tr></thead><tbody>
      ${d.huespedes.map((e) => `<tr class="click" onclick="verEstancia(${e.id})"><td><b>${esc(e.numero)}</b></td><td>${esc(e.huesped)}</td><td>${esc(e.telefono || '')}</td><td><span class="pill mod m-${e.modalidad}">${MOD[e.modalidad]}</span></td><td>${fdt(e.entrada)}</td><td>${fdt(e.salida_prevista)} ${aF(e.salida_prevista) < ahora ? '<span class="pill p-bad">Vencida</span>' : ''}</td><td class="n" style="color:${e.saldo > 0 ? 'var(--ocup)' : 'inherit'}">${money(e.saldo)}</td></tr>`).join('') || '<tr><td colspan="7" class="empty">No hay huéspedes.</td></tr>'}</tbody></table></div></div>
    <div class="cols"><div class="card"><h2>Desocupadas y listas</h2>${chips('libre')}</div><div class="card"><h2>En limpieza</h2>${chips('limpieza')}</div><div class="card"><h2>En mantenimiento</h2>${chips('mant')}</div></div>
    <div class="cols"><div class="card"><h2>Corte por usuario</h2><div class="kv">${Object.entries(d.cobrado.porUsuario).map(([k, v]) => `<span>${esc(k)}</span><b>${money(v)}</b>`).join('') || '<span>Sin cobros</span><span></span>'}</div></div>
      <div class="card"><h2>Movimiento del periodo</h2><div class="kv"><span>Entradas de huéspedes</span><b>${d.entradas}</b><span>Salidas</span><b>${d.salidas}</b><span>Visitantes</span><b>${d.visitantes}</b><span>Ventas de tienda</span><b>${d.ventasTienda.n} · ${money(d.ventasTienda.t)}</b></div></div>
      <div class="card"><h2>Productos por surtir</h2>${d.porSurtir.length ? `<div class="kv">${d.porSurtir.map((p) => `<span>${esc(p.nombre)}</span><b>${p.existencia} / mín. ${p.minimo}</b>`).join('')}</div>` : '<div class="empty">Todo arriba del mínimo.</div>'}</div></div>
    <div class="cols"><div class="card"><h2>Gastos por clasificación</h2>${Object.keys(d.gastos.porGrupo || {}).length ? `<div class="kv">${Object.entries(d.gastos.porGrupo).sort((a, b) => b[1].total - a[1].total).map(([k, x]) => `<span><b>${esc(k)}</b> (${x.n})</span><b>${money(x.total)}</b>${Object.entries(x.conceptos).sort((a, b) => b[1] - a[1]).map(([c, v]) => `<span class="sub" style="padding-left:12px">${esc(c)}</span><span class="sub" style="text-align:right">${money(v)}</span>`).join('')}`).join('')}</div>` : '<div class="empty">Sin gastos.</div>'}</div>
      <div class="card"><h2>Depósitos del periodo</h2><div class="kv"><span>Recibidos</span><b>${money(d.depositos.recibidos)}</b><span>Devueltos</span><b>${money(d.depositos.devueltos)}</b><span>Retenidos por daños</span><b>${money(d.depositos.retenidos)}</b></div></div>
      <div class="card"><h2>Depósitos por devolver</h2>${d.depositos.pendientes.length ? `<div class="kv">${d.depositos.pendientes.map((x) => `<span class="enlace" onclick="liquidarModal(${x.id})">${esc(x.numero)} · ${esc(x.huesped)}</span><b>${money(x.saldo)}</b>`).join('')}</div><div class="sub">Huéspedes que ya salieron y todavía tienen depósito.</div>` : '<div class="empty">Ninguno pendiente.</div>'}</div></div>
    <div class="card"><h2>Limpieza y mantenimiento del periodo</h2><div class="tw"><table><thead><tr><th>Fecha</th><th>Hab.</th><th>Cambio</th><th>Nota</th><th>Usuario</th></tr></thead><tbody>${d.bitacora.map((b) => `<tr><td>${fdt(b.fecha)}</td><td><b>${esc(b.numero)}</b></td><td><span class="pill s-${b.estado}">${ESTB[b.estado]}</span></td><td>${esc(b.nota || '')}</td><td>${esc(b.usuario || '')}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">Sin cambios.</td></tr>'}</tbody></table></div></div></div>`;
  vRep.d = d;
}
function imprimirCorte() {
  const d = vRep.d, w = W();
  imprimir([...encabezado(), 'CORTE ' + fd(d.desde) + (d.desde !== d.hasta ? ' al ' + fd(d.hasta) : ''), '-'.repeat(w), lin('Hospedaje', money(d.cobrado.hospedaje)), lin('Tienda', money(d.cobrado.tienda)), lin('TOTAL', money(d.cobrado.total)), '-'.repeat(w),
    ...Object.entries(d.cobrado.porMetodo).map(([k, v]) => lin(MET[k], money(v))), '-'.repeat(w), ...Object.entries(d.cobrado.porUsuario).map(([k, v]) => lin(k, money(v))), '-'.repeat(w),
    lin('Depósitos recibidos', money(d.depositos.recibidos)), lin('Depósitos devueltos', money(d.depositos.devueltos)), lin('Gastos', money(d.gastos.total)), lin('EFECTIVO EN CAJA', money(efectivoCaja(d))), '-'.repeat(w),
    lin('Entradas', d.entradas), lin('Salidas', d.salidas), lin('Ocupadas ahora', d.huespedes.length + ' / ' + d.habitaciones.length), '', 'Impreso ' + new Date().toLocaleString('es-MX')]);
}
const efectivoCaja = (d) => (d.cobrado.porMetodo.efectivo || 0) - (d.cobrado.cambio || 0) - (d.depositos.cambio || 0) + (d.depositos.recibidosMetodo.efectivo || 0) - (d.gastos.porMetodo.efectivo || 0) - (d.depositos.devueltosMetodo.efectivo || 0);

// ---------- Configuración ----------
async function vCfg() {
  CFG = await GET('/api/config'); aplicarColores();
  const tabs = [['hotel', 'Hotel y colores', 'config'], ['habs', 'Habitaciones', 'habitaciones'], ['impresora', 'Impresora y caja', 'config'], ['contrato', 'Contratos y gastos', 'config'], ['usuarios', 'Usuarios y permisos', 'usuarios'],
    ['mant', 'Portal de mantenimiento', 'usuarios'], ['remoto', 'Monitoreo remoto'], ['resp', 'Respaldos y licencia', 'config'], ['pass', 'Mi contraseña']]
    .filter(([k, , perm]) => (perm ? puede(perm) : true) && !(k === 'remoto' && YO.rol === 'mantenimiento'));
  if (!tabs.find((t) => t[0] === cfgTab)) cfgTab = tabs[0][0];
  const T = `<div class="tabs">${tabs.map(([k, n]) => `<button class="${cfgTab === k ? 'on' : ''}" onclick="cfgTab='${k}';vCfg()">${n}</button>`).join('')}</div>`;
  $('#main').innerHTML = cab('Configuración', '') + T + '<div id="cfgc"></div>';
  ({ hotel: cHotel, habs: cHabs, impresora: cImpresora, contrato: cContrato, usuarios: cUsers, remoto: cRemoto, mant: cMantPortal, resp: cResp, pass: cPass })[cfgTab]();
}
function cContrato() {
  $('#cfgc').innerHTML = `<div class="stack"><div class="card"><h2>Arrendador (aparece en los contratos)</h2><div class="f"><label class="l">Nombre del propietario o representante<input id="aN" value="${esc(CFG.arrendador_nombre)}" placeholder="${esc(CFG.hotel_nombre)}"></label>
    <label class="l">Domicilio del arrendador<input id="aD" value="${esc(CFG.arrendador_domicilio)}" placeholder="${esc(CFG.hotel_direccion)}"></label><label class="l">Ciudad (jurisdicción)<input id="aC" value="${esc(CFG.ciudad_contrato)}"></label></div></div>
    <div class="card"><div class="row" style="justify-content:space-between;margin-bottom:6px;flex-wrap:wrap"><h2 style="margin:0">Clasificación de gastos</h2><button class="btn sm" onclick="$('#aG').value=CFG._clasif_base">Restaurar las recomendadas</button></div>
      <p class="sub" style="margin-top:0">Una clasificación por renglón, luego dos puntos y sus tipos de gasto separados por comas. Ejemplo: <b>Nómina y personal: Nómina, Bono de puntualidad, Días festivos</b></p>
      <textarea id="aG" rows="9" style="font-family:var(--fBody);font-size:13px">${esc(CFG.gastos_clasificacion)}</textarea></div>
    <div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h2 style="margin:0">Texto del contrato</h2><button class="btn sm" onclick="$('#aT').value=CFG._contrato_base">Restaurar texto original</button></div>
    <p class="sub" style="margin-top:0">Las palabras entre llaves se llenan solas: {arrendador}, {arrendatario}, {identificacion}, {domicilio_arrendatario}, {telefono}, {tipo_inmueble}, {inmueble}, {direccion_hotel}, {incluye}, {personas}, {periodo}, {fecha_inicio}, {fecha_fin}, {hora_salida}, {renta}, {renta_letra}, {unidad}, {dia_pago}, {deposito}, {deposito_letra}, {aviso}, {ciudad}, {fecha_firma}. Deje una línea en blanco entre párrafos; los títulos en MAYÚSCULAS salen como encabezado.</p>
    <textarea id="aT" rows="18" style="font-family:var(--fBody);font-size:13px;min-height:340px">${esc(CFG.contrato_clausulas || CFG._contrato_base)}</textarea>
    <div class="aviso" style="margin-top:10px">Este texto es un modelo general. Le recomendamos que lo revise un abogado antes de usarlo con sus clientes.</div></div>
    <div><button class="btn pri" onclick="contratoCfgOk()">Guardar</button></div></div>`;
}
async function contratoCfgOk() {
  const t = $('#aT').value.trim();
  await hacer(() => PUT('/api/config', { arrendador_nombre: val('aN'), arrendador_domicilio: val('aD'), ciudad_contrato: val('aC'), gastos_clasificacion: $('#aG').value.trim() || CFG._clasif_base, contrato_clausulas: t === CFG._contrato_base.trim() ? '' : t }), 'Guardado');
  CFG = await GET('/api/config');
}
function cHotel() {
  const col = (k, n, v) => `<label class="l">${n}<input type="color" id="gc_${k}" value="${esc(v)}" oninput="cfgPrev()"></label>`;
  $('#cfgc').innerHTML = `<div class="stack"><div class="card"><h2>Datos del hotel</h2><div class="f"><label class="l">Nombre<input id="gN" value="${esc(CFG.hotel_nombre)}"></label><label class="l">Dirección<input id="gD" value="${esc(CFG.hotel_direccion)}"></label>
    <label class="l">Teléfono<input id="gT" value="${esc(CFG.hotel_telefono)}"></label>
    <label class="l">Pie del ticket<input id="gP" value="${esc(CFG.ticket_pie)}"></label><label class="l">Ancho del ticket<select id="gA"><option value="58" ${CFG.ticket_ancho !== '80' ? 'selected' : ''}>58 mm</option><option value="80" ${CFG.ticket_ancho === '80' ? 'selected' : ''}>80 mm</option></select></label></div></div>
    <div class="card"><h2>Tipos de renta</h2><p class="sub" style="margin-top:0">Por horas, noche o día van juntos; semana y mes aparte (larga estancia). El precio de cada uno se pone en cada habitación.</p>
    <div class="f"><label class="l">Horas de un rato<input id="gHr" type="number" min="1" max="24" step="0.5" value="${esc(CFG.horas_rato || '3')}"></label>
      <label class="l">Noche: sale al día siguiente a las<input id="gSn" type="time" value="${esc(CFG.hora_salida_noche || '12:00')}"></label>
      <label class="l">Día, semana y mes: hora de salida<input id="gS" type="time" value="${esc(CFG.hora_salida)}"></label></div>
    <label class="row" style="font-weight:600;margin-top:10px"><input type="checkbox" id="g24" ${CFG.dia_24h === '1' ? 'checked' : ''}> El día cuenta 24 horas desde que entra (si no, sale a la hora de salida del día siguiente)</label></div>
    <div class="card"><h2>Unidades de negocio</h2><p class="sub" style="margin-top:0">Una por renglón. Cada habitación, departamento o local se asigna a una (ej. los departamentos del callejón). Salen separadas en Habitaciones, en los reportes, en la gráfica de pastel y en el cierre de mes.</p>
      <textarea id="gUn" rows="4">${esc(CFG.unidades_negocio || '')}</textarea></div>
    <div class="card"><h2>Multas, cuotas e intereses</h2>
      <div class="f"><label class="l">Servicio de limpieza (precio; se vende en Tienda o se carga a la habitación)<input id="gCl" type="number" min="0" step="0.01" value="${esc(CFG.cuota_limpieza || '0')}"></label>
        <label class="l">Cuota por mascota (por estancia)<input id="gCm" type="number" min="0" step="0.01" value="${esc(CFG.cuota_mascota || '0')}"></label>
        <label class="l">Precio general de visita<input id="gPv" type="number" min="0" step="0.01" value="${esc(CFG.precio_visita || '0')}"></label></div>
      <label class="l" style="margin-top:8px">Multas (una por renglón: nombre: monto)<textarea id="gMu" rows="3" placeholder="Ruido: 500">${esc(CFG.multas_lista || '')}</textarea></label>
      <div class="lbl" style="margin-top:10px">Interés moratorio (solo rentas por semana y por mes: departamentos del callejón, otros deptos., locales y cuartos por semana/mes)</div>
      <label class="row" style="font-weight:600"><input type="checkbox" id="gMa" ${CFG.mora_activa !== '0' ? 'checked' : ''}> Cobrar interés si no pagan a tiempo</label>
      <div class="f"><label class="l">Se cobra<select id="gMt"><option value="porcentaje">Porcentaje de la renta atrasada</option><option value="fijo" ${CFG.mora_tipo === 'fijo' ? 'selected' : ''}>Cantidad fija</option></select></label>
        <label class="l">Porcentaje o cantidad<input id="gMv" type="number" min="0" step="0.01" value="${esc(CFG.mora_valor || '10')}"></label>
        <label class="l">Días de gracia después del vencimiento<input id="gMd" type="number" min="0" max="30" value="${esc(CFG.mora_dias ?? '1')}"></label></div>
      <p class="sub" style="margin-bottom:0">Ejemplo: renta de $6,000 que vence el día 1 y no se paga: el día 2 se carga solo el 10% ($600) a la cuenta. Se cobra una vez por cada renta atrasada, también cuando no se cerró la renta y el sistema cobró otro periodo solo. <b>No aplica a ratos, noches ni días.</b></p></div>
    <div class="card"><h2>Seguridad de caja</h2><label class="row" style="font-weight:600"><input type="checkbox" id="gAe" ${CFG.autoriza_egresos !== '0' ? 'checked' : ''}> Los egresos de caja piden la clave de un gerente o del administrador</label>
      <label class="row" style="font-weight:600;margin-top:6px"><input type="checkbox" id="gAg" ${CFG.autoriza_gastos === '1' ? 'checked' : ''}> También los gastos pagados en efectivo con dinero de la caja</label></div>
    <div class="card"><h2>Check out sin registrar</h2><label class="row" style="font-weight:600"><input type="checkbox" id="gCa" ${CFG.cobro_auto !== '0' ? 'checked' : ''}> Si llega la hora del check out y no se registró la salida, cobrar otro periodo automáticamente</label>
      <p class="sub">Se carga otro rato, otra noche, otro día, otra semana u otro mes (según la renta) al mismo precio. Queda en la cuenta del huésped y se cobra al registrar la salida. Se anota en la bitácora de la habitación.</p>
      <div class="f"><label class="l">Minutos de tolerancia después del check out<input id="gCt" type="number" min="0" max="600" value="${esc(CFG.cobro_auto_tolerancia ?? '15')}"></label></div></div>
    <div class="card"><h2>Colores de las habitaciones</h2><p class="sub" style="margin-top:0">Las ocupadas se pintan con el color de su tipo de renta. Antes de vencer cambian al color "Por vencer".</p>
    <div class="f">${col('libre', 'Disponible', CFG.color_libre || '#1b845a')}${col('limpieza', 'En limpieza', CFG.color_limpieza || '#b77a06')}${col('mant', 'Mantenimiento', CFG.color_mant || '#6550b8')}</div>
    <div class="lbl" style="margin-top:10px">Ocupada</div><div class="f">${ORDEN_MOD.map((m) => col(m, MOD[m], CFG['color_' + m])).join('')}</div>
    <div class="lbl" style="margin-top:10px">Avisos</div><div class="f">${col('porvencer', 'Por vencer', CFG.color_porvencer || '#ea580c')}${col('vencida', 'Salida vencida', CFG.color_vencida || '#c03434')}
      <label class="l">Rato, noche y día: avisar horas antes<input id="gAh" type="number" min="0" step="0.5" value="${esc(CFG.aviso_horas || '1')}"></label><label class="l">Semana y mes: avisar días antes<input id="gAd" type="number" min="0" value="${esc(CFG.aviso_dias || '1')}"></label></div>
    <div class="leyenda" id="gLey" style="margin:12px 0 0"></div></div>
    <div class="card"><h2>Módulos</h2><label class="row" style="font-weight:600"><input type="checkbox" id="gMc" ${CFG.modulo_contratos !== '0' ? 'checked' : ''}> Contratos de arrendamiento (para departamentos por semana o mes)</label>
      <p class="sub" style="margin-bottom:0">Si lo apaga, se esconde del menú y de la cuenta del huésped. Los contratos ya hechos se conservan.</p></div>
    <div><button class="btn pri" onclick="hotelOk()">Guardar</button></div></div>`;
  cfgPrev();
}
function cfgPrev() {
  const r = document.documentElement.style, v = (k) => val('gc_' + k);
  for (const m of ORDEN_MOD) r.setProperty('--m-' + m, v(m));
  r.setProperty('--libre', v('libre')); r.setProperty('--limp', v('limpieza')); r.setProperty('--mant', v('mant')); r.setProperty('--porvencer', v('porvencer')); r.setProperty('--vencida', v('vencida'));
  $('#gLey').innerHTML = `<span class="pill" style="--c:var(--libre);--b:color-mix(in srgb,var(--libre) 14%,var(--panel))">Disponible</span><span class="pill s-limpieza">En limpieza</span><span class="pill s-mant">Mantenimiento</span>${ORDEN_MOD.map((m) => `<span class="pill mod m-${m}">${MOD[m]}</span>`).join('')}<span class="pill" style="--c:var(--porvencer);--b:color-mix(in srgb,var(--porvencer) 14%,var(--panel))">Por vencer</span><span class="pill" style="--c:var(--vencida);--b:color-mix(in srgb,var(--vencida) 14%,var(--panel))">Vencida</span>`;
}
async function hotelOk() {
  const b = { hotel_nombre: val('gN') || 'Mi Hotel', hotel_direccion: val('gD'), hotel_telefono: val('gT'), hora_salida: val('gS') || '13:00', ticket_pie: val('gP'), ticket_ancho: val('gA'),
    horas_rato: String(Math.max(0.5, num('gHr') || 3)), hora_salida_noche: val('gSn') || '12:00', dia_24h: $('#g24').checked ? '1' : '0', modulo_contratos: $('#gMc').checked ? '1' : '0',
    aviso_horas: String(num('gAh')), aviso_dias: String(num('gAd')), cobro_auto: $('#gCa').checked ? '1' : '0', cobro_auto_tolerancia: String(Math.max(0, num('gCt'))),
    unidades_negocio: $('#gUn').value.trim() || 'Hotel', cuota_limpieza: String(num('gCl')), limpieza_auto: 'no', cuota_mascota: String(num('gCm')), precio_visita: String(num('gPv')), multas_lista: $('#gMu').value.trim(),
    mora_activa: $('#gMa').checked ? '1' : '0', mora_tipo: val('gMt'), mora_valor: String(num('gMv')), mora_dias: String(Math.max(0, parseInt(val('gMd')) || 0)), autoriza_egresos: $('#gAe').checked ? '1' : '0', autoriza_gastos: $('#gAg').checked ? '1' : '0' };
  for (const k of [...ORDEN_MOD, 'libre', 'limpieza', 'mant', 'porvencer', 'vencida']) b['color_' + k] = val('gc_' + k);
  await hacer(() => PUT('/api/config', b), 'Guardado');
  CFG = await GET('/api/config'); aplicarColores(); marco(); pintarTurno(); ir('cfg');
}
async function cHabs() {
  const H = sortH(await GET('/api/habitaciones')); cHabs.l = H;
  $('#cfgc').innerHTML = `<div class="card"><div class="row" style="justify-content:space-between;margin-bottom:10px"><h2 style="margin:0">Habitaciones y departamentos · ${H.length}</h2><button class="btn pri" onclick="habModal()">Agregar habitación</button></div>
    <div class="tw"><table><thead><tr><th>Número</th><th>Tipo</th><th>Piso</th><th>Incluye</th><th class="n">Día</th><th class="n">Semana</th><th class="n">Mes</th><th>Estado</th></tr></thead><tbody>
    ${H.map((h) => `<tr class="click" onclick="habModal(${h.id})"><td><b>${esc(h.numero)}</b><div class="sub">${esc(h.nombre || '')}</div></td><td>${h.clase === 'departamento' ? 'Departamento' : 'Habitación'}</td><td>${esc(h.piso || '')}</td><td>${feats(h)}${amenIcons(h)}</td>
      <td class="n">${h.precio_dia ? money(h.precio_dia) : '—'}</td><td class="n">${h.precio_semana ? money(h.precio_semana) : '—'}</td><td class="n">${h.precio_mes ? money(h.precio_mes) : '—'}</td><td><span class="pill s-${h.estado}">${EST[h.estado]}</span></td></tr>`).join('') || '<tr><td colspan="8" class="empty">Agregue su primera habitación.</td></tr>'}</tbody></table></div></div>`;
}
function habModal(id) {
  const h = id ? cHabs.l.find((x) => x.id === id) : { numero: '', nombre: '', clase: 'habitacion', piso: '1', camas: { matrimonial: 1 }, recamaras: 1, banos: 1, capacidad: 2, amenidades: ['wifi', 'tv'], precio_rato: '', precio_noche: '', precio_dia: '', precio_semana: '', precio_mes: '' };
  const cont = (idc, label, icon, v) => `<div class="contador"><span>${icon ? ico(icon) : ''}${label}</span><span class="qty"><button type="button" onclick="mas('${idc}',-1)">−</button><b id="${idc}">${v || 0}</b><button type="button" onclick="mas('${idc}',1)">+</button></span></div>`;
  const UN = [...new Set([...unidadesCfg(), ...(cHabs.l || []).map(unidadDe)])], uh = id ? unidadDe(h) : (fUni || UN[0] || 'Hotel');
  modal(id ? `Editar ${esc(h.numero)}` : 'Agregar habitación, departamento o local', `
    ${id ? '' : `<div class="seg"><label><input type="radio" name="hCant" value="una" checked>Agregar una</label><label><input type="radio" name="hCant" value="varias" onchange="cerrar();loteModal()">Agregar varias a la vez</label></div>`}
    <div class="seg"><label><input type="radio" name="hC" value="habitacion" ${h.clase === 'habitacion' || !h.clase ? 'checked' : ''}>${ico('cama')} Habitación</label><label><input type="radio" name="hC" value="departamento" ${h.clase === 'departamento' ? 'checked' : ''}>${ico('edificio')} Departamento</label><label><input type="radio" name="hC" value="local" ${h.clase === 'local' ? 'checked' : ''}>${ico('local')} Local comercial</label></div>
    <div class="f"><label class="l">Número<input id="hN" value="${esc(h.numero)}" placeholder="101, D1, L1…"></label><label class="l">Nombre o descripción<input id="hD" value="${esc(h.nombre || '')}" placeholder="Sencilla, Suite…"></label><label class="l">Piso<input id="hP" value="${esc(h.piso || '')}"></label>
      <label class="l">Unidad de negocio<select id="hU">${UN.map((u) => `<option ${u === uh ? 'selected' : ''}>${esc(u)}</option>`).join('')}</select></label>
      ${puede('autorizar') ? `<label class="l">Precio fijo de visita<input id="hVi" type="number" min="0" step="0.01" value="${h.precio_visita ?? ''}" placeholder="Igual al general (${money(CFG.precio_visita)})"></label>` : `<div class="l">Precio de visita<b style="padding-top:8px">${money(h.precio_visita ?? CFG.precio_visita)}</b><small class="sub">Solo el gerente o el administrador lo cambia</small></div>`}</div>
    <div class="lbl">Camas</div><div class="f cont">${Object.keys(CAMA).map((k) => cont('cama_' + k, CAMA[k], 'cama', h.camas[k])).join('')}</div>
    <div class="lbl">Espacios</div><div class="f cont">${cont('hR', 'Recámaras / cuartos', 'recamara', h.recamaras)}${cont('hB', 'Baños', 'bano', h.banos)}${cont('hCap', 'Capacidad (personas)', 'personas', h.capacidad)}</div>
    <div class="lbl">Qué incluye</div><div class="chipsel">${Object.entries(AMEN).map(([k, n]) => `<label><input type="checkbox" name="hA" value="${k}" ${h.amenidades.includes(k) ? 'checked' : ''}>${ico(k)}${n}</label>`).join('')}</div>
    <div class="lbl">Precios por horas, noche o día (deje vacío el que no maneje)</div>
    <div class="f">${CORTAS.map((m) => `<label class="l"><span><i class="dot" style="display:inline-block;width:10px;height:10px;border-radius:50%;background:var(--m-${m});margin-right:6px"></i>${modTxt(m)}</span><input id="hp_${m}" type="number" min="0" step="0.01" value="${h['precio_' + m] || ''}"></label>`).join('')}</div>
    <div class="lbl">Precios de larga estancia</div><div class="f">${LARGAS.map((m) => `<label class="l"><span><i class="dot" style="display:inline-block;width:10px;height:10px;border-radius:50%;background:var(--m-${m});margin-right:6px"></i>${modTxt(m)}</span><input id="hp_${m}" type="number" min="0" step="0.01" value="${h['precio_' + m] || ''}"></label>`).join('')}</div>`,
  `${id ? `<button class="btn bad" onclick="confirmar(this,()=>habBorrar(${id}))">Eliminar</button>` : ''}<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="habOk(${id || 0})">Guardar</button>`, true);
}
function mas(id, d) { const el = $('#' + id); const min = id === 'hR' || id === 'hCap' ? 1 : 0; el.textContent = Math.max(min, Math.min(20, (parseInt(el.textContent) || 0) + d)); }
async function habOk(id) {
  const camas = {}; for (const k of Object.keys(CAMA)) camas[k] = parseInt($('#cama_' + k).textContent) || 0;
  const b = { numero: val('hN'), nombre: val('hD'), piso: val('hP'), clase: document.querySelector('input[name=hC]:checked').value, unidad: val('hU'), ...($('#hVi') ? { precio_visita: val('hVi') } : {}), camas, recamaras: $('#hR').textContent, banos: $('#hB').textContent, capacidad: $('#hCap').textContent,
    amenidades: [...document.querySelectorAll('input[name=hA]:checked')].map((x) => x.value), precio_rato: val('hp_rato'), precio_noche: val('hp_noche'), precio_dia: val('hp_dia'), precio_semana: val('hp_semana'), precio_mes: val('hp_mes') };
  await hacer(() => (id ? PUT('/api/habitaciones/' + id, b) : POST('/api/habitaciones', b)), 'Habitación guardada'); cerrar(); cHabs();
}
async function habBorrar(id) { await hacer(() => DEL('/api/habitaciones/' + id), 'Habitación eliminada'); cerrar(); cHabs(); }
async function cUsers() {
  const U = await GET('/api/usuarios'); cUsers.l = U;
  $('#cfgc').innerHTML = `<div class="card"><div class="row" style="justify-content:space-between;margin-bottom:10px"><h2 style="margin:0">Usuarios</h2><button class="btn pri" onclick="userModal()">Nuevo usuario</button></div>
    <p class="sub" style="margin-top:0"><b>Administrador</b>: todo. <b>Recepción</b>: registrar huéspedes, visitantes, vender y cambiar estados. <b>Monitoreo</b>: solo ver (ideal para el dueño desde el celular). <b>Mantenimiento</b>: solo ve y atiende los reportes de mantenimiento, con fotos desde su celular.</p>
    <div class="tw"><table><thead><tr><th>Nombre</th><th>Usuario</th><th>Tipo</th><th>Estado</th></tr></thead><tbody>${U.map((u) => `<tr class="click" onclick="userModal(${u.id})"><td><b>${esc(u.nombre)}</b></td><td class="mono">${esc(u.usuario)}</td><td>${ROL[u.rol]}</td><td>${u.activo ? '<span class="pill p-ok">Activo</span>' : '<span class="pill p-bad">Inactivo</span>'}</td></tr>`).join('')}</tbody></table></div></div>`;
}
function userModal(id) {
  const u = id ? cUsers.l.find((x) => x.id === id) : { nombre: '', usuario: '', rol: 'recepcion', activo: 1 };
  modal(id ? 'Editar usuario' : 'Nuevo usuario', `<div class="f"><label class="l">Nombre<input id="uN" value="${esc(u.nombre)}"></label><label class="l">Usuario<input id="uU" value="${esc(u.usuario)}" ${id ? 'disabled' : ''} autocapitalize="off"></label>
    <label class="l">Tipo<select id="uR">${Object.entries(ROL).map(([k, n]) => `<option value="${k}" ${u.rol === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label><label class="l">${id ? 'Nueva contraseña (opcional)' : 'Contraseña'}<input id="uP" type="password" autocomplete="new-password"></label></div>
    ${id ? `<label class="row" style="font-weight:600"><input type="checkbox" id="uA" ${u.activo ? 'checked' : ''}> Usuario activo</label>` : ''}`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="userOk(${id || 0})">Guardar</button>`);
}
async function userOk(id) {
  const b = { nombre: val('uN'), rol: val('uR'), password: $('#uP').value || undefined };
  if (id) b.activo = $('#uA').checked; else b.usuario = val('uU');
  await hacer(() => (id ? PUT('/api/usuarios/' + id, b) : POST('/api/usuarios', b)), 'Usuario guardado'); cerrar(); cUsers();
}
function cRemoto() {
  const ips = CFG._ips || [], ts = ips.filter((i) => i.tailscale), loc = ips.filter((i) => !i.tailscale), p = CFG._puerto;
  $('#cfgc').innerHTML = `<div class="stack">
    <div class="card"><h2>Desde el celular, en el WiFi del hotel</h2>${loc.map((i) => `<div class="codigo" style="font-size:18px">http://${esc(i.ip)}:${p}</div>`).join('') || '<div class="empty">Sin red local.</div>'}<p class="sub">Entre con un usuario de tipo <b>Monitoreo</b> (solo ver) o Recepción.</p></div>
    <div class="card"><h2>Desde fuera del hotel (recomendado: Tailscale)</h2>
      ${ts.length ? `<div class="aviso ok">Tailscale está activo en esta computadora. Desde el celular, con Tailscale encendido y la misma cuenta, abra:</div>${ts.map((i) => `<div class="codigo" style="font-size:18px">http://${esc(i.ip)}:${p}</div>`).join('')}`
    : '<div class="aviso">Tailscale todavía no está instalado en esta computadora. Siga los pasos de abajo.</div>'}
      <ol style="padding-left:20px;line-height:1.7"><li>En esta computadora: entre a <b>tailscale.com/download</b>, instale para Windows e inicie sesión con una cuenta de Google del hotel.</li>
      <li>En el celular del dueño: instale <b>Tailscale</b> (Play Store o App Store) y entre con <b>la misma cuenta</b>.</li>
      <li>Regrese aquí: aparecerá la dirección que empieza con <b>100.</b> Ábrala en el navegador del celular y agréguela a la pantalla de inicio.</li></ol>
      <p class="sub">No hay que abrir puertos en el módem, funciona aunque el internet sea de Telmex, Izzi, Totalplay o celular, y la conexión va cifrada.</p></div>
    ${puede('admin') ? `<div class="card"><h2>Acceso directo desde internet (No-IP / DDNS)</h2>
      <p class="sub" style="margin-top:0">Solo si no puede usar Tailscale. Requiere abrir el puerto ${p} en el módem y que el proveedor de internet le dé IP pública. La conexión NO va cifrada; use contraseñas fuertes.</p>
      <label class="row" style="font-weight:600"><input type="checkbox" id="pi" ${CFG.permitir_internet === '1' ? 'checked' : ''}> Permitir conexiones desde internet</label>
      <div style="margin-top:10px"><button class="btn" onclick="internetOk()">Guardar</button></div></div>` : ''}</div>`;
}
async function internetOk() { await hacer(() => PUT('/api/config', { permitir_internet: $('#pi').checked }), 'Guardado'); CFG = await GET('/api/config'); }
async function cResp() {
  const [r, l] = await Promise.all([GET('/api/respaldos'), GET('/api/licencia/estado')]);
  $('#cfgc').innerHTML = `<div class="stack"><div class="card"><h2>Licencia</h2><div class="kv"><span>Estado</span><b>${l.activa ? 'Activa' : 'Inactiva'}</b><span>Cliente</span><span>${esc(l.cliente || '—')}</span><span>Vence</span><span>${l.expira ? fd(l.expira) + ' (' + l.diasRestantes + ' días)' : 'Permanente'}</span><span>Código de equipo</span><span class="mono">${esc(l.codigoEquipo)}</span><span>Versión</span><span>${esc(l.version)}</span></div>
    <label class="l" style="margin-top:12px">Renovar licencia<textarea id="lic" rows="3" style="font-family:var(--fMono)"></textarea></label><div style="margin-top:8px"><button class="btn" onclick="activar()">Activar licencia nueva</button></div></div>
    <div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h2 style="margin:0">Respaldos</h2><button class="btn pri" onclick="respaldoOk()">Respaldar ahora</button></div>
    <p class="sub" style="margin-top:0">Se hace un respaldo automático cada día y se guardan los últimos 30 en C:\\MaxselHotel\\app\\datos\\respaldos. Copie esa carpeta a una USB de vez en cuando.</p>
    <div class="tw"><table><tbody>${r.map((x) => `<tr><td class="mono">${esc(x.archivo)}</td><td class="n">${(x.tam / 1024).toFixed(0)} KB</td></tr>`).join('') || '<tr><td class="empty">Aún no hay respaldos.</td></tr>'}</tbody></table></div></div></div>`;
}
async function respaldoOk() { await hacer(() => POST('/api/respaldos'), 'Respaldo creado'); cResp(); }
function cPass() {
  $('#cfgc').innerHTML = `<div class="card" style="max-width:480px"><h2>Cambiar mi contraseña</h2><div class="stack" style="gap:10px"><label class="l">Contraseña actual<input id="pa" type="password" autocomplete="current-password"></label>
    <label class="l">Nueva contraseña (mínimo 6)<input id="pn" type="password" autocomplete="new-password"></label><div><button class="btn pri" onclick="passOk()">Cambiar</button></div></div></div>`;
}
async function passOk() { await hacer(() => POST('/api/mi-password', { actual: $('#pa').value, nueva: $('#pn').value }), 'Contraseña cambiada'); cPass(); }

