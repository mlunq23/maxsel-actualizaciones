// Maxsel Hotel 1.11 — pasar toda la información a otra computadora (Configuración → Respaldos y licencia)
const _cRespExp = cResp;
cResp = async function () {
  await _cRespExp();
  if (typeof cfgTab !== 'undefined' && cfgTab !== 'resp') return;
  const st = $('#cfgc .stack'); if (!st || $('#expCard')) return;
  st.insertAdjacentHTML('beforeend', `<div class="card" id="expCard"><h2>Pasar la información a otra computadora</h2>
    <p class="sub" style="margin-top:0">Arme y pruebe el hotel en una computadora y después páselo a la del cliente con un solo archivo.</p>
    <div class="lbl">1. En la computadora donde ya está todo cargado</div>
    <div class="stack" style="gap:8px;margin:6px 0 16px">
      <div class="row" style="gap:10px;align-items:flex-start"><button class="btn pri" style="flex:0 0 auto" onclick="exportarOk('config')">Exportar solo la configuración</button>
        <span class="sub">Lleva habitaciones, precios, productos de la tienda, usuarios y contraseñas, empleados, proveedores, lista de no deseados, logo, contrato, aviso de privacidad y toda la configuración.
        <b>No lleva</b> las rentas, ventas, cortes, gastos ni reportes de prueba: el hotel llega limpio, con todas las habitaciones libres y los folios en 1.</span></div>
      <div class="row" style="gap:10px;align-items:flex-start"><button class="btn" style="flex:0 0 auto" onclick="exportarOk('todo')">Exportar toda la información</button>
        <span class="sub">Copia completa, con todos los movimientos y fotos. Úsela para cambiar el hotel de computadora sin perder nada.</span></div>
    </div>
    <div class="lbl">2. En la computadora del cliente (ya instalada y con su licencia activa)</div>
    <div class="stack" style="gap:8px;margin-top:6px">
      <input type="file" id="impF" accept=".maxsel" onchange="importarVer()">
      <label class="row" style="gap:6px"><input type="checkbox" id="impC" checked> Conservar la impresora configurada en esta computadora</label>
      <div id="impV"></div>
    </div></div>`);
};
async function exportarOk(modo) {
  toast('Preparando el archivo…');
  try {
    const r = await fetch('/api/exportar?modo=' + modo, { credentials: 'same-origin' });
    if (!r.ok) { let e = {}; try { e = await r.json(); } catch { /* nada */ } throw new Error(e.error || 'Error ' + r.status); }
    const nombre = /filename="([^"]+)"/.exec(r.headers.get('content-disposition') || '')?.[1] || 'Maxsel Hotel.maxsel';
    const blob = await r.blob();
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = nombre; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast('Guardado en Descargas: ' + nombre + '. Páselo en una USB a la otra computadora.');
  } catch (e) { toast(e.message, true); }
}
async function leerExportacion(f) {
  const s = f.stream().pipeThrough(new DecompressionStream('gzip'));
  return JSON.parse(await new Response(s).text());
}
async function importarVer() {
  const f = $('#impF').files[0], v = $('#impV'); v.innerHTML = '';
  if (!f) return;
  v.innerHTML = '<div class="sub">Leyendo el archivo…</div>';
  let d;
  try { d = await leerExportacion(f); if (d.firma !== 'MAXSEL-HOTEL-EXPORTAR-1') throw new Error(); } catch { v.innerHTML = '<div class="pill p-bad">Este archivo no es una exportación de Maxsel Hotel o está dañado.</div>'; return; }
  const R = d.resumen || {};
  v.innerHTML = `<div class="card" style="background:var(--bg2,transparent);border:2px solid #d9534f">
    <div class="kv"><span>Hotel</span><b>${esc(d.hotel || '—')}</b><span>Exportado</span><span>${fdt(d.fecha)} por ${esc(d.usuario || '')}</span>
    <span>Contenido</span><b>${d.modo === 'config' ? 'Solo configuración (sin movimientos)' : 'Información completa'}</b>
    <span>Habitaciones</span><span>${R.habitaciones ?? '—'}</span><span>Productos</span><span>${R.productos ?? '—'}</span><span>Usuarios</span><span>${R.usuarios ?? '—'}</span>
    ${d.modo === 'todo' ? `<span>Rentas</span><span>${R.estancias ?? 0}</span><span>Ventas de tienda</span><span>${R.ventas ?? 0}</span><span>Fotos</span><span>${d.fotos || 0}</span>` : ''}</div>
    <p style="margin:12px 0 6px"><b>Atención:</b> se va a reemplazar TODA la información de esta computadora por la del archivo. Antes se guarda un respaldo de lo que hay aquí.
    Después tendrá que entrar con los usuarios y contraseñas de la otra computadora.</p>
    <label class="row" style="gap:6px;margin-bottom:10px"><input type="checkbox" id="impS"> Entiendo, quiero reemplazar la información</label>
    <button class="btn pri" onclick="expImportarOk()">Importar ahora</button></div>`;
}
async function expImportarOk() {
  const f = $('#impF').files[0];
  if (!f) return toast('Elija el archivo .maxsel', true);
  if (!$('#impS').checked) return toast('Marque la casilla para confirmar que quiere reemplazar la información', true);
  $('#impV').innerHTML = '<div class="sub">Importando… no cierre el sistema.</div>';
  try {
    const r = await fetch('/api/importar?conservar=' + ($('#impC').checked ? '1' : '0'), { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: f, credentials: 'same-origin' });
    let d = {}; try { d = await r.json(); } catch { /* nada */ }
    if (!r.ok) throw new Error(d.error || 'Error ' + r.status);
    modal('Información importada', `<p>Se cargó la información de <b>${esc(d.hotel || 'la otra computadora')}</b>.</p>
      <p>Lo que había antes en esta computadora quedó respaldado en <span class="mono">${esc(d.respaldo || '')}</span>.</p>
      <p>${d.servicio ? 'El sistema se está reiniciando. En unos segundos vuelva a entrar' : 'Cierre el sistema y vuelva a abrirlo. Después entre'} con un usuario y contraseña de la otra computadora.</p>`,
    '<button class="btn pri" onclick="location.reload()">Volver a entrar</button>');
  } catch (e) { $('#impV').innerHTML = ''; toast(e.message, true); }
}
