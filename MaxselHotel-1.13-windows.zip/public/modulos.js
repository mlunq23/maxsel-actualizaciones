'use strict';
// Maxsel 2026: Gastos y Asistencia son módulos aparte. Se encienden o apagan desde la licencia que entrega Maxsel.
const modOn = (k) => !(YO && YO.licencia && YO.licencia.modulos && YO.licencia.modulos[k] === false);
{
  const quitar = () => {
    const fuera = [];
    if (!modOn('gastos')) fuera.push('gastos');
    if (!modOn('asistencia')) fuera.push('asis');
    for (let i = VISTAS.length - 1; i >= 0; i--) if (fuera.includes(VISTAS[i][0])) VISTAS.splice(i, 1);
  };
  const _pn = pintarNav;
  pintarNav = function (...a) { quitar(); return _pn.apply(this, a); };
  const _ir = ir;
  ir = function (v, ...a) {
    if ((v === 'gastos' && !modOn('gastos')) || (v === 'asis' && !modOn('asistencia'))) { toast(`El módulo de ${v === 'gastos' ? 'Gastos' : 'Asistencia'} no está incluido en su licencia. Comuníquese con Maxsel.`, true); return; }
    return _ir.call(this, v, ...a);
  };
  if (typeof gastoModal === 'function') {
    const _g = gastoModal;
    gastoModal = function (...a) { if (!modOn('gastos')) return toast('El módulo de Gastos no está incluido en su licencia. Comuníquese con Maxsel.', true); return _g.apply(this, a); };
  }
  if (typeof avisosGastos === 'function') { const _a = avisosGastos; avisosGastos = function (...a) { if (modOn('gastos')) return _a.apply(this, a); return Promise.resolve([]); }; }
}
