// Maxsel Hotel 1.8 — Inventario de tienda: productos, departamentos, conteo físico (hoja PDF y captura) y movimientos
'use strict';
let iTab = 'prod', AREAS_T = [], CONTEO = null;
const TIPO_MOV = { entrada: 'Entrada', venta: 'Venta', ajuste: 'Ajuste', cancelacion: 'Cancelación' };
const nomArea = (p) => p.area || 'Sin departamento';
const mDif = (v) => (v < 0 ? '−' + money(-v) : v > 0 ? '+' + money(v) : money(0));
async function vInv() {
  const [ps, ar] = await Promise.all([GET('/api/productos'), GET('/api/tienda/areas')]); PRODS = ps; AREAS_T = ar.areas;
  const valor = ps.filter((p) => !p.servicio).reduce((s, p) => s + p.existencia * p.costo, 0);
  const T = [['prod', 'Productos'], ['areas', 'Departamentos'], ...(puede('inventario') ? [['conteo', 'Conteo físico']] : []), ['mov', 'Movimientos']];
  if (!T.some((t) => t[0] === iTab)) iTab = 'prod';
  const acc = iTab === 'prod' ? `<button class="btn" onclick="exportarProductos()">Exportar a Excel</button>${puede('productos') ? '<button class="btn" onclick="importarProductos()">Importar de Excel</button>' : ''}${puede('inventario') ? '<button class="btn op" onclick="entradaModal()">Entrada de mercancía</button>' : ''}${puede('productos') ? '<button class="btn pri" onclick="prodModal()">Nuevo producto</button>' : ''}`
    : iTab === 'areas' && puede('productos') ? '<button class="btn pri" onclick="areaModal()">Nuevo departamento</button>' : '';
  $('#main').innerHTML = cab('Inventario', `${ps.length} productos · valor a costo ${money(valor)}`, acc)
    + `<div class="tabs" style="margin-bottom:14px">${T.map(([k, n]) => `<button class="${iTab === k ? 'on' : ''}" onclick="iTab='${k}';vInv()">${n}</button>`).join('')}</div><div id="invc"></div>`;
  await ({ prod: invProductos, areas: invAreas, conteo: invConteo, mov: invMov })[iTab]();
}
// ---------- Productos ----------
function invProductos() {
  const ps = PRODS, A = [...new Set(ps.map(nomArea))].sort((a, b) => a.localeCompare(b, 'es')), vis = ps.filter((p) => !tArea || nomArea(p) === tArea);
  const est = (p) => p.servicio ? '<span class="pill">Servicio</span>' : p.existencia <= 0 ? '<span class="pill p-bad">Agotado</span>' : p.existencia <= p.minimo ? '<span class="pill p-warn">Surtir</span>' : '<span class="pill p-ok">Bien</span>';
  if (tArea && !A.includes(tArea)) tArea = '';
  $('#invc').innerHTML = `<div class="card">${A.length > 1 ? `<div class="chips areas" style="margin-bottom:10px"><button class="chip ${!tArea ? 'on' : ''}" onclick="tArea='';vInv()">Todos</button>${A.map((a) => `<button class="chip ${tArea === a ? 'on' : ''}" data-a="${esc(a)}" onclick="tArea=this.dataset.a;vInv()">${esc(a)} <small>${ps.filter((p) => nomArea(p) === a).length}</small></button>`).join('')}</div>` : ''}
    <div class="tw"><table><thead><tr><th>Código</th><th>Producto</th><th>Departamento</th><th class="n">Costo</th><th class="n">Precio</th><th class="n">Existencia</th><th class="n">Mínimo</th><th>Estado</th><th></th></tr></thead><tbody>
    ${vis.map((p) => `<tr><td class="mono">${esc(p.codigo || '')}</td><td><b>${esc(p.nombre)}</b></td><td>${esc(p.area || '')}</td><td class="n">${money(p.costo)}</td><td class="n">${money(p.precio)}</td><td class="n"><b>${p.servicio ? '—' : p.existencia}</b></td><td class="n">${p.servicio ? '—' : p.minimo}</td><td>${est(p)}</td>
      <td style="white-space:nowrap">${puede('productos') ? `<button class="btn sm" onclick="prodModal(${p.id})">Editar</button> <button class="btn sm bad" onclick="confirmar(this,()=>prodBorrar(${p.id}))">Eliminar</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="9" class="empty">Agregue su primer producto o impórtelos de Excel.</td></tr>'}</tbody></table></div></div>`;
}
async function prodBorrar(id) { await hacer(() => DEL('/api/productos/' + id), 'Producto eliminado'); cerrar(); vInv(); }
// Departamento al crear o editar un producto: lista con opción de crear uno nuevo
{
  const _pm = prodModal;
  prodModal = function (id) {
    _pm(id);
    const inp = $('#pAr'); if (!inp) return;
    const actual = inp.value, l = [...new Set([...AREAS_T.map((a) => a.nombre), ...PRODS.map((x) => x.area).filter(Boolean)])].sort((a, b) => a.localeCompare(b, 'es'));
    inp.closest('label').outerHTML = `<label class="l">Departamento<select id="pArS" onchange="$('#pArN').hidden=this.value!=='__nuevo';if(this.value==='__nuevo')$('#pArN').focus()"><option value="">Sin departamento</option>${l.map((a) => `<option ${a === actual ? 'selected' : ''}>${esc(a)}</option>`).join('')}<option value="__nuevo">+ Nuevo departamento…</option></select>
      <input id="pArN" placeholder="Nombre del departamento nuevo" hidden></label><input type="hidden" id="pAr" value="${esc(actual)}">`;
  };
  const _ok = prodOk;
  prodOk = async function (id) {
    const s = $('#pArS'); if (s) $('#pAr').value = s.value === '__nuevo' ? val('pArN') : s.value;
    if (s?.value === '__nuevo' && val('pArN')) await POST('/api/tienda/areas', { nombre: val('pArN') }).catch(() => {});
    return _ok(id);
  };
}
// ---------- Departamentos ----------
function invAreas() {
  const sin = PRODS.filter((p) => !p.area).length;
  $('#invc').innerHTML = `<div class="card"><p class="sub" style="margin-top:0">Los departamentos agrupan los productos en la tienda (botones de arriba) y en los reportes de ventas por área. Al eliminar un departamento sus productos NO se borran: quedan "Sin departamento".</p>
    <div class="tw"><table><thead><tr><th>Departamento</th><th class="n">Productos</th><th class="n">Valor a costo</th><th></th></tr></thead><tbody>
    ${AREAS_T.map((a, i) => `<tr><td><b>${esc(a.nombre)}</b></td><td class="n">${a.productos}</td><td class="n">${money(PRODS.filter((p) => p.area === a.nombre && !p.servicio).reduce((s, p) => s + p.existencia * p.costo, 0))}</td>
      <td style="white-space:nowrap">${puede('productos') ? `<button class="btn sm" onclick="tArea=AREAS_T[${i}].nombre;iTab='prod';vInv()">Ver productos</button> <button class="btn sm" onclick="areaModal(${i})">Renombrar</button> <button class="btn sm bad" onclick="confirmar(this,()=>areaBorrar(${i}))">Eliminar</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="4" class="empty">No hay departamentos. Cree el primero (Bebidas, Botanas, Abarrotes…).</td></tr>'}
    ${sin ? `<tr><td class="sub">Sin departamento</td><td class="n">${sin}</td><td></td><td><button class="btn sm" onclick="tArea='Sin departamento';iTab='prod';vInv()">Ver productos</button></td></tr>` : ''}</tbody></table></div></div>`;
}
function areaModal(i) {
  const a = i !== undefined ? AREAS_T[i] : null;
  modal(a ? 'Renombrar departamento' : 'Nuevo departamento', `<label class="l">Nombre<input id="arN" value="${esc(a?.nombre || '')}" placeholder="Ej. Bebidas, Botanas, Farmacia"></label>${a ? `<div class="sub">Sus ${a.productos} producto(s) pasan al nombre nuevo.</div>` : ''}`,
    `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="areaOk(${i ?? -1})">Guardar</button>`);
  $('#arN').onkeydown = (e) => { if (e.key === 'Enter') areaOk(i ?? -1); };
}
async function areaOk(i) {
  const n = val('arN'); if (!n) return toast('Escriba el nombre', true);
  await hacer(() => (i >= 0 ? PUT('/api/tienda/areas', { de: AREAS_T[i].nombre, a: n }) : POST('/api/tienda/areas', { nombre: n })), 'Departamento guardado');
  CFG = await GET('/api/config'); cerrar(); vInv();
}
async function areaBorrar(i) {
  const r = await hacer(() => DEL('/api/tienda/areas?nombre=' + encodeURIComponent(AREAS_T[i].nombre)), 'Departamento eliminado');
  if (r?.productos) toast(`Departamento eliminado. ${r.productos} producto(s) quedaron sin departamento.`);
  CFG = await GET('/api/config'); if (tArea === AREAS_T[i]?.nombre) tArea = ''; vInv();
}
// ---------- Conteo físico ----------
async function invConteo() {
  const H = await GET('/api/inventarios').catch(() => []), A = [...new Set(PRODS.filter((p) => !p.servicio).map(nomArea))].sort((a, b) => a.localeCompare(b, 'es'));
  $('#invc').innerHTML = `<div class="cols"><div class="card"><h2>1. Imprimir hoja de conteo</h2><p class="sub" style="margin-top:0">Imprima la hoja, cuente físicamente lo que hay en anaquel y bodega, y anote la cantidad real.</p>
      <div class="f"><label class="l">Departamento<select id="hcA"><option value="">Todos</option>${A.map((a) => `<option>${esc(a)}</option>`).join('')}</select></label>
        <label class="l">Ordenar por<select id="hcO"><option value="area">Departamento y nombre</option><option value="nombre">Nombre</option><option value="codigo">Código</option></select></label></div>
      <label class="row" style="font-weight:600"><input type="checkbox" id="hcC" style="width:auto"> Conteo a ciegas (no mostrar cuánto dice el sistema, recomendado)</label>
      <div style="margin-top:10px"><button class="btn pri" onclick="hojaConteo()">Imprimir / guardar PDF</button></div></div>
    <div class="card"><h2>2. Capturar el conteo</h2><p class="sub" style="margin-top:0">Escriba lo que contó (o escanee cada pieza). El sistema calcula faltantes y sobrantes con su valor y, al guardar, ajusta las existencias.</p>
      <div class="f"><label class="l">Departamento<select id="ccA"><option value="">Todos</option>${A.map((a) => `<option>${esc(a)}</option>`).join('')}</select></label></div>
      <div style="margin-top:10px"><button class="btn pri" onclick="capturaConteo(val('ccA'))">Empezar a capturar</button></div></div></div>
    <div class="card" style="margin-top:16px"><h2>Historial de conteos</h2><div class="tw"><table><thead><tr><th>Folio</th><th>Fecha</th><th>Departamento</th><th>Contó</th><th class="n">Productos</th><th class="n">Pzas. faltantes</th><th class="n">Pzas. sobrantes</th><th class="n">Faltante a costo</th><th class="n">Sobrante a costo</th></tr></thead><tbody>
    ${H.map((i) => `<tr class="click" onclick="verConteo(${i.id})"><td class="mono">${esc(i.folio)}</td><td>${fdt(i.fecha)}</td><td>${esc(i.area || 'Todos')}</td><td>${esc(i.usuario || '')}</td><td class="n">${i.productos}</td><td class="n" style="color:${i.faltantes ? 'var(--ocup)' : 'inherit'}">${i.faltantes}</td><td class="n">${i.sobrantes}</td><td class="n" style="color:${i.valor_faltante ? 'var(--ocup)' : 'inherit'}"><b>${money(i.valor_faltante)}</b></td><td class="n">${money(i.valor_sobrante)}</td></tr>`).join('') || '<tr><td colspan="9" class="empty">Todavía no hay conteos.</td></tr>'}</tbody></table></div></div>`;
}
const ordenarProds = (l, o) => l.slice().sort((a, b) => (o === 'codigo' ? String(a.codigo || '').localeCompare(String(b.codigo || ''), 'es', { numeric: true }) : o === 'nombre' ? a.nombre.localeCompare(b.nombre, 'es') : nomArea(a).localeCompare(nomArea(b), 'es') || a.nombre.localeCompare(b.nombre, 'es')));
function hojaConteo() {
  const area = val('hcA'), ciega = $('#hcC').checked, L = ordenarProds(PRODS.filter((p) => !p.servicio && (!area || nomArea(p) === area)), val('hcO'));
  if (!L.length) return toast('No hay productos para contar', true);
  let ult = '';
  imprimirDoc(`<div class="rep"><div class="rep-enc"><b>${esc(CFG.hotel_nombre)}</b><span>HOJA DE CONTEO DE INVENTARIO</span><span>${esc(area || 'Todos los departamentos')} · ${L.length} productos · ${new Date().toLocaleString('es-MX')}</span></div>
    <table class="conteo"><thead><tr><th>#</th><th>Código</th><th>Producto</th>${ciega ? '' : '<th class="n">Sistema</th>'}<th class="n" style="width:90px">Anaquel</th><th class="n" style="width:90px">Bodega</th><th class="n" style="width:90px">Total contado</th>${ciega ? '' : '<th class="n" style="width:80px">Diferencia</th>'}</tr></thead><tbody>
    ${L.map((p, i) => { const sep = val('hcO') === 'area' && nomArea(p) !== ult ? `<tr class="t"><td colspan="${ciega ? 6 : 8}">${esc(ult = nomArea(p))}</td></tr>` : ''; return sep + `<tr><td>${i + 1}</td><td class="mono">${esc(p.codigo || '')}</td><td>${esc(p.nombre)}</td>${ciega ? '' : `<td class="n">${p.existencia}</td>`}<td class="caja"></td><td class="caja"></td><td class="caja"></td>${ciega ? '' : '<td class="caja"></td>'}</tr>`; }).join('')}</tbody></table>
    <div class="rep-firmas"><div><span></span>Contó (nombre y firma)</div><div><span></span>Revisó / Autorizó</div></div>
    <div class="rep-pie">Después capture lo contado en Inventario → Conteo físico → Capturar el conteo.</div></div>`, 'carta', 'Hoja de conteo de inventario');
}
function capturaConteo(area) {
  const L = ordenarProds(PRODS.filter((p) => !p.servicio && (!area || nomArea(p) === area)), 'area');
  if (!L.length) return toast('No hay productos para contar', true);
  CONTEO = { area, L, c: {} };
  modal(`Capturar conteo · ${esc(area || 'Todos los departamentos')}`, `<div class="scan">${ico('scan')}<input id="cnS" placeholder="Escanee una pieza para sumarla al conteo (o escriba en la tabla)" autocomplete="off"><span class="sub" id="cnSt"></span></div>
    <div class="tw" style="max-height:52vh;margin-top:10px"><table><thead><tr><th>Código</th><th>Producto</th><th>Depto.</th><th class="n">Sistema</th><th class="n">Contado</th><th class="n">Diferencia</th><th class="n">Valor</th></tr></thead><tbody>
    ${L.map((p) => `<tr id="cnr${p.id}"><td class="mono">${esc(p.codigo || '')}</td><td><b>${esc(p.nombre)}</b></td><td class="sub">${esc(p.area || '')}</td><td class="n">${p.existencia}</td>
      <td class="n"><input type="number" min="0" step="any" id="cn${p.id}" style="width:90px;text-align:right" oninput="cnCalc()" placeholder="—"></td><td class="n" id="cnd${p.id}"></td><td class="n" id="cnv${p.id}"></td></tr>`).join('')}</tbody></table></div>
    <div class="calc" id="cnR"></div><label class="l">Notas<input id="cnN" placeholder="Ej. conteo de fin de mes, contó Juan"></label>
    ${puede('productos') ? '<label class="row" style="font-weight:600"><input type="checkbox" id="cnAp" checked> Ajustar las existencias del sistema a lo contado</label>' : '<div class="aviso">El conteo se guarda y el gerente o administrador lo revisa. Las existencias no se cambian.</div>'}
    <div class="sub">Los productos que deje en blanco no se cuentan ni se ajustan.</div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn" onclick="cnLlenar()">Poner lo del sistema en los vacíos</button><button class="btn pri" onclick="cnGuardar()">Guardar conteo</button>`, true);
  $('#modal .mbox').classList.add('extra');
  const s = $('#cnS'); s.focus();
  s.onkeydown = (e) => {
    if (e.key !== 'Enter') return; e.preventDefault();
    const c = s.value.trim(); s.value = ''; const p = CONTEO.L.find((x) => x.codigo && x.codigo === c);
    if (!p) { $('#cnSt').textContent = 'No está en la lista: ' + c; return; }
    const i = $('#cn' + p.id); i.value = (parseFloat(i.value) || 0) + 1; cnCalc(); $('#cnr' + p.id).scrollIntoView({ block: 'center' }); $('#cnSt').textContent = `${p.nombre}: ${i.value}`;
  };
  cnCalc();
}
function cnCalc() {
  let n = 0, F = 0, S = 0, VF = 0, VS = 0;
  for (const p of CONTEO.L) {
    const v = $('#cn' + p.id).value, d = v === '' ? null : (parseFloat(v) || 0) - p.existencia;
    $('#cnd' + p.id).innerHTML = d === null ? '' : `<b style="color:${d < 0 ? 'var(--ocup)' : d > 0 ? 'var(--libre)' : 'inherit'}">${d > 0 ? '+' : ''}${+d.toFixed(3)}</b>`;
    $('#cnv' + p.id).textContent = d ? mDif(d * p.costo) : '';
    $('#cnr' + p.id).classList.toggle('falta', d !== null && d < 0);
    if (d !== null) { n++; if (d < 0) { F -= d; VF -= d * p.costo; } else if (d > 0) { S += d; VS += d * p.costo; } }
  }
  CONTEO.res = { n, F, S, VF, VS };
  $('#cnR').innerHTML = `<span>Contados</span><b>${n} de ${CONTEO.L.length}</b><span>Faltan</span><b style="color:var(--ocup)">${+F.toFixed(3)} pzas · ${money(VF)}</b><span>Sobran</span><b style="color:var(--libre)">${+S.toFixed(3)} pzas · ${money(VS)}</b>`;
}
function cnLlenar() { for (const p of CONTEO.L) { const i = $('#cn' + p.id); if (i.value === '') i.value = p.existencia; } cnCalc(); }
async function cnGuardar() {
  const lineas = CONTEO.L.map((p) => ({ producto_id: p.id, contado: $('#cn' + p.id).value })).filter((l) => l.contado !== '');
  if (!lineas.length) return toast('Capture al menos un producto', true);
  const r = await hacer(() => POST('/api/inventarios', { area: CONTEO.area, notas: val('cnN'), aplicar: !!$('#cnAp')?.checked, lineas }), 'Conteo guardado');
  cerrar(); iTab = 'conteo'; await vInv(); verConteo(r.id);
}
async function verConteo(id) {
  const c = await GET('/api/inventarios/' + id), fal = c.lineas.filter((l) => l.diferencia < 0), sob = c.lineas.filter((l) => l.diferencia > 0);
  verConteo.c = c;
  modal(`Conteo ${esc(c.folio)} · ${esc(c.area || 'Todos')}`, `<div class="kpis"><div class="kpi"><span>Productos contados</span><b>${c.productos}</b><div class="sub">${fdt(c.fecha)} · ${esc(c.usuario || '')}</div></div><div class="kpi cx-vencida"><span>Faltante</span><b>${money(c.valor_faltante)}</b><div class="sub">${c.faltantes} pzas en ${fal.length} producto(s)</div></div><div class="kpi"><span>Sobrante</span><b>${money(c.valor_sobrante)}</b><div class="sub">${c.sobrantes} pzas</div></div></div>
    ${c.aplicado ? '<div class="aviso ok">Las existencias se ajustaron a lo contado.</div>' : '<div class="aviso">Solo se registró (no se ajustaron existencias).</div>'}${c.notas ? `<div class="sub">${esc(c.notas)}</div>` : ''}
    <div class="tw" style="max-height:46vh"><table><thead><tr><th>Producto</th><th>Depto.</th><th class="n">Sistema</th><th class="n">Contado</th><th class="n">Diferencia</th><th class="n">Valor a costo</th></tr></thead><tbody>
    ${[...fal, ...sob, ...c.lineas.filter((l) => !l.diferencia)].map((l) => `<tr class="${l.diferencia < 0 ? 'falta' : ''}"><td><b>${esc(l.nombre)}</b> <span class="mono sub">${esc(l.codigo || '')}</span></td><td class="sub">${esc(l.area || '')}</td><td class="n">${l.sistema}</td><td class="n">${l.contado}</td><td class="n"><b style="color:${l.diferencia < 0 ? 'var(--ocup)' : l.diferencia > 0 ? 'var(--libre)' : 'inherit'}">${l.diferencia > 0 ? '+' : ''}${l.diferencia}</b></td><td class="n">${l.diferencia ? mDif(l.diferencia * l.costo) : ''}</td></tr>`).join('')}</tbody></table></div>`,
  `<button class="btn" onclick="cerrar()">Cerrar</button><button class="btn pri" onclick="pdfConteo()">PDF de faltantes</button>`, true);
}
function pdfConteo() {
  const c = verConteo.c, dif = c.lineas.filter((l) => l.diferencia).sort((a, b) => a.diferencia * a.costo - b.diferencia * b.costo);
  imprimirDoc(`<div class="rep"><div class="rep-enc"><b>${esc(CFG.hotel_nombre)}</b><span>RESULTADO DE CONTEO DE INVENTARIO · FOLIO ${esc(c.folio)}</span><span>${esc(c.area || 'Todos los departamentos')} · ${fdt(c.fecha)} · contó ${esc(c.usuario || '')}</span></div>
    <div class="rep-tot"><div><small>Productos contados</small><b>${c.productos}</b></div><div><small>Faltante a costo</small><b>${money(c.valor_faltante)}</b></div><div><small>Sobrante a costo</small><b>${money(c.valor_sobrante)}</b></div><div><small>Diferencia neta</small><b>${mDif(c.valor_sobrante - c.valor_faltante)}</b></div></div>
    <h3>Productos con diferencia</h3><table><thead><tr><th>Producto</th><th>Código</th><th>Depto.</th><th class="n">Sistema</th><th class="n">Contado</th><th class="n">Diferencia</th><th class="n">Costo</th><th class="n">Valor</th></tr></thead><tbody>
    ${dif.map((l) => `<tr><td>${esc(l.nombre)}</td><td>${esc(l.codigo || '')}</td><td>${esc(l.area || '')}</td><td class="n">${l.sistema}</td><td class="n">${l.contado}</td><td class="n">${l.diferencia > 0 ? '+' : ''}${l.diferencia}</td><td class="n">${money(l.costo)}</td><td class="n">${mDif(l.diferencia * l.costo)}</td></tr>`).join('') || '<tr><td colspan="8">Sin diferencias: el inventario cuadra.</td></tr>'}</tbody></table>
    ${c.notas ? `<h3>Notas</h3><p>${esc(c.notas)}</p>` : ''}<div class="rep-firmas"><div><span></span>Contó</div><div><span></span>Revisó / Autorizó</div></div></div>`, 'carta', 'Conteo ' + c.folio);
}
// ---------- Movimientos ----------
async function invMov() {
  const mv = await GET('/api/movimientos');
  $('#invc').innerHTML = `<div class="card"><div class="tw"><table><thead><tr><th>Fecha</th><th>Producto</th><th>Tipo</th><th class="n">Cantidad</th><th>Referencia</th><th>Usuario</th></tr></thead><tbody>
    ${mv.map((m) => `<tr><td>${fdt(m.fecha)}</td><td>${esc(m.producto || '—')}</td><td>${TIPO_MOV[m.tipo] || m.tipo}</td><td class="n" style="color:${m.cantidad < 0 ? 'var(--ocup)' : 'var(--libre)'}">${m.cantidad > 0 ? '+' : ''}${m.cantidad}</td><td>${esc(m.referencia || '')}</td><td>${esc(m.usuario || '')}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">Sin movimientos.</td></tr>'}</tbody></table></div></div>`;
}
