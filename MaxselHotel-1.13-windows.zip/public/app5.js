// Maxsel Hotel 1.4 — Excel, gastos fijos con vencimiento, corte detallado (ratos, noches, días, semanas, meses) y avisos
'use strict';

// ---------- Excel (.xlsx) hecho aquí mismo, sin internet ----------
const XLSX = (() => {
  const T = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; T[n] = c >>> 0; }
  const crc = (u) => { let c = 0xFFFFFFFF; for (let i = 0; i < u.length; i++) c = T[(c ^ u[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  const enc = new TextEncoder();
  function zip(files) {
    const partes = [], central = []; let off = 0;
    for (const f of files) {
      const nom = enc.encode(f.name), d = typeof f.data === 'string' ? enc.encode(f.data) : f.data, c = crc(d);
      const h = new DataView(new ArrayBuffer(30)); h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint32(14, c, true); h.setUint32(18, d.length, true); h.setUint32(22, d.length, true); h.setUint16(26, nom.length, true);
      partes.push(new Uint8Array(h.buffer), nom, d);
      const ce = new DataView(new ArrayBuffer(46)); ce.setUint32(0, 0x02014b50, true); ce.setUint16(4, 20, true); ce.setUint16(6, 20, true); ce.setUint16(8, 0x0800, true); ce.setUint32(16, c, true); ce.setUint32(20, d.length, true); ce.setUint32(24, d.length, true); ce.setUint16(28, nom.length, true); ce.setUint32(42, off, true);
      central.push(new Uint8Array(ce.buffer), nom); off += 30 + nom.length + d.length;
    }
    const tam = central.reduce((s, x) => s + x.length, 0), fin = new DataView(new ArrayBuffer(22));
    fin.setUint32(0, 0x06054b50, true); fin.setUint16(8, files.length, true); fin.setUint16(10, files.length, true); fin.setUint32(12, tam, true); fin.setUint32(16, off, true);
    return new Blob([...partes, ...central, new Uint8Array(fin.buffer)], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  }
  const x = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '');
  const col = (i) => { let s = ''; i++; while (i) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
  // Estilos: 0 normal · 1 encabezado · 2 pesos · 3 negrita · 4 negrita pesos · 5 título · 6 dólares · 7 sección
  const ST = { h: 1, m: 2, b: 3, bm: 4, t: 5, u: 6, s: 7 };
  const estilos = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="2"><numFmt numFmtId="164" formatCode="&quot;$&quot;#,##0.00"/><numFmt numFmtId="165" formatCode="&quot;US$&quot;#,##0.00"/></numFmts>
<fonts count="4"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="15"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FF1E3A8A"/><name val="Calibri"/></font></fonts>
<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE5E7EB"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFDBEAFE"/></patternFill></fill></fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="8"><xf xfId="0" numFmtId="0" fontId="0" fillId="0" borderId="0"/><xf xfId="0" numFmtId="0" fontId="1" fillId="2" borderId="0" applyFont="1" applyFill="1"/><xf xfId="0" numFmtId="164" fontId="0" fillId="0" borderId="0" applyNumberFormat="1"/>
<xf xfId="0" numFmtId="0" fontId="1" fillId="0" borderId="0" applyFont="1"/><xf xfId="0" numFmtId="164" fontId="1" fillId="0" borderId="0" applyFont="1" applyNumberFormat="1"/><xf xfId="0" numFmtId="0" fontId="2" fillId="0" borderId="0" applyFont="1"/>
<xf xfId="0" numFmtId="165" fontId="0" fillId="0" borderId="0" applyNumberFormat="1"/><xf xfId="0" numFmtId="0" fontId="3" fillId="3" borderId="0" applyFont="1" applyFill="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
  function hoja(filas) {
    const anchos = [];
    const rows = filas.map((f, r) => `<row r="${r + 1}">${(f || []).map((c, i) => {
      const o = c !== null && typeof c === 'object' ? c : { v: c }, s = ST[o.s] || 0, ref = col(i) + (r + 1);
      if (o.v === null || o.v === undefined || o.v === '') return s ? `<c r="${ref}" s="${s}"/>` : '';
      anchos[i] = Math.max(anchos[i] || 0, Math.min(60, String(typeof o.v === 'number' ? o.v.toFixed(2) : o.v).length + (s === 2 || s === 4 || s === 6 ? 4 : 0)));
      return typeof o.v === 'number' ? `<c r="${ref}" s="${s}"><v>${o.v}</v></c>` : `<c r="${ref}" s="${s}" t="inlineStr"><is><t xml:space="preserve">${x(o.v)}</t></is></c>`;
    }).join('')}</row>`).join('');
    const cols = anchos.length ? `<cols>${[...anchos].map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${Math.max(9, (w || 8) + 2)}" customWidth="1"/>`).join('')}</cols>` : '';
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">${cols}<sheetData>${rows}</sheetData></worksheet>`;
  }
  function libro(hojas) {
    const nombres = hojas.map((h, i) => (String(h.nombre || 'Hoja' + (i + 1)).replace(/[\[\]:*?/\\]/g, ' ').slice(0, 31)));
    return zip([
      { name: '[Content_Types].xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${hojas.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>` },
      { name: '_rels/.rels', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>` },
      { name: 'xl/workbook.xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${nombres.map((n, i) => `<sheet name="${x(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>` },
      { name: 'xl/_rels/workbook.xml.rels', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${hojas.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${hojas.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>` },
      { name: 'xl/styles.xml', data: estilos },
      ...hojas.map((h, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, data: hoja(h.filas) })),
    ]);
  }
  return { libro };
})();
function descargarArchivo(blob, nombre) {
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = nombre; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  toast('Excel guardado en Descargas: ' + nombre);
}
const H_ = (...t) => t.map((v) => ({ v, s: 'h' })), M_ = (v) => ({ v: Number(v) || 0, s: 'm' }), U_ = (v) => ({ v: Number(v) || 0, s: 'u' }), B_ = (v) => ({ v, s: 'b' }), BM_ = (v) => ({ v: Number(v) || 0, s: 'bm' }), S_ = (v) => ({ v, s: 's' });
const TIPO_REN = { entrada: 'Entrada', extension: 'Extensión', cambio: 'Cambio de renta', automatico: 'Cobro automático (no registró salida)' };
const CONC = { hospedaje: 'Hospedaje', tienda: 'Tienda', visita: 'Visita', multa: 'Multa', mora: 'Interés moratorio', limpieza: 'Cuota de limpieza', mascota: 'Cuota por mascota', otro: 'Otro cargo' };

// Filas de "cuántos de cada cosa" (sirve para el corte y para los reportes)
function filasCuantos(rentas, visitas, extra = []) {
  const f = [[S_('ESTANCIAS CORTAS (ratos, noches y días)'), S_(''), S_(''), S_(''), S_('')], H_('Concepto', 'Cuántos', 'Unidades', 'Importe generado', 'Dinero cobrado')];
  let tc = 0, tm = 0;
  for (const m of CORTAS) { const r = rentas[m]; f.push([MOD[m].replace('Por ', '').replace(/^./, (c) => c.toUpperCase()) + (m === 'rato' ? ` (${horasRato()} h)` : ''), r.n, r.cantidad, M_(r.importe), M_(r.cobrado)]); tc += r.cobrado; }
  f.push(['Visitas', visitas.n, '', '', M_(visitas.total)]); tc += visitas.total;
  f.push([B_('Subtotal'), '', '', '', BM_(tc)], [], [S_('ESTANCIAS LARGAS (semana y mes)'), S_(''), S_(''), S_(''), S_('')], H_('Concepto', 'Cuántos', 'Unidades', 'Importe generado', 'Dinero cobrado'));
  for (const m of LARGAS) { const r = rentas[m]; f.push([MOD[m].replace('Por ', '').replace(/^./, (c) => c.toUpperCase()), r.n, r.cantidad, M_(r.importe), M_(r.cobrado)]); tm += r.cobrado; }
  f.push([B_('Subtotal'), '', '', '', BM_(tm)], ...extra);
  return f;
}

// ---------- Corte de turno: ticket resumido de 80 mm ----------
// Estancias cortas (ratos, noches, días y visitas) · estancias largas (semana y mes) · tienda · depósitos · dinero y caja
function imprimirCorte2(r, titulo) {
  const antes = CFG.ticket_ancho; CFG.ticket_ancho = '80'; // el corte siempre sale en 80 mm
  try {
    const t = r.turno, p = r.pagos, c = r.conceptos, k = r.cuentas, w = W(), us = (x) => 'US$' + Number(x || 0).toFixed(2), raya = '-'.repeat(w), doble = '='.repeat(w);
    const fila = (n, x) => lin(`${n} (${x.n})`, money(x.cobrado ?? x.total ?? x.t ?? 0));
    const L = [...encabezado(), titulo, raya, lin('Turno ' + t.id, t.usuario || YO.nombre), lin('Abrió', fdt(t.apertura)), ...(t.cierre ? [lin('Cerró', fdt(t.cierre))] : []), lin('Dólar', '$' + Number(t.tipo_cambio).toFixed(2))];
    if (k) {
      // Solo totales por grupo (el detalle está en el PDF del administrador y en el Excel)
      const R = k.rentas, cortas = R.rato.cobrado + R.noche.cobrado + R.dia.cobrado + k.visitas.total + (k.hospedaje_sin_tipo || 0), largas = R.semana.cobrado + R.mes.cobrado;
      const nC = R.rato.n + R.noche.n + R.dia.n + k.visitas.n, nL = R.semana.n + R.mes.n, nT = k.tienda.ventas.n;
      L.push(doble, lin(`ESTANCIAS CORTAS (${nC})`, money(cortas)), lin(`ESTANCIAS LARGAS (${nL})`, money(largas)), lin(`VENTA EN TIENDA (${nT})`, money(c.tienda?.total)));
      const ot = ['multa', 'mora', 'limpieza', 'mascota', 'otro'].reduce((t, x) => ({ n: t.n + (c[x]?.n || 0), t: t.t + (c[x]?.total || 0) }), { n: 0, t: 0 });
      if (ot.t) L.push(lin(`MULTAS Y CUOTAS (${ot.n})`, money(ot.t)));
      const D = k.depositos;
      if (D.recibidos.n || D.devueltos.n || D.retenidos.n) {
        L.push(doble, 'DEPÓSITOS', lin(`Recibidos (${D.recibidos.n})`, money(D.recibidos.t)), lin(`Devueltos (${D.devueltos.n})`, money(D.devueltos.t)));
        if (D.retenidos.n) L.push(lin(`Retenidos (${D.retenidos.n})`, money(D.retenidos.t)));
      }
    } else L.push(doble, lin('Hospedaje', money(c.hospedaje?.total)), lin('Tienda', money(c.tienda?.total)), lin('Visitas', money(c.visita?.total)));
    L.push(doble, lin('TOTAL COBRADO', money(r.cobrado)), raya, 'FORMAS DE PAGO', lin('Efectivo', money(p.efectivo)));
    if (k && k.dolares.usd) L.push(lin(`${us(k.dolares.usd)} x $${Number(k.dolares.tc).toFixed(2)}`, money(k.dolares.pesos)), lin('  Cambio dado en pesos', '-' + money(k.dolares.cambio)));
    if (p.tarjeta) L.push(lin('Tarjeta', money(p.tarjeta)));
    if (p.transferencia) L.push(lin('Transferencia', money(p.transferencia)));
    L.push(raya, 'CAJA', lin('Fondo inicial', money(t.fondo_mxn) + (t.fondo_usd ? ' + ' + us(t.fondo_usd) : '')));
    if (r.gastos.efectivo) L.push(lin('Gastos pagados', '-' + money(r.gastos.efectivo)));
    if (r.movimientos.ing_mxn || r.movimientos.ing_usd) L.push(lin('Ingresos a caja', money(r.movimientos.ing_mxn) + (r.movimientos.ing_usd ? ' ' + us(r.movimientos.ing_usd) : '')));
    if (r.movimientos.ret_mxn || r.movimientos.ret_usd) L.push(lin('Egresos de caja', '-' + money(r.movimientos.ret_mxn) + (r.movimientos.ret_usd ? ' ' + us(r.movimientos.ret_usd) : '')));
    if (r.esperado) L.push(lin('DEBE HABER pesos', money(r.esperado.mxn)), lin('DEBE HABER dólares', us(r.esperado.usd)));
    if (t.estado === 'cerrado') {
      L.push(lin('Contado pesos', money(t.decl_mxn)), lin('Contado dólares', us(t.decl_usd)));
      if (r.dif) L.push(lin('DIFERENCIA pesos', money(r.dif.mxn)), lin('DIFERENCIA dólares', us(r.dif.usd)), '(sobra + / falta -)');
      if (t.notas) L.push(...wrapT('Notas: ' + t.notas));
    }
    L.push('', '', '_'.repeat(30), 'Firma cajero', '', '', '_'.repeat(30), 'Firma supervisor', '', 'Impreso ' + new Date().toLocaleString('es-MX'));
    imprimir(L, titulo.toLowerCase().replace(/^\w/, (x) => x.toUpperCase()));
  } finally { CFG.ticket_ancho = antes; }
}

// ---------- Corte detallado en PDF (hoja carta, solo administrador) ----------
async function pdfCorte(id) {
  const r = await hacer(() => GET(`/api/turnos/${id}/completo`)), t = r.turno, k = r.cuentas, p = r.pagos, d = r.detalle, R = k.rentas, us = (x) => 'US$' + Number(x || 0).toFixed(2);
  const cortas = R.rato.cobrado + R.noche.cobrado + R.dia.cobrado + k.visitas.total + (k.hospedaje_sin_tipo || 0), largas = R.semana.cobrado + R.mes.cobrado;
  const fila = (n, x, uni = true) => `<tr><td>${n}</td><td class="n">${x.n}</td><td class="n">${uni ? x.cantidad ?? '' : ''}</td><td class="n">${x.importe !== undefined ? money(x.importe) : ''}</td><td class="n">${money(x.cobrado ?? x.total ?? x.t ?? 0)}</td></tr>`;
  const cab5 = '<tr><th></th><th class="n">Cuántos</th><th class="n">Unidades</th><th class="n">Generado</th><th class="n">Cobrado</th></tr>';
  const tabla = (tit, cols, filas) => filas.length ? `<h3>${tit}</h3><table><thead><tr>${cols.map((c) => `<th${c.startsWith('$') ? ' class="n"' : ''}>${c.replace(/^\$/, '')}</th>`).join('')}</tr></thead><tbody>${filas.join('')}</tbody></table>` : '';
  const html = `<div class="rep">
    <div class="rep-enc"><b>${esc(CFG.hotel_nombre)}</b><span>Corte de turno detallado · Turno ${t.id}</span><span>${esc(t.usuario || '')} · abrió ${fdt(t.apertura)}${t.cierre ? ' · cerró ' + fdt(t.cierre) : ' · ABIERTO'} · dólar $${Number(t.tipo_cambio).toFixed(2)}</span></div>
    <div class="rep-tot"><div><small>Estancias cortas</small><b>${money(cortas)}</b></div><div><small>Estancias largas</small><b>${money(largas)}</b></div><div><small>Venta en tienda</small><b>${money(r.conceptos.tienda?.total)}</b></div><div><small>Total cobrado</small><b>${money(r.cobrado)}</b></div></div>
    <div class="rep-2"><div><h3>Estancias cortas</h3><table><thead>${cab5}</thead><tbody>${fila(`Ratos (${horasRato()} h)`, R.rato)}${fila('Noches', R.noche)}${fila('Días', R.dia)}${fila('Visitas', k.visitas, false)}${k.hospedaje_sin_tipo ? `<tr><td>Otros hospedajes</td><td></td><td></td><td></td><td class="n">${money(k.hospedaje_sin_tipo)}</td></tr>` : ''}<tr class="t"><td>Total</td><td></td><td></td><td></td><td class="n">${money(cortas)}</td></tr></tbody></table></div>
      <div><h3>Estancias largas</h3><table><thead>${cab5}</thead><tbody>${fila('Semanas', R.semana)}${fila('Meses', R.mes)}<tr class="t"><td>Total</td><td></td><td></td><td></td><td class="n">${money(largas)}</td></tr></tbody></table></div></div>
    <div class="rep-2"><div><h3>Venta en tienda</h3><table><thead><tr><th>Producto</th><th class="n">Cantidad</th><th class="n">Importe</th></tr></thead><tbody>${k.tienda.productos.map((x) => `<tr><td>${esc(x.descripcion)}</td><td class="n">${x.cantidad}</td><td class="n">${money(x.importe)}</td></tr>`).join('') || '<tr><td colspan="3">Sin ventas</td></tr>'}
      <tr><td>Ventas cobradas (${k.tienda.ventas.n})</td><td></td><td class="n">${money(k.tienda.ventas.t)}</td></tr><tr><td>Cargado a habitación (${k.tienda.cargadas.n})</td><td></td><td class="n">${money(k.tienda.cargadas.t)}</td></tr></tbody></table></div>
      <div><h3>Depósitos</h3><table><tbody><tr><td>Recibidos (${k.depositos.recibidos.n})</td><td class="n">${money(k.depositos.recibidos.t)}</td></tr><tr><td>Devueltos (${k.depositos.devueltos.n})</td><td class="n">${money(k.depositos.devueltos.t)}</td></tr><tr><td>Retenidos por daños (${k.depositos.retenidos.n})</td><td class="n">${money(k.depositos.retenidos.t)}</td></tr></tbody></table>
      <h3>Formas de pago</h3><table><tbody><tr><td>Efectivo (neto)</td><td class="n">${money(p.efectivo)}</td></tr><tr><td>Dólares ${us(k.dolares.usd)} × $${Number(k.dolares.tc).toFixed(2)}</td><td class="n">${money(k.dolares.pesos)}</td></tr><tr><td>Cambio entregado en pesos</td><td class="n">-${money(k.dolares.cambio)}</td></tr><tr><td>Tarjeta</td><td class="n">${money(p.tarjeta)}</td></tr><tr><td>Transferencia</td><td class="n">${money(p.transferencia)}</td></tr></tbody></table></div></div>
    <h3>Caja</h3><table><thead><tr><th></th><th class="n">Pesos</th><th class="n">Dólares</th></tr></thead><tbody><tr><td>Fondo inicial</td><td class="n">${money(t.fondo_mxn)}</td><td class="n">${us(t.fondo_usd)}</td></tr><tr><td>Gastos pagados de caja</td><td class="n">-${money(r.gastos.efectivo)}</td><td></td></tr>
      <tr><td>Ingresos a caja</td><td class="n">${money(r.movimientos.ing_mxn)}</td><td class="n">${us(r.movimientos.ing_usd)}</td></tr><tr><td>Egresos de caja</td><td class="n">-${money(r.movimientos.ret_mxn)}</td><td class="n">${us(r.movimientos.ret_usd)}</td></tr>
      <tr class="t"><td>Debe haber</td><td class="n">${money(r.esperado.mxn)}</td><td class="n">${us(r.esperado.usd)}</td></tr>${t.estado === 'cerrado' ? `<tr><td>Contado al cerrar</td><td class="n">${money(t.decl_mxn)}</td><td class="n">${us(t.decl_usd)}</td></tr><tr class="t"><td>Diferencia (sobra + / falta −)</td><td class="n">${money(r.dif.mxn)}</td><td class="n">${us(r.dif.usd)}</td></tr>` : ''}</tbody></table>
    ${tabla('Rentas del turno', ['Hora', 'Hab.', 'Huésped', 'Renta', 'Movimiento', '$Cant.', '$Importe'], d.rentas.map((x) => `<tr><td>${fdt(x.fecha)}</td><td>${esc(x.numero)}</td><td>${esc(x.huesped)}</td><td>${MOD[x.modalidad] || ''}</td><td>${TIPO_REN[x.tipo] || ''}</td><td class="n">${x.cantidad}</td><td class="n">${money(x.importe)}</td></tr>`))}
    ${tabla('Cobros', ['Hora', 'Concepto', 'Hab.', 'Método', '$Monto'], d.pagos.map((x) => `<tr><td>${fdt(x.fecha)}</td><td>${CONC[x.concepto] || ''}${x.modalidad ? ' · ' + MOD[x.modalidad].replace('Por ', '') : ''}</td><td>${esc(x.numero || '')}</td><td>${MET[x.metodo] || ''}${x.usd ? ' ' + us(x.usd) : ''}</td><td class="n">${money(x.monto)}</td></tr>`))}
    ${tabla('Gastos pagados', ['Folio', 'Concepto', 'Clasificación', 'Método', '$Monto'], d.gastos.map((x) => `<tr><td>${esc(x.folio)}</td><td>${esc(x.concepto)}</td><td>${esc(x.grupo || 'Otros')} · ${esc(x.categoria || '')}</td><td>${MET[x.metodo] || ''}</td><td class="n">${money(x.monto)}</td></tr>`))}
    ${tabla('Ingresos y egresos de caja', ['Hora', 'Tipo', 'Motivo', '$Monto'], r.movimientos_caja.map((m) => `<tr><td>${fdt(m.fecha)}</td><td>${m.tipo === 'ingreso' ? 'Ingreso' : 'Egreso'}</td><td>${esc(m.motivo || '')}</td><td class="n">${m.moneda === 'USD' ? us(m.monto) : money(m.monto)}</td></tr>`))}
    <div class="rep-firmas"><div><span></span>Firma cajero</div><div><span></span>Firma administrador</div></div>
    <div class="rep-pie">Impreso ${new Date().toLocaleString('es-MX')} · Documento para uso del administrador</div></div>`;
  imprimirDoc(html, 'carta', 'Corte detallado · turno ' + t.id);
}

// ---------- Corte de turno en Excel ----------
async function excelCorte(id) {
  const r = await hacer(() => GET(`/api/turnos/${id}/detalle`)), t = r.turno, k = r.cuentas, p = r.pagos, d = r.detalle;
  const extra = [[], [S_('VENTA EN TIENDA'), S_(''), S_(''), S_(''), S_('')], H_('Concepto', 'Cuántos', '', '', 'Importe'), ['Ventas cobradas', k.tienda.ventas.n, '', '', M_(k.tienda.ventas.t)], ['Cargado a habitaciones', k.tienda.cargadas.n, '', '', M_(k.tienda.cargadas.t)],
    [], [S_('DEPÓSITOS'), S_(''), S_(''), S_(''), S_('')], H_('Concepto', 'Cuántos', '', '', 'Importe'), ['Depósitos recibidos', k.depositos.recibidos.n, '', '', M_(k.depositos.recibidos.t)], ['Depósitos devueltos', k.depositos.devueltos.n, '', '', M_(k.depositos.devueltos.t)], ['Retenidos por daños', k.depositos.retenidos.n, '', '', M_(k.depositos.retenidos.t)],
    [], [S_('DINERO DEL TURNO'), S_(''), S_(''), S_(''), S_('')], H_('Concepto', '', '', '', 'Importe'), ['Efectivo (neto)', '', '', '', M_(p.efectivo)], ['Dólares (neto, en pesos)', '', '', '', M_(p.dolares)], ['Tarjeta', '', '', '', M_(p.tarjeta)], ['Transferencia', '', '', '', M_(p.transferencia)], [B_('Total cobrado'), '', '', '', BM_(r.cobrado)],
    [], [S_('DÓLARES'), S_(''), S_(''), S_(''), S_('')], H_('Dólares recibidos', 'Tipo de cambio', '', '', 'En pesos'), [U_(k.dolares.usd), M_(k.dolares.tc), '', '', M_(k.dolares.pesos)], ['Cambio entregado en pesos', '', '', '', M_(k.dolares.cambio)],
    [], [S_('CAJA'), S_(''), S_(''), S_(''), S_('')], H_('Concepto', '', '', 'Pesos', 'Dólares'), ['Fondo inicial', '', '', M_(t.fondo_mxn), U_(t.fondo_usd)], ['Gastos pagados de caja', '', '', M_(r.gastos.efectivo), ''],
    ['Ingresos a caja', '', '', M_(r.movimientos.ing_mxn), U_(r.movimientos.ing_usd)], ['Egresos de caja', '', '', M_(r.movimientos.ret_mxn), U_(r.movimientos.ret_usd)],
    ...(r.esperado ? [['Debe haber', '', '', BM_(r.esperado.mxn), U_(r.esperado.usd)]] : []), ...(t.estado === 'cerrado' ? [['Contado al cerrar', '', '', M_(t.decl_mxn), U_(t.decl_usd)]] : []), ...(r.dif ? [['Diferencia (sobra + / falta -)', '', '', BM_(r.dif.mxn), U_(r.dif.usd)]] : [])];
  const resumen = [[{ v: `${CFG.hotel_nombre} · Corte de turno ${t.id}`, s: 't' }], ['Usuario', t.usuario || ''], ['Abrió', fdt(t.apertura)], ['Cerró', t.cierre ? fdt(t.cierre) : 'Abierto'], ['Tipo de cambio', M_(t.tipo_cambio)], [],
    ...filasCuantos(k.rentas, k.visitas, extra)];
  descargarArchivo(XLSX.libro([{ nombre: 'Resumen', filas: resumen }, ...hojasDetalle(d, r.visitantes), { nombre: 'Ingresos y egresos', filas: [H_('Fecha', 'Tipo', 'Moneda', 'Monto', 'Motivo'), ...r.movimientos_caja.map((m) => [fdt(m.fecha), m.tipo === 'ingreso' ? 'Ingreso' : 'Egreso', m.moneda, m.moneda === 'USD' ? U_(m.monto) : M_(m.monto), m.motivo || ''])] }]),
    `Corte turno ${t.id} - ${String(t.apertura).slice(0, 10)}.xlsx`);
}
function hojasDetalle(d, visitantes) {
  const prod = {}; for (const v of d.ventas) { const q = prod[v.descripcion] || (prod[v.descripcion] = { n: 0, t: 0 }); q.n += v.cantidad; q.t += v.importe; }
  return [
    { nombre: 'Rentas', filas: [H_('Fecha', 'Habitación', 'Huésped', 'Folio', 'Tipo de renta', 'Movimiento', 'Cantidad', 'Precio', 'Importe', 'Usuario'), ...d.rentas.map((x) => [fdt(x.fecha), x.numero, x.huesped, x.folio, MOD[x.modalidad] || x.modalidad, TIPO_REN[x.tipo] || x.tipo || '', x.cantidad, M_(x.precio), M_(x.importe), x.usuario || ''])] },
    { nombre: 'Cobros', filas: [H_('Fecha', 'Concepto', 'Tipo de renta', 'Habitación', 'Huésped', 'Método', 'Monto (pesos)', 'Dólares', 'Tipo de cambio', 'Cambio entregado', 'Nota', 'Usuario'),
      ...d.pagos.map((x) => [fdt(x.fecha), CONC[x.concepto] || x.concepto, x.modalidad ? MOD[x.modalidad] : '', x.numero || '', x.huesped || '', MET[x.metodo] || x.metodo, M_(x.monto), x.usd ? U_(x.usd) : '', x.usd ? M_(x.tc) : '', x.cambio ? M_(x.cambio) : '', x.nota || '', x.usuario || ''])] },
    { nombre: 'Tienda', filas: [H_('Folio', 'Fecha', 'Producto', 'Cantidad', 'Precio', 'Importe', 'Pago', 'Habitación'), ...d.ventas.map((x) => [x.folio, fdt(x.fecha), x.descripcion, x.cantidad, M_(x.precio), M_(x.importe), MET[x.metodo] || x.metodo, x.numero || '']),
      [], H_('Producto', 'Cantidad vendida', '', '', '', 'Importe'), ...Object.entries(prod).sort((a, b) => b[1].t - a[1].t).map(([n, q]) => [n, q.n, '', '', '', M_(q.t)])] },
    { nombre: 'Visitas', filas: [H_('Fecha', 'Visitante', 'Habitación', 'Cobro'), ...(visitantes || []).map((v) => [fdt(v.entrada), v.nombre, v.numero || '', M_(v.cobro)])] },
    { nombre: 'Depósitos', filas: [H_('Fecha', 'Folio', 'Tipo', 'Habitación', 'Huésped', 'Método', 'Monto', 'Dólares', 'Motivo'), ...d.depositos.map((x) => [fdt(x.fecha), x.folio || '', { recibido: 'Recibido', devuelto: 'Devuelto', retenido: 'Retenido' }[x.tipo], x.numero, x.huesped, MET[x.metodo] || x.metodo || '', M_(x.monto), x.usd ? U_(x.usd) : '', x.motivo || ''])] },
    { nombre: 'Gastos', filas: [H_('Folio', 'Fecha', 'Concepto', 'Clasificación', 'Tipo de gasto', 'Empleado', 'Proveedor', 'Factura / folio', 'Periodo', 'Método', 'Monto', 'Recibió'), ...d.gastos.map((x) => [x.folio, fdt(x.fecha), x.concepto, x.grupo || 'Otros', x.categoria || '', x.empleado || '', x.proveedor || '', x.factura || '', x.periodo || '', MET[x.metodo] || x.metodo, M_(x.monto), x.recibe || ''])] },
  ];
}

// ---------- Reportes del periodo en Excel ----------
async function excelReporte() {
  const [d, det] = await hacer(() => Promise.all([GET(`/api/reporte?desde=${rDesde}&hasta=${rHasta}`), GET(`/api/reporte/detalle?desde=${rDesde}&hasta=${rHasta}`)]));
  const usd = det.pagos.reduce((s, x) => s + (x.usd || 0), 0) + det.depositos.filter((x) => x.tipo === 'recibido').reduce((s, x) => s + (x.usd || 0), 0);
  const usdPesos = det.pagos.reduce((s, x) => s + (x.usd || 0) * (x.tc || 0), 0) + det.depositos.filter((x) => x.tipo === 'recibido').reduce((s, x) => s + (x.usd || 0) * (x.tc || 0), 0);
  const nDep = (t) => new Set(det.depositos.filter((x) => x.tipo === t).map((x) => x.folio || x.fecha)).size;
  const extra = [[], [S_('VENTA EN TIENDA'), S_(''), S_(''), S_(''), S_('')], H_('Concepto', 'Cuántos', '', '', 'Importe'), ['Ventas de tienda', d.ventasTienda.n, '', '', M_(d.ventasTienda.t)], ['Cargado a habitaciones', '', '', '', M_(d.cargosHabitacion)],
    [], [S_('DEPÓSITOS'), S_(''), S_(''), S_(''), S_('')], H_('Concepto', 'Cuántos', '', '', 'Importe'), ['Depósitos recibidos', nDep('recibido'), '', '', M_(d.depositos.recibidos)], ['Depósitos devueltos', nDep('devuelto'), '', '', M_(d.depositos.devueltos)], ['Retenidos por daños', nDep('retenido'), '', '', M_(d.depositos.retenidos)],
    [], [S_('DINERO'), S_(''), S_(''), S_(''), S_('')], H_('Concepto', '', '', '', 'Importe'), ...Object.entries(d.cobrado.porMetodo).map(([k, v]) => [MET[k], '', '', '', M_(v)]), [B_('Total cobrado'), '', '', '', BM_(d.cobrado.total)], ['Gastos', '', '', '', M_(d.gastos.total)],
    [], [S_('DÓLARES'), S_(''), S_(''), S_(''), S_('')], H_('Dólares recibidos', 'Tipo de cambio promedio', '', '', 'En pesos'), [U_(usd), M_(usd ? usdPesos / usd : 0), '', '', M_(usdPesos)], ['Cambio entregado en pesos', '', '', '', M_(d.cobrado.cambio + d.depositos.cambio)]];
  const resumen = [[{ v: `${CFG.hotel_nombre} · Reporte del ${fd(rDesde)} al ${fd(rHasta)}`, s: 't' }], ['Entradas de huéspedes', d.entradas], ['Salidas', d.salidas], ['Visitantes registrados', d.visitantes], [],
    ...filasCuantos(d.rentas, d.visitasCobradas, extra)];
  const cortes = [H_('Turno', 'Usuario', 'Abrió', 'Cerró', 'Ratos', 'Noches', 'Días', 'Visitas', 'Semanas', 'Meses', 'Total cobrado', 'Dólares', 'Dif. pesos', 'Dif. dólares'),
    ...det.turnos.map((x) => [x.turno.id, x.turno.usuario || '', fdt(x.turno.apertura), x.turno.cierre ? fdt(x.turno.cierre) : 'Abierto', x.cuentas.rentas.rato.n, x.cuentas.rentas.noche.n, x.cuentas.rentas.dia.n, x.cuentas.visitas.n, x.cuentas.rentas.semana.n, x.cuentas.rentas.mes.n,
      M_(x.cobrado), U_(x.cuentas.dolares.usd), x.dif ? M_(x.dif.mxn) : '', x.dif ? U_(x.dif.usd) : ''])];
  const gcl = [[{ v: 'Gastos por clasificación', s: 't' }], H_('Clasificación', 'Tipo de gasto', 'Cuántos', 'Importe')];
  for (const [k, x] of Object.entries(d.gastos.porGrupo || {}).sort((a, b) => b[1].total - a[1].total)) {
    gcl.push([B_(k), '', x.n, BM_(x.total)]);
    for (const [c, v] of Object.entries(x.conceptos).sort((a, b) => b[1] - a[1])) gcl.push(['', c, '', M_(v)]);
  }
  gcl.push([], [B_('TOTAL DE GASTOS'), '', d.gastos.n, BM_(d.gastos.total)]);
  const pEmp = [[{ v: 'Pagos por empleado', s: 't' }], H_('Empleado', 'Pagos', 'Total'), ...(d.gastos.porEmpleado || []).map((x) => [x.nombre, x.n, M_(x.t)])];
  const pProv = [[{ v: 'Pagos por proveedor', s: 't' }], H_('Proveedor', 'Pagos', 'Total'), ...(d.gastos.porProveedor || []).map((x) => [x.nombre, x.n, M_(x.t)])];
  descargarArchivo(XLSX.libro([{ nombre: 'Resumen', filas: resumen }, { nombre: 'Gastos por clasificación', filas: gcl }, { nombre: 'Por empleado', filas: pEmp }, { nombre: 'Por proveedor', filas: pProv }, { nombre: 'Cortes de turno', filas: cortes }, ...hojasDetalle(det, det.visitantes.filter((v) => v.cobro > 0)), ...(typeof hojasExtras === 'function' ? hojasExtras(await GET(`/api/reporte/extra?desde=${rDesde}&hasta=${rHasta}`)) : [])]), `Reporte hotel ${rDesde} al ${rHasta}.xlsx`);
}

// ---------- Caja: tabla de "cuántos" y botones de Excel ----------
function tablaCuantos(k) {
  const f = (n, x, uni) => `<tr><td>${n}</td><td class="n">${x.n}</td><td class="n">${uni ?? x.cantidad ?? ''}</td><td class="n">${money(x.cobrado ?? x.total ?? x.t)}</td></tr>`;
  return `<div class="cols"><div class="card"><h2>Estancias cortas</h2><div class="tw"><table><thead><tr><th></th><th class="n">Cuántos</th><th class="n">Unidades</th><th class="n">Cobrado</th></tr></thead><tbody>
      ${f(`Ratos (${horasRato()} h)`, k.rentas.rato)}${f('Noches', k.rentas.noche)}${f('Días', k.rentas.dia)}${f('Visitas', k.visitas, '')}${k.hospedaje_sin_tipo ? `<tr><td>Hospedaje (otros)</td><td></td><td></td><td class="n">${money(k.hospedaje_sin_tipo)}</td></tr>` : ''}</tbody></table></div></div>
    <div class="card"><h2>Estancias largas</h2><div class="tw"><table><thead><tr><th></th><th class="n">Cuántos</th><th class="n">Unidades</th><th class="n">Cobrado</th></tr></thead><tbody>${f('Semanas', k.rentas.semana)}${f('Meses', k.rentas.mes)}</tbody></table></div>
      <h2 style="margin-top:14px">Tienda</h2><div class="kv"><span>Ventas cobradas (${k.tienda.ventas.n})</span><b>${money(k.tienda.ventas.t)}</b><span>Cargado a habitación (${k.tienda.cargadas.n})</span><b>${money(k.tienda.cargadas.t)}</b></div></div>
    <div class="card"><h2>Depósitos y dólares</h2><div class="kv"><span>Recibidos (${k.depositos.recibidos.n})</span><b>${money(k.depositos.recibidos.t)}</b><span>Devueltos (${k.depositos.devueltos.n})</span><b>${money(k.depositos.devueltos.t)}</b><span>Retenidos (${k.depositos.retenidos.n})</span><b>${money(k.depositos.retenidos.t)}</b>
      <span>Dólares recibidos</span><b>US$${k.dolares.usd.toFixed(2)} × $${Number(k.dolares.tc).toFixed(2)} = ${money(k.dolares.pesos)}</b><span>Cambio entregado en pesos</span><b>${money(k.dolares.cambio)}</b></div></div></div>`;
}
{
  const _vCaja = vCaja;
  vCaja = async function () {
    await _vCaja();
    if (TURNO?.turno && TURNO.cuentas) {
      const b = [...document.querySelectorAll('#main button')].find((x) => x.textContent.includes('Imprimir corte parcial'));
      b?.insertAdjacentHTML('afterend', `<button class="btn" onclick="excelCorte(${TURNO.turno.id})">Corte en Excel</button>${YO.rol === 'admin' ? `<button class="btn" onclick="pdfCorte(${TURNO.turno.id})">Corte detallado (PDF)</button>` : ''}`);
      $('#main .cols')?.insertAdjacentHTML('beforebegin', tablaCuantos(TURNO.cuentas));
    }
    document.querySelectorAll('#main button[onclick^="reimprimirCorte("]').forEach((x) => { const id = x.getAttribute('onclick').match(/\d+/)[0]; x.insertAdjacentHTML('afterend', ` <button class="btn sm" onclick="excelCorte(${id})">Excel</button>${YO.rol === 'admin' ? ` <button class="btn sm" onclick="pdfCorte(${id})">PDF</button>` : ''}`); });
  };
}
// ---------- Reportes: cuántos de cada renta y botón de Excel ----------
{
  const _vRep = vRep;
  vRep = async function () {
    await _vRep();
    const d = vRep.d; if (!d || !d.rentas) return;
    $('#main .top .row')?.insertAdjacentHTML('beforeend', '<button class="btn pri" onclick="excelReporte()">Exportar a Excel</button>');
    const f = (n, x) => `<tr><td>${n}</td><td class="n">${x.n}</td><td class="n">${x.cantidad ?? ''}</td><td class="n">${money(x.importe ?? 0)}</td><td class="n">${money(x.cobrado ?? x.total)}</td></tr>`;
    $('#main .kpis')?.insertAdjacentHTML('afterend', `<div class="card" style="margin-bottom:16px"><h2>Rentas del periodo</h2><div class="tw"><table><thead><tr><th></th><th class="n">Cuántos</th><th class="n">Unidades</th><th class="n">Generado</th><th class="n">Cobrado</th></tr></thead><tbody>
      ${f(`Ratos (${horasRato()} h)`, d.rentas.rato)}${f('Noches', d.rentas.noche)}${f('Días', d.rentas.dia)}<tr><td>Visitas cobradas</td><td class="n">${d.visitasCobradas.n}</td><td></td><td></td><td class="n">${money(d.visitasCobradas.total)}</td></tr>
      <tr><td colspan="5" class="lbl" style="padding-top:10px">Larga estancia</td></tr>${f('Semanas', d.rentas.semana)}${f('Meses', d.rentas.mes)}</tbody></table></div></div>`);
  };
}

// ---------- Gastos fijos ----------
const PERIODO_TXT = { semanal: 'Cada semana', quincenal: 'Cada quincena', mensual: 'Cada mes', bimestral: 'Cada 2 meses', trimestral: 'Cada 3 meses', semestral: 'Cada 6 meses', anual: 'Cada año', unico: 'Una sola vez' };
const EST_FIJO = { vencido: ['Vencido', 'p-bad'], por_vencer: ['Por vencer', 'p-warn'], al_corriente: ['Al corriente', 'p-ok'], sin_fecha: ['Sin fecha', ''] };
const SUGERIDOS = ['Luz (CFE)', 'Agua', 'Gas', 'Internet', 'Cable / TV', 'Teléfono', 'Renta del local', 'Servicio de lavandería', 'Publicidad (marketing)', 'Redes sociales / anuncios', 'Recolección de basura', 'Predial', 'Sueldos', 'Seguro', 'Licencia de funcionamiento'];
let FIJOS = [];
const diasTxt = (g) => (g.dias === null ? '' : g.dias < 0 ? `venció hace ${-g.dias} día${g.dias === -1 ? '' : 's'}` : g.dias === 0 ? 'vence HOY' : g.dias === 1 ? 'vence mañana' : `vence en ${g.dias} días`);
function tarjetasFijos() {
  return `<div class="card" style="margin-bottom:16px"><div class="row" style="justify-content:space-between;margin-bottom:10px;flex-wrap:wrap"><h2 style="margin:0">Gastos fijos · luz, agua, internet…</h2><button class="btn pri" onclick="fijoModal()">Agregar gasto fijo</button></div>
    ${FIJOS.length ? `<div class="fijos">${FIJOS.map((g) => `<div class="fijo f-${g.estado}"><div class="row" style="justify-content:space-between;align-items:flex-start"><div><b>${esc(g.nombre)}</b>${g.proveedor ? `<div class="sub">${esc(g.proveedor)}</div>` : ''}</div><span class="pill ${EST_FIJO[g.estado]?.[1] || ''}">${EST_FIJO[g.estado]?.[0] || ''}</span></div>
      <div class="big">${g.monto ? money(g.monto) : '—'}</div><div class="${g.estado === 'vencido' ? 'malo' : g.estado === 'por_vencer' ? 'pronto' : 'sub'}">${fd(g.vence)} · ${diasTxt(g)}</div>
      <div class="sub">${PERIODO_TXT[g.periodo] || ''}${g.contrato ? ' · Contrato ' + esc(g.contrato) : ''}${g.domiciliado ? ' · Domiciliado' : ''}</div>
      <div class="row" style="margin-top:8px;gap:6px;flex-wrap:wrap"><button class="btn sm pri" onclick="fijoPagar(${g.id})">Pagar</button><button class="btn sm" onclick="fijoHist(${g.id})">Historial</button><button class="btn sm" onclick="fijoModal(${g.id})">Editar</button></div></div>`).join('')}</div>`
    : '<div class="empty">Agregue la luz, el agua, internet, renta… El sistema le avisa con color cuando estén por vencer o vencidos.</div>'}</div>`;
}
{
  const _vGastos = vGastos;
  vGastos = async function () {
    await _vGastos();
    if (!puede('gastos')) return;
    try { FIJOS = await GET('/api/gastos-fijos'); } catch { FIJOS = []; }
    // 1.6: los gastos fijos tienen su propia sección (app6); si no existe, se muestran arriba
    if (typeof gTab === 'undefined') $('#main .top')?.insertAdjacentHTML('afterend', tarjetasFijos());
  };
}
function fijoModal(id) {
  const g = id ? FIJOS.find((x) => x.id === id) : { nombre: '', categoria: 'Luz', proveedor: '', contrato: '', referencia: '', monto: '', periodo: 'mensual', vence: hoyISO(), dias_aviso: 5, domiciliado: 0, notas: '' };
  modal(id ? 'Editar gasto fijo' : 'Nuevo gasto fijo', `
    <div class="f"><label class="l">¿Qué es?<input id="fN" list="fSug" value="${esc(g.nombre)}" placeholder="Luz, Agua, Internet…"><datalist id="fSug">${SUGERIDOS.map((x) => `<option value="${esc(x)}">`).join('')}</datalist></label>
      <label class="l">Compañía / a quién se paga<input id="fPr" value="${esc(g.proveedor || '')}" placeholder="CFE, CESPT, Telmex…"></label>
      <label class="l">Número de contrato / servicio<input id="fCo" value="${esc(g.contrato || '')}" placeholder="Viene en el recibo"></label>
      <label class="l">Referencia de pago (opcional)<input id="fRe" value="${esc(g.referencia || '')}" placeholder="Para pagar en banco o tienda"></label>
      <label class="l">Monto aproximado<input id="fMo" type="number" min="0" step="0.01" value="${g.monto || ''}"></label>
      <label class="l">Clasificación del gasto${selCategoria('fCa', g.categoria)}</label>
      <label class="l">Se paga<select id="fPe">${Object.entries(PERIODO_TXT).map(([k, n]) => `<option value="${k}" ${k === g.periodo ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <label class="l">Próximo vencimiento<input id="fVe" type="date" value="${esc(g.vence || hoyISO())}"></label>
      <label class="l">Avisar días antes<input id="fAv" type="number" min="0" max="60" value="${g.dias_aviso ?? 5}"></label></div>
    <label class="row" style="font-weight:600"><input type="checkbox" id="fDo" ${g.domiciliado ? 'checked' : ''}> Está domiciliado (se cobra solo a la tarjeta o cuenta)</label>
    <label class="l">Notas<input id="fNo" value="${esc(g.notas || '')}" placeholder="Ej. se paga en OXXO, a nombre de…"></label>`,
  `${id ? `<button class="btn bad" onclick="confirmar(this,()=>fijoBorrar(${id}))">Quitar</button>` : ''}<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="fijoOk(${id || 0})">Guardar</button>`);
}
async function fijoOk(id) {
  const b = { nombre: val('fN'), proveedor: val('fPr'), contrato: val('fCo'), referencia: val('fRe'), monto: val('fMo'), categoria: val('fCa'), periodo: val('fPe'), vence: val('fVe'), dias_aviso: val('fAv'), domiciliado: $('#fDo').checked, notas: val('fNo') };
  await hacer(() => (id ? PUT('/api/gastos-fijos/' + id, b) : POST('/api/gastos-fijos', b)), 'Gasto fijo guardado'); cerrar(); avisosGastos(); vGastos();
}
async function fijoBorrar(id) { await hacer(() => DEL('/api/gastos-fijos/' + id), 'Gasto fijo quitado'); cerrar(); avisosGastos(); vGastos(); }
function fijoPagar(id) {
  const g = FIJOS.find((x) => x.id === id), mesTxt = new Date(aF(g.vence)).toLocaleDateString('es-MX', { month: 'long', year: 'numeric' });
  modal(`Pagar · ${esc(g.nombre)}`, `<div class="kv"><span>Vence</span><b>${fd(g.vence)} (${diasTxt(g)})</b>${g.contrato ? `<span>Contrato</span><b>${esc(g.contrato)}</b>` : ''}${g.referencia ? `<span>Referencia</span><b>${esc(g.referencia)}</b>` : ''}${g.promedio ? `<span>Promedio últimos pagos</span><b>${money(g.promedio)}</b>` : ''}</div>
    <div class="f"><label class="l">Monto pagado<input id="pMo" type="number" min="0" step="0.01" value="${g.monto || ''}" oninput="fijoAlto(${g.promedio || 0})"></label><label class="l">Periodo<input id="pPe" value="${esc(mesTxt)}"></label>
      <label class="l">Método de pago${selPago('pMe', null, 'sindolar')}</label></div><div id="pAl"></div>
    <label class="row" style="font-weight:600"><input type="checkbox" id="pFu" ${g.domiciliado ? 'checked' : ''}> Se pagó por fuera (no sale del dinero de la caja del turno)</label>
    <label class="l">Nota<input id="pNo" placeholder="Folio del recibo, quién pagó…"></label>
    <div class="sub">Al guardar se registra en Gastos y el vencimiento pasa al siguiente periodo${g.periodo === 'unico' ? ' (es de una sola vez: se quita de la lista)' : ''}.</div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="fijoPagarOk(${id})">Registrar pago</button>`);
  fijoAlto(g.promedio || 0);
}
function fijoAlto(prom) { const m = num('pMo'), el = $('#pAl'); el.innerHTML = prom && m > prom * 1.2 ? `<div class="aviso bad">Ojo: este pago es ${Math.round((m / prom - 1) * 100)}% más alto que el promedio (${money(prom)}). Revise si hay alguna fuga o consumo raro.</div>` : ''; }
async function fijoPagarOk(id) {
  const r = await hacer(() => POST(`/api/gastos-fijos/${id}/pagar`, { monto: val('pMo'), metodo: val('pMe'), periodo_txt: val('pPe'), nota: val('pNo'), fuera_de_caja: $('#pFu').checked }), 'Pago registrado');
  cerrar(); toast(r.siguiente ? 'Pago registrado. Próximo vencimiento: ' + fd(r.siguiente) : 'Pago registrado'); avisosGastos(); vGastos(); pintarTurno();
}
function fijoHist(id) {
  const g = FIJOS.find((x) => x.id === id);
  modal(`Historial · ${esc(g.nombre)}`, `${g.promedio ? `<div class="aviso">Promedio de los últimos pagos: <b>${money(g.promedio)}</b></div>` : ''}<div class="tw"><table><thead><tr><th>Fecha</th><th>Folio</th><th>Método</th><th>Nota</th><th class="n">Monto</th></tr></thead><tbody>
    ${g.pagos.map((p) => `<tr class="click" onclick="verGasto(${p.id})"><td>${fdt(p.fecha)}</td><td class="mono">${esc(p.folio)}</td><td>${MET[p.metodo] || ''}</td><td class="sub">${esc(p.nota || '')}</td><td class="n">${money(p.monto)}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">Aún no hay pagos.</td></tr>'}</tbody></table></div>`,
  `<button class="btn" onclick="cerrar()">Cerrar</button><button class="btn pri" onclick="fijoPagar(${id})">Pagar</button>`);
}

// ---------- Avisos de gastos fijos (menú y pantalla de habitaciones) ----------
let AVISOS = [];
async function avisosGastos() {
  try { AVISOS = await GET('/api/gastos-fijos/avisos'); } catch { AVISOS = []; }
  ir.badge = { ...(ir.badge || {}), gastos: AVISOS.length || '' }; pintarNav(ir.badge);
  return AVISOS;
}
{
  const _vHab = vHab;
  vHab = async function () {
    await _vHab();
    if (!puede('gastos') && !puede('reportes')) return;
    const av = await avisosGastos();
    if (av.length) $('#main .top')?.insertAdjacentHTML('afterend', `<div class="aviso ${av.some((g) => g.estado === 'vencido') ? 'bad' : ''}" style="margin-bottom:12px;cursor:pointer" onclick="ir('gastos')"><b>Gastos fijos:</b> ${av.map((g) => `${esc(g.nombre)} ${diasTxt(g)}${g.domiciliado ? ' (domiciliado)' : ''}`).join(' · ')} — toque para ver.</div>`);
  };
}
