// Maxsel Hotel 1.9 — Booking.com y Airbnb (calendarios iCal) + reservaciones en reportes y cierre de mes
'use strict';
const ORG_BK = { Booking: 'Booking.com', Airbnb: 'Airbnb', Expedia: 'Expedia', Otro: 'Otra' };
const EST_BK = { pendiente: 'Pendiente', llego: 'Llegó', cancelada: 'Cancelada', no_llego: 'No llegó' };
async function copiarBk(texto, btn) {
  try { await navigator.clipboard.writeText(texto); toast('Copiado'); }
  catch { const t = document.createElement('textarea'); t.value = texto; document.body.appendChild(t); t.select(); try { document.execCommand('copy'); toast('Copiado'); } catch { toast('Selecciónelo y cópielo a mano', true); } t.remove(); }
  if (btn) { const o = btn.textContent; btn.textContent = 'Copiado ✓'; setTimeout(() => { if (btn.isConnected) btn.textContent = o; }, 1500); }
}
// Pestaña "Booking y Airbnb" dentro de Reservaciones (solo quien tiene permiso de configuración)
{
  const _vRes = vRes;
  vRes = async function () {
    if (resTab === 'ical' && puede('config')) {
      await _vResCab(); return bkPantalla();
    }
    await _vRes();
    bkTab();
  };
  // Encabezado igual al de Reservaciones con la pestaña nueva marcada
  async function _vResCab() { const t = resTab; resTab = 'cal'; await _vRes(); resTab = t; bkTab(); $('#resc').innerHTML = '<div class="sub">Cargando…</div>'; }
  function bkTab() {
    if (!puede('config')) return;
    const tabs = $('#main .tabs'); if (!tabs) return;
    tabs.querySelectorAll('button').forEach((b) => b.classList.toggle('on', resTab !== 'ical' ? b.classList.contains('on') : false));
    tabs.insertAdjacentHTML('beforeend', `<button class="${resTab === 'ical' ? 'on' : ''}" onclick="resTab='ical';vRes()">Booking y Airbnb</button>`);
  }
}
async function bkPantalla() {
  const [I, habs] = await Promise.all([GET('/api/ical'), GET('/api/habitaciones')]);
  const ips = (CFG._ips || []).filter((i) => !i.tailscale), p = CFG._puerto || location.port || 3050;
  const base = (CFG.ical_url_base || '').replace(/\/+$/, '') || `http://${ips[0]?.ip || location.hostname}:${p}`;
  bkPantalla.link = (num, exc) => `${base}/ical/${I.token}/${encodeURIComponent(num)}.ics${exc ? '?excluir=' + exc : ''}`;
  const H = sortH(habs), opH = H.map((h) => `<option value="${esc(h.numero)}" data-id="${h.id}">${esc(h.numero)}${h.nombre ? ' · ' + esc(h.nombre) : ''}</option>`).join('');
  $('#resc').innerHTML = `<div class="stack">
    <div class="card"><h2>Cómo funciona</h2>
      <p style="margin-top:0">Booking.com y Airbnb comparten un <b>calendario</b> (iCal) por cada habitación. Con eso, cuando alguien reserva en Booking, la habitación queda <b>apartada sola</b> en Maxsel; y cuando usted reserva o renta aquí, Booking la <b>cierra</b> en esas fechas. Así no se renta dos veces.</p>
      <ul class="sub" style="margin:0;padding-left:18px"><li>Maxsel revisa los calendarios cada 30 minutos (Booking y Airbnb tardan entre 30 minutos y unas horas en leer el de Maxsel).</li>
        <li>Solo pasan las fechas ocupadas: el nombre del huésped, el precio y si ya pagó se ven en la extranet de Booking o Airbnb.</li>
        <li>Booking da la sincronización de calendarios a ciertos alojamientos (departamentos, casas y hoteles chicos). Si en su extranet no aparece "Sincronizar calendarios", hace falta un channel manager (vea abajo).</li></ul></div>
    <div class="card"><h2>1. Traer las reservaciones de Booking / Airbnb a Maxsel</h2>
      <ol class="pasos"><li><b>Booking.com</b>: extranet → <b>Tarifas y disponibilidad → Sincronizar calendarios</b> → elija la habitación → <b>Exportar calendario</b> y copie el enlace.<br><b>Airbnb</b>: Calendario → <b>Disponibilidad → Conectar calendarios → Exportar calendario</b> y copie el enlace.</li><li>Péguelo aquí con su habitación y toque <b>Agregar</b>.</li></ol>
      <div class="f"><label class="l">Habitación<select id="bkH">${opH}</select></label><label class="l">Plataforma<select id="bkC">${Object.entries(ORG_BK).map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select></label>
        <label class="l" style="grid-column:1/-1">Enlace del calendario (.ics)<input id="bkU" placeholder="https://admin.booking.com/hotel/hoteladmin/ical.html?t=..."></label></div>
      <div class="row"><button class="btn pri" onclick="bkAgregar()">Agregar</button>${I.fuentes.length ? '<button class="btn" onclick="bkSync()">Sincronizar ahora</button>' : ''}</div>
      ${I.fuentes.length ? `<div class="tw" style="margin-top:12px"><table><thead><tr><th>Hab.</th><th>Plataforma</th><th>Última vez</th><th>Resultado</th><th></th></tr></thead><tbody>${I.fuentes.map((f) => `<tr><td><b>${esc(f.numero)}</b></td><td>${esc(ORG_BK[f.canal] || f.canal)}</td><td>${f.ultimo ? fdt(f.ultimo) : 'Aún no'}</td><td class="${/^Error/.test(f.resultado || '') ? 'neg' : 'sub'}">${esc(f.resultado || '—')}</td><td style="white-space:nowrap"><button class="btn sm" onclick="bkSync(${f.id})">Sincronizar</button> <button class="btn sm bad" onclick="confirmar(this,()=>bkQuitar(${f.id}))">Quitar</button></td></tr>`).join('')}</tbody></table></div>` : ''}</div>
    <div class="card"><h2>2. Mandar a Booking / Airbnb lo que se reserva y renta en Maxsel</h2>
      <ol class="pasos"><li>La computadora del hotel debe verse desde internet: la dirección del <b>monitoreo remoto</b> (No-IP / DDNS) y el puerto ${esc(p)} abierto en el módem. Escríbala aquí:
          <div class="row" style="margin-top:6px;flex-wrap:wrap"><input id="bkBase" value="${esc(CFG.ical_url_base || '')}" placeholder="http://mihotel.ddns.net:${esc(p)}" style="max-width:340px"><button class="btn sm" onclick="bkGuardarBase()">Guardar</button></div></li>
        <li><label class="row" style="font-weight:600"><input type="checkbox" ${I.publico ? 'checked' : ''} onchange="bkPublico(this.checked)"> Permitir que Booking y Airbnb lean los calendarios desde internet</label><span class="sub">Solo se abre la dirección de los calendarios (con clave secreta); el resto del sistema sigue cerrado.</span></li>
        <li>En Booking: <b>Sincronizar calendarios → Importar calendario</b> y pegue el enlace de esa habitación. En Airbnb: <b>Conectar calendarios → Importar calendario</b>.</li></ol>
      ${!CFG.ical_url_base ? '<div class="aviso bad">Todavía no escribe la dirección de internet: los enlaces de abajo solo funcionan dentro del hotel.</div>' : ''}
      <div class="f"><label class="l">Habitación<select id="bkX" onchange="bkLink()">${opH}</select></label></div>
      <div class="lbl">Enlace para Booking.com</div><div class="row" style="gap:8px;flex-wrap:wrap"><code class="codigo bk-l" id="bkLb"></code><button class="btn sm" onclick="copiarBk($('#bkLb').textContent,this)">Copiar</button></div>
      <div class="lbl">Enlace para Airbnb</div><div class="row" style="gap:8px;flex-wrap:wrap"><code class="codigo bk-l" id="bkLa"></code><button class="btn sm" onclick="copiarBk($('#bkLa').textContent,this)">Copiar</button></div>
      <p class="sub">Si alguien copió los enlaces sin permiso, <button class="btn sm" onclick="confirmar(this,bkToken)">cambie la clave secreta</button> y vuelva a pegarlos en Booking y Airbnb.</p></div>
    <div class="card"><h2>Conexión completa con precios (más adelante)</h2><p class="sub" style="margin:0">Para que Maxsel cambie precios y reciba nombre, teléfono y pago de cada huésped de Booking, Expedia y Airbnb se usa un <b>channel manager</b> conectado por API (por ejemplo Channex, desde unos US$7 al mes por hotel más la cuota de la plataforma). Booking no conecta directo sistemas nuevos sin certificarlos, así que esa es la vía.</p></div></div>`;
  bkLink();
}
function bkLink() { const n = val('bkX'); if (!n || !bkPantalla.link) return; $('#bkLb').textContent = bkPantalla.link(n, 'Booking'); $('#bkLa').textContent = bkPantalla.link(n, 'Airbnb'); }
async function bkAgregar() { const o = $('#bkH').selectedOptions[0]; await hacer(() => POST('/api/ical/fuentes', { habitacion_id: o?.dataset.id, canal: val('bkC'), url: val('bkU') }), 'Calendario agregado'); await bkSync(); }
async function bkSync(id) { toast('Sincronizando…'); try { const r = await POST('/api/ical/sincronizar', { id }); toast(r.length ? r.map((x) => x.resultado).join(' | ').slice(0, 180) : 'No hay calendarios'); } catch (e) { toast(e.message, true); } vRes(); }
async function bkQuitar(id) { await hacer(() => DEL('/api/ical/fuentes/' + id), 'Quitado'); vRes(); }
async function bkPublico(v) { await hacer(() => PUT('/api/config', { ical_publico: v ? '1' : '0' }), v ? 'Booking y Airbnb ya pueden leer los calendarios' : 'Desactivado'); CFG.ical_publico = v ? '1' : '0'; }
async function bkGuardarBase() { const v = val('bkBase').replace(/\/+$/, ''); if (v && !/^https?:\/\//i.test(v)) return toast('Debe empezar con http:// o https://', true); await hacer(() => PUT('/api/config', { ical_url_base: v }), 'Guardado'); CFG.ical_url_base = v; vRes(); }
async function bkToken() { await hacer(() => POST('/api/ical/token'), 'Clave cambiada: vuelva a pegar los enlaces en Booking y Airbnb'); vRes(); }

// ---------- Reservaciones en reportes, cierre de mes, PDF y Excel ----------
function resvHTML(R) {
  if (!R) return '';
  return `<div class="card" style="margin-bottom:16px"><h2>Reservaciones</h2>
    <div class="kpis"><div class="kpi"><span>Reservaciones hechas</span><b>${R.hechas}</b><div class="sub">${R.llegaron} llegaron · ${R.pendientes} pendientes hoy</div></div>
      <div class="kpi"><span>Anticipos cobrados</span><b>${money(R.anticipos.total)}</b><div class="sub">${R.anticipos.n} anticipo(s) · por aplicar ${money(R.anticipos_por_aplicar)}</div></div>
      <div class="kpi"><span>Cancelaciones</span><b>${R.canceladas.n + R.noshow.n}</b><div class="sub">${R.canceladas.n} canceladas · ${R.noshow.n} no llegaron</div></div>
      <div class="kpi"><span>Anticipos retenidos</span><b style="color:var(--libre)">${money(R.retenido_total)}</b><div class="sub">devuelto ${money(R.devoluciones.total)}</div></div></div>
    ${R.por_origen.length ? `<div class="kv">${R.por_origen.map((o) => `<span>${esc(o.nombre)} (${o.n})</span><b>${money(o.total)}</b>`).join('')}</div>` : ''}
    ${R.lista.length ? `<div class="tw" style="margin-top:10px;max-height:320px"><table><thead><tr><th>Folio</th><th>Llega</th><th>Hab.</th><th>Huésped</th><th>Origen</th><th class="n">Total</th><th class="n">Anticipo</th><th class="n">Retenido</th><th>Estado</th></tr></thead><tbody>${R.lista.map((r) => `<tr><td class="mono">${esc(r.folio)}</td><td>${fd(r.llegada)}</td><td>${esc(r.numero || '')}</td><td>${esc(r.huesped)}</td><td>${esc(r.origen || '')}</td><td class="n">${money(r.total)}</td><td class="n">${money(r.anticipo)}</td><td class="n">${r.retenido ? money(r.retenido) : ''}</td><td>${EST_BK[r.estado] || r.estado}</td></tr>`).join('')}</tbody></table></div>` : ''}</div>`;
}
{
  const _ex = extrasHTML;
  extrasHTML = function (X, titulo) { return _ex(X, titulo) + resvHTML(X.reservaciones); };
  const _pdf = pdfExtras;
  pdfExtras = function (C) {
    const R = C.extra?.reservaciones, fila = (a, b, t) => `<tr${t ? ' class="t"' : ''}><td>${a}</td><td class="n">${b}</td></tr>`;
    if (!R) return _pdf(C);
    return _pdf(C) + `<h3>Reservaciones</h3><div class="rep-2"><div><table><tbody>${fila('Reservaciones hechas', R.hechas)}${fila('Llegaron', R.llegaron)}${fila('Canceladas', R.canceladas.n)}${fila('No llegaron', R.noshow.n)}${fila('Pendientes (hoy)', R.pendientes)}</tbody></table></div>
      <div><table><tbody>${fila(`Anticipos cobrados (${R.anticipos.n})`, money(R.anticipos.total))}${fila('Devoluciones de anticipo', '−' + money(R.devoluciones.total))}${fila('Anticipos retenidos (ingreso)', money(R.retenido_total), 1)}${fila('Anticipos por aplicar', money(R.anticipos_por_aplicar))}${R.por_origen.map((o) => fila(`${esc(o.nombre)} (${o.n})`, money(o.total))).join('')}</tbody></table></div></div>
      ${R.lista.length ? `<table><thead><tr><th>Folio</th><th>Llega</th><th>Hab.</th><th>Huésped</th><th>Origen</th><th class="n">Total</th><th class="n">Anticipo</th><th class="n">Retenido</th><th>Estado</th></tr></thead><tbody>${R.lista.map((r) => `<tr><td>${esc(r.folio)}</td><td>${fd(r.llegada)}</td><td>${esc(r.numero || '')}</td><td>${esc(r.huesped)}</td><td>${esc(r.origen || '')}</td><td class="n">${money(r.total)}</td><td class="n">${money(r.anticipo)}</td><td class="n">${r.retenido ? money(r.retenido) : ''}</td><td>${EST_BK[r.estado] || r.estado}</td></tr>`).join('')}</tbody></table>` : ''}`;
  };
  const _hj = hojasExtras;
  hojasExtras = function (X) {
    const out = _hj(X), R = X.reservaciones; if (!R) return out;
    out.push({ nombre: 'Reservaciones', filas: [H_('Resumen', 'Valor'), ['Reservaciones hechas', R.hechas], ['Llegaron', R.llegaron], ['Canceladas', R.canceladas.n], ['No llegaron', R.noshow.n], ['Anticipos cobrados', M_(R.anticipos.total)], ['Devoluciones de anticipo', M_(R.devoluciones.total)], [B_('Anticipos retenidos'), BM_(R.retenido_total)], ['Anticipos por aplicar', M_(R.anticipos_por_aplicar)], [],
      H_('Folio', 'Creada', 'Llega', 'Sale', 'Hab.', 'Huésped', 'Teléfono', 'Origen', 'Renta', 'Total', 'Anticipo', 'Devuelto', 'Retenido', 'Estado'),
      ...R.lista.map((r) => [r.folio, fdt(r.creado), fd(r.llegada), fd(r.salida), r.numero || '', r.huesped, r.telefono || '', r.origen || '', unidad(r.modalidad, r.cantidad), M_(r.total), M_(r.anticipo), M_(r.devuelto), M_(r.retenido), EST_BK[r.estado] || r.estado])] });
    return out;
  };
}
