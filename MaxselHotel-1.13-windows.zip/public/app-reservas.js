// Maxsel Hotel 1.9 — RESERVACIONES A FUTURO
// Calendario de ocupación y reservaciones, apartar habitación con anticipo, aviso de quién llega hoy,
// entrada desde la reservación (el anticipo ya queda abonado), cancelación con devolución y "no llegó".
'use strict';
document.head.insertAdjacentHTML('beforeend', `<style>
.rcal{overflow:auto;border:1px solid var(--line);border-radius:12px;background:var(--panel);max-height:70vh}
.rcal table{border-collapse:separate;border-spacing:0;min-width:100%;font-size:12px}
.rcal th,.rcal td{border-right:1px solid var(--line);border-bottom:1px solid var(--line);padding:0;height:34px;min-width:44px;text-align:center;white-space:nowrap}
.rcal thead th{position:sticky;top:0;background:var(--panel);z-index:2;padding:4px 2px;font-weight:600}
.rcal thead th.hoy{background:var(--libreBg);color:var(--libre)}
.rcal th.hab{position:sticky;left:0;background:var(--panel);z-index:3;text-align:left;padding:0 10px;min-width:70px}
.rcal td.vacio{cursor:pointer}.rcal td.vacio:hover{background:var(--libreBg)}
.rcal td.fin{background:repeating-linear-gradient(45deg,transparent 0 6px,rgba(0,0,0,.03) 6px 12px)}
.rcal .bar{display:block;height:26px;margin:0 1px;border-radius:6px;color:#fff;font-weight:600;line-height:26px;padding:0 6px;overflow:hidden;text-overflow:ellipsis;text-align:left;cursor:pointer;font-size:12px}
.rcal .bar.occ{background:#64748b}.rcal .bar.res{background:var(--m-dia,#2563eb)}
.rcal .bar.res.m-noche{background:var(--m-noche)}.rcal .bar.res.m-semana{background:var(--m-semana)}.rcal .bar.res.m-mes{background:var(--m-mes)}
.res-av{font-size:11px;font-weight:700;color:#fff;background:var(--porvencer,#ea580c);border-radius:20px;padding:2px 8px;display:inline-block;margin-top:4px}
.res-av.hoy{background:var(--vencida,#c03434)}
.res-calc{display:grid;grid-template-columns:1fr auto;gap:4px 12px;padding:10px 12px;border-radius:10px;background:var(--panel2,#f4f6f9);margin-top:8px}
.res-calc .err{grid-column:1/-1;color:var(--ocup);font-weight:600}.res-calc .warn{grid-column:1/-1;color:var(--limp);font-weight:600}
</style>`);
VISTAS.splice(Math.max(1, VISTAS.findIndex((v) => v[0] === 'hab') + 1), 0, ['res', 'Reservaciones', 'registrar|reportes']);
{
  const _ir = ir;
  ir = async function (v) {
    if (v !== 'res') return _ir(v);
    vista = v; clearInterval(timer); pintarNav(ir.badge);
    try { await vRes(); } catch (e) { if (e.message) $('#main').innerHTML = `<div class="aviso bad">${esc(e.message)}</div>`; }
    timer = setInterval(() => { if ($('#modal').hidden && vista === 'res') vRes().catch(() => {}); }, 60000);
    if (window.innerWidth < 760) window.scrollTo(0, 0);
  };
}
const RES_MODS = ['noche', 'dia', 'semana', 'mes'];
const ORIGENES = ['Teléfono', 'WhatsApp', 'En persona', 'Facebook', 'Booking', 'Airbnb', 'Expedia', 'Otro'];
const EST_RES = { pendiente: ['Pendiente', 'p-warn'], llego: ['Llegó', 'p-ok'], cancelada: ['Cancelada', ''], no_llego: ['No llegó', 'p-bad'] };
const fF = (f) => (f ? f.split('-').reverse().join('/') : '—');
const diaSem = (f) => aF(f + ' 12:00:00').toLocaleDateString('es-MX', { weekday: 'short', day: '2-digit', month: 'short' });
const sumarD = (f, n) => { const d = aF(f + ' 12:00:00'); d.setDate(d.getDate() + n); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
let resTab = 'cal', resEst = 'pendiente', calDesde = hoyISO(), calDias = 14, RES_L = [], RES_HABS = [];
const avisoRes = (r) => (r.aviso === 'hoy' ? '<span class="res-av hoy">Llega hoy</span>' : r.aviso === 'manana' ? '<span class="res-av">Llega mañana</span>' : r.aviso === 'no_llego' ? '<span class="res-av hoy">No ha llegado</span>' : '');

async function vRes() {
  const acc = puede('registrar') ? '<button class="btn pri" onclick="resModal()">Nueva reservación</button>' : '';
  const T = [['cal', 'Calendario'], ['lista', 'Lista']];
  $('#main').innerHTML = cab('Reservaciones', 'Aparte habitaciones para otras fechas. El día que llega el huésped, registre su entrada desde aquí y su anticipo ya queda abonado.', acc)
    + `<div class="tabs" style="margin-bottom:14px">${T.map(([k, n]) => `<button class="${resTab === k ? 'on' : ''}" onclick="resTab='${k}';vRes()">${n}</button>`).join('')}</div><div id="resc"></div>`;
  await (resTab === 'cal' ? resCal() : resLista());
}
// ---------- Calendario: habitaciones × días ----------
async function resCal() {
  const c = await GET(`/api/reservaciones/calendario?desde=${calDesde}&dias=${calDias}`);
  RES_HABS = c.habitaciones;
  const dias = Array.from({ length: c.dias }, (_, i) => sumarD(c.desde, i)), hoy = hoyISO();
  const celdas = (h) => {
    const occ = c.estancias.filter((e) => e.habitacion_id === h.id), res = c.reservas.filter((r) => r.habitacion_id === h.id);
    let out = '', i = 0;
    while (i < dias.length) {
      const f = dias[i];
      const e = occ.find((x) => x.entrada.slice(0, 10) <= f && x.salida_prevista.slice(0, 10) > f);
      const r = !e && res.find((x) => x.llegada <= f && x.salida > f);
      if (e || r) {
        const fin = e ? e.salida_prevista.slice(0, 10) : r.salida;
        let n = 0; while (i + n < dias.length && dias[i + n] < fin && !(e && res.some((x) => x.llegada === dias[i + n] && n > 0))) n++;
        n = Math.max(1, n);
        out += e ? `<td colspan="${n}"><span class="bar occ" title="${esc(e.huesped)} · sale ${fdt(e.salida_prevista)}" onclick="verEstancia(${e.id})">${esc(e.huesped)}</span></td>`
          : `<td colspan="${n}"><span class="bar res m-${r.modalidad}" title="${esc(r.folio + ' · ' + r.huesped + ' · ' + fF(r.llegada) + ' al ' + fF(r.salida))}" onclick="resVer(${r.id})">${esc(r.huesped)}</span></td>`;
        i += n;
      } else { out += `<td class="vacio ${[0, 6].includes(aF(f + ' 12:00:00').getDay()) ? 'fin' : ''}" ${puede('registrar') ? `onclick="resModal(0,{habitacion_id:${h.id},llegada:'${f}'})" title="Reservar ${esc(h.numero)} el ${fF(f)}"` : ''}></td>`; i++; }
    }
    return out;
  };
  $('#resc').innerHTML = `<div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:10px;align-items:flex-end">
      <button class="btn" onclick="calDesde=sumarD(calDesde,-${calDias});resCal()">◀ Antes</button><button class="btn" onclick="calDesde=hoyISO();resCal()">Hoy</button><button class="btn" onclick="calDesde=sumarD(calDesde,${calDias});resCal()">Después ▶</button>
      <label class="l" style="margin:0">Desde<input type="date" value="${calDesde}" onchange="calDesde=this.value||hoyISO();resCal()"></label>
      <div class="tabs">${[14, 30].map((n) => `<button class="${calDias === n ? 'on' : ''}" onclick="calDias=${n};resCal()">${n} días</button>`).join('')}</div>
      <div class="leyenda" style="margin:0"><span><i style="background:#64748b"></i>Ocupada ahora</span>${RES_MODS.map((m) => `<span><i style="background:var(--m-${m})"></i>Reservada ${MOD[m].toLowerCase()}</span>`).join('')}</div></div>
    <div class="rcal"><table><thead><tr><th class="hab">Hab.</th>${dias.map((f) => `<th class="${f === hoy ? 'hoy' : ''}">${diaSem(f).replace(/\./g, '').replace(' ', '<br>')}</th>`).join('')}</tr></thead>
    <tbody>${c.habitaciones.map((h) => `<tr><th class="hab">${esc(h.numero)}${h.nombre ? `<div class="sub" style="font-weight:400">${esc(h.nombre)}</div>` : ''}</th>${celdas(h)}</tr>`).join('') || `<tr><td class="empty">No hay habitaciones</td></tr>`}</tbody></table></div>
    <p class="sub">Toque un espacio vacío para apartar esa habitación ese día. Toque una reservación para verla.</p>`;
}
// ---------- Lista ----------
async function resLista() {
  const desde = resEst === 'pendiente' ? hoyISO() : sumarD(hoyISO(), -60), hasta = sumarD(hoyISO(), 365);
  RES_L = await GET(`/api/reservaciones?estado=${resEst}&desde=${desde}&hasta=${hasta}`);
  const F = [['pendiente', 'Pendientes'], ['llego', 'Llegaron'], ['no_llego', 'No llegaron'], ['cancelada', 'Canceladas']];
  $('#resc').innerHTML = `<div class="tabs" style="margin-bottom:10px">${F.map(([k, n]) => `<button class="${resEst === k ? 'on' : ''}" onclick="resEst='${k}';resLista()">${n}</button>`).join('')}</div>
    <div class="tw"><table><thead><tr><th>Folio</th><th>Llega</th><th>Sale</th><th>Hab.</th><th>Huésped</th><th>Renta</th><th class="n">Total</th><th class="n">Anticipo</th><th class="n">Por pagar</th><th></th></tr></thead><tbody>
    ${RES_L.map((r) => `<tr><td class="mono">${esc(r.folio)}<div>${avisoRes(r) || `<span class="pill ${EST_RES[r.estado][1]}">${EST_RES[r.estado][0]}</span>`}</div></td><td>${diaSem(r.llegada)}${r.hora_llegada ? `<div class="sub">${esc(r.hora_llegada)} h</div>` : ''}</td><td>${diaSem(r.salida)}</td>
      <td><b>${esc(r.numero)}</b></td><td><b>${esc(r.huesped)}</b>${r.telefono ? `<div class="sub">${esc(r.telefono)}</div>` : ''}${r.origen ? `<div class="sub">${esc(r.origen)}</div>` : ''}</td><td>${unidad(r.modalidad, r.cantidad)}</td>
      <td class="n">${money(r.total)}</td><td class="n">${money(r.anticipo)}${r.devuelto ? `<div class="sub">devuelto ${money(r.devuelto)}</div>` : ''}</td><td class="n"><b>${money(r.estado === 'pendiente' ? r.saldo : 0)}</b></td>
      <td class="row" style="gap:4px;justify-content:flex-end;flex-wrap:wrap">${r.estado === 'pendiente' && r.llegada <= hoyISO() && puede('registrar') ? `<button class="btn sm pri" onclick="resEntrada(${r.id})">Registrar entrada</button>` : ''}<button class="btn sm" onclick="resVer(${r.id})">Ver</button></td></tr>`).join('')
      || `<tr><td colspan="10" class="empty">${resEst === 'pendiente' ? 'No hay reservaciones pendientes.' : 'No hay reservaciones en esta lista.'}</td></tr>`}</tbody></table></div>`;
}
// ---------- Ver una reservación ----------
async function resVer(id) {
  const r = await GET('/api/reservaciones/' + id), pend = r.estado === 'pendiente';
  modal(`Reservación ${esc(r.folio)} · Hab. ${esc(r.numero)}`, `<div class="row">${avisoRes(r)}<span class="pill ${EST_RES[r.estado][1]}">${EST_RES[r.estado][0]}</span></div>
    <div class="kv"><span>Huésped</span><b>${esc(r.huesped)}</b><span>Teléfono</span><span>${esc(r.telefono || '—')}</span><span>Personas</span><span>${r.personas}</span>
      <span>Llega</span><span>${diaSem(r.llegada)}${r.hora_llegada ? ' · ' + esc(r.hora_llegada) + ' h' : ''}</span><span>Sale</span><span>${diaSem(r.salida)}</span>
      <span>Renta</span><span>${unidad(r.modalidad, r.cantidad)} × ${money(r.precio)}</span><span>Total</span><b>${money(r.total)}</b><span>Anticipo</span><b>${money(r.anticipo)}</b>
      ${pend ? `<span>Por pagar al llegar</span><b style="color:var(--ocup)">${money(r.saldo)}</b>` : ''}${r.origen ? `<span>Cómo reservó</span><span>${esc(r.origen)}</span>` : ''}${r.notas ? `<span>Notas</span><span>${esc(r.notas)}</span>` : ''}
      <span>Reservó</span><span>${fdt(r.creado)}${r.usuario ? ' · ' + esc(r.usuario) : ''}</span>${r.motivo ? `<span>Motivo</span><span>${esc(r.motivo)}</span>` : ''}${r.devuelto ? `<span>Devuelto</span><span>${money(r.devuelto)}</span>` : ''}</div>
    ${r.pagos.length ? `<div class="lbl">Pagos</div><div class="tw"><table><tbody>${r.pagos.map((p) => `<tr><td>${fdt(p.fecha)}</td><td>${MET[p.metodo] || p.metodo}</td><td class="sub">${esc(p.nota || '')}</td><td class="n">${money(p.monto)}</td></tr>`).join('')}</tbody></table></div>` : ''}`,
  `${r.telefono ? `<button class="btn" onclick="resWhats(${r.id})">WhatsApp</button>` : ''}<button class="btn" onclick="resImprimir(${r.id})">Imprimir</button>
   ${pend && puede('registrar') ? `<button class="btn bad" onclick="resCancelar(${r.id})">Cancelar</button><button class="btn" onclick="resModal(${r.id})">Cambiar</button>` : ''}
   ${pend && puede('caja') ? `<button class="btn" onclick="resAnticipo(${r.id})">Recibir anticipo</button>` : ''}
   ${pend && r.llegada <= hoyISO() && puede('registrar') ? `<button class="btn pri" onclick="resEntrada(${r.id})">Registrar entrada</button>` : ''}
   ${r.estado === 'llego' && r.estancia_id ? `<button class="btn pri" onclick="verEstancia(${r.estancia_id})">Ver la cuenta</button>` : ''}`, true);
  resVer.r = r;
}
// ---------- Nueva / cambiar reservación ----------
async function resModal(id, pre = {}) {
  const habs = (await GET('/api/habitaciones')).filter((h) => h.activo !== 0).sort((a, b) => String(a.numero).localeCompare(String(b.numero), 'es', { numeric: true }));
  RES_HABS = habs;
  const r = id ? await GET('/api/reservaciones/' + id) : { habitacion_id: pre.habitacion_id || habs[0]?.id, huesped: '', telefono: '', personas: 1, llegada: pre.llegada || hoyISO(), hora_llegada: '', modalidad: '', cantidad: 1, precio: '', origen: 'Teléfono', notas: '' };
  modal(id ? `Cambiar reservación ${esc(r.folio)}` : 'Nueva reservación', `<div class="f">
    <label class="l" style="grid-column:1/-1">Nombre de quien reserva<input id="xH" value="${esc(r.huesped)}" autocomplete="off"></label>
    <label class="l">Teléfono (WhatsApp)<input id="xT" value="${esc(r.telefono || '')}" inputmode="tel"></label>
    <label class="l">Personas<input id="xP" type="number" min="1" value="${r.personas}"></label>
    <label class="l">Habitación<select id="xHab" onchange="resPrecios(1)">${habs.map((h) => `<option value="${h.id}" ${h.id === r.habitacion_id ? 'selected' : ''}>${esc(h.numero)}${h.nombre ? ' · ' + esc(h.nombre) : ''} (${CLASE_C[h.clase] || 'Hab.'})</option>`).join('')}</select></label>
    <label class="l">Llega el<input id="xL" type="date" value="${esc(r.llegada)}" ${id ? '' : `min="${hoyISO()}"`} onchange="resRevisar()"></label>
    <label class="l">Hora aproximada de llegada<input id="xHL" type="time" value="${esc(r.hora_llegada || '')}"></label>
    <label class="l">Cómo reservó<select id="xO">${ORIGENES.map((o) => `<option ${o === r.origen ? 'selected' : ''}>${o}</option>`).join('')}</select></label></div>
    <div class="lbl">Tipo de renta</div><div class="seg" id="xMods"></div>
    <div class="f"><label class="l">Cantidad<input id="xC" type="number" min="1" value="${r.cantidad}" oninput="resRevisar()"></label><label class="l">Precio unitario<input id="xU" type="number" min="0" step="0.01" value="${r.precio}" oninput="this.dataset.t=1;resRevisar()"></label>
      ${id ? '' : `<label class="l">Anticipo (opcional)<input id="xA" type="number" min="0" step="0.01" placeholder="0.00" oninput="resRevisar()"></label>`}</div>
    <label class="l">Notas<input id="xN" value="${esc(r.notas || '')}" placeholder="Ej. cuna, llega tarde, factura…"></label><div class="res-calc" id="xRes"></div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="resOk(${id || 0})">${id ? 'Guardar cambios' : 'Apartar habitación'}</button>`);
  resModal.r = r; resPrecios(0, r.modalidad, r.precio);
  $('#xH').focus();
}
function resPrecios(reset, mod, precio) {
  const h = RES_HABS.find((x) => x.id === Number(val('xHab'))); if (!h) return;
  const actual = mod || document.querySelector('input[name=xM]:checked')?.value;
  const ok = RES_MODS.filter((m) => h['precio_' + m] > 0), sel = ok.includes(actual) ? actual : ok[0];
  $('#xMods').innerHTML = RES_MODS.map((m) => `<label class="m-${m}"><input type="radio" name="xM" value="${m}" ${m === sel ? 'checked' : ''} ${h['precio_' + m] > 0 ? '' : 'disabled'} onchange="$('#xU').dataset.t='';resPrecios(1)"><span><i class="dot"></i>${MOD[m]}</span><small>${h['precio_' + m] > 0 ? money(h['precio_' + m]) : 'Sin precio'}</small></label>`).join('');
  if (reset || !$('#xU').value) { $('#xU').value = sel ? h['precio_' + sel] : ''; delete $('#xU').dataset.t; }
  else if (precio) $('#xU').value = precio;
  resRevisar();
}
async function resRevisar() {
  clearTimeout(resRevisar.t);
  resRevisar.t = setTimeout(async () => {
    const b = resBody(); if (!b.modalidad) { $('#xRes').innerHTML = '<span class="err">Esta habitación no tiene precios por noche, día, semana ni mes.</span>'; return; }
    const r = await POST('/api/reservaciones/revisar', { ...b, id: resModal.r?.id }).catch((e) => ({ ok: false, error: e.message }));
    if (!$('#xRes')) return;
    if (!r.ok) { $('#xRes').innerHTML = `<span class="err">${esc(r.error)}</span>`; return; }
    const ant = Number(val('xA')) || 0;
    $('#xRes').innerHTML = `<span>Sale el</span><b>${diaSem(r.salida)} · ${esc(CFG.hora_salida || '13:00')} h</b><span>${unidad(b.modalidad, Number(b.cantidad) || 1)} × ${money(r.precio)}</span><b>${money(r.total)}</b>
      ${ant ? `<span>Anticipo</span><b>${money(ant)}</b><span>Pagará al llegar</span><b>${money(Math.max(0, r.total - ant - (resModal.r?.anticipo || 0)))}</b>` : resModal.r?.anticipo ? `<span>Anticipo ya pagado</span><b>${money(resModal.r.anticipo)}</b>` : ''}${r.aviso ? `<span class="warn">${esc(r.aviso)}</span>` : ''}`;
  }, 250);
}
const resBody = () => ({ habitacion_id: val('xHab'), huesped: val('xH'), telefono: val('xT'), personas: val('xP'), llegada: val('xL'), hora_llegada: val('xHL'), modalidad: document.querySelector('input[name=xM]:checked')?.value, cantidad: val('xC'), precio: val('xU'), origen: val('xO'), notas: val('xN') });
async function resOk(id) {
  const b = resBody(), ant = id ? 0 : Number(val('xA')) || 0;
  if (!b.huesped) return toast('Escriba el nombre de quien reserva', true);
  if (id) { await hacer(() => PUT('/api/reservaciones/' + id, b), 'Reservación guardada'); cerrar(); return vista === 'res' ? vRes() : null; }
  let pago = {};
  if (ant > 0) {
    // Primero se revisa que la habitación esté libre; luego se cobra el anticipo en la ventana de cobro
    const rv = await POST('/api/reservaciones/revisar', b).catch((e) => ({ ok: false, error: e.message }));
    if (!rv.ok) return toast(rv.error, true);
    const guardado = $('#modal').innerHTML;
    const r = await ventanaCobro({ total: ant, titulo: 'Anticipo de reservación', detalle: `${b.huesped} · llega ${fF(b.llegada)}` });
    if (!r) return;
    pago = { anticipo: ant, metodo: 'mixto', partes: r.partes, imprimir: r.imprimir };
    if ($('#modal').hidden) { $('#modal').innerHTML = guardado; $('#modal').hidden = false; }
  }
  const res = await hacer(() => POST('/api/reservaciones', { ...b, ...pago }));
  cerrar();
  if (res?.id) { if (pago.imprimir) resImprimir(res.id); toast(`Reservación ${res.folio}: hab. ${res.numero} del ${fF(res.llegada)} al ${fF(res.salida)}`); }
  if (vista === 'res') vRes(); else if (vista === 'hab') vHab();
}
async function resAnticipo(id) {
  const r = resVer.r && resVer.r.id === id ? resVer.r : await GET('/api/reservaciones/' + id);
  modal('Recibir anticipo · ' + esc(r.folio), `<div class="kv"><span>Total de la reservación</span><b>${money(r.total)}</b><span>Ya pagado</span><b>${money(r.anticipo)}</b><span>Falta</span><b>${money(Math.max(0, r.saldo))}</b></div>
    <label class="l">¿Cuánto deja ahora?<input id="xaM" type="number" min="0" step="0.01" value="${Math.max(0, r.saldo).toFixed(2)}"></label>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="resAnticipoOk(${id})">Cobrar</button>`);
}
async function resAnticipoOk(id) {
  const r = resVer.r, monto = Number(val('xaM')) || 0; if (!(monto > 0)) return toast('Escriba el anticipo', true);
  cerrar();
  const v = await ventanaCobro({ total: monto, titulo: 'Anticipo · ' + r.folio, detalle: r.huesped });
  if (!v) return;
  await hacer(() => POST(`/api/reservaciones/${id}/anticipo`, { monto, metodo: 'mixto', partes: v.partes }), 'Anticipo recibido');
  if (v.imprimir) resImprimir(id);
  if (vista === 'res') vRes();
}
function resCancelar(id) {
  const r = resVer.r;
  modal(`Cancelar ${esc(r.folio)}`, `<div class="f"><label class="l" style="grid-column:1/-1">Motivo<input id="xcM" placeholder="Ej. cambió de planes"></label>
    <label class="row" style="grid-column:1/-1;font-weight:600"><input type="checkbox" id="xcN" ${r.llegada < hoyISO() ? 'checked' : ''}> El huésped no llegó (no-show)</label>
    ${r.anticipo > 0 ? `<label class="l">Devolver del anticipo (${money(r.anticipo)} pagado)<input id="xcD" type="number" min="0" max="${r.anticipo}" step="0.01" value="0"></label>
    <label class="l">Se devuelve en<select id="xcF"><option value="efectivo">Efectivo (sale de la caja)</option><option value="transferencia">Transferencia</option><option value="tarjeta">Tarjeta</option></select></label>
    <p class="sub" style="grid-column:1/-1;margin:0">Si no devuelve nada, el anticipo se queda como ingreso.</p>` : ''}</div>`,
  `<button class="btn" onclick="cerrar()">Regresar</button><button class="btn bad" onclick="resCancelarOk(${id})">Cancelar reservación</button>`);
}
async function resCancelarOk(id) {
  await hacer(() => POST(`/api/reservaciones/${id}/cancelar`, { motivo: val('xcM'), no_llego: $('#xcN').checked, devolver: val('xcD') || 0, metodo_devolucion: val('xcF') || 'efectivo' }), 'Reservación cancelada');
  cerrar(); if (vista === 'res') vRes(); else if (vista === 'hab') vHab();
}
function resWhats(id) {
  const r = resVer.r && resVer.r.id === id ? resVer.r : RES_L.find((x) => x.id === id); if (!r?.telefono) return;
  let tel = String(r.telefono).replace(/\D/g, ''); if (tel.length === 10) tel = '52' + tel;
  const msg = `Hola ${r.huesped}, le confirmamos su reservación ${r.folio} en ${CFG.hotel_nombre}: habitación ${r.numero}, llegada ${diaSem(r.llegada)}${r.hora_llegada ? ' ' + r.hora_llegada + ' h' : ''}, salida ${diaSem(r.salida)} a las ${CFG.hora_salida || '13:00'} h. Total ${money(r.total)}${r.anticipo ? `, anticipo recibido ${money(r.anticipo)}, resta ${money(r.saldo)}` : ''}. ¡Le esperamos!`;
  window.open('https://wa.me/' + tel + '?text=' + encodeURIComponent(msg), '_blank');
}
async function resImprimir(id) {
  const r = await GET('/api/reservaciones/' + id);
  imprimir([...encabezado(), 'COMPROBANTE DE RESERVACIÓN', '-'.repeat(W()), lin('Folio', r.folio), lin('Fecha', fdt(r.creado)), ...wrapT('Huésped: ' + r.huesped), ...(r.telefono ? [lin('Teléfono', r.telefono)] : []),
    lin('Habitación', r.numero), lin('Llega', fF(r.llegada) + (r.hora_llegada ? ' ' + r.hora_llegada : '')), lin('Sale', fF(r.salida) + ' ' + (CFG.hora_salida || '13:00')), lin('Renta', unidad(r.modalidad, r.cantidad)),
    '-'.repeat(W()), lin('Total', money(r.total)), lin('Anticipo', money(r.anticipo)), lin('PAGA AL LLEGAR', money(Math.max(0, r.saldo))), '-'.repeat(W()), ...(r.notas ? wrapT('Notas: ' + r.notas) : []), '', ...wrapT('Presente este comprobante al llegar.'), '', 'Impreso ' + new Date().toLocaleString('es-MX')], 'Comprobante de reservación');
}
// ---------- Entrada desde la reservación ----------
let RES_ENTRADA = null;
async function resEntrada(id) {
  const r = await GET('/api/reservaciones/' + id);
  TAB = await GET('/api/tablero');
  const h = TAB.habitaciones.find((x) => x.id === r.habitacion_id);
  if (!h) return toast('La habitación ya no existe: cambie la reservación', true);
  if (h.estado !== 'libre') return toast(`La habitación ${h.numero} está ${EST[h.estado].toLowerCase()}. Libérela o cambie la reservación a otra habitación.`, true);
  cerrar();
  registrar(h.id);
  RES_ENTRADA = { id: r.id, hab: h.id };
  $('#rH').value = r.huesped; $('#rT').value = r.telefono || ''; $('#rN').value = r.personas || 1;
  if (r.notas) $('#rO').value = r.notas;
  const radio = document.querySelector(`input[name=rM][value="${r.modalidad}"]`);
  if (radio && !radio.disabled) { radio.checked = true; rCalc(h.id, 1); }
  $('#rC').value = r.cantidad; $('#rU').value = r.precio; rCalc(h.id);
  const total = r.cantidad * r.precio, resta = Math.max(0, total - r.anticipo);
  $('#rA').value = resta.toFixed(2); $('#rA').dataset.t = 1; rCalc(h.id);
  $('#modal .mbody')?.insertAdjacentHTML('afterbegin', `<div class="aviso" style="margin-bottom:8px">Entrada de la reservación <b>${esc(r.folio)}</b>${r.anticipo ? ` · anticipo ya pagado <b>${money(r.anticipo)}</b> (se abona solo a la cuenta)` : ''}. En "Anticipo / pago" está lo que falta.</div>`);
  $('#modal h3').textContent += ' · Reservación ' + r.folio;
}
{
  const _reg = registrar;
  registrar = function (id) { RES_ENTRADA = null; return _reg(id); };
  const _api = api;
  api = async function (metodo, url, body) {
    if (metodo === 'POST' && url === '/api/estancias' && body && RES_ENTRADA && Number(body.habitacion_id) === RES_ENTRADA.hab) {
      body = { ...body, reservacion_id: RES_ENTRADA.id };
      const r = await _api(metodo, url, body);
      RES_ENTRADA = null; return r;
    }
    return _api(metodo, url, body);
  };
}
// ---------- Tablero de habitaciones: quién llega hoy y mañana ----------
let RES_PROX = [];
{
  const _vh = vHab;
  vHab = async function (...a) {
    const r = await _vh(...a);
    try {
      RES_PROX = await GET(`/api/reservaciones?estado=pendiente&desde=${hoyISO()}&hasta=${sumarD(hoyISO(), 1)}`);
      const hoyN = RES_PROX.filter((x) => x.llegada <= hoyISO()).length;
      ir.badge = { ...(ir.badge || {}), res: hoyN || '' }; pintarNav(ir.badge);
      for (const x of RES_PROX) {
        if (x.llegada > sumarD(hoyISO(), 1)) continue;
        const b = document.querySelector(`#main button.tag[onclick="abrirHab(${x.habitacion_id})"]`); if (!b || b.querySelector('.res-av')) continue;
        b.insertAdjacentHTML('beforeend', `<span class="res-av ${x.llegada <= hoyISO() ? 'hoy' : ''}">${x.llegada < hoyISO() ? 'Reservada (no ha llegado)' : x.llegada === hoyISO() ? 'Reservada hoy' : 'Llega mañana'}: ${esc(x.huesped)}</span>`);
      }
    } catch { /* sin reservaciones */ }
    return r;
  };
  const _ah = abrirHab;
  abrirHab = function (id) {
    const r = _ah(id);
    const x = RES_PROX.find((y) => y.habitacion_id === id && y.llegada <= hoyISO());
    const h = TAB?.habitaciones?.find((y) => y.id === id);
    if (x && h && h.estado === 'libre' && !$('#modal').hidden) {
      $('#modal .mbody')?.insertAdjacentHTML('afterbegin', `<div class="aviso">Reservada para <b>${esc(x.huesped)}</b> (${esc(x.folio)}) · ${unidad(x.modalidad, x.cantidad)}${x.anticipo ? ` · anticipo ${money(x.anticipo)}` : ''}</div>`);
      $('#modal footer')?.insertAdjacentHTML('beforeend', `<button class="btn pri op" onclick="resEntrada(${x.id})">Entrada de la reservación</button>`);
    }
    return r;
  };
}
