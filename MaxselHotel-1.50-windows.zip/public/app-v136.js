// Maxsel Hotel 1.36 — Interés moratorio que corre mientras no se pague:
// rentas por semana: % por cada DÍA de atraso · rentas por mes: % por cada SEMANA de atraso
'use strict';
if (typeof cHotel === 'function') {
  const _ch = cHotel;
  cHotel = function (...a) {
    const r = _ch(...a);
    const mt = $('#gMt'), mv = $('#gMv'), md = $('#gMd');
    if (mt && mv && md && !$('#gMs')) {
      mt.closest('label').hidden = true; mv.closest('label').hidden = true;
      md.closest('label').insertAdjacentHTML('beforebegin', `<label class="l">Rentas por SEMANA: % por cada día de atraso<input id="gMs" type="number" min="0" step="0.5" value="${esc(CFG.mora_semana_pct || '10')}"></label>
        <label class="l">Rentas por MES: % por cada semana de atraso<input id="gMm" type="number" min="0" step="0.5" value="${esc(CFG.mora_mes_pct || '10')}"></label>
        <label class="l">Máximo de días por semana atrasada (vacío = sin límite)<input id="gMst" type="number" min="0" value="${esc(CFG.mora_semana_tope || '')}"></label>
        <label class="l">Máximo de semanas por mes atrasado (vacío = sin límite)<input id="gMmt" type="number" min="0" value="${esc(CFG.mora_mes_tope || '')}"></label>`);
      const ej = md.closest('.f')?.nextElementSibling;
      if (ej && ej.tagName === 'P') ej.textContent = 'Ejemplo: semana de $2,500 que no se paga: después de los días de gracia se carga 10% ($250) por cada día que siga sin pagarse. Mes de $6,000: se carga 10% ($600) por cada semana de atraso. En cuanto paga, deja de correr.';
    }
    return r;
  };
  const _api = api;
  api = function (metodo, url, body) {
    if (metodo === 'PUT' && url === '/api/config' && body && body.mora_dias !== undefined && $('#gMs')) {
      body = { ...body, mora_tipo: 'porcentaje', mora_semana_pct: String(num('gMs')), mora_mes_pct: String(num('gMm')), mora_semana_tope: val('gMst'), mora_mes_tope: val('gMmt') };
    }
    return _api(metodo, url, body);
  };
}
// Interés manual: el porcentaje de fábrica según la renta (semana o mes)
if (typeof cargoModal === 'function') {
  const _cm = cargoModal;
  cargoModal = async function (eid, ...a) {
    let mod = 'semana'; try { mod = (await GET('/api/estancias/' + eid)).modalidad; } catch { /* nada */ }
    const r = await _cm(eid, ...a);
    const pc = $('#cgPct');
    if (pc) { pc.value = mod === 'mes' ? (CFG.mora_mes_pct || '10') : (CFG.mora_semana_pct || '10'); pc.closest('label').firstChild.textContent = mod === 'mes' ? 'Porcentaje de la renta (por cada semana de atraso)' : 'Porcentaje de la renta (por cada día de atraso)'; cargoSel(); }
    return r;
  };
}
