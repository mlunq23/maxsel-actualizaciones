// Maxsel Hotel 1.38 — Habitaciones agrupadas por unidad de negocio (Hotel, Departamentos, Locales comerciales…):
// en "Todas" cada unidad sale en su propio bloque con su encabezado y cuántas están ocupadas; cada bloque se puede plegar.
'use strict';
{
  const PLEGADAS = new Set();
  try { JSON.parse(localStorage.getItem('maxsel_unidades_plegadas') || '[]').forEach((x) => PLEGADAS.add(x)); } catch { /* nada */ }
  const guardarPleg = () => { try { localStorage.setItem('maxsel_unidades_plegadas', JSON.stringify([...PLEGADAS])); } catch { /* nada */ } };
  document.head.insertAdjacentHTML('beforeend', `<style>
    .uniSec{margin:0 0 18px;border:1px solid var(--line);border-radius:14px;background:var(--panel);box-shadow:var(--shadow);overflow:hidden}
    .uniCab{display:flex;align-items:center;gap:12px;width:100%;padding:12px 16px;border:0;background:var(--panel2);cursor:pointer;text-align:left;color:var(--ink);font:inherit;min-height:52px;border-bottom:1px solid var(--line)}
    .uniSec.plegada .uniCab{border-bottom:0}
    .uniCab .uIco{display:grid;place-items:center;width:36px;height:36px;border-radius:10px;background:var(--panel);border:1px solid var(--line);color:var(--accent);flex:0 0 auto}
    .uniCab h2{margin:0;font:700 17px/1.2 var(--fDisp);flex:1;min-width:0}
    .uniCab .uCta{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end}
    .uniCab .uCta span{font-size:12px;font-weight:700;padding:3px 9px;border-radius:20px;background:var(--panel);border:1px solid var(--line);white-space:nowrap}
    .uniCab .uCta .o{color:var(--ocup)} .uniCab .uCta .l{color:var(--libre)}
    .uniCab .flecha{transition:transform .2s;color:var(--muted)}
    .uniSec.plegada .flecha{transform:rotate(-90deg)}
    .uniCuerpo{padding:14px 16px 2px}
    .uniSec.plegada .uniCuerpo{display:none}
    @media (prefers-reduced-motion:reduce){.uniCab .flecha{transition:none}}
  </style>`);
  const SVG = (d) => `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  const icoUni = (u, clases) => {
    if (/hotel|habitaci/i.test(u)) return SVG('<path d="M3 21h18M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16M9 7h1M14 7h1M9 11h1M14 11h1M10 21v-4h4v4"/>');
    if (/local/i.test(u) || clases.has('local')) return SVG('<path d="M3 9l1.5-5h15L21 9M3 9v11h18V9M3 9h18M9 20v-6h6v6"/>');
    if (/depa|depto/i.test(u) || clases.has('departamento')) return SVG('<path d="M4 21V8l8-5 8 5v13M9 21v-6h6v6M8 10h.01M16 10h.01"/>');
    return SVG('<path d="M3 21h18M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16M9 7h1M14 7h1M9 11h1M14 11h1M10 21v-4h4v4"/>');
  };
  function agrupar() {
    if (vista !== 'hab' || fUni || !TAB) return;
    const floors = [...document.querySelectorAll('#main > .floor')]; if (!floors.length) return;
    const porId = new Map(TAB.habitaciones.map((h) => [h.id, h]));
    const UN = [...new Set([...unidadesCfg(), ...TAB.habitaciones.map(unidadDe)])].filter((u) => TAB.habitaciones.some((h) => unidadDe(h) === u));
    if (UN.length < 2) return;
    const grupos = new Map(UN.map((u) => [u, new Map()]));
    for (const f of floors) for (const b of f.querySelectorAll('.grid > button.tag')) {
      const id = Number(/abrirHab\((\d+)\)/.exec(b.getAttribute('onclick') || '')?.[1]), h = porId.get(id); if (!h) continue;
      const u = unidadDe(h), p = h.piso || ''; if (!grupos.has(u)) grupos.set(u, new Map());
      const g = grupos.get(u); if (!g.has(p)) g.set(p, []); g.get(p).push(b);
    }
    const ancla = floors[0];
    for (const [u, pisos] of grupos) {
      if (!pisos.size) continue;
      const todas = TAB.habitaciones.filter((h) => unidadDe(h) === u), oc = todas.filter((h) => h.estado === 'ocupada').length, li = todas.filter((h) => h.estado === 'libre').length;
      const sec = document.createElement('section'); sec.className = 'uniSec' + (PLEGADAS.has(u) ? ' plegada' : '');
      sec.innerHTML = `<button type="button" class="uniCab" aria-expanded="${!PLEGADAS.has(u)}"><span class="uIco">${icoUni(u, new Set(todas.map((h) => h.clase)))}</span><h2>${esc(u)}</h2>
        <span class="uCta"><span class="o">${oc} ocupada${oc === 1 ? '' : 's'}</span><span class="l">${li} disponible${li === 1 ? '' : 's'}</span><span>${todas.length} en total</span></span>
        <span class="flecha">${SVG('<path d="m6 9 6 6 6-6"/>')}</span></button><div class="uniCuerpo"></div>`;
      const cuerpo = sec.querySelector('.uniCuerpo'), ps = [...pisos.keys()].sort((a, b) => a.localeCompare(b, 'es', { numeric: true }));
      for (const p of ps) {
        const fl = document.createElement('div'); fl.className = 'floor';
        if (ps.length > 1 || p) fl.innerHTML = `<h3>${p ? 'Piso ' + esc(p) : 'Sin piso'}</h3>`;
        const gr = document.createElement('div'); gr.className = 'grid'; pisos.get(p).forEach((b) => gr.appendChild(b)); fl.appendChild(gr); cuerpo.appendChild(fl);
      }
      sec.querySelector('.uniCab').addEventListener('click', () => {
        const pl = sec.classList.toggle('plegada'); if (pl) PLEGADAS.add(u); else PLEGADAS.delete(u);
        sec.querySelector('.uniCab').setAttribute('aria-expanded', String(!pl)); guardarPleg();
      });
      ancla.before(sec);
    }
    floors.forEach((f) => f.remove());
  }
  const _vh = vHab;
  vHab = async function (...a) {
    const r = await _vh.apply(this, a);
    try { agrupar(); } catch (err) { console.error('Agrupar unidades:', err); }
    return r;
  };
}
