// Maxsel Hotel 1.48 — Rentas: ya no se carga un mes/semana doble con "Extender" cuando el sistema ya cargó el periodo solo.
// Si pasa, se ofrece "Cobrar lo que debe" (Pagar) o, solo si de verdad quiere pagar uno MÁS por adelantado, "Agregar otro".
// En la cuenta, los pagos que dicen "Extensión" ahora dicen "Pago de renta (renovación)".
'use strict';
{
  const _api = api;
  api = async function (metodo, url, body) {
    const m = metodo === 'POST' && /^\/api\/estancias\/(\d+)\/extender$/.exec(url);
    if (m && window.EXT_FORZAR) body = { ...body, forzar: 1 };
    try { return await _api(metodo, url, body); }
    catch (err) {
      if (!m || !/ya tiene cargado/.test(err.message || '') || body?.forzar) throw err;
      const id = Number(m[1]);
      const eleccion = await new Promise((ok) => avisoExt(`<h3 style="margin:0 0 8px">Ya tiene cargado su periodo sin pagar</h3><p>${esc(err.message)}</p>`,
        [['Cobrar lo que debe', 'verde', () => ok('pagar')], ['Agregar otro de todos modos', '', () => ok('forzar')], ['Cancelar', '', () => ok('no')]]));
      if (eleccion === 'forzar') return _api(metodo, url, { ...body, forzar: 1 });
      if (eleccion === 'pagar') setTimeout(() => { try { cerrar(); } catch { /* nada */ } pagoModal(id); }, 50);
      const e = new Error('Sin cambios: use "Pagar" para cobrar lo que debe'); e.silencioso = true; throw e;
    }
  };
  // Aviso de la cuenta y nombres de los pagos más claros
  const _ve = verEstancia;
  verEstancia = async function (...a) {
    const r = await _ve(...a);
    try {
      document.querySelectorAll('#modal .aviso.bad').forEach((x) => {
        if (/No se registró la salida a tiempo/.test(x.textContent) && !x.dataset.ok) { x.dataset.ok = 1; x.insertAdjacentHTML('beforeend', ' Para cobrarlo use el botón verde <b>Pagar</b> (no "Extender", que cargaría otro más).'); }
      });
      document.querySelectorAll('#modal td').forEach((td) => { if (td.textContent.trim() === 'Extensión') td.textContent = 'Pago de renta (renovación)'; });
    } catch { /* nada */ }
    return r;
  };
}

// ---- Administrador: cuentas con un mes/semana cobrado doble (de antes de esta versión) ----
{
  let ultima = 0;
  const _vh = vHab;
  vHab = async function (...a) {
    const r = await _vh(...a);
    try {
      if (YO?.rol !== 'admin' || vista !== 'hab' || $('#doblesAviso')) return r;
      if (Date.now() - ultima < 20000 && !vHab.dobles?.length) return r;
      ultima = Date.now(); const l = vHab.dobles = await GET('/api/rentas-dobles');
      if (!l.length || $('#doblesAviso') || vista !== 'hab') return r;
      const ancla = $('#main > .floor, #main > .uniSec, #main .grid'); if (!ancla) return r;
      const div = document.createElement('div'); div.id = 'doblesAviso'; div.className = 'aviso bad'; div.style.cssText = 'margin:0 0 12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap';
      div.innerHTML = `<div style="flex:1;min-width:220px"><b>${l.length} cuenta${l.length > 1 ? 's tienen' : ' tiene'} un mes/semana cobrado doble.</b> El sistema cargó el periodo solo y además se usó "Extender" pagando otro; por eso salen con saldo y recargos.</div><button class="btn rojo" onclick="doblesVer()">Revisar y corregir</button>`;
      (ancla.closest('.uniSec') || ancla.closest('.floor') || ancla).before(div);
    } catch { /* nada */ }
    return r;
  };
}
async function doblesVer() {
  const l = await GET('/api/rentas-dobles');
  if (!l.length) { cerrar(); toast('No hay cuentas con cobro doble'); $('#doblesAviso')?.remove(); return; }
  const U = { semana: 'semana', mes: 'mes', dia: 'noche' };
  modal('Cuentas con cobro doble', `<p style="margin-top:0">En cada una, <b>Corregir</b> quita el ${'periodo'} que el sistema cargó solo (porque ya se pagó con "Extender") y los intereses que salieron por eso. Queda en la bitácora.</p>
    <table><thead><tr><th>Hab.</th><th>Huésped</th><th>Renta</th><th class="n">Debe</th><th class="n">Intereses</th><th></th></tr></thead><tbody>
    ${l.map((x) => `<tr id="dbl${x.id}"><td><b>${esc(x.numero)}</b></td><td>${esc(x.huesped)}</td><td>${money(x.precio)} por ${U[x.modalidad]}</td><td class="n">${money(x.debe)}</td><td class="n">${x.moras_n ? money(x.moras) + ` (${x.moras_n})` : '—'}</td>
      <td><button class="btn sm verde" onclick="doblesCorregir(${x.id})">Corregir</button></td></tr>`).join('')}</tbody></table>`,
  `<button class="btn" onclick="cerrar()">Cerrar</button>${l.length > 1 ? `<button class="btn verde" onclick="doblesTodas(${JSON.stringify(l.map((x) => x.id))})">Corregir todas (${l.length})</button>` : ''}`);
}
async function doblesCorregir(id) {
  const r = await hacer(() => POST(`/api/estancias/${id}/corregir-doble`, {}), 'Cuenta corregida');
  const tr = $('#dbl' + id); if (tr) { tr.style.opacity = .5; tr.querySelector('button').replaceWith(Object.assign(document.createElement('b'), { textContent: '✓ Corregida' })); }
  $('#doblesAviso')?.remove(); vHab.dobles = null;
  return r;
}
async function doblesTodas(ids) {
  let ok = 0; for (const id of ids) { try { await POST(`/api/estancias/${id}/corregir-doble`, {}); ok++; const tr = $('#dbl' + id); if (tr) { tr.style.opacity = .5; tr.lastElementChild.innerHTML = '<b>✓ Corregida</b>'; } } catch (e) { toast(e.message, true); } }
  toast(`Se corrigieron ${ok} cuenta(s)`); $('#doblesAviso')?.remove(); vHab.dobles = null; vHab();
}
