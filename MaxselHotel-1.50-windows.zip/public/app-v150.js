// Maxsel Hotel 1.50 — "Cambiar usuario" sin salir del sistema (se queda en la misma pantalla), y botón fijo para el
// administrador en Habitaciones: "Revisar cobros dobles".
'use strict';
function recientesUsuarios() { try { return JSON.parse(localStorage.getItem('maxsel_usuarios_recientes') || '[]'); } catch { return []; } }
function cambiarUsuario() {
  const rec = recientesUsuarios().filter((u) => u !== YO?.usuario);
  modal('Cambiar usuario', `<p style="margin-top:0">Ahora está <b>${esc(YO?.nombre || '')}</b>. Escriba el usuario y contraseña de quien va a trabajar; el sistema se queda en la misma pantalla.</p>
    ${rec.length ? `<div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:8px">${rec.map((u) => `<button type="button" class="btn sm" onclick="$('#cuU').value='${esc(u)}';$('#cuP').focus()">${esc(u)}</button>`).join('')}</div>` : ''}
    <div class="f"><label class="l">Usuario<input id="cuU" autocomplete="username" autocapitalize="none"></label><label class="l">Contraseña<input id="cuP" type="password" autocomplete="current-password" onkeydown="if(event.key==='Enter')cambiarUsuarioOk()"></label></div>
    <div id="cuErr" class="aviso bad" hidden style="margin-top:8px"></div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="cambiarUsuarioOk()">Cambiar</button>`);
  setTimeout(() => (rec.length ? $('#cuU') : $('#cuU'))?.focus(), 50);
}
async function cambiarUsuarioOk() {
  const u = val('cuU').trim().toLowerCase(), p = $('#cuP').value;
  if (!u || !p) { $('#cuErr').hidden = false; $('#cuErr').textContent = 'Escriba usuario y contraseña'; return; }
  try {
    await POST('/api/login', { usuario: u, password: p }); // la sesión nueva reemplaza a la anterior
    try { const l = [u, ...recientesUsuarios().filter((x) => x !== u)].slice(0, 6); localStorage.setItem('maxsel_usuarios_recientes', JSON.stringify(l)); } catch { /* nada */ }
    cerrar(); TURNO = null; await inicio(); toast('Ahora está trabajando: ' + (YO?.nombre || u));
  } catch (err) { $('#cuErr').hidden = false; $('#cuErr').textContent = err.message; }
}
{
  // Botón en la barra de la izquierda, junto a "Salir"
  const _ma = marco;
  marco = function (...a) {
    const r = _ma(...a);
    try {
      const pie = document.querySelector('aside .pie');
      if (pie && !pie.querySelector('[data-cu]')) {
        const b = document.createElement('button'); b.dataset.cu = '1'; b.textContent = 'Cambiar usuario'; b.onclick = cambiarUsuario;
        pie.querySelector('button')?.before(b);
      }
    } catch { /* nada */ }
    return r;
  };
  // Los avisos de turno usan el cambio rápido
  const _vc = vCaja;
  vCaja = async function (...a) { const r = await _vc(...a); document.querySelectorAll('#turnoDe button[onclick="salir()"]').forEach((b) => b.setAttribute('onclick', 'cambiarUsuario()')); return r; };
  // Administrador: botón fijo en Habitaciones para revisar cobros dobles
  const _vh = vHab;
  vHab = async function (...a) {
    const r = await _vh(...a);
    try {
      if (YO?.rol === 'admin' && vista === 'hab' && !$('#doblesBtn') && !$('#doblesAviso')) {
        const top = $('#main .top'); if (top) top.insertAdjacentHTML('beforeend', `<button id="doblesBtn" class="btn sm" onclick="doblesVer()" title="Cuentas con un mes o semana cobrado doble">Revisar cobros dobles</button>`);
      }
    } catch { /* nada */ }
    return r;
  };
}
