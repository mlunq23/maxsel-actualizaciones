// Maxsel Hotel 1.41 — En la cuenta del huésped el botón dice "Pagar" y se elige qué se paga: renta, interés, multa, cuotas…
'use strict';
{
  let PEND = null; // { id, renta, extras:[{clave,nombre,debe}], total, precio }
  const conceptos = () => {
    if (!PEND) return [];
    const L = [['renta', 'Renta', PEND.renta > 0.009 ? PEND.renta : 0]];
    for (const x of PEND.extras) if (x.debe > 0.009) L.push([x.clave, x.nombre, x.debe]);
    if (L.filter((c) => c[2] > 0.009).length > 1) L.push(['todo', 'Todo lo que debe', PEND.total]);
    return L;
  };
  pagoModal = async function (id, saldo) {
    try { PEND = await GET(`/api/estancias/${id}/pendientes`); PEND.id = id; PEND.precio = Number((await GET('/api/estancias/' + id)).precio) || 0; }
    catch (err) { return toast(err.message, true); }
    const C = conceptos(), debeAlgo = C.some((c) => c[2] > 0.009);
    const ini = C.find((c) => c[0] === 'todo') ? 'todo' : (C.find((c) => c[2] > 0.009) || C[0])[0];
    modal('Pagar', `<div class="lbl" style="margin-bottom:6px">¿Qué va a pagar?</div>
      <div class="seg" id="aCs">${C.map(([k, n, d]) => `<label><input type="radio" name="aC" value="${k}" ${k === ini ? 'checked' : ''} onchange="pagoConcepto()"><span>${esc(n)}</span><small style="font-weight:600;color:${d > 0.009 ? 'var(--ocup)' : 'var(--muted)'}">${d > 0.009 ? 'Debe ' + money(d) : (k === 'renta' ? 'Al corriente (pago adelantado)' : '')}</small></label>`).join('')}</div>
      <div style="display:none"><input type="radio" name="aT" value="abono" checked></div>
      ${debeAlgo ? '' : '<div class="aviso" style="margin-top:8px">No debe nada. Si paga renta, queda como pago adelantado.</div>'}
      <div class="f" style="margin-top:10px"><label class="l">Monto en pesos<input id="aM" type="number" min="0" step="0.01" value="" oninput="usdHint('aF')"></label><div class="l">Método de pago${selPago('aF', null, '', 'aM')}</div></div>`,
    `<button class="btn" onclick="verEstancia(${id})">Volver</button><button class="btn pri" onclick="pagoOk(${id})">Pagar</button>`);
    pagoConcepto();
  };
  window.pagoConcepto = function () {
    const k = document.querySelector('input[name=aC]:checked')?.value, c = conceptos().find((x) => x[0] === k); if (!c) return;
    const m = c[2] > 0.009 ? c[2] : (k === 'renta' ? PEND.precio : 0);
    const el = $('#aM'); if (el) { el.value = m ? m.toFixed(2) : ''; el.dispatchEvent(new Event('input', { bubbles: true })); }
  };
  const nombreDe = () => { const k = document.querySelector('input[name=aC]:checked')?.value; return conceptos().find((x) => x[0] === k)?.[1] || ''; };
  // Lo que se manda al servidor: qué concepto se paga
  const _api = api;
  api = function (metodo, url, body) {
    if (metodo === 'POST' && /^\/api\/estancias\/\d+\/pago$/.test(url) && body && document.querySelector('input[name=aC]:checked')) {
      body = { ...body, concepto: document.querySelector('input[name=aC]:checked').value, nota: 'pago' };
    }
    return _api(metodo, url, body);
  };
  // La ventana de cobro dice qué se está pagando
  if (typeof ventanaCobro === 'function') {
    const _vc = ventanaCobro;
    ventanaCobro = function (o) {
      if (o && /^(Abono a la cuenta|Anticipo)$/.test(o.titulo || '') && document.querySelector('input[name=aC]:checked')) o = { ...o, titulo: 'Pago: ' + nombreDe() };
      return _vc(o);
    };
  }
  // El botón de la cuenta dice "Pagar"
  // Si se acaba de imprimir el comprobante, no taparlo con la cuenta (antes la ventana del ticket se cerraba sola)
  let reciboEn = 0;
  if (typeof imprimirRecibo === 'function') { const _ir = imprimirRecibo; imprimirRecibo = async function (...a) { const r = await _ir(...a); reciboEn = Date.now(); return r; }; }
  const _ve = verEstancia;
  verEstancia = async function (...a) {
    if (Date.now() - reciboEn < 4000 && $('#modal .doc') && !$('#modal').hidden) { reciboEn = 0; return; }
    const r = await _ve(...a);
    document.querySelectorAll('#modal button[onclick^="pagoModal"]').forEach((b) => { b.textContent = 'Pagar'; });
    return r;
  };
}
