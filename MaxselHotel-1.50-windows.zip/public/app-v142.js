// Maxsel Hotel 1.42 — Cuenta del huésped: "Pagar" en verde y "Registrar salida" en rojo, y las demás funciones
// agrupadas en un menú "Más opciones" (Cobros y cargos · Huésped · Otros) en lugar de una fila larga de botones.
'use strict';
{
  document.head.insertAdjacentHTML('beforeend', `<style>
    #modal footer.cuentaPie{display:flex;align-items:center;gap:10px;flex-wrap:wrap;position:relative}
    #modal footer.cuentaPie .esp{flex:1}
    .btn.verde{background:var(--libre);border-color:var(--libre);color:#fff}
    .btn.verde:hover{filter:brightness(1.08)}
    .btn.rojo{background:var(--ocup);border-color:var(--ocup);color:#fff}
    .btn.rojo:hover{filter:brightness(1.08)}
    #modal footer.cuentaPie .btn.verde,#modal footer.cuentaPie .btn.rojo{min-height:46px;padding-inline:22px;font-size:15px}
    .masMenu{position:absolute;left:12px;bottom:calc(100% + 6px);z-index:30;width:min(680px,calc(100vw - 48px));background:var(--panel);border:1px solid var(--line);border-radius:14px;box-shadow:0 12px 36px rgba(0,0,0,.22);padding:12px;display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px}
    .masMenu[hidden]{display:none}
    .masMenu h5{margin:0 0 6px;font:700 11px/1 var(--fBody);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}
    .masMenu .grp{display:flex;flex-direction:column;gap:6px}
    .masMenu .grp .btn{width:100%;justify-content:flex-start;text-align:left;min-height:42px;white-space:normal;line-height:1.2}
    .btn.masBtn{min-height:46px}
  </style>`);
  const GRUPO = [
    ['Cobros y cargos', /^(extModal|cargoModal)/],
    ['Huésped', /^(editarEst|visModal|cambiarModal|diaPagoModal|quitarPeriodo)/],
  ];
  function acomodar() {
    const pie = $('#modal footer'); if (!pie || pie.classList.contains('cuentaPie')) return;
    const bts = [...pie.querySelectorAll(':scope > button')];
    const pagar = bts.find((b) => /^pagoModal/.test(b.getAttribute('onclick') || '')), salir = bts.find((b) => /^salidaModal/.test(b.getAttribute('onclick') || ''));
    if (!pagar && !salir) return; // no es la cuenta de un huésped activo
    pie.classList.add('cuentaPie');
    const grupos = GRUPO.map(([n]) => [n, []]); const otros = [];
    for (const b of bts) {
      if (b === pagar || b === salir) continue;
      const oc = b.getAttribute('onclick') || '', i = GRUPO.findIndex(([, re]) => re.test(oc));
      (i >= 0 ? grupos[i][1] : otros).push(b);
    }
    // "Cambiar día de pago" también queda a la mano en el menú
    const dp = document.querySelector('#dpCuenta button[onclick^="diaPagoModal"]');
    if (dp) { const c = dp.cloneNode(true); c.className = 'btn op'; grupos[1][1].push(c); }
    for (const b of otros) if (/^imprimirEstancia/.test(b.getAttribute('onclick') || '')) b.textContent = 'Imprimir estado de cuenta';
    const todos = [...grupos, ['Otros', otros]].filter(([, l]) => l.length);
    const menu = document.createElement('div'); menu.className = 'masMenu'; menu.hidden = true;
    for (const [n, l] of todos) {
      const g = document.createElement('div'); g.className = 'grp'; g.innerHTML = `<h5>${esc(n)}</h5>`;
      l.forEach((b) => { b.classList.remove('pri'); g.appendChild(b); }); menu.appendChild(g);
    }
    const mas = document.createElement('button'); mas.type = 'button'; mas.className = 'btn masBtn'; mas.setAttribute('aria-expanded', 'false');
    mas.innerHTML = 'Más opciones <span aria-hidden="true">▾</span>';
    mas.onclick = (ev) => { ev.stopPropagation(); menu.hidden = !menu.hidden; mas.setAttribute('aria-expanded', String(!menu.hidden)); };
    menu.addEventListener('click', (ev) => { if (ev.target.closest('button')) menu.hidden = true; });
    document.addEventListener('click', (ev) => { if (!menu.hidden && !menu.contains(ev.target) && ev.target !== mas) { menu.hidden = true; mas.setAttribute('aria-expanded', 'false'); } });
    const esp = document.createElement('span'); esp.className = 'esp';
    pie.innerHTML = '';
    pie.append(menu, mas, esp);
    if (pagar) { pagar.className = 'btn verde op'; pagar.textContent = 'Pagar'; pie.appendChild(pagar); }
    if (salir) { salir.className = 'btn rojo op'; pie.appendChild(salir); }
  }
  const _ve = verEstancia;
  verEstancia = async function (...a) {
    const r = await _ve(...a);
    try { acomodar(); } catch (err) { console.error('Botones de la cuenta:', err); }
    return r;
  };
}
