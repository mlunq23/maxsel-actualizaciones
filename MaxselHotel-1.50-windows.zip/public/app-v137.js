// Maxsel Hotel 1.37 — Configuración ordenada: menú lateral por grupos y la pantalla del hotel dividida en secciones
'use strict';
{
  const ic = (d) => `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  const I = {
    hotel: ic('<path d="M3 21h18M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16M9 7h1M14 7h1M9 11h1M14 11h1M10 21v-4h4v4"/>'),
    reloj: ic('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
    dinero: ic('<rect x="2.5" y="6" width="19" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 9.5v5M18 9.5v5"/>'),
    etiqueta: ic('<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8Z"/><circle cx="7.5" cy="7.5" r="1.3"/>'),
    paleta: ic('<path d="M12 3a9 9 0 1 0 0 18c1.1 0 1.7-.9 1.4-1.9-.4-1.2.4-2.1 1.6-2.1H17a4 4 0 0 0 4-4c0-5.5-4-10-9-10Z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7.5" r="1"/>'),
    cama: ic('<path d="M3 18V6M3 14h18v4M21 14v-2a3 3 0 0 0-3-3h-7v5"/><circle cx="7" cy="11" r="1.6"/>'),
    impresora: ic('<path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M6 14h12v7H6z"/>'),
    documento: ic('<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h6"/>'),
    usuarios: ic('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M21.5 20a6.5 6.5 0 0 0-4-6"/>'),
    celular: ic('<rect x="6" y="2.5" width="12" height="19" rx="2.5"/><path d="M11 18h2"/>'),
    llave: ic('<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M17 6l2 2M15 8l2 2"/>'),
    globo: ic('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 2.5 15.3 0 18M12 3c-2.5 2.7-2.5 15.3 0 18"/>'),
    escudo: ic('<path d="M12 3 4.5 6v6c0 4.5 3.2 8 7.5 9 4.3-1 7.5-4.5 7.5-9V6z"/><path d="m9 12 2 2 4-4"/>'),
    candado: ic('<rect x="4.5" y="10.5" width="15" height="10" rx="2"/><path d="M8 10.5V7a4 4 0 0 1 8 0v3.5"/>'),
    lista: ic('<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>'),
    otro: ic('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/>'),
  };
  // [clave, nombre, ícono, descripción]
  const GRUPOS = [
    ['El hotel', [
      ['hotel:datos', 'Datos del hotel y ticket', 'hotel', 'Nombre, dirección y teléfono que salen en los tickets, unidades de negocio y módulos.'],
      ['hotel:rentas', 'Rentas y horarios', 'reloj', 'Horas de salida de cada tipo de renta y qué pasa cuando no se registra la salida.'],
      ['hotel:cobros', 'Cobros, multas e intereses', 'dinero', 'Servicio de limpieza, mascotas, visitas, multas, interés moratorio y seguridad de la caja.'],
      ['hotel:descuentos', 'Descuentos y depósitos', 'etiqueta', 'Descuento máximo al rentar, limpieza y plazo para reclamar el depósito en garantía.'],
      ['hotel:colores', 'Colores de la pantalla', 'paleta', 'Color de cada habitación según su estado y tipo de renta, y cuándo avisar.'],
      ['habs', 'Habitaciones', 'cama', 'Alta de habitaciones, departamentos y locales con sus precios.'],
    ]],
    ['Caja e impresión', [
      ['impresora', 'Impresora y caja', 'impresora', 'Impresora de tickets, cajón de dinero y tipo de cambio.'],
      ['contrato', 'Contratos y gastos', 'documento', 'Datos del arrendador, texto del contrato y clasificación de gastos.'],
    ]],
    ['Personal', [
      ['usuarios', 'Usuarios y permisos', 'usuarios', 'Quién entra al sistema y qué puede hacer cada quien.'],
      ['mant', 'Apps del personal (QR)', 'celular', 'Apps de limpieza y mantenimiento para el celular de los empleados.'],
      ['pass', 'Mi contraseña', 'llave', 'Cambiar la contraseña con la que usted entra.'],
    ]],
    ['Sistema', [
      ['remoto', 'Monitoreo remoto', 'globo', 'Ver y usar el sistema desde el celular o desde fuera del hotel.'],
      ['resp', 'Respaldos y licencia', 'escudo', 'Copias de seguridad de la información, licencia y actualizaciones.'],
      ['aviso', 'Aviso de privacidad', 'candado', 'Texto del aviso de privacidad que firma el huésped.'],
      ['bita', 'Bitácora', 'lista', 'Quién hizo qué y cuándo.'],
    ]],
  ];
  // Qué tarjetas de la pantalla del hotel van en cada sección (por su título)
  const SECCION_DE = {
    'Datos del hotel': 'datos', 'Unidades de negocio': 'datos', 'Módulos': 'datos',
    'Tipos de renta': 'rentas', 'Check out sin registrar': 'rentas',
    'Multas, cuotas e intereses': 'cobros', 'Seguridad de caja': 'cobros',
    'Descuentos al rentar': 'descuentos', 'Depósito en garantía': 'descuentos',
    'Colores de las habitaciones': 'colores',
  };
  let SUB = 'datos';
  try { SUB = localStorage.getItem('maxsel_cfg_sub') || 'datos'; } catch { /* nada */ }

  document.head.insertAdjacentHTML('beforeend', `<style id="cfgEstilo">
    .cfgL{display:grid;grid-template-columns:260px minmax(0,1fr);gap:20px;align-items:start}
    .cfgN{position:sticky;top:12px;background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:10px;box-shadow:var(--shadow);max-height:calc(100vh - 24px);overflow:auto}
    .cfgN h4{margin:12px 10px 6px;font:700 11px/1 var(--fBody);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}
    .cfgN h4:first-child{margin-top:4px}
    .cfgN button{display:flex;align-items:center;gap:10px;width:100%;min-height:44px;padding:8px 10px;border:0;border-radius:10px;background:none;color:var(--ink);font:600 14px/1.25 var(--fBody);text-align:left;cursor:pointer;transition:background .15s}
    .cfgN button:hover{background:var(--panel2)}
    .cfgN button svg{flex:0 0 auto;color:var(--muted)}
    .cfgN button.on{background:var(--accent);color:var(--accentInk)}
    .cfgN button.on svg{color:var(--accentInk)}
    .cfgN button:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
    .cfgH{display:flex;gap:14px;align-items:center;margin:0 0 14px;padding:16px 18px;background:var(--panel);border:1px solid var(--line);border-left:5px solid var(--accent);border-radius:14px;box-shadow:var(--shadow)}
    .cfgH .ico{display:grid;place-items:center;width:44px;height:44px;border-radius:12px;background:var(--panel2);color:var(--accent);flex:0 0 auto}
    .cfgH .ico svg{width:24px;height:24px}
    .cfgH h2{margin:0;font:700 20px/1.2 var(--fDisp)}
    .cfgH p{margin:3px 0 0;color:var(--muted);font-size:14px}
    .cfgL #cfgc .stack{display:flex;flex-direction:column;gap:14px}
    .cfgL #cfgc .card{box-shadow:var(--shadow);border-radius:14px;padding:18px 20px}
    .cfgL #cfgc .card>h2{font:700 16px/1.3 var(--fDisp);margin:0 0 10px;padding-bottom:10px;border-bottom:1px solid var(--line)}
    .cfgL #cfgc .card>.lbl{margin-top:14px;padding-top:12px;border-top:1px dashed var(--line);font-weight:700;color:var(--ink);font-size:14px}
    .cfgL #cfgc .cfgGuardar{order:50;position:sticky;bottom:12px;z-index:5;display:flex;justify-content:flex-end;padding:10px 14px;background:var(--panel);border:1px solid var(--line);border-radius:14px;box-shadow:var(--shadow)}
    .cfgL #cfgc .cfgGuardar .btn{min-height:44px;padding-inline:26px}
    .cfgL #cfgc .cfgGuardar::before{content:"Los cambios de esta pantalla se guardan con este botón";flex:1;align-self:center;color:var(--muted);font-size:13px}
    @media (max-width:900px){
      .cfgL{grid-template-columns:1fr}
      .cfgN{position:static;display:flex;gap:6px;overflow-x:auto;padding:8px;max-height:none;scrollbar-width:thin}
      .cfgN h4{display:none}
      .cfgN button{width:auto;white-space:nowrap;flex:0 0 auto;border:1px solid var(--line)}
      .cfgL #cfgc .cfgGuardar::before{content:none}
    }
  </style>`);

  function filtrarHotel() {
    const st = $('#cfgc .stack'); if (!st || cfgTab !== 'hotel') return;
    for (const el of st.children) {
      if (el.classList.contains('card')) {
        const t = el.querySelector('h2')?.textContent.trim() || '';
        const sec = SECCION_DE[t] || (el.id === 'dpCard' ? 'descuentos' : 'datos');
        el.hidden = sec !== SUB;
      } else if (el.querySelector('button') && /Guardar/.test(el.textContent)) {
        el.classList.add('cfgGuardar'); el.hidden = SUB === 'descuentos';
      }
    }
  }
  function armar() {
    const tabs = $('#main > .tabs'), cfgc = $('#cfgc'); if (!tabs || !cfgc || $('#main .cfgL')) return;
    const hay = new Set([...tabs.querySelectorAll('button')].map((b) => /cfgTab='(\w+)'/.exec(b.getAttribute('onclick') || '')?.[1]).filter(Boolean));
    const conocidas = new Set(GRUPOS.flatMap(([, it]) => it.map(([k]) => k.split(':')[0])));
    const otras = [...tabs.querySelectorAll('button')].map((b) => [/cfgTab='(\w+)'/.exec(b.getAttribute('onclick') || '')?.[1], b.textContent.trim()]).filter(([k]) => k && !conocidas.has(k));
    const actual = cfgTab === 'hotel' ? 'hotel:' + SUB : cfgTab;
    let nav = '', info = null;
    for (const [g, items] of [...GRUPOS, ...(otras.length ? [['Otros', otras.map(([k, n]) => [k, n, 'otro', ''])]] : [])]) {
      const vis = items.filter(([k]) => hay.has(k.split(':')[0])); if (!vis.length) continue;
      nav += `<h4>${esc(g)}</h4>` + vis.map(([k, n, i, d]) => { if (k === actual) info = [n, i, d]; return `<button type="button" class="${k === actual ? 'on' : ''}" data-k="${k}">${I[i] || I.otro}<span>${esc(n)}</span></button>`; }).join('');
    }
    tabs.hidden = true;
    const lay = document.createElement('div'); lay.className = 'cfgL';
    lay.innerHTML = `<nav class="cfgN" aria-label="Secciones de configuración">${nav}</nav><div style="min-width:0"><div class="cfgH"><div class="ico">${I[info?.[1]] || I.otro}</div><div><h2>${esc(info?.[0] || '')}</h2>${info?.[2] ? `<p>${esc(info[2])}</p>` : ''}</div></div></div>`;
    cfgc.before(lay); lay.lastElementChild.appendChild(cfgc);
    lay.querySelector('.cfgN').addEventListener('click', (ev) => {
      const b = ev.target.closest('button[data-k]'); if (!b) return;
      const [tab, sub] = b.dataset.k.split(':');
      if (sub) { SUB = sub; try { localStorage.setItem('maxsel_cfg_sub', sub); } catch { /* nada */ } }
      if (tab === 'hotel' && cfgTab === 'hotel') {
        // Mismo formulario: solo se muestra otra parte (lo escrito no se pierde)
        lay.querySelectorAll('.cfgN button').forEach((x) => x.classList.toggle('on', x === b));
        const it = GRUPOS[0][1].find(([k]) => k === b.dataset.k);
        lay.querySelector('.cfgH').innerHTML = `<div class="ico">${I[it[2]]}</div><div><h2>${esc(it[1])}</h2><p>${esc(it[3])}</p></div>`;
        filtrarHotel(); window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
      cfgTab = tab; vCfg();
    });
    filtrarHotel();
    // Algunas tarjetas llegan después (se cargan aparte): se acomodan solas
    new MutationObserver(() => filtrarHotel()).observe(cfgc, { childList: true, subtree: false });
    const st = $('#cfgc .stack'); if (st) new MutationObserver(() => filtrarHotel()).observe(st, { childList: true });
  }
  const _vc = vCfg;
  vCfg = async function (...a) {
    const r = await _vc(...a);
    try { armar(); setTimeout(() => { try { armar(); filtrarHotel(); } catch { /* nada */ } }, 300); } catch (err) { console.error('Configuración:', err); }
    return r;
  };
}
