// Maxsel Hotel 1.47 — Turnos claros: cada turno dice de quién es y desde cuándo está abierto.
// Si el turno viene de antes (otro día o más de 13 horas), se avisa: casi siempre es que se entró con el usuario de otra
// persona o que no se cerró el turno anterior. También se avisa antes de cerrar un turno en ceros cuando sí hubo cobros.
'use strict';
{
  const horasDesde = (f) => Math.max(0, (Date.now() - aF(f).getTime()) / 3600000);
  const esViejo = (t) => t && (horasDesde(t.apertura) > 13 || String(t.apertura).slice(0, 10) !== hoyISO());
  const hace = (h) => (h < 1 ? 'hace menos de 1 hora' : h < 48 ? `hace ${Math.floor(h)} hora${Math.floor(h) === 1 ? '' : 's'}` : `hace ${Math.floor(h / 24)} días`);

  // ---- Caja: encabezado del turno ----
  const _vc = vCaja;
  vCaja = async function (...a) {
    const r = await _vc(...a);
    try {
      const t = TURNO?.turno, main = $('#main'); if (!t || !main || $('#turnoDe')) return r;
      const h = horasDesde(t.apertura), viejo = esViejo(t);
      const box = document.createElement('div'); box.id = 'turnoDe';
      box.className = 'aviso' + (viejo ? ' bad' : '');
      box.style.cssText = 'margin:0 0 12px;display:flex;gap:12px;align-items:center;flex-wrap:wrap';
      box.innerHTML = `<div style="flex:1;min-width:220px"><b style="font-size:16px">Turno #${t.id} de ${esc(YO?.nombre || t.usuario || '')}</b> · abierto el ${fechaTk(t.apertura)} (${hace(h)})
        ${viejo ? `<div style="margin-top:4px">Este turno <b>viene de antes</b>: aquí está todo lo que se ha cobrado desde esa hora. Si usted acaba de entrar a trabajar, <b>no lo cierre en ceros</b>: la persona del turno anterior debe hacer su corte con el dinero que entregó, y usted entrar con <b>su propio usuario</b>.</div>` : ''}</div>
        <button class="btn" onclick="salir()">Cambiar de usuario</button>`;
      const kp = main.querySelector('.kpis'); (kp || main.firstElementChild)?.before(box);
    } catch { /* nada */ }
    return r;
  };

  // ---- Barra lateral: desde cuándo está abierta la caja ----
  const _pt = pintarTurno;
  pintarTurno = async function (...a) {
    const r = await _pt(...a);
    try {
      const t = TURNO?.turno, b = $('#turnoBar .tb.on small');
      if (t && b) b.textContent = 'Desde ' + (String(t.apertura).slice(0, 10) === hoyISO() ? 'hoy ' : fechaTk(t.apertura).split(' ')[0] + ' ') + soloHora(t.apertura);
      // Al entrar: si su turno viene de antes, avisar una vez
      if (t && esViejo(t) && pintarTurno.avisado !== t.id && puede('caja')) {
        pintarTurno.avisado = t.id;
        setTimeout(() => { if ($('#modal').hidden) modal('Su turno sigue abierto desde antes', `<div class="aviso bad">El turno <b>#${t.id}</b> de <b>${esc(YO?.nombre || '')}</b> está abierto desde el <b>${fechaTk(t.apertura)}</b> (${hace(horasDesde(t.apertura))}).</div>
          <p>Todo lo que se cobre ahora se suma a ese turno. Si es de un turno anterior, <b>haga primero el corte</b> contando el dinero de ese turno y luego abra uno nuevo. Si usted no es <b>${esc(YO?.nombre || '')}</b>, salga y entre con su propio usuario.</p>`,
        '<button class="btn" onclick="salir()">Cambiar de usuario</button><button class="btn" onclick="cerrar();ir(\'caja\')">Ir a Caja</button><button class="btn pri" onclick="cerrar()">Entendido</button>'); }, 600);
      }
    } catch { /* nada */ }
    return r;
  };

  // ---- Abrir turno cuando ya hay uno abierto: explicarlo en vez de solo un error ----
  const _at = abrirTurno;
  abrirTurno = function (...a) {
    if (TURNO?.turno) { ir('caja'); toast(`Ya tiene abierto el turno #${TURNO.turno.id} (desde ${fechaTk(TURNO.turno.apertura)}). Para empezar uno nuevo primero haga el corte.`, true); return; }
    return _at(...a);
  };

  // ---- Cerrar en ceros cuando sí hubo cobros: confirmar ----
  const _ct = cerrarTurnoOk;
  let confirmado = false;
  cerrarTurnoOk = async function (...a) {
    const tot = ['cMx', 'cUs', 'cTa', 'cTr'].reduce((s, k) => s + (Number(val(k)) || 0), 0), e = TURNO?.esperado, cob = Number(TURNO?.cobrado) || 0;
    const debe = e ? (e.mxn + e.tarjeta + e.transferencia) : cob;
    if (!confirmado && tot < 0.01 && debe > 0.01) {
      const zona = $('#modal footer'); if (zona && !$('#cerosAviso')) zona.insertAdjacentHTML('beforebegin', `<div id="cerosAviso" class="aviso bad" style="margin:0 16px 10px">Va a cerrar en <b>ceros</b>, pero en este turno se cobraron <b>${money(cob)}</b>. Quedará como <b>faltante</b> en el corte. Si es correcto, toque otra vez "Cerrar turno e imprimir corte".</div>`);
      confirmado = true; setTimeout(() => { confirmado = false; }, 30000);
      return;
    }
    confirmado = false;
    return _ct(...a);
  };
}
