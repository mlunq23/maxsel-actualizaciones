// Maxsel Hotel 1.45 — "Cancelar renta" (solo administrador): cierra la renta aunque deba, libera la habitación a limpieza
// y perdona el adeudo con un motivo que queda en la bitácora.
'use strict';
{
  const _ve = verEstancia;
  verEstancia = async function (id, ...a) {
    const r = await _ve(id, ...a);
    try {
      const menu = $('#modal footer.cuentaPie .masMenu');
      if (YO?.rol === 'admin' && menu && !menu.querySelector('[data-cancelar]')) {
        let g = [...menu.querySelectorAll('.grp')].find((x) => x.querySelector('h5')?.textContent === 'Otros');
        if (!g) { g = document.createElement('div'); g.className = 'grp'; g.innerHTML = '<h5>Otros</h5>'; menu.appendChild(g); }
        const b = document.createElement('button'); b.type = 'button'; b.className = 'btn bad'; b.dataset.cancelar = '1'; b.textContent = 'Cancelar renta (administrador)';
        b.onclick = () => cancelarRenta(id); g.appendChild(b);
      }
      // Rentas canceladas: se ve claro en la cuenta
      const e = await GET('/api/estancias/' + id);
      if (e.cancelada && !$('#avisoCancelada')) $('#modal .mbody')?.insertAdjacentHTML('afterbegin', `<div id="avisoCancelada" class="aviso bad" style="margin-bottom:10px"><b>Renta cancelada</b> el ${fdt(e.cancelada)}${e.condonado > 0 ? ` · se perdonó un adeudo de ${money(e.condonado)}` : ''}<br>Motivo: ${esc(e.cancel_motivo || '')}</div>`);
    } catch { /* nada */ }
    return r;
  };
}
async function cancelarRenta(id) {
  const e = await GET('/api/estancias/' + id);
  modal('Cancelar renta', `<div class="aviso bad"><b>${esc(e.huesped)}</b> · ${CLASE[e.habitacion?.clase] || 'Habitación'} ${esc(e.habitacion?.numero || '')}</div>
    <p>La renta se cierra y la habitación pasa a <b>limpieza</b>.${e.saldo > 0.009 ? ` Lo que debe (<b>${money(e.saldo)}</b>) <b>se perdona</b> y ya no aparece como adeudo.` : ''} Los pagos que ya hizo se quedan en la caja (si hay que devolver alguno, cancélelo en Pagos antes).</p>
    ${e.deposito_saldo > 0.009 ? `<div class="aviso">Tiene un depósito en garantía de <b>${money(e.deposito_saldo)}</b>. Después de cancelar, devuélvalo o reténgalo desde su cuenta.</div>` : ''}
    <label class="l">Motivo (obligatorio)<input id="crM" placeholder="Ej. se registró por error / se fue sin pagar"></label>`,
  `<button class="btn" onclick="verEstancia(${id})">Volver</button><button class="btn rojo" onclick="cancelarRentaOk(${id})">Cancelar la renta</button>`);
  setTimeout(() => $('#crM')?.focus(), 50);
}
async function cancelarRentaOk(id) {
  if (!val('crM').trim()) return toast('Escriba el motivo', true);
  const r = await hacer(() => POST(`/api/estancias/${id}/cancelar`, { motivo: val('crM') }), 'Renta cancelada');
  if (r?.perdonado > 0) toast('Se perdonó un adeudo de ' + money(r.perdonado));
  cerrar(); vHab();
}
