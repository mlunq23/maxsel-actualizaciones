// Maxsel Hotel 1.43 — Ventana de cada habitación resumida: arriba solo lo importante (huésped, hasta cuándo está pagado,
// día de pago y cuánto debe de cada cosa); lo demás (datos, cargos, pagos, depósito, contrato…) va en secciones plegadas.
// Botones: primero "Pagar", luego "Registrar salida" y "Más opciones" al final.
'use strict';
{
  document.head.insertAdjacentHTML('beforeend', `<style>
    .resCta{border:1px solid var(--line);border-radius:14px;padding:14px 16px;background:var(--panel2);display:flex;flex-direction:column;gap:12px;margin-bottom:12px}
    .resCta .quien{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
    .resCta .quien b{font:700 20px/1.2 var(--fDisp)}
    .resCta .tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
    .resCta .tile{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:10px 12px}
    .resCta .tile .lbl{margin:0 0 2px}
    .resCta .tile b{font-size:16px}
    .resCta .tile.saldo b{font-size:22px}
    .resCta .desglose{display:flex;gap:6px;flex-wrap:wrap;margin-top:4px}
    .resCta .desglose span{font-size:12px;font-weight:700;padding:2px 8px;border-radius:20px;background:var(--ocupBg);color:var(--ocup)}
    details.secCta{border:1px solid var(--line);border-radius:12px;margin-bottom:8px;background:var(--panel)}
    details.secCta>summary{list-style:none;cursor:pointer;padding:12px 14px;display:flex;align-items:center;gap:8px;font-weight:700;min-height:44px}
    details.secCta>summary::-webkit-details-marker{display:none}
    details.secCta>summary::after{content:"";margin-left:auto;width:9px;height:9px;border-right:2px solid var(--muted);border-bottom:2px solid var(--muted);transform:rotate(45deg);transition:transform .2s}
    details.secCta[open]>summary::after{transform:rotate(-135deg)}
    details.secCta>summary .cnt{font-size:12px;font-weight:700;color:var(--muted);background:var(--panel2);border:1px solid var(--line);border-radius:20px;padding:1px 8px}
    details.secCta>.cont{padding:0 14px 12px;display:flex;flex-direction:column;gap:10px}
    #modal footer.cuentaPie .masMenu{left:auto;right:12px}
    @media (max-width:560px){#modal footer.cuentaPie{gap:8px;flex-wrap:nowrap}#modal footer.cuentaPie .esp{display:none}#modal footer.cuentaPie .btn{flex:1 1 auto;padding-inline:10px;min-width:0}#modal footer.cuentaPie .masBtn .txt{display:none}#modal footer.cuentaPie .masBtn span.corto{display:inline}}
    #modal footer.cuentaPie .masBtn .corto{display:none}
    @media (prefers-reduced-motion:reduce){details.secCta>summary::after{transition:none}}
  </style>`);
  const ABIERTAS = new Set(); // secciones que el usuario abrió (se quedan abiertas al volver a la cuenta)
  const lblDe = (el) => (el.querySelector(':scope > .lbl, :scope > .row > .lbl, :scope > .row > div > .lbl')?.textContent || '').trim();
  function seccion(clave, titulo, cnt, nodos) {
    nodos = nodos.filter(Boolean); if (!nodos.length) return null;
    const d = document.createElement('details'); d.className = 'secCta'; d.open = ABIERTAS.has(clave);
    d.innerHTML = `<summary><span>${esc(titulo)}</span>${cnt !== null && cnt !== undefined ? `<span class="cnt">${esc(String(cnt))}</span>` : ''}</summary><div class="cont"></div>`;
    nodos.forEach((n) => d.querySelector('.cont').appendChild(n));
    d.addEventListener('toggle', () => { if (d.open) ABIERTAS.add(clave); else ABIERTAS.delete(clave); });
    return d;
  }
  async function resumir(id) {
    const mb = $('#modal .mbody'); if (!mb || mb.dataset.resumida || !mb.querySelector(':scope > .kv')) return;
    mb.dataset.resumida = '1';
    let e = null, pend = null;
    try { [e, pend] = await Promise.all([GET('/api/estancias/' + id), GET(`/api/estancias/${id}/pendientes`).catch(() => null)]); } catch { return; }
    const hijos = [...mb.children], buscar = (t) => hijos.find((h) => lblDe(h).startsWith(t));
    const kv = mb.querySelector(':scope > .kv'), pill = kv.previousElementSibling?.querySelector('.pill') ? kv.previousElementSibling : null;
    const consumos = buscar('Consumos'), pagos = buscar('Pagos'), visit = buscar('Visitantes'), hist = buscar('Historial');
    const dep = hijos.find((h) => /Depósito en garantía/.test(lblDe(h))), contr = hijos.find((h) => h.classList.contains('solo-contratos'));
    const calc = mb.querySelector(':scope > .calc'), dpc = $('#dpCuenta'), quitar = $('#quitarPer');
    const largo = e.modalidad === 'semana' || e.modalidad === 'mes';
    const dp = e.modalidad === 'semana' && e.dia_pago !== null && e.dia_pago !== undefined && typeof DIAS_PAGO !== 'undefined' ? 'Cada ' + DIAS_PAGO[Number(e.dia_pago)].toLowerCase() : '';
    const desglose = [];
    if (pend && e.saldo > 0.009) {
      if (pend.renta > 0.009) desglose.push('Renta ' + money(pend.renta));
      for (const x of pend.extras) if (x.debe > 0.009) desglose.push(x.nombre + ' ' + money(x.debe));
    }
    const nVis = visit ? visit.querySelectorAll('button').length : 0;
    const res = document.createElement('div'); res.className = 'resCta';
    res.innerHTML = `<div class="quien"><b>${esc(e.huesped)}</b>${pill ? pill.innerHTML : ''}${e.personas > 1 ? `<span class="sub">${e.personas} personas</span>` : ''}${nVis ? `<span class="pill">${nVis} visitante${nVis > 1 ? 's' : ''} dentro</span>` : ''}</div>
      <div class="tiles">
        ${e.activa ? `<div class="tile"><div class="lbl">${largo ? (e.saldo > 0.009 ? 'Renta cargada hasta' : 'Pagado hasta') : 'Check out'}</div><b>${fdt(e.salida_prevista)}</b></div>` : `<div class="tile"><div class="lbl">Salió</div><b>${fdt(e.salida_real)}</b></div>`}
        ${dp ? `<div class="tile"><div class="lbl">Día de pago</div><b>${dp}</b></div>` : ''}
        <div class="tile saldo"><div class="lbl">${e.saldo > 0.009 ? 'Debe' : 'Saldo'}</div><b style="color:${e.saldo > 0.009 ? 'var(--ocup)' : 'var(--libre)'}">${e.saldo > 0.009 ? money(e.saldo) : 'Al corriente'}</b>${desglose.length > 1 ? `<div class="desglose">${desglose.map((x) => `<span>${esc(x)}</span>`).join('')}</div>` : ''}</div>
      </div>`;
    const nCargos = e.cargos?.length || 0, nPagos = (e.pagos || []).filter((p) => !p.venta_id).length;
    const secs = [
      seccion('datos', 'Datos del huésped', null, [kv]),
      seccion('cargos', 'Cargos, multas y cuotas', nCargos, [consumos]),
      seccion('pagos', 'Pagos', nPagos, [pagos]),
      nVis ? seccion('visit', 'Visitantes', nVis, [visit]) : (visit && visit.remove(), null),
      seccion('dep', 'Depósito y contrato', null, [dep, contr]),
      seccion('hist', 'Historial y ajustes', null, [hist, quitar]),
    ].filter(Boolean);
    [pill, calc, dpc].forEach((n) => n && n.remove());
    mb.prepend(res, ...secs);
  }
  function botones() {
    const pie = $('#modal footer.cuentaPie'); if (!pie || pie.dataset.orden) return;
    pie.dataset.orden = '1';
    const salir = pie.querySelector('button[onclick^="salidaModal"]'), pagar = pie.querySelector('button[onclick^="pagoModal"]');
    // 1.44: a la izquierda "Registrar salida" (rojo); a la derecha "Más opciones" y al final "Pagar" (verde)
    const esp = pie.querySelector('.esp'), mas = pie.querySelector('.masBtn');
    if (mas) mas.innerHTML = '<span class="txt">Más opciones</span><span class="corto">Más</span> ▾';
    if (salir) pie.prepend(salir);
    if (esp) pie.appendChild(esp); if (mas) pie.appendChild(mas); if (pagar) pie.appendChild(pagar);
  }
  const _ve = verEstancia;
  verEstancia = async function (id, ...a) {
    const r = await _ve(id, ...a);
    try { botones(); await resumir(id); } catch (err) { console.error('Resumen de la cuenta:', err); }
    return r;
  };
}
