// Maxsel Hotel 1.8 — Logo en el ticket y leyenda de Maxsel en cada ticket
'use strict';
// Leyenda del sistema: sale siempre al final de cada ticket
const LEYENDA_MAXSEL = ['Sistema Punto de Venta MAXSEL', 'Hoteles · Restaurantes · Tiendas · Estacionamientos'];
const ANCHO_LOGO = { chico: 0.45, mediano: 0.7, grande: 1 };
const logoPx = () => Math.floor(((CFG.ticket_ancho === '58' ? 384 : 576) * 0.66 * (ANCHO_LOGO[CFG.ticket_logo_ancho] || 0.7)) / 8) * 8;
let LOGO_CACHE = { key: '', ops: null };
async function logoOps() {
  if (!CFG.ticket_logo) return [];
  const key = CFG.ticket_logo.length + '|' + logoPx();
  if (LOGO_CACHE.key === key) return LOGO_CACHE.ops;
  try {
    const img = await new Promise((ok, mal) => { const i = new Image(); i.onload = () => ok(i); i.onerror = mal; i.src = CFG.ticket_logo; });
    const w = logoPx(), h = Math.min(380, Math.round(img.height * w / img.width)), c = document.createElement('canvas');
    c.width = w; c.height = h; const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); x.drawImage(img, 0, 0, w, h);
    const px = x.getImageData(0, 0, w, h).data, bpr = w / 8, bits = new Uint8Array(bpr * h);
    for (let y = 0; y < h; y++) for (let i = 0; i < w; i++) { const k = (y * w + i) * 4; if (px[k + 3] > 60 && px[k] * 0.3 + px[k + 1] * 0.59 + px[k + 2] * 0.11 < 150) bits[y * bpr + (i >> 3)] |= 0x80 >> (i & 7); }
    let bin = ''; bits.forEach((b) => (bin += String.fromCharCode(b)));
    LOGO_CACHE = { key, ops: [['align', 'center'], ['img', bpr, h, btoa(bin)], ['align', 'left']] };
  } catch { LOGO_CACHE = { key, ops: [] }; }
  return LOGO_CACHE.ops;
}
// Al final del ticket va el logo de Maxsel (chico), la leyenda y los datos de contacto de Maxsel
const contactoMaxsel = () => String(CFG.maxsel_contacto || '').split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
const leyendaHTML = () => `<div class="tk-ley"><img src="logo.png" alt="Maxsel" class="tk-ley-logo"></div>`; // 1.39: solo el logo centrado
let LOGO_MAXSEL_OPS = null;
async function logoMaxselOps() {
  const lw = CFG.ticket_ancho === '58' ? 144 : 192, w = CFG.ticket_ancho === '58' ? 384 : 512, key = lw + 'c' + w; // chico y discreto; 1.39: centrado dentro del ancho del papel (algunas impresoras no centran imágenes)
  if (LOGO_MAXSEL_OPS && LOGO_MAXSEL_OPS.key === key) return LOGO_MAXSEL_OPS.ops;
  try {
    const img = await new Promise((ok, mal) => { const i = new Image(); i.onload = () => ok(i); i.onerror = mal; i.src = 'logo.png'; });
    const h = Math.round(img.height * lw / img.width), c = document.createElement('canvas'); c.width = w; c.height = h;
    const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); x.drawImage(img, Math.round((w - lw) / 2), 0, lw, h);
    const px = x.getImageData(0, 0, w, h).data, bpr = w / 8, bits = new Uint8Array(bpr * h);
    for (let y = 0; y < h; y++) for (let i = 0; i < w; i++) { const k = (y * w + i) * 4; if (px[k] * 0.3 + px[k + 1] * 0.59 + px[k + 2] * 0.11 < 170) bits[y * bpr + (i >> 3)] |= 0x80 >> (i & 7); }
    let bin = ''; bits.forEach((b) => (bin += String.fromCharCode(b)));
    LOGO_MAXSEL_OPS = { key, ops: [['img', bpr, h, btoa(bin)]] };
  } catch { LOGO_MAXSEL_OPS = { key, ops: [] }; }
  return LOGO_MAXSEL_OPS.ops;
}
const leyendaOps = async () => [['align', 'center'], ['feed', 1], ...(await logoMaxselOps()), ['align', 'left'], ['feed', 2]]; // 1.39: al final solo el logo de Maxsel centrado, sin letras
// Todos los tickets (no los documentos tamaño carta) llevan el logo arriba y la leyenda abajo
{
  const _doc = imprimirDoc;
  imprimirDoc = function (html, formato, titulo, ops) {
    if (formato === 'carta') return _doc(html, formato, titulo, ops);
    const h2 = `${CFG.ticket_logo ? `<div class="tk-logo"><img src="${CFG.ticket_logo}" alt="" style="width:${Math.round((ANCHO_LOGO[CFG.ticket_logo_ancho] || 0.7) * 66)}%"></div>` : ''}${html}${leyendaHTML()}`;
    const o2 = ops ? async () => [...(await logoOps()), ...(typeof ops === 'function' ? await ops() : ops), ...(await leyendaOps())] : ops;
    return _doc(h2, formato, titulo, o2);
  };
}
// Configuración → Impresora y caja: logo del ticket
{
  const _ci = cImpresora;
  cImpresora = async function () {
    await _ci();
    $('#cfgc .stack')?.insertAdjacentHTML('afterbegin', `<div class="card"><h2>Logo y leyenda del ticket</h2>
      <div class="row" style="gap:18px;align-items:flex-start;flex-wrap:wrap"><div class="tk-prevlogo" id="lgPrev">${CFG.ticket_logo ? `<img src="${CFG.ticket_logo}" alt="Logo">` : '<span class="sub">Sin logo</span>'}</div>
        <div class="stack" style="gap:8px;flex:1;min-width:240px"><label class="btn pri" style="cursor:pointer;justify-content:center">Elegir logo (PNG o JPG)<input type="file" accept="image/*" hidden onchange="logoSubir(this.files[0])"></label>
          ${CFG.ticket_logo ? '<button class="btn bad" onclick="confirmar(this,logoQuitar)">Quitar logo</button>' : ''}
          <label class="l">Tamaño en el ticket<select id="lgA" onchange="logoAncho()"><option value="chico">Chico</option><option value="mediano">Mediano</option><option value="grande">Grande</option></select></label>
          <button class="btn" onclick="logoPrueba()">Imprimir ticket de prueba</button></div></div>
      <p class="sub">Se imprime en blanco y negro arriba de cada ticket. Funciona mejor un logo con fondo blanco y letras oscuras.</p>
      <div class="aviso">Al final de cada ticket se imprime el logo de Maxsel centrado.</div></div>
      ${YO.rol === 'admin' ? `<div class="card"><h2>Datos de Maxsel al final del ticket</h2>
      <div class="aviso">El logo de Maxsel se imprime siempre al final de cada ticket.</div>
      <label class="l" style="margin-top:8px">Contacto de Maxsel (un renglón por línea, ej. WhatsApp, Facebook, página)<textarea id="mxC" rows="3" placeholder="WhatsApp 664 000 0000&#10;facebook.com/maxsel">${esc(CFG.maxsel_contacto || '')}</textarea></label>
      <button class="btn" onclick="maxselOk()">Guardar</button></div>` : ''}`);
    $('#lgA').value = CFG.ticket_logo_ancho || 'mediano';
  };
}
async function maxselOk() { await hacer(() => PUT('/api/config', { maxsel_contacto: val('mxC') }), 'Guardado'); CFG = await GET('/api/config'); }
// El logo se reduce y se pasa a escala de grises antes de guardarlo (queda ligero)
async function logoSubir(f) {
  if (!f) return;
  try {
    const url = await new Promise((ok, mal) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = mal; r.readAsDataURL(f); });
    const img = await new Promise((ok, mal) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => mal(new Error('No se pudo leer la imagen')); i.src = url; });
    const w = Math.min(576, img.width), h = Math.round(img.height * w / img.width), c = document.createElement('canvas');
    if (h > 900) throw new Error('El logo es muy alto. Use una imagen más ancha que alta.');
    c.width = w; c.height = h; const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); x.drawImage(img, 0, 0, w, h);
    const d = x.getImageData(0, 0, w, h); for (let i = 0; i < d.data.length; i += 4) { const g = d.data[i] * 0.3 + d.data[i + 1] * 0.59 + d.data[i + 2] * 0.11 < 150 ? 0 : 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = g; d.data[i + 3] = 255; }
    x.putImageData(d, 0, 0);
    const png = c.toDataURL('image/png');
    if (png.length > 190000) throw new Error('El logo es muy pesado. Use una imagen más sencilla.');
    await hacer(() => PUT('/api/config', { ticket_logo: png }), 'Logo guardado');
    CFG = await GET('/api/config'); LOGO_CACHE.key = ''; cImpresora();
  } catch (e) { toast(e.message, true); }
}
async function logoQuitar() { await hacer(() => PUT('/api/config', { ticket_logo: '' }), 'Logo quitado'); CFG = await GET('/api/config'); LOGO_CACHE.key = ''; cImpresora(); }
async function logoAncho() { await hacer(() => PUT('/api/config', { ticket_logo_ancho: val('lgA') }), 'Guardado'); CFG.ticket_logo_ancho = val('lgA'); LOGO_CACHE.key = ''; }
function logoPrueba() { const w = W(); imprimir([...encabezado(), 'TICKET DE PRUEBA', fdt(new Date().toISOString().slice(0, 19).replace('T', ' ')), '-'.repeat(w), lin('1 Producto de prueba', money(10)), '-'.repeat(w), lin('TOTAL', money(10)), '', CFG.ticket_pie || ''], 'Ticket de prueba'); }
