// Maxsel Hotel 1.49 — Sin "Extender": todo se cobra con "Pagar". Si en Renta se paga más de lo que debe, se adelantan
// semanas/meses completos (el "pagado hasta" se recorre solo). Cambiar el tipo de renta queda solo para el administrador.
'use strict';
{
  const U = { semana: ['semana', 'semanas'], mes: ['mes', 'meses'], dia: ['noche', 'noches'] };
  // ---- Cuenta: quitar "Extender" (el administrador conserva "Cambiar tipo de renta") ----
  const _ve = verEstancia;
  verEstancia = async function (...a) {
    const r = await _ve(...a);
    try {
      document.querySelectorAll('#modal button[onclick^="extModal"]').forEach((b) => {
        if (YO?.rol === 'admin') b.textContent = 'Cambiar tipo de renta (administrador)'; else b.remove();
      });
      document.querySelectorAll('#modal .masMenu .grp').forEach((g) => { if (!g.querySelector('button')) g.remove(); });
    } catch { /* nada */ }
    return r;
  };
  // ---- Pagar: en Renta, botones para adelantar 1, 2, 3… periodos ----
  const _pm = pagoModal;
  pagoModal = async function (id, ...a) {
    const r = await _pm(id, ...a);
    try {
      const e = await GET('/api/estancias/' + id), u = U[e.modalidad]; if (!u || !(e.precio > 0)) return r;
      const pend = await GET(`/api/estancias/${id}/pendientes`), debe = Math.max(0, pend.renta);
      const seg = $('#aCs'); if (!seg || $('#adelBox')) return r;
      seg.insertAdjacentHTML('afterend', `<div id="adelBox" class="card" style="margin:8px 0 0;padding:10px 12px">
        <div class="sub" style="margin-bottom:6px">${debe > 0.009 ? `De renta debe <b>${money(debe)}</b>. ` : 'Su renta está al corriente. '}Para pagar por adelantado toque cuántas ${u[1]}:</div>
        <div class="row" style="gap:6px;flex-wrap:wrap">${(e.modalidad === 'mes' ? [1, 2, 3] : [1, 2, 3, 4]).map((k) => `<button type="button" class="btn sm" onclick="adelantar(${k},${debe},${e.precio})">${debe > 0.009 ? '+ ' : ''}${k} ${k === 1 ? u[0] : u[1]} (${money(debe + k * e.precio)})</button>`).join('')}</div>
        <div class="sub" id="adelInfo" style="margin-top:6px"></div></div>`);
      const box = $('#adelBox'), sync = () => { box.hidden = document.querySelector('input[name=aC]:checked')?.value !== 'renta'; };
      document.querySelectorAll('input[name=aC]').forEach((x) => x.addEventListener('change', sync)); sync();
      $('#aM')?.addEventListener('input', () => {
        const k = Math.floor((num('aM') - debe + 0.01) / e.precio);
        $('#adelInfo').innerHTML = k >= 1 ? `Con este pago se adelantan <b>${k} ${k === 1 ? u[0] : u[1]}</b>.` : '';
      });
    } catch { /* nada */ }
    return r;
  };
}
function adelantar(k, debe, precio) {
  const rr = document.querySelector('input[name=aC][value=renta]'); if (rr && !rr.checked) { rr.checked = true; rr.dispatchEvent(new Event('change', { bubbles: true })); }
  const m = $('#aM'); m.value = (debe + k * precio).toFixed(2); m.dispatchEvent(new Event('input', { bubbles: true }));
}
