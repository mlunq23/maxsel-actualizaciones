// Permisos que el administrador puede dar o quitar a cada usuario de Maxsel Hotel
export const PERMISOS = [
  { grupo: 'Caja', clave: 'caja', texto: 'Abrir y cerrar su turno de caja y cobrar' },
  { grupo: 'Caja', clave: 'movimientos', texto: 'Registrar ingresos y egresos de caja' },
  { grupo: 'Caja', clave: 'cajon', texto: 'Abrir el cajón de dinero sin cobrar' },
  { grupo: 'Caja', clave: 'ver_corte', texto: 'Ver lo que debería haber al cerrar su turno (si no, el cierre es a ciegas)' },
  { grupo: 'Caja', clave: 'cancelar', texto: 'Cancelar ventas y gastos' },
  { grupo: 'Caja', clave: 'autorizar', texto: 'Autorizar egresos de caja con su clave, fijar el precio de visita y quitar multas o cuotas' },
  { grupo: 'Recepción', clave: 'registrar', texto: 'Registrar huéspedes, extender, cambiar de habitación y dar salida' },
  { grupo: 'Recepción', clave: 'visitantes', texto: 'Registrar visitantes y cobrar visitas' },
  { grupo: 'Recepción', clave: 'estados', texto: 'Cambiar habitaciones a limpieza o lista' },
  { grupo: 'Recepción', clave: 'depositos', texto: 'Recibir, devolver y retener depósitos' },
  { grupo: 'Recepción', clave: 'multas', texto: 'Cargar multas y cuotas (limpieza, mascota) a la cuenta del huésped' },
  { grupo: 'Recepción', clave: 'contratos', texto: 'Hacer y firmar contratos de arrendamiento' },
  { grupo: 'Recepción', clave: 'lista_negra', texto: 'Agregar o quitar personas de la lista de clientes no deseados' },
  { grupo: 'Tienda', clave: 'vender', texto: 'Vender productos' },
  { grupo: 'Tienda', clave: 'inventario', texto: 'Registrar entradas de mercancía' },
  { grupo: 'Tienda', clave: 'productos', texto: 'Dar de alta, editar y borrar productos y precios' },
  { grupo: 'Gastos', clave: 'gastos', texto: 'Registrar gastos y firmarlos' },
  { grupo: 'Gastos', clave: 'cuentas_pagar', texto: 'Dar de alta y pagar cuentas por pagar a proveedores' },
  { grupo: 'Gastos', clave: 'personal', texto: 'Administrar empleados (sueldos y datos) y proveedores, y pagar la nómina' },
  { grupo: 'Asistencia', clave: 'checador', texto: 'Usar el checador de entradas y salidas en esta computadora' },
  { grupo: 'Asistencia', clave: 'asistencia', texto: 'Ver y corregir asistencias, horarios, festivos, vacaciones y reportes' },
  { grupo: 'Mantenimiento', clave: 'mant_reportar', texto: 'Reportar desperfectos con fotos' },
  { grupo: 'Mantenimiento', clave: 'mant_atender', texto: 'Atender reportes y marcarlos como reparados' },
  { grupo: 'Administración', clave: 'reportes', texto: 'Ver reportes de ingresos, gastos y depósitos' },
  { grupo: 'Administración', clave: 'cortes', texto: 'Ver los cortes de caja de todos los usuarios' },
  { grupo: 'Administración', clave: 'habitaciones', texto: 'Agregar habitaciones y cambiar precios' },
  { grupo: 'Administración', clave: 'usuarios', texto: 'Administrar usuarios y sus permisos' },
  { grupo: 'Administración', clave: 'config', texto: 'Configuración del hotel, impresora y respaldos' },
  { grupo: 'Administración', clave: 'bitacora', texto: 'Ver la bitácora de todos los movimientos del sistema' },
];
const RECEPCION = ['checador', 'caja', 'movimientos', 'cajon', 'registrar', 'visitantes', 'estados', 'depositos', 'multas', 'contratos', 'vender', 'inventario', 'gastos', 'mant_reportar'];
export const PERMISOS_ROL = {
  admin: PERMISOS.map((p) => p.clave),
  // Gerente: todo menos administrar usuarios y la configuración general
  gerente: PERMISOS.map((p) => p.clave).filter((k) => k !== 'usuarios' && k !== 'config' && k !== 'bitacora'),
  recepcion: RECEPCION,
  monitor: ['reportes', 'cortes'],
  mantenimiento: ['mant_reportar', 'mant_atender'],
  limpieza: ['mant_reportar', 'mant_atender'], // camaristas: solo su panel de limpieza
};
const VALIDOS = new Set(PERMISOS.map((p) => p.clave));

// Permisos efectivos de un usuario. El administrador siempre tiene todo.
export function permisosDe(u) {
  if (!u) return [];
  if (u.rol === 'admin') return PERMISOS_ROL.admin;
  if (u.permisos) {
    try { const l = JSON.parse(u.permisos); if (Array.isArray(l)) return l.filter((k) => VALIDOS.has(k) && k !== 'usuarios'); } catch { /* usar los del rol */ }
  }
  return PERMISOS_ROL[u.rol] || [];
}
export const limpiarPermisos = (lista) => (Array.isArray(lista) ? [...new Set(lista.filter((k) => VALIDOS.has(k)))] : null);
