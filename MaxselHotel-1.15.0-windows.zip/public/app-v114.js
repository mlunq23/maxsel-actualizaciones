// Maxsel Hotel 1.14 — prioridad (urgencia) y "le toca a" en los trabajos; apps separadas de Mantenimiento y Limpieza con código QR

// ======================================================================
// Prioridad y a quién le toca: recepción, gerente o administrador
// ======================================================================
let PERS_MANT = { t: 0, l: [] };
async function personalMant() {
  if (Date.now() - PERS_MANT.t < 60000) return PERS_MANT.l;
  PERS_MANT = { t: Date.now(), l: await GET('/api/mant/personal').catch(() => []) };
  return PERS_MANT.l;
}
const optsPrio = (sel) => Object.entries(PRIO).map(([k, [n]]) => `<option value="${k}" ${k === (sel || 'normal') ? 'selected' : ''}>${n}</option>`).join('');
const optsPersonal = (l, sel, tipo) => `<option value="">Cualquiera de ${tipo === 'limpieza' ? 'limpieza' : 'mantenimiento'}</option>` + l.filter((x) => (x.rol === 'limpieza') === (tipo === 'limpieza')).map((x) => `<option value="${x.id}" ${x.id === sel ? 'selected' : ''}>${esc(x.nombre)}</option>`).join('');
{
  const _vm = verMant;
  verMant = async function (id) {
    await _vm(id);
    if (ES_PERSONAL() || !puede('mant_reportar')) return;
    try {
      const [m, P] = await Promise.all([GET('/api/mant/' + id), personalMant()]);
      if (m.estado === 'terminado') return;
      $('#modal .mbody')?.insertAdjacentHTML('afterbegin', `<div class="vm-ctl"><label class="l">Prioridad<select id="vmP">${optsPrio(m.prioridad)}</select></label>
        <label class="l">Le toca a<select id="vmA">${optsPersonal(P, m.asignado_a, m.tipo)}</select></label><button class="btn sm" onclick="vmGuardar(${id})">Guardar</button></div>`);
    } catch { /* nada */ }
  };
}
async function vmGuardar(id) {
  await hacer(() => PUT('/api/mant/' + id, { prioridad: val('vmP'), asignado_a: val('vmA') || null }), 'Guardado');
  verMant(id); if (vista === 'mant') vMant();
}
// Al levantar un trabajo, recepción elige la urgencia y a quién le toca
{
  const _ln = limpNuevo;
  limpNuevo = async function (...a) {
    await _ln(...a);
    if (ES_PERSONAL()) return;
    const P = await personalMant();
    $('#lnD')?.closest('label')?.insertAdjacentHTML('beforebegin', `<div class="f"><label class="l">Prioridad<select id="lnP">${optsPrio('normal')}</select></label><label class="l">Le toca a<select id="lnAs">${optsPersonal(P, null, 'limpieza')}</select></label></div>`);
  };
  const _mn = mantNuevo;
  mantNuevo = async function (habId, tipo) {
    const r = await _mn(habId, tipo);
    if (tipo === 'limpieza' || ES_PERSONAL() || !$('#nPr')) return r;
    const P = await personalMant();
    $('#nPr').insertAdjacentHTML('afterend', `<label class="l">Le toca a<select id="nAs">${optsPersonal(P, null, 'reparacion')}</select></label>`);
    return r;
  };
  const _api = api;
  api = function (metodo, url, body) {
    if (metodo === 'POST' && url === '/api/mant' && body) {
      if (body.tipo === 'limpieza' && $('#lnP')) body = { ...body, prioridad: val('lnP'), asignado_a: val('lnAs') || null };
      else if (body.tipo !== 'limpieza' && $('#nAs')) body = { ...body, asignado_a: val('nAs') || null };
    }
    return _api(metodo, url, body);
  };
}

// ======================================================================
// Entrada desde la app del celular: dice si es Mantenimiento o Limpieza
// ======================================================================
{
  const _pl = pantallaLogin;
  pantallaLogin = function (...a) {
    const r = _pl(...a);
    if (window.APP_PERSONAL) {
      const h = $('#flog h1'); if (h) h.textContent = window.APP_PERSONAL === 'limpieza' ? 'Maxsel Limpieza' : 'Maxsel Mantenimiento';
      h?.insertAdjacentHTML('afterend', `<p class="sub" style="text-align:center;margin-top:-6px">Entre con su usuario de ${window.APP_PERSONAL === 'limpieza' ? 'limpieza' : 'mantenimiento'}</p>`);
    }
    return r;
  };
}

// ======================================================================
// Configuración → Personal: QR para instalar las apps de Mantenimiento y Limpieza
// ======================================================================
function qrSVG(texto, celda = 5) {
  try { const q = qrcode(0, 'M'); q.addData(texto); q.make(); return q.createSvgTag(celda, 2); } catch { return ''; }
}
const APPS_PERS = {
  mantenimiento: { n: 'Mantenimiento', ruta: '/mantenimiento', color: 'var(--mant)', hace: 'Ve las reparaciones que le tocan ordenadas por urgencia, las atiende y sube la foto del arreglo.' },
  limpieza: { n: 'Limpieza', ruta: '/limpieza', color: 'var(--libre)', hace: 'Ve las habitaciones y áreas que le toca limpiar (lo urgente primero), avisa lo que manda a lavandería y sube la foto de cómo quedó.' },
};
const urlApp = (k) => { const ip = (CFG._ips || []).find((i) => !i.tailscale); return ip ? `http://${ip.ip}:${CFG._puerto || 3050}${APPS_PERS[k].ruta}` : ''; };
cMantPortal = async function () {
  const U = await GET('/api/usuarios').catch(() => []);
  if (typeof cfgTab !== 'undefined' && cfgTab !== 'mant') return; // mientras cargaba se abrió otra pestaña
  const ts = (CFG._ips || []).filter((i) => i.tailscale);
  const tarjeta = (k) => {
    const a = APPS_PERS[k], url = urlApp(k), us = U.filter((u) => u.rol === k);
    return `<div class="card"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px"><h2 style="margin:0;color:${a.color}">App de ${a.n}</h2><button class="btn" onclick="imprimirQRApp('${k}')">Imprimir hoja con QR</button></div>
      <p class="sub">${a.hace}</p>
      <div class="qr-app">${url ? `<div class="qr-box">${qrSVG(url, 5)}</div>` : '<div class="aviso bad">Esta computadora no está conectada a la red. Conéctela al módem del hotel.</div>'}
        <div class="stack" style="gap:6px;min-width:0"><div class="lbl">Escanee con la cámara del celular (conectado al WiFi del hotel)</div>${url ? `<div class="codigo" style="font-size:18px;word-break:break-all">${esc(url)}</div>` : ''}
          ${ts.length ? `<div class="sub">Desde fuera del hotel (Tailscale): <span class="mono">http://${esc(ts[0].ip)}:${CFG._puerto || 3050}${a.ruta}</span></div>` : ''}
          <button class="btn sm pri" style="width:fit-content" onclick="nuevoUsuarioPers('${k}')">Crear usuario de ${a.n.toLowerCase()}</button>
          <div class="sub">${us.length ? 'Usuarios: ' + us.map((u) => `<b>${esc(u.nombre)}</b> (${esc(u.usuario)})${u.activo ? '' : ' — inactivo'}`).join(', ') : 'Todavía no hay usuarios de ' + a.n.toLowerCase() + '.'}</div></div></div></div>`;
  };
  $('#cfgc').innerHTML = `<div class="stack">${tarjeta('mantenimiento')}${tarjeta('limpieza')}
    <div class="card"><h2>Cómo instalar la app en el celular</h2><ol class="pasos">
      <li>Cree un usuario para cada persona (botón de arriba): de tipo <b>Mantenimiento</b> o <b>Limpieza</b>. Cada quien solo ve su panel.</li>
      <li>Conecte el celular al <b>WiFi del hotel</b> y escanee el código QR con la cámara.</li>
      <li>Entre con su usuario y contraseña.</li>
      <li>Déjela como app: en Android, menú <b>⋮ → Agregar a la pantalla principal</b> (o "Instalar app"); en iPhone, botón <b>Compartir → Agregar a inicio</b>. Queda con el nombre "Maxsel Mantenimiento" o "Maxsel Limpieza".</li>
      <li>Si no abre: el celular debe estar en el WiFi del hotel (no con datos) y esta computadora encendida. Si sigue sin abrir, permita el puerto ${CFG._puerto || 3050} en el Firewall de Windows.</li></ol>
      <div class="sub">La urgencia de cada trabajo y a quién le toca se ponen al levantarlo, o después desde Mantenimiento tocando el trabajo.</div></div></div>`;
};
async function nuevoUsuarioPers(k) {
  PERMS = PERMS || await GET('/api/permisos'); cUsers.l = cUsers.l || await GET('/api/usuarios');
  userModal(); $('#uR').value = k; permisosRol();
}
function imprimirQRApp(k) {
  const a = APPS_PERS[k], url = urlApp(k);
  imprimirDoc(`<div class="rep" style="text-align:center"><div class="rep-enc"><b>${esc(CFG.hotel_nombre)}</b><span>APP DE ${a.n.toUpperCase()}</span><span>Para el celular del personal</span></div>
    <div style="margin:18px auto;width:fit-content">${url ? qrSVG(url, 9) : '(conecte la computadora a la red del hotel)'}</div>
    <div style="font-size:20px;font-weight:800;margin-bottom:14px">${esc(url)}</div>
    <ol style="text-align:left;font-size:15px;line-height:1.8;max-width:560px;margin:0 auto"><li>Conecte su celular al WiFi del hotel.</li><li>Abra la cámara y apunte a este código. Toque el enlace que aparece.</li>
      <li>Entre con su usuario: ____________________ &nbsp; contraseña: ____________________</li>
      <li>Instálela: Android, menú ⋮ → <b>Agregar a la pantalla principal</b>; iPhone, <b>Compartir → Agregar a inicio</b>.</li>
      <li>${k === 'limpieza' ? 'En "Por hacer" están sus limpiezas (lo urgente primero). Al terminar toque "Terminé, quedó limpio" y tome la foto.' : 'En "Por hacer" están sus reparaciones (lo urgente primero). Al terminar toque "Marcar como reparado" y tome la foto del arreglo.'}</li></ol></div>`, 'carta', 'App de ' + a.n);
}
// En el celular de limpieza el menú dice "Limpieza"
{
  const _pn = pintarNav;
  pintarNav = function (...a) {
    const r = _pn.apply(this, a);
    if (YO?.rol === 'limpieza') document.querySelectorAll('#nav button').forEach((b) => { if (/ir\('mant'\)/.test(b.getAttribute('onclick') || '')) b.firstChild.textContent = 'Limpieza'; });
    return r;
  };
}
