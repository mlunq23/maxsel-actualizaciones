// Maxsel Hotel 1.10 — Historial de cambios de habitación, huéspedes por identificación y clientes no deseados,
// aviso de privacidad, tickets de limpieza, bitácora, descuentos con límite, tipo de cambio del administrador
// y carga de habitaciones por unidad con su propio Excel.
'use strict';
const tLargo = (s) => { const d = aF(s); return d ? d.toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric' }) + ' ' + d.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' }) : '—'; };

// ======================================================================
// Configuración: una pestaña ya no se encima con otra (Mantenimiento / Monitoreo remoto)
// ======================================================================
{
  const _vCfg = vCfg;
  vCfg = async function () {
    const n = (vCfg.n = (vCfg.n || 0) + 1), quiere = cfgTab, extra = { bita: puede('bitacora'), aviso: puede('config') };
    if (extra[quiere]) cfgTab = 'pass';
    await _vCfg();
    if (n !== vCfg.n) return;
    const tabs = $('#main .tabs');
    if (tabs) {
      if (extra.aviso) tabs.insertAdjacentHTML('beforeend', `<button class="${quiere === 'aviso' ? 'on' : ''}" onclick="cfgTab='aviso';vCfg()">Aviso de privacidad</button>`);
      if (extra.bita) tabs.insertAdjacentHTML('beforeend', `<button class="${quiere === 'bita' ? 'on' : ''}" onclick="cfgTab='bita';vCfg()">Bitácora</button>`);
    }
    if (extra[quiere]) {
      cfgTab = quiere;
      tabs?.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.getAttribute('onclick') === `cfgTab='${quiere}';vCfg()`));
      return quiere === 'bita' ? cBitacora() : cAviso();
    }
  };
  // Si una pestaña tardó en cargar y mientras tanto se abrió otra, se vuelve a pintar la que está abierta
  for (const nombre of ['cHotel', 'cHabs', 'cImpresora', 'cContrato', 'cUsers', 'cRemoto', 'cMantPortal', 'cResp', 'cPass']) {
    const f = window[nombre]; if (typeof f !== 'function') continue;
    window[nombre] = async function (...a) {
      const n = vCfg.n; const r = await f.apply(this, a);
      if (vista === 'cfg' && n !== vCfg.n) { const v = vCfg.n; setTimeout(() => { if (v === vCfg.n) vCfg(); }, 0); }
      return r;
    };
  }
}

// ======================================================================
// Tipo de cambio: solo el administrador lo pone; el cajero ya no lo escribe al abrir su turno
// ======================================================================
abrirTurno = function () {
  modal('Abrir turno', `<p style="margin:0">Cuente el dinero con el que empieza la caja.</p>
    <div class="f"><label class="l">Fondo de caja en pesos<input id="tFm" type="number" min="0" step="0.01" placeholder="0.00"></label><label class="l">Fondo en dólares<input id="tFu" type="number" min="0" step="0.01" placeholder="0.00"></label></div>
    <div class="aviso">Dólar a <b>$${Number(CFG.tipo_cambio || 0).toFixed(2)}</b>. Solo el administrador lo cambia en Configuración → Impresora y caja.</div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="abrirTurnoOk(num('tFm'),num('tFu'))">Abrir turno</button>`);
  $('#tFm')?.focus();
};
abrirTurno2 = function () { abrirTurnoOk(num('tFm'), num('tFu')); };
tcOk = async function () {
  await hacer(() => PUT('/api/tipo-cambio', { tipo_cambio: val('tcN') }), 'Tipo de cambio actualizado'); CFG.tipo_cambio = val('tcN'); cerrar(); await pintarTurno(); if (vista === 'caja') vCaja();
};
{
  const _vCaja = vCaja;
  vCaja = async function (...a) { const r = await _vCaja.apply(this, a); if (!puede('config')) document.querySelectorAll('#main button[onclick="tcModal()"]').forEach((b) => b.remove()); return r; };
  const _ci = cImpresora;
  cImpresora = async function (...a) {
    const r = await _ci.apply(this, a);
    if (puede('config')) ($('#cfgc .stack') || $('#cfgc'))?.insertAdjacentHTML('afterbegin', `<div class="card"><h2>Tipo de cambio del dólar</h2>
      <div class="row" style="gap:8px;flex-wrap:wrap;align-items:flex-end"><label class="l" style="margin:0">Un dólar vale (pesos)<input id="tcAdm" type="number" min="0" step="0.01" value="${esc(CFG.tipo_cambio || '')}" style="max-width:160px"></label><button class="btn pri" onclick="tcAdmOk()">Guardar</button></div>
      <p class="sub" style="margin-bottom:0">Solo el administrador lo cambia. Se usa en todas las cajas abiertas y al abrir los turnos; los cajeros ya no lo escriben.</p></div>`);
    return r;
  };
}
async function tcAdmOk() { const r = await hacer(() => PUT('/api/tipo-cambio', { tipo_cambio: val('tcAdm') }), 'Tipo de cambio guardado'); CFG.tipo_cambio = String(r.tipo_cambio); pintarTurno(); }

// ======================================================================
// Aviso de privacidad
// ======================================================================
const AVISO_BASE = () => `AVISO DE PRIVACIDAD

${CFG.hotel_nombre || 'El hotel'}, con domicilio en ${CFG.hotel_direccion || '__________'}${CFG.hotel_telefono ? ', teléfono ' + CFG.hotel_telefono : ''}, es responsable del uso y protección de sus datos personales, conforme a la Ley Federal de Protección de Datos Personales en Posesión de los Particulares.

¿QUÉ DATOS RECABAMOS?
Nombre, identificación oficial (tipo y número), teléfono, domicilio, ciudad de procedencia, placas del vehículo, firma y, en su caso, datos de pago. No le pedimos datos personales sensibles.

¿PARA QUÉ LOS USAMOS?
1. Registrar su hospedaje, cobrar, facturar y darle el servicio que contrató.
2. Contactarlo sobre su estancia, reservaciones u objetos olvidados.
3. Seguridad del establecimiento, de los huéspedes y del personal: llevar el registro de huéspedes que exige la ley y, cuando una persona incumple el reglamento (daños, falta de pago, violencia u otros), anotarlo para poder negarle hospedajes futuros.

¿CON QUIÉN LOS COMPARTIMOS?
Solo con autoridades competentes cuando lo requieran conforme a la ley. No vendemos ni compartimos sus datos con terceros para publicidad.

SUS DERECHOS (ARCO)
Usted puede pedir acceso, rectificación, cancelación u oposición al uso de sus datos, y revocar su consentimiento, con un escrito en recepción${CFG.hotel_telefono ? ' o al teléfono ' + CFG.hotel_telefono : ''}. Le responderemos en los plazos que marca la ley.

CONSERVACIÓN
Sus datos se guardan en el sistema del hotel, protegidos con usuario y contraseña, solo por el tiempo necesario para las finalidades anteriores y las obligaciones legales.

CAMBIOS AL AVISO
Cualquier cambio a este aviso estará disponible en recepción.

Al firmar, acepto que mis datos se usen como se indica en este aviso.`;
const avisoTexto = () => (CFG.aviso_privacidad && CFG.aviso_privacidad.trim() ? CFG.aviso_privacidad : AVISO_BASE());
function imprimirAviso(nombre) {
  const t = avisoTexto().split(/\r?\n/), titulo = t[0] || 'AVISO DE PRIVACIDAD';
  const cuerpo = t.slice(1).map((l) => (/^[A-ZÁÉÍÓÚÑ¿?() ]{6,}$/.test(l.trim()) ? `<h3 style="margin:14px 0 4px">${esc(l)}</h3>` : l.trim() ? `<p style="margin:0 0 6px">${esc(l)}</p>` : '')).join('');
  imprimirDoc(`<div class="rep" style="font-size:12.5px;line-height:1.5"><div class="rep-enc"><b>${esc(CFG.hotel_nombre || '')}</b><span>${esc(titulo)}</span><span>${esc(CFG.hotel_direccion || '')}</span></div>${cuerpo}
    <div style="display:flex;gap:40px;margin-top:40px"><div style="flex:1;border-top:1px solid #000;text-align:center;padding-top:4px">Nombre y firma del huésped${nombre ? '<br><b>' + esc(nombre) + '</b>' : ''}</div><div style="width:160px;border-top:1px solid #000;text-align:center;padding-top:4px">Fecha<br>${esc(new Date().toLocaleDateString('es-MX'))}</div></div></div>`, 'carta', 'Aviso de privacidad');
}
function cAviso() {
  $('#cfgc').innerHTML = `<div class="stack"><div class="card"><h2>Aviso de privacidad para los huéspedes</h2>
    <p class="sub" style="margin-top:0">Se imprime para que el huésped lo firme y en el registro se marca que lo aceptó. Ya menciona la lista de clientes no deseados. Puede cambiar el texto; <b>revíselo con su abogado o contador</b> antes de usarlo.</p>
    <label class="row" style="font-weight:600"><input type="checkbox" id="avOb" ${CFG.aviso_obligatorio !== '0' ? 'checked' : ''}> Al registrar, pedir que se marque que el huésped aceptó el aviso</label>
    <label class="l" style="margin-top:10px">Texto del aviso<textarea id="avT" rows="22" style="font-family:var(--fBody);font-size:13.5px">${esc(avisoTexto())}</textarea></label>
    <div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn pri" onclick="avisoOk()">Guardar</button><button class="btn" onclick="imprimirAviso()">Imprimir</button><button class="btn" onclick="confirmar(this,avisoBase)">Volver al texto de Maxsel</button></div></div></div>`;
}
async function avisoOk() { const t = $('#avT').value.trim(); await hacer(() => PUT('/api/config', { aviso_privacidad: t === AVISO_BASE().trim() ? '' : t, aviso_obligatorio: $('#avOb').checked ? '1' : '0' }), 'Aviso guardado'); CFG = await GET('/api/config'); }
async function avisoBase() { await hacer(() => PUT('/api/config', { aviso_privacidad: '' }), 'Listo'); CFG = await GET('/api/config'); cAviso(); }

// ======================================================================
// Registro del huésped: identificación (llena sus datos), alerta de no deseado, aviso, descuento
// ======================================================================
let DESC_LIM = null, ND_ACTUAL = null;
{
  const _reg = registrar;
  registrar = function (id) {
    _reg(id);
    ND_ACTUAL = null;
    const body = $('#modal .mbody'); if (!body || !$('#rH')) return;
    // Identificación: tipo + número (con eso se busca en la base de huéspedes)
    const rI = $('#rI'); if (rI) rI.placeholder = 'Número de la identificación';
    rI?.closest('label')?.insertAdjacentHTML('beforebegin', `<label class="l">Tipo de identificación<select id="rTi"><option>INE</option><option>Pasaporte</option><option>Licencia de manejo</option><option>Cédula profesional</option><option>Otra</option></select></label>`);
    body.insertAdjacentHTML('afterbegin', '<div id="rND"></div><div id="rHist"></div>');
    for (const k of ['rH', 'rI', 'rT']) $('#' + k)?.addEventListener('input', () => { clearTimeout(registrar.t); registrar.t = setTimeout(revisarHuesped, 450); });
    // Descuento
    const res = $('#rRes');
    res?.insertAdjacentHTML('beforebegin', `<div class="lbl">Descuento</div><div class="f"><label class="l">Tipo<select id="rDt" onchange="rCalc(${id})"><option value="">Sin descuento</option><option value="pct">Porcentaje (%)</option><option value="monto">Cantidad ($)</option></select></label>
      <label class="l">Cuánto<input id="rDv" type="number" min="0" step="0.01" oninput="rCalc(${id})" disabled></label><label class="l" style="grid-column:span 2">Motivo del descuento<input id="rDm" placeholder="Ej. huésped frecuente, cortesía, convenio" disabled></label></div><div class="sub" id="rDl"></div>`);
    // Aviso de privacidad
    res?.insertAdjacentHTML('afterend', `<div class="row" style="gap:10px;flex-wrap:wrap;align-items:center;margin-top:6px"><label class="row" style="font-weight:600"><input type="checkbox" id="rAv"> El huésped aceptó el aviso de privacidad</label><button type="button" class="btn sm" onclick="imprimirAviso(val('rH'))">Imprimir aviso para firmar</button></div>`);
    (async () => { try { DESC_LIM = DESC_LIM || await GET('/api/descuento/limite'); } catch { DESC_LIM = { pct: 0, monto: 0 }; } pintaLimite(); })();
  };
}
function pintaLimite() {
  const el = $('#rDl'); if (!el || !DESC_LIM) return;
  const L = DESC_LIM, hay = L.pct > 0 || L.monto > 0;
  el.textContent = hay ? `Máximo ${L.general ? 'del hotel' : 'para su usuario'}: ${[L.pct > 0 ? 'por porcentaje hasta ' + L.pct + '%' : '', L.monto > 0 ? 'por cantidad hasta ' + money(L.monto) : ''].filter(Boolean).join(' · ')}. El motivo es obligatorio.` : 'Su usuario no puede hacer descuentos.';
  if (!hay) { $('#rDt').disabled = true; }
}
async function revisarHuesped() {
  if (!$('#rH')) return;
  let r; try { r = await GET(`/api/huespedes/revisar?identificacion=${encodeURIComponent(val('rI'))}&telefono=${encodeURIComponent(val('rT'))}&huesped=${encodeURIComponent(val('rH'))}`); } catch { return; }
  const h = r.huesped, nd = r.no_deseado; ND_ACTUAL = nd;
  if (h) {
    if (!val('rH')) $('#rH').value = h.nombre || '';
    for (const [id, k] of [['rT', 'telefono'], ['rD', 'domicilio'], ['rP', 'procedencia'], ['rV', 'placas']]) if ($('#' + id) && !val(id) && h[k]) $('#' + id).value = h[k];
    if (h.tipo_id && $('#rTi')) $('#rTi').value = h.tipo_id;
    $('#rHist').innerHTML = `<div class="aviso ok">Huésped conocido: <b>${esc(h.nombre)}</b> · ${h.visitas} estancia(s)${h.ultima ? ' · la última el ' + esc(fd(h.ultima)) : ''}. Se llenaron sus datos.</div>`;
  } else $('#rHist').innerHTML = '';
  const btn = document.querySelector('#modal footer .btn.pri');
  if (nd) {
    $('#rND').innerHTML = `<div class="aviso bad nd-alerta"><b>⚠ CLIENTE NO DESEADO</b><br>${esc(nd.nombre)} (coincide por ${esc(nd.por)}).<br>Motivo: <b>${esc(nd.motivo_bloqueo || 'sin motivo')}</b>${nd.bloqueo_fecha ? ` · desde ${esc(fd(nd.bloqueo_fecha))}${nd.bloqueo_por ? ' por ' + esc(nd.bloqueo_por) : ''}` : ''}
      ${puede('autorizar') ? '<label class="row" style="font-weight:600;margin-top:6px"><input type="checkbox" id="rNdA" onchange="ndBoton()"> Autorizo el registro (gerente / administrador)</label>' : '<div style="margin-top:6px">No se puede registrar. Llame al gerente o al administrador.</div>'}</div>`;
  } else $('#rND').innerHTML = '';
  ndBoton(btn);
}
function ndBoton(btn) { btn = btn || document.querySelector('#modal footer .btn.pri'); if (btn) btn.disabled = !!ND_ACTUAL && !$('#rNdA')?.checked; }
{
  const _rCalc = rCalc;
  rCalc = function (id, reset) {
    _rCalc(id, reset);
    const t = val('rDt'), v = num('rDv');
    if ($('#rDv')) { $('#rDv').disabled = !t; $('#rDm').disabled = !t; }
    if (!t || !(v > 0) || !$('#rRes')) return;
    const n = Math.max(1, parseInt(val('rC')) || 1), u = num('rU'), base = n * u, d = Math.min(base, t === 'pct' ? base * v / 100 : v);
    if (!(d > 0)) return;
    const mas = Math.max(0, parseInt(val('rMas')) || 0) * (Number(CFG.cuota_mascota) || 0), tot = base - d + mas;
    if (!$('#rA').dataset.t) $('#rA').value = Math.max(0, tot).toFixed(2);
    const L = DESC_LIM || {}, pct = base ? d / base * 100 : 0, pasa = t === 'pct' ? v > (L.pct || 0) + 0.001 : L.monto > 0 ? d > L.monto + 0.001 : !L.general || pct > (L.pct || 0) + 0.001;
    const R = $('#rRes'), pend = Math.max(0, tot - num('rA'));
    R.innerHTML = R.innerHTML.replace(/<span>Total<\/span><b class="big">[^<]*<\/b>/, `<span>Descuento${t === 'pct' ? ' ' + v + '%' : ''}</span><b style="color:${pasa ? 'var(--ocup)' : 'var(--libre)'}">−${money(d)}${pasa ? ' (pasa del máximo)' : ''}</b><span>Total con descuento</span><b class="big">${money(tot)}</b>`)
      .replace(/<span>Queda por pagar<\/span><b[^>]*>[^<]*<\/b>/, `<span>Queda por pagar</span><b style="color:${pend > 0 ? 'var(--ocup)' : 'var(--libre)'}">${money(pend)}</b>`);
  };
  // El registro manda la identificación, el aviso, el descuento y la autorización del no deseado
  const _api = api;
  api = function (metodo, url, body) {
    if (metodo === 'POST' && url === '/api/estancias' && $('#rH')) {
      body = { ...body, tipo_id: val('rTi') || undefined, acepto_aviso: !!$('#rAv')?.checked, autorizar_no_deseado: !!$('#rNdA')?.checked };
      if (val('rDt') && num('rDv') > 0) Object.assign(body, { descuento_tipo: val('rDt'), descuento_valor: num('rDv'), descuento_motivo: val('rDm') });
    }
    if ((metodo === 'POST' || metodo === 'PUT') && /^\/api\/usuarios(\/\d+)?$/.test(url) && $('#uDp')) body = { ...body, desc_max_pct: num('uDp'), desc_max_monto: num('uDm') };
    if (metodo === 'POST' && url === '/api/mant' && $('#nTipo')) body = { ...body, tipo: val('nTipo'), area: val('nArea') };
    return _api(metodo, url, body);
  };
  // Antes de cobrar: aviso de privacidad, motivo del descuento y no deseado
  const _rOk = window.rOk;
  window.rOk = async function (...a) {
    if (ND_ACTUAL && !$('#rNdA')?.checked) return toast('Es un cliente no deseado: no se puede registrar', true);
    if (val('rDt') && num('rDv') > 0 && !val('rDm')) return toast('Escriba el motivo del descuento', true);
    if (CFG.aviso_obligatorio !== '0' && $('#rAv') && !$('#rAv').checked) return toast('Marque que el huésped aceptó el aviso de privacidad (puede imprimirlo para que lo firme)', true);
    return _rOk.apply(this, a);
  };
}

// ======================================================================
// Cuenta del huésped: de qué habitación a cuál lo cambiaron, descuento y no deseado
// ======================================================================
cambiarModal = function (id) {
  const libres = sortH(TAB.habitaciones.filter((h) => h.estado === 'libre'));
  if (!libres.length) return toast('No hay habitaciones disponibles', true);
  modal('Cambiar de habitación', `<label class="l">Pasar al huésped a<select id="cH">${libres.map((h) => `<option value="${h.id}">${esc(h.numero)} · ${esc(h.nombre || '')}</option>`).join('')}</select></label>
    <label class="l">Motivo del cambio<input id="cMo" placeholder="Ej. no servía el aire, pidió otra cama, ruido"></label><div class="sub">La tarifa no cambia. La habitación anterior pasa a limpieza. El cambio queda en el historial del huésped.</div>`,
  `<button class="btn" onclick="verEstancia(${id})">Volver</button><button class="btn pri" onclick="cambiarOk(${id})">Cambiar</button>`);
};
cambiarOk = async function (id) {
  if (!val('cMo')) return toast('Escriba el motivo del cambio', true);
  await hacer(() => POST(`/api/estancias/${id}/cambiar`, { habitacion_id: val('cH'), motivo: val('cMo') }), 'Habitación cambiada'); await vHab(); verEstancia(id);
};
{
  const _ve = verEstancia;
  verEstancia = async function (id, ...a) {
    const r = await _ve.call(this, id, ...a);
    let e; try { e = await GET('/api/estancias/' + id); } catch { return r; }
    const body = $('#modal .mbody'); if (!body) return r;
    const kv = body.querySelector('.kv');
    if (e.descuento > 0) kv?.insertAdjacentHTML('beforeend', `<span>Descuento</span><span><b>−${money(e.descuento)}</b>${e.descuento_tipo === 'pct' ? ` (${e.descuento_valor}%)` : ''} · ${esc(e.descuento_motivo || '')}${e.descuento_por ? ' · ' + esc(e.descuento_por) : ''}</span>`);
    if (e.aviso_privacidad) kv?.insertAdjacentHTML('beforeend', '<span>Aviso de privacidad</span><span>Aceptado</span>');
    if (e.no_deseado) body.insertAdjacentHTML('afterbegin', '<div class="aviso bad"><b>Este huésped está en la lista de clientes no deseados.</b></div>');
    const pasos = [e.hab_inicial || e.habitacion?.numero, ...e.cambios.map((c) => c.a_num)];
    body.insertAdjacentHTML('beforeend', `<div><div class="lbl">Historial de habitaciones</div>${e.cambios.length ? `<div class="hab-ruta">${pasos.map((n, i) => `<span class="pill ${i === pasos.length - 1 ? 'p-ok' : ''}">${esc(n || '—')}</span>`).join('<span class="sub">→</span>')}</div>
      <div class="tw"><table><tbody><tr><td>${tLargo(e.entrada)}</td><td colspan="2">Llegó a la <b>${esc(e.hab_inicial || pasos[0])}</b></td><td></td></tr>${e.cambios.map((c) => `<tr><td>${tLargo(c.fecha)}</td><td>De la <b>${esc(c.de_num)}</b> a la <b>${esc(c.a_num)}</b></td><td>${esc(c.motivo || '')}</td><td class="sub">${esc(c.usuario || '')}</td></tr>`).join('')}</tbody></table></div>`
      : `<div class="sub">Llegó a la ${esc(e.hab_inicial || e.habitacion?.numero || '')} y no se ha cambiado.</div>`}</div>`);
    if (puede('lista_negra') && !e.no_deseado) $('#modal footer')?.insertAdjacentHTML('afterbegin', `<button class="btn bad op" onclick="ndDesdeEstancia(${e.id})">No deseado</button>`);
    return r;
  };
}
function ndDesdeEstancia(id) {
  modal('Agregar a clientes no deseados', `<p style="margin:0">La próxima vez que alguien con su identificación, teléfono o nombre quiera registrarse o reservar, el sistema avisará y no lo dejará (solo el gerente o el administrador pueden autorizarlo).</p>
    <label class="l">Motivo<input id="ndM" placeholder="Ej. dañó la habitación, no pagó, pleito con otros huéspedes"></label>`,
  `<button class="btn" onclick="verEstancia(${id})">Volver</button><button class="btn bad" onclick="ndDesdeEstanciaOk(${id})">Agregar a no deseados</button>`);
}
async function ndDesdeEstanciaOk(id) { if (!val('ndM')) return toast('Escriba el motivo', true); await hacer(() => POST(`/api/estancias/${id}/no-deseado`, { motivo: val('ndM') }), 'Agregado a clientes no deseados'); verEstancia(id); }

// ======================================================================
// Huéspedes: estancias, base de huéspedes (por identificación) y clientes no deseados
// ======================================================================
let hTab = 'estancias', hbQ = '';
{
  const _vHues = vHues;
  vHues = async function (...a) {
    if (hTab === 'estancias') { await _vHues.apply(this, a); }
    else {
      const nd = hTab === 'nd', l = await GET(`/api/huespedes?${nd ? 'no_deseados=1&' : ''}q=${encodeURIComponent(hbQ)}`);
      $('#main').innerHTML = cab('Huéspedes', nd ? 'Personas que no se deben hospedar: el sistema avisa al registrarlas o reservarlas' : 'Base de huéspedes por identificación (se guarda sola al registrar)',
        `<input id="hbB" placeholder="Buscar nombre, identificación, teléfono o placas" value="${esc(hbQ)}" style="width:min(340px,100%)" onkeydown="if(event.key==='Enter'){hbQ=this.value;vHues()}"><button class="btn" onclick="hbQ=val('hbB');vHues()">Buscar</button>${nd && puede('lista_negra') ? '<button class="btn bad op" onclick="ndNuevo()">Agregar no deseado</button>' : ''}`)
        + `<div class="card"><div class="tw"><table><thead><tr><th>Nombre</th><th>Identificación</th><th>Teléfono</th><th>Procedencia</th>${nd ? '<th>Motivo</th><th>Desde</th>' : '<th class="n">Estancias</th><th>Última vez</th>'}<th></th></tr></thead><tbody>
          ${l.map((h) => `<tr class="click" onclick="verHuesped(${h.id})"><td><b>${esc(h.nombre)}</b>${h.bloqueado && !nd ? ' <span class="pill p-bad">No deseado</span>' : ''}</td><td class="mono">${esc([h.tipo_id, h.identificacion].filter(Boolean).join(' '))}</td><td>${esc(h.telefono || '')}</td><td>${esc(h.procedencia || '')}</td>
            ${nd ? `<td>${esc(h.motivo_bloqueo || '')}</td><td>${h.bloqueo_fecha ? fd(h.bloqueo_fecha) : ''}${h.bloqueo_por ? '<div class="sub">' + esc(h.bloqueo_por) + '</div>' : ''}</td>` : `<td class="n">${h.visitas}</td><td>${h.ultima ? fd(h.ultima) : '—'}</td>`}<td>›</td></tr>`).join('') || `<tr><td colspan="7" class="empty">${nd ? 'No hay clientes no deseados.' : 'Todavía no hay huéspedes con identificación.'}</td></tr>`}</tbody></table></div></div>`;
    }
    $('#main .top')?.insertAdjacentHTML('afterend', `<div class="tabs" style="margin-bottom:12px">${[['estancias', 'Estancias'], ['base', 'Base de huéspedes'], ['nd', 'Clientes no deseados']].map(([k, n]) => `<button class="${hTab === k ? 'on' : ''}" onclick="hTab='${k}';vHues()">${n}</button>`).join('')}</div>`);
  };
}
async function verHuesped(id) {
  const h = await GET('/api/huespedes/' + id);
  modal(esc(h.nombre), `${h.bloqueado ? `<div class="aviso bad"><b>CLIENTE NO DESEADO</b><br>Motivo: ${esc(h.motivo_bloqueo || '')}${h.bloqueo_fecha ? ` · desde ${esc(fd(h.bloqueo_fecha))}${h.bloqueo_por ? ' por ' + esc(h.bloqueo_por) : ''}` : ''}</div>` : ''}
    <div class="f"><label class="l" style="grid-column:1/-1">Nombre<input id="hN" value="${esc(h.nombre)}"></label><label class="l">Tipo de identificación<input id="hTi" value="${esc(h.tipo_id || '')}" placeholder="INE, pasaporte…"></label><label class="l">Número de identificación<input id="hI" value="${esc(h.identificacion || '')}"></label>
      <label class="l">Teléfono<input id="hT" value="${esc(h.telefono || '')}"></label><label class="l">Procedencia<input id="hP" value="${esc(h.procedencia || '')}"></label><label class="l">Placas<input id="hV" value="${esc(h.placas || '')}"></label>
      <label class="l" style="grid-column:1/-1">Domicilio<input id="hD" value="${esc(h.domicilio || '')}"></label><label class="l" style="grid-column:1/-1">Notas<input id="hO" value="${esc(h.notas || '')}"></label></div>
    <div class="kv"><span>Estancias</span><b>${h.visitas}</b><span>Primera vez</span><span>${h.primera ? fd(h.primera) : '—'}</span><span>Última vez</span><span>${h.ultima ? fd(h.ultima) : '—'}</span><span>Aviso de privacidad</span><span>${h.aviso ? 'Aceptado ' + fd(h.aviso) : '—'}</span></div>
    <div><div class="lbl">Sus estancias</div>${h.estancias.length ? `<div class="tw" style="max-height:220px"><table><tbody>${h.estancias.map((e) => `<tr class="click" onclick="verEstancia(${e.id})"><td class="mono">${esc(e.folio)}</td><td><b>${esc(e.numero)}</b></td><td>${fdt(e.entrada)}</td><td>${unidad(e.modalidad, e.cantidad)}</td><td class="n">${money(e.total_hospedaje)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="sub">Sin estancias registradas.</div>'}</div>`,
  `${puede('lista_negra') ? (h.bloqueado ? `<button class="btn op" onclick="confirmar(this,()=>ndQuitar(${h.id}))">Quitar de no deseados</button>` : `<button class="btn bad op" onclick="ndPoner(${h.id})">Marcar como no deseado</button>`) : ''}<button class="btn" onclick="cerrar()">Cerrar</button>${puede('registrar') ? `<button class="btn pri op" onclick="huespedOk(${h.id})">Guardar</button>` : ''}`, true);
}
async function huespedOk(id) { await hacer(() => PUT('/api/huespedes/' + id, { nombre: val('hN'), tipo_id: val('hTi'), identificacion: val('hI'), telefono: val('hT'), procedencia: val('hP'), placas: val('hV'), domicilio: val('hD'), notas: val('hO') }), 'Guardado'); cerrar(); vHues(); }
function ndPoner(id) {
  modal('Marcar como no deseado', '<label class="l">Motivo<input id="ndM" placeholder="Ej. dañó la habitación, no pagó, pleito con otros huéspedes"></label>',
    `<button class="btn" onclick="verHuesped(${id})">Volver</button><button class="btn bad" onclick="ndPonerOk(${id})">Marcar como no deseado</button>`);
}
async function ndPonerOk(id) { if (!val('ndM')) return toast('Escriba el motivo', true); await hacer(() => POST(`/api/huespedes/${id}/bloquear`, { motivo: val('ndM') }), 'Marcado como no deseado'); verHuesped(id); if (vista === 'hues') vHues(); }
async function ndQuitar(id) { await hacer(() => POST(`/api/huespedes/${id}/desbloquear`), 'Quitado de no deseados'); verHuesped(id); if (vista === 'hues') vHues(); }
function ndNuevo() {
  modal('Agregar cliente no deseado', `<p class="sub" style="margin-top:0">Para una persona que no debe hospedarse aunque nunca haya venido. Con la identificación o el teléfono el aviso es más seguro.</p>
    <div class="f"><label class="l" style="grid-column:1/-1">Nombre completo<input id="nnN"></label><label class="l">Identificación<input id="nnI" placeholder="INE, pasaporte…"></label><label class="l">Teléfono<input id="nnT"></label>
      <label class="l" style="grid-column:1/-1">Motivo<input id="nnM" placeholder="Ej. problemas en otro hotel, amenazas"></label></div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn bad" onclick="ndNuevoOk()">Agregar</button>`);
}
async function ndNuevoOk() { await hacer(() => POST('/api/huespedes', { nombre: val('nnN'), identificacion: val('nnI'), telefono: val('nnT'), bloqueado: true, motivo_bloqueo: val('nnM') }), 'Agregado a no deseados'); cerrar(); vHues(); }

// ======================================================================
// Mantenimiento y limpieza: tickets con evidencia (habitaciones y áreas comunes)
// ======================================================================
let mTipo = '';
const TIPO_T = { reparacion: ['Reparación', 'p-warn'], limpieza: ['Limpieza', 'p-info'] };
vMant = async function () {
  const tq = mTipo ? '&tipo=' + mTipo : '';
  const l = await GET(mTab === 'abiertos' ? '/api/mant?x=1' + tq : `/api/mant?estado=terminados&desde=${mDesde}&hasta=${mHasta}${tq}`);
  if (mTab === 'abiertos') { ir.badge = { ...(ir.badge || {}), mant: l.length || '' }; pintarNav(ir.badge); }
  const lugar = (m) => (m.numero ? (m.clase === 'departamento' ? 'Depto. ' : m.clase === 'local' ? 'Local ' : 'Hab. ') + esc(m.numero) : esc(m.area || 'Área común'));
  $('#main').innerHTML = cab('Mantenimiento y limpieza', mTab === 'abiertos' ? `${l.length} pendiente(s) · se actualiza sola` : 'Tickets terminados',
    puede('mant_reportar') ? `<button class="btn op" onclick="mantNuevo(undefined,'limpieza')">${ico('camara')} Ticket de limpieza</button><button class="btn pri op" onclick="mantNuevo()">${ico('camara')} Reportar desperfecto</button>` : '')
    + `<div class="tabs"><button class="${mTab === 'abiertos' ? 'on' : ''}" onclick="mTab='abiertos';vMant()">Pendientes</button><button class="${mTab === 'terminados' ? 'on' : ''}" onclick="mTab='terminados';vMant()">Terminados</button>
      ${mTab === 'terminados' ? `<input type="date" id="md" value="${mDesde}" style="width:auto"><input type="date" id="mh" value="${mHasta}" style="width:auto"><button class="btn sm" onclick="mDesde=val('md');mHasta=val('mh');vMant()">Ver</button>` : ''}</div>
    <div class="tabs" style="margin:8px 0 12px">${[['', 'Todos'], ['reparacion', 'Reparaciones'], ['limpieza', 'Limpieza']].map(([k, n]) => `<button class="${mTipo === k ? 'on' : ''}" onclick="mTipo='${k}';vMant()">${n}</button>`).join('')}</div>
    <div class="mgrid">${l.map((m) => { const tp = TIPO_T[m.tipo === 'limpieza' ? 'limpieza' : 'reparacion']; return `<button class="mcard" onclick="verMant(${m.id})">${m.foto ? `<img src="fotos/${encodeURIComponent(m.foto)}" alt="foto" loading="lazy">` : `<div class="msin">${ico(m.tipo === 'limpieza' ? 'cama' : 'llave')}</div>`}
      <div class="mbody2"><div class="row" style="gap:6px;flex-wrap:wrap"><span class="pill ${tp[1]}">${tp[0]}</span><span class="pill ${EMANT[m.estado][1]}">${EMANT[m.estado][0]}</span>${m.tipo !== 'limpieza' ? `<span class="pill ${PRIO[m.prioridad][1]}">${PRIO[m.prioridad][0]}</span>` : ''}</div>
      <b>${esc(m.titulo)}</b><span class="sub">${lugar(m)} · Folio ${esc(m.folio)}</span>
      <span class="sub">${m.estado === 'terminado' ? `${m.tipo === 'limpieza' ? 'Limpio' : 'Reparado'} en ${hace(m.alta, m.cierre)}${m.cierre_nombre ? ' por ' + esc(m.cierre_nombre) : ''}` : `Levantado hace ${hace(m.alta)}${m.alta_nombre ? ' por ' + esc(m.alta_nombre) : ' (automático)'}${m.atiende_nombre ? ` · Atiende ${esc(m.atiende_nombre)}` : ''}`}</span>
      <span class="sub">${ico('camara')} ${m.fotos_reporte} antes · ${m.fotos_evidencia} después</span></div></button>`; }).join('') || `<div class="card empty">${mTab === 'abiertos' ? 'No hay tickets pendientes.' : 'No hay tickets terminados en esas fechas.'}</div>`}</div>`;
};
mantNuevo = async function (habId, tipo) {
  if (!TAB || ES_PERSONAL()) TAB = { habitaciones: await GET('/api/habitaciones') };
  const limp = tipo === 'limpieza';
  modal(limp ? 'Ticket de limpieza' : 'Reportar desperfecto', `<div class="seg"><label><input type="radio" name="nTp" value="reparacion" ${limp ? '' : 'checked'} onchange="nTipoCambio()">Reparación</label><label><input type="radio" name="nTp" value="limpieza" ${limp ? 'checked' : ''} onchange="nTipoCambio()">Limpieza</label></div><input type="hidden" id="nTipo" value="${limp ? 'limpieza' : 'reparacion'}">
    <div class="f"><label class="l">Dónde<select id="nH" onchange="$('#nAreaL').hidden=!!this.value">${'<option value="">Área común / otro</option>' + sortH(TAB.habitaciones).map((h) => `<option value="${h.id}" ${h.id === habId ? 'selected' : ''}>${esc(h.numero)}${h.nombre ? ' · ' + esc(h.nombre) : ''}</option>`).join('')}</select></label>
      <label class="l" id="nAreaL" ${habId ? 'hidden' : ''}>Área común<input id="nArea" placeholder="Ej. lobby, pasillo piso 2, escaleras, estacionamiento, alberca"></label>
      <label class="l" style="grid-column:1/-1"><span id="nTl">${limp ? 'Qué hay que limpiar' : 'Qué hay que reparar'}</span><input id="nT" placeholder="${limp ? 'Ej. limpieza profunda, derrame en el pasillo' : 'Ej. no enfría el aire acondicionado'}"></label></div>
    <label class="l">Detalles<textarea id="nD" rows="3" style="font-family:var(--fBody);font-size:14px;min-height:70px"></textarea></label>
    <div id="nPr" ${limp ? 'hidden' : ''}><div class="lbl">Prioridad</div><div class="seg">${Object.entries(PRIO).map(([k, [n]]) => `<label><input type="radio" name="nP" value="${k}" ${k === 'normal' ? 'checked' : ''}>${n}</label>`).join('')}</div></div>
    <div class="lbl">Fotos (antes)</div>${fotoInput('nuevo')}
    <label class="row" style="font-weight:600" id="nML" ${limp ? 'hidden' : ''}><input type="checkbox" id="nM" ${limp ? '' : 'checked'}> Poner la habitación en mantenimiento (si está desocupada)</label>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="mantNuevoOk()">Levantar ticket</button>`);
};
function nTipoCambio() {
  const l = document.querySelector('input[name=nTp]:checked').value === 'limpieza';
  $('#nTipo').value = l ? 'limpieza' : 'reparacion'; $('#nTl').textContent = l ? 'Qué hay que limpiar' : 'Qué hay que reparar';
  $('#nPr').hidden = l; $('#nML').hidden = l; if (l) $('#nM').checked = false;
}
{
  const _mc = mantCerrar;
  mantCerrar = async function (id) {
    const m = await GET('/api/mant/' + id);
    if (m.tipo !== 'limpieza') return _mc(id);
    modal('Marcar como limpio', `<label class="l">Qué se limpió<textarea id="cN" rows="3" style="font-family:var(--fBody);font-size:14px;min-height:70px">${m.habitacion_id ? 'Habitación limpia: cama, baño, piso y basura.' : ''}</textarea></label>
      <div class="lbl">Fotos de evidencia (cómo quedó)</div>${fotoInput('cierre')}${m.habitacion_id ? '<div class="sub">Al guardar, la habitación queda lista para rentar.</div>' : ''}
      <input type="hidden" id="cC" value=""><input type="hidden" id="cF" value="efectivo"><input type="checkbox" id="cG" hidden><input type="radio" name="cE" value="libre" checked hidden>`,
    `<button class="btn" onclick="verMant(${id})">Volver</button><button class="btn ok" onclick="mantCerrarOk(${id})">Guardar como limpio</button>`);
  };
}

// ======================================================================
// Bitácora de movimientos (solo administrador o usuarios autorizados)
// ======================================================================
let bDesde = hoyISO(), bHasta = hoyISO(), bUsr = '', bQ = '';
async function cBitacora() {
  const r = await GET(`/api/auditoria?desde=${bDesde}&hasta=${bHasta}&usuario_id=${bUsr}&q=${encodeURIComponent(bQ)}`); cBitacora.l = r.lista;
  $('#cfgc').innerHTML = `<div class="card"><div class="row" style="gap:8px;flex-wrap:wrap;align-items:flex-end;margin-bottom:10px">
      <label class="l" style="margin:0">Desde<input type="date" id="bD" value="${bDesde}"></label><label class="l" style="margin:0">Hasta<input type="date" id="bH" value="${bHasta}"></label>
      <label class="l" style="margin:0">Usuario<select id="bU"><option value="">Todos</option>${r.usuarios.map((u) => `<option value="${u.id}" ${String(u.id) === String(bUsr) ? 'selected' : ''}>${esc(u.nombre)}</option>`).join('')}</select></label>
      <label class="l" style="margin:0;flex:1;min-width:180px">Buscar<input id="bQ" value="${esc(bQ)}" placeholder="Ej. descuento, 101, egreso"></label>
      <button class="btn pri" onclick="bDesde=val('bD');bHasta=val('bH');bUsr=val('bU');bQ=val('bQ');cBitacora()">Ver</button><button class="btn" onclick="bitacoraExcel()">Excel</button></div>
    <p class="sub" style="margin-top:0">Todo lo que se hace en el sistema queda aquí con fecha, hora, usuario y detalle. Nadie lo puede borrar. ${r.lista.length} movimiento(s).</p>
    <div class="tw" style="max-height:62vh"><table><thead><tr><th>Fecha</th><th>Usuario</th><th>Qué hizo</th><th></th></tr></thead><tbody>
      ${r.lista.map((x, i) => `<tr><td style="white-space:nowrap">${tLargo(x.fecha)}</td><td>${esc(x.usuario || '')}</td><td>${esc(x.accion)}</td><td><button class="btn sm" onclick="bitDet(${i})">Detalle</button></td></tr>`).join('') || '<tr><td colspan="4" class="empty">Sin movimientos en esas fechas.</td></tr>'}</tbody></table></div></div>`;
}
function bitDet(i) {
  const x = cBitacora.l[i]; let d = x.detalle; try { d = JSON.stringify(JSON.parse(x.detalle), null, 2); } catch { /* texto */ }
  modal('Detalle del movimiento', `<div class="kv"><span>Fecha</span><span>${tLargo(x.fecha)}</span><span>Usuario</span><b>${esc(x.usuario || '')}</b><span>Qué hizo</span><span>${esc(x.accion)}</span><span>Desde</span><span class="mono">${esc(x.ip || '')}</span><span>Ruta</span><span class="mono">${esc(x.ruta)}</span></div><pre class="mono" style="white-space:pre-wrap;font-size:12px;background:var(--panel2);padding:10px;border-radius:8px;max-height:300px;overflow:auto">${esc(d)}</pre>`,
    '<button class="btn" onclick="cerrar()">Cerrar</button>');
}
function bitacoraExcel() {
  const filas = [H_('Fecha', 'Usuario', 'Qué hizo', 'Desde', 'Detalle'), ...(cBitacora.l || []).map((x) => [tLargo(x.fecha), x.usuario || '', x.accion, x.ip || '', x.detalle])];
  descargarArchivo(XLSX.libro([{ nombre: 'Bitácora', filas }]), `Bitácora ${bDesde} a ${bHasta} - ${CFG.hotel_nombre}.xlsx`);
}

// ======================================================================
// Usuarios: descuento máximo de cada usuario
// ======================================================================
{
  const _um = userModal;
  userModal = function (id) {
    _um(id);
    const u = id ? (cUsers.l || []).find((x) => x.id === id) : {};
    $('#uR')?.closest('.f')?.insertAdjacentHTML('afterend', `<div class="card" style="padding:12px;margin:6px 0"><div class="lbl" style="margin-bottom:6px">Descuentos que puede hacer al rentar</div>
      <div class="f"><label class="l">Hasta (%)<input id="uDp" type="number" min="0" max="100" step="0.5" value="${Number(u?.desc_max_pct) || 0}"></label><label class="l">Hasta (pesos)<input id="uDm" type="number" min="0" step="1" value="${Number(u?.desc_max_monto) || 0}"></label></div>
      <div class="sub">El % es el máximo cuando descuenta por porcentaje y los pesos cuando descuenta una cantidad. 0 = no puede de esa forma. El gerente y el administrador usan el máximo del hotel (Configuración → Hotel y colores). Siempre se pide el motivo.</div></div>`);
  };
  const _ch = cHotel;
  cHotel = async function (...a) {
    const r = await _ch.apply(this, a);
    if (puede('config')) ($('#cfgc .stack') || $('#cfgc'))?.insertAdjacentHTML('beforeend', `<div class="card"><h2>Descuentos al rentar</h2>
      <div class="f"><label class="l">Máximo del hotel (%)<input id="dxP" type="number" min="0" max="100" step="0.5" value="${esc(CFG.desc_max_pct ?? '30')}"></label><label class="l">Máximo del hotel (pesos, 0 = sin límite)<input id="dxM" type="number" min="0" step="1" value="${esc(CFG.desc_max_monto ?? '0')}"></label></div>
      <p class="sub">Solo el gerente y el administrador pueden llegar a este máximo. A cada recepcionista se le pone su propio límite en Usuarios y permisos. Siempre se pide el motivo y queda en el reporte.</p>
      <label class="row" style="font-weight:600"><input type="checkbox" id="tkL" ${CFG.tickets_limpieza !== '0' ? 'checked' : ''}> Levantar ticket de limpieza cada vez que una habitación queda en limpieza</label>
      <label class="row" style="font-weight:600"><input type="checkbox" id="tkF" ${CFG.limpieza_foto_obligatoria !== '0' ? 'checked' : ''}> Pedir foto de evidencia al terminar una limpieza y al recibir blancos de la lavandería</label>
      <div style="margin-top:8px"><button class="btn pri" onclick="descCfgOk()">Guardar</button></div></div>`);
    return r;
  };
}
async function descCfgOk() { await hacer(() => PUT('/api/config', { desc_max_pct: String(num('dxP')), desc_max_monto: String(num('dxM')), tickets_limpieza: $('#tkL').checked ? '1' : '0', limpieza_foto_obligatoria: $('#tkF').checked ? '1' : '0' }), 'Guardado'); CFG = await GET('/api/config'); DESC_LIM = null; }

// ======================================================================
// Carga de habitaciones con Excel: un Excel por unidad (hotel, locales, departamentos), "qué incluye" con Sí / No
// ======================================================================
const AMEN_X = { habitacion: ['wifi', 'tv', 'ac', 'ventilador', 'agua', 'minibar', 'jacuzzi', 'estacionamiento'], departamento: ['wifi', 'tv', 'ac', 'agua', 'cocina', 'parrilla', 'refri', 'micro', 'lavadora', 'estacionamiento', 'balcon', 'mascotas'], local: ['wifi', 'ac', 'agua', 'estacionamiento'] };
const claseDeUnidad = (u) => (/local/i.test(u) ? 'local' : /depart|depto|callej/i.test(u) ? 'departamento' : 'habitacion');
const COLS_X = {
  habitacion: [['Número', 'numero'], ['Nombre', 'nombre'], ['Piso', 'piso'], ['Camas individual', 'cama_individual'], ['Camas matrimonial', 'cama_matrimonial'], ['Camas queen', 'cama_queen'], ['Camas king', 'cama_king'], ['Capacidad', 'capacidad'], ['Precio rato', 'precio_rato'], ['Precio noche', 'precio_noche'], ['Precio día', 'precio_dia'], ['Precio semana', 'precio_semana'], ['Precio mes', 'precio_mes']],
  departamento: [['Número', 'numero'], ['Nombre', 'nombre'], ['Piso', 'piso'], ['Recámaras', 'recamaras'], ['Baños', 'banos'], ['Camas individual', 'cama_individual'], ['Camas matrimonial', 'cama_matrimonial'], ['Camas queen', 'cama_queen'], ['Capacidad', 'capacidad'], ['Precio semana', 'precio_semana'], ['Precio mes', 'precio_mes']],
  local: [['Número', 'numero'], ['Nombre o giro', 'nombre'], ['Piso', 'piso'], ['Baños', 'banos'], ['Precio semana', 'precio_semana'], ['Precio mes', 'precio_mes']],
};
const EJ_X = {
  habitacion: [['101', 'Sencilla', '1', 0, 1, 0, 0, 2, 250, 450, 550, 3200, 9500, 'Sí', 'Sí', 'Sí', 'No', 'Sí', 'No', 'No', 'Sí'], ['102', 'Doble', '1', 0, 2, 0, 0, 4, 300, 600, 750, 4300, 12500, 'Sí', 'Sí', 'Sí', 'No', 'Sí', 'No', 'No', 'Sí']],
  departamento: [['C1', 'Depto. 1 recámara', '1', 1, 1, 0, 0, 1, 3, 2000, 6500, 'Sí', 'Sí', 'No', 'Sí', 'Sí', 'Sí', 'Sí', 'Sí', 'No', 'Sí', 'No', 'No'], ['C2', 'Depto. 2 recámaras', '1', 2, 1, 1, 1, 0, 4, 2600, 8500, 'Sí', 'Sí', 'Sí', 'Sí', 'Sí', 'Sí', 'Sí', 'Sí', 'Sí', 'Sí', 'No', 'Sí']],
  local: [['L1', 'Farmacia', 'PB', 1, '', 9000, 'No', 'No', 'Sí', 'Sí'], ['L2', 'Taquería', 'PB', 1, '', 11000, 'No', 'No', 'Sí', 'Sí']],
};
const siNo = (v) => /^(s[ií]|si|x|1|true|yes|y)$/i.test(String(v || '').trim());
importarModal = async function (unidad) {
  importarModal.ex = new Map((await GET('/api/habitaciones')).map((h) => [String(h.numero).toLowerCase(), h]));
  const unidades = unidadesCfg();
  if (!unidad) {
    return modal('Cargar habitaciones con Excel', `<p class="sub" style="margin-top:0">Cada unidad tiene su propio Excel sencillo. Lo que incluye cada una se marca con <b>Sí</b> o <b>No</b>. Para cambiar lo que ya tiene, baje su Excel, cambie y vuelva a cargarlo.</p>
      <div class="stack" style="gap:10px">${unidades.map((u) => `<div class="card" style="padding:12px"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px"><div><b>${esc(u)}</b><div class="sub">${({ habitacion: 'Habitaciones', departamento: 'Departamentos', local: 'Locales comerciales' })[claseDeUnidad(u)]} · ${[...importarModal.ex.values()].filter((h) => unidadDe(h) === u).length} cargadas</div></div>
        <div class="row" style="gap:6px;flex-wrap:wrap"><button class="btn sm" onclick="plantillaUnidad(this.dataset.u,false)" data-u="${esc(u)}">Excel vacío</button><button class="btn sm" onclick="plantillaUnidad(this.dataset.u,true)" data-u="${esc(u)}">Bajar las que tengo</button><button class="btn sm pri" onclick="importarModal(this.dataset.u)" data-u="${esc(u)}">Cargar Excel</button></div></div></div>`).join('')}</div>`,
    '<button class="btn" onclick="cerrar()">Cerrar</button>', true);
  }
  const clase = claseDeUnidad(unidad);
  importarModal.unidad = unidad; importarModal.clase = clase;
  modal(`Cargar ${esc(unidad)} con Excel`, `
    <p class="sub" style="margin:0">Todas se guardan como <b>${({ habitacion: 'Habitación', departamento: 'Departamento', local: 'Local comercial' })[clase]}</b> de <b>${esc(unidad)}</b>. Solo el Número es obligatorio.</p>
    <div class="row" style="flex-wrap:wrap;gap:8px"><button class="btn" onclick="plantillaUnidad(importarModal.unidad,false)">Excel vacío</button><button class="btn" onclick="plantillaUnidad(importarModal.unidad,true)">Bajar las que tengo</button>
      <label class="btn pri" style="cursor:pointer">Elegir archivo (.xlsx o .csv)<input type="file" accept=".xlsx,.csv,.txt" hidden onchange="archivoImp(this.files[0])"></label></div>
    <label class="l">O copie las celdas en Excel y péguelas aquí<textarea id="iP" rows="3" oninput="clearTimeout(importarModal.t);importarModal.t=setTimeout(()=>prevImp(leerTexto(this.value)),300)"></textarea></label>
    <label class="l">Si el número ya existe<select id="iEx" onchange="prevImp()"><option value="actualizar">Actualizarla con los datos del Excel</option><option value="saltar">Dejarla como está</option></select></label>
    <div id="iPrev"></div>`,
  `<button class="btn" onclick="importarModal()">Atrás</button><button class="btn pri" id="iOk" disabled onclick="importarOk()">Importar</button>`, true);
  $('#modal .mbox').classList.add('extra');
};
function plantillaUnidad(unidad, conDatos) {
  const clase = claseDeUnidad(unidad), cols = COLS_X[clase], am = AMEN_X[clase];
  const cab = [...cols.map((c) => c[0]), ...am.map((k) => AMEN[k])];
  let filas;
  if (conDatos) {
    filas = [...(importarModal.ex?.values() || [])].filter((h) => unidadDe(h) === unidad).sort((a, b) => String(a.numero).localeCompare(String(b.numero), 'es', { numeric: true }))
      .map((h) => [...cols.map(([, k]) => (k.startsWith('cama_') ? h.camas?.[k.slice(5)] || 0 : h[k] ?? '')), ...am.map((k) => ((h.amenidades || []).includes(k) ? 'Sí' : 'No'))]);
    if (!filas.length) return toast('Todavía no hay ninguna en ' + unidad, true);
  } else filas = EJ_X[clase];
  descargarArchivo(XLSX.libro([{ nombre: unidad.slice(0, 30), filas: [H_(...cab), ...filas] }]), `${conDatos ? '' : 'Plantilla '}${unidad} - Maxsel Hotel.xlsx`);
  toast('Excel descargado (carpeta Descargas)');
}
{
  // Convierte las columnas Sí / No de "qué incluye" en la lista que entiende la carga, y pone la unidad y el tipo
  const _prev = prevImp;
  prevImp = function (filas) {
    if (filas && importarModal.unidad && filas.length) {
      const cab = filas[0].map((x) => String(x || '').trim()), amIdx = [];
      cab.forEach((c, i) => { const k = Object.keys(AMEN).find((a) => normT(AMEN[a]) === normT(c) || normT(a) === normT(c)); if (k) amIdx.push([i, k]); });
      const fuera = new Set(amIdx.map((x) => x[0]));
      const ncab = [...cab.filter((_, i) => !fuera.has(i)), ...(amIdx.length ? ['Incluye'] : []), 'Tipo (Habitación, Departamento o Local)', 'Unidad de negocio'];
      const tipoTxt = ({ habitacion: 'Habitación', departamento: 'Departamento', local: 'Local' })[importarModal.clase];
      filas = [ncab, ...filas.slice(1).map((f) => [...f.filter((_, i) => !fuera.has(i)), ...(amIdx.length ? [amIdx.filter(([i]) => siNo(f[i])).map(([, k]) => AMEN[k]).join(', ')] : []), tipoTxt, importarModal.unidad])];
      prevImp.sinAmen = !amIdx.length;
    }
    return _prev(filas);
  };
  const _cerrar = cerrar;
  cerrar = function (...a) { importarModal.unidad = null; return _cerrar.apply(this, a); };
}

// ======================================================================
// Reportes, cierre, PDF y Excel: cambios de habitación y descuentos
// ======================================================================
function v110HTML(X) {
  const C = X.cambios || [], D = X.descuentos;
  return `<div class="cols" style="margin-bottom:16px"><div class="card"><h2>Cambios de habitación · ${C.length}</h2>${C.length ? `<div class="tw" style="max-height:300px"><table><thead><tr><th>Fecha</th><th>Huésped</th><th>Llegó a</th><th>De → A</th><th>Motivo</th><th>Usuario</th></tr></thead><tbody>${C.map((c) => `<tr><td>${fdt(c.fecha)}</td><td>${esc(c.huesped)}</td><td>${esc(c.inicial || '')}</td><td><b>${esc(c.de_num)}</b> → <b>${esc(c.a_num)}</b></td><td>${esc(c.motivo || '')}</td><td>${esc(c.usuario || '')}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">Sin cambios de habitación.</div>'}</div>
    <div class="card"><h2>Descuentos · ${money(D?.total || 0)}</h2>${D && D.n ? `<div class="kv">${D.por_usuario.map((u) => `<span>${esc(u.usuario)} (${u.n})</span><b>${money(u.total)}</b>`).join('')}</div><div class="tw" style="max-height:240px;margin-top:8px"><table><thead><tr><th>Fecha</th><th>Hab.</th><th>Huésped</th><th>Motivo</th><th>Usuario</th><th class="n">Descuento</th></tr></thead><tbody>${D.lista.map((x) => `<tr><td>${fdt(x.fecha)}</td><td>${esc(x.numero || '')}</td><td>${esc(x.huesped)}</td><td>${esc(x.descuento_motivo || '')}</td><td>${esc(x.usuario || '')}</td><td class="n">${money(x.descuento)}${x.descuento_tipo === 'pct' ? ` <span class="sub">(${x.descuento_valor}%)</span>` : ''}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">Sin descuentos en el periodo.</div>'}</div></div>`;
}
{
  const _ex = extrasHTML;
  extrasHTML = function (X, titulo) { return _ex(X, titulo) + (X.cambios || X.descuentos ? v110HTML(X) : ''); };
  const _pdf = pdfExtras;
  pdfExtras = function (C) {
    const X = C.extra || {}, D = X.descuentos;
    return _pdf(C) + (X.cambios?.length ? `<h3>Cambios de habitación (${X.cambios.length})</h3><table><thead><tr><th>Fecha</th><th>Huésped</th><th>Llegó a</th><th>De</th><th>A</th><th>Motivo</th><th>Usuario</th></tr></thead><tbody>${X.cambios.map((c) => `<tr><td>${fdt(c.fecha)}</td><td>${esc(c.huesped)}</td><td>${esc(c.inicial || '')}</td><td>${esc(c.de_num)}</td><td>${esc(c.a_num)}</td><td>${esc(c.motivo || '')}</td><td>${esc(c.usuario || '')}</td></tr>`).join('')}</tbody></table>` : '')
      + (D?.n ? `<h3>Descuentos (${D.n}) · ${money(D.total)}</h3><table><thead><tr><th>Fecha</th><th>Hab.</th><th>Huésped</th><th>Motivo</th><th>Usuario</th><th class="n">Descuento</th></tr></thead><tbody>${D.lista.map((x) => `<tr><td>${fdt(x.fecha)}</td><td>${esc(x.numero || '')}</td><td>${esc(x.huesped)}</td><td>${esc(x.descuento_motivo || '')}</td><td>${esc(x.usuario || '')}</td><td class="n">${money(x.descuento)}</td></tr>`).join('')}</tbody></table>` : '');
  };
  const _hj = hojasExtras;
  hojasExtras = function (X) {
    const out = _hj(X);
    if (X.cambios) out.push({ nombre: 'Cambios de habitación', filas: [H_('Fecha', 'Folio', 'Huésped', 'Llegó a', 'De', 'A', 'Motivo', 'Usuario'), ...X.cambios.map((c) => [fdt(c.fecha), c.folio, c.huesped, c.inicial || '', c.de_num, c.a_num, c.motivo || '', c.usuario || ''])] });
    if (X.descuentos) out.push({ nombre: 'Descuentos', filas: [H_('Fecha', 'Folio', 'Hab.', 'Huésped', 'Tipo', 'Valor', 'Descuento', 'Motivo', 'Usuario'), ...X.descuentos.lista.map((x) => [fdt(x.fecha), x.folio, x.numero || '', x.huesped, x.descuento_tipo === 'pct' ? '%' : '$', x.descuento_valor, M_(x.descuento), x.descuento_motivo || '', x.usuario || '']), [], [B_('Total'), '', '', '', '', '', BM_(X.descuentos.total)]] });
    return out;
  };
}
