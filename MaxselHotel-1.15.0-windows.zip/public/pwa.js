// Maxsel Hotel 1.14 — app web para el celular: /mantenimiento y /limpieza se pueden "instalar" en la pantalla de inicio
(() => {
  const p = location.pathname.replace(/\/+$/, '');
  const k = p === '/limpieza' ? 'limpieza' : p === '/mantenimiento' ? 'mantenimiento' : null;
  window.APP_PERSONAL = k;
  const nombre = k === 'limpieza' ? 'Maxsel Limpieza' : k === 'mantenimiento' ? 'Maxsel Mantenimiento' : 'Maxsel Hotel';
  const add = (tag, at) => { const e = document.createElement(tag); for (const [a, v] of Object.entries(at)) e.setAttribute(a, v); document.head.appendChild(e); };
  add('link', { rel: 'manifest', href: '/manifest-' + (k || 'hotel') + '.webmanifest' });
  add('meta', { name: 'apple-mobile-web-app-capable', content: 'yes' });
  add('meta', { name: 'mobile-web-app-capable', content: 'yes' });
  add('meta', { name: 'apple-mobile-web-app-title', content: nombre });
  document.title = nombre;
})();
