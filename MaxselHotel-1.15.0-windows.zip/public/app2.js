// Maxsel Hotel 1.1 — gastos, depósitos, contratos, mantenimiento, impresión con firmas
'use strict';

// ---------- Impresión: ticket 58/80 mm o carta (PDF) ----------
function imprimirDoc(html, formato, titulo) {
  const t = $('#ticket'); t.innerHTML = `<div class="doc f-${formato}">${html}</div>`;
  let st = document.getElementById('pagina'); if (!st) { st = document.createElement('style'); st.id = 'pagina'; document.head.appendChild(st); }
  st.textContent = formato === 'carta' ? '@page{size:letter;margin:12mm}' : '@page{margin:2mm}';
  modal(titulo || 'Imprimir', `<div class="prev"><div class="doc f-${formato}">${html}</div></div>${formato === 'carta' ? '<div class="sub">Para guardar como PDF: en la ventana de impresión elija la impresora <b>"Guardar como PDF"</b> o <b>"Microsoft Print to PDF"</b>.</div>' : ''}`,
    `<button class="btn" onclick="cerrar()">Cerrar</button><button class="btn pri" onclick="window.print()">${formato === 'carta' ? 'Imprimir / Guardar PDF' : 'Imprimir'}</button>`, formato === 'carta');
}
const ancho = () => (CFG.ticket_ancho === '58' ? '58' : '80');
const encHTML = () => `<div class="dc-enc"><b>${esc(CFG.hotel_nombre)}</b>${CFG.hotel_direccion ? `<span>${esc(CFG.hotel_direccion)}</span>` : ''}${CFG.hotel_telefono ? `<span>Tel. ${esc(CFG.hotel_telefono)}</span>` : ''}</div>`;
const firmaHTML = (img, rol, nombre) => `<div class="dc-firma">${img ? `<img src="${img}" alt="firma">` : '<div class="dc-sinfirma"></div>'}<div class="dc-linea"></div><b>${esc(rol)}</b><span>${esc(nombre || '')}</span></div>`;
const fLarga = (s) => { const d = s ? aF(s.length <= 10 ? s + ' 00:00:00' : s) : new Date(); return d.toLocaleDateString('es-MX', { day: 'numeric', month: 'long', year: 'numeric' }); };

// ---------- Número a letras (pesos mexicanos) ----------
function numeroALetras(n) {
  const U = ['', 'UN', 'DOS', 'TRES', 'CUATRO', 'CINCO', 'SEIS', 'SIETE', 'OCHO', 'NUEVE', 'DIEZ', 'ONCE', 'DOCE', 'TRECE', 'CATORCE', 'QUINCE', 'DIECISÉIS', 'DIECISIETE', 'DIECIOCHO', 'DIECINUEVE', 'VEINTE', 'VEINTIÚN', 'VEINTIDÓS', 'VEINTITRÉS', 'VEINTICUATRO', 'VEINTICINCO', 'VEINTISÉIS', 'VEINTISIETE', 'VEINTIOCHO', 'VEINTINUEVE'];
  const D = ['', '', '', 'TREINTA', 'CUARENTA', 'CINCUENTA', 'SESENTA', 'SETENTA', 'OCHENTA', 'NOVENTA'];
  const C = ['', 'CIENTO', 'DOSCIENTOS', 'TRESCIENTOS', 'CUATROCIENTOS', 'QUINIENTOS', 'SEISCIENTOS', 'SETECIENTOS', 'OCHOCIENTOS', 'NOVECIENTOS'];
  const cien = (x) => { if (x === 100) return 'CIEN'; const c = Math.floor(x / 100), r = x % 100; let t = C[c]; if (r) t += (t ? ' ' : '') + (r < 30 ? U[r] : D[Math.floor(r / 10)] + (r % 10 ? ' Y ' + U[r % 10] : '')); return t; };
  const mil = (x) => { const m = Math.floor(x / 1000), r = x % 1000; return (m ? (m === 1 ? 'MIL' : cien(m) + ' MIL') : '') + (r ? (m ? ' ' : '') + cien(r) : ''); };
  n = Math.round((Number(n) || 0) * 100) / 100; const ent = Math.floor(n), cts = Math.round((n - ent) * 100);
  const mill = Math.floor(ent / 1e6), rest = ent % 1e6;
  let t = (mill ? (mill === 1 ? 'UN MILLÓN' : mil(mill) + ' MILLONES') + (rest ? ' ' : (rest === 0 ? ' DE' : '')) : '') + (rest ? mil(rest) : '');
  if (!ent) t = 'CERO';
  return `${t} ${ent === 1 ? 'PESO' : 'PESOS'} ${String(cts).padStart(2, '0')}/100 M.N.`;
}

// ---------- Firma en pantalla ----------
function padHTML(id, etiqueta) { return `<div class="padf"><div class="row" style="justify-content:space-between"><span class="lbl">${etiqueta}</span><button type="button" class="btn sm" onclick="padBorrar('${id}')">Borrar</button></div><canvas id="${id}" width="600" height="190"></canvas><span class="sub">Firme con el dedo o el mouse</span></div>`; }
function padIniciar(id) {
  const c = document.getElementById(id); if (!c) return;
  const x = c.getContext('2d'); x.lineWidth = 2.6; x.lineCap = 'round'; x.lineJoin = 'round'; x.strokeStyle = '#111';
  let dib = false; const pos = (e) => { const r = c.getBoundingClientRect(); return [(e.clientX - r.left) * c.width / r.width, (e.clientY - r.top) * c.height / r.height]; };
  c.onpointerdown = (e) => { dib = true; c.setPointerCapture(e.pointerId); x.beginPath(); x.moveTo(...pos(e)); };
  c.onpointermove = (e) => { if (!dib) return; x.lineTo(...pos(e)); x.stroke(); c.dataset.firmado = '1'; };
  c.onpointerup = c.onpointercancel = () => { dib = false; };
}
function padBorrar(id) { const c = document.getElementById(id); c.getContext('2d').clearRect(0, 0, c.width, c.height); delete c.dataset.firmado; }
const padValor = (id) => { const c = document.getElementById(id); return c && c.dataset.firmado ? c.toDataURL('image/png') : null; };

// ---------- Fotos (se achican antes de subir) ----------
const FOTOS = {};
function fotoInput(key) { FOTOS[key] = []; return `<label class="btn" style="width:fit-content">${ico('camara')} Agregar fotos<input type="file" accept="image/*" multiple hidden onchange="fotosElegidas('${key}',this)"></label><div class="fotos" id="fp_${key}"></div>`; }
async function fotosElegidas(key, inp) {
  for (const f of [...inp.files].slice(0, 8 - FOTOS[key].length)) {
    try {
      const img = await new Promise((ok, mal) => { const i = new Image(); i.onload = () => ok(i); i.onerror = mal; i.src = URL.createObjectURL(f); });
      const k = Math.min(1, 1400 / Math.max(img.width, img.height)), c = document.createElement('canvas');
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      FOTOS[key].push(c.toDataURL('image/jpeg', 0.75)); URL.revokeObjectURL(img.src);
    } catch { toast('No se pudo leer una de las fotos', true); }
  }
  inp.value = ''; pintarFotos(key);
}
function pintarFotos(key) { const el = $('#fp_' + key); if (el) el.innerHTML = FOTOS[key].map((f, i) => `<span class="fmini"><img src="${f}" alt="foto"><button type="button" onclick="FOTOS['${key}'].splice(${i},1);pintarFotos('${key}')" aria-label="Quitar">×</button></span>`).join(''); }
P.camara = '<path d="M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/>';
P.llave = '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18v3h3l6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z"/>';

// ---------- Depósitos ----------
function depModal(id) { modal('Recibir depósito en garantía', `<div class="f"><label class="l">Monto<input id="dM" type="number" min="0" step="0.01"></label><div class="l">Método de pago${selPago('dF', null, '', 'dM')}</div></div>`, `<button class="btn" onclick="verEstancia(${id})">Volver</button><button class="btn pri" onclick="depOk(${id})">Guardar depósito</button>`); }
async function depOk(id) { const r = await hacer(() => POST(`/api/estancias/${id}/deposito`, { monto: val('dM'), ...pagoDe('dF') }), 'Depósito recibido'); vHab(); pintarTurno(); imprimirDeposito(r.id); }
async function liquidarModal(id, alSalir) {
  const e = await GET('/api/estancias/' + id);
  modal(`Depósito de ${esc(e.huesped)}`, `${alSalir ? '<div class="aviso ok">Salida registrada. Ahora revise la habitación y liquide el depósito.</div>' : ''}
    <div class="calc"><span>Depósito en resguardo</span><b class="big">${money(e.deposito_saldo)}</b></div>
    <div class="lbl">Retención por daños o faltantes</div>
    <div class="f"><label class="l">Monto a retener<input id="lR" type="number" min="0" step="0.01" value="0" oninput="lCalc(${e.deposito_saldo})"></label><label class="l" style="grid-column:span 2">Motivo<input id="lMo" placeholder="Ej. pared manchada, control de TV faltante"></label></div>
    <label class="row" style="font-weight:600"><input type="checkbox" id="lTk" checked> Crear reporte de mantenimiento para reparar los daños</label>
    <div class="lbl">Devolución al huésped</div>
    <div class="f"><label class="l">Monto a devolver<input id="lD" type="number" min="0" step="0.01" value="${e.deposito_saldo.toFixed(2)}"></label><label class="l">Se devuelve en${selPago('lF', null, 'sinusd')}</label><label class="l">Recibe<input id="lRe" value="${esc(e.huesped)}"></label></div>
    ${padHTML('lFirma', 'Firma de quien recibe la devolución')}`,
  `<button class="btn" onclick="${alSalir ? `imprimirEstancia(${id},'SALIDA')` : `verEstancia(${id})`}">Después</button><button class="btn pri" onclick="liquidarOk(${id})">Guardar</button>`);
  padIniciar('lFirma');
}
function lCalc(saldo) { $('#lD').value = Math.max(0, saldo - num('lR')).toFixed(2); }
async function liquidarOk(id) {
  const r = await hacer(() => POST(`/api/estancias/${id}/deposito/liquidar`, { retener: val('lR'), motivo: val('lMo'), crear_reporte: $('#lTk').checked, devolver: val('lD'), metodo: val('lF'), recibe: val('lRe'), firma: padValor('lFirma') }), 'Depósito liquidado');
  vHab(); pintarTurno(); imprimirDeposito(r.devuelto || r.retenido);
}
async function imprimirDeposito(id, formato) {
  const d = await GET('/api/depositos/' + id), e = d.estancia, h = d.habitacion;
  const T = { recibido: 'RECIBO DE DEPÓSITO EN GARANTÍA', devuelto: 'COMPROBANTE DE DEVOLUCIÓN DE DEPÓSITO', retenido: 'COMPROBANTE DE RETENCIÓN DE DEPÓSITO' }[d.tipo];
  const ret = d.movimientos.filter((m) => m.tipo === 'retenido');
  const cuerpo = (copia) => `<div class="dc">${encHTML()}<div class="dc-tit">${T}</div><div class="dc-copia">${copia}</div>
    <div class="dc-kv"><span>Folio</span><b>${esc(d.folio || d.id)}</b><span>Fecha</span><b>${fdt(d.fecha)}</b><span>${h.clase === 'departamento' ? 'Departamento' : 'Habitación'}</span><b>${esc(h.numero)}</b><span>Huésped</span><b>${esc(e.huesped)}</b>
    ${d.metodo ? `<span>Forma</span><b>${MET[d.metodo]}</b>` : ''}</div>
    <div class="dc-monto">${money(d.monto)}<small>${numeroALetras(d.monto)}</small></div>
    ${d.tipo !== 'recibido' ? `<div class="dc-kv"><span>Depósito recibido</span><b>${money(e.deposito)}</b>${ret.map((m) => `<span>Retenido: ${esc(m.motivo || '')}</span><b>${money(m.monto)}</b>`).join('')}<span>Devuelto</span><b>${money(e.deposito_devuelto)}</b><span>Queda en resguardo</span><b>${money(e.deposito_saldo)}</b></div>` : ''}
    ${d.tipo === 'retenido' ? `<p class="dc-nota">Se retiene esta cantidad del depósito en garantía para cubrir: ${esc(d.motivo || '')}.</p>` : ''}
    <div class="dc-firmas">${firmaHTML(null, d.tipo === 'devuelto' ? 'Entrega' : 'Recibe', d.usuario || CFG.hotel_nombre)}${firmaHTML(d.tipo === 'devuelto' ? d.firma : null, d.tipo === 'devuelto' ? 'Recibe' : 'Entrega', d.tipo === 'devuelto' ? (d.recibe || e.huesped) : e.huesped)}</div></div>`;
  docConCopia(cuerpo, formato, T, (c) => opsDeposito(d, c));
}
// Original y copia: en ticket una tras otra; en carta, media hoja cada una
function docConCopia(cuerpo, formato, titulo) {
  const f = formato || ancho();
  const html = f === 'carta' ? `<div class="mitad">${cuerpo('ORIGINAL')}</div><div class="corte">✂ - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -</div><div class="mitad">${cuerpo('COPIA')}</div>`
    : `${cuerpo('ORIGINAL')}<div class="corte">- - - - - - corte - - - - - -</div>${cuerpo('COPIA')}`;
  imprimirDoc(html, f, titulo);
  const pie = $('#modal footer');
  if (pie) pie.insertAdjacentHTML('afterbegin', `<button class="btn" onclick="cambiarFormato()">${f === 'carta' ? 'Ver en ticket' : 'Ver en hoja carta (PDF)'}</button>`);
  cambiarFormato.fn = () => { const otro = f === 'carta' ? ancho() : 'carta'; docConCopia(cuerpo, otro, titulo); };
}
function cambiarFormato() { cambiarFormato.fn && cambiarFormato.fn(); }

// ---------- Gastos ----------
let gDesde = hoyISO(), gHasta = hoyISO();
// Clasificación de gastos (1.5): "Clasificación: concepto, concepto" por renglón
const clasif = () => String(CFG.gastos_clasificacion || 'Otros: Otros gastos').split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((l) => {
  const i = l.indexOf(':'); return { grupo: (i >= 0 ? l.slice(0, i) : l).trim(), conceptos: (i >= 0 ? l.slice(i + 1) : '').split(',').map((x) => x.trim()).filter(Boolean) };
}).filter((g) => g.grupo);
const categorias = () => clasif().flatMap((g) => g.conceptos.length ? g.conceptos : [g.grupo]);
// Lista desplegable agrupada; si el valor actual no existe se agrega al final
function selCategoria(id, actual) {
  const C = clasif(), hay = C.some((g) => g.conceptos.includes(actual) || g.grupo === actual);
  return `<select id="${id}">${C.map((g) => `<optgroup label="${esc(g.grupo)}">${(g.conceptos.length ? g.conceptos : [g.grupo]).map((c) => `<option data-g="${esc(g.grupo)}" ${c === actual ? 'selected' : ''}>${esc(c)}</option>`).join('')}</optgroup>`).join('')}${actual && !hay ? `<option data-g="" selected>${esc(actual)}</option>` : ''}</select>`;
}
const grupoSel = (id) => document.getElementById(id)?.selectedOptions[0]?.dataset.g || '';
let gGrupo = '';
async function vGastos() {
  const todos = await GET(`/api/gastos?desde=${gDesde}&hasta=${gHasta}`), l = gGrupo ? todos.filter((g) => (g.grupo || 'Otros') === gGrupo) : todos;
  const act = l.filter((g) => !g.cancelado), tot = act.reduce((s, g) => s + g.monto, 0), totTodos = todos.filter((g) => !g.cancelado).reduce((s, g) => s + g.monto, 0);
  const porG = {}; todos.filter((g) => !g.cancelado).forEach((g) => { const k = g.grupo || 'Otros', x = porG[k] || (porG[k] = { t: 0, n: 0, c: {} }); x.t += g.monto; x.n++; x.c[g.categoria || 'Otros'] = (x.c[g.categoria || 'Otros'] || 0) + g.monto; });
  const orden = [...clasif().map((g) => g.grupo), ...Object.keys(porG)].filter((k, i, a) => porG[k] && a.indexOf(k) === i);
  $('#main').innerHTML = cab('Gastos', 'Salidas de dinero con recibo firmado', `<input type="date" id="gd" value="${gDesde}" style="width:auto"><input type="date" id="gh" value="${gHasta}" style="width:auto"><button class="btn" onclick="gDesde=val('gd');gHasta=val('gh');vGastos()">Ver</button><button class="btn pri op" onclick="gastoModal()">Nuevo gasto</button>`)
    + `<div class="kpis"><button class="kpi kpib ${gGrupo ? '' : 'on'}" onclick="gGrupo='';vGastos()"><span>Total de gastos</span><b>${money(totTodos)}</b><div class="sub">${todos.filter((g) => !g.cancelado).length} gasto(s) · ver todos</div></button>
      ${orden.map((k) => `<button class="kpi kpib ${gGrupo === k ? 'on' : ''}" onclick="gGrupo=${esc(JSON.stringify(k))};vGastos()"><span>${esc(k)}</span><b>${money(porG[k].t)}</b><div class="sub">${porG[k].n} gasto(s) · ${totTodos ? Math.round(porG[k].t / totTodos * 100) : 0}%</div></button>`).join('')}</div>
    ${gGrupo && porG[gGrupo] ? `<div class="card" style="margin-bottom:16px"><h2>${esc(gGrupo)} · por concepto</h2><div class="kv">${Object.entries(porG[gGrupo].c).sort((a, b) => b[1] - a[1]).map(([c, v]) => `<span>${esc(c)}</span><b>${money(v)}</b>`).join('')}</div></div>` : ''}
    <div class="card"><div class="tw"><table><thead><tr><th>Folio</th><th>Fecha</th><th>Concepto</th><th>Clasificación</th><th>Recibió</th><th>Pago</th><th class="n">Monto</th><th></th></tr></thead><tbody>
    ${l.map((g) => `<tr class="click" style="${g.cancelado ? 'opacity:.5;text-decoration:line-through' : ''}" onclick="verGasto(${g.id})"><td class="mono">${esc(g.folio)}</td><td>${fdt(g.fecha)}</td><td><b>${esc(g.concepto)}</b>${g.numero ? `<div class="sub">Hab. ${esc(g.numero)}</div>` : ''}</td><td>${esc(g.grupo || 'Otros')}<div class="sub">${esc(g.categoria || '')}</div></td><td>${esc(g.recibe || '')}</td><td>${MET[g.metodo] || ''}</td><td class="n">${money(g.monto)}</td><td>${g.firmado ? '<span class="pill p-ok">Firmado</span>' : '<span class="pill p-warn">Sin firma</span>'}</td></tr>`).join('') || '<tr><td colspan="8" class="empty">No hay gastos en esas fechas.</td></tr>'}</tbody></table></div>
    ${gGrupo ? `<div class="row" style="justify-content:flex-end;margin-top:8px"><b>Total ${esc(gGrupo)}: ${money(tot)}</b></div>` : ''}</div>`;
}
async function gastoModal() {
  if (!TAB) TAB = await GET('/api/tablero');
  modal('Nuevo gasto', `<div class="f"><label class="l" style="grid-column:1/-1">Concepto<input id="xCo" placeholder="Ej. Compra de focos y pintura"></label>
    <label class="l">Clasificación del gasto${selCategoria('xCa', gGrupo ? (clasif().find((g) => g.grupo === gGrupo)?.conceptos[0] || '') : '')}</label><label class="l">Monto<input id="xMo" type="number" min="0" step="0.01"></label>
    <label class="l">Método de pago${selPago('xFp', null, 'sindolar')}</label><label class="l">Habitación (opcional)<select id="xHa"><option value="">—</option>${sortH(TAB.habitaciones).map((h) => `<option value="${h.id}">${esc(h.numero)}</option>`).join('')}</select></label>
    <label class="l">Entrega el dinero<input id="xEn" value="${esc(YO.nombre)}"></label><label class="l">Recibe el dinero<input id="xRe" placeholder="Empleado, proveedor, contador…"></label></div>
    <label class="l">Nota<input id="xNo"></label>
    <div class="cols" style="gap:12px">${padHTML('fEnt', 'Firma de quien entrega')}${padHTML('fRec', 'Firma de quien recibe')}</div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="gastoOk()">Guardar e imprimir</button>`, true);
  padIniciar('fEnt'); padIniciar('fRec');
}
async function gastoOk() {
  const r = await hacer(() => POST('/api/gastos', { concepto: val('xCo'), categoria: val('xCa'), grupo: grupoSel('xCa'), monto: val('xMo'), metodo: val('xFp'), habitacion_id: val('xHa'), entrega: val('xEn'), recibe: val('xRe'), nota: val('xNo'), firma_entrega: padValor('fEnt'), firma_recibe: padValor('fRec') }), 'Gasto guardado');
  if (vista === 'gastos') vGastos(); imprimirGasto(r.id);
}
async function verGasto(id) {
  const g = await GET('/api/gastos/' + id);
  modal(`Gasto ${esc(g.folio)}`, `<div class="kv"><span>Fecha</span><b>${fdt(g.fecha)}</b><span>Concepto</span><b>${esc(g.concepto)}</b><span>Clasificación</span><span>${esc(g.grupo || 'Otros')} · ${esc(g.categoria || '')}</span><span>Monto</span><b>${money(g.monto)}</b><span>Pago</span><span>${MET[g.metodo]}</span>
    <span>Entregó</span><span>${esc(g.entrega || '')}</span><span>Recibió</span><span>${esc(g.recibe || '')}</span>${g.empleado ? `<span>Empleado</span><span>${esc(g.empleado)}</span>` : ''}${g.proveedor ? `<span>Proveedor</span><span>${esc(g.proveedor)}</span>` : ''}${g.factura ? `<span>Factura / folio</span><span>${esc(g.factura)}</span>` : ''}${g.periodo ? `<span>Periodo</span><span>${esc(g.periodo)}</span>` : ''}${g.numero ? `<span>Habitación</span><span>${esc(g.numero)}</span>` : ''}${g.nota ? `<span>Nota</span><span>${esc(g.nota)}</span>` : ''}<span>Capturó</span><span>${esc(g.usuario || '')}</span></div>
    ${g.cancelado ? '<div class="aviso bad">Gasto cancelado</div>' : ''}
    <div class="cols" style="gap:12px">${g.firma_entrega ? `<div><div class="lbl">Firma de quien entrega</div><img class="firma-img" src="${g.firma_entrega}" alt="firma"></div>` : padHTML('vEnt', 'Firma de quien entrega')}
    ${g.firma_recibe ? `<div><div class="lbl">Firma de quien recibe</div><img class="firma-img" src="${g.firma_recibe}" alt="firma"></div>` : padHTML('vRec', 'Firma de quien recibe')}</div>`,
  `${!g.cancelado && puede('cancelar') ? `<button class="btn bad" onclick="confirmar(this,()=>gastoCancelar(${id}))">Cancelar gasto</button>` : ''}${(!g.firma_entrega || !g.firma_recibe) && puede('operar') ? `<button class="btn op" onclick="gastoFirmar(${id})">Guardar firmas</button>` : ''}<button class="btn" onclick="imprimirGasto(${id},'carta')">Hoja carta (PDF)</button><button class="btn pri" onclick="imprimirGasto(${id})">Ticket 80 mm</button>`, true);
  padIniciar('vEnt'); padIniciar('vRec');
}
async function gastoFirmar(id) { await hacer(() => PUT(`/api/gastos/${id}/firmas`, { firma_entrega: padValor('vEnt'), firma_recibe: padValor('vRec') }), 'Firmas guardadas'); verGasto(id); vGastos(); }
async function gastoCancelar(id) { await hacer(() => POST(`/api/gastos/${id}/cancelar`), 'Gasto cancelado'); cerrar(); vGastos(); }
async function imprimirGasto(id, formato) {
  const g = await GET('/api/gastos/' + id);
  const cuerpo = (copia) => `<div class="dc">${encHTML()}<div class="dc-tit">RECIBO DE GASTO</div><div class="dc-copia">${copia}${g.cancelado ? ' · CANCELADO' : ''}</div>
    <div class="dc-kv"><span>Folio</span><b>${esc(g.folio)}</b><span>Fecha</span><b>${fdt(g.fecha)}</b><span>Concepto</span><b>${esc(g.concepto)}</b><span>Clasificación</span><b>${esc(g.grupo || 'Otros')} · ${esc(g.categoria || '')}</b>
    ${g.numero ? `<span>Habitación</span><b>${esc(g.numero)}</b>` : ''}<span>Método de pago</span><b>${MET[g.metodo] || ''}</b></div>
    <div class="dc-monto">${money(g.monto)}<small>${numeroALetras(g.monto)}</small></div>${g.nota ? `<p class="dc-nota">${esc(g.nota)}</p>` : ''}
    <div class="dc-firmas">${firmaHTML(g.firma_entrega, 'Entrega', g.entrega)}${firmaHTML(g.firma_recibe, 'Recibe', g.recibe)}</div></div>`;
  docConCopia(cuerpo, formato, 'Recibo de gasto', (c) => opsGasto(g, c));
}

// ---------- Contratos ----------
let cBus = '';
async function vContratos() {
  const l = await GET('/api/contratos?q=' + encodeURIComponent(cBus)), ahora = new Date();
  $('#main').innerHTML = cab('Contratos', 'Contratos de arrendamiento ligados a cada habitación rentada', `<input id="cb" placeholder="Arrendatario o habitación" value="${esc(cBus)}" style="width:200px"><button class="btn" onclick="cBus=val('cb');vContratos()">Buscar</button>`)
    + `<div class="aviso" style="margin-bottom:14px">Para hacer un contrato: abra la habitación ocupada → <b>Hacer contrato</b>. Toma los datos del huésped, la renta y el depósito.</div>
    <div class="card"><div class="tw"><table><thead><tr><th>Folio</th><th>Hab.</th><th>Arrendatario</th><th>Renta</th><th>Inicio</th><th>Termina</th><th class="n">Depósito</th><th>Estado</th></tr></thead><tbody>
    ${l.map((c) => { const venc = c.activa && aF(c.salida_prevista) < ahora; return `<tr class="click" onclick="verContrato(${c.id})"><td class="mono">${esc(c.folio)}</td><td><b>${esc(c.numero)}</b></td><td>${esc(c.arrendatario)}</td><td><span class="pill mod m-${c.modalidad}">${money(c.renta)} ${{ dia: 'día', semana: 'semana', mes: 'mes' }[c.modalidad] ? '/ ' + { dia: 'día', semana: 'semana', mes: 'mes' }[c.modalidad] : ''}</span></td>
      <td>${fd(c.inicio)}</td><td>${fd(c.fin)}</td><td class="n">${money(c.deposito)}</td><td>${!c.activa ? '<span class="pill">Terminado</span>' : venc ? '<span class="pill p-bad">Vencido</span>' : '<span class="pill p-ok">Vigente</span>'}${c.firmado ? '' : ' <span class="pill p-warn">Sin firma</span>'}</td></tr>`; }).join('') || '<tr><td colspan="8" class="empty">Todavía no hay contratos.</td></tr>'}</tbody></table></div></div>`;
}
function datosContrato(e, h, c) {
  const unidadT = { dia: 'día', semana: 'semana', mes: 'mes' }[c.modalidad];
  const inicio = aF(c.inicio + ' 00:00:00');
  const diaPago = c.dia_pago || (c.modalidad === 'mes' ? `los días ${inicio.getDate()} de cada mes` : c.modalidad === 'semana' ? `cada ${inicio.toLocaleDateString('es-MX', { weekday: 'long' })}` : 'diariamente');
  const incluye = [textoCamas(h.camas), h.recamaras ? `${h.recamaras} recámara(s)` : '', h.banos ? `${h.banos} baño(s)` : '', ...(h.amenidades || []).map((a) => AMEN[a].toLowerCase())].filter(Boolean).join(', ');
  return {
    arrendador: CFG.arrendador_nombre || CFG.hotel_nombre, arrendador_domicilio: CFG.arrendador_domicilio || CFG.hotel_direccion || '________', arrendatario: c.arrendatario || '________',
    identificacion: c.identificacion || '________', domicilio_arrendatario: c.domicilio || '________', telefono: c.telefono || '________', tipo_inmueble: h.clase === 'departamento' ? 'departamento' : 'habitación',
    inmueble: h.numero, direccion_hotel: CFG.hotel_direccion || '________', incluye, personas: h.capacidad, periodo: unidad(c.modalidad, Math.max(1, e.cantidad)), fecha_inicio: fLarga(c.inicio), fecha_fin: fLarga(c.fin),
    hora_salida: CFG.hora_salida, renta: money(c.renta), renta_letra: numeroALetras(c.renta), unidad: unidadT, dia_pago: diaPago, deposito: money(c.deposito), deposito_letra: numeroALetras(c.deposito),
    aviso: { dia: 'un día', semana: 'siete días', mes: 'treinta días' }[c.modalidad], ciudad: CFG.ciudad_contrato || 'Tijuana, Baja California', fecha_firma: fLarga(),
  };
}
const llenar = (t, d) => t.replace(/\{(\w+)\}/g, (m, k) => (d[k] !== undefined ? String(d[k]) : m));
async function contratoNuevo(eid) {
  const e = await GET('/api/estancias/' + eid), h = e.habitacion;
  contratoNuevo.e = e;
  modal(`Contrato · ${h.clase === 'departamento' ? 'Depto.' : 'Hab.'} ${esc(h.numero)}`, `
    <div class="f"><label class="l">Arrendatario<input id="kA" value="${esc(e.huesped)}"></label><label class="l">Identificación<input id="kI" value="${esc(e.identificacion || '')}"></label><label class="l">Teléfono<input id="kT" value="${esc(e.telefono || '')}"></label>
    <label class="l" style="grid-column:1/-1">Domicilio del arrendatario<input id="kD" value="${esc(e.domicilio || '')}"></label>
    <label class="l">Renta por<select id="kM">${['semana', 'mes', 'dia'].map((m) => `<option value="${m}" ${e.modalidad === m ? 'selected' : ''}>${{ dia: 'Día', semana: 'Semana', mes: 'Mes' }[m]}</option>`).join('')}</select></label><label class="l">Renta<input id="kR" type="number" step="0.01" value="${e.precio}"></label>
    <label class="l">Depósito<input id="kDe" type="number" step="0.01" value="${e.deposito}"></label><label class="l">Inicio<input id="kIn" type="date" value="${e.entrada.slice(0, 10)}"></label><label class="l">Termina<input id="kFi" type="date" value="${e.salida_prevista.slice(0, 10)}"></label>
    <label class="l">Día de pago<input id="kP" placeholder="Se calcula solo"></label></div>
    <div class="row" style="justify-content:space-between"><span class="lbl">Texto del contrato (puede corregirlo antes de guardar)</span><button class="btn sm" type="button" onclick="contratoTexto()">Volver a llenar con los datos</button></div>
    <textarea id="kTx" rows="14" style="font-family:var(--fBody);font-size:13px;min-height:260px"></textarea>
    <div class="cols" style="gap:12px">${padHTML('kFA', 'Firma del arrendador')}${padHTML('kFR', 'Firma del arrendatario')}</div>
    <div class="sub">Si prefieren firmar en papel, deje las firmas en blanco: el contrato impreso trae las líneas para firmar.</div>`,
  `<button class="btn" onclick="verEstancia(${eid})">Volver</button><button class="btn pri" onclick="contratoOk(${eid})">Guardar contrato</button>`, true);
  padIniciar('kFA'); padIniciar('kFR'); contratoTexto();
}
function contratoCampos() { return { arrendatario: val('kA'), identificacion: val('kI'), telefono: val('kT'), domicilio: val('kD'), modalidad: val('kM'), renta: num('kR'), deposito: num('kDe'), inicio: val('kIn'), fin: val('kFi'), dia_pago: val('kP') }; }
function contratoTexto() { const e = contratoNuevo.e; $('#kTx').value = llenar(CFG.contrato_clausulas || CFG._contrato_base, datosContrato(e, e.habitacion, contratoCampos())); }
async function contratoOk(eid) {
  const c = contratoCampos();
  const r = await hacer(() => POST('/api/contratos', { estancia_id: eid, ...c, texto: $('#kTx').value, firma_arrendador: padValor('kFA'), firma_arrendatario: padValor('kFR') }), 'Contrato guardado');
  verContrato(r.id);
}
async function verContrato(id) {
  const c = await GET('/api/contratos/' + id);
  modal(`Contrato ${esc(c.folio)}`, `<div class="kv"><span>Arrendatario</span><b>${esc(c.arrendatario)}</b><span>Inmueble</span><span>${c.habitacion.clase === 'departamento' ? 'Departamento' : 'Habitación'} ${esc(c.habitacion.numero)}</span>
    <span>Vigencia</span><span>${fd(c.inicio)} al ${fd(c.fin)}</span><span>Renta</span><span>${money(c.renta)} por ${{ dia: 'día', semana: 'semana', mes: 'mes' }[c.modalidad]}</span><span>Depósito</span><span>${money(c.deposito)}</span>
    <span>Estado</span><span>${c.estancia.activa ? 'Vigente (huésped hospedado)' : 'Terminado'}</span></div>
    <div class="cols" style="gap:12px">${c.firma_arrendador ? `<div><div class="lbl">Firma del arrendador</div><img class="firma-img" src="${c.firma_arrendador}" alt="firma"></div>` : padHTML('cFA', 'Firma del arrendador')}
    ${c.firma_arrendatario ? `<div><div class="lbl">Firma del arrendatario</div><img class="firma-img" src="${c.firma_arrendatario}" alt="firma"></div>` : padHTML('cFR', 'Firma del arrendatario')}</div>`,
  `${(!c.firma_arrendador || !c.firma_arrendatario) && puede('contratos') ? `<button class="btn op" onclick="contratoFirmar(${id})">Guardar firmas</button>` : ''}<button class="btn" onclick="verEstancia(${c.estancia_id})">Ver huésped</button><button class="btn pri" onclick="imprimirContrato(${id})">Imprimir / PDF</button>`, true);
  padIniciar('cFA'); padIniciar('cFR');
}
async function contratoFirmar(id) { await hacer(() => PUT(`/api/contratos/${id}/firmas`, { firma_arrendador: padValor('cFA'), firma_arrendatario: padValor('cFR') }), 'Firmas guardadas'); verContrato(id); }
async function imprimirContrato(id) {
  const c = await GET('/api/contratos/' + id), h = c.habitacion;
  const parrafos = esc(c.texto).split(/\n\s*\n/).map((p) => {
    const t = p.trim();
    if (/^[A-ZÁÉÍÓÚÑ ]{5,}$/.test(t)) return `<h4>${t}</h4>`;
    return `<p>${t.replace(/^((?:[IVX]+\.)|(?:[A-ZÁÉÍÓÚÑ]+\.(?: [A-ZÁÉÍÓÚÑ ]+\.)?))/, '<b>$1</b>').replace(/\n/g, '<br>')}</p>`;
  }).join('');
  const html = `<div class="ct">${encHTML()}<h3>CONTRATO DE ARRENDAMIENTO</h3><div class="ct-folio">Folio ${esc(c.folio)} · ${fLarga(c.fecha)}</div>
    <table class="ct-res"><tr><td>Inmueble</td><td>${h.clase === 'departamento' ? 'Departamento' : 'Habitación'} ${esc(h.numero)}${h.nombre ? ' · ' + esc(h.nombre) : ''}</td><td>Arrendatario</td><td>${esc(c.arrendatario)}</td></tr>
    <tr><td>Vigencia</td><td>${fLarga(c.inicio)} al ${fLarga(c.fin)}</td><td>Renta</td><td>${money(c.renta)} por ${{ dia: 'día', semana: 'semana', mes: 'mes' }[c.modalidad]}</td></tr>
    <tr><td>Depósito en garantía</td><td>${money(c.deposito)}</td><td>Teléfono</td><td>${esc(c.telefono || '')}</td></tr></table>
    ${parrafos}
    <div class="dc-firmas ct-firmas">${firmaHTML(c.firma_arrendador, 'EL ARRENDADOR', CFG.arrendador_nombre || CFG.hotel_nombre)}${firmaHTML(c.firma_arrendatario, 'EL ARRENDATARIO', c.arrendatario)}</div>
    <div class="dc-firmas ct-firmas">${firmaHTML(null, 'TESTIGO', '')}${firmaHTML(null, 'TESTIGO', '')}</div></div>`;
  imprimirDoc(html, 'carta', 'Contrato de arrendamiento');
}

// ---------- Mantenimiento ----------
let mTab = 'abiertos', mDesde = hoyISO(), mHasta = hoyISO();
const PRIO = { baja: ['Baja', 'p-ok'], normal: ['Normal', 's-libre'], alta: ['Alta', 'p-warn'], urgente: ['Urgente', 'p-bad'] };
const EMANT = { pendiente: ['Pendiente', 'p-bad'], proceso: ['En proceso', 'p-warn'], terminado: ['Terminado', 'p-ok'] };
function hace(s, hasta) {
  const ms = (hasta ? aF(hasta) : new Date()) - aF(s), min = Math.round(ms / 60000);
  if (min < 60) return min + ' min'; const h = Math.round(min / 60); if (h < 48) return h + ' h'; return Math.round(h / 24) + ' días';
}
async function vMant() {
  const l = await GET(mTab === 'abiertos' ? '/api/mant' : `/api/mant?estado=terminados&desde=${mDesde}&hasta=${mHasta}`);
  if (mTab === 'abiertos') { ir.badge = { ...(ir.badge || {}), mant: l.length || '' }; pintarNav(ir.badge); }
  $('#main').innerHTML = cab('Mantenimiento', mTab === 'abiertos' ? `${l.length} pendiente(s) · se actualiza sola` : 'Reportes terminados', puede('mant_reportar') ? `<button class="btn pri" onclick="mantNuevo()">${ico('camara')} Reportar desperfecto</button>` : '')
    + `<div class="tabs"><button class="${mTab === 'abiertos' ? 'on' : ''}" onclick="mTab='abiertos';vMant()">Pendientes</button><button class="${mTab === 'terminados' ? 'on' : ''}" onclick="mTab='terminados';vMant()">Terminados</button>
      ${mTab === 'terminados' ? `<input type="date" id="md" value="${mDesde}" style="width:auto"><input type="date" id="mh" value="${mHasta}" style="width:auto"><button class="btn sm" onclick="mDesde=val('md');mHasta=val('mh');vMant()">Ver</button>` : ''}</div>
    <div class="mgrid">${l.map((m) => `<button class="mcard" onclick="verMant(${m.id})">${m.foto ? `<img src="fotos/${encodeURIComponent(m.foto)}" alt="foto" loading="lazy">` : `<div class="msin">${ico('llave')}</div>`}
      <div class="mbody2"><div class="row" style="gap:6px"><span class="pill ${EMANT[m.estado][1]}">${EMANT[m.estado][0]}</span><span class="pill ${PRIO[m.prioridad][1]}">${PRIO[m.prioridad][0]}</span></div>
      <b>${esc(m.titulo)}</b><span class="sub">${m.numero ? (m.clase === 'departamento' ? 'Depto. ' : 'Hab. ') + esc(m.numero) : 'Área común'} · Folio ${esc(m.folio)}</span>
      <span class="sub">${m.estado === 'terminado' ? `Reparado en ${hace(m.alta, m.cierre)} por ${esc(m.cierre_nombre || '')}` : `Reportado hace ${hace(m.alta)} por ${esc(m.alta_nombre || '')}${m.atiende_nombre ? ` · Atiende ${esc(m.atiende_nombre)}` : ''}`}</span>
      <span class="sub">${ico('camara')} ${m.fotos_reporte} antes · ${m.fotos_evidencia} después</span></div></button>`).join('') || `<div class="card empty">${mTab === 'abiertos' ? 'No hay reportes pendientes.' : 'No hay reportes terminados en esas fechas.'}</div>`}</div>`;
}
async function mantNuevo(habId) {
  if (!TAB || ES_PERSONAL()) TAB = { habitaciones: await GET('/api/habitaciones') };
  modal('Reportar desperfecto', `<div class="f"><label class="l">Habitación<select id="nH"><option value="">Área común / otro</option>${sortH(TAB.habitaciones).map((h) => `<option value="${h.id}" ${h.id === habId ? 'selected' : ''}>${esc(h.numero)}${h.nombre ? ' · ' + esc(h.nombre) : ''}</option>`).join('')}</select></label>
    <label class="l" style="grid-column:span 2">Qué hay que reparar<input id="nT" placeholder="Ej. no enfría el aire acondicionado"></label></div>
    <label class="l">Detalles<textarea id="nD" rows="3" style="font-family:var(--fBody);font-size:14px;min-height:70px"></textarea></label>
    <div class="lbl">Prioridad</div><div class="seg">${Object.entries(PRIO).map(([k, [n]]) => `<label><input type="radio" name="nP" value="${k}" ${k === 'normal' ? 'checked' : ''}>${n}</label>`).join('')}</div>
    <div class="lbl">Fotos del desperfecto</div>${fotoInput('nuevo')}
    <label class="row" style="font-weight:600"><input type="checkbox" id="nM" checked> Poner la habitación en mantenimiento (si está desocupada)</label>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="mantNuevoOk()">Enviar reporte</button>`);
}
async function mantNuevoOk() {
  await hacer(() => POST('/api/mant', { habitacion_id: val('nH'), titulo: val('nT'), descripcion: $('#nD').value, prioridad: document.querySelector('input[name=nP]:checked').value, fotos: FOTOS.nuevo, poner_en_mant: $('#nM').checked }), 'Reporte enviado');
  cerrar(); if (vista === 'mant') vMant(); else ir(vista);
}
async function verMant(id) {
  const m = await GET('/api/mant/' + id), antes = m.fotos.filter((f) => f.tipo === 'reporte'), desp = m.fotos.filter((f) => f.tipo === 'evidencia');
  const galeria = (l) => l.length ? `<div class="fotos">${l.map((f) => `<a href="fotos/${encodeURIComponent(f.archivo)}" target="_blank" rel="noopener"><img src="fotos/${encodeURIComponent(f.archivo)}" alt="foto"></a>`).join('')}</div>` : '<div class="sub">Sin fotos.</div>';
  modal(`${esc(m.titulo)}`, `<div class="row"><span class="pill ${EMANT[m.estado][1]}">${EMANT[m.estado][0]}</span><span class="pill ${PRIO[m.prioridad][1]}">Prioridad ${PRIO[m.prioridad][0].toLowerCase()}</span><span class="sub">${m.numero ? (m.clase === 'departamento' ? 'Depto. ' : 'Hab. ') + esc(m.numero) : 'Área común'} · Folio ${esc(m.folio)}</span></div>
    ${m.descripcion ? `<p style="margin:0">${esc(m.descripcion)}</p>` : ''}
    <ol class="linea"><li class="ok"><b>Reportado</b> ${fdt(m.alta)} · ${esc(m.alta_nombre || '')}</li>
      <li class="${m.inicio ? 'ok' : ''}"><b>En proceso</b> ${m.inicio ? `${fdt(m.inicio)} · ${esc(m.atiende_nombre || '')} <span class="sub">(${hace(m.alta, m.inicio)} después)</span>` : '—'}</li>
      <li class="${m.cierre ? 'ok' : ''}"><b>Reparado</b> ${m.cierre ? `${fdt(m.cierre)} · ${esc(m.cierre_nombre || '')} <span class="sub">(tardó ${hace(m.alta, m.cierre)})</span>` : '—'}</li></ol>
    ${m.nota_cierre ? `<div class="aviso ok"><b>Qué se hizo:</b> ${esc(m.nota_cierre)}${m.costo ? ` · Costo ${money(m.costo)}` : ''}</div>` : ''}
    <div class="lbl">Fotos del desperfecto</div>${galeria(antes)}<div class="lbl">Fotos de evidencia (reparado)</div>${galeria(desp)}`,
  m.estado !== 'terminado' && puede('mant') ? `<button class="btn" onclick="mantFotos(${id})">${ico('camara')} Agregar fotos</button>${!puede('mant_atender') ? '' : m.estado === 'pendiente' ? `<button class="btn" onclick="mantAtender(${id})">Empezar a atender</button>` : ''}${puede('mant_atender') ? `<button class="btn ok" onclick="mantCerrar(${id})">Marcar como reparado</button>` : ''}` : `<button class="btn" onclick="cerrar()">Cerrar</button>`);
}
async function mantAtender(id) { await hacer(() => POST(`/api/mant/${id}/atender`), 'En proceso'); verMant(id); vMant(); }
function mantFotos(id) {
  modal('Agregar fotos', `<div class="seg"><label><input type="radio" name="fT" value="reporte">Del desperfecto (antes)</label><label><input type="radio" name="fT" value="evidencia" checked>De evidencia (después)</label></div>${fotoInput('extra')}`,
    `<button class="btn" onclick="verMant(${id})">Volver</button><button class="btn pri" onclick="mantFotosOk(${id})">Subir fotos</button>`);
}
async function mantFotosOk(id) {
  if (!FOTOS.extra.length) return toast('Elija al menos una foto', true);
  await hacer(() => POST(`/api/mant/${id}/fotos`, { tipo: document.querySelector('input[name=fT]:checked').value, fotos: FOTOS.extra }), 'Fotos subidas'); verMant(id); vMant();
}
function mantCerrar(id) {
  modal('Marcar como reparado', `<label class="l">Qué se hizo<textarea id="cN" rows="3" style="font-family:var(--fBody);font-size:14px;min-height:70px" placeholder="Ej. se cambió el capacitor del aire"></textarea></label>
    <div class="lbl">Fotos de evidencia (cómo quedó)</div>${fotoInput('cierre')}
    <div class="f"><label class="l">Costo de material (opcional)<input id="cC" type="number" min="0" step="0.01"></label><label class="l">Pagado con${selPago('cF', null, 'sindolar')}</label></div>
    <label class="row" style="font-weight:600"><input type="checkbox" id="cG" checked> Registrar el costo en Gastos</label>
    <div class="lbl">Si la habitación estaba en mantenimiento, dejarla</div><div class="seg"><label><input type="radio" name="cE" value="limpieza" checked>En limpieza</label><label><input type="radio" name="cE" value="libre">Lista para rentar</label></div>`,
  `<button class="btn" onclick="verMant(${id})">Volver</button><button class="btn ok" onclick="mantCerrarOk(${id})">Guardar como reparado</button>`);
}
async function mantCerrarOk(id) {
  if (!FOTOS.cierre.length && !confirmar.sinFoto) { confirmar.sinFoto = 1; return toast('No subió fotos de evidencia. Toque otra vez "Guardar" para continuar sin fotos.', true); }
  confirmar.sinFoto = 0;
  await hacer(() => POST(`/api/mant/${id}/cerrar`, { nota: $('#cN').value, fotos: FOTOS.cierre, costo: val('cC'), registrar_gasto: $('#cG').checked, metodo: val('cF'), estado_hab: document.querySelector('input[name=cE]:checked').value }), 'Reporte terminado');
  verMant(id); vMant();
}


