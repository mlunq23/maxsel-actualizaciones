// Maxsel Hotel 1.11 — Limpieza con evidencia desde el celular: habitaciones, áreas comunes y lavandería de blancos
const SUBT = {
  habitacion: { n: 'Habitación', i: 'cama', d: 'Limpiar el cuarto de un cliente' },
  area: { n: 'Área común', i: 'edificio', d: 'Lobby, pasillos, escaleras, estacionamiento…' },
  lavanderia: { n: 'Lavandería', i: 'lavadora', d: 'Mandar a lavar sábanas, toallas…' },
  otro: { n: 'Otro', i: 'camara', d: 'Cualquier otra tarea de limpieza' },
};
const BLANCOS_LISTA = ['Sábanas', 'Fundas', 'Toallas de baño', 'Toallas de mano', 'Tapetes de baño', 'Cobijas / edredones', 'Cubrecolchones', 'Cortinas', 'Manteles'];
const AREAS_RAPIDAS = ['Lobby y recepción', 'Pasillos', 'Escaleras', 'Estacionamiento', 'Baños comunes', 'Alberca', 'Elevador', 'Patio', 'Oficina'];
const subDe = (m) => m.subtipo || (m.habitacion_id ? 'habitacion' : 'area');
const blancosDe = (m) => { if (m.blancos && typeof m.blancos === 'object') return m.blancos; try { return JSON.parse(m.blancos || '{}'); } catch { return {}; } };
const piezas = (b, k = 'env') => Object.values(b).reduce((a, v) => a + (v[k] || 0), 0);
const faltanDe = (m) => { const b = blancosDe(m); return m.estado === 'terminado' ? Object.values(b).reduce((a, v) => a + Math.max(0, (v.env || 0) - (v.rec ?? 0)), 0) : 0; };
const lugarDe = (m) => (m.numero ? (m.clase === 'departamento' ? 'Depto. ' : m.clase === 'local' ? 'Local ' : 'Hab. ') + esc(m.numero) : subDe(m) === 'lavanderia' ? esc(m.destino || 'Lavandería') : esc(m.area || 'Área común'));

// ---------- Lista de tickets ----------
vMant = async function () {
  // 1.14: cada quien su panel — limpieza (camaristas) solo limpieza; mantenimiento solo reparaciones
  const rol = YO.rol, esL = rol === 'limpieza', esM = rol === 'mantenimiento', pers = esL || esM;
  const tq = pers ? '' : mTipo === 'reparacion' ? '&tipo=reparacion' : mTipo ? '&tipo=limpieza' : '';
  let l = await GET(mTab === 'abiertos' ? '/api/mant?x=1' + tq : `/api/mant?estado=terminados&desde=${mDesde}&hasta=${mHasta}${tq}`);
  if (mTab === 'abiertos') { ir.badge = { ...(ir.badge || {}), mant: l.length || '' }; pintarNav(ir.badge); }
  if (!pers && mTipo === 'lavanderia') l = l.filter((m) => subDe(m) === 'lavanderia');
  const botones = !puede('mant_reportar') ? '' : esL ? `<button class="btn pri op" onclick="limpNuevo()">${ico('camara')} Avisar limpieza</button>`
    : esM ? `<button class="btn pri op" onclick="mantNuevo()">${ico('llave')} Reportar desperfecto</button>`
    : `<button class="btn op" onclick="limpNuevo()">${ico('camara')} Avisar limpieza</button><button class="btn pri op" onclick="mantNuevo()">${ico('llave')} Reportar desperfecto</button>`;
  const titulo = esL ? 'Mis tareas de limpieza' : esM ? 'Mis trabajos de mantenimiento' : 'Mantenimiento y limpieza';
  const urg = l.filter((m) => m.estado !== 'terminado' && m.prioridad === 'urgente').length;
  $('#main').innerHTML = cab(titulo, mTab === 'abiertos' ? `${l.length} por hacer${urg ? ` · <b style="color:var(--ocup)">${urg} urgente(s)</b>` : ''} · se actualiza sola` : (pers ? 'Lo que ya hice' : 'Tickets terminados'), botones)
    + `<div class="tabs"><button class="${mTab === 'abiertos' ? 'on' : ''}" onclick="mTab='abiertos';vMant()">${pers ? 'Por hacer' : 'Pendientes'}</button><button class="${mTab === 'terminados' ? 'on' : ''}" onclick="mTab='terminados';vMant()">${pers ? 'Ya hice' : 'Terminados'}</button>
      ${mTab === 'terminados' ? `<input type="date" id="md" value="${mDesde}" style="width:auto"><input type="date" id="mh" value="${mHasta}" style="width:auto"><button class="btn sm" onclick="mDesde=val('md');mHasta=val('mh');vMant()">Ver</button>` : ''}</div>
    ${pers ? '<div style="margin-bottom:12px"></div>' : `<div class="tabs" style="margin:8px 0 12px">${[['', 'Todos'], ['reparacion', 'Reparaciones'], ['limpieza', 'Limpieza'], ['lavanderia', 'Lavandería']].map(([k, n]) => `<button class="${mTipo === k ? 'on' : ''}" onclick="mTipo='${k}';vMant()">${n}</button>`).join('')}</div>`}
    <div class="mgrid">${l.map((m) => {
      const limp = m.tipo === 'limpieza', s = subDe(m), lav = limp && s === 'lavanderia', b = lav ? blancosDe(m) : null, f = lav ? faltanDe(m) : 0;
      const etiqueta = limp ? (s === 'habitacion' ? 'Limpieza' : s === 'lavanderia' ? 'Lavandería' : 'Limpieza · ' + SUBT[s].n) : 'Reparación';
      const estado = lav && m.estado === 'proceso' ? ['En lavandería', 'p-warn'] : EMANT[m.estado];
      const pr = PRIO[m.prioridad] || PRIO.normal;
      const linea = m.estado === 'terminado'
        ? `${lav ? 'Regresaron' : limp ? 'Limpio' : 'Reparado'} en ${hace(m.alta, m.cierre)}${m.cierre_nombre ? ' por ' + esc(m.cierre_nombre) : ''}`
        : `${limp && m.inicio ? (lav ? 'Se mandó' : 'Empezó') + ' hace ' + hace(m.inicio) : 'Levantado hace ' + hace(m.alta)}${m.atiende_nombre ? ' · ' + esc(m.atiende_nombre) : m.alta_nombre ? ' por ' + esc(m.alta_nombre) : ' (automático)'}`;
      return `<button class="mcard ${m.estado !== 'terminado' && m.prioridad === 'urgente' ? 'm-urg' : ''}" onclick="verMant(${m.id})">${m.foto ? `<img src="fotos/${encodeURIComponent(m.foto)}" alt="foto" loading="lazy">` : `<div class="msin">${ico(limp ? SUBT[s].i : 'llave')}</div>`}
      <div class="mbody2"><div class="row" style="gap:6px;flex-wrap:wrap">${pers ? '' : `<span class="pill ${limp ? 'p-info' : 'p-warn'}">${etiqueta}</span>`}<span class="pill ${estado[1]}">${estado[0]}</span>${m.estado !== 'terminado' ? `<span class="pill ${pr[1]}">${pr[0]}</span>` : ''}${f ? `<span class="pill p-bad">Faltan ${f}</span>` : ''}${pers && m.asignado_a === YO.id ? '<span class="pill pv">Para usted</span>' : ''}</div>
      <b>${esc(m.titulo)}</b><span class="sub">${lugarDe(m)} · Folio ${esc(m.folio)}</span>
      ${lav ? `<span class="sub">${piezas(b)} pieza(s)${m.estado === 'terminado' ? ` · regresaron ${piezas(b, 'rec')}` : ''}</span>` : ''}
      ${!pers && m.asignado_nombre && m.estado !== 'terminado' ? `<span class="sub">Le toca a: <b>${esc(m.asignado_nombre)}</b></span>` : ''}
      <span class="sub">${linea}</span><span class="sub">${ico('camara')} ${m.fotos_reporte} antes · ${m.fotos_evidencia} después</span></div></button>`;
    }).join('') || `<div class="card empty">${mTab === 'abiertos' ? (pers ? 'No tiene nada pendiente. ¡Buen trabajo!' : 'No hay tickets pendientes.') : 'No hay trabajos terminados en esas fechas.'}</div>`}</div>`;
};

// ---------- Avisar una tarea de limpieza ----------
let LN_SUB = 'habitacion';
async function limpNuevo(sub, habId) {
  if (!TAB || ES_PERSONAL()) TAB = { habitaciones: await GET('/api/habitaciones') };
  LN_SUB = sub || (habId ? 'habitacion' : LN_SUB);
  const hs = sortH(TAB.habitaciones).sort((a, b) => (b.estado === 'limpieza') - (a.estado === 'limpieza'));
  modal('Avisar limpieza', `<div class="lbl">¿Qué va a limpiar?</div>
    <div class="seg" style="flex-wrap:wrap">${Object.entries(SUBT).map(([k, v]) => `<label><input type="radio" name="lnS" value="${k}" ${k === LN_SUB ? 'checked' : ''} onchange="limpSub(this.value)">${ico(v.i)} ${v.n}</label>`).join('')}</div>
    <div class="sub" id="lnDesc"></div>
    <div id="lnHab" class="f"><label class="l" style="grid-column:1/-1">Habitación<select id="lnH">${hs.map((h) => `<option value="${h.id}" ${h.id === habId ? 'selected' : ''}>${esc(h.numero)}${h.nombre ? ' · ' + esc(h.nombre) : ''}${h.estado === 'limpieza' ? ' — en limpieza' : h.estado === 'ocupada' ? ' — ocupada' : ''}</option>`).join('')}</select></label></div>
    <div id="lnArea"><label class="l">Área<input id="lnA" placeholder="Ej. pasillo piso 2"></label>
      <div class="row" style="gap:6px;flex-wrap:wrap;margin-top:6px">${AREAS_RAPIDAS.map((a) => `<button type="button" class="btn sm" onclick="$('#lnA').value=this.textContent">${esc(a)}</button>`).join('')}</div></div>
    <div id="lnLav"><div class="lbl">Cuántas piezas manda a lavar</div>
      <div class="blancos-g">${BLANCOS_LISTA.map((b, i) => `<label class="l">${esc(b)}<input type="number" min="0" step="1" inputmode="numeric" id="lnB${i}" placeholder="0"></label>`).join('')}</div>
      <label class="l">A dónde se mandan<input id="lnDst" placeholder="Ej. Lavandería La Burbuja, o lavado en el hotel"></label></div>
    <div id="lnOtro"><label class="l">Qué va a limpiar<input id="lnT" placeholder="Ej. vidrios de la entrada"></label></div>
    <label class="l">Notas (opcional)<textarea id="lnD" rows="2" style="font-family:var(--fBody);font-size:14px;min-height:56px"></textarea></label>
    <div class="lbl" id="lnFl">Fotos (antes)</div>${fotoInput('ln')}
    <label class="row" style="font-weight:600" id="lnEL"><input type="checkbox" id="lnE" ${ES_PERSONAL() ? 'checked' : ''}> Ya voy a hacerlo (queda como "en proceso" a mi nombre)</label>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="limpNuevoOk()">Avisar</button>`);
  limpSub(LN_SUB);
}
function limpSub(s) {
  LN_SUB = s;
  $('#lnHab').hidden = s !== 'habitacion'; $('#lnArea').hidden = s !== 'area'; $('#lnLav').hidden = s !== 'lavanderia'; $('#lnOtro').hidden = s !== 'otro';
  $('#lnEL').hidden = s === 'lavanderia'; $('#lnDesc').textContent = SUBT[s].d;
  $('#lnFl').textContent = s === 'lavanderia' ? `Foto de lo que se manda${CFG.limpieza_foto_obligatoria !== '0' ? ' (obligatoria)' : ''}` : 'Fotos (antes)';
}
async function limpNuevoOk() {
  const s = LN_SUB, b = {};
  if (s === 'lavanderia') BLANCOS_LISTA.forEach((n, i) => { const v = Math.floor(Number(val('lnB' + i)) || 0); if (v > 0) b[n] = v; });
  if (s === 'area' && !val('lnA').trim()) return toast('Escriba qué área va a limpiar', true);
  if (s === 'otro' && !val('lnT').trim()) return toast('Escriba qué va a limpiar', true);
  if (s === 'lavanderia' && !Object.keys(b).length) return toast('Anote cuántas piezas manda a lavar', true);
  const r = await hacer(() => POST('/api/mant', { tipo: 'limpieza', subtipo: s, habitacion_id: s === 'habitacion' ? val('lnH') : '', area: val('lnA'), titulo: s === 'otro' ? val('lnT') : '',
    descripcion: $('#lnD').value, blancos: b, destino: val('lnDst'), fotos: FOTOS.ln, empiezo: s === 'lavanderia' || $('#lnE').checked }), s === 'lavanderia' ? 'Listo: quedó registrado lo que se mandó a lavar' : 'Aviso de limpieza enviado');
  cerrar(); if (vista === 'mant') vMant(); else ir(vista);
  return r;
}
// El botón "Ticket de limpieza" de otras pantallas abre el aviso nuevo
{
  const _mn = mantNuevo;
  mantNuevo = function (habId, tipo) { return tipo === 'limpieza' ? limpNuevo(habId ? 'habitacion' : undefined, habId) : _mn(habId, tipo); };
}

// ---------- Detalle de un ticket de limpieza ----------
{
  const _vm = verMant;
  verMant = async function (id) {
    const m = await GET('/api/mant/' + id);
    if (m.tipo !== 'limpieza') return _vm(id);
    const s = subDe(m), lav = s === 'lavanderia', b = blancosDe(m), antes = m.fotos.filter((f) => f.tipo === 'reporte'), desp = m.fotos.filter((f) => f.tipo === 'evidencia');
    const galeria = (l) => l.length ? `<div class="fotos">${l.map((f) => `<a href="fotos/${encodeURIComponent(f.archivo)}" target="_blank" rel="noopener"><img src="fotos/${encodeURIComponent(f.archivo)}" alt="foto"></a>`).join('')}</div>` : '<div class="sub">Sin fotos.</div>';
    const est = lav && m.estado === 'proceso' ? ['En lavandería', 'p-warn'] : EMANT[m.estado], f = faltanDe(m);
    modal(esc(m.titulo), `<div class="row" style="flex-wrap:wrap"><span class="pill p-info">${ico(SUBT[s].i)} ${SUBT[s].n}</span><span class="pill ${est[1]}">${est[0]}</span>${f ? `<span class="pill p-bad">Faltan ${f} pieza(s)</span>` : ''}<span class="sub">${lugarDe(m)} · Folio ${esc(m.folio)}</span></div>
      ${m.descripcion ? `<p style="margin:0">${esc(m.descripcion)}</p>` : ''}
      ${lav ? `<div class="tw"><table><thead><tr><th>Pieza</th><th class="n">Se mandaron</th><th class="n">Regresaron</th></tr></thead><tbody>${Object.entries(b).map(([k, v]) => `<tr><td>${esc(k)}</td><td class="n">${v.env}</td><td class="n">${v.rec === undefined ? '—' : v.rec < v.env ? `<b style="color:var(--bad,#c0392b)">${v.rec}</b>` : v.rec}</td></tr>`).join('')}
        <tr><td><b>Total</b></td><td class="n"><b>${piezas(b)}</b></td><td class="n"><b>${m.estado === 'terminado' ? piezas(b, 'rec') : '—'}</b></td></tr></tbody></table></div>` : ''}
      <ol class="linea"><li class="ok"><b>${m.alta_nombre ? 'Avisado' : 'Levantado solo'}</b> ${fdt(m.alta)} · ${esc(m.alta_nombre || 'al quedar en limpieza')}</li>
        <li class="${m.inicio ? 'ok' : ''}"><b>${lav ? 'Se mandó a lavar' : 'Empezó a limpiar'}</b> ${m.inicio ? `${fdt(m.inicio)} · ${esc(m.atiende_nombre || '')}` : '—'}</li>
        <li class="${m.cierre ? 'ok' : ''}"><b>${lav ? 'Regresaron' : 'Terminado'}</b> ${m.cierre ? `${fdt(m.cierre)} · ${esc(m.cierre_nombre || '')} <span class="sub">(tardó ${hace(m.inicio || m.alta, m.cierre)})</span>` : '—'}</li></ol>
      ${m.nota_cierre ? `<div class="aviso ${f ? '' : 'ok'}"><b>${lav ? 'Al regresar:' : 'Qué se hizo:'}</b> ${esc(m.nota_cierre)}</div>` : ''}
      <div class="lbl">${lav ? 'Fotos de lo que se mandó' : 'Fotos de antes'}</div>${galeria(antes)}<div class="lbl">${lav ? 'Fotos de lo que regresó' : 'Fotos de cómo quedó'}</div>${galeria(desp)}`,
    m.estado !== 'terminado' && puede('mant') ? `<button class="btn" onclick="mantFotos(${id})">${ico('camara')} Agregar fotos</button>${puede('mant_atender') && m.estado === 'pendiente' ? `<button class="btn" onclick="mantAtender(${id})">Empezar a limpiar</button>` : ''}${puede('mant_atender') ? `<button class="btn ok" onclick="mantCerrar(${id})">${lav ? 'Ya regresaron' : 'Terminé, quedó limpio'}</button>` : ''}` : `<button class="btn" onclick="cerrar()">Cerrar</button>`);
  };
}

// ---------- Terminar: evidencia de cómo quedó / qué regresó de la lavandería ----------
{
  const _mc = mantCerrar;
  mantCerrar = async function (id) {
    const m = await GET('/api/mant/' + id);
    if (m.tipo !== 'limpieza') return _mc(id);
    const lav = subDe(m) === 'lavanderia', b = blancosDe(m), ob = CFG.limpieza_foto_obligatoria !== '0';
    modal(lav ? 'Regresaron los blancos' : 'Terminé la limpieza', lav
      ? `<div class="lbl">Cuente lo que regresó</div><div class="blancos-g">${Object.entries(b).map(([k, v], i) => `<label class="l">${esc(k)} <span class="sub">(se mandaron ${v.env})</span><input type="number" min="0" step="1" inputmode="numeric" id="lrB${i}" data-k="${esc(k)}" value="${v.env}"></label>`).join('')}</div>
        <label class="l">Notas (opcional)<textarea id="cN" rows="2" style="font-family:var(--fBody);font-size:14px;min-height:56px" placeholder="Ej. una toalla regresó manchada"></textarea></label>
        <div class="lbl">Foto de lo que regresó${ob ? ' (obligatoria)' : ''}</div>${fotoInput('cierre')}`
      : `<label class="l">Qué se limpió<textarea id="cN" rows="3" style="font-family:var(--fBody);font-size:14px;min-height:70px">${m.habitacion_id ? 'Habitación limpia: cama tendida, baño, piso, basura y blancos cambiados.' : ''}</textarea></label>
        <div class="lbl">Fotos de cómo quedó${ob ? ' (al menos una)' : ''}</div>${fotoInput('cierre')}${m.habitacion_id ? '<div class="sub">Si la habitación estaba en limpieza, queda lista para rentar.</div>' : ''}`,
    `<button class="btn" onclick="verMant(${id})">Volver</button><button class="btn ok" onclick="limpCerrarOk(${id},${lav})">Guardar</button>`);
  };
}
async function limpCerrarOk(id, lav) {
  if (CFG.limpieza_foto_obligatoria !== '0' && !FOTOS.cierre.length) return toast(lav ? 'Tome una foto de los blancos que regresaron' : 'Tome al menos una foto de cómo quedó', true);
  const rec = {}; if (lav) document.querySelectorAll('#modal input[id^=lrB]').forEach((i) => (rec[i.dataset.k] = Math.floor(Number(i.value) || 0)));
  if (!lav && !$('#cN').value.trim()) return toast('Escriba qué se limpió', true);
  await hacer(() => POST(`/api/mant/${id}/cerrar`, { nota: $('#cN').value, fotos: FOTOS.cierre, recibidos: rec }), lav ? 'Registrado lo que regresó' : 'Limpieza terminada');
  verMant(id); vMant();
}

// ---------- Reportes, cierre de mes, PDF y Excel ----------
function limpHTML(L) {
  const B = L.blancos;
  return `<div class="cols" style="margin-bottom:16px"><div class="card"><h2>Limpieza del periodo · ${L.total}</h2>
    <div class="kv"><span>Habitaciones</span><b>${L.por.habitacion || 0}</b><span>Áreas comunes</span><b>${L.por.area || 0}</b><span>Lavandería</span><b>${L.por.lavanderia || 0}</b><span>Otras</span><b>${L.por.otro || 0}</b><span>Con foto de evidencia</span><b>${L.con_foto} de ${L.total}</b></div>
    ${L.personas.length ? `<div class="tw" style="margin-top:10px"><table><thead><tr><th>Persona</th><th class="n">Hab.</th><th class="n">Áreas</th><th class="n">Lavand.</th><th class="n">Otras</th><th class="n">Total</th></tr></thead><tbody>${L.personas.map((p) => `<tr><td>${esc(p.nombre)}</td><td class="n">${p.habitacion}</td><td class="n">${p.area}</td><td class="n">${p.lavanderia}</td><td class="n">${p.otro}</td><td class="n"><b>${p.total}</b></td></tr>`).join('')}</tbody></table></div>` : ''}</div>
    <div class="card"><h2>Blancos a lavandería</h2><div class="kv"><span>Piezas que se mandaron</span><b>${B.enviadas}</b><span>Piezas que regresaron</span><b>${B.regresaron}</b><span>Piezas en la lavandería ahora</span><b>${B.en_lavanderia}</b></div>
    ${B.faltan.length ? `<div class="aviso" style="margin-top:10px"><b>Faltaron:</b> ${B.faltan.map((x) => `${x.n} ${esc(x.pieza.toLowerCase())}`).join(', ')}</div>` : '<div class="sub" style="margin-top:10px">No faltó ninguna pieza.</div>'}
    ${L.lista.length ? `<div class="tw" style="max-height:240px;margin-top:10px"><table><thead><tr><th>Terminado</th><th>Tarea</th><th>Dónde</th><th>Quién</th></tr></thead><tbody>${L.lista.map((m) => `<tr><td>${fdt(m.cierre)}</td><td>${esc(m.titulo)}</td><td>${esc(m.subtipo === 'lavanderia' ? m.destino || 'Lavandería' : m.area || '')}</td><td>${esc(m.cierre_nombre || '')}</td></tr>`).join('')}</tbody></table></div>` : ''}</div></div>`;
}
{
  const _ex = extrasHTML;
  extrasHTML = function (X, titulo) { return _ex(X, titulo) + (X.limpieza ? limpHTML(X.limpieza) : ''); };
  const _pdf = pdfExtras;
  pdfExtras = function (C) {
    const L = C.extra?.limpieza; if (!L || !L.total) return _pdf(C);
    return _pdf(C) + `<h3>Limpieza (${L.total})</h3><table><tbody><tr><td>Habitaciones</td><td class="n">${L.por.habitacion || 0}</td><td>Áreas comunes</td><td class="n">${L.por.area || 0}</td><td>Lavandería</td><td class="n">${L.por.lavanderia || 0}</td><td>Otras</td><td class="n">${L.por.otro || 0}</td></tr></tbody></table>
      <table><thead><tr><th>Persona</th><th class="n">Hab.</th><th class="n">Áreas</th><th class="n">Lavandería</th><th class="n">Otras</th><th class="n">Total</th></tr></thead><tbody>${L.personas.map((p) => `<tr><td>${esc(p.nombre)}</td><td class="n">${p.habitacion}</td><td class="n">${p.area}</td><td class="n">${p.lavanderia}</td><td class="n">${p.otro}</td><td class="n">${p.total}</td></tr>`).join('')}</tbody></table>
      <p>Blancos: se mandaron ${L.blancos.enviadas}, regresaron ${L.blancos.regresaron}${L.blancos.faltan.length ? ' · Faltaron: ' + L.blancos.faltan.map((x) => `${x.n} ${esc(x.pieza.toLowerCase())}`).join(', ') : ''} · En lavandería ahora: ${L.blancos.en_lavanderia}</p>`;
  };
  const _hj = hojasExtras;
  hojasExtras = function (X) {
    const out = _hj(X), L = X.limpieza;
    if (L) out.push({ nombre: 'Limpieza', filas: [H_('Persona', 'Habitaciones', 'Áreas comunes', 'Lavandería', 'Otras', 'Total'), ...L.personas.map((p) => [p.nombre, p.habitacion, p.area, p.lavanderia, p.otro, p.total]), [],
      [B_('Blancos'), 'Se mandaron', L.blancos.enviadas, 'Regresaron', L.blancos.regresaron, 'En lavandería', L.blancos.en_lavanderia], ...L.blancos.faltan.map((x) => ['Faltó', x.pieza, x.n])] });
    return out;
  };
}
