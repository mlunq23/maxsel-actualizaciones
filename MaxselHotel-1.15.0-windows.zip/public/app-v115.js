// Maxsel Hotel 1.15 — al registrar un huésped, el administrador puede poner otra fecha y hora de ingreso
const fechaLocal = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}T${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
const ingresoCambiado = () => !!($('#rEnt') && $('#rEnt').dataset.t && $('#rEnt').value);
{
  const _reg = registrar;
  registrar = function (id, ...a) {
    const r = _reg(id, ...a);
    if (YO?.rol !== 'admin' || !$('#rC')) return r;
    const ya = new Date();
    $('#rC').closest('.f')?.insertAdjacentHTML('beforebegin', `<div class="f r-ing"><label class="l">Fecha y hora de ingreso <span class="pill p-info" style="font-size:11px">Solo administrador</span>
      <input id="rEnt" type="datetime-local" value="${fechaLocal(ya)}" max="${fechaLocal(ya)}" oninput="this.dataset.t=1;rCalc(${id})"></label>
      <div class="sub" style="align-self:end">Déjela como está si el huésped llega ahorita. Cámbiela solo si ya estaba hospedado desde antes.</div></div>`);
    return r;
  };
}
{
  const _rc = rCalc;
  rCalc = function (id, reset) {
    const r = _rc(id, reset);
    if (!ingresoCambiado()) return r;
    const m = document.querySelector('input[name=rM]:checked')?.value; if (!m) return r;
    const desde = new Date($('#rEnt').value); if (isNaN(desde)) return r;
    const n = Math.max(1, parseInt(val('rC')) || 1);
    let s = salidaCalc(m, n, desde);
    if ($('#rSal').dataset.t && m !== 'rato') { const [a, b] = val('rSal').split(':').map(Number); if (!isNaN(a)) s.setHours(a, b || 0, 0, 0); }
    if ($('#rSal').dataset.t && m === 'rato') { const [a, b] = val('rSal').split(':').map(Number); if (!isNaN(a)) { const d = new Date(desde); d.setHours(a, b || 0, 0, 0); if (d <= desde) d.setDate(d.getDate() + 1); s = d; } }
    const res = $('#rRes'); if (!res) return r;
    res.innerHTML = res.innerHTML.replace(/<span>Check out<\/span><b>[^<]*<\/b>/, `<span>Ingreso</span><b>${fSal(desde)}</b><span>Check out</span><b>${fSal(s)}</b>`);
    if (s < new Date()) res.insertAdjacentHTML('beforeend', `<div class="aviso bad" style="grid-column:1/-1;margin:6px 0 0">Con esta fecha de ingreso la salida ya pasó. Al registrarlo, el sistema le carga a la cuenta ${m === 'mes' ? 'los meses que ya pasaron' : m === 'semana' ? 'las semanas que ya pasaron' : m === 'rato' ? 'los ratos que ya pasaron' : m === 'noche' ? 'las noches que ya pasaron' : 'los días que ya pasaron'}. Si ya pagó ese tiempo, aumente la cantidad y ponga el pago.</div>`);
    return r;
  };
}
{
  const _api = api;
  api = function (metodo, url, body) {
    if (metodo === 'POST' && url === '/api/estancias' && body && ingresoCambiado()) body = { ...body, fecha_entrada: $('#rEnt').value };
    return _api(metodo, url, body);
  };
}
