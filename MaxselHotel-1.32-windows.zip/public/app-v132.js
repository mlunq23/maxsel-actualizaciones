// Maxsel Hotel 1.32 — La pantalla ya no se regresa sola a "Habitaciones" mientras se está en Tienda, Caja u otra pantalla
// (antes: si se cambiaba de pantalla mientras Habitaciones todavía cargaba, su actualización automática seguía corriendo
// y cada 20 segundos volvía a dibujar Habitaciones encima de la venta)
'use strict';
{
  const VISTA_DE = { vHab: 'hab', vRep: 'rep', vVis: 'vis', vMant: 'mant' };
  for (const [nom, v] of Object.entries(VISTA_DE)) {
    const orig = window[nom]; if (typeof orig !== 'function') continue;
    window[nom] = async function (...a) {
      if (typeof vista !== 'undefined' && vista !== v) return; // no dibujar encima de otra pantalla
      const r = await orig.apply(this, a);
      // Si mientras cargaba se cambió de pantalla, se vuelve a dibujar la pantalla actual
      if (typeof vista !== 'undefined' && vista !== v) { const fn = { caja: 'vCaja', tienda: 'vTienda', inv: 'vInv', gastos: 'vGastos', hues: 'vHues', cfg: 'vCfg', res: 'vRes', contratos: 'vContratos', ...Object.fromEntries(Object.entries(VISTA_DE).map(([a, b]) => [b, a])) }[vista]; if (fn && typeof window[fn] === 'function') window[fn]().catch?.(() => {}); }
      return r;
    };
  }
}
