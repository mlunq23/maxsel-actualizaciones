// Maxsel Hotel 1.16 — Reiniciar ventas (como Maxsel POS) y descuento que se repite en cada renovación

// ======================================================================
// Descuento que se repite al renovar (mismo tipo de renta y mismo precio), hasta que el huésped desocupa
// ======================================================================
{
  const _rc = rCalc;
  rCalc = function (id, reset) {
    const r = _rc(id, reset);
    const dt = $('#rDt'); if (!dt) return r;
    const m = document.querySelector('input[name=rM]:checked')?.value;
    let box = $('#rDrBox');
    if (!box) {
      ($('#rDl') || dt.closest('.f'))?.insertAdjacentHTML('afterend', `<label id="rDrBox" style="display:flex;gap:8px;align-items:flex-start;margin:4px 0 6px;cursor:pointer"><input type="checkbox" id="rDr" style="margin-top:3px" onchange="this.dataset.t=1">
        <span>Repetir este descuento cada vez que renueve <span class="sub">(se quita solo cuando desocupa; la habitación conserva su precio normal)</span></span></label>`);
      box = $('#rDrBox');
    }
    const hay = !!val('rDt') && num('rDv') > 0 && m && m !== 'rato';
    box.hidden = !hay;
    if (hay && !$('#rDr').dataset.t) $('#rDr').checked = m === 'mes' || m === 'semana';
    return r;
  };
  const _api = api;
  api = function (metodo, url, body) {
    if (metodo === 'POST' && url === '/api/estancias' && body && $('#rDr') && !$('#rDrBox').hidden) body = { ...body, descuento_renueva: $('#rDr').checked };
    return _api(metodo, url, body);
  };
}
const descRenueva = (e, m, u) => (e && e.desc_renueva && m === e.modalidad && Math.abs(u - e.precio) < 0.005 ? Math.min(e.precio, Number(e.desc_periodo) || 0) : 0);
{
  const _xc = xCalc;
  xCalc = function (reset) {
    const e = xCalc.e, m = document.querySelector('input[name=xM]:checked')?.value;
    const r = _xc(reset);
    const n = Math.max(1, parseInt(val('xC')) || 1), u = num('xU'), d = descRenueva(e, m, u);
    if (d > 0 && $('#xRes')) {
      const tot = Math.max(0, u * n - d * n);
      if (!$('#xP').dataset.t) $('#xP').value = tot.toFixed(2);
      const b1 = $('#xRes b.big'); b1?.classList.remove('big');
      b1?.insertAdjacentHTML('afterend', `<span>Descuento que se repite${e.descuento_motivo ? ' (' + esc(e.descuento_motivo) + ')' : ''}</span><b style="color:var(--libre)">−${money(d * n)}</b><span>Total a pagar</span><b class="big">${money(tot)}</b>`);
      if (typeof refrescarPagos === 'function') refrescarPagos();
    } else if (e?.desc_renueva && $('#xRes')) {
      $('#xRes').insertAdjacentHTML('beforeend', '<span class="sub" style="grid-column:1/-1">Al cambiar el tipo de renta o el precio, ya no se aplica el descuento que se repetía.</span>');
    }
    return r;
  };
  const _ve = verEstancia;
  verEstancia = async function (id, ...a) {
    const r = await _ve.call(this, id, ...a);
    try {
      const e = await GET('/api/estancias/' + id), kv = $('#modal .mbody .kv');
      if (e.activa && e.desc_renueva && e.desc_periodo > 0) kv?.insertAdjacentHTML('beforeend', `<span>Descuento al renovar</span><span><b>−${money(e.desc_periodo)}</b> por cada ${MODU?.[e.modalidad]?.[0] || 'periodo'} · se quita al desocupar</span>`);
    } catch { /* nada */ }
    return r;
  };
}

// ======================================================================
// Configuración → Respaldos y licencia: Reiniciar ventas (solo administrador)
// ======================================================================
{
  const _cr = cResp;
  cResp = async function () {
    await _cr();
    if (typeof cfgTab !== 'undefined' && cfgTab !== 'resp') return;
    if (YO?.rol !== 'admin') return;
    const st = $('#cfgc .stack'); if (!st || $('#reiCard')) return;
    st.insertAdjacentHTML('beforeend', `<div class="card" id="reiCard" style="border:2px solid var(--ocup)"><h2 style="color:var(--ocup)">Reiniciar ventas (empezar de cero)</h2>
      <p class="sub" style="margin-top:0">Para dejar el hotel limpio después de hacer pruebas, o para empezar el año en ceros. Se guarda un respaldo antes de borrar.</p>
      <button class="btn bad" onclick="reiniciarVer()">Reiniciar ventas…</button></div>`);
  };
}
async function reiniciarVer() {
  let c; try { c = await GET('/api/reiniciar'); } catch (e) { return toast(e.message, true); }
  modal('Reiniciar ventas', `<div class="aviso bad" style="margin-top:0"><b>Esto no se puede deshacer</b> (solo restaurando el respaldo que se guarda antes).</div>
    <p style="margin:0 0 6px"><b>Se borran:</b> rentas y huéspedes registrados (${c.rentas}), ventas de la tienda (${c.ventas}), pagos, cortes y turnos de caja (${c.cortes}), gastos (${c.gastos}),
      depósitos, contratos, reservaciones (${c.reservaciones} por llegar), mantenimiento y limpieza, asistencia, nómina, inventarios, cuentas por pagar e historial. Los folios vuelven a empezar en 1 y todas las habitaciones quedan libres.</p>
    <p style="margin:0 0 10px"><b>NO se borran:</b> habitaciones y precios, productos y existencias, usuarios y contraseñas, empleados, proveedores, la base de huéspedes y no deseados, logo, contrato, licencia ni la configuración.</p>
    ${c.hospedados ? `<label style="display:flex;gap:8px;align-items:flex-start;margin-bottom:10px;cursor:pointer"><input type="checkbox" id="reiH" style="margin-top:3px"> <span>También borrar los <b>${c.hospedados} huésped(es) hospedado(s) ahorita</b> (sus habitaciones quedan libres)</span></label>` : ''}
    <label class="l">Para confirmar escriba <b>BORRAR</b><input id="reiW" autocomplete="off"></label>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn bad" id="reiOk" onclick="reiniciarOk()">Reiniciar ventas</button>`);
}
async function reiniciarOk() {
  if (val('reiW').trim().toUpperCase() !== 'BORRAR') return toast('Escriba BORRAR para confirmar', true);
  const b = $('#reiOk'); b.disabled = true; b.textContent = 'Borrando…';
  try {
    const r = await POST('/api/reiniciar', { confirmar: val('reiW'), con_hospedados: !!$('#reiH')?.checked });
    modal('Ventas reiniciadas', `<p>El hotel quedó en ceros: habitaciones libres y folios en 1.</p><p>Lo que había antes quedó respaldado en <span class="mono">${esc(r.respaldo || '')}</span> (carpeta de respaldos).</p>`,
      '<button class="btn pri" onclick="location.reload()">Listo</button>');
  } catch (e) { b.disabled = false; b.textContent = 'Reiniciar ventas'; toast(e.message, true); }
}
