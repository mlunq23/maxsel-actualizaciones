// Permisos que el administrador puede dar o quitar a cada usuario de Maxsel Carwash
export const PERMISOS = [
  { grupo: 'Caja', clave: 'caja', texto: 'Abrir y cerrar su turno de caja y cobrar' },
  { grupo: 'Caja', clave: 'movimientos', texto: 'Registrar ingresos y egresos de caja' },
  { grupo: 'Caja', clave: 'cajon', texto: 'Abrir el cajón de dinero sin cobrar' },
  { grupo: 'Caja', clave: 'ver_corte', texto: 'Ver lo que debería haber al cerrar su turno (si no, el cierre es a ciegas)' },
  { grupo: 'Caja', clave: 'cancelar', texto: 'Cancelar ventas y gastos' },
  { grupo: 'Caja', clave: 'autorizar', texto: 'Autorizar egresos de caja con su clave' },
  { grupo: 'Caja', clave: 'tipo_cambio', texto: 'Cambiar el tipo de cambio del dólar con el turno abierto' },
  { grupo: 'Punto de venta', clave: 'vender', texto: 'Vender paquetes de lavado, servicios y productos' },
  { grupo: 'Punto de venta', clave: 'reimprimir', texto: 'Reimprimir tickets ya cobrados (F11 y Ventas del día)' },
  { grupo: 'Punto de venta', clave: 'ventas_dia', texto: 'Ver las ventas del día y el total vendido en el punto de venta (F3)' },
  { grupo: 'Punto de venta', clave: 'inventario', texto: 'Registrar entradas de mercancía y conteos' },
  { grupo: 'Punto de venta', clave: 'productos', texto: 'Dar de alta, editar y borrar paquetes, productos y precios' },
  { grupo: 'Lavadores', clave: 'lavadores', texto: 'Dar de alta lavadores, tiempos de lavado y comisiones' },
  { grupo: 'Lavadores', clave: 'comisiones', texto: 'Pagar las comisiones de los lavadores (sale como gasto de la caja)' },
  { grupo: 'Gastos', clave: 'gastos', texto: 'Registrar gastos y firmarlos' },
  { grupo: 'Gastos', clave: 'cuentas_pagar', texto: 'Dar de alta y pagar cuentas por pagar a proveedores' },
  { grupo: 'Gastos', clave: 'personal', texto: 'Administrar empleados (sueldos y datos) y proveedores, y pagar la nómina' },
  { grupo: 'Asistencia', clave: 'checador', texto: 'Usar el checador de entradas y salidas en esta computadora' },
  { grupo: 'Asistencia', clave: 'asistencia', texto: 'Ver y corregir asistencias, horarios, festivos, vacaciones y reportes' },
  { grupo: 'Administración', clave: 'reportes', texto: 'Ver reportes de ventas, paquetes vendidos y gastos' },
  { grupo: 'Administración', clave: 'cortes', texto: 'Ver los cortes de caja de todos los usuarios' },
  { grupo: 'Administración', clave: 'usuarios', texto: 'Administrar usuarios y sus permisos' },
  { grupo: 'Administración', clave: 'config', texto: 'Configuración del negocio, impresora, pantalla del cliente, nube y respaldos' },
];
const RECEPCION = ['checador', 'caja', 'movimientos', 'cajon', 'vender', 'inventario', 'gastos', 'comisiones'];
export const PERMISOS_ROL = {
  admin: PERMISOS.map((p) => p.clave),
  // Gerente: todo menos administrar usuarios y la configuración general
  gerente: PERMISOS.map((p) => p.clave).filter((k) => k !== 'usuarios' && k !== 'config'),
  recepcion: RECEPCION,
  monitor: ['reportes', 'cortes'],
  mantenimiento: [],
};
const VALIDOS = new Set(PERMISOS.map((p) => p.clave));

// Permisos efectivos de un usuario. El administrador siempre tiene todo.
export function permisosDe(u) {
  if (!u) return [];
  if (u.rol === 'admin') return PERMISOS_ROL.admin;
  if (u.permisos) {
    try { const l = JSON.parse(u.permisos); if (Array.isArray(l)) return l.filter((k) => VALIDOS.has(k) && k !== 'usuarios'); } catch { /* usar los del rol */ }
  }
  return PERMISOS_ROL[u.rol] || [];
}
export const limpiarPermisos = (lista) => (Array.isArray(lista) ? [...new Set(lista.filter((k) => VALIDOS.has(k)))] : null);
