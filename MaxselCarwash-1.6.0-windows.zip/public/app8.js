// Maxsel Hotel 1.8 — multas y cuotas, egresos con clave de gerente, escáner en tienda, Excel de productos,
// cuentas por pagar, reloj checador por red, unidades de negocio, gráfica de pastel y venta promedio diaria
'use strict';

// ---------- Multas, cuotas e intereses en la cuenta del huésped ----------
function cargoModal(eid) {
  const M = multasCfg();
  const ops = [...M.map((m, i) => [`multa:${i}`, `Multa: ${m.nombre}`, m.monto, 'multa', m.nombre]),
    ['limpieza', 'Servicio de limpieza', Number(CFG.cuota_limpieza) || 0, 'limpieza', 'Servicio de limpieza'],
    ['mascota', 'Cuota por mascota', Number(CFG.cuota_mascota) || 0, 'mascota', 'Cuota por mascota'],
    ['multa:x', 'Otra multa (escribir)', 0, 'multa', ''], ['mora', 'Interés moratorio (manual)', 0, 'mora', 'Interés moratorio'], ['otro', 'Otro cargo', 0, 'otro', '']];
  cargoModal.ops = ops;
  modal('Multa o cargo', `<label class="l">¿Qué se cobra?<select id="cgT" onchange="cargoSel()">${ops.map((o) => `<option value="${o[0]}">${esc(o[1])}${o[2] ? ' · ' + money(o[2]) : ''}</option>`).join('')}</select></label>
    <div class="f"><label class="l">Descripción<input id="cgD"></label><label class="l">Cantidad<input id="cgC" type="number" min="1" value="1" oninput="cargoSel(1)"></label><label class="l">Monto c/u<input id="cgM" type="number" min="0" step="0.01" oninput="cargoSel(1)"></label></div>
    <label class="l">Nota (qué pasó)<input id="cgN" placeholder="Ej. 2:30 am, queja del cuarto 104"></label>
    <div class="calc" id="cgR"></div>
    <div class="seg"><label><input type="radio" name="cgCo" value="cuenta" checked onchange="$('#cgPg').hidden=true">Cargar a la cuenta (se cobra al salir)</label><label><input type="radio" name="cgCo" value="ahora" onchange="$('#cgPg').hidden=false">Cobrar ahora</label></div>
    <div id="cgPg" hidden><div class="l">Método de pago${selPago('cgF', null, '', 'cgTot')}</div><input type="hidden" id="cgTot"></div>`,
  `<button class="btn" onclick="verEstancia(${eid})">Volver</button><button class="btn pri" onclick="cargoOk(${eid})">Guardar</button>`);
  cargoSel();
}
function cargoSel(soloTotal) {
  const o = cargoModal.ops.find((x) => x[0] === val('cgT'));
  if (!soloTotal) { $('#cgD').value = o[4]; $('#cgM').value = o[2] ? o[2].toFixed(2) : ''; }
  const t = (parseInt(val('cgC')) || 1) * num('cgM'); $('#cgTot').value = t.toFixed(2);
  $('#cgR').innerHTML = `<span>Total</span><b class="big">${money(t)}</b>`;
  if (typeof refrescarPagos === 'function') refrescarPagos();
}
async function cargoOk(eid) {
  const o = cargoModal.ops.find((x) => x[0] === val('cgT')), ahora = document.querySelector('input[name=cgCo]:checked').value === 'ahora';
  const r = await hacer(() => POST(`/api/estancias/${eid}/cargo`, { tipo: o[3], descripcion: val('cgD') || o[1], cantidad: val('cgC'), monto: val('cgM'), nota: val('cgN'), cobrar: ahora, ...(ahora ? pagoDe('cgF') : {}) }), ahora ? 'Cobrado' : 'Cargado a la cuenta');
  if (r?.pago?.cambio > 0) toast('Entregue de cambio ' + money(r.pago.cambio));
  if (ahora) { const w = W(); imprimir([...encabezado(), (TIPOS_CARGO[o[3]] || 'Cargo').toUpperCase(), fdt(new Date().toISOString().slice(0, 19).replace('T', ' ')), '-'.repeat(w), ...wrapT(val('cgD') || o[1]), ...(val('cgN') ? wrapT('Nota: ' + val('cgN')) : []), lin('Total', money((parseInt(val('cgC')) || 1) * num('cgM'))), ...lineasPago(r?.pago), '', CFG.ticket_pie || '']); }
  verEstancia(eid); vHab(); pintarTurno();
}
async function cargoQuitar(id, eid) { await hacer(() => DEL('/api/cargos/' + id), 'Cargo quitado'); verEstancia(eid); vHab(); }

// ---------- Egreso de caja: clave de gerente o administrador ----------
const pideClave = () => CFG.autoriza_egresos !== '0' && !puede('autorizar');
function movModal(tipo) {
  const clave = tipo !== 'ingreso' && pideClave();
  modal(tipo === 'ingreso' ? 'Registrar ingreso a caja' : 'Registrar egreso de caja', `<div class="f"><label class="l">Moneda<select id="mvM"><option value="MXN">Pesos</option><option value="USD">Dólares</option></select></label><label class="l">Monto<input id="mvC" type="number" min="0" step="0.01"></label></div>
    <label class="l">Motivo<input id="mvT" placeholder="${tipo === 'ingreso' ? 'Ej. cambio, morralla' : 'Ej. retiro del dueño, pago de garrafones'}"></label>
    ${clave ? `<div class="card autoriza"><div class="lbl">${ico('llave')} Autoriza el gerente o el administrador</div><div class="f"><label class="l">Usuario<input id="mvAu" autocomplete="off" autocapitalize="off"></label><label class="l">Contraseña<input id="mvAp" type="password" autocomplete="new-password"></label></div><div class="sub">Los egresos de caja solo salen con la clave de un gerente o del administrador.</div></div>` : ''}`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="movOk('${tipo}')">Guardar</button>`);
}
async function movOk(tipo) {
  const mon = val('mvM'), monto = num('mvC'), motivo = val('mvT'), au = $('#mvAu') ? { usuario: val('mvAu'), password: $('#mvAp').value } : undefined;
  await hacer(() => POST('/api/turno/movimiento', { tipo, moneda: mon, monto, motivo, autoriza: au }), tipo === 'ingreso' ? 'Ingreso a caja registrado' : 'Egreso de caja registrado');
  cerrar(); vCaja(); pintarTurno(); const w = W();
  imprimir([...encabezado(), tipo === 'ingreso' ? 'INGRESO A CAJA' : 'EGRESO DE CAJA', '-'.repeat(w), lin('Fecha', fdt(new Date().toISOString().slice(0, 19).replace('T', ' '))), lin('Usuario', YO.nombre),
    ...(tipo !== 'ingreso' ? [lin('Autorizó', au ? au.usuario : YO.nombre)] : []), lin('Monto', mon === 'USD' ? 'US$' + monto.toFixed(2) : money(monto)), ...wrapT('Motivo: ' + motivo), '', '', '_'.repeat(Math.min(30, w)), 'Firma'], tipo === 'ingreso' ? 'Ingreso a caja' : 'Egreso de caja');
}
// Gastos en efectivo de la caja (opcional): también piden clave
if (typeof gastoModal === 'function') {
  const _gm = gastoModal;
  gastoModal = async function (...a) {
    const r = await _gm(...a);
    if (CFG.autoriza_gastos === '1' && !puede('autorizar') && TURNO?.turno) $('#modal .mbody')?.insertAdjacentHTML('beforeend', `<div class="card autoriza" style="margin-top:10px"><div class="lbl">Si se paga en efectivo con dinero de la caja, autoriza el gerente</div><div class="f"><label class="l">Usuario<input id="gaAu" autocomplete="off" autocapitalize="off"></label><label class="l">Contraseña<input id="gaAp" type="password" autocomplete="new-password"></label></div></div>`);
    return r;
  };
}

// ---------- Tienda: siempre lista para escanear ----------
// El lector de código de barras "teclea" muy rápido y termina con Enter. Si el cursor está en otro campo
// (por ejemplo en el pago), se reconoce el código, se regresa lo que ya había en ese campo y se agrega el producto.
const SCAN = { buf: '', t: 0, el: null, val: '' };
document.addEventListener('keydown', (e) => {
  if (vista !== 'tienda' || !$('#qP') || !$('#modal').hidden) return;
  const t = performance.now(), qp = $('#qP');
  if (e.key === 'Enter') {
    const code = SCAN.buf.trim(), rapido = code.length >= 4 && t - SCAN.t < 80;
    SCAN.buf = '';
    if (rapido && SCAN.el && SCAN.el !== qp) {
      e.preventDefault(); e.stopPropagation();
      if ('value' in SCAN.el) SCAN.el.value = SCAN.val;
      const p = PRODS.find((x) => x.codigo && x.codigo === code);
      if (p) { qProd = ''; agregar(p.id); } else toast('No hay producto con el código ' + code, true);
      setTimeout(() => $('#qP')?.focus(), 0);
    }
    return;
  }
  if (e.key.length === 1 && !e.ctrlKey && !e.altKey && !e.metaKey) {
    if (t - SCAN.t > 80) { SCAN.buf = ''; SCAN.el = document.activeElement; SCAN.val = SCAN.el && 'value' in SCAN.el ? SCAN.el.value : ''; }
    SCAN.buf += e.key; SCAN.t = t;
    const a = document.activeElement;
    if (!a || a === document.body || a.tagName === 'BUTTON') { qp.focus(); }
  }
}, true);
// Si nada tiene el cursor, regresa al buscador para que el siguiente escaneo entre directo
setInterval(() => { if (vista === 'tienda' && $('#modal').hidden) { const a = document.activeElement; if (!a || a === document.body) $('#qP')?.focus(); } }, 1200);
{
  const _qPkey = pintarTienda;
  pintarTienda = function (v) {
    _qPkey(v);
    const qp = $('#qP'); if (!qp) return;
    const viejo = qp.onkeydown;
    qp.onkeydown = (e) => {
      if (e.key === 'Enter') {
        const c = qp.value.trim(), p = PRODS.find((x) => x.codigo && x.codigo === c);
        if (!p && c && /^\d{4,}$/.test(c) && !PRODS.some((x) => (x.nombre + ' ' + (x.codigo || '')).toLowerCase().includes(c.toLowerCase()))) { qProd = ''; pintarTienda(pintarTienda.v); toast('No hay producto con el código ' + c, true); return; }
      }
      viejo?.(e);
    };
  };
}

// ---------- Productos: exportar e importar de Excel ----------
function exportarProductos() {
  const filas = [H_('Código', 'Nombre', 'Área', 'Costo', 'Precio', 'Existencia', 'Mínimo'), ...PRODS.slice().sort((a, b) => String(a.area || '').localeCompare(String(b.area || ''), 'es') || a.nombre.localeCompare(b.nombre, 'es'))
    .map((p) => [p.codigo || '', p.nombre, p.area || '', M_(p.costo), M_(p.precio), p.existencia, p.minimo])];
  descargarArchivo(XLSX.libro([{ nombre: 'Productos', filas }]), `Productos tienda - ${CFG.hotel_nombre}.xlsx`);
}
const COLS_PROD = (t) => { t = normT(t); if (!t) return null; if (t.includes('cod') || t.includes('barra')) return 'codigo'; if (t.includes('area') || t.includes('depart') || t.includes('categ') || t.includes('famil') || t.includes('linea')) return 'area';
  if (t.includes('costo') || t.includes('compra')) return 'costo'; if (t.includes('precio') || t.includes('venta')) return 'precio'; if (t.includes('exist') || t.includes('stock') || t.includes('cantidad') || t.includes('inventario')) return 'existencia';
  if (t.includes('min')) return 'minimo'; if (t.includes('nombre') || t.includes('producto') || t.includes('descrip') || t.includes('articulo')) return 'nombre'; return null; };
function importarProductos() {
  modal('Importar productos de Excel', `<p class="sub" style="margin:0">Una hoja con un producto por renglón y los títulos en el primer renglón: <b>Código, Nombre, Área, Costo, Precio, Existencia, Mínimo</b>. Solo Nombre y Precio son obligatorios. Puede bajar su lista con "Exportar a Excel", cambiarla y volverla a subir.</p>
    <div class="row" style="flex-wrap:wrap;gap:8px"><button class="btn" onclick="exportarProductos()">Bajar mi lista actual (sirve de plantilla)</button><label class="btn pri" style="cursor:pointer">Elegir archivo (.xlsx o .csv)<input type="file" accept=".xlsx,.csv,.txt" hidden onchange="archivoProd(this.files[0])"></label></div>
    <label class="l">O copie las celdas en Excel y péguelas aquí<textarea id="ipP" rows="3" oninput="clearTimeout(importarProductos.t);importarProductos.t=setTimeout(()=>prevProd(leerTexto(this.value)),300)"></textarea></label>
    <label class="l">Si el producto ya existe (mismo código o nombre), la existencia del Excel<select id="ipE"><option value="sumar">Se SUMA a la que ya hay (llegó mercancía)</option><option value="reemplazar">REEMPLAZA a la que hay (conteo de inventario)</option></select></label>
    <div id="ipPrev"></div>`, `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" id="ipOk" disabled onclick="importarProdOk()">Importar</button>`, true);
}
async function archivoProd(f) {
  if (!f) return;
  try { prevProd(/\.xlsx$/i.test(f.name) ? await leerXlsx(await f.arrayBuffer()) : leerTexto(await f.text())); } catch (e) { toast(e.message || 'No se pudo leer el archivo', true); }
}
function prevProd(filas) {
  const pv = $('#ipPrev'), ok = $('#ipOk');
  if (!filas?.length) { pv.innerHTML = ''; ok.disabled = true; return; }
  const cab = filas[0].map(COLS_PROD);
  if (!cab.includes('nombre')) { pv.innerHTML = '<div class="aviso bad">No encontré la columna <b>Nombre</b>. El primer renglón debe tener los títulos.</div>'; ok.disabled = true; return; }
  const L = filas.slice(1).map((f) => { const r = {}; cab.forEach((k, j) => { if (k && f[j] !== undefined && String(f[j]).trim() !== '') r[k] = String(f[j]).trim(); }); for (const k of ['costo', 'precio', 'existencia', 'minimo']) if (r[k] !== undefined) r[k] = parseFloat(String(r[k]).replace(/[$,\s]/g, '')) || 0; return r; }).filter((r) => r.nombre);
  prevProd.L = L;
  const ex = new Set(PRODS.map((p) => (p.codigo || '').toLowerCase()).filter(Boolean)), exN = new Set(PRODS.map((p) => p.nombre.toLowerCase()));
  const nuevos = L.filter((r) => !(r.codigo && ex.has(r.codigo.toLowerCase())) && !exN.has(r.nombre.toLowerCase())).length, sinPrecio = L.filter((r) => !(r.precio > 0)).length;
  pv.innerHTML = `<div class="aviso">Se crearán <b>${nuevos}</b> productos y se actualizarán <b>${L.length - nuevos}</b>.${sinPrecio ? ` <b style="color:var(--ocup)">${sinPrecio} sin precio no se van a importar.</b>` : ''}</div>
    <div class="tw" style="max-height:280px"><table><thead><tr><th>Código</th><th>Nombre</th><th>Área</th><th class="n">Costo</th><th class="n">Precio</th><th class="n">Existencia</th><th class="n">Mínimo</th></tr></thead><tbody>
    ${L.slice(0, 200).map((r) => `<tr><td class="mono">${esc(r.codigo || '')}</td><td>${esc(r.nombre)}</td><td>${esc(r.area || '')}</td><td class="n">${r.costo !== undefined ? money(r.costo) : ''}</td><td class="n">${r.precio > 0 ? money(r.precio) : '<span class="pill p-bad">Sin precio</span>'}</td><td class="n">${r.existencia ?? ''}</td><td class="n">${r.minimo ?? ''}</td></tr>`).join('')}</tbody></table></div>`;
  ok.disabled = !L.length; ok.textContent = L.length ? `Importar ${L.length} productos` : 'Importar';
}
async function importarProdOk() {
  const r = await hacer(() => POST('/api/productos/importar', { productos: prevProd.L, existencia: val('ipE') }));
  cerrar(); toast(`Listo: ${r.creados} nuevos, ${r.actualizados} actualizados${r.errores.length ? ` · ${r.errores.length} con error` : ''}`, !!r.errores.length);
  if (r.errores.length) modal('Productos con error', `<div class="aviso bad">${r.errores.slice(0, 30).map(esc).join('<br>')}</div>`, '<button class="btn" onclick="cerrar()">Cerrar</button>');
  vInv();
}

// ---------- Cuentas por pagar a proveedores ----------
let CXP = [], CXP_AV = [], cxpF = 'abiertas';
const EST_CXP = { pendiente: ['Se debe', 'cx-debe'], vencida: ['Vencida', 'cx-vencida'], pagada: ['Pagada', 'cx-pagada'] };
async function cxpAvisos() { try { CXP_AV = puede('cuentas_pagar') ? await GET('/api/cuentas-pagar/avisos') : []; } catch { CXP_AV = []; } return CXP_AV; }
{
  const _av = avisosGastos;
  avisosGastos = async function () {
    const a = await _av(); await cxpAvisos();
    const n = (a?.length || 0) + CXP_AV.length; ir.badge = { ...(ir.badge || {}), gastos: n || '' }; pintarNav(ir.badge);
    return a;
  };
}
const diasCxp = (c) => (c.estado === 'pagada' ? 'Pagada' : c.dias === null ? 'Sin fecha límite' : c.dias < 0 ? `venció hace ${-c.dias} día${c.dias === -1 ? '' : 's'}` : c.dias === 0 ? 'vence HOY' : c.dias === 1 ? 'vence mañana' : `vence en ${c.dias} días`);
async function tablaCxp() {
  CXP = await GET('/api/cuentas-pagar?estado=' + cxpF);
  const todas = cxpF === 'abiertas' ? CXP : await GET('/api/cuentas-pagar?estado=abiertas');
  const deb = todas.filter((c) => c.estado === 'pendiente'), ven = todas.filter((c) => c.estado === 'vencida'), S = (l) => l.reduce((s, c) => s + c.saldo, 0);
  const F = [['abiertas', 'Por pagar'], ['vencida', 'Vencidas'], ['pagada', 'Pagadas'], ['todas', 'Todas']];
  return `<div class="kpis"><div class="kpi cx-debe"><span>Se debe (a tiempo)</span><b>${money(S(deb))}</b><div class="sub">${deb.length} cuenta(s)</div></div><div class="kpi cx-vencida"><span>Vencido</span><b>${money(S(ven))}</b><div class="sub">${ven.length} cuenta(s) pasadas de la fecha</div></div><div class="kpi"><span>Total por pagar</span><b>${money(S(deb) + S(ven))}</b><div class="sub">${CXP_AV.length} con aviso</div></div></div>
    <div class="card"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:10px"><div class="seg sm">${F.map(([k, n]) => `<label><input type="radio" name="cxF" ${cxpF === k ? 'checked' : ''} onchange="cxpF='${k}';vGastos()">${n}</label>`).join('')}</div>
      <div class="leyenda" style="margin:0"><span><i style="background:var(--cx-debe)"></i>Se debe</span><span><i style="background:var(--cx-pagada)"></i>Pagada</span><span><i style="background:var(--cx-vencida)"></i>Pasó la fecha límite</span></div></div>
    <div class="tw"><table><thead><tr><th>Proveedor</th><th>Concepto</th><th>Factura</th><th>Fecha</th><th>Vence</th><th class="n">Monto</th><th class="n">Pagado</th><th class="n">Debe</th><th>Estado</th><th></th></tr></thead><tbody>
    ${CXP.map((c) => `<tr class="click cxr ${EST_CXP[c.estado]?.[1] || ''}" onclick="cxpVer(${c.id})"><td><b>${esc(c.proveedor || '—')}</b></td><td>${esc(c.concepto)}</td><td class="mono">${esc(c.factura || '')}</td><td>${fd(c.fecha)}</td><td>${c.vence ? fd(c.vence) : '—'}<div class="sub">${diasCxp(c)}</div></td>
      <td class="n">${money(c.monto)}</td><td class="n">${money(c.pagado)}</td><td class="n"><b>${money(c.saldo)}</b></td><td><span class="pill ${EST_CXP[c.estado]?.[1] || ''}">${EST_CXP[c.estado]?.[0] || c.estado}</span>${c.por_vencer ? ' <span class="pill p-warn">Por vencer</span>' : ''}</td>
      <td>${c.estado !== 'pagada' ? `<button class="btn sm pri" onclick="event.stopPropagation();cxpPagar(${c.id})">Pagar</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="10" class="empty">No hay cuentas en esta vista. Registre aquí las facturas o notas que le quedan a deber a sus proveedores.</td></tr>'}</tbody></table></div></div>`;
}
async function cxpModal(id) {
  const P = await GET('/api/proveedores/lista'), c = id ? CXP.find((x) => x.id === id) || cxpVer.c : { proveedor_id: '', concepto: '', factura: '', categoria: 'Pago a proveedores', monto: '', fecha: hoyISO(), vence: (() => { const d = new Date(); d.setDate(d.getDate() + 15); return d.toISOString().slice(0, 10); })(), notas: '' };
  modal(id ? 'Editar cuenta por pagar' : 'Nueva cuenta por pagar', `<div class="f"><label class="l">Proveedor<select id="cxP"><option value="">— Elija —</option>${P.map((p) => `<option value="${p.id}" ${String(p.id) === String(c.proveedor_id) ? 'selected' : ''}>${esc(p.nombre)}</option>`).join('')}</select></label>
      <label class="l">Concepto<input id="cxC" value="${esc(c.concepto)}" placeholder="Refrescos, blancos, material…"></label><label class="l">Factura / nota<input id="cxFa" value="${esc(c.factura || '')}"></label>
      <label class="l">Clasificación${selCategoria('cxCa', c.categoria)}</label><label class="l">Monto que se debe<input id="cxM" type="number" min="0" step="0.01" value="${c.monto || ''}"></label>
      <label class="l">Fecha de la factura<input id="cxFe" type="date" value="${esc(c.fecha || hoyISO())}"></label><label class="l">Fecha límite de pago<input id="cxV" type="date" value="${esc(c.vence || '')}"></label></div>
    <label class="l">Notas<input id="cxN" value="${esc(c.notas || '')}" placeholder="Crédito a 15 días, cuenta para depósito…"></label>
    ${P.length ? '' : '<div class="aviso">Primero dé de alta al proveedor en la pestaña Proveedores (o déjelo vacío).</div>'}`,
  `${id && !c.pagado ? `<button class="btn bad" onclick="confirmar(this,()=>cxpBorrar(${id}))">Cancelar cuenta</button>` : ''}<button class="btn" onclick="cerrar()">Cerrar</button><button class="btn pri" onclick="cxpOk(${id || 0})">Guardar</button>`);
}
async function cxpOk(id) {
  const b = { proveedor_id: val('cxP'), concepto: val('cxC'), factura: val('cxFa'), categoria: val('cxCa'), monto: val('cxM'), fecha: val('cxFe'), vence: val('cxV'), notas: val('cxN') };
  await hacer(() => (id ? PUT('/api/cuentas-pagar/' + id, b) : POST('/api/cuentas-pagar', b)), 'Cuenta guardada'); cerrar(); await avisosGastos(); gTab = 'cxp'; vGastos();
}
async function cxpBorrar(id) { await hacer(() => DEL('/api/cuentas-pagar/' + id), 'Cuenta cancelada'); cerrar(); await avisosGastos(); vGastos(); }
async function cxpVer(id) {
  const c = await GET('/api/cuentas-pagar/' + id); cxpVer.c = c;
  modal(`Cuenta por pagar · ${esc(c.proveedor || '')}`, `<div class="row"><span class="pill ${EST_CXP[c.estado]?.[1] || ''}">${EST_CXP[c.estado]?.[0] || c.estado}</span><span class="sub">${diasCxp(c)}</span></div>
    <div class="kv"><span>Concepto</span><b>${esc(c.concepto)}</b><span>Factura</span><span>${esc(c.factura || '—')}</span><span>Clasificación</span><span>${esc(c.categoria || '')}</span><span>Fecha</span><span>${fd(c.fecha)}</span><span>Fecha límite</span><span>${c.vence ? fd(c.vence) : '—'}</span>${c.notas ? `<span>Notas</span><span>${esc(c.notas)}</span>` : ''}</div>
    <div class="calc"><span>Monto</span><b>${money(c.monto)}</b><span>Pagado</span><b>${money(c.pagado)}</b><span>Debe</span><b class="big" style="color:${c.saldo > 0 ? 'var(--ocup)' : 'var(--libre)'}">${money(c.saldo)}</b></div>
    <div class="lbl">Pagos</div>${c.pagos.length ? `<div class="tw"><table><tbody>${c.pagos.map((p) => `<tr class="click" onclick="verGasto(${p.gasto_id})"><td>${fdt(p.fecha)}</td><td class="mono">${esc(p.folio || '')}</td><td>${MET[p.metodo] || ''}</td><td>${esc(p.usuario || '')}</td><td class="n">${money(p.monto)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="sub">Sin pagos.</div>'}`,
  `<button class="btn" onclick="cerrar()">Cerrar</button><button class="btn" onclick="cxpModal(${id})">Editar</button>${c.saldo > 0 ? `<button class="btn pri" onclick="cxpPagar(${id})">Pagar</button>` : ''}`);
}
async function cxpPagar(id) {
  const c = await GET('/api/cuentas-pagar/' + id);
  modal(`Pagar a ${esc(c.proveedor || 'proveedor')}`, `<div class="kv"><span>Concepto</span><b>${esc(c.concepto)}${c.factura ? ' · ' + esc(c.factura) : ''}</b><span>Debe</span><b>${money(c.saldo)}</b><span>Fecha límite</span><span>${c.vence ? fd(c.vence) + ' (' + diasCxp(c) + ')' : '—'}</span></div>
    <div class="f"><label class="l">Monto que paga<input id="cpM" type="number" min="0" step="0.01" value="${c.saldo.toFixed(2)}"></label><label class="l">Método de pago${selPago('cpMe', null, 'sindolar')}</label></div>
    <label class="row" style="font-weight:600"><input type="checkbox" id="cpFu"> Se pagó por fuera (no sale del dinero de la caja del turno)</label><label class="l">Nota<input id="cpN" placeholder="Folio de transferencia, quién pagó…"></label>
    <div class="sub">Se registra en Gastos a nombre del proveedor. Si paga menos del total queda como abono.</div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="cxpPagarOk(${id})">Registrar pago</button>`);
}
async function cxpPagarOk(id) {
  const r = await hacer(() => POST(`/api/cuentas-pagar/${id}/pagar`, { monto: val('cpM'), metodo: val('cpMe'), fuera_de_caja: $('#cpFu').checked, nota: val('cpN') }), 'Pago registrado');
  cerrar(); toast(r.saldo > 0 ? 'Abono registrado. Todavía se deben ' + money(r.saldo) : 'Cuenta pagada'); await avisosGastos(); gTab = 'cxp'; vGastos(); pintarTurno();
}

// ---------- Asistencia: reloj checador por red (ZKTeco) ----------
{
  const _ar = aReglas;
  aReglas = async function () {
    _ar();
    const R = await GET('/api/relojes').catch(() => []), ip = (CFG._ips || []).find((x) => !x.tailscale)?.ip || 'IP de esta computadora';
    $('#asisc').insertAdjacentHTML('beforeend', `<div class="card" style="max-width:760px;margin-top:16px"><h2>Reloj checador por red (ZKTeco)</h2>
      <p class="sub" style="margin-top:0">Los relojes ZKTeco con <b>ADMS / Servidor en la nube</b> mandan las checadas solos por la red. En el reloj: <b>Menú → Comunicación → Servidor en la nube</b>: dirección <b class="mono">${esc(ip)}</b>, puerto <b class="mono">${CFG._puerto || 3070}</b>, sin HTTPS. El <b>número de usuario</b> en el reloj debe ser igual al "Número para checar" del empleado. La primera vez que el reloj se conecta aparece aquí: actívelo para empezar a recibir checadas.</p>
      <div class="tw"><table><thead><tr><th>Reloj (número de serie)</th><th>Nombre</th><th>IP</th><th>Última conexión</th><th>Recibir checadas</th><th></th></tr></thead><tbody>
      ${R.map((r) => `<tr><td class="mono">${esc(r.sn)}</td><td><input value="${esc(r.nombre || '')}" id="rlN_${esc(r.sn)}" style="width:150px"></td><td class="mono">${esc(r.ip || '')}</td><td>${fdt(r.ultimo)}</td>
        <td><label class="row" style="font-weight:600"><input type="checkbox" ${r.activo ? 'checked' : ''} onchange="relojOk('${esc(r.sn)}',this.checked)"> ${r.activo ? '<span class="pill p-ok">Activo</span>' : '<span class="pill p-warn">Esperando autorización</span>'}</label></td>
        <td><button class="btn sm bad" onclick="confirmar(this,()=>relojBorrar('${esc(r.sn)}'))">Quitar</button></td></tr>`).join('') || '<tr><td colspan="6" class="empty">Aún no se ha conectado ningún reloj.</td></tr>'}</tbody></table></div>
      <label class="l" style="margin-top:10px;max-width:420px">Cada checada del reloj se toma como<select id="rlE" onchange="relojEstado()"><option value="auto">Automático: el sistema decide entrada, comida o salida</option><option value="reloj" ${CFG.reloj_estado === 'reloj' ? 'selected' : ''}>La tecla que oprime el empleado en el reloj (Entrada/Salida)</option></select></label></div>`);
  };
}
async function relojOk(sn, activo) { await hacer(() => PUT('/api/relojes/' + encodeURIComponent(sn), { activo, nombre: val('rlN_' + sn) }), activo ? 'Reloj activado' : 'Reloj desactivado'); aReglas(); }
async function relojBorrar(sn) { await hacer(() => DEL('/api/relojes/' + encodeURIComponent(sn)), 'Reloj quitado'); aReglas(); }
async function relojEstado() { await hacer(() => PUT('/api/config', { reloj_estado: val('rlE') }), 'Guardado'); CFG.reloj_estado = val('rlE'); }

// ---------- Gráfica de pastel ----------
const COL_PASTEL = ['#2563eb', '#e07a10', '#16a34a', '#b4237a', '#0d9488', '#7c3aed', '#dc2626', '#ca8a04', '#0891b2', '#4b5563', '#db2777', '#65a30d'];
function pastelSVG(items, tam = 220) {
  const tot = items.reduce((s, x) => s + x.valor, 0); if (!tot) return '<div class="empty">Sin ingresos en el periodo.</div>';
  const r = tam / 2, c = r; let a0 = -Math.PI / 2;
  const seg = items.map((x, i) => {
    const f = x.valor / tot, a1 = a0 + f * 2 * Math.PI, col = COL_PASTEL[i % COL_PASTEL.length];
    let d;
    if (f > 0.9999) d = `<circle cx="${c}" cy="${c}" r="${r}" fill="${col}"/>`;
    else { const x0 = c + r * Math.cos(a0), y0 = c + r * Math.sin(a0), x1 = c + r * Math.cos(a1), y1 = c + r * Math.sin(a1); d = `<path d="M${c},${c} L${x0.toFixed(2)},${y0.toFixed(2)} A${r},${r} 0 ${f > 0.5 ? 1 : 0} 1 ${x1.toFixed(2)},${y1.toFixed(2)} Z" fill="${col}"><title>${esc(x.nombre)}: ${money(x.valor)} (${(f * 100).toFixed(1)}%)</title></path>`; }
    const am = (a0 + a1) / 2, txt = f >= 0.06 ? `<text x="${(c + r * 0.62 * Math.cos(am)).toFixed(1)}" y="${(c + r * 0.62 * Math.sin(am)).toFixed(1)}" text-anchor="middle" dominant-baseline="middle" font-size="13" font-weight="700" fill="#fff">${Math.round(f * 100)}%</text>` : '';
    a0 = a1; return d + txt;
  }).join('');
  return `<div class="pastel"><svg viewBox="0 0 ${tam} ${tam}" width="${tam}" height="${tam}" role="img" aria-label="Gráfica de pastel">${seg}<circle cx="${c}" cy="${c}" r="${r * 0.28}" fill="var(--panel, #fff)"/></svg>
    <div class="pleyenda">${items.map((x, i) => `<div><i style="background:${COL_PASTEL[i % COL_PASTEL.length]}"></i><span>${esc(x.nombre)}</span><b>${(x.valor / tot * 100).toFixed(1)}%</b><span class="sub">${money(x.valor)}</span></div>`).join('')}<div class="tot"><span>Total generado</span><b>${money(tot)}</b></div></div></div>`;
}
const TXT_TIPO = { multa: 'Multas', mora: 'Intereses moratorios', limpieza: 'Cuotas de limpieza', mascota: 'Cuotas por mascota', otro: 'Otros cargos' };
function extrasHTML(X, titulo) {
  const P = X.promedio, k = (o) => Object.entries(o).map(([a, b]) => `<span>${a}</span><b>${b}</b>`).join('');
  const tiposHTML = Object.entries(X.tipos).filter(([, t]) => t.n || t.cobrado).map(([kk, t]) => `<span><b>${TXT_TIPO[kk]}</b> (${t.n})</span><b>${money(t.generado)}</b>${Object.entries(t.conceptos).map(([c, v]) => `<span class="sub" style="padding-left:12px">${esc(c)} (${v.n})</span><span class="sub" style="text-align:right">${money(v.total)}</span>`).join('')}<span class="sub" style="padding-left:12px">Cobrado</span><span class="sub" style="text-align:right">${money(t.cobrado)}</span>`).join('');
  return `<div class="card" style="margin:16px 0"><h2>${titulo || 'Impacto económico por unidad de negocio'}</h2>${pastelSVG(X.pastel)}<p class="sub" style="margin-bottom:0">Porcentaje de lo que generó cada unidad (rentas cobradas o por cobrar, tienda, visitas, multas, intereses y cuotas) en el periodo.</p></div>
    <div class="kpis"><div class="kpi"><span>Venta promedio diaria</span><b>${money(P.diario)}</b><div class="sub">cobrado en ${P.dias} día(s) · generado ${money(P.generado_diario)}/día</div></div>
      <div class="kpi"><span>Hospedaje por día</span><b>${money(P.hospedaje)}</b><div class="sub">tienda ${money(P.tienda)} · visitas ${money(P.visitas)} · otros ${money(P.otros)}</div></div>
      <div class="kpi"><span>Mejor día</span><b>${P.mejor ? money(P.mejor.total) : '—'}</b><div class="sub">${P.mejor ? fd(P.mejor.fecha) : ''}${P.peor && P.peor.fecha !== P.mejor?.fecha ? ` · el más bajo ${money(P.peor.total)} (${fd(P.peor.fecha)})` : ''}</div></div>
      <div class="kpi ${X.cuentas.vencido ? 'cx-vencida' : ''}"><span>Cuentas por pagar</span><b>${money(X.cuentas.pendiente + X.cuentas.vencido)}</b><div class="sub">${money(X.cuentas.vencido)} vencido · pagado en el periodo ${money(X.cuentas.pagado)}</div></div></div>
    <div class="card" style="margin-bottom:16px"><h2>Unidades de negocio</h2><div class="tw"><table><thead><tr><th>Unidad</th><th class="n">Espacios</th><th class="n">Ocupados ahora</th><th class="n">Rentas</th><th class="n">Estancias cortas</th><th class="n">Estancias largas</th><th class="n">Multas y cuotas</th><th class="n">Generado</th><th class="n">Cobrado</th><th class="n">Promedio diario</th></tr></thead><tbody>
      ${X.unidades.map((u) => `<tr><td><b>${esc(u.nombre)}</b></td><td class="n">${u.habitaciones}</td><td class="n">${u.ocupadas}</td><td class="n">${u.rentas}</td><td class="n">${money(u.cortas)}</td><td class="n">${money(u.largas)}</td><td class="n">${money(u.extras)}</td><td class="n"><b>${money(u.generado)}</b></td><td class="n">${money(u.cobrado)}</td><td class="n">${money(P.unidades.find((x) => x.nombre === u.nombre)?.diario || 0)}</td></tr>`).join('')}</tbody></table></div></div>
    <div class="cols" style="margin-bottom:16px"><div class="card"><h2>Multas, intereses y cuotas</h2>${tiposHTML ? `<div class="kv">${tiposHTML}</div>` : '<div class="empty">Sin multas ni cuotas en el periodo.</div>'}</div>
      <div class="card"><h2>Tienda por área</h2>${X.tienda_areas.length ? `<div class="kv">${X.tienda_areas.map((a) => `<span>${esc(a.area)} (${a.cantidad})</span><b>${money(a.importe)}</b><span class="sub" style="padding-left:12px">Utilidad</span><span class="sub" style="text-align:right">${money(a.utilidad)}</span>`).join('')}</div>` : '<div class="empty">Sin ventas.</div>'}</div>
      <div class="card"><h2>Visitas cobradas</h2>${X.visitas_hab.length ? `<div class="kv">${X.visitas_hab.map((v) => `<span>Hab. ${esc(v.numero)} (${v.n})</span><b>${money(v.total)}</b>`).join('')}<span><b>Total</b></span><b>${money(X.visitas_total)}</b></div>` : '<div class="empty">Sin visitas cobradas.</div>'}</div></div>
    <div class="cols" style="margin-bottom:16px"><div class="card"><h2>Descuentos de nómina (checador)</h2>${X.nomina.length ? `<div class="tw"><table><thead><tr><th>Empleado</th><th class="n">Retardos</th><th class="n">Faltas</th><th class="n">Descontado</th><th class="n">Pagado</th></tr></thead><tbody>${X.nomina.map((n) => `<tr><td>${esc(n.nombre)}</td><td class="n">${n.retardos}</td><td class="n">${n.faltas}</td><td class="n">${money(n.descuento)}</td><td class="n">${money(n.total)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">No se ha pagado nómina en el periodo.</div>'}</div>
      <div class="card"><h2>Egresos de caja</h2>${X.egresos.length ? `<div class="tw"><table><thead><tr><th>Fecha</th><th>Motivo</th><th>Lo hizo</th><th>Autorizó</th><th class="n">Monto</th></tr></thead><tbody>${X.egresos.map((m) => `<tr><td>${fdt(m.fecha)}</td><td>${esc(m.motivo || '')}</td><td>${esc(m.usuario || '')}</td><td>${esc(m.autorizo || m.usuario || '')}</td><td class="n">${m.moneda === 'USD' ? 'US$' + m.monto.toFixed(2) : money(m.monto)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">Sin egresos.</div>'}</div>
      <div class="card"><h2>Conteos de inventario (faltantes)</h2>${(X.conteos || []).length ? `<div class="kv">${X.conteos.map((c) => `<span>${fd(c.fecha)} · ${esc(c.area || 'Todo')} (${c.productos})</span><b style="color:${c.valor_faltante ? 'var(--ocup)' : 'inherit'}">−${money(c.valor_faltante)}</b>`).join('')}<span><b>Total faltante a costo</b></span><b style="color:var(--ocup)">${money(X.conteos.reduce((s, c) => s + c.valor_faltante, 0))}</b></div>` : '<div class="empty">Sin conteos en el periodo.</div>'}</div>
      <div class="card"><h2>Marketing y lavandería</h2><div class="kv">${k({ 'Publicidad y marketing': money(X.marketing), 'Servicio de lavandería': money(X.lavanderia) })}</div><div class="sub" style="margin-top:6px">Sale de los gastos clasificados como Marketing / Publicidad y Lavandería.</div></div></div>
    ${X.cuentas.lista.length ? `<div class="card" style="margin-bottom:16px"><h2>Cuentas por pagar</h2><div class="tw"><table><thead><tr><th>Proveedor</th><th>Concepto</th><th>Vence</th><th class="n">Monto</th><th class="n">Debe</th><th>Estado</th></tr></thead><tbody>${X.cuentas.lista.map((c) => `<tr class="cxr ${EST_CXP[c.estado]?.[1] || ''}"><td>${esc(c.proveedor || '—')}</td><td>${esc(c.concepto)}${c.factura ? ' · ' + esc(c.factura) : ''}</td><td>${c.vence ? fd(c.vence) : '—'}</td><td class="n">${money(c.monto)}</td><td class="n">${money(c.saldo)}</td><td><span class="pill ${EST_CXP[c.estado]?.[1] || ''}">${EST_CXP[c.estado]?.[0] || c.estado}</span></td></tr>`).join('')}</tbody></table></div></div>` : ''}
    ${X.cargos.length ? `<div class="card" style="margin-bottom:16px"><h2>Detalle de multas, intereses y cuotas</h2><div class="tw" style="max-height:340px"><table><thead><tr><th>Fecha</th><th>Hab.</th><th>Huésped</th><th>Tipo</th><th>Concepto</th><th>Usuario</th><th class="n">Importe</th></tr></thead><tbody>${X.cargos.map((c) => `<tr><td>${fdt(c.fecha)}</td><td><b>${esc(c.numero)}</b></td><td>${esc(c.huesped)}</td><td><span class="pill ct-${c.tipo}">${TIPOS_CARGO[c.tipo] || c.tipo}</span></td><td>${esc(c.descripcion)}</td><td>${esc(c.usuario || 'Automático')}</td><td class="n">${money(c.importe)}</td></tr>`).join('')}</tbody></table></div></div>` : ''}`;
}

// ---------- Reportes ----------
{
  const _vRep = vRep;
  vRep = async function () {
    await _vRep();
    try {
      const X = await GET(`/api/reporte/extra?desde=${rDesde}&hasta=${rHasta}`); vRep.x = X;
      $('#main .kpis')?.insertAdjacentHTML('afterend', `<div class="rep-extra">${extrasHTML(X)}</div>`);
    } catch { /* sin datos extra */ }
  };
}

// ---------- Cierre de mes: secciones nuevas en pantalla, PDF y Excel ----------
function cierreExtrasHTML(C) { return `<div style="margin-top:16px">${extrasHTML(C.extra, 'Impacto económico de cada unidad de negocio en el mes')}</div>`; }
function pdfExtras(C) {
  const X = C.extra, P = X.promedio, fila = (a, b, t) => `<tr${t ? ' class="t"' : ''}><td>${a}</td><td class="n">${b}</td></tr>`;
  return `<h3>Impacto económico por unidad de negocio</h3>${pastelSVG(X.pastel, 200)}
    <table><thead><tr><th>Unidad</th><th class="n">Espacios</th><th class="n">Rentas</th><th class="n">Cortas</th><th class="n">Largas</th><th class="n">Multas y cuotas</th><th class="n">Generado</th><th class="n">Cobrado</th><th class="n">Prom. diario</th></tr></thead><tbody>
    ${X.unidades.map((u) => `<tr><td>${esc(u.nombre)}</td><td class="n">${u.habitaciones}</td><td class="n">${u.rentas}</td><td class="n">${money(u.cortas)}</td><td class="n">${money(u.largas)}</td><td class="n">${money(u.extras)}</td><td class="n">${money(u.generado)}</td><td class="n">${money(u.cobrado)}</td><td class="n">${money(P.unidades.find((x) => x.nombre === u.nombre)?.diario || 0)}</td></tr>`).join('')}</tbody></table>
    <div class="rep-2"><div><h3>Venta promedio diaria</h3><table><tbody>${fila('Días del periodo', P.dias)}${fila('Promedio diario cobrado', money(P.diario), 1)}${fila('Promedio diario generado', money(P.generado_diario))}${fila('Hospedaje por día', money(P.hospedaje))}${fila('Tienda por día', money(P.tienda))}${fila('Visitas por día', money(P.visitas))}${fila('Multas y cuotas por día', money(P.otros))}${P.mejor ? fila('Mejor día ' + fd(P.mejor.fecha), money(P.mejor.total)) : ''}${P.peor ? fila('Día más bajo ' + fd(P.peor.fecha), money(P.peor.total)) : ''}</tbody></table>
      <h3>Multas, intereses y cuotas</h3><table><tbody>${Object.entries(X.tipos).filter(([, t]) => t.n || t.cobrado).map(([k, t]) => fila(`${TXT_TIPO[k]} (${t.n}) · cobrado ${money(t.cobrado)}`, money(t.generado), 1) + Object.entries(t.conceptos).map(([c, v]) => fila(`&nbsp;&nbsp;${esc(c)} (${v.n})`, money(v.total))).join('')).join('') || fila('Ninguno', '')}</tbody></table></div>
      <div><h3>Cuentas por pagar</h3><table><tbody>${fila('Se debe (a tiempo)', money(X.cuentas.pendiente))}${fila('Vencido', money(X.cuentas.vencido), 1)}${fila('Facturas nuevas del mes', money(X.cuentas.nuevas))}${fila('Pagado en el mes', money(X.cuentas.pagado))}</tbody></table>
      <h3>Tienda por área</h3><table><tbody>${X.tienda_areas.map((a) => fila(`${esc(a.area)} (${a.cantidad}) · utilidad ${money(a.utilidad)}`, money(a.importe))).join('') || fila('Sin ventas', '')}</tbody></table>
      <h3>Conteos de inventario</h3><table><tbody>${(X.conteos || []).map((c) => fila(`${fd(c.fecha)} ${esc(c.area || 'Todo')} · faltan ${c.faltantes} pzas, sobran ${c.sobrantes}`, '−' + money(c.valor_faltante))).join('') || fila('Sin conteos', '')}</tbody></table>
      <h3>Marketing y lavandería</h3><table><tbody>${fila('Publicidad y marketing', money(X.marketing))}${fila('Servicio de lavandería', money(X.lavanderia))}</tbody></table></div></div>
    ${X.cuentas.lista.length ? `<h3>Detalle de cuentas por pagar</h3><table><thead><tr><th>Proveedor</th><th>Concepto</th><th>Vence</th><th class="n">Monto</th><th class="n">Debe</th><th>Estado</th></tr></thead><tbody>${X.cuentas.lista.map((c) => `<tr><td>${esc(c.proveedor || '—')}</td><td>${esc(c.concepto)}${c.factura ? ' · ' + esc(c.factura) : ''}</td><td>${c.vence ? fd(c.vence) : '—'}</td><td class="n">${money(c.monto)}</td><td class="n">${money(c.saldo)}</td><td>${EST_CXP[c.estado]?.[0] || c.estado}</td></tr>`).join('')}</tbody></table>` : ''}
    ${X.cargos.length ? `<h3>Detalle de multas, intereses y cuotas</h3><table><thead><tr><th>Fecha</th><th>Hab.</th><th>Huésped</th><th>Tipo</th><th>Concepto</th><th class="n">Importe</th></tr></thead><tbody>${X.cargos.map((c) => `<tr><td>${fdt(c.fecha)}</td><td>${esc(c.numero)}</td><td>${esc(c.huesped)}</td><td>${TIPOS_CARGO[c.tipo] || c.tipo}</td><td>${esc(c.descripcion)}</td><td class="n">${money(c.importe)}</td></tr>`).join('')}</tbody></table>` : ''}
    ${X.nomina.length ? `<h3>Nómina: descuentos por retardos y faltas</h3><table><thead><tr><th>Empleado</th><th class="n">Pagos</th><th class="n">Retardos</th><th class="n">Faltas</th><th class="n">Desc. retardos</th><th class="n">Desc. faltas</th><th class="n">Total descontado</th><th class="n">Total pagado</th></tr></thead><tbody>${X.nomina.map((n) => `<tr><td>${esc(n.nombre)}</td><td class="n">${n.pagos}</td><td class="n">${n.retardos}</td><td class="n">${n.faltas}</td><td class="n">${money(n.desc_retardos)}</td><td class="n">${money(n.desc_faltas)}</td><td class="n">${money(n.descuento)}</td><td class="n">${money(n.total)}</td></tr>`).join('')}</tbody></table>` : ''}
    ${X.egresos.length ? `<h3>Egresos de caja y quién los autorizó</h3><table><thead><tr><th>Fecha</th><th>Motivo</th><th>Lo hizo</th><th>Autorizó</th><th class="n">Monto</th></tr></thead><tbody>${X.egresos.map((m) => `<tr><td>${fdt(m.fecha)}</td><td>${esc(m.motivo || '')}</td><td>${esc(m.usuario || '')}</td><td>${esc(m.autorizo || m.usuario || '')}</td><td class="n">${m.moneda === 'USD' ? 'US$' + m.monto.toFixed(2) : money(m.monto)}</td></tr>`).join('')}</tbody></table>` : ''}`;
}
function hojasExtras(X) {
  const P = X.promedio;
  const pas = [H_('Unidad / ingreso', 'Generado', '% del total'), ...X.pastel.map((x) => [x.nombre, M_(x.valor), Number(x.pct)]), [B_('Total'), BM_(X.total_generado), 100]];
  const uni = [H_('Unidad de negocio', 'Espacios', 'Ocupados ahora', 'Rentas', 'Estancias cortas', 'Estancias largas', 'Multas y cuotas', 'Generado', 'Cobrado', 'Promedio diario'),
    ...X.unidades.map((u) => [u.nombre, u.habitaciones, u.ocupadas, u.rentas, M_(u.cortas), M_(u.largas), M_(u.extras), BM_(u.generado), M_(u.cobrado), M_(P.unidades.find((x) => x.nombre === u.nombre)?.diario || 0)])];
  const pro = [H_('Concepto', 'Importe'), ['Días del periodo', P.dias], ['Promedio diario cobrado', BM_(P.diario)], ['Promedio diario generado', M_(P.generado_diario)], ['Hospedaje por día', M_(P.hospedaje)], ['Tienda por día', M_(P.tienda)], ['Visitas por día', M_(P.visitas)], ['Multas y cuotas por día', M_(P.otros)],
    ...(P.mejor ? [['Mejor día ' + fd(P.mejor.fecha), M_(P.mejor.total)]] : []), ...(P.peor ? [['Día más bajo ' + fd(P.peor.fecha), M_(P.peor.total)]] : [])];
  const mul = [H_('Tipo', 'Concepto', 'Cuántos', 'Generado', 'Cobrado')];
  for (const [k, t] of Object.entries(X.tipos)) { if (!t.n && !t.cobrado) continue; mul.push([B_(TXT_TIPO[k]), '', t.n, BM_(t.generado), M_(t.cobrado)]); for (const [c, v] of Object.entries(t.conceptos)) mul.push(['', c, v.n, M_(v.total), '']); }
  mul.push([], H_('Fecha', 'Hab.', 'Huésped', 'Tipo', 'Concepto', 'Usuario', 'Importe'), ...X.cargos.map((c) => [fdt(c.fecha), c.numero, c.huesped, TIPOS_CARGO[c.tipo] || c.tipo, c.descripcion, c.usuario || 'Automático', M_(c.importe)]));
  const cxp = [H_('Resumen', 'Importe'), ['Se debe (a tiempo)', M_(X.cuentas.pendiente)], ['Vencido', BM_(X.cuentas.vencido)], ['Facturas nuevas', M_(X.cuentas.nuevas)], ['Pagado en el periodo', M_(X.cuentas.pagado)], [],
    H_('Proveedor', 'Concepto', 'Factura', 'Fecha', 'Vence', 'Monto', 'Pagado', 'Debe', 'Estado'), ...X.cuentas.lista.map((c) => [c.proveedor || '', c.concepto, c.factura || '', fd(c.fecha), c.vence ? fd(c.vence) : '', M_(c.monto), M_(c.pagado), BM_(c.saldo), EST_CXP[c.estado]?.[0] || c.estado])];
  const tie = [H_('Área', 'Cantidad', 'Venta', 'Costo', 'Utilidad'), ...X.tienda_areas.map((a) => [a.area, a.cantidad, M_(a.importe), M_(a.costo), M_(a.utilidad)])];
  const nom = [H_('Empleado', 'Pagos', 'Sueldo', 'Retardos', 'Faltas', 'Desc. retardos', 'Desc. faltas', 'Total descontado', 'Total pagado'), ...X.nomina.map((n) => [n.nombre, n.pagos, M_(n.sueldo), n.retardos, n.faltas, M_(n.desc_retardos), M_(n.desc_faltas), BM_(n.descuento), M_(n.total)])];
  const egr = [H_('Fecha', 'Moneda', 'Monto', 'Motivo', 'Lo hizo', 'Autorizó'), ...X.egresos.map((m) => [fdt(m.fecha), m.moneda, m.moneda === 'USD' ? U_(m.monto) : M_(m.monto), m.motivo || '', m.usuario || '', m.autorizo || m.usuario || ''])];
  const vis = [H_('Habitación', 'Visitas cobradas', 'Total'), ...X.visitas_hab.map((v) => [v.numero, v.n, M_(v.total)]), [B_('Total'), '', BM_(X.visitas_total)], [], ['Publicidad y marketing (gastos)', '', M_(X.marketing)], ['Servicio de lavandería (gastos)', '', M_(X.lavanderia)]];
  return [{ nombre: 'Pastel unidades de negocio', filas: pas }, { nombre: 'Unidades de negocio', filas: uni }, { nombre: 'Promedio diario', filas: pro }, { nombre: 'Multas y cuotas', filas: mul }, { nombre: 'Cuentas por pagar', filas: cxp },
    { nombre: 'Tienda por área', filas: tie }, { nombre: 'Conteos de inventario', filas: [H_('Folio', 'Fecha', 'Departamento', 'Productos contados', 'Piezas faltantes', 'Piezas sobrantes', 'Faltante a costo', 'Sobrante a costo', 'Contó'), ...(X.conteos || []).map((c) => [c.folio, fdt(c.fecha), c.area || 'Todo', c.productos, c.faltantes, c.sobrantes, M_(c.valor_faltante), M_(c.valor_sobrante), c.usuario || ''])] }, { nombre: 'Descuentos de nómina', filas: nom }, { nombre: 'Egresos autorizados', filas: egr }, { nombre: 'Visitas y otros', filas: vis }];
}
// Avisos de cuentas por pagar al iniciar
setTimeout(() => { if (YO && typeof avisosGastos === 'function' && (puede('gastos') || puede('cuentas_pagar'))) avisosGastos(); }, 2500);
