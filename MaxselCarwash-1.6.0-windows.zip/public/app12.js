// Maxsel Carwash 1.0 — Punto de venta para autolavados (basado en Maxsel Hotel 1.8)
// Paquetes de lavado como venta principal, número del paquete en GRANDE en el ticket y en la pantalla
// (para que la cámara de seguridad vea qué paquete se vende y cobra), tienda con inventario, cobro en pesos,
// dólares, tarjeta, transferencia y mixto, caja con turnos, gastos, asistencia y reportes de paquetes.
'use strict';
document.title = 'Maxsel Carwash';
iTab = 'paq'; // Paquetes y productos abre en los paquetes de lavado

// ======================================================================
// Menú: fuera todo lo del hotel (habitaciones, visitantes, contratos, mantenimiento, huéspedes, cierre de mes)
// ======================================================================
for (let i = VISTAS.length - 1; i >= 0; i--) if (['hab', 'vis', 'contratos', 'mant', 'hues', 'cierre'].includes(VISTAS[i][0])) VISTAS.splice(i, 1);
{
  const _ir = ir;
  ir = async function (v) {
    if (['hab', 'vis', 'contratos', 'mant', 'hues', 'cierre'].includes(v)) v = 'tienda';
    if (v === 'tienda' && YO && !puede('vender')) v = (VISTAS.find((x) => x[0] !== 'tienda' && (!x[2] || puede(x[2]))) || ['cfg'])[0];
    await _ir(v);
    if (vista === 'rep') clearInterval(timer); // el reporte no se recarga solo (se puede buscar sin que se borre)
  };
}
// Rol de mantenimiento del hotel: aquí no se usa
{
  const _um = userModal;
  userModal = function (...a) { const r = _um(...a); document.querySelectorAll('#modal select option[value="mantenimiento"]').forEach((o) => o.remove()); return r; };
}

// ---------- Utilidades de paquetes ----------
const COLORES_PAQ = ['#2563eb', '#0d9488', '#e07a10', '#b4237a', '#7c3aed', '#c03434', '#1b845a', '#475569'];
const esPaq = (p) => !!(p && p.paquete);
const colorPaq = (p) => (p && p.color) || COLORES_PAQ[(parseInt(p?.paquete, 10) - 1 + COLORES_PAQ.length * 10) % COLORES_PAQ.length] || COLORES_PAQ[0];
const ordenPaq = (a, b) => String(a.paquete).localeCompare(String(b.paquete), 'es', { numeric: true });
const PAQS = () => PRODS.filter(esPaq).sort(ordenPaq);
const prodDe = (id) => PRODS.find((x) => x.id === id);
// Paquetes que van en el ticket actual (con su cantidad)
function paqsCarrito(items) {
  const out = [];
  for (const l of items || []) { const p = prodDe(l.producto_id); const paq = l.paquete || p?.paquete; if (paq) out.push({ paquete: paq, nombre: l.nombre, cantidad: l.cantidad, color: colorPaq(p || { paquete: paq }), incluye: p?.incluye || l.incluye || '' }); }
  return out;
}
const tiposVehiculo = () => String(CFG.cw_tipos_vehiculo || '').split(',').map((x) => x.trim()).filter(Boolean);

// ======================================================================
// Punto de venta
// ======================================================================
vTienda = async function () {
  PRODS = await GET('/api/productos');
  pintarTienda(await GET('/api/ventas'));
};
pintarTienda = function (ventas) {
  if (ventas) pintarTienda.v = ventas; ventas = pintarTienda.v || [];
  const tk = TICKETS[TK]; carrito = tk.items;
  if (SEL >= carrito.length) SEL = carrito.length - 1;
  const normales = PRODS.filter((p) => !esPaq(p));
  const AREAS = [...new Set(normales.map((p) => p.area || 'Sin área'))].sort((a, b) => a.localeCompare(b, 'es'));
  if (tArea && !AREAS.includes(tArea)) tArea = '';
  const ps = normales.filter((p) => !tArea || (p.area || 'Sin área') === tArea), tot = totalT(tk);
  const vivas = ventas.filter((v) => !v.cancelada), hoyT = vivas.reduce((s, v) => s + v.total, 0);
  const carrosHoy = vivas.reduce((s, v) => s + (v.items || []).filter((i) => i.paquete).reduce((t, i) => t + i.cantidad, 0), 0);
  const T = (k, n, f) => `<button class="pk" onclick="${f}"><kbd>${k}</kbd><span>${n}</span></button>`;
  const enTicket = paqsCarrito(carrito);
  const paqs = PAQS();
  const placas = CFG.cw_pedir_placas !== '0';
  $('#main').innerHTML = `<div class="pv cw">
    <div class="pv-top"><div class="pv-tks"><button class="on">Venta actual${carrito.length ? ` <small>${money(tot)}</small>` : ''}</button></div>
      <div class="pv-hoy">Carros de hoy <b>${carrosHoy}</b>${verVentas() ? ` · Ventas de hoy <b>${money(hoyT)}</b> · ${vivas.length} tickets` : ''}</div></div>
    <div class="cw-paqs">${paqs.map((p) => `<button class="cw-paq" style="--pc:${colorPaq(p)}" onclick="agregar(${p.id})"><span class="cw-paq-l">PAQUETE</span><span class="cw-paq-n">${esc(p.paquete)}</span><span class="cw-paq-nom">${esc(p.nombre)}</span><b class="cw-paq-p">${money(p.precio)}</b>${p.incluye ? `<small>${esc(p.incluye)}</small>` : ''}</button>`).join('')
      || `<div class="empty" style="grid-column:1/-1">Todavía no hay paquetes de lavado. ${puede('productos') ? '<button class="btn pri sm" onclick="iTab=\'paq\';ir(\'inv\')">Dar de alta los paquetes</button>' : 'Pida al administrador que los dé de alta.'}</div>`}</div>
    <div class="pv-teclas">${T('F10', 'Buscar producto', 'tBuscar()')}${T('F9', 'Verificar precio', 'tVerificar()')}${T('*', 'Cantidad', 'tCantidad()')}${T('Supr', 'Quitar artículo', 'tQuitar()')}${puede('reimprimir') ? T('F11', 'Reimprimir último', 'tReimprimir()') : ''}${verVentas() ? T('F3', 'Ventas del día', 'tVentasDia()') : ''}</div>
    <div class="pv-cuerpo">
      <div class="pv-izq">
        <div class="cw-pantalla ${enTicket.length ? '' : 'vacia'}" aria-live="polite">${enTicket.length
          ? enTicket.map((x) => `<div class="cw-pan-item" style="--pc:${x.color}"><span>PAQUETE</span><b>${esc(x.paquete)}</b>${x.cantidad > 1 ? `<em>×${x.cantidad}</em>` : ''}<small>${esc(x.nombre)}</small></div>`).join('')
          : '<div class="cw-pan-vacio">Toque el paquete de lavado que pidió el cliente</div>'}</div>
        ${placas ? `<div class="cw-veh"><label>Placas<input id="cwPl" value="${esc(tk.placas || '')}" placeholder="Opcional" autocomplete="off" maxlength="12" oninput="TICKETS[TK].placas=this.value.toUpperCase()"></label>
          <div class="cw-veh-t">${tiposVehiculo().map((t) => `<button class="chip ${tk.vehiculo === t ? 'on' : ''}" data-t="${esc(t)}" onclick="cwVehiculo(this.dataset.t)">${esc(t)}</button>`).join('')}</div></div>` : ''}
        <div class="scan">${ico('scan')}<input id="qP" placeholder="Escanee el código o escriba cantidad*código (ej. 3*7501055300075)" autocomplete="off"><span class="sub">Listo para escanear</span></div>
        <div class="pv-tabla"><table><thead><tr><th>Código</th><th>Descripción</th><th class="n">Precio</th><th class="n">Cant.</th><th class="n">Importe</th><th></th></tr></thead><tbody>
        ${carrito.map((l, i) => { const p = prodDe(l.producto_id); return `<tr class="${i === SEL ? 'sel' : ''}" onclick="SEL=${i};pintarTienda()"><td class="mono">${esPaq(p) ? `<span class="cw-mini" style="--pc:${colorPaq(p)}">P${esc(p.paquete)}</span>` : esc(l.codigo || '')}</td><td><b>${esc(l.nombre)}</b></td><td class="n">${money(l.precio)}</td>
          <td class="n"><span class="qty"><button onclick="event.stopPropagation();cant(${i},-1)" aria-label="Quitar uno">−</button><b>${l.cantidad}</b><button onclick="event.stopPropagation();cant(${i},1)" aria-label="Agregar uno">+</button></span></td><td class="n"><b>${money(l.cantidad * l.precio)}</b></td>
          <td><button class="x" onclick="event.stopPropagation();SEL=${i};tQuitar()" aria-label="Quitar">×</button></td></tr>`; }).join('') || `<tr><td colspan="6" class="pv-vacio">${ico('scan')}<div>Toque un paquete arriba, o un producto a la derecha</div></td></tr>`}</tbody></table></div>
        <div class="pv-pie"><div><span>${artT(tk)} artículo(s)</span></div><div class="pv-total"><span>Total</span><b>${money(tot)}</b></div>
          <button class="pv-cobrar" ${carrito.length ? '' : 'disabled'} onclick="cobrar()"><kbd>F12</kbd> Cobrar</button></div></div>
      <div class="pv-der"><h2 style="margin:0 0 8px">Servicios extra y productos</h2><div class="chips areas"><button class="chip ${!tArea ? 'on' : ''}" onclick="tArea='';pintarTienda()">Todo</button>${AREAS.map((a) => `<button class="chip ${tArea === a ? 'on' : ''}" data-a="${esc(a)}" onclick="tArea=this.dataset.a;pintarTienda()">${esc(a)}</button>`).join('')}</div>
        <div class="prods">${ps.map((p) => `<button class="prod ${p.servicio ? 'serv' : ''}" ${!p.servicio && p.existencia <= 0 ? 'disabled' : ''} onclick="agregar(${p.id})"><span>${esc(p.nombre)}</span><b>${money(p.precio)}</b><small>${p.servicio ? 'Servicio' : p.existencia <= 0 ? 'Agotado' : 'Quedan ' + p.existencia}</small></button>`).join('') || '<div class="empty">Sin productos. Agréguelos en Paquetes y productos.</div>'}</div></div></div></div>`;
  const qp = $('#qP');
  qp.onkeydown = (e) => {
    if (e.key === 'Enter') { e.preventDefault(); tEscaneo(qp.value); qp.value = ''; return; }
    if (!qp.value && (e.key === '+' || e.key === '-')) { e.preventDefault(); if (SEL >= 0) cant(SEL, e.key === '+' ? 1 : -1); return; }
    if (!qp.value && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) { e.preventDefault(); if (carrito.length) { SEL = Math.max(0, Math.min(carrito.length - 1, SEL + (e.key === 'ArrowUp' ? -1 : 1))); pintarTienda(); } }
  };
  const a = document.activeElement; if (!a || a === document.body || a.tagName === 'BUTTON') qp.focus();
};
function cwVehiculo(t) { const tk = TICKETS[TK]; tk.vehiculo = tk.vehiculo === t ? '' : t; pintarTienda(); }
// Los paquetes se pueden marcar con su número: escribir "P2" o "2" + Enter en el escáner agrega el paquete 2
{
  const _esc = tEscaneo;
  tEscaneo = function (t) {
    const s = String(t || '').trim().toUpperCase(), m = s.match(/^(?:P|PAQ|PAQUETE)?\s*([0-9A-Z]{1,4})$/);
    if (m && !PRODS.some((x) => x.codigo && x.codigo.toUpperCase() === s)) { const p = PRODS.find((x) => esPaq(x) && String(x.paquete).toUpperCase() === m[1]); if (p && (/^P/.test(s) || /^\d{1,2}$/.test(s))) return agregar(p.id); }
    return _esc(t);
  };
}

// ---------- Cobrar ----------
cobrar = async function () {
  if (!carrito.length) return toast('El ticket está vacío', true);
  const tk = TICKETS[TK], tot = totalT(tk), paqs = paqsCarrito(carrito);
  if (CFG.cw_pedir_placas !== '0') tk.placas = (val('cwPl') || tk.placas || '').toUpperCase();
  const det = [tk.vehiculo, tk.placas ? 'Placas ' + tk.placas : ''].filter(Boolean).join(' · ');
  const pr = ventanaCobro({ total: tot, titulo: paqs.length ? 'Cobrar ' + paqs.map((x) => 'Paquete ' + x.paquete).join(' + ') : 'Cobrar venta', detalle: det, articulos: artT(tk), habitaciones: [] });
  if (paqs.length) $('#cobro .vc-main')?.insertAdjacentHTML('afterbegin', `<div class="cw-vc">${paqs.map((x) => `<div style="--pc:${x.color}"><span>PAQUETE</span><b>${esc(x.paquete)}</b></div>`).join('')}</div>`);
  const r = await pr;
  if (!r) { $('#qP')?.focus(); return; }
  const v = await hacer(() => POST('/api/ventas', { items: carrito.map(({ producto_id, cantidad }) => ({ producto_id, cantidad })), metodo: 'mixto', partes: r.partes, nota: r.nota, placas: tk.placas || '', vehiculo: tk.vehiculo || '' }), 'Venta cobrada');
  ULTIMA = { v, nota: r.nota };
  tkCerrar(); await vTienda(); pintarTurno();
  if (CFG.cw_aviso_pantalla !== '0' && paqs.length) avisoPaquete(paqs, v);
  else if (v.cambio > 0) toast('Cambio: ' + money(v.cambio));
  if (r.imprimir) imprimirTicketCW(v, r.nota);
};
tReimprimir = function () {
  if (!puede('reimprimir')) return toast('Su usuario no tiene permiso para reimprimir tickets', true);
  if (!ULTIMA) return toast('Aún no hay ventas en esta sesión', true); imprimirTicketCW(ULTIMA.v, ULTIMA.nota, true);
};
// Ventas del día: muestra el paquete y las placas
{
  const _vd = tVentasDia;
  tVentasDia = function () {
    _vd();
    const v = pintarTienda.v || [];
    document.querySelectorAll('#modal tbody tr').forEach((tr, i) => {
      const x = v[i]; if (!x) return; const td = tr.children[2]; if (!td) return;
      const pq = (x.items || []).filter((it) => it.paquete).map((it) => `<span class="cw-mini" style="--pc:${colorPaq(PRODS.find((p) => p.paquete === it.paquete) || { paquete: it.paquete })}">P${esc(it.paquete)}</span>`).join(' ');
      if (pq || x.placas) td.insertAdjacentHTML('afterbegin', `<div>${pq} ${x.placas ? `<b class="mono">${esc(x.placas)}</b>` : ''}</div>`);
      const b = tr.querySelector('td:last-child'); if (b && puede('reimprimir')) b.insertAdjacentHTML('afterbegin', `<button class="btn sm" onclick="cwReimprimir(${i})">Ticket</button> `);
    });
  };
}
function cwReimprimir(i) { if (!puede('reimprimir')) return; const x = (pintarTienda.v || [])[i]; if (!x) return; cerrar(); GET('/api/ventas?desde=' + x.fecha.slice(0, 10)).then((l) => { const v = l.find((y) => y.id === x.id); if (v) imprimirTicketCW({ ...v, items: v.items }, v.nota, true); }); }

// Aviso en pantalla completa con el número del paquete (para la cámara)
function avisoPaquete(paqs, v) {
  let el = $('#cwAviso'); if (!el) { el = document.createElement('div'); el.id = 'cwAviso'; document.body.appendChild(el); }
  const cambio = v.cambio > 0 ? `<div class="cw-av-cambio">Cambio: <b>${money(v.cambio)}</b></div>` : '';
  el.innerHTML = `<div class="cw-av" onclick="cwAvisoCerrar()" role="alert"><div class="cw-av-top">COBRADO · Folio ${esc(v.folio)}${v.placas ? ' · ' + esc(v.placas) : ''}</div>
    <div class="cw-av-paqs">${paqs.map((x) => `<div class="cw-av-p" style="--pc:${x.color}"><span>PAQUETE</span><b>${esc(x.paquete)}</b>${x.cantidad > 1 ? `<em>×${x.cantidad}</em>` : ''}<small>${esc(x.nombre)}</small></div>`).join('')}</div>
    <div class="cw-av-tot">${money(v.total)}</div>${cambio}<div class="cw-av-pie">Toque para cerrar</div></div>`;
  el.hidden = false; clearTimeout(avisoPaquete.t);
  avisoPaquete.t = setTimeout(cwAvisoCerrar, (Number(CFG.cw_aviso_segundos) || 6) * 1000);
}
function cwAvisoCerrar() { const el = $('#cwAviso'); if (el) el.hidden = true; clearTimeout(avisoPaquete.t); $('#qP')?.focus(); }
document.addEventListener('keydown', (e) => { const el = $('#cwAviso'); if (el && !el.hidden && (e.key === 'Escape' || e.key === 'Enter')) { e.preventDefault(); cwAvisoCerrar(); } }, true);

// ======================================================================
// Ticket con el número del paquete GIGANTE (solo arriba, al principio del ticket)
// ======================================================================
// El número se imprime como imagen del ancho del papel: sale más grande que la letra más grande de la impresora.
const PAQ_IMG = new Map();
// 1.5.1: versión compacta para el ticket del cliente: solo el número, recortado a su ancho (imprime rápido y sin rayas)
const PAQ_CHICO = new Map();
function paqChicoOps(paq) {
  const alto = CFG.ticket_ancho === '58' ? 150 : 190, key = alto + '|' + PTS() + '|' + paq;
  if (PAQ_CHICO.has(key)) return PAQ_CHICO.get(key);
  const num = String(paq).toUpperCase(), c = document.createElement('canvas'), x = c.getContext('2d');
  const fuente = (f) => `900 ${f}px "Arial Black", Arial, sans-serif`;
  let f = alto * 1.4, m;
  for (let i = 0; i < 30; i++) { x.font = fuente(f); m = x.measureText(num); const hh = m.actualBoundingBoxAscent + m.actualBoundingBoxDescent; if (Math.abs(alto / hh - 1) < 0.01) break; f *= alto / hh; }
  x.font = fuente(f); m = x.measureText(num);
  const anchoTxt = Math.ceil(m.actualBoundingBoxLeft + m.actualBoundingBoxRight), ancho = Math.min(PTS(), Math.ceil((anchoTxt + 16) / 8) * 8), h = alto + 6;
  c.width = ancho; c.height = h;
  x.fillStyle = '#fff'; x.fillRect(0, 0, ancho, h); x.fillStyle = '#000'; x.font = fuente(f); x.textBaseline = 'alphabetic';
  x.fillText(num, (ancho - anchoTxt) / 2 + m.actualBoundingBoxLeft, 3 + m.actualBoundingBoxAscent);
  const px = x.getImageData(0, 0, ancho, h).data, bpr = ancho / 8, bits = new Uint8Array(bpr * h);
  for (let yy = 0; yy < h; yy++) for (let i = 0; i < ancho; i++) { const k = (yy * ancho + i) * 4; if (px[k] < 128) bits[yy * bpr + (i >> 3)] |= 0x80 >> (i & 7); }
  let bin = ''; bits.forEach((b) => (bin += String.fromCharCode(b)));
  const ops = [['align', 'center'], ['img', bpr, h, btoa(bin)], ['align', 'left']];
  PAQ_CHICO.set(key, ops); return ops;
}
async function paqImgOps(paq, cantidad) {
  const ancho = PTS(), key = ancho + '|' + paq + '|' + (cantidad || 1);
  if (PAQ_IMG.has(key)) return PAQ_IMG.get(key);
  const titulo = 'PAQUETE', num = String(paq).toUpperCase(), extra = cantidad > 1 ? `× ${cantidad} CARROS` : '';
  const MAXH = 400, c = document.createElement('canvas'); c.width = ancho; c.height = MAXH;   // la impresora acepta hasta 400 puntos de alto por imagen
  const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, ancho, MAXH); x.fillStyle = '#000'; x.textAlign = 'center'; x.textBaseline = 'alphabetic';
  const fuente = (f) => `900 ${f}px "Arial Black", Arial, sans-serif`;
  // Tamaño de letra para que el texto mida exactamente "alto" puntos (sin espacio de sobra) sin pasarse del ancho
  const medir = (txt, alto) => {
    let f = alto * 1.5, m;
    for (let i = 0; i < 40; i++) { x.font = fuente(f); m = x.measureText(txt); const hh = m.actualBoundingBoxAscent + m.actualBoundingBoxDescent, ww = m.actualBoundingBoxLeft + m.actualBoundingBoxRight; const k = Math.min(alto / hh, (ancho - 16) / ww); if (Math.abs(k - 1) < 0.01) break; f *= k; }
    x.font = fuente(f); m = x.measureText(txt); return { f, a: m.actualBoundingBoxAscent, d: m.actualBoundingBoxDescent };
  };
  const hT = Math.round(ancho * 0.075), hX = extra ? Math.round(ancho * 0.06) : 0, gap = 16;
  const hN = Math.min(290, MAXH - hT - (extra ? hX + gap : 0) - gap - 8); // número de unos 3.6 cm de alto en papel de 80 mm
  let y = 2;
  let m = medir(titulo, hT); x.fillText(titulo, ancho / 2, y + m.a); y += hT + gap;
  m = medir(num, hN); x.fillText(num, ancho / 2, y + m.a); y += hN + gap;
  if (extra) { m = medir(extra, hX); x.fillText(extra, ancho / 2, y + m.a); y += hX + 4; }
  const h = Math.min(MAXH, Math.ceil(y + 4));
  const px = x.getImageData(0, 0, ancho, h).data, bpr = ancho / 8, bits = new Uint8Array(bpr * h);
  for (let yy = 0; yy < h; yy++) for (let i = 0; i < ancho; i++) { const k = (yy * ancho + i) * 4; if (px[k] < 128) bits[yy * bpr + (i >> 3)] |= 0x80 >> (i & 7); }
  let bin = ''; bits.forEach((b) => (bin += String.fromCharCode(b)));
  const ops = [['align', 'center'], ['img', bpr, h, btoa(bin)], ['align', 'left']];
  PAQ_IMG.set(key, ops); return ops;
}
// "2026-10-16 15:40:00" -> "3:40 pm"
const hora12 = (f) => { const [h, m] = String(f).slice(11, 16).split(':').map(Number); return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h < 12 ? 'am' : 'pm'}`; };
const bloquePaqHTML = (x, conNombre = true) => `<div class="cw-tk-paq"><div class="cw-tk-l">PAQUETE</div><div class="cw-tk-n">${esc(x.paquete)}</div>${x.cantidad > 1 ? `<div class="cw-tk-l">× ${x.cantidad} CARROS</div>` : ''}${conNombre ? `<div class="cw-tk-nom">${esc(x.nombre)}</div>${x.incluye ? `<div class="cw-tk-inc">${esc(x.incluye)}</div>` : ''}` : ''}</div>`;
const nombrePaqOps = (x) => [['align', 'center'], ['bold', true], ['big', true], ...wrapT(x.nombre.toUpperCase(), Math.floor(W() / 2)).map((l) => ['text', l]), ['big', false], ['bold', false], ...(x.incluye ? wrapT(x.incluye).map((l) => ['text', l]) : []), ['align', 'left']];
function imprimirTicketCW(v, nota, reimpresion) {
  const w = W(), raya = '-'.repeat(w);
  const paqs = (v.items || []).filter((i) => i.paquete).map((i) => ({ paquete: i.paquete, nombre: i.descripcion, cantidad: i.cantidad, incluye: i.incluye || prodDe(i.producto_id)?.incluye || '' }));
  const usd = Number(v.pago?.usd) || 0, tc = Number(v.pago?.tc) || 0;
  const datos = [lin('Folio', v.folio), lin('Fecha', fdt(v.fecha)), ...(v.vehiculo ? [lin('Vehículo', v.vehiculo)] : []), ...(v.placas ? [lin('Placas', v.placas)] : []), lin('Atendió', v.usuario || YO.nombre), ...(v.lavador ? [lin('Lavador', v.lavador)] : []), ...(v.listo ? [lin('Listo aprox.', hora12(v.listo))] : [])];
  const items = (v.items || []).map((i) => lin((i.paquete ? '[P' + i.paquete + '] ' : '') + i.cantidad + ' ' + i.descripcion, money(i.importe)));
  const pago = usd ? [lin('Pagó con', `US$${usd.toFixed(2)}`), lin(`  US$${usd.toFixed(2)} x $${tc.toFixed(2)}`, money(usd * tc)), ...(v.recibido - usd * tc > 0.004 ? [lin('  y en pesos', money(v.recibido - usd * tc))] : []), lin('Total en dólares', 'US$' + (Math.ceil(v.total / (tc || 1) * 100) / 100).toFixed(2)), lin('Cambio', money(v.cambio || 0))]
    : lineasPago({ total: v.recibido, cambio: v.cambio });
  const pie = [...(nota ? wrapT('Nota: ' + nota) : []), ...(reimpresion ? ['', '*** REIMPRESIÓN ***'] : []), '', ...(CFG.ticket_pie ? wrapT(CFG.ticket_pie) : [])];
  const copia = CFG.cw_copia_lavador !== '0' && paqs.length;
  const ops = async () => {
    const o = [];
    // 1) Lo primero del ticket: PAQUETE y el número gigante
    // 1.5.1: ticket del cliente compacto: PAQUETE, el número grande (imagen chica y rápida) y el nombre en una línea
    for (const x of paqs) o.push(['align', 'center'], ['bold', true], ['text', 'PAQUETE' + (x.cantidad > 1 ? ` (x${x.cantidad} carros)` : '')], ['bold', false], ...paqChicoOps(x.paquete), ['align', 'center'], ['bold', true], ...wrapT(x.nombre.toUpperCase()).map((l) => ['text', l]), ['bold', false], ['align', 'left']);
    if (paqs.length) o.push(['align', 'center'], ['text', raya], ['bold', true], ['text', 'TICKET DEL CLIENTE'], ['bold', false], ...wrapT('Preséntelo para recoger su vehículo').map((l) => ['text', l]), ['align', 'left']);
    o.push(...(await logoOps()), ...encOps(), ...datos.map((l) => ['text', l]), ['text', raya], ...items.map((l) => ['text', l]), ['text', raya], ['align', 'right'], ['bold', true], ['big', true], ['text', 'TOTAL ' + money(v.total)], ['big', false], ['bold', false], ['align', 'left'],
      ...pago.map((l) => ['text', l]), ...pie.map((l) => ['text', l]), ...(await leyendaOps()));
    if (copia) {
      o.push(['cut'], ['align', 'center'], ['bold', true], ['big', true], ['text', 'PARABRISAS'], ['big', false], ['text', 'Póngalo en el parabrisas'], ['text', 'o entréguelo al secador'], ['bold', false], ['text', raya]);
      for (const x of paqs) o.push(...(await paqImgOps(x.paquete, x.cantidad)), ...nombrePaqOps(x));
      o.push(['align', 'center'], ['text', raya], ['bold', true], ...(v.placas ? [['big', true], ['text', v.placas], ['big', false]] : []), ...(v.vehiculo ? [['text', v.vehiculo]] : []), ['bold', false], ...(v.lavador ? [['bold', true], ['text', 'Lavador: ' + v.lavador], ['bold', false]] : []), ...(v.listo ? [['text', 'Listo aprox. ' + hora12(v.listo)]] : []), ['text', 'Folio ' + v.folio + ' · ' + fdt(v.fecha)], ...wrapT('NO es comprobante para recoger el carro').map((l) => ['text', l]), ['align', 'left']);
    }
    return o;
  };
  ops.leyendaPropia = true;
  const enc = encabezado().filter((l) => !/^-+$/.test(l));
  const html = `<div class="cw-tk">${paqs.map((x) => bloquePaqHTML(x)).join('')}${paqs.length ? '<div class="cw-tk-l" style="margin-top:4px">TICKET DEL CLIENTE</div><div class="cw-c" style="font-size:12px">Preséntelo para recoger su vehículo</div>' : ''}${CFG.ticket_logo ? `<div class="tk-logo"><img src="${CFG.ticket_logo}" alt="" style="width:${Math.round((ANCHO_LOGO[CFG.ticket_logo_ancho] || 0.7) * 66)}%"></div>` : ''}<pre class="tk cw-c">${esc(enc.join('\n'))}</pre>
    <pre class="tk">${esc([raya, ...datos, raya, ...items, raya].join('\n'))}</pre><div class="cw-tk-tot">TOTAL ${esc(money(v.total))}</div>
    <pre class="tk">${esc([...pago, ...pie].join('\n'))}</pre>${leyendaHTML()}
    ${copia ? `<div class="cw-tk-corte">✂ - - - - - - - - - - - - - - -</div><div class="cw-tk-l" style="font-size:20px">PARABRISAS</div><div class="cw-c" style="font-size:12px">Póngalo en el parabrisas o entréguelo al secador</div>${paqs.map((x) => bloquePaqHTML(x)).join('')}${v.placas ? `<div class="cw-tk-pl">${esc(v.placas)}</div>` : ''}<pre class="tk cw-c">${esc((v.vehiculo ? v.vehiculo + '\n' : '') + (v.lavador ? 'Lavador: ' + v.lavador + '\n' : '') + (v.listo ? 'Listo aprox. ' + hora12(v.listo) + '\n' : '') + 'Folio ' + v.folio + ' · ' + fdt(v.fecha) + '\nNO es comprobante para recoger el carro')}</pre>` : ''}</div>`;
  imprimirDoc(html, ancho(), reimpresion ? 'Reimprimir ticket' : 'Ticket', ops);
}

// ======================================================================
// Paquetes y productos (inventario)
// ======================================================================
vInv = async function () {
  const [ps, ar] = await Promise.all([GET('/api/productos'), GET('/api/tienda/areas')]); PRODS = ps; AREAS_T = ar.areas;
  const valor = ps.filter((p) => !p.servicio).reduce((s, p) => s + p.existencia * p.costo, 0);
  const T = [['paq', 'Paquetes de lavado'], ['prod', 'Productos y servicios'], ['areas', 'Departamentos'], ...(puede('inventario') ? [['conteo', 'Conteo físico']] : []), ['mov', 'Movimientos']];
  if (!T.some((t) => t[0] === iTab)) iTab = 'paq';
  const acc = iTab === 'paq' ? (puede('productos') ? '<button class="btn pri" onclick="paqModal()">Nuevo paquete</button>' : '')
    : iTab === 'prod' ? `<button class="btn" onclick="exportarProductos()">Exportar a Excel</button>${puede('productos') ? '<button class="btn" onclick="importarProductos()">Importar de Excel</button>' : ''}${puede('inventario') ? '<button class="btn op" onclick="entradaModal()">Entrada de mercancía</button>' : ''}${puede('productos') ? '<button class="btn pri" onclick="prodModal()">Nuevo producto</button>' : ''}`
    : iTab === 'areas' && puede('productos') ? '<button class="btn pri" onclick="areaModal()">Nuevo departamento</button>' : '';
  $('#main').innerHTML = cab('Paquetes y productos', `${PAQS().length} paquetes · ${ps.filter((p) => !esPaq(p)).length} productos y servicios · inventario a costo ${money(valor)}`, acc)
    + `<div class="tabs" style="margin-bottom:14px">${T.map(([k, n]) => `<button class="${iTab === k ? 'on' : ''}" onclick="iTab='${k}';vInv()">${n}</button>`).join('')}</div><div id="invc"></div>`;
  await ({ paq: invPaquetes, prod: invProductos, areas: invAreas, conteo: invConteo, mov: invMov })[iTab]();
};
async function invPaquetes() {
  const L = PAQS(), r = await GET(`/api/reporte/paquetes?desde=${hoyISO()}&hasta=${hoyISO()}`).catch(() => null), hoyN = Object.fromEntries((r?.porPaquete || []).map((x) => [x.paquete, x.n]));
  $('#invc').innerHTML = `<div class="aviso" style="margin-bottom:12px">El <b>número del paquete</b> sale en <b>GRANDE</b> en el ticket y en la pantalla al cobrar, para que la cámara de seguridad vea qué paquete se vendió. Los paquetes son servicios: no llevan inventario.</div>
    <div class="cw-paqs cw-paqs-adm">${L.map((p) => `<div class="cw-paq" style="--pc:${colorPaq(p)}"><span class="cw-paq-l">PAQUETE</span><span class="cw-paq-n">${esc(p.paquete)}</span><span class="cw-paq-nom">${esc(p.nombre)}</span><b class="cw-paq-p">${money(p.precio)}</b>${p.incluye ? `<small>${esc(p.incluye)}</small>` : ''}
      <small class="cw-paq-hoy">Hoy: ${hoyN[p.paquete] || 0} vendido(s)</small>${puede('productos') ? `<div class="row" style="justify-content:center;margin-top:6px"><button class="btn sm" onclick="paqModal(${p.id})">Editar</button><button class="btn sm bad" onclick="confirmar(this,()=>prodBorrar(${p.id}))">Eliminar</button></div>` : ''}</div>`).join('')
      || '<div class="empty" style="grid-column:1/-1">Todavía no hay paquetes. Toque "Nuevo paquete" para crear el Paquete 1, 2, 3…</div>'}</div>`;
}
function siguientePaq() { const n = PAQS().map((p) => parseInt(p.paquete, 10)).filter((x) => x > 0); return String(n.length ? Math.max(...n) + 1 : 1); }
function paqModal(id) {
  const p = id ? prodDe(id) : { paquete: siguientePaq(), nombre: '', precio: '', costo: 0, incluye: '', color: '', codigo: '', minutos: '', com_tipo: '', com_valor: '' };
  const col = p.color || colorPaq({ paquete: p.paquete });
  modal(id ? 'Editar paquete ' + esc(p.paquete) : 'Nuevo paquete de lavado', `<div class="f">
    <label class="l">Número del paquete (sale en GRANDE)<input id="qN" value="${esc(p.paquete)}" maxlength="4" style="font-size:28px;font-weight:800;text-align:center" oninput="$('#qPrev b').textContent=this.value.toUpperCase()||'?'"></label>
    <label class="l">Nombre<input id="qNo" value="${esc(p.nombre)}" placeholder="Ej. Lavado exterior e interior"></label>
    <label class="l">Precio<input id="qP" type="number" min="0" step="0.01" value="${p.precio}"></label>
    <label class="l">Costo aproximado (jabón, cera, comisión…)<input id="qC" type="number" min="0" step="0.01" value="${p.costo || 0}"></label>
    <label class="l" style="grid-column:1/-1">¿Qué incluye? (se imprime en el ticket)<textarea id="qI" rows="2" maxlength="300" placeholder="Ej. Lavado exterior, aspirado, tablero y llantas negras">${esc(p.incluye || '')}</textarea></label>
    <label class="l">Color del botón<input id="qCo" type="color" value="${esc(col)}" oninput="$('#qPrev').style.setProperty('--pc',this.value)"></label>
    <label class="l">Código (opcional, para escanear)<input id="qCd" value="${esc(p.codigo || '')}" placeholder="PAQ-1"></label>
    <label class="l">Tiempo de lavado (minutos)<input id="qMi" type="number" min="0" step="1" value="${p.minutos || ''}" placeholder="${esc(CFG.cw_minutos_lavado || '30')}"></label>
    <label class="l">Comisión para el lavador<span class="row" style="gap:6px"><select id="qCt" style="flex:1"><option value="">Sin comisión</option><option value="monto" ${p.com_tipo === 'monto' ? 'selected' : ''}>Pesos por carro</option><option value="porc" ${p.com_tipo === 'porc' ? 'selected' : ''}>% del precio</option></select><input id="qCv" type="number" min="0" step="0.01" value="${p.com_valor || ''}" placeholder="0" style="width:90px"></span></label></div>
    ${CFG.cw_comisiones !== '1' ? '<p class="sub" style="margin:6px 0 0">Las comisiones están apagadas. Se encienden en <b>Lavadores → Configurar</b>.</p>' : ''}
    <div class="cw-paqs" style="margin-top:12px;grid-template-columns:minmax(0,220px)"><div class="cw-paq" id="qPrev" style="--pc:${esc(col)}"><span class="cw-paq-l">PAQUETE</span><b class="cw-paq-n">${esc(p.paquete || '?')}</b><span class="cw-paq-nom">Así se ve el botón</span></div></div>`,
  `${id ? `<button class="btn bad" onclick="confirmar(this,()=>prodBorrar(${id}))">Eliminar</button>` : ''}<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="paqOk(${id || 0})">Guardar</button>`);
  $(id ? '#qNo' : '#qNo').focus();
}
async function paqOk(id) {
  const n = val('qN').toUpperCase(); if (!n) return toast('Escriba el número del paquete', true);
  const b = { paquete: n, nombre: val('qNo'), precio: val('qP'), costo: val('qC'), incluye: $('#qI').value.trim(), color: val('qCo'), codigo: val('qCd') || 'PAQ-' + n, area: 'Paquetes de lavado', servicio: true, existencia: 0, minimo: 0,
    minutos: val('qMi'), com_tipo: val('qCt'), com_valor: val('qCv') };
  await hacer(() => (id ? PUT('/api/productos/' + id, b) : POST('/api/productos', b)), 'Paquete guardado'); cerrar(); iTab = 'paq'; vInv();
}
// Al editar un paquete desde la lista general se abre la ventana de paquete
{
  const _pm = prodModal;
  prodModal = function (id) { if (id && esPaq(prodDe(id))) return paqModal(id); return _pm(id); };
  // Guardar producto conservando los campos del paquete (el original no los manda)
  prodOk = async function (id) {
    const s = $('#pArS'); if (s) $('#pAr').value = s.value === '__nuevo' ? val('pArN') : s.value;
    if (s?.value === '__nuevo' && val('pArN')) await POST('/api/tienda/areas', { nombre: val('pArN') }).catch(() => {});
    const b = { codigo: val('pC'), nombre: val('pN'), area: val('pAr'), servicio: $('#pSv').checked, costo: val('pCo'), precio: val('pP'), existencia: val('pE'), minimo: val('pM') };
    await hacer(() => (id ? PUT('/api/productos/' + id, b) : POST('/api/productos', b)), 'Producto guardado'); cerrar(); vInv();
  };
  // Texto de la casilla de servicio
  const _pm2 = prodModal;
  prodModal = function (id) { const r = _pm2(id); const l = $('#pSv')?.closest('label'); if (l) l.lastChild.textContent = ' Es un servicio extra (no lleva inventario: aspirado de cajuela, lavado de motor, encerado…)'; return r; };
}
// La lista de productos no muestra los paquetes (tienen su pestaña)
{
  const _ip = invProductos;
  invProductos = function () { const todos = PRODS; PRODS = todos.filter((p) => !esPaq(p)); try { return _ip(); } finally { PRODS = todos; } };
}

// (Los reportes del autolavado están en app13.js)
// ======================================================================
// Caja: paquetes del turno en pantalla y en el corte
// ======================================================================
{
  const _vc = vCaja;
  vCaja = async function () {
    await _vc();
    const m = $('#main'); if (!m) return;
    m.querySelectorAll('button[onclick^="excelCorte("],button[onclick^="pdfCorte("]').forEach((b) => b.remove());
    if (!puede('tipo_cambio')) m.querySelectorAll('button[onclick^="tcModal("]').forEach((b) => b.remove());
    // si las tarjetas del hotel ocupaban el lugar de "Cobros por concepto", la de ventas del turno va primero
    if (!m.querySelector('#main .card h2') || ![...m.querySelectorAll('.card h2')].some((h) => h.textContent.trim() === 'Cobros por concepto')) {
      const fp = [...m.querySelectorAll('.card h2')].find((h) => h.textContent.trim() === 'Por forma de pago')?.closest('.card');
      fp?.insertAdjacentHTML('beforebegin', '<div class="card" id="cwConc"><h2>Ventas del turno</h2></div>');
    }
    m.querySelectorAll('.card h2').forEach((h) => {
      const t = h.textContent.trim(), card = h.closest('.card');
      if (t === 'Depósitos y gastos') card.innerHTML = `<h2>Gastos</h2><div class="kv"><span>Gastos pagados de caja</span><b>${money(TURNO?.gastos?.efectivo)}</b></div>`;
      if (t === 'Cobros por concepto') card.id = 'cwConc';
      if (['Estancias cortas', 'Estancias largas', 'Depósitos y dólares', 'Depósitos'].includes(t)) card.remove();
    });
    m.querySelectorAll('.card p.sub').forEach((p) => { if (/hospedaje/i.test(p.textContent)) p.textContent = 'Para cobrar paquetes de lavado, servicios y productos primero abra su turno: le pedirá el fondo de caja y el tipo de cambio del dólar.'; });
    const c = $('#cwConc');
    if (c && TURNO?.turno) {
      const k = await GET(`/api/turnos/${TURNO.turno.id}/paquetes`).catch(() => null); if (!k) return;
      c.innerHTML = `<h2>Ventas del turno</h2><div class="kv">${k.porPaquete.map((x) => `<span><span class="cw-mini" style="--pc:${colorPaq(PRODS.find((p) => p.paquete === x.paquete) || { paquete: x.paquete })}">P${esc(x.paquete)}</span> ${esc(x.nombre)} (${x.n})</span><b>${money(x.total)}</b>`).join('')}
        <span><b>Carros lavados (${k.carros})</b></span><b>${money(k.totalPaquetes)}</b><span>Servicios extra</span><b>${money(k.serviciosExtra)}</b><span>Productos</span><b>${money(k.productos)}</b></div>`;
    }
  };
}
// Corte de turno (ticket 80 mm) con los paquetes vendidos
imprimirCorte2 = async function (r, titulo) {
  let k = null; try { k = await GET(`/api/turnos/${r.turno.id}/paquetes`); } catch { /* sin detalle */ }
  const antes = CFG.ticket_ancho; CFG.ticket_ancho = '80';
  try {
    const t = r.turno, p = r.pagos, w = W(), us = (x) => 'US$' + Number(x || 0).toFixed(2), raya = '-'.repeat(w), doble = '='.repeat(w), kk = r.cuentas;
    const L = [...encabezado(), titulo, raya, lin('Turno ' + t.id, t.usuario || YO.nombre), lin('Abrió', fdt(t.apertura)), ...(t.cierre ? [lin('Cerró', fdt(t.cierre))] : []), lin('Dólar', '$' + Number(t.tipo_cambio).toFixed(2)), doble];
    if (k) {
      L.push('PAQUETES VENDIDOS', ...k.porPaquete.map((x) => lin(`Paquete ${x.paquete} (${x.n})`, money(x.total))), lin(`CARROS LAVADOS (${k.carros})`, money(k.totalPaquetes)), raya, lin('Servicios extra', money(k.serviciosExtra)), lin('Productos', money(k.productos)));
    }
    L.push(doble, lin('TOTAL COBRADO', money(r.cobrado)), raya, 'FORMAS DE PAGO', lin('Efectivo', money(p.efectivo)));
    if (kk && kk.dolares?.usd) L.push(lin(`${us(kk.dolares.usd)} x $${Number(kk.dolares.tc).toFixed(2)}`, money(kk.dolares.pesos)), lin('  Cambio dado en pesos', '-' + money(kk.dolares.cambio)));
    else if (p.usd) L.push(lin('Dólares ' + us(p.usd), money(p.dolares)));
    if (p.tarjeta) L.push(lin('Tarjeta', money(p.tarjeta)));
    if (p.transferencia) L.push(lin('Transferencia', money(p.transferencia)));
    L.push(raya, 'CAJA', lin('Fondo inicial', money(t.fondo_mxn) + (t.fondo_usd ? ' + ' + us(t.fondo_usd) : '')));
    if (r.gastos?.efectivo) L.push(lin('Gastos pagados', '-' + money(r.gastos.efectivo)));
    if (r.movimientos?.ing_mxn || r.movimientos?.ing_usd) L.push(lin('Ingresos a caja', money(r.movimientos.ing_mxn) + (r.movimientos.ing_usd ? ' ' + us(r.movimientos.ing_usd) : '')));
    if (r.movimientos?.ret_mxn || r.movimientos?.ret_usd) L.push(lin('Egresos de caja', '-' + money(r.movimientos.ret_mxn) + (r.movimientos.ret_usd ? ' ' + us(r.movimientos.ret_usd) : '')));
    if (r.esperado) L.push(lin('DEBE HABER pesos', money(r.esperado.mxn)), lin('DEBE HABER dólares', us(r.esperado.usd)));
    if (t.estado === 'cerrado') {
      L.push(lin('Contado pesos', money(t.decl_mxn)), lin('Contado dólares', us(t.decl_usd)));
      if (r.dif) L.push(lin('DIFERENCIA pesos', money(r.dif.mxn)), lin('DIFERENCIA dólares', us(r.dif.usd)), '(sobra + / falta -)');
      if (t.notas) L.push(...wrapT('Notas: ' + t.notas));
    }
    L.push('', '', '_'.repeat(30), 'Firma cajero', '', '', '_'.repeat(30), 'Firma supervisor', '', 'Impreso ' + new Date().toLocaleString('es-MX'));
    imprimir(L, titulo.toLowerCase().replace(/^\w/, (x) => x.toUpperCase()));
  } finally { CFG.ticket_ancho = antes; }
};

// ======================================================================
// Configuración
// ======================================================================
cHotel = function () {
  $('#cfgc').innerHTML = `<div class="stack"><div class="card"><h2>Datos del autolavado</h2><div class="f"><label class="l">Nombre<input id="gN" value="${esc(CFG.hotel_nombre)}"></label><label class="l">Dirección<input id="gD" value="${esc(CFG.hotel_direccion)}"></label>
    <label class="l">Teléfono<input id="gT" value="${esc(CFG.hotel_telefono)}"></label>
    <label class="l">Pie del ticket<input id="gP" value="${esc(CFG.ticket_pie)}"></label><label class="l">Ancho del ticket<select id="gA"><option value="58" ${CFG.ticket_ancho !== '80' ? 'selected' : ''}>58 mm</option><option value="80" ${CFG.ticket_ancho === '80' ? 'selected' : ''}>80 mm</option></select></label></div></div>
    <div class="card"><h2>Seguridad de caja</h2><label class="row" style="font-weight:600"><input type="checkbox" id="gAe" ${CFG.autoriza_egresos !== '0' ? 'checked' : ''}> Los egresos de caja piden la clave de un gerente o del administrador</label>
      <label class="row" style="font-weight:600;margin-top:6px"><input type="checkbox" id="gAg" ${CFG.autoriza_gastos === '1' ? 'checked' : ''}> También los gastos pagados en efectivo con dinero de la caja</label></div>
    <div><button class="btn pri" onclick="negocioOk()">Guardar</button></div></div>`;
};
async function negocioOk() {
  await hacer(() => PUT('/api/config', { hotel_nombre: val('gN') || 'Mi Autolavado', hotel_direccion: val('gD'), hotel_telefono: val('gT'), ticket_pie: val('gP'), ticket_ancho: val('gA'), autoriza_egresos: $('#gAe').checked ? '1' : '0', autoriza_gastos: $('#gAg').checked ? '1' : '0' }), 'Guardado');
  CFG = await GET('/api/config'); marco(); pintarTurno(); ir('cfg');
}
function cCarwash() {
  $('#cfgc').innerHTML = `<div class="stack"><div class="card"><h2>Número del paquete para la cámara</h2>
    <label class="row" style="font-weight:600"><input type="checkbox" id="wAv" ${CFG.cw_aviso_pantalla !== '0' ? 'checked' : ''}> Al cobrar, mostrar el número del paquete en GRANDE en toda la pantalla</label>
    <div class="f" style="margin-top:6px"><label class="l">Segundos que se queda en pantalla<input id="wAs" type="number" min="2" max="30" value="${esc(CFG.cw_aviso_segundos || '6')}"></label></div>
    <label class="row" style="font-weight:600;margin-top:10px"><input type="checkbox" id="wCo" ${CFG.cw_copia_lavador !== '0' ? 'checked' : ''}> Imprimir una segunda tira para poner en el parabrisas o entregar al secador (con el número del paquete, placas y lavador)</label>
    <p class="sub">El número del paquete sale <b>GIGANTE</b> al principio del ticket (es lo primero que imprime), para que la cámara lo vea al salir el papel. El logo del ticket se pone en <b>Impresora y caja</b>.</p>
    <button class="btn" onclick="cwPrueba()">Imprimir ticket de prueba</button></div>
    <div class="card"><h2>Datos del vehículo</h2><label class="row" style="font-weight:600"><input type="checkbox" id="wPl" ${CFG.cw_pedir_placas !== '0' ? 'checked' : ''}> Mostrar el campo de placas y el tipo de vehículo en la venta (opcional al cobrar)</label>
      <label class="l" style="margin-top:8px">Tipos de vehículo (separados por comas)<input id="wTv" value="${esc(CFG.cw_tipos_vehiculo || '')}" placeholder="Auto, Camioneta, SUV, Pick up, Moto"></label></div>
    <div class="card"><h2>Paquetes de lavado</h2><p class="sub" style="margin-top:0">Los paquetes (número, nombre, precio, qué incluye y color) se dan de alta en <b>Paquetes y productos → Paquetes de lavado</b>.</p><button class="btn" onclick="iTab='paq';ir('inv')">Ir a los paquetes</button></div>
    <div><button class="btn pri" onclick="carwashOk()">Guardar</button></div></div>`;
}
async function carwashOk() {
  await hacer(() => PUT('/api/config', { cw_aviso_pantalla: $('#wAv').checked ? '1' : '0', cw_aviso_segundos: String(Math.max(2, Math.min(30, parseInt(val('wAs')) || 6))), cw_copia_lavador: $('#wCo').checked ? '1' : '0', cw_pedir_placas: $('#wPl').checked ? '1' : '0', cw_tipos_vehiculo: val('wTv') }), 'Guardado');
  CFG = await GET('/api/config'); cCarwash();
}
function cwPrueba() {
  const p = PAQS()[1] || PAQS()[0] || { paquete: '2', nombre: 'Lavado exterior e interior', precio: 180, incluye: 'Aspirado y tablero' };
  imprimirTicketCW({ folio: '00000', fecha: new Date().toISOString().slice(0, 19).replace('T', ' '), placas: 'ABC-123-D', vehiculo: 'Camioneta', usuario: YO.nombre, total: p.precio, recibido: p.precio, cambio: 0,
    items: [{ paquete: p.paquete, descripcion: p.nombre, cantidad: 1, importe: p.precio, incluye: p.incluye }] }, 'Ticket de prueba');
}
// Clasificación de gastos (sin contratos de arrendamiento)
cContrato = function () {
  $('#cfgc').innerHTML = `<div class="stack"><div class="card"><div class="row" style="justify-content:space-between;margin-bottom:6px;flex-wrap:wrap"><h2 style="margin:0">Clasificación de gastos</h2><button class="btn sm" onclick="$('#aG').value=CFG._clasif_base">Restaurar las recomendadas</button></div>
    <p class="sub" style="margin-top:0">Una clasificación por renglón, luego dos puntos y sus tipos de gasto separados por comas. Ejemplo: <b>Compras: Químicos y jabones, Ceras, Toallas</b></p>
    <textarea id="aG" rows="10" style="font-family:var(--fBody);font-size:13px">${esc(CFG.gastos_clasificacion)}</textarea></div>
    <div><button class="btn pri" onclick="gastosCfgOk()">Guardar</button></div></div>`;
};
async function gastosCfgOk() { await hacer(() => PUT('/api/config', { gastos_clasificacion: $('#aG').value.trim() || CFG._clasif_base }), 'Guardado'); CFG = await GET('/api/config'); }
