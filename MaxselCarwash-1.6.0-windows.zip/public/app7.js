// Maxsel Hotel 1.7 — Control de asistencia (checador con NIP o huella DigitalPersona) y cierre de mes
'use strict';
VISTAS.splice(VISTAS.findIndex((v) => v[0] === 'rep'), 0, ['asis', 'Asistencia', 'checador|asistencia']);
VISTAS.splice(VISTAS.findIndex((v) => v[0] === 'rep') + 1, 0, ['cierre', 'Cierre de mes', 'reportes']);
{
  const _ir = ir;
  ir = async function (v) {
    if (v !== 'asis' && v !== 'cierre') { HUELLA_ON = false; return _ir(v); }
    vista = v; clearInterval(timer); pintarNav(ir.badge);
    try { await (v === 'asis' ? vAsis() : vCierre()); } catch (e) { if (e.message) $('#main').innerHTML = `<div class="aviso bad">${esc(e.message)}</div>`; }
    if (window.innerWidth < 760) window.scrollTo(0, 0);
  };
}
const EST_ASIS = { asistencia: ['Asistió', 'p-ok'], retardo: ['Retardo', 'p-warn'], falta: ['Falta', 'p-bad'], descanso: ['Descanso', ''], festivo: ['Festivo', ''], festivo_trabajado: ['Trabajó festivo', 'p-ok'], trabajo_descanso: ['Trabajó en descanso', 'p-ok'],
  pendiente: ['Pendiente', ''], sin_horario: ['Sin horario', ''], vacaciones: ['Vacaciones', 'p-ok'], permiso_goce: ['Permiso con goce', 'p-ok'], permiso_sin_goce: ['Permiso sin goce', 'p-warn'], incapacidad: ['Incapacidad', ''], falta_justificada: ['Falta justificada', ''], descanso_extra: ['Descanso extra', ''] };
const TIPO_CHK = { entrada: 'Entrada', descanso: 'Salida a comer', regreso: 'Regreso de comer', salida: 'Salida' };
const TIPO_INC = { vacaciones: 'Vacaciones', permiso_goce: 'Permiso con goce', permiso_sin_goce: 'Permiso sin goce', incapacidad: 'Incapacidad', falta_justificada: 'Falta justificada', descanso_extra: 'Descanso extra' };
const DIAS = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
const pill = (e) => `<span class="pill ${EST_ASIS[e]?.[1] || ''}">${EST_ASIS[e]?.[0] || e}</span>`;
const hm = (f) => (f ? String(f).slice(11, 16) : '');
const hrs = (min) => `${Math.floor(min / 60)}:${String(Math.round(min % 60)).padStart(2, '0')}`;
const lunesDe = (d = new Date()) => { const x = new Date(d); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x.toISOString().slice(0, 10); };
let aTab = 'checador', aDesde = lunesDe(), aHasta = hoyISO(), aEmp = '', HUELLA_ON = false, AEMPS = [];

async function vAsis() {
  const admin = puede('asistencia');
  if (!admin) aTab = 'checador';
  const T = [['checador', 'Checador'], ...(admin ? [['hoy', 'Hoy'], ['reporte', 'Reporte'], ['registros', 'Registros'], ['horarios', 'Horarios, NIP y huella'], ['festivos', 'Días festivos'], ['incid', 'Vacaciones y permisos'], ['reglas', 'Reglas y checador']] : [])];
  if (aTab !== 'checador') HUELLA_ON = false;
  $('#main').innerHTML = cab('Asistencia', 'Entradas, salidas, descansos, retardos, faltas, festivos y vacaciones del personal') + `<div class="tabs" style="margin-bottom:14px">${T.map(([k, n]) => `<button class="${aTab === k ? 'on' : ''}" onclick="aTab='${k}';vAsis()">${n}</button>`).join('')}</div><div id="asisc"></div>`;
  if (admin && aTab !== 'checador') AEMPS = await GET('/api/asistencia/empleados');
  await ({ checador: aChecador, hoy: aHoy, reporte: aReporte, registros: aRegistros, horarios: aHorarios, festivos: aFestivos, incid: aIncid, reglas: aReglas })[aTab]();
}
const selEmp = (id, actual, todos) => `<select id="${id}"><option value="">${todos ? 'Todos los empleados' : '— Elija —'}</option>${AEMPS.filter((e) => e.activo || String(e.id) === String(actual)).map((e) => `<option value="${e.id}" ${String(e.id) === String(actual) ? 'selected' : ''}>${esc(e.nombre)}</option>`).join('')}</select>`;

// ---------- Checador ----------
async function aChecador() {
  let est = { instalado: false }; try { est = await GET('/api/huella/estado'); } catch { /* sin permiso */ }
  const met = est.metodo || CFG.asis_metodo || 'ambos', conNip = met !== 'huella', conHuella = met !== 'nip';
  $('#asisc').innerHTML = `<div class="aviso" style="margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><span>Para dejar el checador siempre abierto use la <b>pantalla del checador</b> (también tiene su icono en el escritorio: "Checador Maxsel Carwash").</span><button class="btn pri" onclick="window.open('/checador','checador','width=1280,height=800')">Abrir pantalla del checador</button></div>
    <div class="checador"><div class="card chk-reloj"><div id="chkHora" class="chk-hora"></div><div id="chkFecha" class="sub"></div></div>
    <div class="card"><div id="chkRes" class="chk-res"><span class="sub">${conNip ? 'Ponga su número y NIP' + (conHuella && est.instalado && !est.error ? ', o su dedo en el lector' : '') : 'Ponga su dedo en el lector'}.</span></div>
      ${conNip ? '' : '<div hidden>'}<div class="f" style="margin-top:12px"><label class="l">Número de empleado<input id="chkN" inputmode="numeric" autocomplete="off" style="font-size:22px"></label><label class="l">NIP<input id="chkP" type="password" inputmode="numeric" autocomplete="off" style="font-size:22px" onkeydown="if(event.key==='Enter')checar()"></label></div>
      <div class="chk-btns"><button class="btn pri" onclick="checar()">Checar</button>${Object.entries(TIPO_CHK).map(([k, n]) => `<button class="btn" onclick="checar('${k}')">${n}</button>`).join('')}</div>
      <div class="sub" style="margin-top:6px">"Checar" elige solo: entrada → salida a comer → regreso → salida.</div>${conNip ? '' : '</div>'}</div>
    <div class="card"><h2>Lector de huellas</h2>${!conHuella ? '<p class="sub" style="margin:0">El checador está configurado solo con número y NIP (vea Reglas).</p>' : !est.instalado ? '<p class="sub" style="margin:0">El lector de huellas no está instalado en esta computadora. Se checa con número y NIP.</p>'
      : est.error ? `<div class="aviso bad">${esc(est.error)}</div>` : `<p style="margin:0">Lector: <b>${esc(est.lector || 'DigitalPersona')}</b> · ${est.registradas} huella(s) registradas</p>
      <button class="btn ${HUELLA_ON ? 'bad' : 'pri'}" style="margin-top:10px" onclick="HUELLA_ON=!HUELLA_ON;aChecador();if(HUELLA_ON)cicloHuella()">${HUELLA_ON ? 'Detener lector' : 'Activar checado con huella'}</button>
      ${HUELLA_ON ? '<div class="aviso ok" style="margin-top:10px">Lector activo: ponga su dedo para checar.</div>' : ''}`}</div>
    <div class="card"><h2>Hoy</h2><div id="chkHoy"></div></div></div>`;
  relojChecador(); chkHoy(); if (conNip) $('#chkN').focus();
}
function relojChecador() {
  clearInterval(relojChecador.t);
  const f = () => { const h = $('#chkHora'); if (!h) return clearInterval(relojChecador.t); const d = new Date(); h.textContent = d.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit', second: '2-digit' }); $('#chkFecha').textContent = d.toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }); };
  f(); relojChecador.t = setInterval(f, 1000);
}
async function chkHoy() {
  const el = $('#chkHoy'); if (!el) return;
  const L = await GET('/api/asistencia/hoy').catch(() => []);
  el.innerHTML = `<div class="tw"><table><tbody>${L.map((e) => `<tr><td><b>${esc(e.nombre)}</b><div class="sub">${esc(e.puesto || '')}</div></td><td>${e.ultima ? `${TIPO_CHK[e.ultima.tipo]} ${hm(e.ultima.fecha)}` : '<span class="sub">Sin checar</span>'}</td><td>${e.estado ? pill(e.estado) : ''}</td></tr>`).join('') || '<tr><td class="empty">Sin empleados.</td></tr>'}</tbody></table></div>`;
}
function mostrarChecada(r) {
  const el = $('#chkRes'); if (!el) return;
  el.innerHTML = `<div class="chk-ok ${r.aviso ? 'tarde' : ''}"><b>${esc(r.nombre)}</b><span>${esc(r.texto)} · ${hm(r.fecha)}${r.metodo === 'huella' ? ' · huella' : ''}</span>${r.aviso ? `<span class="chk-aviso">${esc(r.aviso)}</span>` : ''}</div>`;
  clearTimeout(mostrarChecada.t); mostrarChecada.t = setTimeout(() => { const x = $('#chkRes'); if (x) x.innerHTML = '<span class="sub">Listo para el siguiente.</span>'; }, 6000);
  chkHoy();
}
async function checar(tipo) {
  try {
    const r = await POST('/api/asistencia/checar', { numero: val('chkN'), pin: val('chkP'), tipo });
    $('#chkN').value = ''; $('#chkP').value = ''; $('#chkN').focus(); mostrarChecada(r);
  } catch (e) { $('#chkRes').innerHTML = `<div class="aviso bad">${esc(e.message)}</div>`; $('#chkP').value = ''; }
}
async function cicloHuella() {
  while (HUELLA_ON && vista === 'asis' && aTab === 'checador') {
    try {
      const r = await POST('/api/huella/checar', { segundos: 10 });
      if (r.sinDedo) continue;
      if (r.noReconocida) { $('#chkRes').innerHTML = '<div class="aviso bad">Huella no reconocida. Intente otra vez o use su número y NIP.</div>'; continue; }
      mostrarChecada(r); await new Promise((ok) => setTimeout(ok, 1500));
    } catch (e) { const x = $('#chkRes'); if (x) x.innerHTML = `<div class="aviso bad">${esc(e.message)}</div>`; await new Promise((ok) => setTimeout(ok, 3000)); if (/no está instalado|no se encontró|ninguno/i.test(e.message)) HUELLA_ON = false; }
  }
}

// ---------- Hoy ----------
async function aHoy() {
  const L = await GET('/api/asistencia/hoy'), c = (k) => L.filter((e) => e.estado === k).length;
  const dentro = L.filter((e) => e.ultima && (e.ultima.tipo === 'entrada' || e.ultima.tipo === 'regreso')).length, desc = L.filter((e) => e.ultima?.tipo === 'descanso').length;
  $('#asisc').innerHTML = `<div class="kpis"><div class="kpi"><span>Trabajando ahora</span><b>${dentro}</b><div class="sub">${desc} en descanso</div></div><div class="kpi"><span>Retardos hoy</span><b style="color:var(--limp)">${c('retardo')}</b></div><div class="kpi"><span>Faltas hoy</span><b style="color:var(--ocup)">${c('falta')}</b><div class="sub">${c('pendiente')} aún no llegan</div></div><div class="kpi"><span>Descanso / vacaciones</span><b>${c('descanso') + c('vacaciones') + c('festivo')}</b></div></div>
    <div class="card"><div class="tw"><table><thead><tr><th>Empleado</th><th>Horario hoy</th><th>Checadas</th><th>Estado</th></tr></thead><tbody>
    ${L.map((e) => `<tr><td><b>${esc(e.nombre)}</b><div class="sub">${esc(e.puesto || '')}</div></td><td>${e.horario ? `${e.horario.entrada} a ${e.horario.salida}` : '<span class="sub">Descansa / sin horario</span>'}</td><td>${e.checadas.map((x) => `${TIPO_CHK[x.tipo]} ${hm(x.fecha)}`).join('<br>') || '—'}</td><td>${e.estado ? pill(e.estado) : ''}${e.tarde ? ` <span class="sub">${e.tarde} min</span>` : ''}</td></tr>`).join('') || '<tr><td colspan="4" class="empty">Agregue empleados en Gastos → Empleados.</td></tr>'}</tbody></table></div></div>`;
}

// ---------- Reporte ----------
async function aReporte() {
  $('#asisc').innerHTML = `<div class="card" style="margin-bottom:14px"><div class="row" style="flex-wrap:wrap;gap:8px;align-items:flex-end"><label class="l">Desde<input type="date" id="arD" value="${aDesde}"></label><label class="l">Hasta<input type="date" id="arH" value="${aHasta}"></label><label class="l">Empleado${selEmp('arE', aEmp, true)}</label>
    <button class="btn" onclick="aDesde=val('arD');aHasta=val('arH');aEmp=val('arE');aReporte()">Ver</button><button class="btn" onclick="aDesde=lunesDe();aHasta=hoyISO();aReporte()">Esta semana</button><button class="btn" onclick="const d=new Date();aDesde=hoyISO().slice(0,8)+'01';aHasta=hoyISO();aReporte()">Este mes</button>
    <span style="flex:1"></span><button class="btn" onclick="pdfAsis()">PDF</button><button class="btn pri" onclick="excelAsis()">Excel</button></div></div><div id="arR"><div class="empty">Calculando…</div></div>`;
  const R = await GET(`/api/asistencia/reporte?desde=${aDesde}&hasta=${aHasta}&empleado_id=${aEmp}`); aReporte.R = R;
  const tot = (k) => R.reduce((s, r) => s + (r.resumen[k] || 0), 0);
  $('#arR').innerHTML = `<div class="kpis"><div class="kpi"><span>Retardos</span><b style="color:var(--limp)">${tot('retardos')}</b><div class="sub">${tot('min_tarde')} minutos en total</div></div><div class="kpi"><span>Faltas</span><b style="color:var(--ocup)">${tot('faltas')}</b><div class="sub">+ ${tot('faltas_retardos')} por acumular retardos</div></div>
      <div class="kpi"><span>Descuentos</span><b style="color:var(--ocup)">${money(tot('total_descuento'))}</b><div class="sub">retardos ${money(tot('desc_retardos'))} · faltas ${money(tot('desc_faltas'))}</div></div><div class="kpi"><span>Pago extra festivos</span><b>${money(tot('pago_festivos'))}</b><div class="sub">${tot('festivos_trabajados')} festivo(s) trabajados</div></div></div>
    <div class="card"><div class="tw"><table><thead><tr><th>Empleado</th><th class="n">Días trab.</th><th class="n">Horas</th><th class="n">Retardos</th><th class="n">Min. tarde</th><th class="n">Faltas</th><th class="n">Por retardos</th><th class="n">Descansos</th><th class="n">Festivos trab.</th><th>Vacaciones / permisos</th><th class="n">Descuento</th><th class="n">Extra festivos</th></tr></thead><tbody>
    ${R.map((r, i) => { const x = r.resumen; return `<tr class="click" onclick="detAsis(${i})"><td><b>${esc(r.empleado.nombre)}</b><div class="sub">${esc(r.empleado.puesto || '')}${r.empleado.horario ? '' : ' · sin horario'}</div></td><td class="n">${x.trabajados}</td><td class="n">${hrs(x.min_trabajados)}</td><td class="n">${x.retardos}</td><td class="n">${x.min_tarde}</td><td class="n">${x.faltas}</td><td class="n">${x.faltas_retardos}</td><td class="n">${x.descansos}</td><td class="n">${x.festivos_trabajados}</td>
      <td>${Object.entries(x.incidencias).map(([k, n]) => `${TIPO_INC[k]} ${n}`).join(', ') || '—'}</td><td class="n" style="color:${x.total_descuento ? 'var(--ocup)' : 'inherit'}">${money(x.total_descuento)}</td><td class="n">${money(x.pago_festivos)}</td></tr>`; }).join('') || '<tr><td colspan="12" class="empty">Sin empleados.</td></tr>'}</tbody></table></div>
    <div class="sub" style="margin-top:6px">Toque un empleado para ver día por día. Los descuentos se calculan con las Reglas (pestaña Reglas) y se pueden pasar a "Pagar nómina".</div></div>`;
}
function detAsis(i) {
  const r = aReporte.R[i], x = r.resumen;
  modal(`${esc(r.empleado.nombre)} · ${fd(aDesde)} al ${fd(aHasta)}`, `<div class="kv"><span>Sueldo diario</span><b>${money(x.sueldo_diario)}</b><span>Descuento por retardos</span><b>${money(x.desc_retardos)}</b><span>Descuento por faltas</span><b>${money(x.desc_faltas)}</b><span>Total a descontar</span><b style="color:var(--ocup)">${money(x.total_descuento)}</b><span>Pago extra por festivos</span><b>${money(x.pago_festivos)}</b></div>
    <div class="tw" style="max-height:420px;margin-top:10px"><table><thead><tr><th>Fecha</th><th>Horario</th><th>Entrada</th><th>Descanso</th><th>Salida</th><th class="n">Trabajó</th><th>Estado</th><th class="n">Descuento</th></tr></thead><tbody>
    ${r.dias.map((d) => `<tr><td>${DIAS[d.dow].slice(0, 3)} ${fd(d.fecha)}</td><td>${d.horario ? d.horario.entrada + '–' + d.horario.salida : '—'}</td><td>${hm(d.entrada)}</td><td>${d.descanso_min ? d.descanso_min + ' min' : ''}</td><td>${hm(d.salida)}</td><td class="n">${d.trabajado_min ? hrs(d.trabajado_min) : ''}</td>
      <td>${pill(d.estado)}${d.tarde ? ` <span class="sub">${d.tarde} min</span>` : ''}${d.nota ? `<div class="sub">${esc(d.nota)}</div>` : ''}</td><td class="n">${d.descuento ? money(d.descuento) : d.extra ? '+' + money(d.extra) : ''}</td></tr>`).join('')}</tbody></table></div>`,
  `<button class="btn" onclick="cerrar()">Cerrar</button>`, true);
}
function excelAsis() {
  const R = aReporte.R; if (!R) return;
  const res = [[{ v: `${CFG.hotel_nombre} · Asistencia del ${fd(aDesde)} al ${fd(aHasta)}`, s: 't' }], [], H_('Empleado', 'Puesto', 'Días trabajados', 'Horas trabajadas', 'Retardos', 'Minutos tarde', 'Faltas', 'Faltas por retardos', 'Descansos', 'Festivos', 'Festivos trabajados', 'Vacaciones', 'Permisos', 'Incapacidades', 'Salidas antes', 'Sueldo diario', 'Desc. retardos', 'Desc. faltas', 'Total descuento', 'Extra festivos'),
    ...R.map((r) => { const x = r.resumen, I = x.incidencias; return [r.empleado.nombre, r.empleado.puesto || '', x.trabajados, hrs(x.min_trabajados), x.retardos, x.min_tarde, x.faltas, x.faltas_retardos, x.descansos, x.festivos, x.festivos_trabajados, I.vacaciones || 0, (I.permiso_goce || 0) + (I.permiso_sin_goce || 0), I.incapacidad || 0, x.salidas_antes, M_(x.sueldo_diario), M_(x.desc_retardos), M_(x.desc_faltas), BM_(x.total_descuento), M_(x.pago_festivos)]; })];
  const det = [H_('Empleado', 'Fecha', 'Día', 'Horario', 'Entrada', 'Comida (min)', 'Salida', 'Horas trabajadas', 'Estado', 'Minutos tarde', 'Descuento', 'Extra', 'Nota')];
  for (const r of R) for (const d of r.dias) det.push([r.empleado.nombre, fd(d.fecha), DIAS[d.dow], d.horario ? d.horario.entrada + '-' + d.horario.salida : '', hm(d.entrada), d.descanso_min || '', hm(d.salida), d.trabajado_min ? hrs(d.trabajado_min) : '', EST_ASIS[d.estado]?.[0] || d.estado, d.tarde || '', d.descuento ? M_(d.descuento) : '', d.extra ? M_(d.extra) : '', d.nota || '']);
  const chk = [H_('Empleado', 'Fecha y hora', 'Tipo', 'Cómo')];
  for (const r of R) for (const d of r.dias) for (const c of d.checadas) chk.push([r.empleado.nombre, fdt(c.fecha), TIPO_CHK[c.tipo], { nip: 'Número y NIP', huella: 'Huella', manual: 'Manual' }[c.metodo] || c.metodo || '']);
  descargarArchivo(XLSX.libro([{ nombre: 'Resumen', filas: res }, { nombre: 'Día por día', filas: det }, { nombre: 'Checadas', filas: chk }]), `Asistencia ${aDesde} al ${aHasta}.xlsx`);
}
function pdfAsis() {
  const R = aReporte.R; if (!R) return;
  imprimirDoc(`<div class="rep"><div class="rep-enc"><b>${esc(CFG.hotel_nombre)}</b><span>REPORTE DE ASISTENCIA</span><span>Del ${fd(aDesde)} al ${fd(aHasta)}</span></div>
    <h3>Resumen</h3><table><thead><tr><th>Empleado</th><th class="n">Días</th><th class="n">Horas</th><th class="n">Retardos</th><th class="n">Min.</th><th class="n">Faltas</th><th class="n">x Ret.</th><th class="n">Fest. trab.</th><th>Vac./perm.</th><th class="n">Descuento</th><th class="n">Extra</th></tr></thead><tbody>
    ${R.map((r) => { const x = r.resumen; return `<tr><td>${esc(r.empleado.nombre)}</td><td class="n">${x.trabajados}</td><td class="n">${hrs(x.min_trabajados)}</td><td class="n">${x.retardos}</td><td class="n">${x.min_tarde}</td><td class="n">${x.faltas}</td><td class="n">${x.faltas_retardos}</td><td class="n">${x.festivos_trabajados}</td><td>${Object.entries(x.incidencias).map(([k, n]) => `${TIPO_INC[k]} ${n}`).join(', ')}</td><td class="n">${money(x.total_descuento)}</td><td class="n">${money(x.pago_festivos)}</td></tr>`; }).join('')}</tbody></table>
    ${R.map((r) => `<h3>${esc(r.empleado.nombre)}${r.empleado.puesto ? ' · ' + esc(r.empleado.puesto) : ''}</h3><table><thead><tr><th>Fecha</th><th>Horario</th><th>Entrada</th><th>Desc.</th><th>Salida</th><th class="n">Horas</th><th>Estado</th><th class="n">Desc./extra</th></tr></thead><tbody>
      ${r.dias.map((d) => `<tr><td>${DIAS[d.dow].slice(0, 3)} ${fd(d.fecha)}</td><td>${d.horario ? d.horario.entrada + '–' + d.horario.salida : '—'}</td><td>${hm(d.entrada)}</td><td>${d.descanso_min ? d.descanso_min + "'" : ''}</td><td>${hm(d.salida)}</td><td class="n">${d.trabajado_min ? hrs(d.trabajado_min) : ''}</td><td>${EST_ASIS[d.estado]?.[0] || d.estado}${d.tarde ? ' (' + d.tarde + ' min)' : ''}</td><td class="n">${d.descuento ? '-' + money(d.descuento) : d.extra ? '+' + money(d.extra) : ''}</td></tr>`).join('')}
      <tr class="t"><td colspan="5">Total a descontar ${money(r.resumen.total_descuento)} · extra festivos ${money(r.resumen.pago_festivos)}</td><td colspan="3" class="firma" style="text-align:right;font-weight:400">Firma de conformidad ____________________</td></tr></tbody></table>`).join('')}
    <div class="rep-pie">Impreso ${new Date().toLocaleString('es-MX')}</div></div>`, 'carta', 'Reporte de asistencia');
}

// ---------- Registros (checadas) ----------
async function aRegistros() {
  const L = await GET(`/api/asistencia/checadas?desde=${aDesde}&hasta=${aHasta}&empleado_id=${aEmp}`);
  $('#asisc').innerHTML = `<div class="card" style="margin-bottom:14px"><div class="row" style="flex-wrap:wrap;gap:8px;align-items:flex-end"><label class="l">Desde<input type="date" id="arD" value="${aDesde}"></label><label class="l">Hasta<input type="date" id="arH" value="${aHasta}"></label><label class="l">Empleado${selEmp('arE', aEmp, true)}</label>
    <button class="btn" onclick="aDesde=val('arD');aHasta=val('arH');aEmp=val('arE');aRegistros()">Ver</button><span style="flex:1"></span><button class="btn pri" onclick="chkManual()">Agregar registro (olvidó checar)</button></div></div>
    <div class="card"><div class="tw"><table><thead><tr><th>Fecha y hora</th><th>Empleado</th><th>Tipo</th><th>Cómo</th><th>Nota</th><th></th></tr></thead><tbody>
    ${L.map((c) => `<tr style="${c.anulada ? 'opacity:.45;text-decoration:line-through' : ''}"><td>${fdt(c.fecha)}</td><td>${esc(c.nombre)}</td><td>${TIPO_CHK[c.tipo]}</td><td>${{ nip: 'Número y NIP', huella: 'Huella', manual: 'Manual · ' + esc(c.usuario || '') }[c.metodo] || ''}</td><td class="sub">${esc(c.nota || '')}</td><td>${c.anulada ? '' : `<button class="btn sm bad" onclick="confirmar(this,()=>chkAnular(${c.id}))">Anular</button>`}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">Sin registros en esas fechas.</td></tr>'}</tbody></table></div></div>`;
}
function chkManual() {
  modal('Agregar registro manual', `<div class="f"><label class="l">Empleado${selEmp('cmE', aEmp)}</label><label class="l">Tipo<select id="cmT">${Object.entries(TIPO_CHK).map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select></label>
    <label class="l">Fecha y hora<input id="cmF" type="datetime-local" value="${hoyISO()}T08:00"></label></div><label class="l">Motivo<input id="cmN" placeholder="Ej. olvidó checar, se descompuso el lector"></label>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="chkManualOk()">Guardar</button>`);
}
async function chkManualOk() { await hacer(() => POST('/api/asistencia/checadas', { empleado_id: val('cmE'), tipo: val('cmT'), fecha: val('cmF'), nota: val('cmN') }), 'Registro agregado'); cerrar(); aRegistros(); }
async function chkAnular(id) { await hacer(() => POST(`/api/asistencia/checadas/${id}/anular`), 'Registro anulado'); aRegistros(); }

// ---------- Horarios, NIP y huella ----------
async function aHorarios() {
  let est = { instalado: false }; try { est = await GET('/api/huella/estado'); } catch { /* nada */ }
  aHorarios.est = est;
  $('#asisc').innerHTML = `<div class="card"><div class="tw"><table><thead><tr><th>Empleado</th><th>Número</th><th>NIP</th><th>Huella</th><th>Horario</th><th></th></tr></thead><tbody>
    ${AEMPS.filter((e) => e.activo).map((e) => `<tr class="click" onclick="horModal(${e.id})"><td><b>${esc(e.nombre)}</b><div class="sub">${esc(e.puesto || '')}</div></td><td class="mono">${esc(e.numero || '—')}</td><td>${e.tiene_pin ? '<span class="pill p-ok">Sí</span>' : '<span class="pill p-warn">Falta</span>'}</td><td>${e.tiene_huella ? '<span class="pill p-ok">Registrada</span>' : '<span class="sub">—</span>'}</td>
      <td class="sub">${e.horario ? resumenHorario(e.horario) : 'Sin horario (no cuenta retardos ni faltas)'}</td><td><button class="btn sm">Editar</button></td></tr>`).join('') || '<tr><td colspan="6" class="empty">Agregue empleados en Gastos → Empleados.</td></tr>'}</tbody></table></div>
    <div class="sub" style="margin-top:6px">${est.instalado ? (est.error ? 'Lector: ' + esc(est.error) : 'Lector de huellas listo: ' + esc(est.lector || '')) : 'El lector de huellas no está instalado en esta computadora (se puede checar con número y NIP).'}</div></div>`;
}
function resumenHorario(h) {
  const g = {}; for (let k = 1; k <= 7; k++) { const d = k % 7, x = h[d]; const key = x ? `${x.entrada}–${x.salida}` : 'Descansa'; (g[key] ||= []).push(DIAS[d].slice(0, 3)); }
  return Object.entries(g).map(([k, ds]) => `${ds.join(', ')}: ${k}`).join(' · ');
}
function horModal(id) {
  const e = AEMPS.find((x) => x.id === id), h = e.horario || {}, est = aHorarios.est || {};
  const fila = (d) => { const x = h[d]; return `<tr><td><label class="row" style="gap:6px;font-weight:600"><input type="checkbox" id="hT${d}" ${x || (!e.horario && d !== 0) ? 'checked' : ''}> ${DIAS[d]}</label></td><td><input type="time" id="hE${d}" value="${x?.entrada || '08:00'}"></td><td><input type="time" id="hS${d}" value="${x?.salida || '16:00'}"></td><td><input type="number" min="0" id="hD${d}" value="${x?.descanso ?? 60}" style="width:80px"></td></tr>`; };
  modal(`Checador y horario · ${esc(e.nombre)}`, `<div class="f"><label class="l">Número para checar<input id="hN" value="${esc(e.numero || '')}" inputmode="numeric"></label><label class="l">NIP nuevo (4 a 8 números)<input id="hP" type="password" inputmode="numeric" placeholder="${e.tiene_pin ? 'Déjelo vacío para no cambiarlo' : 'Ej. 1234'}"></label></div>
    <div class="lbl" style="margin-top:8px">Horario de trabajo (desmarque los días que descansa)</div>
    <div class="tw"><table class="hor"><thead><tr><th>Día</th><th>Entrada</th><th>Salida</th><th>Comida (min)</th></tr></thead><tbody>${[1, 2, 3, 4, 5, 6, 0].map(fila).join('')}</tbody></table></div>
    <div class="row" style="gap:8px;margin-top:6px;flex-wrap:wrap"><button class="btn sm" onclick="for(const d of [2,3,4,5,6,0]){$('#hE'+d).value=$('#hE1').value;$('#hS'+d).value=$('#hS1').value;$('#hD'+d).value=$('#hD1').value}">Copiar el horario del lunes a todos</button>
      <label class="row" style="font-weight:600;font-size:13px"><input type="checkbox" id="hSin" ${e.horario ? '' : 'checked'}> Sin horario (no calcula retardos ni faltas)</label></div>
    <div class="card" style="padding:12px;margin-top:12px"><div class="lbl">Huella digital</div>${est.instalado && !est.error ? `<p style="margin:4px 0">${e.tiene_huella ? 'Ya tiene huella registrada.' : 'Aún no tiene huella.'}</p><div class="row" style="gap:8px"><button class="btn pri" onclick="enrolar(${e.id})">${e.tiene_huella ? 'Volver a registrar huella' : 'Registrar huella'}</button>${e.tiene_huella ? `<button class="btn bad" onclick="confirmar(this,()=>borrarHuella(${e.id}))">Borrar huella</button>` : ''}</div><div id="enrRes" class="sub" style="margin-top:6px"></div>`
      : `<p class="sub" style="margin:4px 0">${est.error ? esc(est.error) : 'El lector de huellas no está instalado en esta computadora.'}</p>`}</div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="horOk(${id})">Guardar</button>`, true);
}
async function horOk(id) {
  let horario = null;
  if (!$('#hSin').checked) { horario = {}; for (let d = 0; d <= 6; d++) horario[d] = $('#hT' + d).checked ? { entrada: val('hE' + d), salida: val('hS' + d), descanso: num('hD' + d) } : null; }
  await hacer(() => PUT('/api/asistencia/empleados/' + id, { numero: val('hN'), pin: val('hP'), horario }), 'Guardado'); cerrar(); vAsis();
}
async function enrolar(id) {
  $('#enrRes').innerHTML = '<div class="aviso">Ponga el <b>mismo dedo</b> en el lector varias veces (4 normalmente). Levántelo entre cada vez.</div>';
  try { const r = await POST('/api/huella/enrolar/' + id); toast(`Huella registrada (${r.muestras} lecturas)`); cerrar(); vAsis(); } catch (e) { $('#enrRes').innerHTML = `<div class="aviso bad">${esc(e.message)}</div>`; }
}
async function borrarHuella(id) { await hacer(() => DEL('/api/huella/' + id), 'Huella borrada'); cerrar(); vAsis(); }

// ---------- Días festivos ----------
let aAnio = new Date().getFullYear();
async function aFestivos() {
  const L = await GET('/api/festivos?anio=' + aAnio);
  $('#asisc').innerHTML = `<div class="card"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px"><div class="row" style="gap:6px"><button class="btn sm" onclick="aAnio--;aFestivos()">‹</button><b style="font-size:18px">${aAnio}</b><button class="btn sm" onclick="aAnio++;aFestivos()">›</button></div>
    <div class="row" style="gap:8px"><button class="btn" onclick="festLey()">Agregar los de ley (LFT)</button><button class="btn pri" onclick="festModal()">Agregar día festivo</button></div></div>
    <div class="tw"><table><thead><tr><th>Fecha</th><th>Día</th><th>Festivo</th><th>Descansan</th><th></th></tr></thead><tbody>
    ${L.map((f) => `<tr><td>${fd(f.fecha)}</td><td>${DIAS[aF(f.fecha).getDay()]}</td><td>${esc(f.nombre || '')}</td><td>${f.descansa ? 'Sí' : 'No (día normal)'}</td><td><button class="btn sm bad" onclick="confirmar(this,()=>festBorrar(${f.id}))">Quitar</button></td></tr>`).join('') || '<tr><td colspan="5" class="empty">Sin días festivos. Use "Agregar los de ley".</td></tr>'}</tbody></table></div>
    <div class="sub" style="margin-top:6px">El que trabaja en día festivo recibe el pago extra que ponga en Reglas (la ley marca salario doble adicional). El que no trabaja no tiene falta.</div></div>`;
}
async function festLey() { const r = await hacer(() => POST('/api/festivos/ley', { anio: aAnio })); toast('Días de ley agregados'); aFestivos(); }
function festModal() { modal('Agregar día festivo', `<div class="f"><label class="l">Fecha<input type="date" id="ffF" value="${aAnio}-12-12"></label><label class="l">Nombre<input id="ffN" placeholder="Ej. Día de la Virgen"></label></div><label class="row" style="font-weight:600"><input type="checkbox" id="ffD" checked> Es día de descanso</label>`, `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="festOk()">Guardar</button>`); }
async function festOk() { await hacer(() => POST('/api/festivos', { fecha: val('ffF'), nombre: val('ffN'), descansa: $('#ffD').checked }), 'Guardado'); cerrar(); aFestivos(); }
async function festBorrar(id) { await hacer(() => DEL('/api/festivos/' + id), 'Quitado'); aFestivos(); }

// ---------- Vacaciones, permisos e incapacidades ----------
async function aIncid() {
  const L = await GET(`/api/incidencias?desde=${aAnio}-01-01&hasta=${aAnio}-12-31`);
  $('#asisc').innerHTML = `<div class="card"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px"><div class="row" style="gap:6px"><button class="btn sm" onclick="aAnio--;aIncid()">‹</button><b style="font-size:18px">${aAnio}</b><button class="btn sm" onclick="aAnio++;aIncid()">›</button></div><button class="btn pri" onclick="incModal()">Agregar vacaciones o permiso</button></div>
    <div class="tw"><table><thead><tr><th>Empleado</th><th>Tipo</th><th>Del</th><th>Al</th><th class="n">Días</th><th>Nota</th><th></th></tr></thead><tbody>
    ${L.map((i) => `<tr><td>${esc(i.nombre)}</td><td>${TIPO_INC[i.tipo]}</td><td>${fd(i.desde)}</td><td>${fd(i.hasta)}</td><td class="n">${Math.round((aF(i.hasta) - aF(i.desde)) / 864e5) + 1}</td><td class="sub">${esc(i.nota || '')}</td><td><button class="btn sm bad" onclick="confirmar(this,()=>incBorrar(${i.id}))">Quitar</button></td></tr>`).join('') || '<tr><td colspan="7" class="empty">Sin registros.</td></tr>'}</tbody></table></div>
    <div class="sub" style="margin-top:6px">Vacaciones, permisos con goce, incapacidades y faltas justificadas no se descuentan. El permiso sin goce sí descuenta el día.</div></div>`;
}
function incModal() {
  modal('Vacaciones, permiso o incapacidad', `<div class="f"><label class="l">Empleado${selEmp('inE', '')}</label><label class="l">Tipo<select id="inT">${Object.entries(TIPO_INC).map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select></label>
    <label class="l">Del<input type="date" id="inD" value="${hoyISO()}"></label><label class="l">Al<input type="date" id="inH" value="${hoyISO()}"></label></div><label class="l">Nota<input id="inN" placeholder="Ej. vacaciones 2026, folio de incapacidad IMSS"></label>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="incOk()">Guardar</button>`);
}
async function incOk() { await hacer(() => POST('/api/incidencias', { empleado_id: val('inE'), tipo: val('inT'), desde: val('inD'), hasta: val('inH'), nota: val('inN') }), 'Guardado'); cerrar(); aIncid(); }
async function incBorrar(id) { await hacer(() => DEL('/api/incidencias/' + id), 'Quitado'); aIncid(); }

// ---------- Reglas de retardos y descuentos ----------
function aReglas() {
  $('#asisc').innerHTML = `<div class="card" style="max-width:760px;margin-bottom:16px"><h2>Cómo checan los empleados</h2>
    <div class="seg" id="rgMet">${[['ambos', 'Huella o NIP (las dos)'], ['huella', 'Solo huella'], ['nip', 'Solo número y NIP']].map(([k, n]) => `<label><input type="radio" name="rgMet" value="${k}" ${(CFG.asis_metodo || 'ambos') === k ? 'checked' : ''}>${n}</label>`).join('')}</div>
    <p class="sub" style="margin-bottom:0">Con "Solo huella" no se puede checar con NIP (solo el administrador agrega registros manuales). Con "Solo número y NIP" el lector no se usa.</p></div>
    <div class="card" style="max-width:760px"><h2>Retardos y descuentos</h2>
    <div class="f"><label class="l">Tolerancia (minutos)<input id="rgT" type="number" min="0" value="${esc(CFG.asis_tolerancia ?? '10')}"></label>
      <label class="l">Descuento por retardo<select id="rgM"><option value="fijo">Monto fijo por retardo</option><option value="minutos">Proporcional a los minutos tarde</option><option value="ninguno">No descontar retardos</option></select></label>
      <label class="l">Monto por retardo (si es fijo)<input id="rgA" type="number" min="0" step="0.01" value="${esc(CFG.asis_desc_monto ?? '50')}"></label>
      <label class="l">Cada cuántos retardos = 1 falta (0 = no)<input id="rgN" type="number" min="0" value="${esc(CFG.asis_retardos_falta ?? '3')}"></label>
      <label class="l">Trabajar en festivo: pago extra de<select id="rgF"><option value="0">Nada extra</option><option value="1">1 día extra (doble)</option><option value="2">2 días extra (triple, como marca la ley)</option></select></label></div>
    <label class="row" style="font-weight:600;margin-top:10px"><input type="checkbox" id="rgD" ${CFG.asis_desc_doble === '1' ? 'checked' : ''}> Descuento DOBLE por retardo (cada retardo se descuenta dos veces)</label>
    <label class="row" style="font-weight:600;margin-top:6px"><input type="checkbox" id="rgFa" ${CFG.asis_falta_desc !== '0' ? 'checked' : ''}> Descontar el día completo por cada falta</label>
    <div class="aviso" style="margin-top:12px">Ejemplo con estas reglas: llega 20 minutos tarde con tolerancia de 10 → retardo. El sueldo diario se calcula con el sueldo y cada cuánto se le paga (semanal ÷ 7, quincenal ÷ 15, mensual ÷ 30).</div>
    <div style="margin-top:12px"><button class="btn pri" onclick="reglasOk()">Guardar</button></div></div>`;
  $('#rgM').value = CFG.asis_desc_modo || 'fijo'; $('#rgF').value = CFG.asis_festivo_pago || '2';
}
async function reglasOk() {
  await hacer(() => PUT('/api/config', { asis_metodo: document.querySelector('input[name=rgMet]:checked')?.value || 'ambos', asis_tolerancia: String(num('rgT')), asis_desc_modo: val('rgM'), asis_desc_monto: String(num('rgA')), asis_retardos_falta: String(num('rgN')), asis_festivo_pago: val('rgF'), asis_desc_doble: $('#rgD').checked ? '1' : '0', asis_falta_desc: $('#rgFa').checked ? '1' : '0' }), 'Reglas guardadas');
  CFG = await GET('/api/config');
}

// ---------- Nómina: traer descuentos y festivos de asistencia ----------
{
  const _nom = nominaModal;
  nominaModal = async function () {
    await _nom();
    if (!$('#nmPer')) return;
    const fin = hoyISO(), ini = new Date(); ini.setDate(ini.getDate() - 6);
    $('#nmPer').closest('.f').insertAdjacentHTML('afterend', `<div class="row" style="gap:8px;align-items:flex-end;flex-wrap:wrap;margin:6px 0"><label class="l">Asistencia del<input type="date" id="nmD" value="${ini.toISOString().slice(0, 10)}" onchange="asisANomina()"></label><label class="l">al<input type="date" id="nmH" value="${fin}" onchange="asisANomina()"></label><button class="btn" onclick="asisANomina()">Volver a calcular descuentos</button><span id="nmAs" class="sub"></span></div>`);
    // 1.8: los descuentos por retardos y faltas del checador se traen solos al abrir la nómina
    asisANomina();
  };
}
async function asisANomina() {
  const R = await hacer(() => GET(`/api/nomina/asistencia?desde=${val('nmD')}&hasta=${val('nmH')}`));
  let n = 0;
  for (const r of R) {
    const de = $(`#nm_de_${r.empleado_id}`), fe = $(`#nm_fe_${r.empleado_id}`), as = $(`#nm_as_${r.empleado_id}`); if (!de) continue;
    const x = r.resumen, fal = x.faltas + x.faltas_retardos;
    de.value = x.total_descuento ? x.total_descuento.toFixed(2) : ''; fe.value = x.pago_festivos ? x.pago_festivos.toFixed(2) : '';
    Object.assign(de.dataset, { ret: x.retardos, fal, dr: x.desc_retardos, df: x.desc_faltas });
    if (as) as.textContent = !r.con_horario ? 'Sin horario' : [x.retardos ? `${x.retardos} retardo${x.retardos > 1 ? 's' : ''} ${money(x.desc_retardos)}` : '', fal ? `${fal} falta${fal > 1 ? 's' : ''} ${money(x.desc_faltas)}` : ''].filter(Boolean).join(' · ') || 'Sin retardos ni faltas';
    if (x.total_descuento || x.pago_festivos) n++;
  }
  nominaCalc(); $('#nmAs').textContent = `Del checador: ${n} empleado(s) con descuentos por retardos/faltas o pago de festivos (ya se restaron).`;
}

// ---------- Cierre de mes ----------
let cMes = (() => { const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - 1); return d.toISOString().slice(0, 7); })();
const mesTxt = (m) => { const [y, mm] = m.split('-').map(Number); return new Date(y, mm - 1, 1).toLocaleDateString('es-MX', { month: 'long', year: 'numeric' }); };
const varPct = (a, b) => (b ? ((a - b) / Math.abs(b)) * 100 : a ? 100 : 0);
const flecha = (a, b, inv) => { const v = varPct(a, b); if (!b && !a) return ''; const bueno = inv ? v <= 0 : v >= 0; return `<span style="color:${bueno ? 'var(--libre)' : 'var(--ocup)'};font-weight:700">${v >= 0 ? '▲' : '▼'} ${Math.abs(v).toFixed(1)}%</span>`; };
async function vCierre(actual) {
  const [C, lista] = await Promise.all([GET(`/api/cierre?mes=${cMes}${actual ? '&actual=1' : ''}`), GET('/api/cierres')]); vCierre.C = C;
  const T = C.totales, A = C.anterior, O = C.ocupacion, R = C.rentas, fin = C.hasta < hoyISO();
  const kv = (o) => Object.entries(o).map(([k, v]) => `<span>${k}</span><b>${v}</b>`).join('');
  const rr = (n, x) => `<tr><td>${n}</td><td class="n">${x.n}</td><td class="n">${x.unidades}</td><td class="n">${money(x.generado)}</td><td class="n">${money(x.cobrado)}</td></tr>`;
  const cortas = R.rato.cobrado + R.noche.cobrado + R.dia.cobrado + C.hospedaje_sin_tipo, largas = R.semana.cobrado + R.mes.cobrado;
  $('#main').innerHTML = cab('Cierre de mes', mesTxt(cMes).replace(/^\w/, (x) => x.toUpperCase()) + (C.cerrado ? ` · CERRADO el ${fdt(C.cerrado.fecha)} por ${esc(C.cerrado.usuario || '')}` : fin ? ' · listo para cerrar' : ' · mes en curso (vista previa)'),
    `<input type="month" id="cmM" value="${cMes}" style="width:auto" onchange="cMes=this.value;vCierre()"><button class="btn" onclick="pdfCierre()">PDF detallado</button><button class="btn" onclick="excelCierre()">Excel detallado</button>${C.cerrado ? '<button class="btn" onclick="vCierre(true)">Ver con datos actuales</button>' : ''}${!C.cerrado && fin && puede('config') ? '<button class="btn pri" onclick="cerrarMes()">Cerrar el mes</button>' : ''}`)
  + `<div class="kpis"><div class="kpi"><span>Ingresos</span><b>${money(T.ingresos)}</b><div class="sub">${flecha(T.ingresos, A.ingresos)} vs ${mesTxt(A.mes)}</div></div><div class="kpi"><span>Gastos</span><b style="color:var(--ocup)">${money(T.gastos)}</b><div class="sub">${flecha(T.gastos, A.gastos, true)} vs mes anterior</div></div>
      <div class="kpi"><span>Utilidad</span><b style="color:${T.utilidad >= 0 ? 'var(--libre)' : 'var(--ocup)'}">${money(T.utilidad)}</b><div class="sub">margen ${T.ingresos ? (T.utilidad / T.ingresos * 100).toFixed(1) : 0}% · ${flecha(T.utilidad, A.utilidad)}</div></div>
      <div class="kpi"><span>Ocupación</span><b>${O.porcentaje}%</b><div class="sub">${O.noches} de ${O.capacidad} noches · antes ${A.ocupacion}%</div></div></div>
    <div class="cols"><div class="card"><h2>Ingresos por concepto</h2><div class="kv">${kv({ 'Estancias cortas (rato, noche, día)': money(cortas), 'Estancias largas (semana, mes)': money(largas), 'Venta en tienda': money(T.tienda), 'Visitas': money(T.visitas), 'Multas, intereses y cuotas': money(T.otros || 0), 'TOTAL INGRESOS': money(T.ingresos) })}</div></div>
      <div class="card"><h2>Por forma de pago</h2><div class="kv">${kv({ Efectivo: money(C.porMetodo.efectivo), [`Dólares US$${C.usd.toFixed(2)} (${money(C.usd_pesos)})`]: money(C.porMetodo.dolares), 'Cambio dado en pesos': money(C.cambio), Tarjeta: money(C.porMetodo.tarjeta), Transferencia: money(C.porMetodo.transferencia) })}</div></div>
      <div class="card"><h2>Ocupación</h2><div class="kv">${kv({ Habitaciones: O.habitaciones, 'Noches ocupadas': `${O.noches} de ${O.capacidad}`, 'Ingreso promedio por noche': money(O.promedio_noche), 'Ingreso por habitación disponible': money(O.revpar), 'Entradas / salidas': `${O.entradas} / ${O.salidas}`, 'Hospedados al cierre': O.activas_al_cierre, 'Por cobrar a huéspedes': money(C.por_cobrar) })}</div></div></div>
    <div class="card" style="margin-top:16px"><h2>Rentas por tipo</h2><div class="tw"><table><thead><tr><th></th><th class="n">Rentas</th><th class="n">Unidades</th><th class="n">Generado</th><th class="n">Cobrado</th></tr></thead><tbody>${rr(`Ratos (${horasRato()} h)`, R.rato)}${rr('Noches', R.noche)}${rr('Días', R.dia)}${rr('Semanas', R.semana)}${rr('Meses', R.mes)}</tbody></table></div></div>
    <div class="cols" style="margin-top:16px"><div class="card"><h2>Tienda</h2><div class="kv">${kv({ [`Ventas cobradas (${C.tienda.ventas.n})`]: money(C.tienda.ventas.t), [`Cargado a habitación (${C.tienda.cargadas.n})`]: money(C.tienda.cargadas.t), 'Costo de lo vendido': money(C.tienda.costo), 'Utilidad de tienda': money(C.tienda.utilidad), [`Canceladas (${C.tienda.canceladas.n})`]: money(C.tienda.canceladas.t), 'Inventario a costo': money(C.tienda.inventario) })}</div></div>
      <div class="card"><h2>Depósitos y visitas</h2><div class="kv">${kv({ [`Depósitos recibidos (${C.depositos.recibidos.n})`]: money(C.depositos.recibidos.t), [`Devueltos (${C.depositos.devueltos.n})`]: money(C.depositos.devueltos.t), [`Retenidos (${C.depositos.retenidos.n})`]: money(C.depositos.retenidos.t), 'En resguardo al cierre': money(C.depositos.resguardo), 'Visitantes registrados': C.visitas.registradas, [`Visitas cobradas (${C.visitas.cobradas})`]: money(C.visitas.total) })}</div></div>
      <div class="card"><h2>Caja</h2><div class="kv">${kv({ Turnos: C.caja.turnos.length, 'Ingresos a caja': money(C.caja.ingresos), 'Egresos de caja': money(C.caja.egresos), 'Diferencias en pesos': money(C.caja.diferencia_mxn), 'Diferencias en dólares': 'US$' + C.caja.diferencia_usd.toFixed(2) })}</div></div></div>
    <div class="cols" style="margin-top:16px"><div class="card"><h2>Gastos por clasificación</h2><div class="kv">${Object.entries(C.gastos.porGrupo).sort((a, b) => b[1].total - a[1].total).map(([k, x]) => `<span><b>${esc(k)}</b> (${x.n})</span><b>${money(x.total)}</b>${Object.entries(x.conceptos).sort((a, b) => b[1].total - a[1].total).map(([c, v]) => `<span class="sub" style="padding-left:12px">${esc(c)} (${v.n})</span><span class="sub" style="text-align:right">${money(v.total)}</span>`).join('')}`).join('') || '<span>Sin gastos</span><span></span>'}</div></div>
      <div class="card"><h2>Nómina y personal</h2><div class="kv">${C.nomina.map((x) => `<span><b>${esc(x.nombre)}</b></span><b>${money(x.total)}</b>${Object.entries(x.conceptos).map(([c, v]) => `<span class="sub" style="padding-left:12px">${esc(c)}</span><span class="sub" style="text-align:right">${money(v)}</span>`).join('')}`).join('') || '<span>Sin pagos a empleados</span><span></span>'}</div></div>
      <div class="card"><h2>Proveedores</h2><div class="kv">${C.gastos.porProveedor.map((x) => `<span>${esc(x.nombre)} (${x.n})</span><b>${money(x.total)}</b>`).join('') || '<span>Sin pagos a proveedores</span><span></span>'}</div></div></div>
    <div class="card" style="margin-top:16px"><h2>Asistencia del mes</h2><div class="tw"><table><thead><tr><th>Empleado</th><th class="n">Días trab.</th><th class="n">Retardos</th><th class="n">Faltas</th><th class="n">Festivos trab.</th><th class="n">Descuentos</th></tr></thead><tbody>${C.asistencia.map((x) => `<tr><td>${esc(x.nombre)}</td><td class="n">${x.trabajados}</td><td class="n">${x.retardos}</td><td class="n">${x.faltas + x.faltas_retardos}</td><td class="n">${x.festivos_trabajados}</td><td class="n">${money(x.total_descuento)}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">Sin empleados.</td></tr>'}</tbody></table></div></div>
    ${typeof cierreExtrasHTML === 'function' && C.extra ? cierreExtrasHTML(C) : ''}
    <div class="card" style="margin-top:16px"><h2>Día por día</h2><div class="tw" style="max-height:420px"><table><thead><tr><th>Día</th><th class="n">Ocupadas</th><th class="n">Entradas</th><th class="n">Hospedaje</th><th class="n">Tienda</th><th class="n">Visitas</th><th class="n">Total</th><th class="n">Gastos</th></tr></thead><tbody>${C.porDia.map((d) => `<tr><td>${DIAS[aF(d.fecha).getDay()].slice(0, 3)} ${fd(d.fecha)}</td><td class="n">${d.ocupadas}</td><td class="n">${d.entradas}</td><td class="n">${money(d.hospedaje)}</td><td class="n">${money(d.tienda)}</td><td class="n">${money(d.visitas)}</td><td class="n"><b>${money(d.total)}</b></td><td class="n">${money(d.gastos)}</td></tr>`).join('')}</tbody></table></div></div>
    ${lista.length ? `<div class="card" style="margin-top:16px"><h2>Meses cerrados</h2><div class="kv">${lista.map((x) => `<span class="enlace" onclick="cMes='${x.mes}';vCierre()">${mesTxt(x.mes)}</span><span>cerrado ${fdt(x.fecha)} · ${esc(x.usuario || '')}</span>`).join('')}</div></div>` : ''}`;
}
async function cerrarMes() {
  modal(`Cerrar ${mesTxt(cMes)}`, `<p style="margin:0">Se guarda una copia de todos los números del mes tal como están hoy. Después podrá consultarla, imprimirla o bajarla en Excel igual.</p><label class="l" style="margin-top:10px">Notas del cierre<input id="cmNo" placeholder="Opcional"></label>`,
    `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="cerrarMesOk()">Cerrar el mes</button>`);
}
async function cerrarMesOk() { await hacer(() => POST('/api/cierre', { mes: cMes, notas: val('cmNo') }), 'Mes cerrado'); cerrar(); vCierre(); }
function pdfCierre() {
  const C = vCierre.C, T = C.totales, A = C.anterior, O = C.ocupacion, R = C.rentas;
  const cortas = R.rato.cobrado + R.noche.cobrado + R.dia.cobrado + C.hospedaje_sin_tipo, largas = R.semana.cobrado + R.mes.cobrado;
  const fila = (k, v, b) => `<tr${b ? ' class="t"' : ''}><td>${k}</td><td class="n">${v}</td></tr>`;
  const comp = (n, a, b) => `<tr><td>${n}</td><td class="n">${money(a)}</td><td class="n">${money(b)}</td><td class="n">${varPct(a, b).toFixed(1)}%</td></tr>`;
  const rr = (n, x) => `<tr><td>${n}</td><td class="n">${x.n}</td><td class="n">${x.unidades}</td><td class="n">${money(x.generado)}</td><td class="n">${money(x.cobrado)}</td></tr>`;
  imprimirDoc(`<div class="rep"><div class="rep-enc"><b>${esc(CFG.hotel_nombre)}</b><span>CIERRE DE MES · ${mesTxt(C.mes).toUpperCase()}</span><span>Del ${fd(C.desde)} al ${fd(C.hasta)}${C.cerrado ? ` · cerrado el ${fdt(C.cerrado.fecha)} por ${esc(C.cerrado.usuario || '')}` : ' · vista previa'}</span></div>
    <div class="rep-tot"><div><small>Ingresos</small><b>${money(T.ingresos)}</b></div><div><small>Gastos</small><b>${money(T.gastos)}</b></div><div><small>Utilidad</small><b>${money(T.utilidad)}</b></div><div><small>Ocupación</small><b>${O.porcentaje}%</b></div></div>
    <div class="rep-2"><div><h3>Estado de resultados</h3><table><tbody>${fila('Estancias cortas (rato, noche, día)', money(cortas))}${fila('Estancias largas (semana, mes)', money(largas))}${fila('Venta en tienda', money(T.tienda))}${fila('Visitas', money(T.visitas))}${fila('Multas, intereses y cuotas', money(T.otros || 0))}${fila('TOTAL INGRESOS', money(T.ingresos), 1)}
      ${Object.entries(C.gastos.porGrupo).sort((a, b) => b[1].total - a[1].total).map(([k, x]) => fila('(−) ' + esc(k), money(x.total))).join('')}${fila('TOTAL GASTOS', money(T.gastos), 1)}${fila('UTILIDAD DEL MES', money(T.utilidad), 1)}${fila('Margen', (T.ingresos ? (T.utilidad / T.ingresos * 100).toFixed(1) : '0') + '%')}</tbody></table></div>
      <div><h3>Comparativo con ${mesTxt(A.mes)}</h3><table><thead><tr><th></th><th class="n">Este mes</th><th class="n">Anterior</th><th class="n">Cambio</th></tr></thead><tbody>${comp('Hospedaje', T.hospedaje, A.hospedaje)}${comp('Tienda', T.tienda, A.tienda)}${comp('Visitas', T.visitas, A.visitas)}${comp('Ingresos', T.ingresos, A.ingresos)}${comp('Gastos', T.gastos, A.gastos)}${comp('Utilidad', T.utilidad, A.utilidad)}
        <tr><td>Ocupación</td><td class="n">${O.porcentaje}%</td><td class="n">${A.ocupacion}%</td><td class="n">${(O.porcentaje - A.ocupacion).toFixed(1)} pts</td></tr></tbody></table>
      <h3>Ocupación</h3><table><tbody>${fila('Habitaciones', O.habitaciones)}${fila('Noches ocupadas', `${O.noches} de ${O.capacidad}`)}${fila('Ingreso promedio por noche ocupada', money(O.promedio_noche))}${fila('Ingreso por habitación disponible', money(O.revpar))}${fila('Entradas / salidas', `${O.entradas} / ${O.salidas}`)}${fila('Hospedados al cierre', O.activas_al_cierre)}${fila('Por cobrar a huéspedes', money(C.por_cobrar))}</tbody></table></div></div>
    <h3>Rentas por tipo</h3><table><thead><tr><th></th><th class="n">Rentas</th><th class="n">Unidades</th><th class="n">Generado</th><th class="n">Cobrado</th></tr></thead><tbody>${rr(`Ratos (${horasRato()} h)`, R.rato)}${rr('Noches', R.noche)}${rr('Días', R.dia)}<tr class="t"><td>Estancias cortas</td><td></td><td></td><td></td><td class="n">${money(cortas)}</td></tr>${rr('Semanas', R.semana)}${rr('Meses', R.mes)}<tr class="t"><td>Estancias largas</td><td></td><td></td><td></td><td class="n">${money(largas)}</td></tr></tbody></table>
    <div class="rep-2"><div><h3>Formas de pago</h3><table><tbody>${fila('Efectivo', money(C.porMetodo.efectivo))}${fila(`Dólares US$${C.usd.toFixed(2)} = ${money(C.usd_pesos)}`, money(C.porMetodo.dolares))}${fila('Cambio entregado en pesos', '-' + money(C.cambio))}${fila('Tarjeta', money(C.porMetodo.tarjeta))}${fila('Transferencia', money(C.porMetodo.transferencia))}</tbody></table>
      <h3>Cobrado por usuario</h3><table><tbody>${C.porUsuario.map((x) => fila(esc(x.nombre), money(x.total))).join('')}</tbody></table></div>
      <div><h3>Depósitos y visitas</h3><table><tbody>${fila(`Depósitos recibidos (${C.depositos.recibidos.n})`, money(C.depositos.recibidos.t))}${fila(`Devueltos (${C.depositos.devueltos.n})`, money(C.depositos.devueltos.t))}${fila(`Retenidos por daños (${C.depositos.retenidos.n})`, money(C.depositos.retenidos.t))}${fila('En resguardo al cierre', money(C.depositos.resguardo))}${fila('Visitantes registrados', C.visitas.registradas)}${fila(`Visitas cobradas (${C.visitas.cobradas})`, money(C.visitas.total))}</tbody></table>
      <h3>Caja y mantenimiento</h3><table><tbody>${fila('Turnos de caja', C.caja.turnos.length)}${fila('Ingresos a caja', money(C.caja.ingresos))}${fila('Egresos de caja', money(C.caja.egresos))}${fila('Diferencias de caja (pesos)', money(C.caja.diferencia_mxn))}${fila('Reportes de mantenimiento', `${C.mantenimiento.reportados} nuevos · ${C.mantenimiento.terminados} terminados · ${C.mantenimiento.abiertos} abiertos`)}${fila('Costo de mantenimiento', money(C.mantenimiento.costo))}</tbody></table></div></div>
    <h3>Tienda</h3><table><thead><tr><th>Producto</th><th class="n">Cantidad</th><th class="n">Venta</th><th class="n">Costo</th><th class="n">Utilidad</th></tr></thead><tbody>${C.tienda.productos.map((x) => `<tr><td>${esc(x.descripcion)}</td><td class="n">${x.cantidad}</td><td class="n">${money(x.importe)}</td><td class="n">${money(x.costo)}</td><td class="n">${money(x.utilidad)}</td></tr>`).join('')}<tr class="t"><td>Total</td><td></td><td class="n">${money(C.tienda.venta)}</td><td class="n">${money(C.tienda.costo)}</td><td class="n">${money(C.tienda.utilidad)}</td></tr></tbody></table>
    <h3>Gastos por clasificación y concepto</h3><table><thead><tr><th>Clasificación / concepto</th><th class="n">Cuántos</th><th class="n">Importe</th><th class="n">% del gasto</th></tr></thead><tbody>${Object.entries(C.gastos.porGrupo).sort((a, b) => b[1].total - a[1].total).map(([k, x]) => `<tr class="t"><td>${esc(k)}</td><td class="n">${x.n}</td><td class="n">${money(x.total)}</td><td class="n">${T.gastos ? (x.total / T.gastos * 100).toFixed(1) : 0}%</td></tr>${Object.entries(x.conceptos).sort((a, b) => b[1].total - a[1].total).map(([c, v]) => `<tr><td style="padding-left:14px">${esc(c)}</td><td class="n">${v.n}</td><td class="n">${money(v.total)}</td><td></td></tr>`).join('')}`).join('')}<tr class="t"><td>TOTAL</td><td class="n">${C.gastos.n}</td><td class="n">${money(T.gastos)}</td><td></td></tr></tbody></table>
    <div class="rep-2"><div><h3>Nómina por empleado</h3><table><tbody>${C.nomina.map((x) => `<tr class="t"><td>${esc(x.nombre)}</td><td class="n">${money(x.total)}</td></tr>${Object.entries(x.conceptos).map(([c, v]) => `<tr><td style="padding-left:14px">${esc(c)}</td><td class="n">${money(v)}</td></tr>`).join('')}`).join('') || '<tr><td>Sin pagos</td><td></td></tr>'}</tbody></table></div>
      <div><h3>Pagos a proveedores</h3><table><tbody>${C.gastos.porProveedor.map((x) => fila(`${esc(x.nombre)} (${x.n})`, money(x.total))).join('') || '<tr><td>Sin pagos</td><td></td></tr>'}</tbody></table>
      <h3>Gastos fijos pagados</h3><table><tbody>${C.gastos.fijos.map((x) => fila(esc(x.concepto), money(x.monto))).join('') || '<tr><td>Ninguno</td><td></td></tr>'}</tbody></table></div></div>
    <h3>Asistencia</h3><table><thead><tr><th>Empleado</th><th class="n">Días trab.</th><th class="n">Retardos</th><th class="n">Min. tarde</th><th class="n">Faltas</th><th class="n">Por retardos</th><th class="n">Festivos trab.</th><th class="n">Descuentos</th></tr></thead><tbody>${C.asistencia.map((x) => `<tr><td>${esc(x.nombre)}</td><td class="n">${x.trabajados}</td><td class="n">${x.retardos}</td><td class="n">${x.min_tarde}</td><td class="n">${x.faltas}</td><td class="n">${x.faltas_retardos}</td><td class="n">${x.festivos_trabajados}</td><td class="n">${money(x.total_descuento)}</td></tr>`).join('')}</tbody></table>
    <h3>Ingresos por habitación</h3><table><thead><tr><th>Habitación</th><th class="n">Rentas</th><th class="n">Noches ocupada</th><th class="n">Cobrado</th></tr></thead><tbody>${C.porHab.map((x) => `<tr><td>${esc(x.numero)} ${esc(x.nombre || '')}</td><td class="n">${x.rentas}</td><td class="n">${x.noches}</td><td class="n">${money(x.cobrado)}</td></tr>`).join('')}</tbody></table>
    <h3>Día por día</h3><table><thead><tr><th>Día</th><th class="n">Ocup.</th><th class="n">Hospedaje</th><th class="n">Tienda</th><th class="n">Visitas</th><th class="n">Efectivo</th><th class="n">Tarjeta</th><th class="n">Transf.</th><th class="n">Total</th><th class="n">Gastos</th></tr></thead><tbody>${C.porDia.map((d) => `<tr><td>${DIAS[aF(d.fecha).getDay()].slice(0, 3)} ${aF(d.fecha).getDate()}</td><td class="n">${d.ocupadas}</td><td class="n">${money(d.hospedaje)}</td><td class="n">${money(d.tienda)}</td><td class="n">${money(d.visitas)}</td><td class="n">${money(d.efectivo + d.dolares)}</td><td class="n">${money(d.tarjeta)}</td><td class="n">${money(d.transferencia)}</td><td class="n"><b>${money(d.total)}</b></td><td class="n">${money(d.gastos)}</td></tr>`).join('')}</tbody></table>
    <h3>Turnos de caja</h3><table><thead><tr><th>Turno</th><th>Usuario</th><th>Abrió</th><th>Cerró</th><th class="n">Cobrado</th><th class="n">Dif. pesos</th></tr></thead><tbody>${C.caja.turnos.map((t) => `<tr><td>${t.id}</td><td>${esc(t.usuario || '')}</td><td>${fdt(t.apertura)}</td><td>${t.cierre ? fdt(t.cierre) : 'Abierto'}</td><td class="n">${money(t.cobrado)}</td><td class="n">${t.dif ? money(t.dif.mxn) : '—'}</td></tr>`).join('')}</tbody></table>
    ${C.cerrado?.notas ? `<h3>Notas del cierre</h3><p>${esc(C.cerrado.notas)}</p>` : ''}
    ${typeof pdfExtras === 'function' && C.extra ? pdfExtras(C) : ''}
    <div class="rep-firmas"><div><span></span>Elaboró</div><div><span></span>Revisó / Autorizó</div></div>
    <div class="rep-pie">Generado ${fdt(C.generado)} · impreso ${new Date().toLocaleString('es-MX')}</div></div>`, 'carta', 'Cierre de ' + mesTxt(C.mes));
}
function excelCierre() {
  const C = vCierre.C, T = C.totales, A = C.anterior, O = C.ocupacion, R = C.rentas;
  const cortas = R.rato.cobrado + R.noche.cobrado + R.dia.cobrado + C.hospedaje_sin_tipo, largas = R.semana.cobrado + R.mes.cobrado;
  const res = [[{ v: `${CFG.hotel_nombre} · Cierre de ${mesTxt(C.mes)}`, s: 't' }], ['Periodo', `${fd(C.desde)} al ${fd(C.hasta)}`], ['Estado', C.cerrado ? `Cerrado el ${fdt(C.cerrado.fecha)} por ${C.cerrado.usuario || ''}` : 'Vista previa'], [],
    [S_('ESTADO DE RESULTADOS'), S_('')], ['Estancias cortas (rato, noche, día)', M_(cortas)], ['Estancias largas (semana, mes)', M_(largas)], ['Venta en tienda', M_(T.tienda)], ['Visitas', M_(T.visitas)], ['Multas, intereses y cuotas', M_(T.otros || 0)], [B_('TOTAL INGRESOS'), BM_(T.ingresos)],
    ...Object.entries(C.gastos.porGrupo).sort((a, b) => b[1].total - a[1].total).map(([k, x]) => ['(−) ' + k, M_(x.total)]), [B_('TOTAL GASTOS'), BM_(T.gastos)], [B_('UTILIDAD'), BM_(T.utilidad)], ['Margen %', T.ingresos ? Number((T.utilidad / T.ingresos * 100).toFixed(2)) : 0], [],
    [S_('COMPARATIVO'), S_(''), S_(''), S_('')], H_('Concepto', 'Este mes', mesTxt(A.mes), 'Cambio %'), ...[['Hospedaje', T.hospedaje, A.hospedaje], ['Tienda', T.tienda, A.tienda], ['Visitas', T.visitas, A.visitas], ['Ingresos', T.ingresos, A.ingresos], ['Gastos', T.gastos, A.gastos], ['Utilidad', T.utilidad, A.utilidad]].map(([n, a, b]) => [n, M_(a), M_(b), Number(varPct(a, b).toFixed(1))]),
    ['Ocupación %', O.porcentaje, A.ocupacion, Number((O.porcentaje - A.ocupacion).toFixed(1))], [],
    [S_('OCUPACIÓN'), S_('')], ['Habitaciones', O.habitaciones], ['Noches disponibles', O.capacidad], ['Noches ocupadas', O.noches], ['Ocupación %', O.porcentaje], ['Ingreso promedio por noche', M_(O.promedio_noche)], ['Ingreso por habitación disponible', M_(O.revpar)], ['Entradas', O.entradas], ['Salidas', O.salidas], ['Por cobrar a huéspedes', M_(C.por_cobrar)], [],
    [S_('FORMAS DE PAGO'), S_('')], ['Efectivo', M_(C.porMetodo.efectivo)], ['Dólares (neto en pesos)', M_(C.porMetodo.dolares)], ['Dólares recibidos US$', U_(C.usd)], ['Dólares en pesos', M_(C.usd_pesos)], ['Cambio entregado en pesos', M_(C.cambio)], ['Tarjeta', M_(C.porMetodo.tarjeta)], ['Transferencia', M_(C.porMetodo.transferencia)], [],
    [S_('DEPÓSITOS, VISITAS, CAJA'), S_('')], ['Depósitos recibidos', M_(C.depositos.recibidos.t)], ['Depósitos devueltos', M_(C.depositos.devueltos.t)], ['Retenidos', M_(C.depositos.retenidos.t)], ['En resguardo al cierre', M_(C.depositos.resguardo)], ['Visitantes registrados', C.visitas.registradas], ['Visitas cobradas', C.visitas.cobradas], ['Turnos de caja', C.caja.turnos.length], ['Diferencias de caja (pesos)', M_(C.caja.diferencia_mxn)]];
  const ren = [H_('Tipo de renta', 'Rentas', 'Unidades', 'Generado', 'Cobrado'), ...[['Ratos', R.rato], ['Noches', R.noche], ['Días', R.dia], ['Semanas', R.semana], ['Meses', R.mes]].map(([n, x]) => [n, x.n, x.unidades, M_(x.generado), M_(x.cobrado)]), [B_('Estancias cortas'), '', '', '', BM_(cortas)], [B_('Estancias largas'), '', '', '', BM_(largas)]];
  const dia = [H_('Fecha', 'Día', 'Hab. ocupadas', 'Entradas', 'Hospedaje', 'Tienda', 'Visitas', 'Efectivo', 'Dólares', 'Tarjeta', 'Transferencia', 'Total cobrado', 'Gastos'), ...C.porDia.map((d) => [fd(d.fecha), DIAS[aF(d.fecha).getDay()], d.ocupadas, d.entradas, M_(d.hospedaje), M_(d.tienda), M_(d.visitas), M_(d.efectivo), M_(d.dolares), M_(d.tarjeta), M_(d.transferencia), BM_(d.total), M_(d.gastos)])];
  const hab = [H_('Habitación', 'Nombre', 'Rentas', 'Noches ocupada', 'Cobrado'), ...C.porHab.map((x) => [x.numero, x.nombre || '', x.rentas, x.noches, M_(x.cobrado)])];
  const tie = [H_('Producto', 'Cantidad', 'Venta', 'Costo', 'Utilidad'), ...C.tienda.productos.map((x) => [x.descripcion, x.cantidad, M_(x.importe), M_(x.costo), M_(x.utilidad)]), [B_('Total'), '', BM_(C.tienda.venta), BM_(C.tienda.costo), BM_(C.tienda.utilidad)], [], [B_('Entradas de mercancía'), '', '', '', ''], H_('Producto', 'Cantidad', 'Costo'), ...C.tienda.entradas.map((x) => [x.nombre, x.cantidad, M_(x.costo)]), [], ['Inventario a costo al cierre', '', M_(C.tienda.inventario)]];
  const gcl = [H_('Clasificación', 'Concepto', 'Cuántos', 'Importe', '% del gasto')];
  for (const [k, x] of Object.entries(C.gastos.porGrupo).sort((a, b) => b[1].total - a[1].total)) { gcl.push([B_(k), '', x.n, BM_(x.total), T.gastos ? Number((x.total / T.gastos * 100).toFixed(1)) : 0]); for (const [c, v] of Object.entries(x.conceptos).sort((a, b) => b[1].total - a[1].total)) gcl.push(['', c, v.n, M_(v.total), '']); }
  const gas = [H_('Folio', 'Fecha', 'Concepto', 'Clasificación', 'Tipo', 'Empleado', 'Proveedor', 'Factura / folio', 'Método', 'Monto', 'Recibió'), ...C.gastos.lista.map((g) => [g.folio, fdt(g.fecha), g.concepto, g.grupo || '', g.categoria || '', g.empleado || '', g.proveedor || '', g.factura || '', MET[g.metodo] || g.metodo, M_(g.monto), g.recibe || ''])];
  const nom = [H_('Empleado', 'Concepto', 'Importe')]; for (const x of C.nomina) { nom.push([B_(x.nombre), '', BM_(x.total)]); for (const [c, v] of Object.entries(x.conceptos)) nom.push(['', c, M_(v)]); }
  const prov = [H_('Proveedor', 'Pagos', 'Total'), ...C.gastos.porProveedor.map((x) => [x.nombre, x.n, M_(x.total)])];
  const asi = [H_('Empleado', 'Puesto', 'Días trabajados', 'Retardos', 'Minutos tarde', 'Faltas', 'Faltas por retardos', 'Festivos trabajados', 'Desc. retardos', 'Desc. faltas', 'Total descuento', 'Extra festivos'), ...C.asistencia.map((x) => [x.nombre, x.puesto || '', x.trabajados, x.retardos, x.min_tarde, x.faltas, x.faltas_retardos, x.festivos_trabajados, M_(x.desc_retardos), M_(x.desc_faltas), BM_(x.total_descuento), M_(x.pago_festivos)])];
  const caj = [H_('Turno', 'Usuario', 'Abrió', 'Cerró', 'Cobrado', 'Gastos de caja', 'Dif. pesos', 'Dif. dólares'), ...C.caja.turnos.map((t) => [t.id, t.usuario || '', fdt(t.apertura), t.cierre ? fdt(t.cierre) : 'Abierto', M_(t.cobrado), M_(t.gastos), t.dif ? M_(t.dif.mxn) : '', t.dif ? U_(t.dif.usd) : ''])];
  descargarArchivo(XLSX.libro([{ nombre: 'Resumen', filas: res }, { nombre: 'Rentas por tipo', filas: ren }, { nombre: 'Día por día', filas: dia }, { nombre: 'Por habitación', filas: hab }, { nombre: 'Tienda', filas: tie }, { nombre: 'Gastos por clasificación', filas: gcl }, { nombre: 'Gastos (lista)', filas: gas },
    { nombre: 'Nómina', filas: nom }, { nombre: 'Proveedores', filas: prov }, { nombre: 'Asistencia', filas: asi }, { nombre: 'Turnos de caja', filas: caj }, ...(typeof hojasExtras === 'function' && C.extra ? hojasExtras(C.extra) : [])]), `Cierre ${C.mes} - ${CFG.hotel_nombre}.xlsx`);
}
