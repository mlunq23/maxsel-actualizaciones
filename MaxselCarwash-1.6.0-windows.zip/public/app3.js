// Maxsel Hotel 1.2 — caja con turnos, dólares, impresión directa (corte y cajón) y permisos por usuario
'use strict';
let TURNO = null; // resumen del turno abierto del usuario

// ---------- Tipo de cambio y forma de pago en dólares ----------
const tcHoy = () => Number(TURNO?.turno?.tipo_cambio || YO?.turno?.tipo_cambio || CFG.tipo_cambio) || 18;
// Método de pago: se llena cuánto se recibe en pesos, dólares, tarjeta y/o transferencia (se suman)
function mixtoHTML(id, alCambiar) {
  const on = alCambiar || `usdHint('${id}')`;
  return `<div class="mixto" id="${id}_mx"><label>Efectivo (pesos)<input id="${id}_ef" type="number" min="0" step="0.01" placeholder="0.00" oninput="${on}"></label>
    <label>Dólares (US$)<input id="${id}_us" type="number" min="0" step="0.01" placeholder="0.00" oninput="${on}"></label>
    <label>Tarjeta<input id="${id}_ta" type="number" min="0" step="0.01" placeholder="0.00" oninput="${on}"></label>
    <label>Transferencia<input id="${id}_tr" type="number" min="0" step="0.01" placeholder="0.00" oninput="${on}"></label></div>`;
}
function sumaMixto(id) {
  const partes = { efectivo: num(id + '_ef'), usd: num(id + '_us'), tarjeta: num(id + '_ta'), transferencia: num(id + '_tr') };
  return { partes, total: partes.efectivo + partes.usd * tcHoy() + partes.tarjeta + partes.transferencia };
}
// Lo que se manda al servidor según la forma de pago elegida (sufijo para el depósito: '_deposito')
function pagoDe(id, suf = '') {
  const m = val(id);
  return { ['metodo' + suf]: m, ['usd' + suf]: m === 'dolares' ? val(id + '_u') : '', ['partes' + suf]: m === 'mixto' ? sumaMixto(id).partes : undefined };
}
function usdHint(id) {
  const sel = document.getElementById(id); if (!sel) return;
  const u = document.getElementById(id + '_u'), h = document.getElementById(id + '_h'), mx = document.getElementById(id + '_mx'), modo = sel.dataset.modo, dol = sel.value === 'dolares';
  if (u) u.hidden = !dol || modo === 'sinusd';
  if (!h) return;
  const ref = sel.dataset.monto, monto = ref === '' ? 0 : isNaN(Number(ref)) ? num(ref) : Number(ref), tc = tcHoy();
  if (sel.value === 'mixto') {
    const r = sumaMixto(id);
    h.textContent = !r.total ? (monto ? `Si no escribe nada se cobra ${money(monto)} en efectivo exacto · Dólar a $${tc}` : `Dólar a $${tc}`)
      : `Pagó con ${money(r.total)}${r.partes.usd ? ` (US$${r.partes.usd} = ${money(r.partes.usd * tc)})` : ''}${monto ? (r.total >= monto - 0.009 ? ` · Cambio: ${money(r.total - monto)}` : ` · Faltan ${money(monto - r.total)}`) : ''}`;
    return;
  }
  if (!dol) { h.textContent = ''; return; }
  if (modo === 'sinusd') { h.textContent = monto ? `Se entregan US$${(monto / tc).toFixed(2)} (TC ${tc})` : `Tipo de cambio ${tc}`; return; }
  const usd = num(id + '_u'), eq = usd * tc;
  h.textContent = usd ? `US$${usd} × ${tc} = ${money(eq)}${monto ? (eq >= monto - 0.009 ? ` · Cambio en pesos: ${money(eq - monto)}` : ` · Faltan ${money(monto - eq)}`) : ''}`
    : monto ? `Equivale a US$${(Math.ceil(monto / tc * 100) / 100).toFixed(2)} (TC ${tc}). Escriba cuántos dólares le entregan.` : `Tipo de cambio ${tc}`;
}
// Los avisos de "Pagó con / Cambio" se actualizan al escribir cualquier monto y al abrir cada ventana
const refrescarPagos = () => document.querySelectorAll('[data-modo]').forEach((e) => usdHint(e.id));
document.addEventListener('input', refrescarPagos);
{ const _modal = modal; modal = function (...a) { const r = _modal(...a); refrescarPagos(); return r; }; }
// Renglones del ticket: con cuánto pagaron y el cambio (sin desglosar formas de pago)
function lineasPago(p) {
  if (!p || !(p.total > 0)) return [];
  const usd = Number(p.usd) || 0, pesos = p.total - usd * (Number(p.tc) || 0);
  const con = usd ? `US$${usd.toFixed(2)}` + (pesos > 0.004 ? ' + ' + money(pesos) : '') : money(p.total);
  return [lin('Pagó con', con), lin('Cambio', money(p.cambio || 0))];
}

// ---------- Impresión: directa a la impresora de tickets (corta sola) o por el navegador ----------
const hayRaw = () => CFG.impresora_tipo && CFG.impresora_tipo !== 'ninguna';
// 1.5.2: cada marca de impresora tiene su ancho: letras por renglón (columnas) y puntos imprimibles (para imágenes)
const MODELOS_IMP = {
  epson80: { n: 'Epson TM-T88 / TM-T20 / TM-m30, Bixolon, Star (80 mm)', col: 42, pts: 512, mm: '80' },
  gen80: { n: 'Genérica 80 mm: Xprinter, 3nStar, EC Line, Ghia, Nextep, POS-80', col: 48, pts: 576, mm: '80' },
  gen58: { n: 'Cualquier impresora de 58 mm', col: 32, pts: 384, mm: '58' },
  otro: { n: 'Otra (escribo las letras por renglón)', col: 42, pts: 512, mm: '80' },
};
// Adivina el modelo por el nombre de la impresora en Windows
function modeloPorNombre(n) {
  const s = String(n || '').toUpperCase();
  if (/58|XP-?58|POS-?58|PT-?210|GOOJPRT|MTP/.test(s)) return 'gen58';
  if (/EPSON|TM-?T|TM-?M|TM-?U|BIXOLON|SRP|STAR|TSP|MCP|CITIZEN|CT-S/.test(s)) return 'epson80';
  if (/XPRINTER|XP-|3NSTAR|RPT|EC-?LINE|EC-?PM|GHIA|NEXTEP|POS-?80|80MM|THERMAL|RECEIPT|SAT|HPRT|ZJ-|DIG/.test(s)) return 'gen80';
  return '';
}
const modeloImp = () => MODELOS_IMP[CFG.impresora_modelo] ? CFG.impresora_modelo : CFG.ticket_ancho === '58' ? 'gen58' : 'epson80';
const W = () => {
  if (CFG.ticket_ancho === '58' && CFG.impresora_modelo !== 'otro') return 32;
  if (CFG.impresora_modelo === 'otro') return Math.max(24, Math.min(64, parseInt(CFG.ticket_columnas) || 42));
  return MODELOS_IMP[modeloImp()].col;
};
// Puntos imprimibles a lo ancho (múltiplo de 8): las imágenes nunca pasan de aquí
const PTS = () => {
  if (CFG.ticket_ancho === '58') return 384;
  if (CFG.impresora_modelo === 'otro') return Math.max(256, Math.min(576, Math.floor((parseInt(CFG.ticket_puntos) || Math.round(W() * 12.2)) / 8) * 8));
  return MODELOS_IMP[modeloImp()].pts;
};
function lin(a, b) { const w = W(); a = String(a); b = String(b); return a.slice(0, Math.max(1, w - b.length - 1)).padEnd(w - b.length) + b; }
function encabezado() { return [CFG.hotel_nombre.toUpperCase(), CFG.hotel_direccion, CFG.hotel_telefono ? 'Tel. ' + CFG.hotel_telefono : '', '-'.repeat(W())].filter(Boolean); }
function wrapT(s, w = W()) { const out = []; for (const p of String(s || '').split('\n')) { let l = ''; for (const x of p.split(/\s+/).filter(Boolean)) { if (!l) l = x; else if ((l + ' ' + x).length <= w) l += ' ' + x; else { out.push(l); l = x; } } out.push(l); } return out; }
function encOps() {
  const n = String(CFG.hotel_nombre || ''), ops = [['align', 'center'], ['bold', true]];
  if (n.length <= W() / 2) ops.push(['big', true], ['text', n], ['big', false]); else wrapT(n).forEach((l) => ops.push(['text', l]));
  ops.push(['bold', false]);
  [CFG.hotel_direccion, CFG.hotel_telefono ? 'Tel. ' + CFG.hotel_telefono : ''].filter(Boolean).forEach((x) => wrapT(x).forEach((l) => ops.push(['text', l])));
  ops.push(['align', 'left'], ['text', '-'.repeat(W())]);
  return ops;
}
// Ticket de texto: lo que va antes de la primera línea de guiones es el encabezado (centrado)
function imprimir(lineas, titulo) {
  const sep = lineas.findIndex((l) => /^-{8,}$/.test(l));
  const ops = sep > 0 ? [...encOps(), ...lineas.slice(sep + 1).map((l) => ['text', l])] : lineas.map((l) => ['text', l]);
  imprimirDoc(`<pre class="tk">${esc(lineas.join('\n'))}</pre>`, ancho(), titulo || 'Ticket', ops);
}
let OPS_ACTUAL = null;
async function imprimirDoc(html, formato, titulo, ops) {
  const t = $('#ticket'); t.innerHTML = `<div class="doc f-${formato}">${html}</div>`;
  let st = document.getElementById('pagina'); if (!st) { st = document.createElement('style'); st.id = 'pagina'; document.head.appendChild(st); }
  st.textContent = formato === 'carta' ? '@page{size:letter;margin:12mm}' : '@page{margin:2mm}';
  const directo = formato !== 'carta' && hayRaw() && ops;
  OPS_ACTUAL = directo ? ops : null;
  modal(titulo || 'Imprimir', `<div class="prev"><div class="doc f-${formato}">${html}</div></div>${formato === 'carta' ? '<div class="sub">Para guardar como PDF: en la ventana de impresión elija la impresora <b>"Guardar como PDF"</b> o <b>"Microsoft Print to PDF"</b>.</div>' : ''}<div id="impEstado" class="sub"></div>`,
    `<button class="btn" onclick="cerrar()">Cerrar</button><button class="btn pri" onclick="${directo ? 'mandarImpresora()' : 'window.print()'}">${formato === 'carta' ? 'Imprimir / Guardar PDF' : directo ? 'Reimprimir' : 'Imprimir'}</button>`, formato === 'carta');
  if (directo) mandarImpresora();
}
async function mandarImpresora() {
  const el = $('#impEstado'); if (el) el.textContent = 'Imprimiendo…';
  try {
    const ops = typeof OPS_ACTUAL === 'function' ? await OPS_ACTUAL() : OPS_ACTUAL;
    const r = await POST('/api/imprimir', { ops });
    if (el) el.innerHTML = r.ok ? '<span style="color:var(--libre)">Ticket impreso y cortado.</span>' : `<span style="color:var(--ocup)">No se imprimió: ${esc(r.error || 'sin impresora')}</span>`;
    if (!r.ok) toast('No se imprimió: ' + (r.error || 'revise la impresora'), true);
  } catch (e) { if (el) el.textContent = e.message; }
}
// Firma → imagen de 1 bit para la impresora térmica
async function firmaOps(dataURL, nombre, rol) {
  const ops = [['feed', 1]];
  if (dataURL) {
    try {
      const img = await new Promise((ok, mal) => { const i = new Image(); i.onload = () => ok(i); i.onerror = mal; i.src = dataURL; });
      const w = Math.floor(PTS() * 0.6 / 8) * 8, h = Math.min(110, Math.round(img.height * w / img.width)), c = document.createElement('canvas');
      c.width = w; c.height = h; const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); x.drawImage(img, 0, 0, w, h);
      const px = x.getImageData(0, 0, w, h).data, bpr = w / 8, bits = new Uint8Array(bpr * h);
      for (let y = 0; y < h; y++) for (let i = 0; i < w; i++) { const k = (y * w + i) * 4; if (px[k] + px[k + 1] + px[k + 2] < 380) bits[y * bpr + (i >> 3)] |= 0x80 >> (i & 7); }
      let bin = ''; bits.forEach((b) => (bin += String.fromCharCode(b)));
      ops.push(['align', 'center'], ['img', bpr, h, btoa(bin)]);
    } catch { ops.push(['feed', 3]); }
  } else ops.push(['feed', 3]);
  ops.push(['align', 'center'], ['text', '_'.repeat(Math.min(32, W()))], ['bold', true], ['text', rol], ['bold', false]);
  if (nombre) ops.push(['text', nombre]);
  return [...ops, ['align', 'left']];
}
function montoOps(monto) { return [['align', 'center'], ['bold', true], ['big', true], ['text', money(monto)], ['big', false], ['bold', false], ...wrapT(numeroALetras(monto)).map((l) => ['text', l]), ['align', 'left']]; }
async function opsGasto(g, copia) {
  return [...encOps(), ['align', 'center'], ['bold', true], ['text', 'RECIBO DE GASTO'], ['text', copia + (g.cancelado ? ' - CANCELADO' : '')], ['bold', false], ['align', 'left'],
    ['text', lin('Folio', g.folio)], ['text', lin('Fecha', fdt(g.fecha))], ...wrapT('Concepto: ' + g.concepto).map((l) => ['text', l]), ...wrapT('Clasificación: ' + (g.grupo || 'Otros') + ' · ' + (g.categoria || '')).map((l) => ['text', l]), ...(g.periodo ? [['text', lin('Periodo', g.periodo)]] : []), ...(g.factura ? [['text', lin('Factura / folio', g.factura)]] : []),
    ...(g.numero ? [['text', lin('Habitación', g.numero)]] : []), ['text', lin('Método de pago', MET[g.metodo] || '')], ['text', '-'.repeat(W())], ...montoOps(g.monto),
    ...(g.nota ? wrapT(g.nota).map((l) => ['text', l]) : []), ...(await firmaOps(g.firma_entrega, g.entrega, 'ENTREGA')), ...(await firmaOps(g.firma_recibe, g.recibe, 'RECIBE'))];
}
async function opsDeposito(d, copia) {
  const e = d.estancia, h = d.habitacion, T = { recibido: 'RECIBO DE DEPÓSITO', devuelto: 'DEVOLUCIÓN DE DEPÓSITO', retenido: 'RETENCIÓN DE DEPÓSITO' }[d.tipo];
  return [...encOps(), ['align', 'center'], ['bold', true], ['text', T], ['text', copia], ['bold', false], ['align', 'left'],
    ['text', lin('Folio', d.folio || d.id)], ['text', lin('Fecha', fdt(d.fecha))], ['text', lin(h.clase === 'departamento' ? 'Departamento' : 'Habitación', h.numero)], ['text', lin('Huésped', e.huesped)],
    ...(d.tipo === 'recibido' ? [] : d.metodo ? [['text', lin('Método de pago', MET[d.metodo] + (d.usd ? ` US$${d.usd}` : ''))]] : []), ['text', '-'.repeat(W())], ...montoOps(d.monto),
    ...(d.tipo === 'recibido' ? lineasPago({ total: d.recibido || d.monto, usd: d.usd, tc: d.tc, cambio: d.cambio_total ?? d.cambio }).map((l) => ['text', l]) : []),
    ...(d.tipo !== 'recibido' ? [['text', lin('Depósito recibido', money(e.deposito))], ...d.movimientos.filter((m) => m.tipo === 'retenido').flatMap((m) => wrapT(`Retenido (${m.motivo || ''}): ${money(m.monto)}`).map((l) => ['text', l])),
      ['text', lin('Devuelto', money(e.deposito_devuelto))], ['text', lin('Queda en resguardo', money(e.deposito_saldo))]] : []),
    ...(await firmaOps(null, d.tipo === 'devuelto' ? d.usuario : e.huesped, d.tipo === 'devuelto' ? 'ENTREGA' : 'ENTREGA')),
    ...(await firmaOps(d.tipo === 'devuelto' ? d.firma : null, d.tipo === 'devuelto' ? (d.recibe || e.huesped) : (d.usuario || CFG.hotel_nombre), 'RECIBE'))];
}
// Original y copia (cortadas por separado)
function docConCopia(cuerpo, formato, titulo, opsFn) {
  const f = formato || ancho();
  const html = f === 'carta' ? `<div class="mitad">${cuerpo('ORIGINAL')}</div><div class="corte">✂ - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -</div><div class="mitad">${cuerpo('COPIA')}</div>`
    : `${cuerpo('ORIGINAL')}<div class="corte">- - - - - - corte - - - - - -</div>${cuerpo('COPIA')}`;
  imprimirDoc(html, f, titulo, opsFn ? async () => [...(await opsFn('ORIGINAL')), ['cut'], ...(await opsFn('COPIA'))] : null);
  const pie = $('#modal footer');
  if (pie) pie.insertAdjacentHTML('afterbegin', `<button class="btn" onclick="cambiarFormato()">${f === 'carta' ? 'Ver en ticket' : 'Hoja carta (PDF)'}</button>`);
  cambiarFormato.fn = () => docConCopia(cuerpo, f === 'carta' ? ancho() : 'carta', titulo, opsFn);
}

// ---------- Turno de caja ----------
async function pintarTurno() {
  const el = $('#turnoBar'); if (!el || !YO) return;
  if (!puede('caja') && !puede('cortes')) { el.innerHTML = ''; return; }
  try { TURNO = await GET('/api/turno'); } catch { return; }
  YO.turno = TURNO.turno;
  el.innerHTML = TURNO.turno ? `<button class="tb on" onclick="ir('caja')"><span>Caja abierta</span><small>Dólar $${Number(TURNO.turno.tipo_cambio).toFixed(2)}</small></button>`
    : puede('caja') ? `<button class="tb" onclick="abrirTurno()"><span>Abrir turno</span><small>Caja cerrada</small></button>` : '';
}
function abrirTurno() {
  modal('Abrir turno · 1 de 2', `<p style="margin:0">Cuente el dinero con el que empieza la caja.</p>
    <div class="f"><label class="l">Fondo de caja en pesos<input id="tFm" type="number" min="0" step="0.01" placeholder="0.00"></label><label class="l">Fondo en dólares<input id="tFu" type="number" min="0" step="0.01" placeholder="0.00"></label></div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="abrirTurno2()">Siguiente</button>`);
}
function abrirTurno2() {
  const fm = num('tFm'), fu = num('tFu');
  modal('Abrir turno · 2 de 2', `<div class="calc"><span>Fondo en pesos</span><b>${money(fm)}</b><span>Fondo en dólares</span><b>US$${fu.toFixed(2)}</b></div>
    <label class="l" style="font-size:15px">¿En cuánto toma el dólar hoy? (tipo de cambio)<input id="tTc" type="number" min="0" step="0.01" value="${Number(CFG.tipo_cambio) || ''}" style="font-size:22px"></label>`,
  `<button class="btn" onclick="abrirTurno()">Atrás</button><button class="btn pri" onclick="abrirTurnoOk(${fm},${fu})">Abrir turno</button>`);
  $('#tTc').select();
}
async function abrirTurnoOk(fm, fu) {
  const r = await hacer(() => POST('/api/turno/abrir', { fondo_mxn: fm, fondo_usd: fu, tipo_cambio: val('tTc') }), 'Turno abierto');
  CFG.tipo_cambio = String(r.turno.tipo_cambio);
  if (r.cajon && r.cajon.error) toast('No se abrió el cajón: ' + r.cajon.error, true);
  await pintarTurno(); if (vista === 'caja') vCaja();
  const w = W();
  imprimir([...encabezado(), 'APERTURA DE TURNO', '-'.repeat(w), lin('Usuario', YO.nombre), lin('Fecha', fdt(r.turno.apertura)), lin('Fondo en pesos', money(fm)), lin('Fondo en dólares', 'US$' + fu.toFixed(2)), lin('Tipo de cambio', '$' + Number(r.turno.tipo_cambio).toFixed(2)), '', '', '_'.repeat(Math.min(30, w)), 'Firma'], 'Apertura de turno');
}
let cjDesde = hoyISO(), cjHasta = hoyISO();
async function vCaja() {
  const r = await GET('/api/turno'); TURNO = r;
  let html = '';
  if (!r.turno) {
    html = `<div class="card" style="max-width:520px"><h2>Su caja está cerrada</h2><p class="sub">Para cobrar hospedaje, anticipos, depósitos, tienda o visitas primero abra su turno: le pedirá el fondo de caja y el tipo de cambio del dólar.</p>${puede('caja') ? '<button class="btn pri" onclick="abrirTurno()">Abrir turno</button>' : ''}</div>`;
  } else {
    const t = r.turno, p = r.pagos, c = r.conceptos, e = r.esperado;
    html = `<div class="kpis"><div class="kpi"><span>Fondo inicial</span><b>${money(t.fondo_mxn)}</b><div class="sub">más US$${t.fondo_usd.toFixed(2)} · abrió ${fdt(t.apertura)}</div></div>
      <div class="kpi"><span>Cobrado en el turno</span><b>${money(r.cobrado)}</b><div class="sub">Dólar a $${Number(t.tipo_cambio).toFixed(2)}</div></div>
      ${e ? `<div class="kpi"><span>Debe haber en pesos</span><b>${money(e.mxn)}</b><div class="sub">efectivo en el cajón</div></div><div class="kpi"><span>Debe haber en dólares</span><b>US$${e.usd.toFixed(2)}</b><div class="sub">tarjeta ${money(e.tarjeta)} · transf. ${money(e.transferencia)}</div></div>`
    : '<div class="kpi"><span>Cierre a ciegas</span><b>—</b><div class="sub">Al cerrar, cuente el dinero; el sistema calcula la diferencia.</div></div>'}</div>
    <div class="row" style="margin-bottom:16px">${puede('movimientos') ? `<button class="btn" onclick="movModal('ingreso')">Registrar ingreso a caja</button><button class="btn" onclick="movModal('retiro')">Registrar egreso de caja</button>` : ''}
      ${puede('cajon') ? '<button class="btn" onclick="abrirCajonBtn()">Abrir cajón</button>' : ''}<button class="btn" onclick="tcModal()">Cambiar tipo de cambio</button>
      <button class="btn" onclick="imprimirCorte2(TURNO,'CORTE PARCIAL (X)')">Imprimir corte parcial</button><button class="btn pri" onclick="cerrarTurno()">Cerrar turno</button></div>
    <div class="cols"><div class="card"><h2>Cobros por concepto</h2><div class="kv"><span>Hospedaje y anticipos</span><b>${money(c.hospedaje?.total)}</b><span>Tienda (productos)</span><b>${money(c.tienda?.total)}</b><span>Visitas</span><b>${money(c.visita?.total)}</b></div></div>
      <div class="card"><h2>Por forma de pago</h2><div class="kv"><span>Efectivo (neto, ya sin cambio)</span><b>${money(p.efectivo)}</b><span>Dólares (neto, ya sin cambio)</span><b>US$${p.usd.toFixed(2)} → ${money(p.dolares)}</b><span>Cambio en pesos por pagos en dólares</span><b>${money(p.cambio)}</b><span>Tarjeta</span><b>${money(p.tarjeta)}</b><span>Transferencia</span><b>${money(p.transferencia)}</b></div></div>
      <div class="card"><h2>Depósitos y gastos</h2><div class="kv"><span>Depósitos recibidos (efectivo)</span><b>${money(r.depositos.recibidos.efectivo)}</b><span>Depósitos en dólares</span><b>US$${r.depositos.recibidos.usd.toFixed(2)}</b><span>Depósitos devueltos (efectivo)</span><b>${money(r.depositos.devueltos.efectivo)}</b><span>Gastos pagados de caja</span><b>${money(r.gastos.efectivo)}</b></div></div></div>
    <div class="card" style="margin-top:16px"><h2>Ingresos y egresos de caja</h2><div class="tw"><table><thead><tr><th>Hora</th><th>Tipo</th><th>Motivo</th><th class="n">Monto</th></tr></thead><tbody>
      ${r.lista_mov.map((m) => `<tr><td>${fdt(m.fecha)}</td><td><span class="pill ${m.tipo === 'ingreso' ? 'p-ok' : 'p-bad'}">${m.tipo === 'ingreso' ? 'Ingreso' : 'Egreso'}</span></td><td>${esc(m.motivo)}</td><td class="n">${m.moneda === 'USD' ? 'US$' + m.monto.toFixed(2) : money(m.monto)}</td></tr>`).join('') || '<tr><td colspan="4" class="empty">Sin movimientos.</td></tr>'}</tbody></table></div></div>`;
  }
  if (puede('cortes')) {
    const l = await GET(`/api/turnos?desde=${cjDesde}&hasta=${cjHasta}`);
    html += `<div class="card" style="margin-top:16px"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h2 style="margin:0">Cortes de caja</h2><div class="row"><input type="date" id="cjd" value="${cjDesde}" style="width:auto"><input type="date" id="cjh" value="${cjHasta}" style="width:auto"><button class="btn sm" onclick="cjDesde=val('cjd');cjHasta=val('cjh');vCaja()">Ver</button></div></div>
      <div class="tw"><table><thead><tr><th>Turno</th><th>Usuario</th><th>Abrió</th><th>Cerró</th><th class="n">Cobrado</th><th class="n">Dif. pesos</th><th class="n">Dif. dólares</th><th></th></tr></thead><tbody>
      ${l.map((x) => `<tr><td class="mono">${x.turno.id}</td><td>${esc(x.turno.usuario)}</td><td>${fdt(x.turno.apertura)}</td><td>${x.turno.cierre ? fdt(x.turno.cierre) : '<span class="pill p-ok">Abierto</span>'}</td><td class="n">${money(x.cobrado)}</td>
        <td class="n" style="color:${x.dif && x.dif.mxn < 0 ? 'var(--ocup)' : 'inherit'}">${x.dif ? money(x.dif.mxn) : '—'}</td><td class="n" style="color:${x.dif && x.dif.usd < 0 ? 'var(--ocup)' : 'inherit'}">${x.dif ? 'US$' + x.dif.usd.toFixed(2) : '—'}</td>
        <td><button class="btn sm" onclick="reimprimirCorte(${x.turno.id})">Ticket</button></td></tr>`).join('') || '<tr><td colspan="8" class="empty">Sin turnos en esas fechas.</td></tr>'}</tbody></table></div></div>`;
  }
  $('#main').innerHTML = cab('Caja', r.turno ? `Turno de ${esc(YO.nombre)}` : 'Turno, fondo, entradas y salidas de dinero') + html;
}
function movModal(tipo) {
  modal(tipo === 'ingreso' ? 'Registrar ingreso a caja' : 'Registrar egreso de caja', `<div class="f"><label class="l">Moneda<select id="mvM"><option value="MXN">Pesos</option><option value="USD">Dólares</option></select></label><label class="l">Monto<input id="mvC" type="number" min="0" step="0.01"></label></div>
    <label class="l">Motivo<input id="mvT" placeholder="${tipo === 'ingreso' ? 'Ej. cambio, morralla' : 'Ej. retiro del dueño, pago de garrafones'}"></label>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="movOk('${tipo}')">Guardar</button>`);
}
async function movOk(tipo) {
  const mon = val('mvM'), monto = num('mvC'), motivo = val('mvT');
  await hacer(() => POST('/api/turno/movimiento', { tipo, moneda: mon, monto, motivo }), tipo === 'ingreso' ? 'Ingreso a caja registrado' : 'Egreso de caja registrado');
  vCaja(); const w = W();
  imprimir([...encabezado(), tipo === 'ingreso' ? 'INGRESO A CAJA' : 'EGRESO DE CAJA', '-'.repeat(w), lin('Fecha', fdt(new Date().toISOString().slice(0, 19).replace('T', ' '))), lin('Usuario', YO.nombre),
    lin('Monto', mon === 'USD' ? 'US$' + monto.toFixed(2) : money(monto)), ...wrapT('Motivo: ' + motivo), '', '', '_'.repeat(Math.min(30, w)), 'Firma'], tipo === 'ingreso' ? 'Ingreso a caja' : 'Egreso de caja');
}
async function abrirCajonBtn() { const r = await hacer(() => POST('/api/cajon')); toast(r.ok ? 'Cajón abierto' : r.sinImpresora ? 'No hay impresora configurada para abrir el cajón' : 'No se abrió: ' + r.error, !r.ok); }
function tcModal() { modal('Tipo de cambio', `<label class="l">¿En cuánto toma el dólar?<input id="tcN" type="number" step="0.01" value="${tcHoy()}"></label>`, `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="tcOk()">Guardar</button>`); }
async function tcOk() { await hacer(() => POST('/api/turno/tipo-cambio', { tipo_cambio: val('tcN') }), 'Tipo de cambio actualizado'); CFG.tipo_cambio = val('tcN'); cerrar(); await pintarTurno(); vCaja(); }
function cerrarTurno() {
  modal('Cerrar turno', `<p style="margin:0">Cuente lo que hay en la caja y escríbalo. Ponga 0 donde no haya.</p>
    <div class="f"><label class="l">Efectivo en pesos<input id="cMx" type="number" min="0" step="0.01"></label><label class="l">Dólares<input id="cUs" type="number" min="0" step="0.01"></label>
    <label class="l">Vouchers de tarjeta<input id="cTa" type="number" min="0" step="0.01"></label><label class="l">Transferencias<input id="cTr" type="number" min="0" step="0.01"></label></div>
    <label class="l">Notas<input id="cNo"></label>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="cerrarTurnoOk()">Cerrar turno e imprimir corte</button>`);
}
async function cerrarTurnoOk() {
  const r = await hacer(() => POST('/api/turno/cerrar', { decl_mxn: val('cMx'), decl_usd: val('cUs'), decl_tarjeta: val('cTa'), decl_transferencia: val('cTr'), notas: val('cNo') }), 'Turno cerrado');
  await pintarTurno(); vCaja(); imprimirCorte2(r, 'CORTE DE TURNO');
}
async function reimprimirCorte(id) { imprimirCorte2(await GET('/api/turnos/' + id), 'CORTE DE TURNO (REIMPRESIÓN)'); }
function imprimirCorte2(r, titulo) {
  const t = r.turno, p = r.pagos, c = r.conceptos, w = W(), us = (x) => 'US$' + Number(x || 0).toFixed(2);
  const L = [...encabezado(), titulo, '-'.repeat(w), lin('Turno', t.id), lin('Usuario', t.usuario || YO.nombre), lin('Abrió', fdt(t.apertura)), ...(t.cierre ? [lin('Cerró', fdt(t.cierre))] : []), lin('Tipo de cambio', '$' + Number(t.tipo_cambio).toFixed(2)),
    '-'.repeat(w), lin('Fondo pesos', money(t.fondo_mxn)), lin('Fondo dólares', us(t.fondo_usd)), '-'.repeat(w), 'COBROS',
    lin('Hospedaje y anticipos', money(c.hospedaje?.total)), lin('Tienda', money(c.tienda?.total)), lin('Visitas', money(c.visita?.total)), lin('TOTAL COBRADO', money(r.cobrado)), '-'.repeat(w), 'FORMAS DE PAGO',
    lin('Efectivo (neto)', money(p.efectivo)), lin(`Dólares ${us(p.usd)}`, money(p.dolares)), lin('Cambio por dólares', money(p.cambio)), lin('Tarjeta', money(p.tarjeta)), lin('Transferencia', money(p.transferencia)), '-'.repeat(w),
    'DEPÓSITOS', lin('Recibidos efectivo', money(r.depositos.recibidos.efectivo)), lin('Recibidos dólares', us(r.depositos.recibidos.usd)), lin('Recibidos tarjeta/transf.', money(r.depositos.recibidos.tarjeta + r.depositos.recibidos.transferencia)),
    lin('Devueltos efectivo', money(r.depositos.devueltos.efectivo)), lin('Devueltos dólares', us(r.depositos.devueltos.usd)), '-'.repeat(w),
    lin('Gastos pagados de caja', money(r.gastos.efectivo)), lin('Ingresos a caja', money(r.movimientos.ing_mxn) + (r.movimientos.ing_usd ? ' ' + us(r.movimientos.ing_usd) : '')),
    lin('Egresos de caja', money(r.movimientos.ret_mxn) + (r.movimientos.ret_usd ? ' ' + us(r.movimientos.ret_usd) : '')), '-'.repeat(w)];
  if (r.esperado) L.push('DEBE HABER', lin('Pesos', money(r.esperado.mxn)), lin('Dólares', us(r.esperado.usd)), lin('Tarjeta', money(r.esperado.tarjeta)), lin('Transferencia', money(r.esperado.transferencia)), '-'.repeat(w));
  if (t.estado === 'cerrado') {
    L.push('CONTADO AL CERRAR', lin('Pesos', money(t.decl_mxn)), lin('Dólares', us(t.decl_usd)), lin('Tarjeta', money(t.decl_tarjeta)), lin('Transferencia', money(t.decl_transferencia)));
    if (r.dif) L.push('-'.repeat(w), 'DIFERENCIA (sobra + / falta -)', lin('Pesos', money(r.dif.mxn)), lin('Dólares', us(r.dif.usd)), lin('Tarjeta', money(r.dif.tarjeta)), lin('Transferencia', money(r.dif.transferencia)));
    if (t.notas) L.push(...wrapT('Notas: ' + t.notas));
  }
  L.push('', '', '_'.repeat(Math.min(30, w)), 'Firma cajero', '', '', '_'.repeat(Math.min(30, w)), 'Firma supervisor', '', 'Impreso ' + new Date().toLocaleString('es-MX'));
  imprimir(L, titulo.toLowerCase().replace(/^\w/, (x) => x.toUpperCase()));
}

// ---------- Configuración: impresora y caja ----------
async function cImpresora() {
  $('#cfgc').innerHTML = `<div class="stack"><div class="card"><h2>Impresora de tickets</h2>
    <p class="sub" style="margin-top:0">Con la impresora configurada aquí los tickets se imprimen directo, <b>se cortan solos al terminar</b> y el <b>cajón de dinero se abre</b> al abrir turno y al cobrar o sacar efectivo (el cajón va conectado a la impresora).</p>
    <div class="f"><label class="l">Conexión<select id="iT" onchange="iTipo()"><option value="ninguna">Sin impresora (usar ventana de imprimir)</option><option value="windows">Impresora instalada en Windows (USB)</option><option value="ip">Impresora de red (IP)</option></select></label>
      <label class="l" id="iNL">Impresora<span class="row" style="gap:6px;flex-wrap:nowrap"><select id="iN"><option value="${esc(CFG.impresora_nombre)}">${esc(CFG.impresora_nombre || 'Elija…')}</option></select><button class="btn sm" type="button" onclick="buscarImpresoras()">Buscar</button></span></label>
      <label class="l" id="iIL">IP de la impresora<input id="iI" value="${esc(CFG.impresora_ip)}" placeholder="192.168.1.100"></label><label class="l" id="iPL">Puerto<input id="iP" value="${esc(CFG.impresora_puerto)}"></label>
      <label class="l" style="grid-column:span 2">Marca / modelo de la impresora<select id="iM" onchange="iModelo()">${Object.entries(MODELOS_IMP).map(([k, m]) => `<option value="${k}">${esc(m.n)}</option>`).join('')}</select></label>
      <label class="l" id="iCoL">Letras por renglón<input id="iCo" type="number" min="24" max="64" value="${esc(CFG.ticket_columnas || '42')}"></label>
      <label class="l">Ancho del papel<select id="iA"><option value="80">80 mm</option><option value="58">58 mm</option></select></label><label class="l">Corte<select id="iC"><option value="parcial">Parcial (queda unido de una orilla)</option><option value="total">Total</option></select></label></div>
    <label class="row" style="font-weight:600;margin-top:10px"><input type="checkbox" id="iK" ${CFG.abrir_cajon !== '0' ? 'checked' : ''}> Abrir el cajón de dinero al cobrar cada ticket, al registrar ingresos o egresos de caja y al abrir y cerrar turno</label>
    <p class="sub">Si los renglones salen cortados (una palabra se pasa al renglón de abajo) o el ticket sale muy angosto, imprima la <b>Prueba de ancho</b>: el renglón más largo que salga completo en una sola línea es el que debe elegir.</p>
    <div class="row" style="margin-top:12px"><button class="btn" onclick="pruebaImpresora()">Imprimir prueba</button><button class="btn" onclick="pruebaAncho()">Prueba de ancho</button><button class="btn" onclick="abrirCajonBtn()">Probar cajón</button></div></div>
    <div class="card"><h2>Caja</h2><label class="row" style="font-weight:600"><input type="checkbox" id="iE" ${CFG.exigir_turno !== '0' ? 'checked' : ''}> Pedir que el usuario abra su turno (fondo y tipo de cambio) antes de cobrar</label>
      <label class="row" style="font-weight:600"><input type="checkbox" id="iPA" ${CFG.imprimir_auto !== '0' ? 'checked' : ''}> Imprimir el ticket automáticamente al cobrar</label>
    <div class="f" style="margin-top:10px"><label class="l">Cobro de visita (sugerido)<input id="iV" type="number" min="0" step="0.01" value="${esc(CFG.precio_visita)}"></label><label class="l">Último tipo de cambio<input value="${esc(CFG.tipo_cambio)}" disabled></label></div></div>
    <div><button class="btn pri" onclick="impresoraOk()">Guardar</button></div></div>`;
  $('#iT').value = CFG.impresora_tipo || 'ninguna'; $('#iA').value = CFG.ticket_ancho === '58' ? '58' : '80'; $('#iC').value = CFG.impresora_corte || 'parcial'; $('#iM').value = modeloImp(); iTipo(); iModelo(true);
  $('#iN').addEventListener('change', () => { const m = modeloPorNombre(val('iN')); if (m) { $('#iM').value = m; iModelo(); toast('Se eligió el modelo según el nombre de la impresora'); } });
}
function iModelo(inicio) {
  const m = val('iM'); $('#iCoL').hidden = m !== 'otro';
  if (!inicio && MODELOS_IMP[m]) { $('#iA').value = MODELOS_IMP[m].mm; if (m !== 'otro') $('#iCo').value = MODELOS_IMP[m].col; }
}
// Imprime renglones de 32, 42, 48 y 56 letras: el más largo que salga en UNA línea es el bueno
async function pruebaAncho() {
  await impresoraOk();
  const regla = (n) => { let s = ''; for (let i = 1; i <= n; i++) s += i % 10 === 0 ? String((i / 10) % 10) : i % 5 === 0 ? '+' : '-'; return s.slice(0, n - 3) + n; };
  const ops = [['align', 'center'], ['bold', true], ['text', 'PRUEBA DE ANCHO'], ['bold', false], ['align', 'left'], ['text', ''],
    ...[32, 42, 48, 56].flatMap((n) => [['text', `Renglon de ${n} letras:`], ['text', regla(n)], ['text', '']]),
    ['text', 'Elija el numero mas grande que'], ['text', 'salio completo en UNA sola linea.']];
  const r = await hacer(() => POST('/api/imprimir', { ops }));
  toast(r.ok ? 'Prueba de ancho enviada a la impresora' : 'No se imprimió: ' + (r.error || 'elija una impresora'), !r.ok);
}
function iTipo() { const t = val('iT'); $('#iNL').hidden = t !== 'windows'; $('#iIL').hidden = $('#iPL').hidden = t !== 'ip'; }
async function buscarImpresoras() {
  const r = await hacer(() => GET('/api/impresoras'));
  if (!r.lista.length) return toast(r.error || 'No se encontraron impresoras instaladas', true);
  const actual = val('iN'); $('#iN').innerHTML = r.lista.map((n) => `<option ${n === actual ? 'selected' : ''}>${esc(n)}</option>`).join(''); toast(r.lista.length + ' impresora(s) encontradas');
}
async function impresoraOk() {
  await hacer(() => PUT('/api/config', { impresora_tipo: val('iT'), impresora_nombre: val('iN'), impresora_ip: val('iI'), impresora_puerto: val('iP') || '9100', ticket_ancho: val('iA'), impresora_corte: val('iC'), impresora_modelo: val('iM'), ticket_columnas: String(Math.max(24, Math.min(64, parseInt(val('iCo')) || 42))), ticket_puntos: '',
    abrir_cajon: $('#iK').checked ? '1' : '0', exigir_turno: $('#iE').checked ? '1' : '0', imprimir_auto: $('#iPA').checked ? '1' : '0', precio_visita: val('iV') || '0' }), 'Guardado');
  CFG = await GET('/api/config');
}
async function pruebaImpresora() {
  await impresoraOk();
  const r = await hacer(() => POST('/api/imprimir', { ops: [...encOps(), ['align', 'center'], ['bold', true], ['text', 'PRUEBA DE IMPRESORA'], ['bold', false], ['text', 'Acentos: á é í ó ú ñ ¿ ¡'], ['text', new Date().toLocaleString('es-MX')], ['text', 'Si ve este ticket cortado, quedó lista.']] }));
  toast(r.ok ? 'Prueba enviada a la impresora' : 'No se imprimió: ' + (r.error || 'elija una impresora'), !r.ok);
}

// ---------- Usuarios y permisos ----------
let PERMS = null;
async function cUsers() {
  const [U, P] = await Promise.all([GET('/api/usuarios'), PERMS ? PERMS : GET('/api/permisos')]); cUsers.l = U; PERMS = P;
  $('#cfgc').innerHTML = `<div class="card"><div class="row" style="justify-content:space-between;margin-bottom:10px"><h2 style="margin:0">Usuarios y permisos</h2><button class="btn pri" onclick="userModal()">Nuevo usuario</button></div>
    <p class="sub" style="margin-top:0">Cada usuario empieza con los permisos de su tipo y usted puede quitar o agregar los que quiera. El administrador siempre tiene todo.</p>
    <div class="tw"><table><thead><tr><th>Nombre</th><th>Usuario</th><th>Tipo</th><th>Permisos</th><th>Estado</th></tr></thead><tbody>${U.map((u) => `<tr class="click" onclick="userModal(${u.id})"><td><b>${esc(u.nombre)}</b></td><td class="mono">${esc(u.usuario)}</td><td>${ROL[u.rol]}</td>
      <td>${u.rol === 'admin' ? 'Todos' : u.permisos.length + ' de ' + P.lista.length}${u.personalizado ? ' <span class="pill p-warn">Personalizados</span>' : ''}</td><td>${u.activo ? '<span class="pill p-ok">Activo</span>' : '<span class="pill p-bad">Inactivo</span>'}</td></tr>`).join('')}</tbody></table></div></div>`;
}
function userModal(id) {
  const u = id ? cUsers.l.find((x) => x.id === id) : { nombre: '', usuario: '', rol: 'recepcion', activo: 1, permisos: PERMS.roles.recepcion };
  const grupos = [...new Set(PERMS.lista.map((p) => p.grupo))];
  modal(id ? 'Editar usuario' : 'Nuevo usuario', `<div class="f"><label class="l">Nombre<input id="uN" value="${esc(u.nombre)}"></label><label class="l">Usuario<input id="uU" value="${esc(u.usuario)}" ${id ? 'disabled' : ''} autocapitalize="off"></label>
    <label class="l">Tipo<select id="uR" onchange="permisosRol()">${Object.entries(ROL).map(([k, n]) => `<option value="${k}" ${u.rol === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label><label class="l">${id ? 'Nueva contraseña (opcional)' : 'Contraseña'}<input id="uP" type="password" autocomplete="new-password"></label></div>
    ${id ? `<label class="row" style="font-weight:600"><input type="checkbox" id="uA" ${u.activo ? 'checked' : ''}> Usuario activo</label>` : ''}
    <div class="row" style="justify-content:space-between"><span class="lbl">Qué puede hacer</span><button type="button" class="btn sm" onclick="permisosRol()">Poner los de su tipo</button></div>
    <div class="permgrid">${grupos.map((g) => `<div class="permg"><b>${g}</b>${PERMS.lista.filter((p) => p.grupo === g).map((p) => `<label><input type="checkbox" name="uPm" value="${p.clave}" ${u.permisos.includes(p.clave) ? 'checked' : ''}> ${esc(p.texto)}</label>`).join('')}</div>`).join('')}</div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="userOk(${id || 0})">Guardar</button>`, true);
  permisosAdmin();
}
function permisosRol() { const l = PERMS.roles[val('uR')] || []; document.querySelectorAll('input[name=uPm]').forEach((c) => (c.checked = l.includes(c.value))); permisosAdmin(); }
function permisosAdmin() { const adm = val('uR') === 'admin'; document.querySelectorAll('input[name=uPm]').forEach((c) => { c.disabled = adm; if (adm) c.checked = true; }); }
async function userOk(id) {
  const b = { nombre: val('uN'), rol: val('uR'), password: $('#uP').value || undefined, permisos: [...document.querySelectorAll('input[name=uPm]:checked')].map((c) => c.value) };
  if (id) b.activo = $('#uA').checked; else b.usuario = val('uU');
  await hacer(() => (id ? PUT('/api/usuarios/' + id, b) : POST('/api/usuarios', b)), 'Usuario guardado'); cerrar(); cUsers();
}

inicio();
