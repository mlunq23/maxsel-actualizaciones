// Maxsel Carwash 1.1 — Reportes del autolavado
// Resumen con comparación contra el periodo anterior, paquetes, horas pico y días de la semana, tipo de vehículo,
// clientes frecuentes por placas, cajeros, cancelaciones (quién y por qué), productos con utilidad, existencias,
// gastos y la lista de cada paquete vendido para revisar contra la cámara. Ticket, PDF carta y Excel.
'use strict';

const RANGOS = () => {
  const d = new Date(), iso = (x) => x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0') + '-' + String(x.getDate()).padStart(2, '0');
  const ayer = new Date(d); ayer.setDate(d.getDate() - 1);
  const lunes = new Date(d); lunes.setDate(d.getDate() - ((d.getDay() + 6) % 7));
  const lunesA = new Date(lunes); lunesA.setDate(lunes.getDate() - 7); const domA = new Date(lunes); domA.setDate(lunes.getDate() - 1);
  const mes1 = new Date(d.getFullYear(), d.getMonth(), 1), mesA1 = new Date(d.getFullYear(), d.getMonth() - 1, 1), mesA2 = new Date(d.getFullYear(), d.getMonth(), 0);
  const d30 = new Date(d); d30.setDate(d.getDate() - 29);
  return [['Hoy', iso(d), iso(d)], ['Ayer', iso(ayer), iso(ayer)], ['Esta semana', iso(lunes), iso(d)], ['Semana pasada', iso(lunesA), iso(domA)], ['Este mes', iso(mes1), iso(d)], ['Mes pasado', iso(mesA1), iso(mesA2)], ['Últimos 30 días', iso(d30), iso(d)], ['Este año', d.getFullYear() + '-01-01', iso(d)]];
};
// Íconos de línea (estilo Lucide, licencia ISC) — una sola familia en todo el sistema
const ICW = {
  car: '<path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/>',
  caja: '<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>',
  caja2: '<path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/>',
  recibo: '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><path d="M12 17.5v-11"/>',
  reloj: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  grafica: '<path d="M3 3v18h18"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>',
  ajustes: '<path d="M21 4h-7M10 4H3M21 12h-9M8 12H3M21 20h-5M12 20H3M14 2v4M8 10v4M16 18v4"/>',
  estrella: '<path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>',
  calendario: '<rect width="18" height="18" x="3" y="4" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  ok: '<path d="M20 6 9 17l-5-5"/>',
};
const icoCW = (k, cls = 'cw-ico') => `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICW[k] || ''}</svg>`;
const DIAS_SEM = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
const horaTxt = (h) => `${h % 12 || 12} ${h < 12 ? 'am' : 'pm'}`;
const pctTxt = (n) => (Number(n) || 0).toLocaleString('es-MX', { maximumFractionDigits: 1 }) + '%';
const ent0 = (n) => (Number(n) || 0).toLocaleString('es-MX', { maximumFractionDigits: 1 });
const colorDe = (paq) => colorPaq(PRODS.find((p) => p.paquete === paq) || { paquete: paq });
let rTab = 'resumen', rBus = '', R = null;

// Flecha contra el periodo anterior (malo = true cuando subir es malo: gastos, cancelaciones)
function compara(act, ant, malo) {
  act = Number(act) || 0; ant = Number(ant) || 0;
  if (!ant && !act) return '<span class="cw-cmp">sin cambio</span>';
  if (!ant) return '<span class="cw-cmp up">nuevo</span>';
  const p = (act - ant) / ant * 100, sube = p >= 0, bien = malo ? !sube : sube;
  if (Math.abs(p) < 0.5) return '<span class="cw-cmp">igual</span>';
  return `<span class="cw-cmp ${bien ? 'up' : 'down'}">${sube ? '▲' : '▼'} ${pctTxt(Math.abs(p))}</span>`;
}
// Columnas verticales simples (sin librerías). datos: [{l, v, t, c, on}]
function columnas(datos, fmt = ent0, alto = 170) {
  const max = Math.max(1, ...datos.map((x) => x.v || 0));
  return `<div class="cw-cols" style="--h:${alto}px">${datos.map((x) => `<div class="cw-col ${x.on ? 'on' : ''}" title="${esc(x.t || x.l)}: ${esc(fmt(x.v))}"><span class="cw-col-v">${x.v ? esc(fmt(x.v)) : ''}</span><i style="height:${Math.round((x.v || 0) / max * 100)}%;${x.c ? 'background:' + x.c : ''}"></i><span class="cw-col-l">${esc(x.l)}</span></div>`).join('')}</div>`;
}
// Barras horizontales: [{l, v, sub, c, mini}]
function barras(datos, fmt = ent0) {
  const max = Math.max(1, ...datos.map((x) => x.v || 0));
  return `<div class="cw-barras">${datos.map((x) => `<div class="cw-barra">${x.mini || '<span></span>'}<div class="cw-b-txt"><b>${esc(x.l)}</b><div class="cw-b-bar"><i style="width:${Math.round((x.v || 0) / max * 100)}%;background:${x.c || 'var(--accent)'}"></i></div></div><div class="cw-b-n"><b>${esc(fmt(x.v))}</b>${x.sub ? `<span>${x.sub}</span>` : ''}</div></div>`).join('')}</div>`;
}
const miniP = (paq) => `<span class="cw-mini" style="--pc:${colorDe(paq)}">P${esc(paq)}</span>`;
const kpi = (t, v, sub, cmp, color) => `<div class="kpi"><span>${t}</span><b ${color ? `style="color:${color}"` : ''}>${v}</b><div class="sub">${sub || ''}</div>${cmp ? `<div class="cw-kpi-cmp">${cmp}</div>` : ''}</div>`;

vRep = async function () {
  if (!PRODS.length) PRODS = await GET('/api/productos').catch(() => []);
  R = await GET(`/api/reporte/carwash?desde=${rDesde}&hasta=${rHasta}`);
  vRep.d = await GET(`/api/reporte?desde=${rDesde}&hasta=${rHasta}`); // efectivo en caja y corte por usuario (los usa el corte)
  const TABS = [['resumen', 'Resumen'], ['paquetes', 'Paquetes'], ['horas', 'Horas y días'], ['clientes', 'Vehículos y clientes'], ['cajeros', 'Cajeros y cancelaciones'], ['productos', 'Productos e inventario'], ['gastos', 'Gastos y utilidad'], ['lav', 'Lavadores y comisiones'], ['camara', 'Revisar con cámara']];
  const rangos = RANGOS().map(([n, a, b]) => `<button class="chip ${rDesde === a && rHasta === b ? 'on' : ''}" onclick="rDesde='${a}';rHasta='${b}';vRep()">${n}</button>`).join('');
  const per = R.desde === R.hasta ? fd(R.desde) : `${fd(R.desde)} al ${fd(R.hasta)}`;
  $('#main').innerHTML = cab('Reportes', `${per} · comparado con ${R.anterior.desde === R.anterior.hasta ? fd(R.anterior.desde) : fd(R.anterior.desde) + ' al ' + fd(R.anterior.hasta)}`,
    `<label class="l">Desde<input type="date" id="rd" value="${rDesde}" onchange="rDesde=this.value;vRep()"></label><label class="l">Hasta<input type="date" id="rh" value="${rHasta}" onchange="rHasta=this.value;vRep()"></label>
     <button class="btn" onclick="imprimirCorte()">Imprimir corte</button><button class="btn" onclick="cwPdfRep()">PDF</button><button class="btn" onclick="cwExcelRep()">Excel</button>`)
    + `<div class="chips areas" style="margin:-6px 0 12px">${rangos}</div>
    <div class="tabs" style="margin-bottom:14px">${TABS.map(([k, n]) => `<button class="${rTab === k ? 'on' : ''}" onclick="rTab='${k}';cwPintarRep()">${n}${k === 'cajeros' && R.resumen.canceladas ? ` <span class="cw-badge">${R.resumen.canceladas}</span>` : ''}</button>`).join('')}</div><div id="repc"></div>`;
  cwPintarRep();
};
function cwPintarRep() {
  document.querySelectorAll('#main .tabs button').forEach((b) => b.classList.toggle('on', (b.getAttribute('onclick') || '').includes(`'${rTab}'`)));
  ({ resumen: rResumen, paquetes: rPaquetes, horas: rHoras, clientes: rClientes, cajeros: rCajeros, productos: rProductos, gastos: rGastos, lav: rLav, camara: rCamara })[rTab]();
}

// ---------- Resumen ----------
function rResumen() {
  const a = R.resumen, b = R.anterior, d = vRep.d;
  const pico = R.porHora.reduce((m, x) => (x.carros > m.carros ? x : m), { carros: 0 });
  const mejorDia = R.porDia.reduce((m, x) => (x.total > (m?.total || 0) ? x : m), null);
  const sem = R.porSemana.filter((x) => x.fechas).map((x) => ({ ...x, prom: x.carros / x.fechas })).sort((x, y) => y.prom - x.prom)[0];
  const top = R.paquetes.porPaquete.slice().sort((x, y) => y.n - x.n)[0];
  const diasCols = R.porDia.length > 1 ? R.porDia.slice(-31).map((x) => ({ l: x.dia.slice(8), t: fd(x.dia), v: x.carros })) : null;
  $('#repc').innerHTML = `<div class="kpis">
    ${kpi('Carros lavados', ent0(a.carros), `${ent0(a.carrosDia)} por día · antes ${ent0(b.carros)}`, compara(a.carros, b.carros))}
    ${kpi('Venta total', money(a.total), `${a.tickets} tickets · antes ${money(b.total)}`, compara(a.total, b.total))}
    ${kpi('Ticket promedio', money(a.ticketPromedio), `por carro ${money(a.carroPromedio)} (lavado + extras)`, compara(a.ticketPromedio, b.ticketPromedio))}
    ${kpi('Venta adicional', pctTxt(a.pctExtra), `${a.conExtra} de ${a.ticketsPaquete} carros compraron algo extra`, compara(a.pctExtra, b.pctExtra))}
    ${kpi('Paquetes de lavado', money(a.paquetes), a.total ? pctTxt(a.paquetes / a.total * 100) + ' de la venta' : '', compara(a.paquetes, b.paquetes))}
    ${kpi('Servicios extra', money(a.extras), 'aspirados, motor, encerados…', compara(a.extras, b.extras))}
    ${kpi('Productos (tienda)', money(a.productos), 'aromatizantes, bebidas…', compara(a.productos, b.productos))}
    ${kpi('Utilidad', money(a.utilidad), `venta − costo ${money(a.costo)} − gastos ${money(a.gastos)}`, compara(a.utilidad, b.utilidad), a.utilidad < 0 ? 'var(--ocup)' : 'var(--libre)')}
    ${kpi('Efectivo en caja', money(efectivoCaja(d)), 'cobros − cambio − gastos en efectivo')}
    ${kpi('Cancelaciones', a.canceladas, a.canceladas ? money(a.canceladoTotal) + ' cancelado' : 'ninguna', compara(a.canceladas, b.canceladas, true), a.canceladas ? 'var(--ocup)' : '')}</div>
  <div class="cw-datos">${[
    top ? `<div>${miniP(top.paquete)} <b>El más vendido:</b> Paquete ${esc(top.paquete)} · ${esc(top.nombre)} (${top.n} carros)</div>` : '',
    pico.carros ? `<div>${icoCW('reloj')}<b>Hora pico:</b> ${horaTxt(pico.hora)} a ${horaTxt((pico.hora + 1) % 24)} (${pico.carros} carros)</div>` : '',
    sem && R.resumen.dias >= 7 ? `<div>${icoCW('calendario')}<b>Mejor día de la semana:</b> ${DIAS_SEM[sem.dia]} (${ent0(sem.prom)} carros en promedio)</div>` : '',
    mejorDia && R.porDia.length > 1 ? `<div>${icoCW('estrella')}<b>Mejor día:</b> ${fd(mejorDia.dia)} · ${mejorDia.carros} carros · ${money(mejorDia.total)}</div>` : '',
    R.conPlacas ? `<div>${icoCW('car')}<b>${R.conPlacas}</b> vehículos distintos con placas · ${R.regresaron ?? R.clientes.filter((c) => c.visitas > 1).length} regresaron más de una vez</div>` : ''].join('') || '<div class="sub">Aún no hay ventas en estas fechas.</div>'}</div>
  <div class="cols"><div class="card"><h2>${diasCols ? 'Carros por día' : 'Paquetes vendidos'}</h2>${diasCols ? columnas(diasCols) : (R.paquetes.porPaquete.length ? barras(R.paquetes.porPaquete.map((x) => ({ l: x.nombre, v: x.n, sub: money(x.total), c: colorDe(x.paquete), mini: miniP(x.paquete) }))) : '<div class="empty">Sin paquetes vendidos.</div>')}</div>
    <div class="card"><h2>Formas de pago</h2>${R.pagos.length ? `<div class="kv">${R.pagos.map((p) => `<span>${MET[p.metodo] || p.metodo} (${p.tickets})</span><b>${money(p.monto)}${p.usd ? ` <small class="sub">US$${p.usd.toFixed(2)}</small>` : ''}</b>`).join('')}<span><b>Total</b></span><b>${money(R.pagos.reduce((t, p) => t + p.monto, 0))}</b>${R.pagos.some((p) => p.cambio) ? `<span>Cambio entregado</span><b>${money(R.pagos.reduce((t, p) => t + p.cambio, 0))}</b>` : ''}</div>` : '<div class="empty">Sin cobros.</div>'}
      <h2 style="margin-top:16px">Productos por surtir</h2>${(() => { const l = R.existencias.filter((x) => x.existencia <= x.minimo); return l.length ? `<div class="kv">${l.map((p) => `<span>${esc(p.nombre)}</span><b style="color:${p.existencia <= 0 ? 'var(--ocup)' : 'inherit'}">${p.existencia} / mín. ${p.minimo}</b>`).join('')}</div>` : '<div class="empty">Todo arriba del mínimo.</div>'; })()}</div></div>`;
}

// ---------- Paquetes ----------
function rPaquetes() {
  const k = R.paquetes, tot = k.carros || 1, vehs = [...new Set(R.vehPaq.map((x) => x.vehiculo))], nums = k.porPaquete.map((x) => x.paquete);
  $('#repc').innerHTML = `<div class="cols"><div class="card"><h2>Carros por paquete · ${k.carros}</h2>${k.porPaquete.length ? barras(k.porPaquete.map((x) => ({ l: x.nombre, v: x.n, sub: `${money(x.total)} · ${pctTxt(x.n / tot * 100)}`, c: colorDe(x.paquete), mini: miniP(x.paquete) }))) : '<div class="empty">No se vendieron paquetes en estas fechas.</div>'}</div>
    <div class="card"><h2>Dinero por paquete · ${money(k.totalPaquetes)}</h2>${k.porPaquete.length ? barras(k.porPaquete.slice().sort((a, b) => b.total - a.total).map((x) => ({ l: 'Paquete ' + x.paquete, v: x.total, sub: pctTxt(x.total / (k.totalPaquetes || 1) * 100), c: colorDe(x.paquete), mini: miniP(x.paquete) })), money) : '<div class="empty">—</div>'}</div></div>
  <div class="card"><h2>Detalle por paquete</h2><div class="tw"><table><thead><tr><th>Paquete</th><th>Nombre</th><th class="n">Carros</th><th class="n">% de carros</th><th class="n">Venta</th><th class="n">Precio promedio</th><th class="n">Por día</th></tr></thead><tbody>
    ${k.porPaquete.map((x) => `<tr><td>${miniP(x.paquete)}</td><td><b>${esc(x.nombre)}</b></td><td class="n"><b>${x.n}</b></td><td class="n">${pctTxt(x.n / tot * 100)}</td><td class="n">${money(x.total)}</td><td class="n">${money(x.total / (x.n || 1))}</td><td class="n">${ent0(x.n / R.resumen.dias)}</td></tr>`).join('') || '<tr><td colspan="7" class="empty">Sin datos.</td></tr>'}</tbody></table></div></div>
  ${vehs.length && nums.length ? `<div class="card"><h2>Qué paquete pide cada tipo de vehículo</h2><div class="tw"><table><thead><tr><th>Vehículo</th>${nums.map((n) => `<th class="n">${miniP(n)}</th>`).join('')}<th class="n">Total</th></tr></thead><tbody>
    ${vehs.map((v) => { const f = R.vehPaq.filter((x) => x.vehiculo === v); return `<tr><td><b>${esc(v)}</b></td>${nums.map((n) => `<td class="n">${f.find((x) => x.paquete === n)?.n || ''}</td>`).join('')}<td class="n"><b>${f.reduce((t, x) => t + x.n, 0)}</b></td></tr>`; }).join('')}</tbody></table></div></div>` : ''}
  ${R.porDia.length > 1 ? `<div class="card"><h2>Carros por día y paquete</h2><div class="tw" style="max-height:420px"><table><thead><tr><th>Día</th>${nums.map((n) => `<th class="n">${miniP(n)}</th>`).join('')}<th class="n">Carros</th><th class="n">Venta del día</th></tr></thead><tbody>
    ${R.porDia.slice().reverse().map((dd) => { const f = k.porDia.filter((x) => x.dia === dd.dia); return `<tr><td>${DIAS_SEM[aF(dd.dia).getDay()].slice(0, 3)} ${fd(dd.dia)}</td>${nums.map((n) => `<td class="n">${f.find((x) => x.paquete === n)?.n || ''}</td>`).join('')}<td class="n"><b>${dd.carros}</b></td><td class="n">${money(dd.total)}</td></tr>`; }).join('')}</tbody></table></div></div>` : ''}`;
}

// ---------- Horas y días ----------
function rHoras() {
  const hs = R.porHora.filter((x) => x.tickets || (x.hora >= 7 && x.hora <= 20));
  const pico = R.porHora.reduce((m, x) => (x.carros > m.carros ? x : m), { carros: 0, hora: -1 });
  const sem = [1, 2, 3, 4, 5, 6, 0].map((i) => R.porSemana[i]);
  const mejor = sem.reduce((m, x) => ((x.fechas ? x.carros / x.fechas : 0) > (m.p || 0) ? { ...x, p: x.carros / x.fechas } : m), {});
  $('#repc').innerHTML = `<div class="card"><h2>Carros por hora del día</h2><p class="sub" style="margin-top:0">Sirve para saber a qué hora poner más lavadores. ${pico.carros ? `La hora pico es de <b>${horaTxt(pico.hora)} a ${horaTxt((pico.hora + 1) % 24)}</b>.` : ''}</p>
    ${columnas(hs.map((x) => ({ l: horaTxt(x.hora).replace(' ', ''), t: horaTxt(x.hora), v: x.carros, on: x.hora === pico.hora })), ent0, 200)}</div>
  <div class="cols"><div class="card"><h2>Carros promedio por día de la semana</h2>${R.resumen.dias < 7 ? '<p class="sub" style="margin-top:0">Elija una semana o un mes para comparar los días.</p>' : ''}
      ${columnas(sem.map((x) => ({ l: DIAS_SEM[x.dia].slice(0, 3), t: DIAS_SEM[x.dia], v: x.fechas ? +(x.carros / x.fechas).toFixed(1) : 0, on: x.dia === mejor.dia })), ent0, 170)}</div>
    <div class="card"><h2>Venta por día de la semana</h2><div class="tw"><table><thead><tr><th>Día</th><th class="n">Días trabajados</th><th class="n">Carros</th><th class="n">Promedio carros</th><th class="n">Venta</th><th class="n">Venta promedio</th></tr></thead><tbody>
      ${sem.map((x) => `<tr><td><b>${DIAS_SEM[x.dia]}</b></td><td class="n">${x.fechas}</td><td class="n">${x.carros}</td><td class="n">${x.fechas ? ent0(x.carros / x.fechas) : '—'}</td><td class="n">${money(x.total)}</td><td class="n">${x.fechas ? money(x.total / x.fechas) : '—'}</td></tr>`).join('')}</tbody></table></div></div></div>
  <div class="card"><h2>Detalle por hora</h2><div class="tw"><table><thead><tr><th>Hora</th><th class="n">Tickets</th><th class="n">Carros</th><th class="n">Venta</th></tr></thead><tbody>
    ${R.porHora.filter((x) => x.tickets).map((x) => `<tr><td>${horaTxt(x.hora)} a ${horaTxt((x.hora + 1) % 24)}</td><td class="n">${x.tickets}</td><td class="n"><b>${x.carros}</b></td><td class="n">${money(x.total)}</td></tr>`).join('') || '<tr><td colspan="4" class="empty">Sin ventas.</td></tr>'}</tbody></table></div></div>`;
}

// ---------- Vehículos y clientes ----------
function rClientes() {
  const L = R.clientes, frec = L.filter((c) => c.visitas > 1);
  $('#repc').innerHTML = `<div class="cols"><div class="card"><h2>Carros por tipo de vehículo</h2>${R.porVehiculo.length ? barras(R.porVehiculo.map((x) => ({ l: x.vehiculo, v: x.carros, sub: money(x.total), c: x.vehiculo === 'Sin especificar' ? 'var(--line)' : 'var(--accent)' }))) : '<div class="empty">Sin datos.</div>'}
      <p class="sub">Toque el tipo de vehículo al cobrar para que este reporte salga completo.</p></div>
    <div class="card"><h2>Clientes con placas</h2><div class="kv"><span>Vehículos distintos</span><b>${R.conPlacas}</b><span>Regresaron 2 veces o más</span><b>${frec.length}</b><span>Venta de clientes que regresan</span><b>${money(frec.reduce((t, c) => t + c.total, 0))}</b></div>
      <p class="sub">Para que salgan sus clientes frecuentes, escriba las placas en cada venta.</p></div></div>
  <div class="card"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px"><h2 style="margin:0">Clientes frecuentes (por placas)</h2><input id="cBus" placeholder="Buscar placas" style="width:200px" oninput="cwClientes(this.value)"></div>
    <div class="tw" style="max-height:480px"><table><thead><tr><th>Placas</th><th>Vehículo</th><th class="n">Visitas</th><th>Paquete favorito</th><th class="n">Gastó</th><th>Última visita</th><th></th></tr></thead><tbody id="cLista"></tbody></table></div></div>`;
  cwClientes('');
}
function cwClientes(q) {
  q = String(q || '').trim().toUpperCase();
  $('#cLista').innerHTML = R.clientes.filter((c) => !q || c.placas.includes(q)).map((c) => `<tr><td class="mono"><b>${esc(c.placas)}</b></td><td>${esc(c.vehiculo || '')}</td><td class="n"><b>${c.visitas}</b></td><td>${c.paquete ? miniP(c.paquete) : ''}</td><td class="n">${money(c.total)}</td><td>${fdt(c.ultimo)}</td>
    <td><button class="btn sm" data-p="${esc(c.placas)}" onclick="cwHistorial(this.dataset.p)">Historial</button></td></tr>`).join('') || '<tr><td colspan="7" class="empty">No hay ventas con placas en estas fechas.</td></tr>';
}
async function cwHistorial(placas) {
  const l = await hacer(() => GET('/api/placas/' + encodeURIComponent(placas)));
  modal('Historial de ' + esc(placas), `<div class="tw" style="max-height:460px"><table><thead><tr><th>Fecha</th><th>Folio</th><th>Vehículo</th><th>Qué se le hizo</th><th>Cobró</th><th class="n">Total</th></tr></thead><tbody>
    ${l.map((x) => `<tr style="${x.cancelada ? 'opacity:.5;text-decoration:line-through' : ''}"><td>${fdt(x.fecha)}</td><td class="mono">${esc(x.folio)}</td><td>${esc(x.vehiculo || '')}</td><td>${esc(x.detalle || '')}</td><td>${esc(x.usuario || '')}</td><td class="n">${money(x.total)}</td></tr>`).join('')}</tbody></table></div>
    <div class="sub" style="margin-top:8px">${l.filter((x) => !x.cancelada).length} visitas · ${money(l.filter((x) => !x.cancelada).reduce((t, x) => t + x.total, 0))} en total (todas las fechas)</div>`, '<button class="btn" onclick="cerrar()">Cerrar</button>', true);
}

// ---------- Cajeros y cancelaciones ----------
function rCajeros() {
  const C = R.canceladas;
  $('#repc').innerHTML = `<div class="card"><h2>Ventas por cajero</h2><div class="tw"><table><thead><tr><th>Cajero</th><th class="n">Tickets</th><th class="n">Carros</th><th class="n">Venta</th><th class="n">Ticket promedio</th><th class="n">Canceladas</th></tr></thead><tbody>
    ${R.porCajero.map((x) => `<tr><td><b>${esc(x.cajero)}</b></td><td class="n">${x.tickets}</td><td class="n">${x.carros}</td><td class="n"><b>${money(x.total)}</b></td><td class="n">${money(x.total / (x.tickets || 1))}</td><td class="n" style="color:${x.canceladas ? 'var(--ocup)' : 'inherit'};font-weight:${x.canceladas ? 700 : 400}">${x.canceladas}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">Sin ventas.</td></tr>'}</tbody></table></div></div>
  <div class="card"><h2>Ventas canceladas · ${C.length}${C.length ? ' · ' + money(C.reduce((t, x) => t + x.total, 0)) : ''}</h2>
    <p class="sub" style="margin-top:0">Revise cada cancelación contra la cámara: una venta cobrada y luego cancelada puede ser dinero que no entró a la caja.</p>
    <div class="tw"><table><thead><tr><th>Venta</th><th>Folio</th><th>Paquete</th><th>Placas</th><th>Qué llevaba</th><th>Vendió</th><th>Canceló</th><th>Motivo</th><th class="n">Total</th></tr></thead><tbody>
    ${C.map((x) => `<tr><td>${fdt(x.fecha)}</td><td class="mono">${esc(x.folio)}</td><td>${(x.paquetes || '').split(' ').filter(Boolean).map((p) => miniP(p.slice(1))).join(' ')}</td><td class="mono">${esc(x.placas || '')}</td><td>${esc(x.detalle || '')}</td><td>${esc(x.vendio || '')}</td>
      <td>${esc(x.cancelo || '—')}${x.cancelo_fecha ? `<div class="sub">${fdt(x.cancelo_fecha)}</div>` : ''}</td><td>${esc(x.cancelo_motivo || '')}</td><td class="n" style="color:var(--ocup)"><b>${money(x.total)}</b></td></tr>`).join('') || '<tr><td colspan="9" class="empty">No hubo cancelaciones.</td></tr>'}</tbody></table></div></div>`;
}

// ---------- Productos e inventario ----------
let pFiltro = 'todo';
function rProductos() {
  const A = R.articulos.filter((x) => pFiltro === 'todo' || x.tipo === pFiltro), T = { paquete: 'Paquete', servicio: 'Servicio extra', producto: 'Producto' };
  const ex = R.existencias, valor = ex.reduce((t, x) => t + x.valor, 0), surtir = ex.filter((x) => x.existencia <= x.minimo);
  $('#repc').innerHTML = `<div class="card"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px"><h2 style="margin:0">Lo que más se vende</h2>
      <div class="chips areas">${[['todo', 'Todo'], ['paquete', 'Paquetes'], ['servicio', 'Servicios extra'], ['producto', 'Productos']].map(([k, n]) => `<button class="chip ${pFiltro === k ? 'on' : ''}" onclick="pFiltro='${k}';rProductos()">${n}</button>`).join('')}</div></div>
    <div class="tw" style="max-height:460px"><table><thead><tr><th>#</th><th>Artículo</th><th>Tipo</th><th class="n">Cantidad</th><th class="n">Venta</th><th class="n">Costo</th><th class="n">Utilidad</th><th class="n">Margen</th></tr></thead><tbody>
    ${A.map((x, i) => `<tr><td class="sub">${i + 1}</td><td>${x.paquete ? miniP(x.paquete) + ' ' : ''}<b>${esc(x.descripcion)}</b></td><td>${T[x.tipo]}</td><td class="n">${ent0(x.cantidad)}</td><td class="n"><b>${money(x.importe)}</b></td><td class="n">${money(x.costo)}</td><td class="n" style="color:${x.utilidad < 0 ? 'var(--ocup)' : 'var(--libre)'}">${money(x.utilidad)}</td><td class="n">${x.importe ? pctTxt(x.utilidad / x.importe * 100) : '—'}</td></tr>`).join('') || '<tr><td colspan="8" class="empty">Sin ventas.</td></tr>'}</tbody></table></div>
    <p class="sub">El costo de los paquetes es el "costo aproximado" que se pone en cada paquete (jabón, cera, comisión). Si está en $0 la utilidad sale igual a la venta.</p></div>
  <div class="card"><h2>Existencias de hoy · valor a costo ${money(valor)}${surtir.length ? ` · <span style="color:var(--ocup)">${surtir.length} por surtir</span>` : ''}</h2><div class="tw" style="max-height:460px"><table><thead><tr><th>Producto</th><th>Departamento</th><th class="n">Existencia</th><th class="n">Mínimo</th><th class="n">Costo</th><th class="n">Precio</th><th class="n">Valor</th><th>Estado</th></tr></thead><tbody>
    ${ex.map((x) => `<tr><td><b>${esc(x.nombre)}</b></td><td>${esc(x.area || '')}</td><td class="n"><b>${x.existencia}</b></td><td class="n">${x.minimo}</td><td class="n">${money(x.costo)}</td><td class="n">${money(x.precio)}</td><td class="n">${money(x.valor)}</td>
      <td>${x.existencia <= 0 ? '<span class="pill p-bad">Agotado</span>' : x.existencia <= x.minimo ? '<span class="pill p-warn">Surtir</span>' : '<span class="pill p-ok">Bien</span>'}</td></tr>`).join('') || '<tr><td colspan="8" class="empty">Sin productos con inventario.</td></tr>'}</tbody></table></div></div>`;
}

// ---------- Gastos y utilidad ----------
function rGastos() {
  const a = R.resumen;
  $('#repc').innerHTML = `<div class="cols"><div class="card"><h2>Estado de resultados del periodo</h2><div class="kv cw-er">
      <span>Paquetes de lavado</span><b>${money(a.paquetes)}</b><span>Servicios extra</span><b>${money(a.extras)}</b><span>Productos</span><b>${money(a.productos)}</b>
      <span><b>Venta total</b></span><b>${money(a.total)}</b><span>− Costo de lo vendido</span><b>− ${money(a.costo)}</b><span><b>Utilidad bruta</b></span><b>${money(a.utilidadBruta)}</b>
      <span>− Gastos</span><b>− ${money(a.gastos)}</b><span><b>UTILIDAD</b></span><b style="font-size:20px;color:${a.utilidad < 0 ? 'var(--ocup)' : 'var(--libre)'}">${money(a.utilidad)}</b>
      <span>Margen</span><b>${a.total ? pctTxt(a.utilidad / a.total * 100) : '—'}</b><span>Antes (periodo anterior)</span><b>${money(R.anterior.utilidad)} ${compara(a.utilidad, R.anterior.utilidad)}</b></div></div>
    <div class="card"><h2>Gastos por clasificación · ${money(a.gastos)}</h2>${R.gastos.length ? barras(R.gastos.map((g) => ({ l: g.grupo, v: g.t, sub: `${g.n} gasto(s) · ${pctTxt(g.t / (a.gastos || 1) * 100)}`, c: 'var(--ocup)' })), money) : '<div class="empty">Sin gastos en estas fechas.</div>'}
      ${a.carros ? `<p class="sub">Cada carro le costó en gastos <b>${money(a.gastos / a.carros)}</b> y le dejó de utilidad <b>${money(a.utilidad / a.carros)}</b>.</p>` : ''}</div></div>`;
}

// ---------- Revisar con cámara ----------
function rCamara() {
  $('#repc').innerHTML = `<div class="card"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px"><h2 style="margin:0">Cada paquete vendido · ${R.paquetes.lista.length}</h2><input id="rBus" placeholder="Buscar placas, folio, paquete (P2) o cajero" value="${esc(rBus)}" style="width:280px" oninput="rBus=this.value;cwListaRep()"></div>
    <p class="sub" style="margin-top:0">Busque la hora en la grabación: en el ticket y en la pantalla debe verse el mismo número de paquete.</p>
    <div class="tw" style="max-height:560px"><table><thead><tr><th>Hora</th><th>Folio</th><th>Paquete</th><th>Placas</th><th>Vehículo</th><th>Cobró</th><th>Pago</th><th class="n">Total ticket</th></tr></thead><tbody id="rLista"></tbody></table></div></div>`;
  cwListaRep();
}
function cwListaRep() {
  const q = rBus.trim().toLowerCase(), L = (R?.paquetes.lista || []).filter((x) => !q || [x.folio, x.placas, x.vehiculo, 'p' + x.paquete, x.usuario].join(' ').toLowerCase().includes(q));
  const el = $('#rLista'); if (!el) return;
  el.innerHTML = L.map((x) => `<tr><td>${fdt(x.fecha)}</td><td class="mono">${esc(x.folio)}</td><td>${miniP(x.paquete)}${x.cantidad > 1 ? ' ×' + x.cantidad : ''}</td><td class="mono"><b>${esc(x.placas || '')}</b></td><td>${esc(x.vehiculo || '')}</td><td>${esc(x.usuario || '')}</td><td>${MET[x.metodo] || x.metodo}</td><td class="n">${money(x.total)}</td></tr>`).join('') || '<tr><td colspan="8" class="empty">Sin ventas de paquetes.</td></tr>';
}

// ---------- Corte en ticket ----------
imprimirCorte = function () {
  const d = vRep.d, a = R.resumen, k = R.paquetes, w = W(), raya = '-'.repeat(w);
  imprimir([...encabezado(), 'CORTE ' + fd(R.desde) + (R.desde !== R.hasta ? ' al ' + fd(R.hasta) : ''), raya, 'PAQUETES VENDIDOS', ...k.porPaquete.map((x) => lin(`Paquete ${x.paquete} (${x.n})`, money(x.total))), lin(`CARROS LAVADOS (${k.carros})`, money(k.totalPaquetes)), raya,
    lin('Servicios extra', money(a.extras)), lin('Productos', money(a.productos)), lin('VENTA TOTAL', money(a.total)), lin('Tickets', a.tickets), lin('Ticket promedio', money(a.ticketPromedio)), raya,
    ...R.pagos.map((p) => lin(MET[p.metodo] || p.metodo, money(p.monto))), raya, ...R.porCajero.map((c) => lin(`${c.cajero} (${c.carros})`, money(c.total))), raya,
    ...(a.canceladas ? [lin(`CANCELADAS (${a.canceladas})`, money(a.canceladoTotal))] : []), lin('Gastos', money(a.gastos)), lin('Utilidad', money(a.utilidad)), lin('EFECTIVO EN CAJA', money(efectivoCaja(d))), '', 'Impreso ' + new Date().toLocaleString('es-MX')]);
};

// ---------- PDF (hoja carta) ----------
function cwPdfRep() {
  const a = R.resumen, b = R.anterior, k = R.paquetes, per = R.desde === R.hasta ? fd(R.desde) : `${fd(R.desde)} al ${fd(R.hasta)}`;
  const cmpT = (x, y) => (y ? `${x >= y ? '+' : ''}${pctTxt((x - y) / y * 100)}` : '—');
  const tabla = (cab, filas) => `<table class="cw-pdf-t"><thead><tr>${cab.map((c) => `<th>${c}</th>`).join('')}</tr></thead><tbody>${filas.map((f) => `<tr>${f.map((c) => `<td>${c}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${cab.length}">Sin datos</td></tr>`}</tbody></table>`;
  const html = `<div class="cw-pdf"><div class="cw-pdf-cab"><div><h1>${esc(CFG.hotel_nombre)}</h1><div>Reporte de ventas · ${per}</div></div><div style="text-align:right">Impreso ${new Date().toLocaleString('es-MX')}<br>Maxsel Carwash</div></div>
    <h2>Resumen</h2>${tabla(['Concepto', 'Este periodo', 'Periodo anterior', 'Cambio'], [['Carros lavados', ent0(a.carros), ent0(b.carros), cmpT(a.carros, b.carros)], ['Venta total', money(a.total), money(b.total), cmpT(a.total, b.total)], ['Tickets', a.tickets, b.tickets, cmpT(a.tickets, b.tickets)],
      ['Ticket promedio', money(a.ticketPromedio), money(b.ticketPromedio), cmpT(a.ticketPromedio, b.ticketPromedio)], ['Paquetes de lavado', money(a.paquetes), money(b.paquetes), cmpT(a.paquetes, b.paquetes)], ['Servicios extra', money(a.extras), money(b.extras), cmpT(a.extras, b.extras)],
      ['Productos', money(a.productos), money(b.productos), cmpT(a.productos, b.productos)], ['Carros con venta adicional', pctTxt(a.pctExtra), pctTxt(b.pctExtra), ''], ['Costo de lo vendido', money(a.costo), money(b.costo), ''], ['Gastos', money(a.gastos), money(b.gastos), cmpT(a.gastos, b.gastos)],
      ['<b>Utilidad</b>', `<b>${money(a.utilidad)}</b>`, money(b.utilidad), cmpT(a.utilidad, b.utilidad)], ['Cancelaciones', `${a.canceladas} · ${money(a.canceladoTotal)}`, `${b.canceladas} · ${money(b.canceladoTotal)}`, '']])}
    <div class="cw-pdf-2"><div><h2>Paquetes vendidos</h2>${tabla(['Paquete', 'Nombre', 'Carros', '%', 'Venta'], k.porPaquete.map((x) => [`<b>P${esc(x.paquete)}</b>`, esc(x.nombre), x.n, pctTxt(x.n / (k.carros || 1) * 100), money(x.total)]))}</div>
      <div><h2>Formas de pago</h2>${tabla(['Forma', 'Tickets', 'Monto'], R.pagos.map((p) => [MET[p.metodo] || p.metodo, p.tickets, money(p.monto) + (p.usd ? ` (US$${p.usd.toFixed(2)})` : '')]))}
      <h2>Por cajero</h2>${tabla(['Cajero', 'Carros', 'Venta', 'Canc.'], R.porCajero.map((c) => [esc(c.cajero), c.carros, money(c.total), c.canceladas]))}</div></div>
    <div class="cw-pdf-2"><div><h2>Horas pico</h2>${tabla(['Hora', 'Carros', 'Venta'], R.porHora.filter((x) => x.tickets).sort((x, y) => y.carros - x.carros).slice(0, 8).map((x) => [`${horaTxt(x.hora)} a ${horaTxt((x.hora + 1) % 24)}`, x.carros, money(x.total)]))}</div>
      <div><h2>Días de la semana (promedio)</h2>${tabla(['Día', 'Carros prom.', 'Venta prom.'], [1, 2, 3, 4, 5, 6, 0].map((i) => R.porSemana[i]).filter((x) => x.fechas).map((x) => [DIAS_SEM[x.dia], ent0(x.carros / x.fechas), money(x.total / x.fechas)]))}</div></div>
    <h2>Lo más vendido</h2>${tabla(['Artículo', 'Cantidad', 'Venta', 'Costo', 'Utilidad'], R.articulos.slice(0, 15).map((x) => [esc((x.paquete ? 'P' + x.paquete + ' · ' : '') + x.descripcion), ent0(x.cantidad), money(x.importe), money(x.costo), money(x.utilidad)]))}
    ${R.canceladas.length ? `<h2>Cancelaciones</h2>${tabla(['Fecha', 'Folio', 'Qué llevaba', 'Vendió', 'Canceló', 'Motivo', 'Total'], R.canceladas.map((x) => [fdt(x.fecha), x.folio, esc(x.detalle || ''), esc(x.vendio || ''), esc(x.cancelo || ''), esc(x.cancelo_motivo || ''), money(x.total)]))}` : ''}
    <div class="cw-pdf-2"><div><h2>Gastos</h2>${tabla(['Clasificación', 'Gastos', 'Monto'], R.gastos.map((g) => [esc(g.grupo), g.n, money(g.t)]))}</div>
      <div><h2>Por surtir</h2>${tabla(['Producto', 'Hay', 'Mínimo'], R.existencias.filter((x) => x.existencia <= x.minimo).map((x) => [esc(x.nombre), x.existencia, x.minimo]))}</div></div>
    ${R.lavadores?.lavadores?.length ? `<h2>Lavadores y comisiones</h2>${tabla(['Lavador', 'Carros', 'Minutos', 'Vendido', 'Comisión', 'Pagada', 'Pendiente'], R.lavadores.lavadores.map((x) => [esc(x.nombre), x.carros, x.minutos, money(x.vendido), money(x.generada), money(x.pagada), `<b>${money(x.pendiente)}</b>`]))}` : ''}</div>`;
  imprimirDoc(html, 'carta', 'Reporte del autolavado');
}

// ---------- Excel ----------
function cwExcelRep() {
  const a = R.resumen, b = R.anterior, k = R.paquetes;
  const resumen = [H_('Concepto', 'Este periodo', 'Periodo anterior'), ['Periodo', R.desde + ' al ' + R.hasta, b.desde + ' al ' + b.hasta], ['Carros lavados', a.carros, b.carros], ['Tickets', a.tickets, b.tickets],
    [B_('Venta total'), BM_(a.total), M_(b.total)], ['Paquetes de lavado', M_(a.paquetes), M_(b.paquetes)], ['Servicios extra', M_(a.extras), M_(b.extras)], ['Productos', M_(a.productos), M_(b.productos)],
    ['Ticket promedio', M_(a.ticketPromedio), M_(b.ticketPromedio)], ['% carros con venta adicional', a.pctExtra, b.pctExtra], ['Costo de lo vendido', M_(a.costo), M_(b.costo)], ['Gastos', M_(a.gastos), M_(b.gastos)],
    [B_('Utilidad'), BM_(a.utilidad), M_(b.utilidad)], ['Cancelaciones', a.canceladas, b.canceladas], ['Monto cancelado', M_(a.canceladoTotal), M_(b.canceladoTotal)], [], H_('Forma de pago', 'Tickets', 'Monto', 'Dólares'), ...R.pagos.map((p) => [MET[p.metodo] || p.metodo, p.tickets, M_(p.monto), U_(p.usd)])];
  const nums = k.porPaquete.map((x) => x.paquete);
  descargarArchivo(XLSX.libro([
    { nombre: 'Resumen', filas: resumen },
    { nombre: 'Paquetes', filas: [H_('Paquete', 'Nombre', 'Carros', 'Venta', 'Precio promedio'), ...k.porPaquete.map((x) => ['P' + x.paquete, x.nombre, x.n, M_(x.total), M_(x.total / (x.n || 1))])] },
    { nombre: 'Por día', filas: [H_('Día', ...nums.map((n) => 'P' + n), 'Carros', 'Tickets', 'Venta'), ...R.porDia.map((dd) => { const f = k.porDia.filter((x) => x.dia === dd.dia); return [dd.dia, ...nums.map((n) => f.find((x) => x.paquete === n)?.n || 0), dd.carros, dd.tickets, M_(dd.total)]; })] },
    { nombre: 'Por hora', filas: [H_('Hora', 'Tickets', 'Carros', 'Venta'), ...R.porHora.filter((x) => x.tickets).map((x) => [horaTxt(x.hora), x.tickets, x.carros, M_(x.total)])] },
    { nombre: 'Día de la semana', filas: [H_('Día', 'Días trabajados', 'Carros', 'Venta', 'Carros promedio', 'Venta promedio'), ...[1, 2, 3, 4, 5, 6, 0].map((i) => R.porSemana[i]).map((x) => [DIAS_SEM[x.dia], x.fechas, x.carros, M_(x.total), x.fechas ? +(x.carros / x.fechas).toFixed(1) : 0, M_(x.fechas ? x.total / x.fechas : 0)])] },
    { nombre: 'Vehículos', filas: [H_('Vehículo', 'Carros', 'Venta'), ...R.porVehiculo.map((x) => [x.vehiculo, x.carros, M_(x.total)])] },
    { nombre: 'Clientes', filas: [H_('Placas', 'Vehículo', 'Visitas', 'Paquete favorito', 'Gastó', 'Última visita'), ...R.clientes.map((c) => [c.placas, c.vehiculo || '', c.visitas, c.paquete ? 'P' + c.paquete : '', M_(c.total), c.ultimo])] },
    { nombre: 'Cajeros', filas: [H_('Cajero', 'Tickets', 'Carros', 'Venta', 'Canceladas'), ...R.porCajero.map((c) => [c.cajero, c.tickets, c.carros, M_(c.total), c.canceladas])] },
    { nombre: 'Cancelaciones', filas: [H_('Fecha', 'Folio', 'Paquetes', 'Placas', 'Qué llevaba', 'Vendió', 'Canceló', 'Fecha cancelación', 'Motivo', 'Total'), ...R.canceladas.map((x) => [x.fecha, x.folio, x.paquetes || '', x.placas || '', x.detalle || '', x.vendio || '', x.cancelo || '', x.cancelo_fecha || '', x.cancelo_motivo || '', M_(x.total)])] },
    { nombre: 'Artículos', filas: [H_('Artículo', 'Tipo', 'Cantidad', 'Venta', 'Costo', 'Utilidad'), ...R.articulos.map((x) => [(x.paquete ? 'P' + x.paquete + ' ' : '') + x.descripcion, x.tipo, x.cantidad, M_(x.importe), M_(x.costo), M_(x.utilidad)])] },
    { nombre: 'Existencias', filas: [H_('Producto', 'Departamento', 'Existencia', 'Mínimo', 'Costo', 'Precio', 'Valor'), ...R.existencias.map((x) => [x.nombre, x.area || '', x.existencia, x.minimo, M_(x.costo), M_(x.precio), M_(x.valor)])] },
    { nombre: 'Gastos', filas: [H_('Clasificación', 'Gastos', 'Monto'), ...R.gastos.map((g) => [g.grupo, g.n, M_(g.t)])] },
    { nombre: 'Lavadores', filas: [H_('Lavador', 'Carros', 'Minutos', 'Vendido', 'Comisión', 'Pagada', 'Pendiente'), ...(R.lavadores?.lavadores || []).map((x) => [x.nombre, x.carros, x.minutos, M_(x.vendido), M_(x.generada), M_(x.pagada), M_(x.pendiente)]), ['Carros sin lavador', R.lavadores?.sinLavador || 0]] },
    { nombre: 'Paquetes vendidos', filas: [H_('Fecha', 'Folio', 'Paquete', 'Cantidad', 'Placas', 'Vehículo', 'Cobró', 'Pago', 'Total ticket'), ...k.lista.map((x) => [x.fecha, x.folio, 'P' + x.paquete, x.cantidad, x.placas || '', x.vehiculo || '', x.usuario || '', MET[x.metodo] || x.metodo, M_(x.total)])] },
  ]), `Reporte carwash ${R.desde}${R.desde !== R.hasta ? ' al ' + R.hasta : ''}.xlsx`);
}

// ---------- Cancelar una venta pide el motivo (sale en el reporte de cancelaciones) ----------
cancelarVenta = function (id) {
  modal('Cancelar venta', `<p style="margin-top:0">La venta se cancela, los productos regresan al inventario y queda registrado quién la canceló.</p>
    <label class="l">Motivo de la cancelación (obligatorio)<input id="cMot" maxlength="200" placeholder="Ej. Se cobró el paquete equivocado"></label>`,
  `<button class="btn" onclick="cerrar()">No cancelar</button><button class="btn bad" onclick="cwCancelarOk(${id})">Cancelar venta</button>`);
  $('#cMot').focus();
};
async function cwCancelarOk(id) {
  const m = val('cMot'); if (m.length < 3) return toast('Escriba el motivo de la cancelación', true);
  await hacer(() => POST(`/api/ventas/${id}/cancelar`, { motivo: m }), 'Venta cancelada'); cerrar(); if (vista === 'tienda') vTienda(); else if (vista === 'rep') vRep();
}
