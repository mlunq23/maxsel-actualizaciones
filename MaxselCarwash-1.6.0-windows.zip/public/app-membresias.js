// Maxsel Carwash 1.4 — MEMBRESÍAS DE LAVADO
// Planes (ej. "Mensual ilimitado"), socios reconocidos por sus placas, renovación desde el punto de venta,
// lavado incluido con $0 en el ticket, límite de lavados por día / por periodo, avisos por WhatsApp y resumen.
'use strict';
// Estilos de la membresía en la caja
document.head.insertAdjacentHTML('beforeend', `<style>
.mem-banner{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin:8px 0;padding:8px 12px;border-radius:10px;border:1px solid var(--line);background:var(--panel)}
.mem-banner .i{width:16px;height:16px;vertical-align:-3px}
.mem-ok{border-color:var(--libre);background:var(--libreBg)}.mem-warn{border-color:var(--limp);background:var(--limpBg)}.mem-bad{border-color:var(--ocup);background:var(--ocupBg)}
.mem-nada{justify-content:flex-start;padding:6px 10px}
.pv-tabla tr.mem-fila td{background:var(--libreBg)}
tr.tach td{text-decoration:line-through;opacity:.6}
</style>`);
ICW.socio = '<rect width="20" height="14" x="2" y="5" rx="2"/><circle cx="8" cy="12" r="2.5"/><path d="M14 10h4M14 14h3"/>';
ICONO_VISTA.mem = 'socio';
MET.membresia = 'Membresía';
VISTAS.splice(Math.max(1, VISTAS.findIndex((v) => v[0] === 'tienda') + 1), 0, ['mem', 'Membresías', 'vender|reportes']);
{
  const _ir = ir;
  ir = async function (v) {
    if (v !== 'mem') return _ir(v);
    vista = v; clearInterval(timer); pintarNav(ir.badge);
    try { await vMem(); } catch (e) { if (e.message) $('#main').innerHTML = `<div class="aviso bad">${esc(e.message)}</div>`; }
    if (window.innerWidth < 760) window.scrollTo(0, 0);
  };
}
let memTab = 'socios', memFiltro = '', memBus = '', MPLANES = [], MSOCIOS = [];
const EST_MEM = { vigente: ['Vigente', 'p-ok'], por_vencer: ['Por vencer', 'p-warn'], vencida: ['Vencida', 'p-bad'], sin_pago: ['Sin pagar', ''] };
const pillMem = (e) => `<span class="pill ${EST_MEM[e]?.[1] || ''}">${EST_MEM[e]?.[0] || e}</span>`;
const fFecha = (f) => (f ? f.split('-').reverse().join('/') : '—');
const esMemProd = (p) => !!(p && String(p.codigo || '').startsWith('MEM-'));
const limiteTxt = (p) => [p.por_dia > 0 ? `${p.por_dia} lavado${p.por_dia > 1 ? 's' : ''} por día` : 'sin límite por día', p.por_periodo > 0 ? `máximo ${p.por_periodo} en el periodo` : 'ilimitado en el periodo'].join(' · ');
const paqsTxt = (p) => (p.paquetes ? 'Paquetes ' + p.paquetes.split(',').join(', ') : 'Todos los paquetes');
async function cargarPlanes() { MPLANES = await GET('/api/membresias/planes'); return MPLANES; }

// ======================================================================
// Vista "Membresías": socios, planes y resumen
// ======================================================================
async function vMem() {
  if (!PRODS.length) PRODS = await GET('/api/productos');
  await cargarPlanes();
  const T = [['socios', 'Socios'], ['planes', 'Planes'], ...(puede('reportes') ? [['resumen', 'Resumen']] : [])];
  if (!T.some((t) => t[0] === memTab)) memTab = 'socios';
  const acc = memTab === 'socios' && puede('vender') ? '<button class="btn pri" onclick="socioModal()">Nuevo socio</button>' : memTab === 'planes' && puede('productos') ? '<button class="btn pri" onclick="planModal()">Nuevo plan</button>' : '';
  $('#main').innerHTML = cab('Membresías de lavado', 'Socios que pagan su plan y lavan sin pagar cada vez. En la caja se reconocen por sus placas.', acc)
    + `<div class="tabs" style="margin-bottom:14px">${T.map(([k, n]) => `<button class="${memTab === k ? 'on' : ''}" onclick="memTab='${k}';vMem()">${n}</button>`).join('')}</div><div id="memc"></div>`;
  await ({ socios: memSocios, planes: memPlanes, resumen: memResumen })[memTab]();
}
async function memSocios() {
  MSOCIOS = await GET('/api/membresias/socios');
  const n = (e) => MSOCIOS.filter((s) => s.estado === e).length;
  const F = [['', 'Todos', MSOCIOS.length], ['vigente', 'Vigentes', n('vigente')], ['por_vencer', 'Por vencer', n('por_vencer')], ['vencida', 'Vencidas', n('vencida')], ['sin_pago', 'Sin pagar', n('sin_pago')]];
  $('#memc').innerHTML = `${!MPLANES.length ? `<div class="aviso" style="margin-bottom:12px">Primero cree sus planes de membresía (pestaña <b>Planes</b>): precio, duración y qué paquetes incluye.</div>` : ''}
    <div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:10px"><input id="mB" placeholder="Buscar por nombre, teléfono o placas" value="${esc(memBus)}" style="max-width:320px" oninput="memBus=this.value;memPintar()">
    <div class="tabs">${F.map(([k, t, c]) => `<button class="${memFiltro === k ? 'on' : ''}" onclick="memFiltro='${k}';memPintar()">${t} (${c})</button>`).join('')}</div></div><div id="memL"></div>`;
  memPintar();
}
function memPintar() {
  document.querySelectorAll('#memc .tabs button').forEach((b, i) => b.classList.toggle('on', ['', 'vigente', 'por_vencer', 'vencida', 'sin_pago'][i] === memFiltro));
  const q = memBus.trim().toLowerCase(), qp = q.toUpperCase().replace(/[^0-9A-Z]/g, '');
  const L = MSOCIOS.filter((s) => (!memFiltro || s.estado === memFiltro) && (!q || s.nombre.toLowerCase().includes(q) || String(s.telefono || '').includes(q) || (qp && String(s.placas || '').toUpperCase().replace(/[^0-9A-Z,]/g, '').includes(qp))));
  $('#memL').innerHTML = `<div class="tw"><table><thead><tr><th>Socio</th><th>Placas</th><th>Plan</th><th>Vence</th><th class="n">Lavados hoy</th><th>Estado</th><th></th></tr></thead><tbody>
    ${L.map((s) => `<tr><td><b>${esc(s.nombre)}</b>${s.telefono ? `<div class="sub">${esc(s.telefono)}</div>` : ''}</td><td class="mono">${esc(s.placas || '')}${s.vehiculo ? `<div class="sub">${esc(s.vehiculo)}</div>` : ''}</td>
      <td>${esc(s.plan_nombre || '—')}</td><td>${fFecha(s.vence)}${s.vence && s.dias_restantes >= 0 ? `<div class="sub">${s.dias_restantes === 0 ? 'vence hoy' : 'faltan ' + s.dias_restantes + ' días'}</div>` : ''}</td>
      <td class="n">${s.usos_hoy}${s.plan?.por_dia ? ' / ' + s.plan.por_dia : ''}</td><td>${pillMem(s.estado)}</td>
      <td class="row" style="gap:4px;justify-content:flex-end;flex-wrap:wrap">${puede('vender') ? `<button class="btn sm pri" onclick="memCobrar(${s.id})">${s.estado === 'sin_pago' ? 'Cobrar' : 'Renovar'}</button>` : ''}
        ${s.telefono && s.estado !== 'vigente' ? `<button class="btn sm" onclick="memWhats(${s.id})" title="Mandar aviso por WhatsApp">WhatsApp</button>` : ''}
        <button class="btn sm" onclick="memVer(${s.id})">Ver</button>${puede('vender') ? `<button class="btn sm" onclick="socioModal(${s.id})">Editar</button>` : ''}</td></tr>`).join('')
      || `<tr><td colspan="7" class="empty">${MSOCIOS.length ? 'No hay socios con ese filtro.' : 'Todavía no hay socios. Toque "Nuevo socio" o désdelo de alta al cobrar en la caja.'}</td></tr>`}</tbody></table></div>`;
}
function opcionesPlan(sel) { return MPLANES.map((p) => `<option value="${p.id}" ${Number(sel) === p.id ? 'selected' : ''}>${esc(p.nombre)} · ${money(p.precio)} / ${p.dias} días</option>`).join(''); }
// Alta o edición del socio. alGuardar(socio) se usa desde la caja para seguir cobrando.
function socioModal(id, previo = {}, alGuardar) {
  const s = id ? MSOCIOS.find((x) => x.id === id) || previo : { nombre: '', telefono: '', placas: '', vehiculo: '', plan_id: MPLANES[0]?.id, notas: '', ...previo };
  if (!MPLANES.length) return toast('Primero cree un plan en Membresías → Planes', true);
  socioModal.alGuardar = alGuardar || null;
  modal(id ? 'Editar socio' : 'Nuevo socio', `<div class="f">
    <label class="l">Nombre<input id="sN" value="${esc(s.nombre)}" autocomplete="off"></label>
    <label class="l">Teléfono (WhatsApp)<input id="sT" value="${esc(s.telefono || '')}" inputmode="tel" autocomplete="off"></label>
    <label class="l">Placas (si tiene varios carros, sepárelas con comas)<input id="sP" value="${esc(s.placas || '')}" style="text-transform:uppercase" autocomplete="off"></label>
    <label class="l">Vehículo<input id="sV" value="${esc(s.vehiculo || '')}" placeholder="Ej. Tsuru blanco"></label>
    <label class="l">Plan<select id="sPl">${opcionesPlan(s.plan_id)}</select></label>
    ${id && puede('productos') ? `<label class="l">Vence (solo para corregir)<input id="sVe" type="date" value="${esc(s.vence || '')}"></label>` : ''}
    <label class="l" style="grid-column:1/-1">Notas<input id="sNo" value="${esc(s.notas || '')}"></label></div>
    ${id ? '' : '<p class="sub">Al guardar se cobra la membresía en la caja para que quede vigente.</p>'}`,
  `${id && puede('productos') ? `<button class="btn bad" onclick="confirmar(this,()=>socioBaja(${id}))">Dar de baja</button>` : ''}<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="socioOk(${id || 0})">${id ? 'Guardar' : 'Guardar y cobrar'}</button>`);
}
async function socioOk(id) {
  const b = { nombre: val('sN'), telefono: val('sT'), placas: val('sP'), vehiculo: val('sV'), plan_id: val('sPl'), notas: val('sNo') };
  if ($('#sVe')) b.vence = val('sVe');
  const s = await hacer(() => (id ? PUT('/api/membresias/socios/' + id, b) : POST('/api/membresias/socios', b)), id ? 'Socio guardado' : 'Socio dado de alta');
  cerrar();
  const fn = socioModal.alGuardar; socioModal.alGuardar = null;
  if (fn) return fn(s);
  if (!id && s?.id) return memCobrar(s.id, s);
  if (vista === 'mem') vMem();
}
async function socioBaja(id) { await hacer(() => DEL('/api/membresias/socios/' + id), 'Socio dado de baja'); cerrar(); vMem(); }
async function memVer(id) {
  const s = await GET('/api/membresias/socios/' + id);
  modal(esc(s.nombre), `<div class="kv"><span>Placas</span><b class="mono">${esc(s.placas || '—')}</b><span>Plan</span><b>${esc(s.plan_nombre || '—')}</b>
    <span>Estado</span><b>${pillMem(s.estado)}</b><span>Vence</span><b>${fFecha(s.vence)}</b><span>Lavados hoy</span><b>${s.usos_hoy}</b><span>Lavados en este periodo</span><b>${s.usos_periodo}</b>
    ${s.plan ? `<span>Incluye</span><b>${esc(paqsTxt(s.plan))} · ${esc(limiteTxt(s.plan))}</b>` : ''}${s.motivo && s.estado !== 'sin_pago' ? `<span>Aviso</span><b>${esc(s.motivo)}</b>` : ''}</div>
    <h3 style="margin:14px 0 6px">Pagos</h3><div class="tw"><table><thead><tr><th>Fecha</th><th>Folio</th><th>Plan</th><th>Periodo</th><th class="n">Monto</th></tr></thead><tbody>
    ${s.pagos.map((p) => `<tr class="${p.cancelado ? 'tach' : ''}"><td>${fdt(p.fecha)}</td><td>${esc(p.folio || '')}</td><td>${esc(p.plan || '')}${p.periodos > 1 ? ' ×' + p.periodos : ''}</td><td>${fFecha(p.desde)} al ${fFecha(p.hasta)}${p.cancelado ? ' (cancelado)' : ''}</td><td class="n">${money(p.monto)}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">Sin pagos</td></tr>'}</tbody></table></div>
    <h3 style="margin:14px 0 6px">Lavados usados</h3><div class="tw" style="max-height:260px"><table><thead><tr><th>Fecha</th><th>Paquete</th><th>Placas</th><th>Cajero</th><th class="n">Valor</th></tr></thead><tbody>
    ${s.usos.map((x) => `<tr class="${x.cancelado ? 'tach' : ''}"><td>${fdt(x.fecha)}</td><td>P${esc(x.paquete || '')}</td><td class="mono">${esc(x.placas || '')}</td><td>${esc(x.usuario || '')}</td><td class="n">${money(x.valor)}${x.cancelado ? ' (cancelado)' : ''}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">Todavía no ha usado lavados</td></tr>'}</tbody></table></div>`,
  `${s.telefono ? `<button class="btn" onclick="memWhats(${s.id})">WhatsApp</button>` : ''}${puede('vender') ? `<button class="btn pri" onclick="memCobrar(${s.id})">${s.estado === 'sin_pago' ? 'Cobrar' : 'Renovar'}</button>` : ''}<button class="btn" onclick="cerrar()">Cerrar</button>`, true);
}
// Aviso por WhatsApp: abre el chat con el mensaje listo
function memWhats(id) {
  const s = MSOCIOS.find((x) => x.id === id); if (!s?.telefono) return toast('El socio no tiene teléfono', true);
  let tel = String(s.telefono).replace(/\D/g, ''); if (tel.length === 10) tel = '52' + tel;
  const neg = CFG.hotel_nombre || 'el autolavado';
  const msg = s.estado === 'vencida' ? `Hola ${s.nombre}, su membresía de lavado en ${neg} venció el ${fFecha(s.vence)}. Renuévela en su próxima visita y siga lavando sin pagar cada vez.`
    : s.estado === 'por_vencer' ? `Hola ${s.nombre}, le recordamos que su membresía de lavado en ${neg} vence el ${fFecha(s.vence)}. Renuévela en caja para no perder sus lavados.`
      : `Hola ${s.nombre}, gracias por ser socio de ${neg}. Su membresía está vigente hasta el ${fFecha(s.vence)}.`;
  window.open('https://wa.me/' + tel + '?text=' + encodeURIComponent(msg), '_blank');
}
// Cobrar / renovar: abre la caja con el socio y su plan ya en el ticket
async function memCobrar(id, socio) {
  const s = socio || MSOCIOS.find((x) => x.id === id) || await GET('/api/membresias/socios/' + id);
  if (!PRODS.length) PRODS = await GET('/api/productos');
  const plan = MPLANES.find((p) => p.id === s.plan_id) || MPLANES[0];
  const pr = plan && PRODS.find((p) => p.id === plan.producto_id);
  if (!pr) return toast('El socio no tiene un plan válido: edítelo y elija su plan', true);
  cerrar();
  if (TICKETS[TK].items.length) { TICKETS.push({ items: [] }); TK = TICKETS.length - 1; }
  const tk = TICKETS[TK];
  tk.socio = s; tk.placas = listaPl(s.placas)[0] || ''; tk.usarMem = undefined;
  tk.items.push({ producto_id: pr.id, nombre: pr.nombre, codigo: pr.codigo, precio: pr.precio, cantidad: 1 });
  SEL = tk.items.length - 1;
  await ir('tienda');
  toast('Cobre la membresía de ' + s.nombre + ' con F12. Si también lava hoy, toque su paquete.');
}
const listaPl = (s) => String(s || '').split(/[,;/]+/).map((x) => x.trim()).filter(Boolean);

// ---------- Planes ----------
async function memPlanes() {
  $('#memc').innerHTML = `<div class="aviso" style="margin-bottom:12px">Cada plan se vende en la caja como un servicio (aparece en el área <b>Membresías</b>). Al cobrarlo, la vigencia del socio se alarga los días del plan.</div>
    <div class="grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px">${MPLANES.map((p) => `<div class="card"><h2 style="margin:0 0 4px">${esc(p.nombre)}</h2>
      <div style="font-size:26px;font-weight:800">${money(p.precio)} <small class="sub">/ ${p.dias} días</small></div>
      <p class="sub" style="margin:6px 0">${esc(paqsTxt(p))}<br>${esc(limiteTxt(p))}${p.descripcion ? '<br>' + esc(p.descripcion) : ''}</p>
      <div class="sub"><b>${p.socios}</b> socio(s) vigentes</div>
      ${puede('productos') ? `<div class="row" style="gap:6px;margin-top:8px"><button class="btn sm" onclick="planModal(${p.id})">Editar</button><button class="btn sm bad" onclick="confirmar(this,()=>planBorrar(${p.id}))">Eliminar</button></div>` : ''}</div>`).join('')
      || '<div class="empty" style="grid-column:1/-1">Todavía no hay planes. Ejemplos: "Mensual ilimitado" $599 / 30 días, 1 lavado por día; "Semanal" $199 / 7 días.</div>'}</div>`;
}
function planModal(id) {
  const p = id ? MPLANES.find((x) => x.id === id) : { nombre: '', precio: '', dias: 30, por_dia: 1, por_periodo: 0, paquetes: '', descripcion: '' };
  const sel = new Set(String(p.paquetes || '').split(',').filter(Boolean)), paqs = PAQS();
  modal(id ? 'Editar plan' : 'Nuevo plan de membresía', `<div class="f">
    <label class="l">Nombre del plan<input id="pmN" value="${esc(p.nombre)}" placeholder="Ej. Mensual ilimitado"></label>
    <label class="l">Precio<input id="pmP" type="number" min="0" step="0.01" value="${p.precio}"></label>
    <label class="l">Duración (días)<input id="pmD" type="number" min="1" value="${p.dias}"></label>
    <label class="l">Lavados por día (0 = sin límite)<input id="pmL" type="number" min="0" value="${p.por_dia}"></label>
    <label class="l">Lavados en todo el periodo (0 = ilimitado)<input id="pmT" type="number" min="0" value="${p.por_periodo}"></label>
    <label class="l" style="grid-column:1/-1">Descripción (opcional, sale en el ticket)<input id="pmDe" value="${esc(p.descripcion || '')}"></label></div>
    <h3 style="margin:12px 0 6px">¿Qué paquetes incluye?</h3><p class="sub" style="margin-top:0">Si no marca ninguno, incluye todos.</p>
    <div class="row" style="gap:8px;flex-wrap:wrap">${paqs.map((x) => `<label class="chip" style="--c:${colorPaq(x)};display:flex;gap:6px;align-items:center"><input type="checkbox" class="pmPq" value="${esc(x.paquete)}" ${sel.has(String(x.paquete)) ? 'checked' : ''}><b>P${esc(x.paquete)}</b>${esc(x.nombre)}</label>`).join('') || '<span class="sub">No hay paquetes de lavado dados de alta.</span>'}</div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="planOk(${id || 0})">Guardar</button>`);
}
async function planOk(id) {
  const b = { nombre: val('pmN'), precio: val('pmP'), dias: val('pmD'), por_dia: val('pmL'), por_periodo: val('pmT'), descripcion: val('pmDe'), paquetes: [...document.querySelectorAll('.pmPq:checked')].map((x) => x.value).join(',') };
  await hacer(() => (id ? PUT('/api/membresias/planes/' + id, b) : POST('/api/membresias/planes', b)), 'Plan guardado');
  cerrar(); PRODS = await GET('/api/productos'); vMem();
}
async function planBorrar(id) { await hacer(() => DEL('/api/membresias/planes/' + id), 'Plan eliminado'); PRODS = await GET('/api/productos'); vMem(); }

// ---------- Resumen ----------
let memDesde = hoyISO().slice(0, 8) + '01', memHasta = hoyISO();
async function memResumen() {
  const r = await GET(`/api/membresias/resumen?desde=${memDesde}&hasta=${memHasta}`);
  const K = (t, v, s = '') => `<div class="card" style="padding:12px"><div class="sub">${t}</div><div style="font-size:26px;font-weight:800">${v}</div>${s ? `<div class="sub">${s}</div>` : ''}</div>`;
  $('#memc').innerHTML = `<div class="row" style="gap:8px;margin-bottom:12px;flex-wrap:wrap"><label class="l">Desde<input type="date" id="mrD" value="${memDesde}"></label><label class="l">Hasta<input type="date" id="mrH" value="${memHasta}"></label>
    <button class="btn" style="align-self:flex-end" onclick="memDesde=val('mrD');memHasta=val('mrH');memResumen()">Ver</button></div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px;margin-bottom:14px">
      ${K('Socios activos', r.activos, `${r.por_vencer} por vencer en 5 días`)}${K('Vencidos', r.vencidos, 'para renovar')}${K('Cobrado en membresías', money(r.ingresos), `${r.pagos} pago(s)`)}
      ${K('Lavados de socios', r.lavados, `valen ${money(r.valor_lavados)} a precio normal`)}</div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px">
      <div class="card"><h2>Por plan</h2><div class="kv">${r.por_plan.map((x) => `<span>${esc(x.nombre)} (${x.n})</span><b>${money(x.t)}</b>`).join('') || '<span class="sub">Sin pagos en el periodo</span>'}</div></div>
      <div class="card"><h2>Socios que más lavan</h2><div class="kv">${r.top.map((x) => `<span>${esc(x.nombre)} <small class="mono">${esc(x.placas || '')}</small></span><b>${x.n} lavados</b>`).join('') || '<span class="sub">Sin lavados en el periodo</span>'}</div></div></div>`;
}

// ======================================================================
// Punto de venta: reconoce al socio por sus placas y aplica su lavado incluido
// ======================================================================
const MEM_COD = 'SOCIO';
// La línea "Membresía" es una línea de descuento que solo vive en la pantalla (el servidor hace la cuenta de verdad)
function memSync(tk) {
  for (let i = tk.items.length - 1; i >= 0; i--) if (tk.items[i].memLinea) tk.items.splice(i, 1);
  const s = tk.socio; if (!s || tk.usarMem === false) return;
  const renueva = tk.items.some((l) => esMemProd(prodDe(l.producto_id)));
  const plan = renueva ? MPLANES.find((p) => p.producto_id === tk.items.find((l) => esMemProd(prodDe(l.producto_id))).producto_id) || s.plan : s.plan;
  if (!plan) return;
  if (!renueva && !s.puede_usar) return;
  if (renueva && plan.por_dia > 0 && s.usos_hoy >= plan.por_dia) return;
  const inc = String(plan.paquetes || '').split(',').filter(Boolean);
  const l = tk.items.find((x) => { const p = prodDe(x.producto_id); return esPaq(p) && (!inc.length || inc.includes(String(p.paquete).toUpperCase())); });
  if (!l) return;
  tk.items.push({ producto_id: 0, memLinea: true, codigo: MEM_COD, nombre: `Membresía de ${s.nombre} · Paquete ${prodDe(l.producto_id).paquete} incluido`, precio: -l.precio, cantidad: 1 });
}
{
  const _pt = pintarTienda;
  pintarTienda = function (...a) {
    const tk = TICKETS[TK];
    memSync(tk);
    const r = _pt(...a);
    memBanner(tk);
    return r;
  };
}
function memBanner(tk) {
  // fila de la membresía en el ticket: sin botones de cantidad
  const filas = document.querySelectorAll('.pv-tabla tbody tr');
  tk.items.forEach((l, i) => {
    if (!l.memLinea || !filas[i]) return;
    filas[i].classList.add('mem-fila');
    filas[i].innerHTML = `<td class="mono"><span class="pill p-ok">SOCIO</span></td><td><b>${esc(l.nombre)}</b></td><td class="n">${money(l.precio)}</td><td class="n">1</td><td class="n"><b>${money(l.precio)}</b></td>
      <td><button class="x" onclick="event.stopPropagation();memNoUsar()" title="No usar la membresía en esta venta" aria-label="No usar la membresía">×</button></td>`;
  });
  const s = tk.socio, cont = $('.cw-veh') || $('.cw-pantalla');
  if (!cont) return;
  let html;
  if (s) {
    const enTk = tk.items.some((l) => esMemProd(prodDe(l.producto_id)));
    const cls = enTk ? 'ok' : s.estado === 'vencida' || s.estado === 'sin_pago' || !s.puede_usar ? 'bad' : s.estado === 'por_vencer' ? 'warn' : 'ok';
    const usa = tk.items.some((l) => l.memLinea);
    const msg = enTk ? 'Renovando su membresía en esta venta' : s.puede_usar ? (usa ? 'Lavado incluido en su membresía' : `Toque un paquete incluido (${esc(s.plan ? paqsTxt(s.plan) : '')}) y sale en $0`) : esc(s.motivo);
    html = `<div class="mem-banner mem-${cls}"><div><b>${ico('personas')} Socio: ${esc(s.nombre)}</b> · ${esc(s.plan_nombre || '')} · ${pillMem(s.estado)} · vence ${fFecha(s.vence)}${s.plan?.por_dia ? ` · lavados hoy ${s.usos_hoy}/${s.plan.por_dia}` : ''}<div class="sub">${msg}</div></div>
      <div class="row" style="gap:6px">${!enTk && (s.estado === 'vencida' || s.estado === 'por_vencer' || s.estado === 'sin_pago') ? `<button class="btn sm pri" onclick="memRenovarAqui()">${s.estado === 'sin_pago' ? 'Cobrar membresía' : 'Renovar'}</button>` : ''}
      ${tk.usarMem === false && s.puede_usar ? '<button class="btn sm" onclick="memSiUsar()">Usar membresía</button>' : ''}<button class="btn sm" onclick="memQuitarSocio()">Quitar socio</button></div></div>`;
  } else html = `<div class="mem-banner mem-nada"><span class="sub">¿Es socio? Escriba sus placas o</span><button class="btn sm" onclick="memBuscarSocio()">Buscar socio</button>${puede('vender') && MPLANES.length ? '<button class="btn sm" onclick="memNuevoAqui()">Nuevo socio</button>' : ''}</div>`;
  cont.insertAdjacentHTML('afterend', html);
  const pl = $('#cwPl');
  if (pl && !pl.dataset.mem) {
    pl.dataset.mem = '1';
    pl.addEventListener('input', () => { clearTimeout(memBanner.t); memBanner.t = setTimeout(() => memPorPlacas(pl.value), 450); });
    pl.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); clearTimeout(memBanner.t); memPorPlacas(pl.value, true); } });
  }
}
async function memPorPlacas(placas, avisar) {
  const tk = TICKETS[TK], p = String(placas || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
  if (p.length < 3) { if (tk.socio && !tk.items.some((l) => esMemProd(prodDe(l.producto_id)))) { tk.socio = null; memRepintar(); } return; }
  let r; try { r = await GET('/api/membresias/placas/' + encodeURIComponent(p)); } catch { return; }
  if (TICKETS[TK] !== tk) return;
  const antes = tk.socio?.id || 0, ahora = r.socio?.id || 0;
  if (r.socio) { tk.socio = r.socio; if (!r.socio.puede_usar) tk.usarMem = undefined; }
  else if (antes && !tk.items.some((l) => esMemProd(prodDe(l.producto_id)))) tk.socio = null;
  if (antes !== ahora || avisar) {
    memRepintar();
    if (r.socio) { beep(1200); toast(r.socio.puede_usar ? `Socio ${r.socio.nombre}: lavado incluido` : `Socio ${r.socio.nombre}: ${r.socio.motivo}`, !r.socio.puede_usar); }
    else if (avisar) toast('Esas placas no son de ningún socio');
  }
}
// Vuelve a pintar sin perder lo que el cajero está escribiendo en placas
function memRepintar() {
  const a = document.activeElement, enPl = a && a.id === 'cwPl', pos = enPl ? a.selectionStart : 0;
  pintarTienda();
  if (enPl) { const n = $('#cwPl'); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch { /* nada */ } } }
}
function memNoUsar() { TICKETS[TK].usarMem = false; pintarTienda(); }
function memSiUsar() { TICKETS[TK].usarMem = undefined; pintarTienda(); }
function memQuitarSocio() {
  const tk = TICKETS[TK]; tk.socio = null; tk.usarMem = undefined;
  tk.items = tk.items.filter((l) => !esMemProd(prodDe(l.producto_id)) && !l.memLinea); carrito = tk.items; pintarTienda();
}
async function memRenovarAqui() {
  const tk = TICKETS[TK], s = tk.socio; if (!s) return;
  if (!MPLANES.length) await cargarPlanes();
  const plan = MPLANES.find((p) => p.id === s.plan_id) || MPLANES[0], pr = plan && PRODS.find((p) => p.id === plan.producto_id);
  if (!pr) return toast('El socio no tiene plan: edítelo en Membresías', true);
  tk.usarMem = undefined;
  agregar(pr.id);
}
// Buscar socio por nombre, teléfono o placas
async function memBuscarSocio(despues) {
  if (!MPLANES.length) await cargarPlanes();
  MSOCIOS = await GET('/api/membresias/socios');
  modal('Buscar socio', `<input id="msB" placeholder="Nombre, teléfono o placas" autocomplete="off" oninput="memBuscarPintar()"><div class="tw" style="max-height:380px;margin-top:10px"><table><tbody id="msL"></tbody></table></div>`,
    `${puede('vender') ? '<button class="btn" onclick="memNuevoAqui()">Nuevo socio</button>' : ''}<button class="btn" onclick="cerrar()">Cerrar</button>`, true);
  memBuscarSocio.despues = despues || null; memBuscarPintar();
}
function memBuscarPintar() {
  const q = val('msB').toLowerCase(), qp = q.toUpperCase().replace(/[^0-9A-Z]/g, '');
  const L = MSOCIOS.filter((s) => !q || s.nombre.toLowerCase().includes(q) || String(s.telefono || '').includes(q) || (qp && String(s.placas || '').toUpperCase().replace(/[^0-9A-Z,]/g, '').includes(qp))).slice(0, 60);
  $('#msL').innerHTML = L.map((s) => `<tr style="cursor:pointer" onclick="memElegir(${s.id})"><td><b>${esc(s.nombre)}</b><div class="sub">${esc(s.telefono || '')}</div></td><td class="mono">${esc(s.placas || '')}</td><td>${esc(s.plan_nombre || '')}</td><td>${pillMem(s.estado)}</td><td>vence ${fFecha(s.vence)}</td></tr>`).join('') || '<tr><td class="empty">No se encontró. Toque "Nuevo socio".</td></tr>';
}
function memElegir(id) {
  const s = MSOCIOS.find((x) => x.id === id); if (!s) return; cerrar();
  const tk = TICKETS[TK]; tk.socio = s; tk.usarMem = undefined; if (!tk.placas) tk.placas = listaPl(s.placas)[0] || '';
  const fn = memBuscarSocio.despues; memBuscarSocio.despues = null;
  if (fn) fn(s); else pintarTienda();
}
async function memNuevoAqui(despues) {
  if (!MPLANES.length) await cargarPlanes();
  const tk = TICKETS[TK];
  socioModal(0, { placas: tk.placas || val('cwPl') || '', vehiculo: tk.vehiculo || '' }, (s) => {
    tk.socio = s; tk.usarMem = undefined; if (!tk.placas) tk.placas = listaPl(s.placas)[0] || '';
    const plan = MPLANES.find((p) => p.id === s.plan_id), pr = plan && PRODS.find((p) => p.id === plan.producto_id);
    if (pr && !tk.items.some((l) => l.producto_id === pr.id)) tk.items.push({ producto_id: pr.id, nombre: pr.nombre, codigo: pr.codigo, precio: pr.precio, cantidad: 1 });
    if (typeof despues === 'function') despues(s);
    pintarTienda(); toast('Socio dado de alta: cobre su membresía con F12');
  });
  $('#sN')?.focus();
}
// Vender una membresía sin socio elegido: primero se pide el socio
{
  const _ag = agregar;
  agregar = function (id, c) {
    const p = PRODS.find((x) => x.id === id), tk = TICKETS[TK];
    if (esMemProd(p) && !tk.socio) {
      return memBuscarSocio((s) => {
        const plan = MPLANES.find((x) => x.producto_id === p.id);
        if (plan && s.plan_id !== plan.id) PUT('/api/membresias/socios/' + s.id, { plan_id: plan.id }).catch(() => {});
        _ag(id, c);
      });
    }
    if (esMemProd(p) && tk.items.some((l) => esMemProd(prodDe(l.producto_id)) && l.producto_id !== id)) return toast('Solo un plan por venta', true);
    return _ag(id, c);
  };
  const _tq = tQuitar;
  tQuitar = function () { if (carrito[SEL]?.memLinea) return memNoUsar(); return _tq(); };
  const _cant = cant;
  cant = function (i, d) { if (carrito[i]?.memLinea) { if (d < 0) memNoUsar(); return; } return _cant(i, d); };
}
// Al cobrar: la línea de membresía no se manda; se manda el socio y si usa su lavado incluido
{
  const _api = api;
  api = async function (metodo, url, body) {
    let tk = null;
    if (metodo === 'POST' && url === '/api/ventas' && body && Array.isArray(body.items)) {
      tk = TICKETS[TK];
      body = { ...body, items: body.items.filter((it) => Number(it.producto_id) > 0) };
      if (tk?.socio) { body.socio_id = tk.socio.id; body.usar_membresia = tk.items.some((l) => l.memLinea); }
    }
    const r = await _api(metodo, url, body);
    if (tk && r?.membresia) {
      const m = r.membresia;
      setTimeout(() => toast(m.renovo ? `Membresía de ${m.socio} vigente hasta el ${fFecha(m.vence)}` : `Lavado de socio registrado (${m.socio})`), 2800);
    }
    return r;
  };
}
// Ticket: el socio y la vigencia salen al final
{
  const _tk = imprimirTicketCW;
  imprimirTicketCW = function (v, nota, re) {
    const m = v?.membresia;
    const extra = m ? `SOCIO ${m.socio} · Membresía ${m.plan} vigente hasta ${fFecha(m.vence)}${m.uso ? ' · Lavado incluido' : ''}` : '';
    return _tk(v, [nota, extra].filter(Boolean).join(' · '), re);
  };
}
// La lista de productos de inventario no muestra los planes (se editan en Membresías)
{
  const _ip = invProductos;
  invProductos = function () { const todos = PRODS; PRODS = todos.filter((p) => !esMemProd(p)); try { return _ip(); } finally { PRODS = todos; } };
}
// Cargar los planes al entrar
{
  const _vt = vTienda;
  vTienda = async function () { if (!MPLANES.length) await cargarPlanes().catch(() => {}); return _vt(); };
}
