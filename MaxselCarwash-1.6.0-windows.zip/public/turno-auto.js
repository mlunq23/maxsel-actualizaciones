'use strict';
// Maxsel 2026: el ticket se imprime solo al cobrar, y si la caja está cerrada se abre sola la ventana de "Abrir turno"
// (al terminar de abrirlo, sigue el cobro donde se quedó).
const turnoListo = () => CFG.exigir_turno === '0' || !!(YO && YO.turno) || !puede('caja');
function asegurarTurno() {
  if (turnoListo()) return Promise.resolve(true);
  toast('Su caja está cerrada: abra su turno para poder cobrar');
  abrirTurno();
  return new Promise((ok) => {
    const vig = setInterval(async () => {
      if (YO && YO.turno) {
        // Ya se abrió: si quedó a la vista el comprobante de apertura (sin impresora), se cierra y sigue el cobro
        clearInterval(vig);
        if (!$('#modal').hidden && /apertura/i.test($('#modal h3')?.textContent || '')) cerrar();
        return ok(true);
      }
      if (!$('#modal').hidden) return; // sigue capturando el fondo o el tipo de cambio
      clearInterval(vig);
      try { await pintarTurno(); } catch { /* sin red */ }
      ok(!!(YO && YO.turno));
    }, 250);
  });
}
{
  const _vc = ventanaCobro, _ok = vcOk;
  const auto = () => CFG.imprimir_auto !== '0';
  // Ticket automático: "Cobrar" siempre imprime (se puede apagar en Configuración → Caja)
  vcOk = function (imp) { return _ok(auto() ? true : imp); };
  const abrirVentana = (o) => {
    const r = _vc(o);
    if (auto()) {
      document.querySelector('#cobro .vc-b[onclick="vcOk(false)"]')?.remove();
      const p = document.querySelector('#cobro .vc-b.pri'); if (p) p.innerHTML = '<kbd>F1</kbd>Cobrar e imprimir ticket';
    }
    return r;
  };
  // Cualquier ventana de cobro revisa primero que haya turno abierto
  ventanaCobro = function (o) {
    if (turnoListo()) return abrirVentana(o);
    return asegurarTurno().then((sigue) => (sigue ? abrirVentana(o) : null));
  };
}
// Carwash: antes de abrir la ventana de cobro revisa el turno (así el número del paquete se ve en la ventana)
if (typeof cobrar === 'function' && typeof paqsCarrito === 'function') {
  const _cb = cobrar;
  cobrar = async function () {
    if (!carrito.length) return toast('El ticket está vacío', true);
    if (!(await asegurarTurno())) return;
    return _cb();
  };
}
