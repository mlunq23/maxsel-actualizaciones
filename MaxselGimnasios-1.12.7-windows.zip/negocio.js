// Reglas del negocio: membresías, promociones, acceso con lector, pantalla secundaria
import fs from 'node:fs';
import path from 'node:path';
import { buscarFotosEnPc } from './fotospc.js';
import { all, get, run, tx, cfg, hoy, ahora, sumarDias, sumarMeses, diasEntre, isoLocal, r2, FOTOS_DIR } from './db.js';
import { Hikvision, EVENTOS_OK, EVENTOS_DESCONOCIDO } from './hikvision.js';
import { limiteClientes } from './licencia.js';

export class ErrorUsuario extends Error { constructor(msg, status = 400) { super(msg); this.status = status; } }

// ---------- Estado de membresía ----------
export function estadoCliente(id) {
  const c = get('SELECT bloqueado FROM clientes WHERE id=?', id);
  const t = hoy();
  const activa = get(`SELECT m.*, p.nombre plan FROM membresias m JOIN planes p ON p.id=m.plan_id
    WHERE m.cliente_id=? AND m.cancelada=0 AND m.inicio<=? AND m.fin>=? ORDER BY m.fin DESC LIMIT 1`, id, t, t);
  const ultima = get(`SELECT m.*, p.nombre plan FROM membresias m JOIN planes p ON p.id=m.plan_id
    WHERE m.cliente_id=? AND m.cancelada=0 ORDER BY m.fin DESC LIMIT 1`, id);
  let estado = 'sin', dias = null;
  if (ultima) {
    dias = diasEntre(t, ultima.fin);
    estado = activa ? (dias <= 3 ? 'por_vencer' : 'activo') : (ultima.fin < t ? 'vencido' : 'pendiente');
  }
  if (c?.bloqueado) estado = 'bloqueado';
  return { estado, vence: ultima?.fin || null, plan: (activa || ultima)?.plan || null, dias_restantes: dias };
}
export const puedeEntrar = (e) => ['activo', 'por_vencer'].includes(e.estado);

export function textoEstado(e) {
  switch (e.estado) {
    case 'activo': return `Membresía activa hasta ${e.vence}`;
    case 'por_vencer': return e.dias_restantes === 0 ? 'Tu membresía vence HOY' : `Tu membresía vence en ${e.dias_restantes} día(s)`;
    case 'vencido': return `Membresía vencida desde ${e.vence}`;
    case 'pendiente': return `Membresía inicia después (${e.vence})`;
    case 'bloqueado': return 'Acceso bloqueado, pasa a recepción';
    default: return 'Sin membresía, pasa a recepción';
  }
}

// ---------- Cotizar membresía con promoción ----------
export function cotizarMembresia({ cliente_id, plan_id, promo_id, pareja_id }) {
  const cliente = get('SELECT * FROM clientes WHERE id=?', cliente_id);
  if (!cliente) throw new ErrorUsuario('Selecciona un cliente');
  const plan = get('SELECT * FROM planes WHERE id=? AND activo=1', plan_id);
  if (!plan) throw new ErrorUsuario('Selecciona un plan');
  let promo = null, pareja = null, personas = 1;
  if (promo_id) {
    promo = get('SELECT * FROM promociones WHERE id=? AND activo=1', promo_id);
    if (!promo) throw new ErrorUsuario('La promoción no existe o está desactivada');
    if (promo.plan_id && promo.plan_id !== plan.id) {
      const pp = get('SELECT nombre FROM planes WHERE id=?', promo.plan_id);
      throw new ErrorUsuario(`La promoción "${promo.nombre}" solo aplica al plan ${pp?.nombre}`);
    }
    if (promo.tipo === 'estudiante' && (!cliente.estudiante || !cliente.doc_estudiante))
      throw new ErrorUsuario('Para la promoción de estudiante, el cliente debe estar marcado como estudiante y tener la foto de su credencial escolar. Agrégala en su ficha (Evidencias).');
    if (promo.tipo === 'vecino' && (!cliente.vecino || !cliente.doc_vecino))
      throw new ErrorUsuario('Para la promoción de vecinos, el cliente debe estar marcado como vecino de la zona y tener la foto de su INE o comprobante de domicilio. Agrégala en su ficha (Evidencias).');
    if (promo.tipo === 'vecino') {
      const zonas = String(promo.zonas || '').split(',').map((z) => z.trim().toLowerCase()).filter(Boolean);
      const dir = [cliente.colonia, cliente.cp, cliente.direccion].join(' ').toLowerCase();
      if (zonas.length && !zonas.some((z) => dir.includes(z)))
        throw new ErrorUsuario(`La colonia/código postal del cliente no está en la zona de la promoción (${promo.zonas}).`);
      if (!zonas.length && !cliente.colonia && !cliente.cp)
        throw new ErrorUsuario('Captura la colonia o código postal del cliente para aplicar la promoción de vecinos.');
    }
    if (promo.tipo === 'pareja') {
      if (!pareja_id) pareja_id = cliente.pareja_id;
      if (!pareja_id) throw new ErrorUsuario('Selecciona a la pareja (también debe estar dado de alta como cliente)');
      if (Number(pareja_id) === Number(cliente_id)) throw new ErrorUsuario('La pareja debe ser otra persona');
      pareja = get('SELECT id, nombre FROM clientes WHERE id=?', pareja_id);
      if (!pareja) throw new ErrorUsuario('No se encontró a la pareja');
      personas = 2;
    }
  }
  const subtotal = r2(plan.precio * personas);
  let total = subtotal;
  if (promo) {
    if (promo.descuento_tipo === 'porcentaje') total = subtotal * (1 - promo.valor / 100);
    else if (promo.descuento_tipo === 'monto') total = subtotal - promo.valor;
    else total = promo.valor;
  }
  total = r2(Math.max(0, total));
  const fechas = (cid) => {
    const ult = get('SELECT MAX(fin) fin FROM membresias WHERE cliente_id=? AND cancelada=0', cid)?.fin;
    const inicio = ult && ult >= hoy() ? sumarDias(ult, 1) : hoy(); // si aún está vigente, se suma al final
    let fin = sumarMeses(inicio, plan.meses || 0);
    fin = sumarDias(fin, (plan.dias || 0) - 1);
    if (fin < inicio) fin = inicio;
    return { inicio, fin };
  };
  const f1 = fechas(cliente.id);
  const desc = `Membresía ${plan.nombre}${promo ? ' – ' + promo.nombre : ''} · ${cliente.nombre}${pareja ? ' y ' + pareja.nombre : ''}`;
  return {
    cliente_id: cliente.id, plan_id: plan.id, promo_id: promo?.id || null, pareja_id: pareja?.id || null,
    descripcion: desc, subtotal, descuento: r2(subtotal - total), total, inicio: f1.inicio, fin: f1.fin,
    pareja_fechas: pareja ? fechas(pareja.id) : null,
  };
}

// ---------- Pantalla secundaria (Server-Sent Events) ----------
const pantallas = new Set();
export function conectarPantalla(res) {
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
  res.write('retry: 2000\n\n');
  pantallas.add(res);
  res.on('close', () => pantallas.delete(res));
}
export function avisarPantallas(obj) {
  const msg = `data: ${JSON.stringify(obj)}\n\n`;
  for (const r of pantallas) r.write(msg);
}
setInterval(() => { for (const r of pantallas) r.write(': ping\n\n'); }, 25000).unref();

// ---------- Lector Hikvision ----------
export const lectorEstado = { conectado: false, error: null, ultimo: null, modo: 'simulador' };
export const lector = () => new Hikvision({
  ip: cfg('hik_ip'), puerto: cfg('hik_puerto'), usuario: cfg('hik_usuario'),
  password: cfg('hik_password'), puerta: cfg('hik_puerta'),
});
export const modoReal = () => cfg('hik_modo') === 'real' && !!cfg('hik_ip');

// Envía al lector los datos y vigencia del cliente (y su rostro si cambió)
export async function sincronizarCliente(id, { soloFoto: pedirSoloFoto = false } = {}) {
  const c = get('SELECT * FROM clientes WHERE id=?', id);
  if (!c) return;
  if (!modoReal()) {
    run('UPDATE clientes SET sincronizado=1, sync_error=NULL, cara_sync=? WHERE id=?', c.foto ? 1 : 0, id);
    return { ok: true, simulador: true };
  }
  const e = estadoCliente(id);
  const ayer = sumarDias(hoy(), -1);
  // Si no tiene membresía vigente (o está bloqueado) la vigencia queda en el pasado => el lector niega el acceso
  const inicio = (c.creado || hoy()).slice(0, 10);
  let fin = e.vence && e.estado !== 'bloqueado' ? e.vence : ayer;
  const ini = inicio > fin ? sumarDias(fin, -1) : inicio;
  // 1.12.4: cliente importado del lector que aún NO tiene membresía en el sistema: solo se le cambia la foto;
  // su acceso (vigencia) en el lector se queda como estaba, para no quitárselo.
  // 1.12.5: también si su única membresía es la "Importado del lector" (la misma vigencia que ya tiene en el lector).
  // 1.12.7: SOLO cuando se está cambiando la foto (nunca al bloquear, editar o vender) y si no está bloqueado.
  const soloFoto = pedirSoloFoto && c.importado && !c.bloqueado && !get(`SELECT m.id FROM membresias m LEFT JOIN planes p ON p.id=m.plan_id
      WHERE m.cliente_id=? AND m.cancelada=0 AND COALESCE(p.nombre,'')<>'Importado del lector' LIMIT 1`, id);
  try {
    const h = lector();
    if (!soloFoto) try {
      await h.guardarUsuario({ empleado: c.hik_empleado, nombre: c.nombre, inicio: `${ini}T00:00:00`, fin: `${fin}T23:59:59` });
    } catch (e) { throw new Error('Al dar de alta a la persona en el lector: ' + e.message); }
    if (c.foto && !c.cara_sync) {
      const jpg = fs.readFileSync(path.join(FOTOS_DIR, c.foto));
      try { await h.guardarRostro(c.hik_empleado, jpg); }
      catch (e) {
        // si la persona no existe en el lector (se borró allá), se da de alta y se intenta otra vez
        if (soloFoto && /no existe|not ?exist|employeeNo|noMatch|FPID/i.test(e.message)) {
          await h.guardarUsuario({ empleado: c.hik_empleado, nombre: c.nombre, inicio: `${ini}T00:00:00`, fin: `${fin}T23:59:59` });
          try { await h.guardarRostro(c.hik_empleado, jpg); } catch (e2) { throw new Error('Al subir el rostro al lector: ' + e2.message); }
        } else throw new Error('Al subir el rostro al lector: ' + e.message);
      }
      run('UPDATE clientes SET cara_sync=1 WHERE id=?', id);
    }
    run(`UPDATE clientes SET sincronizado=1, sync_error=NULL${soloFoto ? '' : ', importado=0'} WHERE id=?`, id);
    return { ok: true };
  } catch (err) {
    console.error(`[lector] cliente ${id}: ${err.message}`);
    run('UPDATE clientes SET sincronizado=0, sync_error=? WHERE id=?', err.message, id);
    return { ok: false, error: err.message };
  }
}
export function sincronizarEnSegundoPlano(id) { sincronizarCliente(id).catch(() => {}); }

// ---------- Procesar un acceso (del lector, simulador o manual) ----------
export function infoPantallaCliente(id) {
  const c = get('SELECT id, nombre, foto FROM clientes WHERE id=?', id);
  if (!c) return null;
  const e = estadoCliente(id);
  const visitas = all(`SELECT fecha FROM visitas WHERE cliente_id=? AND resultado='permitido' ORDER BY fecha DESC LIMIT 11`, id);
  const deudas = all(`SELECT v.id, v.fecha, v.credito_pendiente pendiente, v.total,
      (SELECT GROUP_CONCAT(CASE WHEN cantidad<>1 THEN printf('%g', cantidad) || ' x ' ELSE '' END || descripcion, ', ') FROM venta_items WHERE venta_id=v.id) productos
    FROM ventas v WHERE v.cliente_id=? AND v.cancelada=0 AND v.credito_pendiente>0.009 ORDER BY v.fecha`, id);
  const saldo = r2(deudas.reduce((s, d) => s + d.pendiente, 0));
  return { cliente: { id: c.id, nombre: c.nombre, foto: c.foto ? `/fotos/${c.id}?v=${encodeURIComponent(c.foto)}` : null }, estado: e, mensaje: textoEstado(e), visitas, deudas, saldo };
}

export function procesarAcceso({ clienteId, permitidoLector = null, origen, serial = null, minor = null }) {
  if (serial && get('SELECT id FROM visitas WHERE serial=?', serial)) return null; // evento repetido
  const fecha = ahora();
  if (!clienteId) {
    avisarPantallas({ tipo: 'desconocido', fecha, mensaje: 'Rostro no reconocido' });
    return null;
  }
  const info = infoPantallaCliente(clienteId);
  if (!info) { avisarPantallas({ tipo: 'desconocido', fecha, mensaje: `Usuario ${clienteId} no existe en el sistema` }); return null; }
  const sistemaPermite = puedeEntrar(info.estado);
  const permitido = permitidoLector === null ? sistemaPermite : permitidoLector;
  let motivo = permitido ? null : textoEstado(info.estado);
  if (permitidoLector === false && sistemaPermite) motivo = 'El lector negó el acceso (revisar sincronización)' + (minor ? ` · evento ${minor}` : '');
  let alerta = null;
  if (permitidoLector === true && !sistemaPermite && clienteId) {
    // 1.12.7: el lector dejó pasar a alguien que el sistema no permite (bloqueado o vencido): se le corrige en el lector de inmediato
    sincronizarEnSegundoPlano(clienteId);
  }
  if (permitidoLector === true && !sistemaPermite) {
    alerta = get('SELECT importado FROM clientes WHERE id=?', clienteId)?.importado
      ? 'Cliente importado del lector: pasa a recepción para registrar tu membresía'
      : 'El lector abrió pero la membresía NO está vigente: sincroniza este cliente';
  }
  run('INSERT INTO visitas(cliente_id,fecha,resultado,motivo,origen,serial) VALUES(?,?,?,?,?,?)',
    clienteId, fecha, permitido ? 'permitido' : 'denegado', motivo || alerta, origen, serial);
  const datos = { tipo: 'acceso', fecha, resultado: permitido ? 'permitido' : 'denegado', motivo, alerta, origen, ...infoPantallaCliente(clienteId) };
  avisarPantallas(datos);
  return datos;
}

// Evento de acceso que viene del lector (por envío directo o por consulta periódica)
export function eventoLector(ev) {
  const major = Number(ev.major ?? ev.majorEventType ?? 5);
  const minor = Number(ev.minor ?? ev.subEventType);
  if (major !== 5) return;
  const emp = ev.employeeNoString ?? ev.employeeNo;
  const serial = ev.claveUnica || (ev.serialNo !== undefined && ev.serialNo !== '' ? `hik-${ev.serialNo}` : (ev.dateTime && emp ? `hik-${ev.dateTime}-${emp}` : null));
  const via = ev.claveUnica ? 'consulta' : 'envío directo';
  const quien = `persona ${emp ?? '-'} · evento ${minor} · hora lector ${ev.time || ev.dateTime || '?'} · ${via}`;
  if (ev.dateTime && eventoViejo(ev.dateTime)) { bitacora(quien + ' → ignorado: evento viejo (revisa la hora del lector)'); return; }
  if (serial && !ev.claveUnica) { if (vistos.has(serial)) return; recordar(serial); }
  if (emp !== undefined && emp !== null && String(emp) !== '' && String(emp) !== '0') {
    const ok = EVENTOS_OK.has(minor);
    const c = get('SELECT id FROM clientes WHERE hik_empleado=?', String(emp));
    // 1.12.2: el lector vuelve a reconocer a la persona si se queda frente a él (o reenvía el mismo evento):
    // si la misma persona ya tuvo una entrada hace menos de "acceso_repetido_seg" segundos, no se cuenta otra vez.
    if (c) {
      const seg = Math.max(0, Number(cfg('acceso_repetido_seg')) || 0);
      if (seg) {
        const ult = get(`SELECT fecha FROM visitas WHERE cliente_id=? AND origen='lector' ORDER BY id DESC LIMIT 1`, c.id);
        if (ult && Date.now() - new Date(ult.fecha.replace(' ', 'T')).getTime() < seg * 1000) { bitacora(quien + ` → no se cuenta: ya había entrado hace menos de ${seg} s`); return; }
      }
    }
    if (!c) bitacora(quien + ' → no está en el sistema');
    else bitacora(quien + (ok ? ' → mostrado: permitido por el lector' : ' → mostrado: el lector lo negó'));
    if (!c) { avisarPantallas({ tipo: 'desconocido', fecha: ahora(), mensaje: `La persona ${emp} del lector no está en el sistema. Usa "Importar usuarios del lector".` }); return; }
    procesarAcceso({ clienteId: c.id, permitidoLector: ok, origen: 'lector', serial, minor });
  } else if (EVENTOS_DESCONOCIDO.has(minor)) {
    if (serial && desconocidos.has(serial)) return; // pudo llegar por envío directo y por consulta
    if (serial) { desconocidos.add(serial); if (desconocidos.size > 500) desconocidos.delete(desconocidos.values().next().value); }
    procesarAcceso({ clienteId: null, origen: 'lector' });
  }
}
const desconocidos = new Set();
const vistos = new Set();
// 1.12.6: bitácora de los últimos eventos del lector y qué se hizo con cada uno (sale en "Diagnóstico del lector")
export const bitacoraEventos = [];
function bitacora(t) { bitacoraEventos.push(new Date().toLocaleTimeString('es-MX') + ' ' + t); if (bitacoraEventos.length > 60) bitacoraEventos.shift(); }
function recordar(s) { vistos.add(s); if (vistos.size > 2000) vistos.delete(vistos.values().next().value); }

// ---------- Reloj del lector ----------
// Las consultas se hacen con la hora DEL LECTOR (no la de la PC) para que, aunque el lector tenga otra
// hora o zona horaria, nunca se pidan eventos viejos. Los eventos de más de 2 minutos se ignoran.
const reloj = { desfase: 0, sufijo: null, revisado: 0 };
const ANTIGUEDAD_MAX = 120000;
async function revisarReloj(h) {
  if (Date.now() - reloj.revisado < 60000) return;
  try {
    const t = await h.horaLector();
    const ms = Date.parse(t);
    if (!isNaN(ms)) {
      reloj.desfase = ms - Date.now();
      reloj.sufijo = (/([+-]\d\d:?\d\d|Z)$/.exec(t) || [])[1] || null;
      reloj.revisado = Date.now();
      lectorEstado.desfase_seg = Math.round(reloj.desfase / 1000);
    }
  } catch { reloj.revisado = Date.now() - 50000; /* reintenta en 10 s */ }
}
const ahoraLector = () => Date.now() + reloj.desfase;
const p2 = (n) => String(n).padStart(2, '0');
function horaParaLector(ms) {
  if (!reloj.sufijo) return isoLocal(new Date(ms - reloj.desfase)); // sin dato: hora de la PC
  if (reloj.sufijo === 'Z') return new Date(ms).toISOString().slice(0, 19) + 'Z';
  const m = /([+-])(\d\d):?(\d\d)/.exec(reloj.sufijo);
  const off = (m[1] === '-' ? -1 : 1) * (Number(m[2]) * 60 + Number(m[3]));
  const d = new Date(ms + off * 60000);
  return `${d.getUTCFullYear()}-${p2(d.getUTCMonth() + 1)}-${p2(d.getUTCDate())}T${p2(d.getUTCHours())}:${p2(d.getUTCMinutes())}:${p2(d.getUTCSeconds())}${m[1]}${m[2]}:${m[3]}`;
}
// ¿El evento es viejo? (se compara con el reloj del propio lector)
export function eventoViejo(hora) {
  const ms = Date.parse(String(hora || ''));
  if (isNaN(ms) || !reloj.revisado) return false;
  return ms < ahoraLector() - ANTIGUEDAD_MAX;
}

// Consulta periódica de eventos (respaldo por si el envío directo no está configurado)
let primera = true, consultando = false;
export function iniciarConsultaEventos() {
  setInterval(async () => {
    lectorEstado.modo = cfg('hik_modo');
    if (!modoReal() || consultando) { if (!modoReal()) { lectorEstado.conectado = false; lectorEstado.error = null; } return; }
    consultando = true;
    try {
      const h = lector();
      await revisarReloj(h);
      const ahoraL = ahoraLector();
      const desde = horaParaLector(ahoraL - ANTIGUEDAD_MAX), hasta = horaParaLector(ahoraL + 60000);
      // se leen todas las páginas (de 30 en 30) por si entraron varias personas juntas
      const lista = [];
      for (let pos = 0, i = 0; i < 10; i++) {
        const r = await h.eventos(desde, hasta, pos);
        const pag = r.InfoList || [];
        lista.push(...pag);
        pos += pag.length;
        if (!pag.length || r.responseStatusStrg !== 'MORE') break;
      }
      lista.sort((a, b) => (a.serialNo || 0) - (b.serialNo || 0));
      for (const ev of lista) {
        const s = ev.serialNo !== undefined ? `hik-${ev.serialNo}` : `hik-${ev.time}-${ev.employeeNoString ?? ''}-${ev.minor}`;
        if (vistos.has(s)) continue;
        recordar(s);
        if (primera) continue; // al arrancar solo se marcan
        if (eventoViejo(ev.time)) { bitacora(`persona ${ev.employeeNoString ?? '-'} · hora lector ${ev.time} → ignorado: evento viejo (diferencia de hora con el lector ${lectorEstado.desfase_seg ?? '?'} s)`); continue; }
        eventoLector({ ...ev, serialNo: undefined, claveUnica: s });
      }
      primera = false;
      lectorEstado.conectado = true; lectorEstado.error = null; lectorEstado.ultimo = ahora();
    } catch (e) {
      if (lectorEstado.conectado !== false || lectorEstado.error !== e.message) bitacora('consulta de eventos falló: ' + e.message);
      lectorEstado.conectado = false; lectorEstado.error = e.message;
    } finally { consultando = false; }
  }, 2000).unref();

  // Reintenta cada 5 minutos los clientes que no se pudieron sincronizar
  setInterval(async () => {
    if (!modoReal()) return;
    for (const c of all('SELECT id FROM clientes WHERE sincronizado=0 LIMIT 50')) await sincronizarCliente(c.id);
  }, 300000).unref();
}

// ---------- Importar las personas que ya están registradas en el lector ----------
// Se crean como clientes con el mismo número que tienen en el lector. No se modifica nada en el lector:
// cada persona conserva su acceso actual hasta que se le cobre una membresía o se edite en el sistema.
function planImportado() {
  let p = get(`SELECT id FROM planes WHERE nombre='Importado del lector'`);
  if (!p) p = { id: run(`INSERT INTO planes(nombre,dias,meses,precio,activo,orden) VALUES('Importado del lector',1,0,0,0,999)`).id };
  return p.id;
}
// La importación corre en segundo plano y la pantalla va preguntando el avance
export const importacion = { activa: false, fase: '', hechos: 0, total: 0, resultado: null, error: null, inicio: null };

export function iniciarImportacion(opciones) {
  if (importacion.activa) throw new ErrorUsuario('Ya hay una importación en proceso');
  if (!modoReal()) throw new ErrorUsuario('Para importar, configura el lector real en Configuración → Lector facial y guarda.');
  Object.assign(importacion, { activa: true, fase: 'Leyendo las personas del lector…', hechos: 0, total: 0, resultado: null, error: null, inicio: Date.now() });
  importarDelLector(opciones)
    .then((r) => { importacion.resultado = r; })
    .catch((e) => { importacion.error = e.message; console.error('[importar] ' + e.message); })
    .finally(() => { importacion.activa = false; importacion.fase = 'Terminado'; });
  return { ...importacion };
}

async function importarDelLector({ vigencia = true, fotos = true } = {}) {
  const h = lector();
  const personas = await h.listarUsuarios();
  const res = { encontrados: personas.length, nuevos: 0, ya_existian: 0, con_foto: 0, con_vigencia: 0, sin_foto_en_lector: 0, errores: [], errores_foto: 0, segundos: 0 };
  importacion.total = personas.length;

  // 1) Datos y vigencias: se guardan todos juntos (muy rápido)
  importacion.fase = 'Guardando clientes…';
  const pendientesFoto = []; // [clienteId, número en el lector]
  const lim = limiteClientes(); let registrados = get('SELECT COUNT(*) n FROM clientes').n;
  tx(() => {
    for (const pz of personas) {
      importacion.hechos++;
      const emp = String(pz.employeeNo ?? '').trim();
      if (!emp) continue;
      const ya = get('SELECT id, foto FROM clientes WHERE hik_empleado=?', emp);
      if (ya) {
        res.ya_existian++;
        if (!ya.foto) pendientesFoto.push([ya.id, emp]); // si se importó antes sin foto, se intenta otra vez
        continue;
      }
      if (lim && registrados >= lim) { res.fuera_de_licencia = (res.fuera_de_licencia || 0) + 1; continue; }
      registrados++;
      try {
        const nombre = String(pz.name || '').trim() || `Persona ${emp}`;
        const id = run(`INSERT INTO clientes(nombre,creado,sincronizado,cara_sync,importado,acepta_publicidad,notas) VALUES(?,?,1,1,1,0,?)`,
          nombre, hoy(), `Importado del lector (número ${emp})`).id;
        run('UPDATE clientes SET hik_empleado=? WHERE id=?', emp, id);
        res.nuevos++;
        const fin = String(pz.Valid?.endTime || '').slice(0, 10);
        const ini = String(pz.Valid?.beginTime || '').slice(0, 10) || hoy();
        // 2030 en adelante se toma como "sin vencimiento" (así vienen por defecto en el lector)
        if (vigencia && pz.Valid?.enable !== false && /^\d{4}-\d\d-\d\d$/.test(fin) && fin >= hoy() && fin < '2030-01-01') {
          run('INSERT INTO membresias(cliente_id,plan_id,inicio,fin,precio,creado) VALUES(?,?,?,?,0,?)', id, planImportado(), ini > fin ? fin : ini, fin, ahora());
          res.con_vigencia++;
        }
        pendientesFoto.push([id, emp]);
      } catch (e) { res.errores.push(`${emp}: ${e.message}`); }
    }
  });

  // 2) Fotos: primero se pide la lista de todas las fotos (de 30 en 30) y luego se descargan de 4 en 4
  if (fotos && pendientesFoto.length) {
    importacion.fase = 'Buscando las fotos en el lector…'; importacion.hechos = 0; importacion.total = pendientesFoto.length;
    let mapa = null;
    try { mapa = await h.listarRostros((n) => { importacion.fase = `Buscando las fotos en el lector… (${n} encontradas)`; }); }
    catch (e) { console.error('[importar] no se pudo listar los rostros: ' + e.message); }
    importacion.fase = 'Descargando fotos…';
    const cola = [...pendientesFoto];
    const trabajador = async () => {
      const hw = lector(); // cada trabajador con su propia conexión
      while (cola.length) {
        const [id, emp] = cola.shift();
        try {
          // el lector puede guardar el número con o sin ceros a la izquierda ("00000003" o "3")
          let url = mapa && (mapa.get(emp) || mapa.get(String(Number(emp))) || mapa.get(emp.padStart(8, '0')));
          if (!url) url = await hw.urlRostro(emp);
          if (!url) { res.sin_foto_en_lector++; continue; }
          const jpg = await hw.descargarImagen(url);
          const archivo = `${id}-${Date.now()}.jpg`;
          fs.writeFileSync(path.join(FOTOS_DIR, archivo), jpg);
          run('UPDATE clientes SET foto=?, cara_sync=1 WHERE id=?', archivo, id);
          res.con_foto++;
        } catch (e) {
          res.errores_foto++;
          if (res.errores.length < 20) res.errores.push(`Foto de ${emp}: ${e.message}`);
        } finally { importacion.hechos++; }
      }
    };
    await Promise.all([trabajador(), trabajador(), trabajador(), trabajador()]);
  }
  // 3) Los que siguen sin foto: se buscan en ESTA computadora (iVMS-4200, Hik-Connect, carpetas de fotos…)
  if (fotos && (res.sin_foto_en_lector || res.errores_foto)) {
    importacion.fase = 'Buscando las fotos que faltan en esta computadora (iVMS-4200, carpetas…)';
    try { const r = await buscarFotosEnPc(); res.fotos_pc = r?.encontradas || 0; res.con_foto += res.fotos_pc; }
    catch (e) { console.error('[importar] fotos en la PC: ' + e.message); }
  }
  res.segundos = Math.round((Date.now() - importacion.inicio) / 1000);
  console.log(`[importar] ${JSON.stringify({ ...res, errores: res.errores.slice(0, 5) })}`);
  return res;
}
