// Configuración pública del proyecto Firebase de Maxsel (no es secreta)
window.MAXSEL_FB={apiKey:"AIzaSyC5z267XDrGrQtndJwbyHZu5SkGNy_EnQY",authDomain:"maxsel-pos.firebaseapp.com",projectId:"maxsel-pos",storageBucket:"maxsel-pos.firebasestorage.app",messagingSenderId:"122208638981",appId:"1:122208638981:web:f1170cb4f6bf8e94d2646c"};
window.MAXSEL_ADMINS=['ventasmaxsel@gmail.com'];
