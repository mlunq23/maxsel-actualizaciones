// Maxsel Hotel 1.17 — huésped que ya estaba desde antes: capturar los pagos que hizo (día, cantidad y forma de pago)
const fISO = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
function ppPeriodos(m, desde, n0) { // cuántos periodos van desde que entró hasta hoy (igual que el sistema al registrarlo)
  const ya = new Date(); let k = Math.max(1, n0);
  while (k < 400 && salidaCalc(m, k, desde) <= ya) k++;
  return k;
}
function ppDatos() {
  const m = document.querySelector('input[name=rM]:checked')?.value, desde = new Date($('#rEnt')?.value || '');
  const n = Math.max(1, parseInt(val('rC')) || 1), u = num('rU');
  const t = val('rDt'), v = num('rDv'), rep = $('#rDr')?.checked && !$('#rDrBox')?.hidden;
  const per = t && v > 0 ? (t === 'pct' ? u * v / 100 : v / n) : 0;
  return { m, desde, n, u, per: Math.min(u, per), rep, P: m && !isNaN(desde) ? ppPeriodos(m, desde, n) : n };
}
function ppFila(f = '', monto = '', metodo = 'efectivo') {
  $('#ppL').insertAdjacentHTML('beforeend', `<div class="pp-r"><input type="date" class="ppF" value="${f}" max="${fISO(new Date())}" oninput="ppCalc()">
    <input type="number" class="ppM" min="0" step="0.01" placeholder="Cantidad" value="${monto}" oninput="ppCalc()">
    <select class="ppT">${[['efectivo', 'Efectivo'], ['transferencia', 'Transferencia'], ['tarjeta', 'Tarjeta']].map(([k, n]) => `<option value="${k}" ${k === metodo ? 'selected' : ''}>${n}</option>`).join('')}</select>
    <button class="btn sm" title="Quitar" onclick="this.parentNode.remove();ppCalc()">✕</button></div>`);
}
function ppLlenar() {
  const d = ppDatos(); if (!d.m || isNaN(d.desde)) return toast('Elija primero la fecha de ingreso y el tipo de renta', true);
  if (d.P > 60) return toast('Son muchos periodos para llenarlos uno por uno; agregue los pagos a mano', true);
  $('#ppL').innerHTML = '';
  for (let k = 0; k < d.P; k++) {
    const ini = k === 0 ? d.desde : salidaCalc(d.m, k, d.desde);
    const monto = d.u - (k === 0 || d.rep ? d.per : 0);
    ppFila(fISO(ini), Math.max(0, monto).toFixed(2));
  }
  ppCalc();
}
function ppLista() {
  return [...document.querySelectorAll('#ppL .pp-r')].map((r) => ({ fecha: r.querySelector('.ppF').value, monto: Number(r.querySelector('.ppM').value) || 0, metodo: r.querySelector('.ppT').value })).filter((x) => x.monto > 0);
}
function ppCalc() {
  const box = $('#ppRes'); if (!box) return;
  const d = ppDatos(), L = ppLista(), pagos = L.reduce((s, x) => s + x.monto, 0);
  const renta = d.P * d.u - (d.rep ? d.per * d.P : d.per * d.n), hoyPago = num('rA'), debe = renta - pagos - hoyPago;
  box.innerHTML = `<span>Renta desde que entró (${unidad(d.m || 'mes', d.P)})</span><b>${money(renta)}</b>
    <span>Pagos anteriores capturados (${L.length})</span><b style="color:var(--libre)">−${money(pagos)}</b>
    ${hoyPago > 0 ? `<span>Paga hoy</span><b style="color:var(--libre)">−${money(hoyPago)}</b>` : ''}
    <span>${debe >= 0 ? 'Queda debiendo' : 'Saldo a favor'}</span><b class="big" style="color:${debe > 0.004 ? 'var(--ocup)' : 'var(--libre)'}">${money(Math.abs(debe))}</b>`;
}
{
  const _rc = rCalc;
  rCalc = function (id, reset) {
    const r = _rc(id, reset);
    const on = typeof ingresoCambiado === 'function' && ingresoCambiado();
    let box = $('#ppBox');
    if (!box && $('#rEnt')) {
      $('#rEnt').closest('.f')?.insertAdjacentHTML('afterend', `<div id="ppBox" class="card" style="padding:12px;margin:4px 0 8px" hidden>
        <div class="lbl" style="margin-top:0">Pagos que ya hizo antes de usar el sistema</div>
        <div class="sub" style="margin-bottom:8px">Ponga el día, la cantidad y la forma de pago de cada pago. No entran al corte de caja de hoy; salen en los reportes en su fecha.
          Con "Un pago por cada periodo" se llena uno por cada mes (o semana) desde que entró: borre los que no pagó y corrija las cantidades.</div>
        <div id="ppL" class="stack" style="gap:6px"></div>
        <div class="row" style="gap:8px;flex-wrap:wrap;margin:8px 0"><button class="btn sm" onclick="ppFila();ppCalc()">+ Agregar un pago</button><button class="btn sm" onclick="ppLlenar()">Un pago por cada periodo</button></div>
        <div class="calc" id="ppRes"></div></div>`);
      box = $('#ppBox');
    }
    if (!box) return r;
    box.hidden = !on;
    if (on) {
      if (!$('#rA').dataset.t) $('#rA').value = '0.00'; // lo de antes va en "Pagos anteriores"; aquí solo lo que paga hoy
      ppCalc();
    }
    return r;
  };
  const _api = api;
  api = function (metodo, url, body) {
    if (metodo === 'POST' && url === '/api/estancias' && body && $('#ppBox') && !$('#ppBox').hidden) {
      const L = ppLista();
      if (L.some((x) => !x.fecha)) return Promise.reject(new Error('Falta la fecha de un pago anterior'));
      body = { ...body, pagos_previos: L };
    }
    return _api(metodo, url, body);
  };
}
