// Maxsel Hotel 1.34 — Tickets claros:
//  • Al abonar o renovar (extender) sale un COMPROBANTE DE PAGO con lo que se pagó en ese momento (antes el ticket mostraba
//    el total acumulado de la cuenta: pagaban 3,000 y decía 6,000 porque eran 2 semanas en total).
//  • El estado de cuenta y la salida salen cortos: resumen de la cuenta y solo los últimos 3 pagos.
'use strict';
const CONC_TK = { hospedaje: 'Renta', multa: 'Multa', mora: 'Interés moratorio', limpieza: 'Cuota de limpieza', mascota: 'Cuota por mascota', otro: 'Otro cargo', deposito: 'Depósito' };
const metTk = (p) => String(MET[p.metodo] || p.metodo || '').replace(/<[^>]*>/g, '');
const pagosDe = (e) => (e.pagos || []).filter((p) => !p.venta_id);
// Pagos del último movimiento (un cobro puede guardarse en varios renglones: renta, cuotas, varios métodos)
const pagosUltimo = (e) => { const ps = pagosDe(e).filter((p) => !p.cancela_id && !p.cancelado); if (!ps.length) return []; const f = ps[ps.length - 1].fecha; return ps.filter((p) => p.fecha === f); };
function cabeceraHuesped(e, titulo) {
  const raya = '-'.repeat(W());
  return [...encabezado(), titulo, raya, lin('Folio', e.folio), lin(e.habitacion.clase === 'departamento' ? 'Departamento' : 'Habitación', e.habitacion.numero), ...wrapT('Huésped: ' + e.huesped),
    lin('Tipo de renta', String(MOD[e.modalidad] || e.modalidad).replace(/<[^>]*>/g, '')), lin('Precio', money(e.precio))];
}
function pieCuenta(e) {
  const largo = e.modalidad === 'semana' || e.modalidad === 'mes', L = ['-'.repeat(W())];
  if (e.activa) L.push(lin(largo ? 'Pagado hasta' : 'Check out', fechaTk(e.salida_prevista)));
  if (e.modalidad === 'semana' && e.dia_pago !== null && e.dia_pago !== undefined && typeof DIAS_PAGO !== 'undefined') L.push(lin('Día de pago', 'cada ' + DIAS_PAGO[Number(e.dia_pago)].toLowerCase()));
  if (e.saldo > 0.009) L.push(lin('SALDO PENDIENTE', money(e.saldo)));
  else if (e.saldo < -0.009) L.push(lin('SALDO A FAVOR', money(-e.saldo)));
  else L.push(lin('Saldo', 'Al corriente'));
  return L;
}

// ---------- Comprobante de pago (abono, anticipo, renovación o cambio de renta) ----------
async function imprimirRecibo(eid, titulo, pago, detalle) {
  const e = await GET('/api/estancias/' + eid), raya = '-'.repeat(W());
  // Los renglones de ESTE cobro: del más reciente hacia atrás hasta juntar lo que se cobró (aunque haya otros cobros en el mismo segundo)
  let ps = pagosUltimo(e); const meta = Math.round(((Number(pago?.total) || 0) - (Number(pago?.cambio) || 0)) * 100) / 100; // lo recibido menos el cambio = lo cobrado
  if (meta > 0) { const todos = pagosDe(e).filter((p) => !p.cancela_id && !p.cancelado), sel = []; let suma = 0; for (let i = todos.length - 1; i >= 0 && suma < meta - 0.004; i--) { sel.unshift(todos[i]); suma += Number(todos[i].monto || 0); } if (Math.abs(suma - meta) < 0.01) ps = sel; }
  const L = [...cabeceraHuesped(e, titulo), raya];
  if (detalle) L.push(...detalle, raya);
  L.push('ESTE PAGO');
  const porConcepto = {};
  for (const p of ps) { const k = CONC_TK[p.concepto] || p.concepto; porConcepto[k] = (porConcepto[k] || 0) + Number(p.monto || 0); }
  for (const [k, m] of Object.entries(porConcepto)) L.push(lin(k, money(m)));
  const total = ps.reduce((s, p) => s + Number(p.monto || 0), 0) || meta;
  L.push(lin('TOTAL PAGADO', money(total)));
  const porMet = {};
  for (const p of ps) { const k = metTk(p); porMet[k] = (porMet[k] || 0) + (p.usd ? 0 : Number(p.monto || 0)); if (p.usd) porMet[k + ' (US$)'] = (porMet[k + ' (US$)'] || 0) + Number(p.usd); }
  if (Object.keys(porMet).length) { L.push('Forma de pago:'); for (const [k, m] of Object.entries(porMet)) if (m) L.push(lin('  ' + k, /US\$/.test(k) ? 'US$' + m.toFixed(2) : money(m))); }
  L.push(...lineasPago(pago), ...pieCuenta(e), '', CFG.ticket_pie || '');
  imprimir(L);
}
{
  const _api = api;
  api = async function (metodo, url, body) {
    const r = await _api(metodo, url, body);
    try {
      const m = metodo === 'POST' && /^\/api\/estancias\/(\d+)\/(extender|pago)$/.exec(url);
      if (m) {
        const pago = m[2] === 'extender' ? r?.pago : r;
        if (pago && Number(pago.total) > 0) {
          let titulo = 'COMPROBANTE DE PAGO', det = null;
          if (m[2] === 'extender') {
            const n = Number(body.cantidad) || 0, mod = body.modalidad;
            titulo = 'RENOVACIÓN DE RENTA';
            if (n > 0) det = [lin('Se agregó', unidad(mod, n)), lin('Importe', money(n * (Number(body.precio) || 0)))];
          } else if (body?.nota === 'anticipo') titulo = 'COMPROBANTE DE ANTICIPO';
          else titulo = 'COMPROBANTE DE ABONO';
          await imprimirRecibo(Number(m[1]), titulo, pago, det);
        }
      }
    } catch { /* si el ticket falla, el cobro ya quedó guardado */ }
    return r;
  };
}

// ---------- Estado de cuenta / salida / entrada: cortos ----------
{
  const _ie = imprimirEstancia;
  imprimirEstancia = async function (id, titulo, pago) {
    if (pago) return _ie(id, titulo, pago); // entrada con cobro: ya es corto (no lleva historial)
    const e = await GET('/api/estancias/' + id), raya = '-'.repeat(W());
    const L = [...cabeceraHuesped(e, titulo), lin('Entrada', fechaTk(e.entrada)), ...(e.salida_real ? [lin('Salió', fechaTk(e.salida_real))] : []), raya,
      lin('Hospedaje (' + unidad(e.modalidad, e.cantidad) + ')', money(e.total_hospedaje)), ...(e.consumo > 0.009 ? [lin('Consumos y cargos', money(e.consumo))] : []),
      lin('TOTAL DE LA CUENTA', money(e.total_hospedaje + e.consumo)), lin('Total pagado', money(e.pagado))];
    const ps = pagosDe(e).filter((p) => !p.cancela_id && !p.cancelado);
    if (ps.length) {
      L.push(raya, ps.length > 3 ? 'ÚLTIMOS 3 PAGOS' : 'PAGOS');
      for (const p of ps.slice(-3)) L.push(lin(soloFecha(p.fecha) + ' ' + metTk(p), money(p.monto)));
    }
    if (e.deposito) L.push(raya, lin('Depósito en resguardo', money(e.deposito_saldo)));
    L.push(...pieCuenta(e), '', CFG.ticket_pie || '');
    imprimir(L);
  };
}
