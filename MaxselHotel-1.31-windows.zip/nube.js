// 1.18 NUBE (Tailscale Funnel) — monitoreo desde el teléfono, igual que Maxsel Tech / Abarrotes.
// Funnel publica https://<computadora>.<red>.ts.net y lo manda al puerto 3051, que solo escucha en
// esta computadora y solo deja CONSULTAR (ver server.js: req.desdeInternet). Nada que instalar en el teléfono.
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';

export function exeTailscale() {
  if (process.platform === 'win32') {
    const c = [path.join(process.env.ProgramFiles || 'C:\\Program Files', 'Tailscale', 'tailscale.exe'),
      path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Tailscale', 'tailscale.exe')];
    for (const f of c) { try { if (fs.existsSync(f)) return f; } catch {} }
    return '';
  }
  for (const d of String(process.env.PATH || '').split(path.delimiter)) { const f = path.join(d, 'tailscale'); try { if (fs.existsSync(f)) return f; } catch {} }
  return '';
}
const RE_LOGIN = /https:\/\/login\.tailscale\.com\/\S+/;
function correrTS(seg, args) {
  return new Promise((resolve) => {
    const exe = exeTailscale();
    if (!exe) return resolve({ out: '', error: 'Tailscale no está instalado en esta computadora.' });
    let out = '', fin = false, c;
    try { c = spawn(exe, args, { windowsHide: true }); } catch (e) { return resolve({ out: '', error: String(e.message || e) }); }
    const terminar = (r) => { if (fin) return; fin = true; clearTimeout(t); clearInterval(iv); resolve(r); };
    c.stdout.on('data', (d) => (out += d)); c.stderr.on('data', (d) => (out += d));
    c.on('error', (e) => terminar({ out, error: String(e.message || e) }));
    c.on('close', (code) => terminar({ out, error: code === 0 ? '' : (out.trim() || 'código ' + code) }));
    // si Tailscale pide habilitar Funnel en la cuenta, regresamos el enlace en lugar de esperar
    const iv = setInterval(() => { if (RE_LOGIN.test(out)) { try { c.kill(); } catch {} terminar({ out, error: '' }); } }, 300);
    const t = setTimeout(() => { try { c.kill(); } catch {} terminar({ out, error: 'Tailscale no respondió a tiempo.' }); }, seg * 1000);
  });
}
async function leerTailscale() {
  const exe = exeTailscale();
  const r = { instalado: !!exe, conectado: false, nombre: '', ip: '' };
  if (!exe) return r;
  const s = await correrTS(8, ['status', '--json']);
  try {
    const j = JSON.parse(s.out);
    r.conectado = j.BackendState === 'Running';
    r.nombre = String(j.Self?.DNSName || '').replace(/\.$/, '');
    r.ip = (j.Self?.TailscaleIPs || []).find((x) => !x.includes(':')) || '';
  } catch {}
  return r;
}
export async function estadoNube(puertoFunnel) {
  const ts = await leerTailscale();
  const out = { instalado: ts.instalado, conectado: ts.conectado, nombre: ts.nombre, ip: ts.ip, funnel: { activo: false, url: ts.nombre ? 'https://' + ts.nombre : '' } };
  if (ts.instalado && ts.conectado) {
    const f = await correrTS(8, ['funnel', 'status', '--json']);
    out.funnel.activo = f.out.includes('127.0.0.1:' + puertoFunnel) && f.out.includes('AllowFunnel');
  }
  return out;
}
export async function cambiarFunnel(activar, puertoFunnel) {
  const r = activar
    ? await correrTS(25, ['funnel', '--bg', '--https=443', 'http://127.0.0.1:' + puertoFunnel])
    : await correrTS(15, ['funnel', '--https=443', 'off']);
  const m = r.out.match(RE_LOGIN);
  if (m) return { habilitar: m[0].replace(/[.,)]+$/, '') };
  if (r.error) {
    let msg = r.error;
    if (/access denied|operator|permission/i.test(msg)) msg = 'Tailscale no dio permiso. Reinicie la computadora y vuelva a intentar. Detalle: ' + msg;
    return { error: msg };
  }
  return { ok: true };
}

// 1.21: nombre corto de esta computadora en Tailscale (cambia la dirección a https://<nombre>.<red>.ts.net)
export async function cambiarNombreTS(nombre) {
  const r = await correrTS(20, ['set', '--hostname=' + nombre]);
  return { error: r.error ? 'Tailscale no aceptó el nombre: ' + r.error : '' };
}

// ---------- 1.25: revisar paso por paso que el acceso por internet funcione, y repararlo solo ----------
import https from 'node:https';
import http from 'node:http';
import dns from 'node:dns';
function pedir(mod, opciones, seg) {
  return new Promise((resolve) => {
    const rq = mod.request({ ...opciones, timeout: seg * 1000 }, (rs) => { let b = ''; rs.on('data', (d) => { if (b.length < 4000) b += d; }); rs.on('end', () => resolve({ ok: true, status: rs.statusCode, cuerpo: b })); });
    rq.on('error', (e) => resolve({ ok: false, error: e.code || e.message }));
    rq.on('timeout', () => { rq.destroy(); resolve({ ok: false, error: 'TIEMPO' }); });
    rq.end();
  });
}
async function ipPublica(nombre) {
  try { const r = new dns.promises.Resolver({ timeout: 4000, tries: 2 }); r.setServers(['8.8.8.8', '1.1.1.1']); const l = await r.resolve4(nombre); return l[0] || ''; } catch { return ''; }
}
// Para qué puerto está publicado Funnel ahorita (o '' si no está)
export async function destinoFunnel() {
  const f = await correrTS(8, ['funnel', 'status', '--json']);
  const m = f.out.match(/127\.0\.0\.1:(\d+)/) || f.out.match(/localhost:(\d+)/);
  return { puerto: m ? Number(m[1]) : 0, publico: f.out.includes('AllowFunnel') };
}
export async function probarNube(puertoFunnel, polizaActiva) {
  const P = [];
  const add = (clave, titulo, ok, detalle) => { P.push({ clave, titulo, ok, detalle }); return ok; };
  if (!add('poliza', 'Póliza con monitoreo vigente', !!polizaActiva, polizaActiva ? 'La licencia trae la póliza.' : 'La licencia no trae la póliza o ya venció. Pida a Maxsel una licencia con póliza.')) return P;
  const ts = await leerTailscale();
  if (!add('instalado', 'Tailscale instalado', ts.instalado, ts.instalado ? 'Sí está instalado.' : 'Instálelo desde tailscale.com/download/windows.')) return P;
  if (!add('sesion', 'Tailscale con sesión iniciada', ts.conectado, ts.conectado ? 'Conectado como ' + ts.nombre : 'Falta iniciar sesión en Tailscale.')) return P;
  const loc = await pedir(http, { host: '127.0.0.1', port: puertoFunnel, path: '/', method: 'GET' }, 5);
  add('entrada', 'Entrada de internet del sistema', loc.ok, loc.ok ? 'El sistema está escuchando (puerto ' + puertoFunnel + ').' : 'El sistema no abrió su entrada de internet. Reinicie Maxsel Hotel.');
  const d = await destinoFunnel();
  const bien = d.puerto === puertoFunnel && d.publico;
  if (!add('funnel', 'Funnel encendido y apuntando al sistema', bien, bien ? 'Publicado hacia el puerto ' + puertoFunnel + '.'
    : d.puerto ? `Funnel está apuntando al puerto ${d.puerto} y debe ser el ${puertoFunnel}. Toque "Reparar".` : 'Funnel está apagado. Toque "Reparar".')) return P;
  const ip = await ipPublica(ts.nombre);
  if (!add('dns', 'La dirección existe en internet', !!ip, ip ? ts.nombre + ' ya se encuentra en internet.' : 'Internet todavía no encuentra la dirección. Si la acaba de crear o cambiar de nombre, espere 10 minutos y vuelva a probar.')) return P;
  // Entra como lo haría un celular desde fuera: por la IP pública de Tailscale, con el nombre de la dirección
  const pub = await pedir(https, { host: ip, servername: ts.nombre, port: 443, path: '/', method: 'GET', headers: { Host: ts.nombre } }, 20);
  const llega = pub.ok && pub.status < 500;
  add('publico', 'Se entra desde internet', llega, llega ? 'Respondió bien: https://' + ts.nombre
    : pub.error === 'TIEMPO' ? 'No respondió a tiempo. Revise el internet del hotel y vuelva a probar.' : 'No se pudo entrar (' + (pub.error || 'error ' + pub.status) + '). Toque "Reparar"; si sigue, espere 10 minutos (Tailscale está sacando el certificado).');
  return P;
}
// Apaga todo lo que haya en Funnel y lo vuelve a publicar hacia el sistema
export async function repararFunnel(puertoFunnel) {
  await correrTS(15, ['funnel', 'reset']);
  return cambiarFunnel(true, puertoFunnel);
}
// Inicia sesión en Tailscale: regresa el enlace para entrar con la cuenta del hotel
export async function sesionTS() {
  const r = await correrTS(25, ['login', '--timeout=20s']);
  const m = r.out.match(RE_LOGIN);
  return m ? { enlace: m[0].replace(/[.,)]+$/, '') } : { error: r.error || '', listo: !r.error };
}
