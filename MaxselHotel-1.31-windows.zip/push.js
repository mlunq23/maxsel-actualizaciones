// Maxsel Hotel 1.21 — notificaciones Web Push (RFC 8291 + VAPID RFC 8292) sin librerías externas.
// Funcionan cuando el personal abre su app desde la dirección segura de Tailscale Funnel (https://...ts.net).
import crypto from 'node:crypto';
import https from 'node:https';

const b64u = (b) => Buffer.from(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = (s) => Buffer.from(String(s).replace(/-/g, '+').replace(/_/g, '/'), 'base64');
const hmac = (k, d) => crypto.createHmac('sha256', k).update(d).digest();

export function clavesNuevas() {
  const e = crypto.createECDH('prime256v1'); e.generateKeys();
  return { publica: b64u(e.getPublicKey()), privada: b64u(e.getPrivateKey()) };
}

// Cifra el mensaje para un navegador (aes128gcm). `prueba` permite fijar la llave y la sal (para comprobar contra el RFC).
export function cifrar(texto, p256dh, auth, prueba) {
  const ua = unb64u(p256dh), secreto = unb64u(auth);
  const as = crypto.createECDH('prime256v1');
  if (prueba?.privada) as.setPrivateKey(unb64u(prueba.privada)); else as.generateKeys();
  const asPub = as.getPublicKey(), compartido = as.computeSecret(ua);
  const prkKey = hmac(secreto, compartido);
  const ikm = hmac(prkKey, Buffer.concat([Buffer.from('WebPush: info\0'), ua, asPub, Buffer.from([1])]));
  const sal = prueba?.sal ? unb64u(prueba.sal) : crypto.randomBytes(16);
  const prk = hmac(sal, ikm);
  const cek = hmac(prk, Buffer.from('Content-Encoding: aes128gcm\0\x01', 'binary')).subarray(0, 16);
  const nonce = hmac(prk, Buffer.from('Content-Encoding: nonce\0\x01', 'binary')).subarray(0, 12);
  const c = crypto.createCipheriv('aes-128-gcm', cek, nonce);
  const ct = Buffer.concat([c.update(Buffer.concat([Buffer.from(texto, 'utf8'), Buffer.from([2])])), c.final(), c.getAuthTag()]);
  const rs = Buffer.alloc(4); rs.writeUInt32BE(4096);
  return Buffer.concat([sal, rs, Buffer.from([asPub.length]), asPub, ct]);
}

function jwtVapid(endpoint, claves, contacto) {
  const aud = new URL(endpoint).origin;
  const h = b64u(JSON.stringify({ typ: 'JWT', alg: 'ES256' }));
  const p = b64u(JSON.stringify({ aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: contacto || 'mailto:soporte@maxsel.mx' }));
  const pub = unb64u(claves.publica);
  const key = crypto.createPrivateKey({ key: { kty: 'EC', crv: 'P-256', d: claves.privada, x: b64u(pub.subarray(1, 33)), y: b64u(pub.subarray(33, 65)) }, format: 'jwk' });
  const firma = crypto.sign('sha256', Buffer.from(h + '.' + p), { key, dsaEncoding: 'ieee-p1363' });
  return h + '.' + p + '.' + b64u(firma);
}

// Manda una notificación. Regresa 'ok', 'borrar' (la suscripción ya no existe) o 'error'.
export function mandarPush(sub, datos, claves, urgencia = 'high') {
  return new Promise((resolve) => {
    let u; try { u = new URL(sub.endpoint); } catch { return resolve('borrar'); }
    if (u.protocol !== 'https:') return resolve('borrar');
    let cuerpo; try { cuerpo = cifrar(JSON.stringify(datos), sub.p256dh, sub.auth); } catch { return resolve('borrar'); }
    const rq = https.request(u, { method: 'POST', timeout: 15000, headers: {
      'Content-Type': 'application/octet-stream', 'Content-Encoding': 'aes128gcm', 'Content-Length': cuerpo.length,
      TTL: '86400', Urgency: urgencia, Authorization: `vapid t=${jwtVapid(sub.endpoint, claves)}, k=${claves.publica}` } }, (rs) => {
      rs.resume();
      resolve(rs.statusCode < 300 ? 'ok' : [404, 410].includes(rs.statusCode) ? 'borrar' : 'error');
    });
    rq.on('error', () => resolve('error')); rq.on('timeout', () => { rq.destroy(); resolve('error'); });
    rq.end(cuerpo);
  });
}
