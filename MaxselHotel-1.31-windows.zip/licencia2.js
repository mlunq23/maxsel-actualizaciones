// ---------- Licencia de Maxsel Hotel (1.19) ----------
// Igual que licencia.js pero entiende la licencia versión 3, que trae además la fecha en que
// vence el MONITOREO REMOTO (Tailscale Funnel = póliza anual). La clave pública se lee de
// licencia.js (ahí la pone CREAR_INSTALADOR.bat; las actualizaciones no tocan ese archivo).
import crypto from 'node:crypto';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { DATA_DIR, hoy } from './db.js';

const CLAVE_PUBLICA = (() => {
  try { const t = fs.readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), 'licencia.js'), 'utf8'); const m = t.match(/const CLAVE_PUBLICA = '([^']+)'/); if (m) return m[1]; } catch { /* abajo */ }
  return '__CLAVE_PUBLICA__';
})();
export const MODO_DESARROLLO = CLAVE_PUBLICA.startsWith('__');
const LIC_FILE = path.join(DATA_DIR, 'licencia.txt');
const B32 = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
const DIA0 = Date.UTC(2020, 0, 1);

function b32enc(buf) { let bits = 0, val = 0, out = ''; for (const b of buf) { val = (val << 8) | b; bits += 8; while (bits >= 5) { out += B32[(val >>> (bits - 5)) & 31]; bits -= 5; } } if (bits > 0) out += B32[(val << (5 - bits)) & 31]; return out; }
function b32dec(s) {
  s = String(s).toUpperCase().replace(/[^0-9A-Z]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1');
  const out = []; let bits = 0, val = 0;
  for (const ch of s) { const i = B32.indexOf(ch); if (i < 0) throw new Error('Carácter inválido'); val = (val << 5) | i; bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } }
  return Buffer.from(out);
}

// Módulos que se activan desde la licencia (bit por módulo). Las licencias viejas traen todos.
export const MODULOS = { gastos: 1, asistencia: 2 };
export const NOMBRE_MODULO = { gastos: 'Gastos', asistencia: 'Asistencia (checador de empleados)' };
const MOD_TODOS = 255;
const modulosDe = (b) => Object.fromEntries(Object.entries(MODULOS).map(([k, bit]) => [k, !!(b & bit)]));
function modulosPrueba() { // en modo desarrollo se pueden apagar para probar: MAXSEL_SIN_MODULOS=gastos,asistencia
  const sin = String(process.env.MAXSEL_SIN_MODULOS || '').split(',').map((x) => x.trim());
  return Object.fromEntries(Object.keys(MODULOS).map((k) => [k, !sin.includes(k)]));
}
export const moduloActivo = (k) => (LICENCIA.modulos ? LICENCIA.modulos[k] !== false : true);

let _equipo = null;
function idEquipoBytes() {
  if (_equipo) return _equipo;
  let base = '';
  try {
    if (process.platform === 'win32') {
      const r = execSync('reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid', { encoding: 'utf8', windowsHide: true });
      const m = r.match(/MachineGuid\s+REG_SZ\s+([0-9a-fA-F-]+)/); if (m) base = m[1].toLowerCase();
    } else {
      base = fs.readFileSync('/etc/machine-id', 'utf8').trim();
    }
  } catch { /* respaldo abajo */ }
  if (!base) base = os.hostname() + '|' + (os.cpus()[0] || {}).model + '|' + os.totalmem();
  _equipo = crypto.createHash('sha256').update('maxsel-hotel|' + base).digest().subarray(0, 10);
  return _equipo;
}
export const codigoEquipo = () => b32enc(idEquipoBytes()).match(/.{1,4}/g).join('-');
export const huella = () => (MODO_DESARROLLO ? '' : crypto.createHash('sha256').update(CLAVE_PUBLICA).digest('hex').slice(0, 8).toUpperCase());

function leerLicencia(clave) {
  if (!clave) return { activa: false, motivo: 'Sin licencia' };
  try {
    const buf = b32dec(String(clave).trim().replace(/^HT1-?/i, ''));
    // Versión 1: sin módulos (trae todo). Versión 2: un byte extra con los módulos que se vendieron.
    // Versión 3: además 2 bytes (después de la vigencia) con el día en que vence el monitoreo remoto (0 = no incluido).
    const v = buf[0];
    if (buf.length < 14 + 64 || ![1, 2, 3].includes(v)) throw new Error();
    const ini = v === 3 ? 16 : 14, nl = buf[ini - 1], extra = v >= 2 ? 1 : 0;
    const payload = buf.subarray(0, ini + nl + extra), firma = buf.subarray(ini + nl + extra, ini + nl + extra + 64);
    if (firma.length !== 64) throw new Error();
    const pub = crypto.createPublicKey({ key: Buffer.from(CLAVE_PUBLICA, 'base64'), format: 'der', type: 'spki' });
    if (!crypto.verify(null, payload, pub, firma)) return { activa: false, motivo: 'La licencia no es válida para este instalador: fue hecha con OTRO activador de licencias. Use el activador de la misma carpeta con la que se creó el instalador.' };
    if (!payload.subarray(1, 11).equals(idEquipoBytes())) return { activa: false, motivo: 'Esta licencia es de OTRA computadora' };
    const dias = payload.readUInt16BE(11);
    const cliente = payload.subarray(ini, ini + nl).toString('utf8');
    const expira = dias ? new Date(DIA0 + dias * 86400000).toISOString().slice(0, 10) : null;
    const nd = v === 3 ? payload.readUInt16BE(13) : 0;
    const nubeExpira = nd ? new Date(DIA0 + nd * 86400000).toISOString().slice(0, 10) : null;
    if (expira && expira < hoy()) return { activa: false, cliente, expira, nubeExpira, motivo: 'La licencia VENCIÓ el ' + expira.split('-').reverse().join('/') };
    return { activa: true, cliente, expira, nubeExpira, modulos: modulosDe(extra ? payload[ini + nl] : MOD_TODOS) };
  } catch { return { activa: false, motivo: 'La clave de licencia está incompleta o mal escrita' }; }
}

export let LICENCIA = { activa: false };
export function revisarLicencia() {
  if (MODO_DESARROLLO) { LICENCIA = { activa: true, cliente: 'Modo desarrollo', expira: null, nubeExpira: process.env.MAXSEL_NUBE_VENCE || '2099-12-31', modulos: modulosPrueba() }; return LICENCIA; }
  let clave = ''; try { clave = fs.readFileSync(LIC_FILE, 'utf8').trim(); } catch { /* sin archivo */ }
  LICENCIA = leerLicencia(clave);
  return LICENCIA;
}
// Monitoreo remoto (Tailscale Funnel): incluido en la póliza anual; se activa y vence con la licencia
export function nubeLicencia() {
  const vence = LICENCIA.activa ? LICENCIA.nubeExpira || null : null;
  const dias = vence ? Math.ceil((new Date(vence + 'T23:59:59') - new Date()) / 86400000) : null;
  return { activa: !!vence && vence >= hoy(), vence, dias, incluida: !!vence };
}
export function estadoLicencia() {
  const dias = LICENCIA.expira ? Math.ceil((new Date(LICENCIA.expira + 'T23:59:59') - new Date()) / 86400000) : null;
  return { activa: !!LICENCIA.activa, codigoEquipo: codigoEquipo(), huella: huella(), cliente: LICENCIA.cliente || '', expira: LICENCIA.expira || null, diasRestantes: dias, motivo: LICENCIA.motivo || '', desarrollo: MODO_DESARROLLO,
    modulos: LICENCIA.modulos || modulosDe(MOD_TODOS), nube: nubeLicencia() };
}
export function activarLicencia(clave) {
  const r = leerLicencia(clave);
  if (!r.activa) throw new Error(r.motivo);
  fs.writeFileSync(LIC_FILE, String(clave).trim().toUpperCase());
  revisarLicencia();
  return estadoLicencia();
}
