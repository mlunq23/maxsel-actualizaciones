// Base de datos de Maxsel Hotel (SQLite integrado en Node.js, no requiere instalar nada)
import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

export const DATA_DIR = path.resolve(process.env.HOTEL_DATA || path.join(path.dirname(fileURLToPath(import.meta.url)), 'datos'));
export const RESPALDOS_DIR = path.join(DATA_DIR, 'respaldos');
fs.mkdirSync(RESPALDOS_DIR, { recursive: true });

export const DB_FILE = path.join(DATA_DIR, 'hotel.db');
// Información importada de otra computadora: se pone en lugar de la actual al arrancar (la anterior queda en respaldos)
export const IMPORT_PENDIENTE = path.join(DATA_DIR, 'importar_pendiente.db');
export let SE_IMPORTO = false;
if (fs.existsSync(IMPORT_PENDIENTE)) {
  try {
    const t = Date.now();
    for (const s of ['', '-wal', '-shm']) if (fs.existsSync(DB_FILE + s)) fs.renameSync(DB_FILE + s, path.join(RESPALDOS_DIR, `hotel_reemplazado_${t}.db${s}`));
    fs.renameSync(IMPORT_PENDIENTE, DB_FILE); SE_IMPORTO = true;
    console.log('  Se cargó la información importada de otra computadora');
  } catch (e) { console.error('No se pudo cargar la información importada:', e.message); }
}
export const db = new DatabaseSync(DB_FILE);
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');

db.exec(`
CREATE TABLE IF NOT EXISTS config (clave TEXT PRIMARY KEY, valor TEXT);

CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, usuario TEXT UNIQUE NOT NULL, pass_hash TEXT NOT NULL,
  rol TEXT NOT NULL CHECK (rol IN ('admin','gerente','recepcion','monitor','mantenimiento')), activo INTEGER DEFAULT 1);

CREATE TABLE IF NOT EXISTS sesiones (token TEXT PRIMARY KEY, usuario_id INTEGER, creado TEXT, ip TEXT);

-- clase: habitacion | departamento. camas y amenidades en JSON.
CREATE TABLE IF NOT EXISTS habitaciones (
  id INTEGER PRIMARY KEY, numero TEXT UNIQUE NOT NULL, nombre TEXT, clase TEXT DEFAULT 'habitacion',
  piso TEXT, camas TEXT DEFAULT '{}', recamaras INTEGER DEFAULT 1, banos INTEGER DEFAULT 1, capacidad INTEGER DEFAULT 2,
  amenidades TEXT DEFAULT '[]', precio_dia REAL DEFAULT 0, precio_semana REAL DEFAULT 0, precio_mes REAL DEFAULT 0,
  estado TEXT DEFAULT 'libre' CHECK (estado IN ('libre','ocupada','limpieza','mant')), nota TEXT, activo INTEGER DEFAULT 1);

-- Los datos del huésped se capturan en la estancia (no hay catálogo de clientes)
CREATE TABLE IF NOT EXISTS estancias (
  id INTEGER PRIMARY KEY, folio TEXT, habitacion_id INTEGER NOT NULL,
  huesped TEXT NOT NULL, telefono TEXT, identificacion TEXT, procedencia TEXT, placas TEXT, personas INTEGER DEFAULT 1,
  modalidad TEXT NOT NULL, cantidad INTEGER NOT NULL, precio REAL NOT NULL,
  total_hospedaje REAL NOT NULL, entrada TEXT NOT NULL, salida_prevista TEXT NOT NULL, salida_real TEXT,
  activa INTEGER DEFAULT 1, notas TEXT, usuario_id INTEGER);

CREATE TABLE IF NOT EXISTS cargos (
  id INTEGER PRIMARY KEY, estancia_id INTEGER NOT NULL, fecha TEXT, descripcion TEXT, cantidad REAL, importe REAL, venta_id INTEGER);

CREATE TABLE IF NOT EXISTS pagos (
  id INTEGER PRIMARY KEY, fecha TEXT, monto REAL, metodo TEXT, concepto TEXT, estancia_id INTEGER, venta_id INTEGER, usuario_id INTEGER, nota TEXT);

CREATE TABLE IF NOT EXISTS visitantes (
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, identificacion TEXT, habitacion_id INTEGER, estancia_id INTEGER,
  motivo TEXT, entrada TEXT, salida TEXT, usuario_id INTEGER);

CREATE TABLE IF NOT EXISTS productos (
  id INTEGER PRIMARY KEY, codigo TEXT, nombre TEXT NOT NULL, costo REAL DEFAULT 0, precio REAL NOT NULL,
  existencia REAL DEFAULT 0, minimo REAL DEFAULT 0, activo INTEGER DEFAULT 1);

CREATE TABLE IF NOT EXISTS ventas (
  id INTEGER PRIMARY KEY, folio TEXT, fecha TEXT, total REAL, metodo TEXT, estancia_id INTEGER,
  recibido REAL DEFAULT 0, cambio REAL DEFAULT 0, usuario_id INTEGER, cancelada INTEGER DEFAULT 0);

CREATE TABLE IF NOT EXISTS venta_items (
  id INTEGER PRIMARY KEY, venta_id INTEGER NOT NULL, producto_id INTEGER, descripcion TEXT, cantidad REAL, precio REAL, costo REAL, importe REAL);

CREATE TABLE IF NOT EXISTS movimientos (
  id INTEGER PRIMARY KEY, fecha TEXT, producto_id INTEGER, tipo TEXT, cantidad REAL, referencia TEXT, usuario_id INTEGER);

CREATE TABLE IF NOT EXISTS bitacora (
  id INTEGER PRIMARY KEY, fecha TEXT, habitacion_id INTEGER, estado TEXT, nota TEXT, usuario_id INTEGER);

CREATE INDEX IF NOT EXISTS ix_est_hab ON estancias(habitacion_id, activa);
CREATE INDEX IF NOT EXISTS ix_pagos_fecha ON pagos(fecha);
CREATE INDEX IF NOT EXISTS ix_cargos_est ON cargos(estancia_id);
CREATE INDEX IF NOT EXISTS ix_vis_est ON visitantes(estancia_id);
`);

// ---------- Versión 1.1: gastos, depósitos, contratos y mantenimiento ----------
// Agrega el tipo de usuario "mantenimiento" (SQLite no permite cambiar un CHECK: se reconstruye la tabla)
if (!String(db.prepare("SELECT sql FROM sqlite_master WHERE name='usuarios'").get().sql).includes('mantenimiento')) {
  db.exec(`PRAGMA foreign_keys=OFF; BEGIN;
    CREATE TABLE usuarios_nueva (id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, usuario TEXT UNIQUE NOT NULL, pass_hash TEXT NOT NULL,
      rol TEXT NOT NULL CHECK (rol IN ('admin','recepcion','monitor','mantenimiento')), activo INTEGER DEFAULT 1);
    INSERT INTO usuarios_nueva SELECT id,nombre,usuario,pass_hash,rol,activo FROM usuarios;
    DROP TABLE usuarios; ALTER TABLE usuarios_nueva RENAME TO usuarios; COMMIT; PRAGMA foreign_keys=ON;`);
}
db.exec(`
CREATE TABLE IF NOT EXISTS gastos (
  id INTEGER PRIMARY KEY, folio TEXT, fecha TEXT, concepto TEXT NOT NULL, categoria TEXT, monto REAL NOT NULL, metodo TEXT,
  entrega TEXT, recibe TEXT, firma_entrega TEXT, firma_recibe TEXT, habitacion_id INTEGER, ticket_id INTEGER, nota TEXT,
  usuario_id INTEGER, cancelado INTEGER DEFAULT 0);

-- tipo: recibido | devuelto | retenido
CREATE TABLE IF NOT EXISTS depositos (
  id INTEGER PRIMARY KEY, estancia_id INTEGER NOT NULL, fecha TEXT, tipo TEXT NOT NULL, monto REAL NOT NULL, metodo TEXT,
  motivo TEXT, recibe TEXT, firma TEXT, ticket_id INTEGER, folio TEXT, usuario_id INTEGER);

CREATE TABLE IF NOT EXISTS contratos (
  id INTEGER PRIMARY KEY, folio TEXT, estancia_id INTEGER NOT NULL, fecha TEXT, arrendatario TEXT, identificacion TEXT, domicilio TEXT,
  telefono TEXT, inicio TEXT, fin TEXT, modalidad TEXT, renta REAL, deposito REAL, dia_pago TEXT, texto TEXT,
  firma_arrendador TEXT, firma_arrendatario TEXT, usuario_id INTEGER);

-- estado: pendiente | proceso | terminado
CREATE TABLE IF NOT EXISTS mantenimiento (
  id INTEGER PRIMARY KEY, folio TEXT, habitacion_id INTEGER, titulo TEXT NOT NULL, descripcion TEXT, prioridad TEXT DEFAULT 'normal',
  estado TEXT DEFAULT 'pendiente', alta TEXT, alta_usuario INTEGER, inicio TEXT, atiende_usuario INTEGER, cierre TEXT, cierre_usuario INTEGER,
  nota_cierre TEXT, costo REAL DEFAULT 0, gasto_id INTEGER, estancia_id INTEGER);

CREATE TABLE IF NOT EXISTS mant_fotos (id INTEGER PRIMARY KEY, mant_id INTEGER NOT NULL, tipo TEXT, archivo TEXT, fecha TEXT, usuario_id INTEGER);

CREATE INDEX IF NOT EXISTS ix_gastos_fecha ON gastos(fecha);
CREATE INDEX IF NOT EXISTS ix_dep_est ON depositos(estancia_id);
CREATE INDEX IF NOT EXISTS ix_mant_estado ON mantenimiento(estado);
`);
const colsEst = db.prepare('PRAGMA table_info(estancias)').all().map((c) => c.name);
if (!colsEst.includes('domicilio')) db.exec('ALTER TABLE estancias ADD COLUMN domicilio TEXT');
// ---------- Versión 1.2: caja con turnos, dólares y permisos por usuario ----------
db.exec(`
CREATE TABLE IF NOT EXISTS turnos (
  id INTEGER PRIMARY KEY, usuario_id INTEGER NOT NULL, apertura TEXT NOT NULL, cierre TEXT,
  fondo_mxn REAL DEFAULT 0, fondo_usd REAL DEFAULT 0, tipo_cambio REAL NOT NULL,
  decl_mxn REAL, decl_usd REAL, decl_tarjeta REAL, decl_transferencia REAL, notas TEXT, estado TEXT DEFAULT 'abierto');
CREATE TABLE IF NOT EXISTS caja_mov (
  id INTEGER PRIMARY KEY, turno_id INTEGER NOT NULL, usuario_id INTEGER, fecha TEXT, tipo TEXT NOT NULL, moneda TEXT NOT NULL, monto REAL NOT NULL, motivo TEXT);
CREATE INDEX IF NOT EXISTS ix_turnos_usr ON turnos(usuario_id, estado);
`);
function columna(tabla, col, def) {
  if (!db.prepare(`PRAGMA table_info(${tabla})`).all().some((c) => c.name === col)) db.exec(`ALTER TABLE ${tabla} ADD COLUMN ${col} ${def}`);
}
columna('usuarios', 'permisos', 'TEXT');
for (const t of ['pagos', 'depositos', 'gastos', 'ventas']) columna(t, 'turno_id', 'INTEGER');
for (const t of ['pagos', 'depositos']) { columna(t, 'usd', 'REAL DEFAULT 0'); columna(t, 'tc', 'REAL DEFAULT 0'); }
columna('pagos', 'cambio', 'REAL DEFAULT 0');
columna('depositos', 'cambio', 'REAL DEFAULT 0');
columna('depositos', 'recibido', 'REAL DEFAULT 0'); // con cuánto pagaron el depósito (1.2.2)
columna('visitantes', 'cobro', 'REAL DEFAULT 0');
// ---------- Versión 1.4: rentas por rato / noche / día / semana / mes, gastos fijos ----------
// Quita el CHECK viejo de modalidad (solo permitía día, semana y mes)
{
  const sqlEst = String(db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='estancias'").get().sql);
  if (/CHECK\s*\(\s*modalidad\s+IN/i.test(sqlEst)) {
    const cols = db.prepare('PRAGMA table_info(estancias)').all().map((c) => c.name).join(',');
    const nuevo = sqlEst.replace(/CHECK\s*\(\s*modalidad\s+IN\s*\([^)]*\)\s*\)/i, '').replace(/CREATE TABLE\s+"?estancias"?/i, 'CREATE TABLE estancias_nueva');
    db.exec(`PRAGMA foreign_keys=OFF; BEGIN; ${nuevo}; INSERT INTO estancias_nueva(${cols}) SELECT ${cols} FROM estancias;
      DROP TABLE estancias; ALTER TABLE estancias_nueva RENAME TO estancias; COMMIT; PRAGMA foreign_keys=ON;
      CREATE INDEX IF NOT EXISTS ix_est_hab ON estancias(habitacion_id, activa);`);
  }
}
columna('habitaciones', 'precio_rato', 'REAL DEFAULT 0');
columna('habitaciones', 'precio_noche', 'REAL DEFAULT 0');
columna('estancias', 'inicio_tramo', 'TEXT');           // desde cuándo corre la renta actual (cambia al pasar de día a semana, etc.)
columna('estancias', 'hospedaje_previo', 'REAL DEFAULT 0'); // lo que se generó antes de cambiar el tipo de renta
columna('estancias', 'turno_id', 'INTEGER');
columna('estancias', 'hora_checkout', 'TEXT');      // 1.7.2 hora de check out elegida al registrar
columna('estancias', 'cobros_auto', 'INTEGER DEFAULT 0'); // 1.7.2 veces que se cobró sola por no registrar la salida
columna('pagos', 'modalidad', 'TEXT');
columna('pagos', 'cancelado', 'TEXT');       // 1.30: fecha en que el administrador canceló este cobro
columna('pagos', 'cancela_id', 'INTEGER');   // 1.30: este renglón (negativo) cancela el cobro con ese id
columna('gastos', 'fijo_id', 'INTEGER');
columna('visitantes', 'turno_id', 'INTEGER');
columna('gastos', 'grupo', 'TEXT'); // clasificación del gasto (1.5): Nómina y personal, Compras, Impuestos…
// ---------- Versión 1.6: empleados y proveedores ligados a los gastos ----------
db.exec(`
CREATE TABLE IF NOT EXISTS empleados (
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, puesto TEXT, telefono TEXT, ingreso TEXT, sueldo REAL DEFAULT 0, periodo_pago TEXT DEFAULT 'semanal',
  nss TEXT, rfc TEXT, curp TEXT, domicilio TEXT, emergencia TEXT, notas TEXT, activo INTEGER DEFAULT 1, creado TEXT);
CREATE TABLE IF NOT EXISTS proveedores (
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, contacto TEXT, telefono TEXT, correo TEXT, rfc TEXT, surte TEXT, banco TEXT, cuenta TEXT, notas TEXT,
  activo INTEGER DEFAULT 1, creado TEXT);
`);
columna('gastos', 'empleado_id', 'INTEGER');
columna('gastos', 'proveedor_id', 'INTEGER');
columna('gastos', 'factura', 'TEXT');   // número de factura, nota o folio / línea de captura
columna('gastos', 'periodo', 'TEXT');   // periodo que se paga (ej. semana 41, septiembre 2026)
db.exec('CREATE INDEX IF NOT EXISTS ix_gastos_emp ON gastos(empleado_id); CREATE INDEX IF NOT EXISTS ix_gastos_prov ON gastos(proveedor_id);');
// ---------- Versión 1.7: control de asistencia ----------
columna('empleados', 'numero', 'TEXT');      // número para checar
columna('empleados', 'pin', 'TEXT');         // NIP (guardado cifrado)
columna('empleados', 'horario', 'TEXT');     // JSON {0..6: {entrada, salida, descanso}} 0=domingo; null = día de descanso
columna('empleados', 'huella', 'TEXT');      // plantilla de huella (cuando se conecte el lector)
db.exec(`
CREATE TABLE IF NOT EXISTS checadas (
  id INTEGER PRIMARY KEY, empleado_id INTEGER NOT NULL, fecha TEXT NOT NULL, tipo TEXT NOT NULL, metodo TEXT, usuario_id INTEGER, nota TEXT, anulada INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS ix_checadas ON checadas(empleado_id, fecha);
CREATE TABLE IF NOT EXISTS festivos (id INTEGER PRIMARY KEY, fecha TEXT UNIQUE NOT NULL, nombre TEXT, descansa INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS incidencias (
  id INTEGER PRIMARY KEY, empleado_id INTEGER NOT NULL, tipo TEXT NOT NULL, desde TEXT NOT NULL, hasta TEXT NOT NULL, nota TEXT, usuario_id INTEGER, creado TEXT);
CREATE INDEX IF NOT EXISTS ix_incid ON incidencias(empleado_id, desde);
CREATE TABLE IF NOT EXISTS cierres (id INTEGER PRIMARY KEY, mes TEXT UNIQUE NOT NULL, fecha TEXT, usuario_id INTEGER, notas TEXT, datos TEXT);
`);
db.exec(`
-- Cada renta, extensión o cambio de tipo de renta (para el corte: cuántos ratos, noches, días, semanas, meses)
CREATE TABLE IF NOT EXISTS rentas (
  id INTEGER PRIMARY KEY, estancia_id INTEGER NOT NULL, fecha TEXT, turno_id INTEGER, usuario_id INTEGER,
  modalidad TEXT NOT NULL, cantidad INTEGER NOT NULL, precio REAL, importe REAL, tipo TEXT);
CREATE INDEX IF NOT EXISTS ix_rentas_turno ON rentas(turno_id);
CREATE INDEX IF NOT EXISTS ix_rentas_fecha ON rentas(fecha);
-- Gastos fijos: luz, agua, internet, renta… con vencimiento y aviso
CREATE TABLE IF NOT EXISTS gastos_fijos (
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, categoria TEXT, proveedor TEXT, contrato TEXT, referencia TEXT,
  monto REAL DEFAULT 0, periodo TEXT DEFAULT 'mensual', vence TEXT, dias_aviso INTEGER DEFAULT 5, domiciliado INTEGER DEFAULT 0,
  notas TEXT, activo INTEGER DEFAULT 1, creado TEXT);
`);
db.exec("UPDATE estancias SET inicio_tramo=entrada WHERE inicio_tramo IS NULL");
// ---------- Versión 1.8 ----------
// Tipo de usuario "gerente" (SQLite no permite cambiar un CHECK: se reconstruye la tabla)
if (!String(db.prepare("SELECT sql FROM sqlite_master WHERE name='usuarios'").get().sql).includes('gerente')) {
  const cols = db.prepare('PRAGMA table_info(usuarios)').all().map((c) => c.name).join(',');
  db.exec(`PRAGMA foreign_keys=OFF; BEGIN;
    CREATE TABLE usuarios_nueva (id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, usuario TEXT UNIQUE NOT NULL, pass_hash TEXT NOT NULL,
      rol TEXT NOT NULL CHECK (rol IN ('admin','gerente','recepcion','monitor','mantenimiento')), activo INTEGER DEFAULT 1, permisos TEXT);
    INSERT INTO usuarios_nueva(${cols}) SELECT ${cols} FROM usuarios;
    DROP TABLE usuarios; ALTER TABLE usuarios_nueva RENAME TO usuarios; COMMIT; PRAGMA foreign_keys=ON;`);
}
// ---------- Versión 1.14: usuario de tipo "limpieza" (camaristas) y tareas asignadas a una persona ----------
{
  const sql = String(db.prepare("SELECT sql FROM sqlite_master WHERE name='usuarios'").get().sql);
  if (!sql.includes("'limpieza'")) {
    const cols = db.prepare('PRAGMA table_info(usuarios)').all().map((c) => c.name).join(',');
    const nuevo = sql.replace(/CREATE TABLE\s+"?usuarios"?/i, 'CREATE TABLE usuarios_nueva').replace("'mantenimiento')", "'mantenimiento','limpieza')");
    if (!nuevo.includes("'limpieza'")) throw new Error('No se pudo preparar el tipo de usuario Limpieza');
    db.exec(`PRAGMA foreign_keys=OFF; BEGIN; ${nuevo}; INSERT INTO usuarios_nueva(${cols}) SELECT ${cols} FROM usuarios;
      DROP TABLE usuarios; ALTER TABLE usuarios_nueva RENAME TO usuarios; COMMIT; PRAGMA foreign_keys=ON;`);
  }
}
columna('mantenimiento', 'asignado_a', 'INTEGER');
// 1.21: notificaciones al celular del personal. Lo que ya estaba abierto al actualizar no se avisa
if (!db.prepare('PRAGMA table_info(mantenimiento)').all().some((c) => c.name === 'avisado')) { db.exec('ALTER TABLE mantenimiento ADD COLUMN avisado TEXT'); db.exec("UPDATE mantenimiento SET avisado='antes' WHERE estado<>'terminado'"); }
columna('habitaciones', 'unidad', 'TEXT');          // unidad de negocio: Hotel, Departamentos del callejón, Locales comerciales…
columna('habitaciones', 'precio_visita', 'REAL');   // precio fijo de visita de esa habitación (vacío = el general)
columna('cargos', 'tipo', "TEXT DEFAULT 'consumo'"); // consumo | multa | mora | limpieza | mascota | otro
columna('cargos', 'usuario_id', 'INTEGER');
columna('estancias', 'mora_renta_id', 'INTEGER');   // última renta a la que ya se le cobró interés moratorio
columna('estancias', 'mascotas', 'INTEGER DEFAULT 0');
columna('estancias', 'entrada_registro', 'TEXT'); // 1.15: cuándo se capturó, si el administrador puso otra fecha de ingreso
columna('estancias', 'entrada_por', 'INTEGER');
columna('estancias', 'dia_pago', 'INTEGER');      // 1.23: renta semanal — día de la semana en que paga (0 domingo … 6 sábado)
columna('estancias', 'desc_renueva', 'INTEGER DEFAULT 0'); // 1.16: el descuento se repite al renovar
columna('estancias', 'desc_periodo', 'REAL DEFAULT 0');  // 1.16: cuánto se descuenta por cada periodo
columna('caja_mov', 'autorizo_id', 'INTEGER');      // gerente o administrador que autorizó el egreso
columna('productos', 'area', 'TEXT');               // departamento / área de la tienda
columna('ventas', 'nota', 'TEXT');
columna('productos', 'servicio', 'INTEGER DEFAULT 0');
// Conteos de inventario físico (toma de inventario)
db.exec(`
CREATE TABLE IF NOT EXISTS inventarios (id INTEGER PRIMARY KEY, folio TEXT, fecha TEXT, usuario_id INTEGER, area TEXT, notas TEXT, aplicado INTEGER DEFAULT 1,
  productos INTEGER, faltantes REAL, sobrantes REAL, valor_faltante REAL, valor_sobrante REAL);
CREATE TABLE IF NOT EXISTS inventario_lineas (id INTEGER PRIMARY KEY, inventario_id INTEGER NOT NULL, producto_id INTEGER, codigo TEXT, nombre TEXT, area TEXT,
  sistema REAL, contado REAL, diferencia REAL, costo REAL, precio REAL);
CREATE INDEX IF NOT EXISTS ix_invl ON inventario_lineas(inventario_id);
`); // servicio: no lleva inventario (limpieza, lavandería…)                  // nota de la venta (F4 en la ventana de cobro)
db.exec(`
CREATE INDEX IF NOT EXISTS ix_cargos_tipo ON cargos(tipo, fecha);
-- Cuentas por pagar a proveedores
CREATE TABLE IF NOT EXISTS cuentas_pagar (
  id INTEGER PRIMARY KEY, proveedor_id INTEGER, concepto TEXT NOT NULL, factura TEXT, categoria TEXT, grupo TEXT, monto REAL NOT NULL,
  fecha TEXT, vence TEXT, pagado REAL DEFAULT 0, estado TEXT DEFAULT 'pendiente', notas TEXT, usuario_id INTEGER, creado TEXT, cancelada INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS cuentas_pagos (id INTEGER PRIMARY KEY, cuenta_id INTEGER NOT NULL, gasto_id INTEGER, fecha TEXT, monto REAL, usuario_id INTEGER);
-- Nómina pagada: renglón por empleado con los descuentos de asistencia
CREATE TABLE IF NOT EXISTS nomina_lineas (
  id INTEGER PRIMARY KEY, fecha TEXT, periodo TEXT, empleado_id INTEGER, sueldo REAL, descuento REAL, desc_retardos REAL, desc_faltas REAL,
  retardos INTEGER, faltas INTEGER, puntualidad REAL, bono REAL, festivos REAL, extra REAL, total REAL, usuario_id INTEGER);
-- Relojes checadores por red (ZKTeco ADMS)
CREATE TABLE IF NOT EXISTS relojes (sn TEXT PRIMARY KEY, nombre TEXT, ip TEXT, ultimo TEXT, stamp TEXT, activo INTEGER DEFAULT 1);
`);
// Clasificación de gastos: agrega Marketing y Lavandería a los hoteles que ya tenían su lista
{
  const r = db.prepare("SELECT valor FROM config WHERE clave='gastos_clasificacion'").get();
  if (r && r.valor) {
    let v = r.valor;
    if (!/^\s*marketing/im.test(v)) v = v.replace(/\s*$/, '') + '\nMarketing: Publicidad (marketing fijo), Gastos varios de marketing, Redes sociales, Volantes y lonas';
    if (!/lavander/i.test(v)) v = /^\s*servicios\s*:/im.test(v) ? v.replace(/^(\s*servicios\s*:[^\n]*)/im, '$1, Servicio de lavandería') : v + '\nServicios: Servicio de lavandería';
    if (v !== r.valor) db.prepare("UPDATE config SET valor=? WHERE clave='gastos_clasificacion'").run(v);
  }
}

db.exec(`
-- 1.8 Índices para que el sistema siga rápido con años de información (resultado de la prueba de 2 años)
CREATE INDEX IF NOT EXISTS ix_pagos_est ON pagos(estancia_id, concepto);
CREATE INDEX IF NOT EXISTS ix_pagos_venta ON pagos(venta_id);
CREATE INDEX IF NOT EXISTS ix_pagos_turno ON pagos(turno_id);
CREATE INDEX IF NOT EXISTS ix_rentas_est ON rentas(estancia_id);
CREATE INDEX IF NOT EXISTS ix_cargos_est_tipo ON cargos(estancia_id, tipo);
CREATE INDEX IF NOT EXISTS ix_cargos_venta ON cargos(venta_id);
CREATE INDEX IF NOT EXISTS ix_est_activa ON estancias(activa);
CREATE INDEX IF NOT EXISTS ix_est_entrada ON estancias(entrada);
CREATE INDEX IF NOT EXISTS ix_vis_hab ON visitantes(habitacion_id, salida);
CREATE INDEX IF NOT EXISTS ix_vis_turno ON visitantes(turno_id);
CREATE INDEX IF NOT EXISTS ix_vis_entrada ON visitantes(entrada);
CREATE INDEX IF NOT EXISTS ix_ventas_turno ON ventas(turno_id);
CREATE INDEX IF NOT EXISTS ix_ventas_fecha ON ventas(fecha);
CREATE INDEX IF NOT EXISTS ix_ventas_est ON ventas(estancia_id);
CREATE INDEX IF NOT EXISTS ix_vitems_venta ON venta_items(venta_id);
CREATE INDEX IF NOT EXISTS ix_mov_prod ON movimientos(producto_id);
CREATE INDEX IF NOT EXISTS ix_gastos_turno ON gastos(turno_id);
CREATE INDEX IF NOT EXISTS ix_dep_turno ON depositos(turno_id);
CREATE INDEX IF NOT EXISTS ix_cajamov_turno ON caja_mov(turno_id);
CREATE INDEX IF NOT EXISTS ix_bitacora_fecha ON bitacora(fecha);
CREATE INDEX IF NOT EXISTS ix_mant_hab ON mantenimiento(habitacion_id, estado);
CREATE INDEX IF NOT EXISTS ix_nomina_fecha ON nomina_lineas(fecha);
CREATE INDEX IF NOT EXISTS ix_cxp_pagos ON cuentas_pagos(cuenta_id);
`);
export const FOTOS_DIR = path.join(DATA_DIR, 'fotos');
fs.mkdirSync(FOTOS_DIR, { recursive: true });

// ---------- Ayudantes de consultas ----------
const cache = new Map();
function st(sql) { let s = cache.get(sql); if (!s) { s = db.prepare(sql); cache.set(sql, s); } return s; }
const norm = (p) => (p === undefined ? null : typeof p === 'boolean' ? (p ? 1 : 0) : p);
export const all = (sql, ...p) => st(sql).all(...p.map(norm));
export const get = (sql, ...p) => st(sql).get(...p.map(norm));
export const run = (sql, ...p) => { const r = st(sql).run(...p.map(norm)); return { changes: Number(r.changes), id: Number(r.lastInsertRowid) }; };
let enTx = false;
export function tx(fn) {
  if (enTx) return fn();
  db.exec('BEGIN'); enTx = true;
  try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; } finally { enTx = false; }
}

// ---------- Fechas (hora local de la computadora) ----------
const p2 = (n) => String(n).padStart(2, '0');
export const fechaStr = (d) => `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
export const fechaHora = (d) => `${fechaStr(d)} ${p2(d.getHours())}:${p2(d.getMinutes())}:${p2(d.getSeconds())}`;
export const hoy = () => fechaStr(new Date());
export const ahora = () => fechaHora(new Date());
export const aFecha = (s) => { const [f, h = '00:00:00'] = String(s).split(' '); const [y, m, d] = f.split('-').map(Number); const [hh, mm, ss] = h.split(':').map(Number); return new Date(y, m - 1, d, hh || 0, mm || 0, ss || 0); };
export function salidaPrevista(entrada, modalidad, cantidad, horaSalida, horaFija) {
  const d = aFecha(entrada);
  // Hora de check out elegida al registrar: se respeta en noche, día, semana y mes
  if (horaFija && /^\d{1,2}:\d{2}$/.test(horaFija) && modalidad !== 'rato') {
    if (modalidad === 'dia' && cfg('dia_24h') === '1') d.setDate(d.getDate() + cantidad);
    else if (modalidad === 'mes') { const dia = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + cantidad); d.setDate(Math.min(dia, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate())); }
    else d.setDate(d.getDate() + (modalidad === 'semana' ? 7 : 1) * cantidad);
    const [h, m] = horaFija.split(':').map(Number); d.setHours(h, m, 0, 0); return fechaHora(d);
  }
  // Por rato: N horas desde que entra (3 h por omisión)
  if (modalidad === 'rato') { d.setMinutes(d.getMinutes() + Math.round((Number(cfg('horas_rato')) || 3) * 60) * cantidad); return fechaHora(d); }
  // Por día de 24 horas (opcional): sale a la misma hora en que entró
  if (modalidad === 'dia' && cfg('dia_24h') === '1') { d.setDate(d.getDate() + cantidad); return fechaHora(d); }
  // Por noche: sale al día siguiente a la hora de salida de noche (12:00 por omisión)
  if (modalidad === 'noche') horaSalida = cfg('hora_salida_noche') || '12:00';
  else if (modalidad === 'dia') horaSalida = horaSalida || cfg('hora_salida');
  if (modalidad === 'mes') {
    const dia = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + cantidad);
    d.setDate(Math.min(dia, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate()));
  } else d.setDate(d.getDate() + (modalidad === 'semana' ? 7 : 1) * cantidad);
  const [h, m] = String(horaSalida || '13:00').split(':').map(Number);
  d.setHours(h || 0, m || 0, 0, 0);
  return fechaHora(d);
}
export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

// ---------- Contraseñas ----------
export function hashPass(pass) {
  const salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.scryptSync(String(pass), salt, 32).toString('hex');
}
export function checkPass(pass, hash) {
  const [salt, h] = String(hash).split(':');
  return crypto.timingSafeEqual(crypto.scryptSync(String(pass), salt, 32), Buffer.from(h, 'hex'));
}

// ---------- Configuración ----------
export const CONFIG_DEFAULT = {
  hotel_nombre: 'Mi Hotel',
  hotel_direccion: '',
  hotel_telefono: '',
  hora_salida: '13:00',
  color_rato: '#0d9488',
  color_noche: '#4f46e5',
  color_dia: '#2563eb',
  color_semana: '#e07a10',
  color_mes: '#b4237a',
  ticket_pie: '¡Gracias por su preferencia!',
  hotel_razon_social: '', // 1.31
  hotel_rfc: '', // 1.31
  ticket_leyenda: 'Este ticket no es un comprobante fiscal.', // 1.31
  ticket_ancho: '80',
  arrendador_nombre: '',
  arrendador_domicilio: '',
  ciudad_contrato: 'Tijuana, Baja California',
  gastos_categorias: 'Mantenimiento, Limpieza, Servicios (luz, agua, gas), Internet y cable, Insumos y blancos, Sueldos, Otros',
  contrato_clausulas: '',
  tipo_cambio: '18.50',
  exigir_turno: '1',
  imprimir_auto: '1',               // el ticket se imprime solo al cobrar
  precio_visita: '0',
  impresora_tipo: 'ninguna',
  impresora_nombre: '',
  impresora_ip: '',
  impresora_puerto: '9100',
  impresora_corte: 'parcial',
  impresora_lenguaje: 'escpos', // 1.26: 'escpos' (Epson y genéricas) o 'star' (Star Micronics en modo Star: TSP650, TSP100, TSP143…)
  abrir_cajon: '1',
  // 1.4
  horas_rato: '3',
  hora_salida_noche: '12:00',
  dia_24h: '0',
  modulo_contratos: '1',
  color_libre: '#1b845a',
  color_limpieza: '#b77a06',
  color_mant: '#6550b8',
  color_porvencer: '#ea580c',
  color_vencida: '#c03434',
  aviso_horas: '1',
  aviso_dias: '1',
  // 1.7.2 Si no se registra la salida, al pasar el check out se cobra otro periodo
  cobro_auto: '1',
  cobro_auto_tolerancia: '15',   // minutos de gracia después del check out
  // 1.8
  unidades_negocio: 'Hotel\nDepartamentos del callejón\nOtros departamentos\nLocales comerciales',
  multas_lista: 'Ruido: 500\nFumar en áreas comunes: 1000\nFumar dentro de la habitación: 1500',
  cuota_limpieza: '150',          // cuota de limpieza (cobro de servicio)
  limpieza_auto: 'no',            // cobrarla sola al registrar: no | largas | todas
  cuota_mascota: '200',           // por mascota, por estancia
  mora_activa: '1',               // interés moratorio en rentas por semana/mes que no se pagan a tiempo
  mora_tipo: 'porcentaje',        // porcentaje | fijo
  mora_valor: '10',               // 10% de la renta atrasada, o pesos fijos
  mora_dias: '1',                 // días de gracia después del vencimiento
  mora_aplica: 'semana,mes',
  autoriza_egresos: '1',          // los egresos de caja piden clave de gerente o administrador
  tienda_areas: 'Bebidas, Botanas, Dulces, Abarrotes, Higiene personal, Farmacia, Otros',
  ticket_logo: '',                // logo del ticket (imagen PNG en blanco y negro)
  ticket_logo_ancho: 'mediano',
  ticket_logo_maxsel: '1',        // logo chico de Maxsel al final del ticket (obligatorio, no se puede quitar)
  upd_disponible: '',             // 1.13: versión nueva disponible en internet (la llena el sistema)
  deposito_dias_reclamo: '7',     // 1.12: días para reclamar el depósito después de desocupar
  deposito_plazo_desde: '',       // 1.12: fecha desde la que aplica el plazo (se pone sola al instalar)
  limpieza_foto_obligatoria: '1', // 1.11: pedir foto de evidencia al terminar una limpieza o recibir blancos
  maxsel_contacto: '',            // datos de contacto de Maxsel al final del ticket (un renglón por línea)
  autoriza_gastos: '0',           // 1 = los gastos en efectivo de la caja también piden clave de gerente
  cxp_dias_aviso: '3',            // cuentas por pagar: avisar días antes de que venzan
  reloj_estado: 'auto',           // reloj ZKTeco: auto = el sistema decide entrada/comida/salida · reloj = usa la tecla que oprimen
  // 1.9 Booking.com / Airbnb (calendarios iCal)
  reserva_hora_llegada: '15:00',  // hora de llegada de las reservaciones que llegan de Booking / Airbnb
  ical_token: '',                 // clave secreta de los calendarios que se comparten con Booking / Airbnb
  ical_publico: '0',              // 1 = Booking / Airbnb pueden leer los calendarios desde internet (solo esa dirección)
  ical_url_base: '',              // dirección de internet del hotel (la del monitoreo remoto) para los enlaces
  // 1.10 Huéspedes, lista negra, aviso de privacidad, limpieza, descuentos
  aviso_obligatorio: '1',         // 1 = al registrar hay que marcar que el huésped aceptó el aviso de privacidad
  aviso_privacidad: '',           // texto del aviso (vacío = el de Maxsel)
  tickets_limpieza: '1',          // 1 = al quedar una habitación en limpieza se levanta su ticket de limpieza
  desc_max_pct: '30',             // descuento máximo (gerente y administrador) en porcentaje (0 = sin descuentos)
  desc_max_monto: '0',            // descuento máximo (gerente y administrador) en pesos (0 = sin límite en pesos)
  // 1.5 Clasificación de gastos: una clasificación por renglón y sus conceptos separados por comas
  // 1.7 Asistencia
  asis_metodo: 'ambos',           // checador con: nip | huella | ambos
  asis_tolerancia: '10',          // minutos de tolerancia
  asis_desc_modo: 'fijo',         // fijo | minutos | ninguno
  asis_desc_monto: '50',          // pesos por retardo (modo fijo)
  asis_desc_doble: '0',           // 1 = cada retardo se descuenta doble
  asis_retardos_falta: '3',       // cada N retardos cuentan como 1 falta (0 = no)
  asis_falta_desc: '1',           // descontar el día por falta
  asis_festivo_pago: '2',         // trabajar en día festivo: pago extra de N días (ley: doble adicional)
  gastos_clasificacion: `Nómina y personal: Nómina, Bonos para empleados, Bono de puntualidad, Días festivos, Tiempo extra, Aguinaldo, Vacaciones y prima vacacional, Finiquitos
Compras: Compras para tienda, Compras para mantenimiento, Compras para oficina, Limpieza y blancos
Proveedores: Pago a proveedores
Servicios: Luz, Agua, Gas, Internet y cable, Teléfono, Renta del local, Servicio de lavandería
Mantenimiento: Reparaciones, Mano de obra
Impuestos y gobierno: Seguro Social (IMSS), INFONAVIT, Pagos federales (SAT), Impuesto sobre nómina, Predial y pagos municipales
Honorarios: Contador, Abogado
Marketing: Publicidad (marketing fijo), Gastos varios de marketing, Redes sociales, Volantes y lonas
Otros: Otros gastos`,
};
// Texto base del contrato. Las palabras entre llaves se llenan solas con los datos de la renta.
export const CONTRATO_BASE = `DECLARACIONES

I. Declara EL ARRENDADOR, {arrendador}, con domicilio en {arrendador_domicilio}, que es quien administra el inmueble objeto de este contrato y que tiene facultades para darlo en arrendamiento.

II. Declara EL ARRENDATARIO, {arrendatario}, que se identifica con {identificacion}, con domicilio en {domicilio_arrendatario} y teléfono {telefono}, que conoce el inmueble, que se encuentra en buenas condiciones de uso y que es su voluntad arrendarlo.

Expuesto lo anterior, las partes se sujetan a las siguientes:

CLÁUSULAS

PRIMERA. OBJETO. EL ARRENDADOR da en arrendamiento a EL ARRENDATARIO el {tipo_inmueble} número {inmueble} ubicado en {direccion_hotel}, que incluye: {incluye}. El inmueble se destinará exclusivamente a casa habitación para un máximo de {personas} persona(s).

SEGUNDA. VIGENCIA. El arrendamiento será por {periodo}, iniciando el {fecha_inicio} y terminando el {fecha_fin} a las {hora_salida} horas. Podrá renovarse por periodos iguales si ambas partes están de acuerdo y la renta está al corriente.

TERCERA. RENTA. EL ARRENDATARIO pagará una renta de {renta} ({renta_letra}) por {unidad}, por adelantado, {dia_pago}, en el domicilio de EL ARRENDADOR o por los medios que éste indique. El pago fuera de tiempo dará derecho a EL ARRENDADOR a dar por terminado el contrato.

CUARTA. DEPÓSITO EN GARANTÍA. EL ARRENDATARIO entrega la cantidad de {deposito} ({deposito_letra}) como depósito en garantía. Este depósito no se aplicará al pago de rentas. Se devolverá al desocupar el inmueble, previa revisión, una vez descontado el costo de reparación de los daños, faltantes o adeudos que existan, entregando a EL ARRENDATARIO el comprobante correspondiente.

QUINTA. USO Y CONSERVACIÓN. EL ARRENDATARIO se obliga a conservar el inmueble, mobiliario y equipo en el estado en que lo recibe, salvo el desgaste natural por el uso. Las reparaciones de daños causados por EL ARRENDATARIO, sus acompañantes o visitantes serán por su cuenta.

SEXTA. PROHIBICIONES. Queda prohibido a EL ARRENDATARIO: subarrendar o ceder el inmueble; hacer modificaciones sin autorización por escrito; guardar sustancias peligrosas o ilícitas; causar ruido o molestias a los demás huéspedes; y meter mascotas si el inmueble no lo permite.

SÉPTIMA. VISITAS. Toda visita deberá registrarse en la recepción con identificación oficial. EL ARRENDATARIO es responsable de la conducta de sus visitantes dentro del inmueble.

OCTAVA. REVISIÓN Y MANTENIMIENTO. EL ARRENDATARIO permitirá el acceso al personal de EL ARRENDADOR, previo aviso, para revisar el inmueble o realizar reparaciones.

NOVENA. TERMINACIÓN. Cualquiera de las partes podrá dar por terminado el contrato avisando a la otra con al menos {aviso} de anticipación. Al terminar, EL ARRENDATARIO entregará el inmueble desocupado, limpio, con sus llaves y en las condiciones en que lo recibió.

DÉCIMA. JURISDICCIÓN. Para todo lo relativo a este contrato, las partes se someten a las leyes y tribunales de {ciudad}.

Leído el presente contrato y enteradas las partes de su contenido y alcance, lo firman en {ciudad} el día {fecha_firma}.`;
export function cfg(clave) { const r = get('SELECT valor FROM config WHERE clave=?', clave); return r ? r.valor : CONFIG_DEFAULT[clave] ?? ''; }
export function cfgTodo() { const o = { ...CONFIG_DEFAULT }; for (const r of all('SELECT clave, valor FROM config')) o[r.clave] = r.valor; return o; }
export function setCfg(clave, valor) { run('INSERT INTO config(clave,valor) VALUES(?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor', clave, String(valor ?? '')); }

// ---------- Folios ----------
export function siguienteFolio(tipo) {
  const k = 'folio_' + tipo, n = (Number(cfg(k)) || 0) + 1;
  setCfg(k, n);
  return String(n).padStart(5, '0');
}

// ---------- Respaldo automático (uno por día, guarda 30) ----------
export function respaldar(motivo = 'diario') {
  const nombre = `hotel_${motivo}_${hoy()}${motivo === 'diario' ? '' : '_' + Date.now()}.db`;
  const destino = path.join(RESPALDOS_DIR, nombre);
  if (fs.existsSync(destino)) return null;
  db.exec(`VACUUM INTO '${destino.replace(/'/g, "''")}'`);
  const viejos = fs.readdirSync(RESPALDOS_DIR).filter((f) => f.startsWith('hotel_diario_')).sort();
  while (viejos.length > 30) { try { fs.unlinkSync(path.join(RESPALDOS_DIR, viejos.shift())); } catch { /* sigue */ } }
  return nombre;
}

// ---------- Datos iniciales ----------
if (!get('SELECT id FROM usuarios LIMIT 1')) {
  tx(() => {
    run('INSERT INTO usuarios(nombre,usuario,pass_hash,rol) VALUES(?,?,?,?)', 'Administrador', 'admin', hashPass('admin123'), 'admin');
    const H = (numero, nombre, clase, piso, camas, rec, banos, cap, amen, d, s, m) =>
      run(`INSERT INTO habitaciones(numero,nombre,clase,piso,camas,recamaras,banos,capacidad,amenidades,precio_dia,precio_semana,precio_mes)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`, numero, nombre, clase, piso, JSON.stringify(camas), rec, banos, cap, JSON.stringify(amen), d, s, m);
    // Ejemplos: el hotel los cambia o borra en Configuración → Habitaciones
    H('101', 'Sencilla', 'habitacion', '1', { matrimonial: 1 }, 1, 1, 2, ['wifi', 'tv', 'ac', 'agua'], 550, 3200, 9500);
    H('102', 'Doble', 'habitacion', '1', { matrimonial: 2 }, 1, 1, 4, ['wifi', 'tv', 'ac', 'agua'], 750, 4300, 12500);
    H('103', 'Sencilla con ventilador', 'habitacion', '1', { individual: 1 }, 1, 1, 1, ['wifi', 'ventilador', 'agua'], 400, 2400, 7000);
    H('201', 'Suite', 'habitacion', '2', { king: 1 }, 1, 1, 2, ['wifi', 'tv', 'ac', 'agua', 'minibar', 'jacuzzi'], 1200, 7000, 19000);
    H('D1', 'Departamento 2 recámaras', 'departamento', '2', { queen: 1, individual: 2 }, 2, 1, 4, ['wifi', 'tv', 'ac', 'cocina', 'refri', 'micro', 'estacionamiento'], 1500, 8500, 16000);
  });
}
