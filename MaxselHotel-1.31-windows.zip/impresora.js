// Impresión directa a la impresora de tickets (ESC/POS): corte automático y pulso al cajón de dinero.
// Igual que Maxsel Parking: impresora instalada en Windows (USB) o impresora de red (IP).
import fs from 'node:fs';
import os from 'node:os';
import net from 'node:net';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { cfg } from './db.js';

const HERR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'herramientas');
const ESC = 0x1B, GS = 0x1D;
const CP437 = { 'á': 0xA0, 'é': 0x82, 'í': 0xA1, 'ó': 0xA2, 'ú': 0xA3, 'ñ': 0xA4, 'Ñ': 0xA5, 'ü': 0x81, 'Ü': 0x9A, '¿': 0xA8, '¡': 0xAD, 'É': 0x90, '°': 0xF8, '·': 0xFA };
const SIN_ACENTO = { 'Á': 'A', 'Í': 'I', 'Ó': 'O', 'Ú': 'U', '–': '-', '—': '-', '“': '"', '”': '"', '’': "'", '×': 'x', '✂': '-' };
function cp437(s) {
  const out = [];
  for (const ch of String(s)) {
    const c = ch.charCodeAt(0);
    if (c < 128) out.push(c); else if (CP437[ch] !== undefined) out.push(CP437[ch]); else if (SIN_ACENTO[ch]) out.push(SIN_ACENTO[ch].charCodeAt(0)); else out.push(0x3F);
  }
  return Buffer.from(out);
}

// ops: ['align','center'] ['bold',true] ['big',true] ['text','...'] ['feed',n] ['img', bytesPorRenglón, alto, base64] ['cut']
export function escpos(ops, { cajon = false } = {}) {
  const parts = [Buffer.from([ESC, 0x40, ESC, 0x74, 0x00])];
  if (cajon) parts.push(Buffer.from([ESC, 0x70, 0x00, 0x19, 0xFA]));
  for (const op of ops || []) {
    switch (op[0]) {
      case 'align': parts.push(Buffer.from([ESC, 0x61, { left: 0, center: 1, right: 2 }[op[1]] ?? 0])); break;
      case 'bold': parts.push(Buffer.from([ESC, 0x45, op[1] ? 1 : 0])); break;
      case 'big': parts.push(Buffer.from([GS, 0x21, op[1] ? 0x11 : 0x00])); break;
      case 'text': parts.push(cp437(String(op[1]).slice(0, 200)), Buffer.from([0x0A])); break;
      case 'feed': parts.push(Buffer.from([ESC, 0x64, Math.min(10, Number(op[1]) || 1)])); break;
      case 'cut': parts.push(Buffer.from([ESC, 0x64, 3, GS, 0x56, cfg('impresora_corte') === 'total' ? 0x41 : 0x42, 0x00])); break; // corte entre original y copia
      case 'img': { // imagen de 1 bit (firmas): GS v 0
        const w = Number(op[1]), h = Number(op[2]), data = Buffer.from(String(op[3]), 'base64');
        if (w > 0 && w <= 72 && h > 0 && h <= 400 && data.length === w * h) parts.push(Buffer.from([GS, 0x76, 0x30, 0, w & 255, w >> 8, h & 255, h >> 8]), data, Buffer.from([0x0A]));
        break;
      }
    }
  }
  // Al final siempre avanza hasta la cuchilla y corta el ticket
  parts.push(Buffer.from([ESC, 0x64, 3, GS, 0x56, cfg('impresora_corte') === 'total' ? 0x41 : 0x42, 0x00]));
  return Buffer.concat(parts);
}

// ---------- 1.26: impresoras Star Micronics en "Star Line Mode" (TSP650, TSP650II, TSP100, TSP143…) ----------
// Mismos renglones que escpos(), con los comandos de Star. Por red se mandan al puerto 9100.
export function starLine(ops, { cajon = false } = {}) {
  const corte = () => Buffer.from([ESC, 0x64, cfg('impresora_corte') === 'total' ? 2 : 3]); // ESC d n: 2 total / 3 parcial (avanza hasta la cuchilla)
  const parts = [Buffer.from([ESC, 0x40, ESC, 0x1D, 0x74, 0x01])]; // inicializar + página de códigos PC437 (acentos y ñ)
  if (cajon) parts.push(Buffer.from([0x07])); // BEL: abre el cajón 1
  for (const op of ops || []) {
    switch (op[0]) {
      case 'align': parts.push(Buffer.from([ESC, 0x1D, 0x61, { left: 0, center: 1, right: 2 }[op[1]] ?? 0])); break;
      case 'bold': parts.push(Buffer.from([ESC, op[1] ? 0x45 : 0x46])); break;
      case 'big': parts.push(Buffer.from([ESC, 0x69, op[1] ? 1 : 0, op[1] ? 1 : 0])); break; // doble alto y doble ancho
      case 'text': parts.push(cp437(String(op[1]).slice(0, 200)), Buffer.from([0x0A])); break;
      case 'feed': parts.push(Buffer.from([ESC, 0x61, Math.min(10, Number(op[1]) || 1)])); break;
      case 'cut': parts.push(Buffer.from([ESC, 0x61, 2]), corte()); break;
      case 'img': { // imagen de 1 bit en modo raster de Star
        const w = Number(op[1]), h = Number(op[2]), data = Buffer.from(String(op[3]), 'base64');
        if (!(w > 0 && w <= 72 && h > 0 && h <= 400 && data.length === w * h)) break;
        parts.push(Buffer.from([ESC, 0x2A, 0x72, 0x41]), Buffer.from([ESC, 0x2A, 0x72, 0x50, 0x30, 0x00])); // entrar a raster, largo continuo
        for (let y = 0; y < h; y++) parts.push(Buffer.from([0x62, w & 255, w >> 8]), data.subarray(y * w, (y + 1) * w));
        parts.push(Buffer.from([ESC, 0x2A, 0x72, 0x42])); // salir de raster
        break;
      }
    }
  }
  parts.push(Buffer.from([ESC, 0x61, 2]), corte());
  return Buffer.concat(parts);
}
const esStar = () => cfg('impresora_lenguaje') === 'star';
const armar = (ops, o) => (esStar() ? starLine(ops, o) : escpos(ops, o));

// Busca impresoras de red en el WiFi/red del hotel (las que tienen abierto el puerto 9100)
export async function buscarEnRed() {
  const redes = new Set();
  for (const l of Object.values(os.networkInterfaces())) for (const i of l || []) {
    if (i.family !== 'IPv4' || i.internal) continue;
    const p = i.address.split('.');
    if (p[0] === '10' || (p[0] === '192' && p[1] === '168') || (p[0] === '172' && Number(p[1]) >= 16 && Number(p[1]) <= 31)) redes.add(p.slice(0, 3).join('.'));
  }
  const probar = (ip) => new Promise((ok) => {
    const s = net.createConnection({ host: ip, port: 9100 }); let fin = false;
    const t = (r) => { if (fin) return; fin = true; s.destroy(); ok(r); };
    s.setTimeout(700); s.on('connect', () => t(ip)); s.on('timeout', () => t(null)); s.on('error', () => t(null));
  });
  const ips = []; for (const r of redes) for (let i = 1; i < 255; i++) ips.push(r + '.' + i);
  const hallados = [];
  for (let i = 0; i < ips.length; i += 64) (await Promise.all(ips.slice(i, i + 64).map(probar))).forEach((x) => x && hallados.push(x));
  return { redes: [...redes], impresoras: hallados };
}

function powershell(script, args, timeout = 20000) {
  return new Promise((ok, mal) => {
    execFile('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(HERR, script), ...args], { timeout, windowsHide: true }, (err, stdout, stderr) => {
      const out = String(stdout || '').trim();
      if (err) return mal(new Error(String(stderr || err.message).trim()));
      if (script === 'imprimir-raw.ps1' && out && !out.endsWith('OK')) return mal(new Error(out));
      ok(out);
    });
  });
}
function enviarIP(buf, ip, puerto) {
  return new Promise((ok, mal) => {
    const s = net.createConnection({ host: ip, port: Number(puerto) || 9100 });
    s.setTimeout(5000);
    s.on('connect', () => s.end(buf));
    s.on('close', (e) => (e ? null : ok()));
    s.on('timeout', () => { s.destroy(); mal(new Error('La impresora de red no respondió (' + ip + ')')); });
    s.on('error', (e) => mal(new Error('Impresora de red: ' + e.message)));
  });
}
export const hayImpresora = () => ['windows', 'ip'].includes(cfg('impresora_tipo'));
export async function enviar(buf) {
  const tipo = cfg('impresora_tipo');
  if (tipo === 'ip') {
    if (!cfg('impresora_ip')) throw new Error('Escriba la IP de la impresora en Configuración → Impresora y cajón');
    return enviarIP(buf, cfg('impresora_ip'), cfg('impresora_puerto'));
  }
  if (tipo === 'windows') {
    if (process.platform !== 'win32') throw new Error('La impresora de Windows solo funciona en Windows');
    if (!cfg('impresora_nombre')) throw new Error('Elija la impresora en Configuración → Impresora y cajón');
    const f = path.join(os.tmpdir(), 'maxsel_hotel_' + crypto.randomBytes(6).toString('hex') + '.bin');
    fs.writeFileSync(f, buf);
    try { await powershell('imprimir-raw.ps1', ['-Printer', cfg('impresora_nombre'), '-File', f]); } finally { fs.rm(f, () => {}); }
    return;
  }
  throw new Error('No hay impresora de tickets configurada');
}
export async function imprimirOps(ops, cajon) {
  if (!hayImpresora()) return { ok: false, sinImpresora: true };
  try { await enviar(armar(ops, { cajon: cajon && cfg('abrir_cajon') !== '0' })); return { ok: true }; } catch (e) { return { ok: false, error: e.message }; }
}
// Solo el pulso para abrir el cajón (sin imprimir nada)
export async function abrirCajon() {
  if (!hayImpresora() || cfg('abrir_cajon') === '0') return { ok: false, sinImpresora: true };
  try { await enviar(esStar() ? Buffer.from([ESC, 0x40, 0x07]) : Buffer.from([ESC, 0x40, ESC, 0x70, 0x00, 0x19, 0xFA])); return { ok: true }; } catch (e) { return { ok: false, error: e.message }; }
}
export async function listarImpresoras() {
  if (process.platform !== 'win32') return [];
  const out = await powershell('listar-impresoras.ps1', [], 15000);
  return out.split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
}
