// Maxsel Hotel 1.27 — desde internet (Tailscale Funnel) el Administrador y el Gerente también pueden hacer cambios, si el administrador lo permite
'use strict';
// En Monitoreo remoto (solo en la computadora del hotel): interruptor para permitir cambios desde internet
if (typeof nubePintar === 'function') {
  const _np = nubePintar;
  nubePintar = function (e) {
    const r = _np(e);
    const c = $('#nubeCard'); if (!c || !e || e.error || !(e.licencia || {}).activa || YO?.rol !== 'admin') return r;
    c.insertAdjacentHTML('beforeend', `<div style="border-top:1px solid var(--line);margin-top:14px;padding-top:12px">
      <label style="display:flex;flex-direction:row;font-weight:700;gap:10px;align-items:flex-start;cursor:pointer"><input type="checkbox" id="nubeEsc" style="margin-top:4px;flex:0 0 auto;width:18px;height:18px" ${e.escritura ? 'checked' : ''} onchange="nubeEscritura(this.checked)">
      <span>Permitir hacer cambios desde internet <span class="sub" style="font-weight:400;display:block">Administrador y Gerente podrán cobrar, registrar huéspedes, agregar o quitar productos, habitaciones, precios, etc. desde su celular o computadora fuera del hotel. Los usuarios de Monitoreo siguen solo viendo. Desde fuera no se abre el cajón ni se imprime en la impresora del hotel.</span></span></label>
      <div class="aviso" style="margin-top:8px" ${e.escritura ? '' : 'hidden'} id="nubeEscAv"><b>Use contraseñas fuertes</b> para Administrador y Gerente (mínimo 10 letras y números). Después de 5 intentos fallidos desde internet se bloquea 30 minutos. Todo queda en la bitácora.</div></div>`);
    return r;
  };
}
async function nubeEscritura(activar) {
  try { const r = await POST('/api/nube/escritura', { activar }); toast(r.escritura ? 'Listo: desde internet ya se pueden hacer cambios' : 'Desde internet otra vez solo se puede consultar'); const a = $('#nubeEscAv'); if (a) a.hidden = !r.escritura; }
  catch (e) { toast(e.message, true); const c = $('#nubeEsc'); if (c) c.checked = !activar; }
}
// Franja de arriba: si puede hacer cambios, se avisa en verde en vez de "modo consulta"
if (typeof avisoRemoto === 'function') {
  const _ar = avisoRemoto;
  avisoRemoto = function (...a) {
    const r = _ar(...a);
    const b = $('#avisoRemoto');
    if (b && YO?.escritura && !b.dataset.esc) { b.dataset.esc = 1; b.textContent = 'Conectado desde internet · puede hacer cambios (el cajón y la impresora del hotel no se usan desde aquí)'; b.style.background = 'var(--libre)'; b.style.color = '#fff'; }
    return r;
  };
}
