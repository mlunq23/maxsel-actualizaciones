// Maxsel Hotel 1.30 — ticket siempre a la vista al cobrar, no se cobra doble con varios clics y el administrador puede cancelar cobros
'use strict';
// ---------- Un solo envío por botón: mientras se guarda, los clics de más no hacen nada ----------
{
  const _api = api, enVuelo = new Set();
  api = async function (metodo, url, body) {
    if (metodo === 'GET' || /^\/api\/(imprimir|cajon|login|logout)/.test(url)) return _api(metodo, url, body);
    const k = metodo + ' ' + url + ' ' + JSON.stringify(body || {});
    if (enVuelo.has(k)) throw new Error('Espere, ya se está guardando…');
    enVuelo.add(k);
    try { return await _api(metodo, url, body); } finally { setTimeout(() => enVuelo.delete(k), 1500); }
  };
  // El botón principal de la ventana se apaga mientras trabaja
  document.addEventListener('click', (e) => {
    const b = e.target.closest?.('#modal .btn.pri'); if (!b || b.dataset.ocupado) return;
    b.dataset.ocupado = 1; b.style.opacity = '.55'; b.style.pointerEvents = 'none';
    setTimeout(() => { if (document.body.contains(b)) { delete b.dataset.ocupado; b.style.opacity = ''; b.style.pointerEvents = ''; } }, 2500);
  }, true);
}

// ---------- Imprimir: si se está fuera del hotel o la impresora falla, se imprime desde esta computadora o celular ----------
{
  const _id = imprimirDoc;
  imprimirDoc = async function (html, formato, titulo, ops) {
    const r = await _id(html, formato, titulo, YO?.remoto ? null : ops); // desde internet: siempre el botón "Imprimir" de este equipo
    if (YO?.remoto) { const s = $('#modal .mbody'); if (s && !$('#avRemImp')) s.insertAdjacentHTML('afterbegin', '<div class="aviso" id="avRemImp" style="margin-bottom:8px">Está fuera del hotel: el ticket se imprime o se guarda en PDF desde este equipo.</div>'); }
    return r;
  };
  const _mi = mandarImpresora;
  mandarImpresora = async function (...a) {
    const r = await _mi(...a);
    const el = $('#impEstado');
    if (el && /No se imprimió|sin impresora/i.test(el.textContent) && !$('#btnImpLocal')) el.insertAdjacentHTML('beforeend', ` <button class="btn sm pri" id="btnImpLocal" onclick="window.print()">Imprimir desde esta computadora</button>`);
    return r;
  };
}

// ---------- Cuenta del huésped: el administrador puede cancelar un cobro hecho por error ----------
{
  const MET2 = typeof MET === 'object' ? MET : {};
  const _ve = verEstancia;
  verEstancia = async function (id, ...a) {
    const r = await _ve(id, ...a);
    try {
      const lbl = [...document.querySelectorAll('#modal .lbl')].find((x) => x.textContent.trim() === 'Pagos');
      const tabla = lbl?.parentElement?.querySelector('table'); if (!tabla) return r;
      const e = await GET('/api/estancias/' + id), admin = YO?.rol === 'admin';
      tabla.querySelector('tbody').innerHTML = e.pagos.map((p) => {
        const anul = p.cancelado, rev = p.cancela_id;
        return `<tr style="${anul ? 'text-decoration:line-through;opacity:.6' : ''}"><td>${fdt(p.fecha)}</td><td>${MET2[p.metodo] || esc(p.metodo)}</td><td class="sub">${esc(p.nota || '')}${anul ? ' · <b style="color:var(--ocup)">CANCELADO</b>' : ''}</td><td class="n" style="${rev ? 'color:var(--ocup)' : ''}">${money(p.monto)}</td>
          <td>${admin && !anul && !rev && p.monto > 0 && !p.venta_id ? `<button class="btn sm bad" onclick="cancelarCobro(${p.id},${id},${p.monto},'${fdt(p.fecha)}')">Cancelar</button>` : ''}</td></tr>`;
      }).join('');
    } catch { /* nada */ }
    return r;
  };
}
function cancelarCobro(pid, eid, monto, fecha) {
  modal('Cancelar cobro', `<p>Va a cancelar el cobro de <b>${money(monto)}</b> del ${esc(fecha)}.</p>
    <p class="sub">No se borra: queda tachado en la cuenta y en la caja sale un renglón en negativo con el motivo (en su turno abierto). El saldo del huésped se recalcula solo.</p>
    <label class="l">Motivo<input id="ccM" placeholder="Ej. se cobró dos veces por error"></label>`,
  `<button class="btn" onclick="verEstancia(${eid})">Volver</button><button class="btn bad" onclick="cancelarCobroOk(${pid},${eid})">Cancelar cobro</button>`);
}
async function cancelarCobroOk(pid, eid) {
  const m = val('ccM'); if (!m) return toast('Escriba el motivo', true);
  await hacer(() => POST(`/api/pagos/${pid}/cancelar`, { motivo: m }), 'Cobro cancelado');
  verEstancia(eid); if (typeof vHab === 'function' && vista === 'hab') vHab();
}
// ---------- Registrar / cobrar: mientras uno está en proceso, los clics de más se ignoran ----------
for (const fn of ['rOk', 'extOk', 'pagoOk', 'salidaOk', 'visOk', 'depOk', 'cargoOk']) {
  const orig = window[fn]; if (typeof orig !== 'function') continue;
  let ocupado = false;
  window[fn] = async function (...a) {
    if (ocupado) { toast('Espere, ya se está cobrando…'); return; }
    ocupado = true;
    try { return await orig.apply(this, a); } finally { setTimeout(() => { ocupado = false; }, 800); }
  };
}
