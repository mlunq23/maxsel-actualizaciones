// Maxsel Hotel 1.18 — igual que Maxsel Tech / Abarrotes:
//  1) "¿Olvidó su contraseña?" en la pantalla de entrada
//  2) Reiniciar ventas con botón oculto (tocar 7 veces la versión al pie de Configuración) y contraseña de Maxsel
//  3) Monitoreo desde el teléfono solo por Tailscale Funnel, fácil de activar

// ======================================================================
// 1) Recuperar contraseña
// ======================================================================
{
  const _pl = pantallaLogin;
  pantallaLogin = function () {
    _pl();
    const f = $('#flog'); if (!f) return;
    $('#lerr').insertAdjacentHTML('beforebegin', `<button type="button" class="btn" style="justify-content:center;border:0;background:none;color:var(--accent);font-weight:600" onclick="recuperarVer()">¿Olvidó su contraseña?</button>`);
  };
}
function recuperarVer() {
  modal('Recuperar contraseña', `<p class="sub" style="margin-top:0">Para poner una contraseña nueva se necesita la autorización de un <b>administrador</b> (su contraseña) o la <b>clave de soporte de Maxsel</b>.</p>
    <div class="f"><label class="l">Usuario que olvidó su contraseña<input id="rcU" autocomplete="off" autocapitalize="off" value="${esc(val('lu'))}"></label>
    <label class="l">Contraseña de un administrador o clave de soporte Maxsel<input id="rcA" type="password" autocomplete="off"></label>
    <label class="l">Contraseña nueva (mínimo 6)<input id="rcN" type="password" autocomplete="new-password"></label>
    <label class="l">Repita la contraseña nueva<input id="rcR" type="password" autocomplete="new-password"></label></div>
    <div class="sub">¿No tiene ninguna? Llame a soporte Maxsel por WhatsApp: <b>664 337 5433</b></div><div id="rcE"></div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" id="rcOk" onclick="recuperarOk()">Cambiar contraseña</button>`);
  setTimeout(() => (val('rcU') ? $('#rcA') : $('#rcU'))?.focus(), 50);
}
async function recuperarOk() {
  const err = (m) => { $('#rcE').innerHTML = `<div class="aviso bad">${esc(m)}</div>`; };
  const usuario = val('rcU').toLowerCase(), autoriza = $('#rcA').value, nueva = $('#rcN').value;
  if (!usuario) return err('Escriba el usuario.');
  if (!autoriza) return err('Falta la contraseña del administrador o la clave de soporte.');
  if (nueva.length < 6) return err('La contraseña nueva debe tener al menos 6 caracteres.');
  if (nueva !== $('#rcR').value) return err('Las contraseñas nuevas no coinciden.');
  const b = $('#rcOk'); b.disabled = true;
  try {
    const r = await POST('/api/recuperar-password', { usuario, autoriza, nueva });
    cerrar(); toast(`Listo: ${r.nombre || usuario} ya puede entrar con su contraseña nueva`);
    if ($('#lu')) { $('#lu').value = r.usuario || usuario; $('#lp').value = ''; $('#lp').focus(); }
  } catch (e) { b.disabled = false; err(e.message); }
}

// ======================================================================
// 2) Pie de Configuración con la versión; 7 toques seguidos abren "Reiniciar el sistema" (solo Maxsel)
// ======================================================================
{
  const _vc = vCfg;
  vCfg = async function (...a) {
    const r = await _vc.apply(this, a);
    if (vista === 'cfg' && $('#main') && !$('#cfgPie')) {
      $('#main').insertAdjacentHTML('beforeend', `<div id="cfgPie" style="text-align:center;color:var(--muted);font-size:12px;padding:28px 0 8px;user-select:none;cursor:default">Maxsel Hotel · versión ${esc(YO?.version || '')} · Maxsel Sistemas de Punto de Venta</div>`);
      let n = 0, t0 = 0;
      $('#cfgPie').onclick = () => {
        const ya = Date.now(); if (ya - t0 > 4000) { n = 0; t0 = ya; }
        if (++n >= 7) { n = 0; t0 = 0; reiniciarVer(); }
      };
    }
    return r;
  };
}
reiniciarVer = async function () {
  let c; try { c = await GET('/api/reiniciar'); } catch (e) { return toast(e.message, true); }
  modal('🔒 Reiniciar el sistema · solo Maxsel', `<div class="aviso bad" style="margin-top:0"><b>Esto no se puede deshacer</b> (solo restaurando el respaldo que se guarda antes de borrar).</div>
    <p style="margin:0 0 6px"><b>Se borran:</b> rentas y huéspedes registrados (${c.rentas}), ventas de la tienda (${c.ventas}), pagos, cortes y turnos de caja (${c.cortes}), gastos (${c.gastos}),
      depósitos, contratos, reservaciones (${c.reservaciones} por llegar), mantenimiento y limpieza, asistencia, nómina, inventarios, cuentas por pagar e historial. Los folios vuelven a empezar en 1 y todas las habitaciones quedan libres.</p>
    <p style="margin:0 0 10px"><b>NO se borran:</b> habitaciones y precios, productos y existencias, usuarios y contraseñas, empleados, proveedores, la base de huéspedes y no deseados, logo, contrato, licencia ni la configuración.</p>
    ${c.hospedados ? `<label style="display:flex;gap:8px;align-items:flex-start;margin-bottom:10px;cursor:pointer"><input type="checkbox" id="reiH" style="margin-top:3px"> <span>También borrar los <b>${c.hospedados} huésped(es) hospedado(s) ahorita</b> (sus habitaciones quedan libres)</span></label>` : ''}
    <label class="l">Contraseña de Maxsel<input id="reiC" type="password" autocomplete="off"></label>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn bad" id="reiOk" onclick="confirmar(this, reiniciarOk)">Reiniciar ventas</button>`);
  setTimeout(() => $('#reiC')?.focus(), 50);
};
reiniciarOk = async function () {
  const clave = $('#reiC')?.value || '';
  if (!clave) return toast('Escriba la contraseña de Maxsel', true);
  const b = $('#reiOk'); b.disabled = true; b.textContent = 'Borrando…';
  try {
    const r = await POST('/api/reiniciar', { clave, con_hospedados: !!$('#reiH')?.checked });
    modal('Ventas reiniciadas', `<p>El hotel quedó en ceros: habitaciones libres y folios en 1.</p><p>Lo que había antes quedó respaldado en <span class="mono">${esc(r.respaldo || '')}</span> (carpeta de respaldos).</p>`,
      '<button class="btn pri" onclick="location.reload()">Listo</button>');
  } catch (e) { b.disabled = false; delete b.dataset.armado; b.textContent = 'Reiniciar ventas'; toast(e.message, true); }
};

// ======================================================================
// 3) Monitoreo remoto: WiFi del hotel + teléfono desde cualquier lugar (Tailscale Funnel)
// ======================================================================
const TS_DESCARGA = 'https://tailscale.com/download/windows';
cRemoto = async function () {
  const ips = CFG._ips || [], loc = ips.filter((i) => !i.tailscale), p = CFG._puerto || 3050;
  const lan = `<div class="card"><h2>Desde el celular, en el WiFi del hotel</h2>${loc.map((i) => `<div class="codigo" style="font-size:18px">http://${esc(i.ip)}:${p}</div>`).join('') || '<div class="empty">Sin red local.</div>'}
    <p class="sub">Entre con un usuario de tipo <b>Monitoreo</b> (solo ver), Gerente o Administrador.</p></div>`;
  if (YO?.remoto) { $('#cfgc').innerHTML = `<div class="stack"><div class="aviso">Está entrando desde el teléfono (fuera del hotel): aquí solo se puede consultar.</div></div>`; return; }
  if (!puede('config')) { $('#cfgc').innerHTML = `<div class="stack">${lan}<div class="aviso">El acceso desde fuera del hotel lo activa el administrador.</div></div>`; return; }
  $('#cfgc').innerHTML = `<div class="stack">${lan}<div class="card" id="nubeCard"><h2>Desde el teléfono, en cualquier lugar</h2><div class="empty">Revisando Tailscale…</div></div></div>`;
  let e; try { e = await GET('/api/nube'); } catch (er) { e = { error: er.message }; }
  if (cfgTab !== 'remoto' || !$('#nubeCard')) return;
  nubePintar(e);
};
function nubePintar(e) {
  const c = $('#nubeCard'); if (!c) return;
  const paso = (n, t) => `<div class="row" style="gap:10px;align-items:flex-start;margin:8px 0"><b style="flex:0 0 26px;height:26px;border-radius:50%;background:var(--accent);color:#fff;display:grid;place-items:center">${n}</b><div style="flex:1;line-height:1.5">${t}</div></div>`;
  let h = '<h2>Desde el teléfono, en cualquier lugar</h2><p class="sub" style="margin-top:0">El dueño ve el hotel desde su celular con internet, sin instalar nada en el teléfono. Desde fuera <b>solo se puede consultar</b>: no se cobra, no se borra y no se cambia la configuración.</p>';
  const L = e.licencia || {}, fV = (f) => f ? f.split('-').reverse().join('/') : '';
  if (!e.error && !L.activa) {
    h += `<div class="aviso bad"><b>${L.vence ? 'La póliza de monitoreo venció el ' + fV(L.vence) + '.' : 'No incluido en esta licencia.'}</b> El monitoreo desde el teléfono es parte de la <b>póliza anual de mantenimiento</b>.</div>
      <p style="margin:8px 0">Para activarlo o renovarlo comuníquese con Maxsel por WhatsApp: <b>664 337 5433</b>. Le enviaremos una licencia nueva que se pega en Configuración → Respaldos y licencia → Activar licencia nueva.</p>`;
    c.innerHTML = h; return;
  }
  if (L.activa && L.vence) h += `<div class="sub" style="margin:-4px 0 10px">Póliza de monitoreo vigente hasta el <b>${fV(L.vence)}</b>${L.dias != null && L.dias <= 30 ? ` · <span style="color:var(--ocup);font-weight:700">faltan ${L.dias} días, renueve con Maxsel</span>` : ''}.</div>`;
  if (e.error) h += `<div class="aviso bad">${esc(e.error)}</div><button class="btn" onclick="cRemoto()">Volver a revisar</button>`;
  else if (!e.instalado) h += paso(1, `Instale <b>Tailscale</b> en esta computadora: <a href="${TS_DESCARGA}" target="_blank" rel="noopener">tailscale.com/download/windows</a>`)
    + paso(2, 'Ábralo e inicie sesión con una cuenta de Google o Microsoft del hotel.') + paso(3, 'Regrese aquí y toque <b>Volver a revisar</b>.')
    + '<button class="btn pri" onclick="cRemoto()">Volver a revisar</button>';
  else if (!e.conectado) h += '<div class="aviso">Tailscale está instalado pero no ha iniciado sesión.</div>'
    + paso(1, 'Abra Tailscale (icono junto al reloj de Windows) y toque <b>Log in</b>. Entre con la cuenta del hotel.') + paso(2, 'Regrese aquí y toque <b>Volver a revisar</b>.')
    + '<button class="btn pri" onclick="cRemoto()">Volver a revisar</button>';
  else if (e.habilitar) h += '<div class="aviso">Falta un paso único: permitir Funnel en la cuenta de Tailscale.</div>'
    + paso(1, `Abra este enlace e inicie sesión con la cuenta del hotel: <div class="codigo" style="font-size:13px;word-break:break-all">${esc(e.habilitar)}</div><button class="btn sm" onclick="copiar('${esc(e.habilitar)}')">Copiar enlace</button> <a class="btn sm" href="${esc(e.habilitar)}" target="_blank" rel="noopener">Abrir</a>`)
    + paso(2, 'Toque <b>Enable</b> (habilitar) y regrese aquí.') + '<button class="btn pri" onclick="nubeFunnel(true)">Ya lo habilité, activar</button>';
  else if (!e.funnel.activo) h += `<div class="aviso ok">Tailscale está conectado en esta computadora (${esc(e.nombre)}).</div>`
    + '<button class="btn pri" id="nubeBtn" onclick="nubeFunnel(true)">Activar acceso desde el teléfono</button>';
  else h += `<div class="aviso ok"><b>Activo.</b> Abra esta dirección en el navegador del celular y agréguela a la pantalla de inicio:</div>
      <div class="row" style="gap:18px;align-items:center;flex-wrap:wrap"><div style="background:#fff;padding:8px;border-radius:12px">${qrSVG(e.funnel.url, 5)}</div>
      <div style="flex:1;min-width:220px"><div class="codigo" style="font-size:16px;word-break:break-all" id="codeq">${esc(e.funnel.url)}</div>
      <div class="row" style="gap:8px;margin-top:8px;flex-wrap:wrap"><button class="btn" onclick="copiar('${esc(e.funnel.url)}')">Copiar dirección</button><button class="btn bad" id="nubeBtn" onclick="confirmar(this, () => nubeFunnel(false))">Desactivar</button></div>
      <p class="sub">Desde fuera solo entran usuarios <b>Administrador</b>, <b>Gerente</b> o <b>Monitoreo</b>. Use contraseñas fuertes.</p></div></div>`;
  c.innerHTML = h;
}
async function nubeFunnel(activar) {
  const b = $('#nubeBtn'); if (b) { b.disabled = true; b.textContent = activar ? 'Activando… (puede tardar 20 s)' : 'Desactivando…'; }
  try { const e = await POST('/api/nube/funnel', { activar }); if (e.habilitar) { const s = await GET('/api/nube'); s.habilitar = e.habilitar; nubePintar(s); } else { nubePintar(e); toast(activar ? 'Acceso desde el teléfono activado' : 'Acceso desde el teléfono desactivado'); } }
  catch (er) { toast(er.message, true); cRemoto(); }
}

// Entrando desde el teléfono (Funnel): aviso de solo consulta
function avisoRemoto() { if (YO?.remoto && !['limpieza', 'mantenimiento'].includes(YO?.rol) && !$('#avisoRemoto')) document.body.insertAdjacentHTML('afterbegin', '<div id="avisoRemoto" style="background:#cd6628;color:#fff;text-align:center;font-size:13px;padding:6px 10px">Modo consulta desde el teléfono · para cobrar o hacer cambios use la computadora del hotel</div>'); }
{
  const _ini = inicio;
  inicio = async function (...a) { const r = await _ini.apply(this, a); avisoRemoto(); return r; };
  let k = 0; const t = setInterval(() => { if (YO || ++k > 40) { clearInterval(t); avisoRemoto(); } }, 500);
}

// 1.19: en Respaldos y licencia se ve hasta cuándo está la póliza de monitoreo remoto
{
  const _cr = cResp;
  cResp = async function (...a) {
    const r = await _cr.apply(this, a);
    if (typeof cfgTab !== 'undefined' && cfgTab !== 'resp') return r;
    try {
      const l = await GET('/api/licencia/estado'), kv = $('#cfgc .kv'); if (!kv || $('#kvNube') || !l.nube) return r;
      const n = l.nube, f = n.vence ? n.vence.split('-').reverse().join('/') : '';
      const M = l.modulos || {}, mtxt = (k, n) => `<span style="font-weight:600;color:${M[k] !== false ? 'var(--libre)' : 'var(--ocup)'}">${M[k] !== false ? 'Incluido' : 'No incluido'}</span>`;
      kv.insertAdjacentHTML('beforeend', `<span>Módulo de Gastos</span>${mtxt('gastos')}<span>Módulo de Asistencia (checador)</span>${mtxt('asistencia')}`);
      kv.insertAdjacentHTML('beforeend', `<span id="kvNube">Monitoreo remoto (póliza)</span><span style="font-weight:600;color:${n.activa ? 'var(--libre)' : 'var(--ocup)'}">${n.activa ? 'Vigente hasta ' + f : n.vence ? 'Venció el ' + f : 'No incluido'}</span>`);
    } catch { /* nada */ }
    return r;
  };
}
