// Maxsel Hotel 1.31 — Tickets completos: fecha y hora de expedición, quién atendió, turno, forma de pago,
// historial de pagos en el estado de cuenta, razón social / RFC del hotel y leyenda fiscal
'use strict';
const dosD = (n) => String(n).padStart(2, '0');
// 09/11/2026 10:50 p.m.  (con año, para que nunca falte la fecha)
function fechaTk(s) {
  const d = s ? (typeof s === 'string' ? aF(s) : s) : new Date(); if (!d || isNaN(d)) return '—';
  const h = d.getHours(), h12 = h % 12 || 12;
  return `${dosD(d.getDate())}/${dosD(d.getMonth() + 1)}/${d.getFullYear()} ${h12}:${dosD(d.getMinutes())} ${h < 12 ? 'a.m.' : 'p.m.'}`;
}
const soloFecha = (s) => fechaTk(s).split(' ')[0];
const soloHora = (s) => fechaTk(s).split(' ').slice(1).join(' ');

// ---------- Encabezado: nombre, razón social, RFC, dirección y teléfono ----------
const datosFiscales = () => [CFG.hotel_razon_social, CFG.hotel_rfc ? 'RFC: ' + String(CFG.hotel_rfc).toUpperCase() : ''].filter(Boolean);
encabezado = function () {
  return [String(CFG.hotel_nombre || '').toUpperCase(), ...datosFiscales(), CFG.hotel_direccion, CFG.hotel_telefono ? 'Tel. ' + CFG.hotel_telefono : '', '-'.repeat(W())].filter(Boolean);
};
encOps = function () {
  const n = String(CFG.hotel_nombre || ''), ops = [['align', 'center'], ['bold', true]];
  if (n.length <= W() / 2) ops.push(['big', true], ['text', n], ['big', false]); else wrapT(n).forEach((l) => ops.push(['text', l]));
  ops.push(['bold', false]);
  [...datosFiscales(), CFG.hotel_direccion, CFG.hotel_telefono ? 'Tel. ' + CFG.hotel_telefono : ''].filter(Boolean).forEach((x) => wrapT(x).forEach((l) => ops.push(['text', l])));
  ops.push(['align', 'left'], ['text', '-'.repeat(W())]);
  return ops;
};
// ---------- Todos los tickets: fecha y hora de expedición, quién atendió, turno y leyenda al final ----------
let CORTE_T = null;
if (typeof imprimirCorte2 === 'function') { const _c2 = imprimirCorte2; imprimirCorte2 = function (r, ...a) { CORTE_T = r?.turno || null; try { return _c2(r, ...a); } finally { CORTE_T = null; } }; }
function completarTicket(L) {
  if (!Array.isArray(L) || L._completo) return L;
  const sep = L.findIndex((l) => /^-{8,}$/.test(l)); if (sep < 0) return L;
  const w = W(), titulo = String(L[sep + 1] || ''), corte = /^CORTE/i.test(titulo);
  const quien = String(YO?.nombre || '').slice(0, w - 9), turno = TURNO?.turno?.id;
  const bloque = [lin('Fecha', soloFecha()), lin('Hora', soloHora()), ...(quien ? [lin(corte ? 'Imprimió' : 'Atendió', quien)] : []), ...(turno && !corte ? [lin('Turno de caja', '#' + turno)] : [])];
  const out = [...L];
  if (corte && CORTE_T) for (let i = 0; i < out.length; i++) { const m = /^(Abrió|Cerró)\s/.exec(out[i]); if (m) out[i] = lin(m[1], fechaTk(m[1] === 'Abrió' ? CORTE_T.apertura : CORTE_T.cierre)); }
  // Si debajo del título ya viene la fecha corta del movimiento, se cambia por la fecha completa con año
  if (/^\d{1,2}[-\s]\w{3,5}\.?[-\s]+\d{1,2}:\d{2}/.test(String(out[sep + 2] || ''))) out.splice(sep + 2, 1);
  out.splice(sep + 2, 0, ...bloque);
  // Al final: leyenda fiscal (si la hay) antes del pie del ticket
  const ley = corte ? '' : (CFG.ticket_leyenda ?? 'Este ticket no es un comprobante fiscal.');
  if (ley) {
    let k = out.length; while (k > 0 && (out[k - 1] === '' || out[k - 1] === (CFG.ticket_pie || ''))) k--;
    out.splice(k, 0, '', ...wrapT(ley));
  }
  out._completo = true;
  return out;
}
{
  const _imp = imprimir;
  imprimir = function (lineas, ...a) {
    try { lineas = completarTicket(lineas); } catch { /* si algo falla, se imprime como antes */ }
    return _imp(lineas, ...a);
  };
}

// ---------- Ticket de la cuenta del huésped (entrada, abono, salida, estado de cuenta) ----------
imprimirEstancia = async function (id, titulo, pago) {
  const e = await GET('/api/estancias/' + id), w = W(), raya = '-'.repeat(w);
  const largo = e.modalidad === 'semana' || e.modalidad === 'mes';
  const dp = e.dia_pago !== null && e.dia_pago !== undefined && typeof DIAS_PAGO !== 'undefined' ? DIAS_PAGO[Number(e.dia_pago)] : '';
  const pagos = (e.pagos || []).filter((p) => !p.venta_id);
  const L = [...encabezado(), titulo, raya,
    lin('Folio', e.folio), lin(e.habitacion.clase === 'departamento' ? 'Departamento' : 'Habitación', e.habitacion.numero), ...wrapT('Huésped: ' + e.huesped),
    lin('Tipo de renta', MOD[e.modalidad] || e.modalidad), lin('Personas', e.personas || 1),
    lin('Entrada', fechaTk(e.entrada)), lin(e.salida_real ? 'Salió' : (largo ? 'Pagado hasta' : 'Check out'), fechaTk(e.salida_real || e.salida_prevista)),
    ...(largo && e.modalidad === 'semana' && dp ? [lin('Día de pago', 'cada ' + dp.toLowerCase())] : []),
    raya, lin(unidad(e.modalidad, e.cantidad) + ' x ' + money(e.precio), money(e.total_hospedaje)),
    ...e.cargos.map((c) => lin(c.cantidad + ' ' + c.descripcion, money(c.importe))), raya,
    lin('TOTAL', money(e.total_hospedaje + e.consumo)), lin('PAGADO', money(e.pagado)), e.saldo < -0.009 ? lin('SALDO A FAVOR', money(-e.saldo)) : lin('SALDO', money(e.saldo))];
  // Forma de pago de este cobro (los pagos registrados en el último movimiento)
  if (pago && pagos.length) {
    const ult = pagos[pagos.length - 1].fecha, ahora = pagos.filter((p) => p.fecha === ult && !p.cancelado && !p.cancela_id);
    if (ahora.length) {
      L.push(raya, 'ESTE PAGO');
      for (const p of ahora) L.push(lin(MET[p.metodo] || p.metodo, p.usd ? 'US$' + Number(p.usd).toFixed(2) : money(p.monto)));
      if (ahora.length > 1) L.push(lin('Total de este pago', money(ahora.reduce((s, p) => s + Number(p.monto || 0), 0))));
    }
  }
  L.push(...lineasPago(pago));
  // Estado de cuenta y salida: todos los pagos con su fecha
  if (!pago && pagos.length && /ESTADO|SALIDA/i.test(titulo)) {
    L.push(raya, 'PAGOS RECIBIDOS');
    const ver = pagos.slice(-15);
    if (pagos.length > ver.length) L.push(`(${pagos.length - ver.length} pagos anteriores)`);
    for (const p of ver) L.push(lin(soloFecha(p.fecha) + ' ' + (p.cancela_id ? 'Cancelación' : (MET[p.metodo] || p.metodo)) + (p.cancelado ? ' (canc.)' : ''), money(p.monto)));
  }
  if (e.deposito) L.push(raya, lin('Depósito en garantía', money(e.deposito)), ...(e.deposito_retenido ? [lin('Retenido', money(e.deposito_retenido))] : []), ...(e.deposito_devuelto ? [lin('Devuelto', money(e.deposito_devuelto))] : []), lin('Depósito en resguardo', money(e.deposito_saldo)));
  if (e.activa) {
    L.push(raya);
    if (e.saldo > 0.009) L.push(lin('SALDO PENDIENTE', money(e.saldo)));
    else if (largo) L.pop();
    else if (!largo) L.push(lin('Hora de salida', fechaTk(e.salida_prevista)));
  }
  L.push('', CFG.ticket_pie || '');
  imprimir(L);
};

// ---------- Configuración → Datos del hotel: razón social, RFC y leyenda ----------
if (typeof cHotel === 'function') {
  const _ch = cHotel;
  cHotel = function (...a) {
    const r = _ch(...a);
    const lb = $('#gP')?.closest('label');
    if (lb && !$('#gRs')) lb.insertAdjacentHTML('beforebegin', `<label class="l">Razón social (opcional)<input id="gRs" value="${esc(CFG.hotel_razon_social || '')}" placeholder="Ej. Juan Pérez López"></label>
      <label class="l">RFC (opcional)<input id="gRfc" value="${esc(CFG.hotel_rfc || '')}" maxlength="13" style="text-transform:uppercase"></label>
      <label class="l">Leyenda al final del ticket<input id="gLey" value="${esc(CFG.ticket_leyenda ?? 'Este ticket no es un comprobante fiscal.')}" placeholder="Déjela vacía para no imprimirla"></label>`);
    return r;
  };
  const _api = api;
  api = function (metodo, url, body) {
    if (metodo === 'PUT' && url === '/api/config' && body && body.ticket_pie !== undefined && $('#gRs')) body = { ...body, hotel_razon_social: val('gRs'), hotel_rfc: val('gRfc').toUpperCase(), ticket_leyenda: val('gLey') };
    return _api(metodo, url, body);
  };
}
