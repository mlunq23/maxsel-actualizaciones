// Maxsel Hotel 1.25 — Monitoreo remoto: "Probar que funciona" paso por paso, "Reparar" con un botón e iniciar sesión en Tailscale desde el sistema
'use strict';
if (typeof nubePintar === 'function') {
  const _np = nubePintar;
  nubePintar = function (e) {
    const r = _np(e);
    const c = $('#nubeCard'); if (!c || !e || e.error || !(e.licencia || {}).activa) return r;
    // Sin sesión: en vez de solo instrucciones, un botón que abre la página para entrar
    if (e.instalado && !e.conectado) c.insertAdjacentHTML('beforeend', `<div style="margin-top:8px"><button class="btn pri" id="tsSesBtn" onclick="tsSesion()">Iniciar sesión en Tailscale</button></div><div id="tsSes"></div>`);
    c.insertAdjacentHTML('beforeend', `<div style="border-top:1px solid var(--line);margin-top:14px;padding-top:12px">
      <div class="row" style="justify-content:space-between;gap:10px;flex-wrap:wrap"><b>¿Ya funciona desde internet?</b><button class="btn" id="nubePrBtn" onclick="nubeProbar()">Probar que funciona</button></div>
      <div id="nubePr" class="sub" style="margin-top:6px">Revisa todo paso por paso, como si entrara un celular desde fuera del hotel, y le dice qué falta.</div></div>`);
    // Al entrar a esta pantalla se prueba solo, una vez
    if (e.conectado && !nubePintar.probado) { nubePintar.probado = true; setTimeout(() => { if ($('#nubePrBtn')) nubeProbar(); }, 300); }
    return r;
  };
}
const pasoTxt = (p) => `<div class="row" style="gap:10px;align-items:flex-start;margin:6px 0"><b style="flex:0 0 24px;height:24px;border-radius:50%;display:grid;place-items:center;color:#fff;background:${p.ok ? 'var(--libre)' : 'var(--ocup)'}">${p.ok ? '✓' : '!'}</b>
  <div style="flex:1;min-width:0"><b>${esc(p.titulo)}</b><div class="sub">${esc(p.detalle)}</div></div></div>`;
function nubePasos(pasos) {
  const box = $('#nubePr'); if (!box) return;
  const malo = pasos.find((p) => !p.ok);
  let h = pasos.map(pasoTxt).join('');
  if (!malo) h += `<div class="aviso ok" style="margin-top:8px"><b>Todo funciona.</b> Ya se puede entrar desde cualquier celular con internet.</div>`;
  else if (['funnel', 'entrada', 'publico'].includes(malo.clave)) h += `<button class="btn pri" id="nubeRepBtn" onclick="nubeReparar()">Reparar automáticamente</button>`;
  else if (malo.clave === 'sesion') h += `<button class="btn pri" onclick="tsSesion()">Iniciar sesión en Tailscale</button><div id="tsSes"></div>`;
  else if (malo.clave === 'dns') { h += `<div class="sub">Se vuelve a probar solo en 1 minuto…</div>`; clearTimeout(nubePasos.t); nubePasos.t = setTimeout(() => { if (cfgTab === 'remoto' && $('#nubePr')) nubeProbar(); }, 60000); }
  box.innerHTML = h;
}
async function nubeProbar() {
  const b = $('#nubePrBtn'); if (b) { b.disabled = true; b.textContent = 'Probando… (hasta 30 s)'; }
  $('#nubePr').innerHTML = '<div class="empty">Revisando paso por paso…</div>';
  try { const r = await GET('/api/nube/probar'); nubePasos(r.pasos); } catch (e) { $('#nubePr').innerHTML = `<div class="aviso bad">${esc(e.message)}</div>`; }
  finally { if (b) { b.disabled = false; b.textContent = 'Probar otra vez'; } }
}
async function nubeReparar() {
  const b = $('#nubeRepBtn'); if (b) { b.disabled = true; b.textContent = 'Reparando… (hasta 40 s)'; }
  try {
    const r = await POST('/api/nube/reparar', {});
    if (r.habilitar) { const s = await GET('/api/nube'); s.habilitar = r.habilitar; nubePintar(s); toast('Falta permitir Funnel en la cuenta de Tailscale (un solo paso)'); return; }
    nubePasos(r.pasos); toast(r.pasos.every((p) => p.ok) ? 'Listo: ya funciona desde internet' : 'Se reparó lo que se pudo; revise los pasos');
    const s = await GET('/api/nube'); const keep = $('#nubePr')?.innerHTML; nubePintar(s); if (keep && $('#nubePr')) $('#nubePr').innerHTML = keep;
  } catch (e) { toast(e.message, true); if (b) { b.disabled = false; b.textContent = 'Reparar automáticamente'; } }
}
async function tsSesion() {
  const b = $('#tsSesBtn'); if (b) { b.disabled = true; b.textContent = 'Abriendo Tailscale…'; }
  try {
    const r = await POST('/api/nube/sesion', {});
    const box = $('#tsSes');
    if (r.enlace) {
      if (box) box.innerHTML = `<div class="aviso" style="margin-top:8px">Abra este enlace, entre con la cuenta de Google o Microsoft del hotel y regrese aquí:</div>
        <div class="codigo" style="font-size:13px;word-break:break-all">${esc(r.enlace)}</div>
        <div class="row" style="gap:8px;margin-top:6px;flex-wrap:wrap"><a class="btn pri" href="${esc(r.enlace)}" target="_blank" rel="noopener" style="text-decoration:none">Abrir para iniciar sesión</a><button class="btn" onclick="copiar('${esc(r.enlace)}')">Copiar enlace</button><button class="btn" onclick="cRemoto()">Ya inicié sesión</button></div>`;
    } else if (r.listo) { toast('Tailscale ya tiene sesión'); cRemoto(); }
    else if (box) box.innerHTML = `<div class="aviso bad" style="margin-top:8px">${esc(r.error || 'No se pudo abrir Tailscale')}. Ábralo desde el icono junto al reloj y toque Log in.</div>`;
  } catch (e) { toast(e.message, true); }
  finally { if (b) { b.disabled = false; b.textContent = 'Iniciar sesión en Tailscale'; } }
}
// En "Apps del personal (QR)", si no hay dirección de internet, llevar directo a probar y reparar
if (typeof cMantPortal === 'function') {
  const _cm = cMantPortal;
  cMantPortal = async function (...a) {
    const r = await _cm(...a);
    const av = [...document.querySelectorAll('#cfgc .aviso')].find((x) => /monitoreo desde el teléfono/.test(x.textContent));
    if (av && !av.querySelector('button')) av.insertAdjacentHTML('beforeend', ` <button class="btn sm pri" onclick="cfgTab='remoto';vCfg().then(()=>setTimeout(nubeProbar,1500))">Probar y reparar</button>`);
    return r;
  };
}
