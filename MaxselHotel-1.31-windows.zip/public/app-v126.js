// Maxsel Hotel 1.26 — Impresoras Star Micronics por red (TSP650, TSP650II, TSP100, TSP143…) sin instalarlas en Windows
'use strict';
{
  const _ci = cImpresora;
  cImpresora = async function (...a) {
    const r = await _ci(...a);
    const con = $('#iT')?.closest('label'); if (!con || $('#iLg')) return r;
    con.insertAdjacentHTML('afterend', `<label class="l">Marca / tipo de impresora<select id="iLg" onchange="iLgCambio()"><option value="escpos">Epson y genéricas (ESC/POS)</option><option value="star">Star Micronics (TSP650, TSP100, TSP143…)</option></select></label>`);
    $('#iLg').value = CFG.impresora_lenguaje === 'star' ? 'star' : 'escpos';
    $('#iIL')?.querySelector('input')?.insertAdjacentHTML('afterend', `<button class="btn sm" type="button" style="margin-top:6px" onclick="buscarRed()">Buscar en la red</button><div id="iRed"></div>`);
    $('#iT').closest('.card').querySelector('p.sub')?.insertAdjacentHTML('afterend', `<div class="aviso" id="iStarAy" style="margin:8px 0">
      <b>Star TSP650 por red (sin instalarla en Windows):</b> 1) Conecte la impresora con cable de red al módem del hotel. 2) Elija <b>Impresora de red (IP)</b> y <b>Star Micronics</b>.
      3) Toque <b>Buscar en la red</b> o escriba su IP (para verla: con la impresora apagada, mantenga presionado <b>FEED</b> y enciéndala; imprime una hoja con la "IP Address"). 4) Puerto <b>9100</b>, papel <b>80 mm</b>. 5) <b>Imprimir prueba</b>.
      <div style="margin-top:6px"><button class="btn sm pri" type="button" onclick="iStarRapido()">Configurar como Star TSP650 por red</button></div></div>`);
    iLgCambio();
    return r;
  };
  const _api = api;
  api = function (metodo, url, body) {
    if (metodo === 'PUT' && url === '/api/config' && body && body.impresora_tipo !== undefined && $('#iLg')) body = { ...body, impresora_lenguaje: val('iLg') };
    return _api(metodo, url, body);
  };
}
function iLgCambio() { const a = $('#iStarAy'); if (a) a.hidden = false; }
function iStarRapido() {
  $('#iT').value = 'ip'; iTipo(); $('#iLg').value = 'star';
  if (!val('iP')) $('#iP').value = '9100'; else if (val('iP') !== '9100') $('#iP').value = '9100';
  $('#iA').value = '80'; $('#iT').dispatchEvent(new Event('change', { bubbles: true }));
  if (!val('iI')) buscarRed(); else toast('Listo. Revise la IP y toque "Imprimir prueba".');
}
async function buscarRed() {
  const box = $('#iRed'); if (box) box.innerHTML = '<div class="sub">Buscando impresoras en la red del hotel… (hasta 30 segundos)</div>';
  try {
    const r = await GET('/api/impresoras/red');
    if (!r.impresoras.length) { box.innerHTML = `<div class="aviso bad" style="margin-top:6px">No se encontró ninguna impresora de red${r.redes.length ? ' en ' + r.redes.map((x) => x + '.x').join(', ') : ''}. Revise que esté encendida y con el cable de red conectado al módem, o escriba su IP a mano.</div>`; return; }
    box.innerHTML = `<div class="sub" style="margin-top:6px">Encontradas (toque una):</div><div class="row" style="gap:6px;flex-wrap:wrap;margin-top:4px">${r.impresoras.map((ip) => `<button class="btn sm" type="button" onclick="$('#iI').value='${ip}';$('#iI').dispatchEvent(new Event('input',{bubbles:true}));toast('IP ${ip} elegida. Toque Imprimir prueba.')">${ip}</button>`).join('')}</div>`;
    if (r.impresoras.length === 1 && !val('iI')) { $('#iI').value = r.impresoras[0]; $('#iI').dispatchEvent(new Event('input', { bubbles: true })); }
  } catch (e) { if (box) box.innerHTML = `<div class="aviso bad">${esc(e.message)}</div>`; }
}
