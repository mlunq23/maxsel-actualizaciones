// Maxsel Hotel 1.21 — botón "Activar notificaciones" en la app del personal de limpieza y mantenimiento.
// Las notificaciones llegan por la dirección segura de Tailscale Funnel (https://...ts.net), parte de la póliza anual.
// Con la app abierta, además suena y vibra cuando llega un trabajo nuevo.
'use strict';
let PUSH_CEL = null;
const esPersonalCel = () => YO && (YO.rol === 'limpieza' || YO.rol === 'mantenimiento');
const rutaPersonal = () => (YO?.rol === 'mantenimiento' ? '/mantenimiento' : '/limpieza');
const esIOS = () => /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const instalada = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
const pushPosible = () => window.isSecureContext && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
async function estadoPushCel() {
  try { PUSH_CEL = await GET('/api/push'); } catch { PUSH_CEL = null; }
  PUSH_CEL = PUSH_CEL || {};
  PUSH_CEL.activoAqui = false;
  if (pushPosible()) {
    try { const reg = await navigator.serviceWorker.getRegistration('/'); const s = reg && (await reg.pushManager.getSubscription()); PUSH_CEL.activoAqui = !!s && Notification.permission === 'granted'; } catch { /* nada */ }
  }
  return PUSH_CEL;
}
// En la dirección segura el service worker queda listo desde que se abre la app
if (pushPosible()) navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(() => {});

if (typeof vMant === 'function') {
  const _vm = vMant;
  vMant = async function (...a) {
    const r = await _vm(...a);
    if (esPersonalCel()) {
      if (!PUSH_CEL) await estadoPushCel();
      const fila = document.querySelector('#main .top .row');
      if (fila && !document.getElementById('btnAvisos')) {
        fila.insertAdjacentHTML('beforeend', PUSH_CEL.activoAqui
          ? `<button class="btn op" id="btnAvisos" onclick="avisosModal()">Notificaciones activas</button>`
          : `<button class="btn op" id="btnAvisos" onclick="avisosModal()" style="border-color:var(--pri,#1e40af)">Activar notificaciones</button>`);
      }
    }
    return r;
  };
}

async function avisosModal() {
  await estadoPushCel();
  const P = PUSH_CEL, dir = P.direccion ? P.direccion + rutaPersonal() : '';
  // 1) No está en la dirección segura: hay que abrir la de internet
  if (!pushPosible()) {
    if (!P.poliza) return modal('Notificaciones', `<p>Las notificaciones al celular vienen con la <b>póliza anual</b> del sistema y no están activas en este hotel.</p><p class="sub">Pida al administrador que lo active con Maxsel: WhatsApp 664 337 5433.</p>`, `<button class="btn pri" onclick="cerrar()">Entendido</button>`);
    if (!dir) return modal('Notificaciones', `<p>Para recibir notificaciones, el administrador debe encender el <b>monitoreo desde el teléfono</b> en Configuración → Monitoreo remoto.</p>`, `<button class="btn pri" onclick="cerrar()">Entendido</button>`);
    return modal('Notificaciones', `<p>Para recibir avisos, abra su app desde esta dirección (funciona con WiFi o con datos):</p>
      <p><a class="btn pri" href="${esc(dir)}" style="display:inline-block;text-decoration:none">Abrir la app segura</a></p>
      <div class="codigo" style="word-break:break-all;font-size:15px">${esc(dir)}</div>
      <p class="sub">Ahí entre con su mismo usuario, déjela en la pantalla de inicio y toque otra vez "Activar notificaciones".</p>`, `<button class="btn" onclick="cerrar()">Cerrar</button>`);
  }
  // 2) iPhone: solo funciona si la app está en la pantalla de inicio
  if (esIOS() && !instalada()) {
    return modal('Notificaciones en iPhone', `<ol style="padding-left:20px;line-height:1.7"><li>Toque el botón <b>Compartir</b> (el cuadro con la flecha hacia arriba).</li><li>Elija <b>Agregar a inicio</b> y toque <b>Agregar</b>.</li>
      <li>Abra la app <b>Maxsel ${YO.rol === 'mantenimiento' ? 'Mantenimiento' : 'Limpieza'}</b> desde su pantalla de inicio y toque otra vez "Activar notificaciones".</li></ol>
      <p class="sub">Apple solo permite notificaciones a las apps que están en la pantalla de inicio (iPhone con iOS 16.4 o más nuevo).</p>`, `<button class="btn pri" onclick="cerrar()">Entendido</button>`);
  }
  if (P.activoAqui) {
    return modal('Notificaciones activas', `<p>Este celular ya recibe un aviso cada vez que le mandan un trabajo, aunque tenga la pantalla apagada.</p><p class="sub">Toque <b>Mandar prueba</b> para revisar que le suene.</p>`,
      `<button class="btn bad" onclick="avisosQuitar()">Desactivar</button><button class="btn" onclick="cerrar()">Cerrar</button><button class="btn pri" onclick="avisosPrueba()">Mandar prueba</button>`);
  }
  if (Notification.permission === 'denied') {
    return modal('Notificaciones bloqueadas', `<p>Este celular tiene bloqueadas las notificaciones de esta app.</p><p class="sub">Ábralas en Ajustes del celular → Notificaciones → ${esIOS() ? 'Maxsel ' + (YO.rol === 'mantenimiento' ? 'Mantenimiento' : 'Limpieza') : 'Chrome → el sitio del hotel'} y permita las notificaciones. Luego vuelva a tocar el botón.</p>`, `<button class="btn pri" onclick="cerrar()">Entendido</button>`);
  }
  modal('Activar notificaciones', `<p>Le va a llegar un aviso al celular cada vez que le manden un trabajo, aunque tenga la pantalla apagada.</p><p class="sub">Al tocar <b>Activar</b>, el celular le pregunta si permite notificaciones: toque <b>Permitir</b>.</p>`,
    `<button class="btn" onclick="cerrar()">Ahora no</button><button class="btn pri" onclick="avisosActivar()">Activar</button>`);
}
const b64aBytes = (s) => { const p = '='.repeat((4 - (s.length % 4)) % 4), b = atob((s + p).replace(/-/g, '+').replace(/_/g, '/')); return Uint8Array.from(b, (c) => c.charCodeAt(0)); };
async function avisosActivar() {
  try {
    sonidoCel(true);
    const perm = await Notification.requestPermission();
    if (perm !== 'granted') { toast('No dio permiso. Toque Permitir cuando el celular pregunte.', true); return avisosModal(); }
    const reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' }); await navigator.serviceWorker.ready;
    let s = await reg.pushManager.getSubscription();
    if (s) { try { await s.unsubscribe(); } catch { /* nada */ } }
    s = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64aBytes(PUSH_CEL.clave) });
    await POST('/api/push/suscribir', { suscripcion: s.toJSON(), equipo: navigator.userAgent.slice(0, 120) });
    toast('Notificaciones activadas'); await estadoPushCel(); cerrar(); vMant();
    setTimeout(() => avisosPrueba(true), 600);
  } catch (e) { toast('No se pudo activar: ' + (e.message || e), true); }
}
async function avisosPrueba(silencio) { try { await POST('/api/push/prueba', {}); if (!silencio) toast('Prueba enviada: debe sonarle en unos segundos'); } catch (e) { toast(e.message, true); } }
async function avisosQuitar() {
  try { const reg = await navigator.serviceWorker.getRegistration('/'), s = reg && (await reg.pushManager.getSubscription()); if (s) { await POST('/api/push/quitar', { endpoint: s.endpoint }); await s.unsubscribe(); } } catch { /* nada */ }
  toast('Notificaciones desactivadas en este celular'); await estadoPushCel(); cerrar(); vMant();
}

// ---------- Con la app abierta: suena y vibra cuando llega un trabajo nuevo ----------
let ctxSonidoCel = null;
function sonidoCel(soloPreparar) {
  try {
    ctxSonidoCel = ctxSonidoCel || new (window.AudioContext || window.webkitAudioContext)();
    if (ctxSonidoCel.state === 'suspended') ctxSonidoCel.resume();
    if (soloPreparar) return;
    [0, 0.25, 0.5].forEach((t) => { const o = ctxSonidoCel.createOscillator(), g = ctxSonidoCel.createGain(); o.frequency.value = 880; g.gain.value = 0.25; o.connect(g); g.connect(ctxSonidoCel.destination); o.start(ctxSonidoCel.currentTime + t); o.stop(ctxSonidoCel.currentTime + t + 0.15); });
  } catch { /* sin sonido */ }
}
document.addEventListener('click', () => sonidoCel(true), { once: true, capture: true });
let vistosCel = null;
setInterval(async () => {
  if (!esPersonalCel() || document.hidden) return;
  try {
    const l = await GET('/api/mant?x=1'), ids = new Set(l.map((m) => m.id));
    if (vistosCel) {
      const nuevos = l.filter((m) => !vistosCel.has(m.id));
      if (nuevos.length) {
        sonidoCel(); try { navigator.vibrate?.([300, 150, 300]); } catch { /* nada */ }
        const m = nuevos[0]; toast(`Trabajo nuevo${m.numero ? ' · Hab. ' + m.numero : ''}: ${m.titulo}`);
        if (typeof vista !== 'undefined' && vista === 'mant' && $('#modal').hidden) vMant().catch(() => {});
      }
    }
    vistosCel = ids;
  } catch { /* sin conexión */ }
}, 15000);

// ---------- Configuración → Personal: dirección de internet (con notificaciones) para el personal ----------
if (typeof cMantPortal === 'function') {
  const _cmp = cMantPortal;
  cMantPortal = async function (...a) {
    const r = await _cmp(...a);
    let P = {}; try { P = await GET('/api/push'); } catch { /* nada */ }
    if (typeof cfgTab !== 'undefined' && cfgTab !== 'mant') return r;
    const c = $('#cfgc .stack'); if (!c) return r;
    const dir = P.direccion || '';
    const caja = (k, n) => `<div class="stack" style="gap:6px;align-items:center;min-width:0;text-align:center"><b>App de ${n}</b>${typeof qrSVG === 'function' ? `<div class="qr-box">${qrSVG(dir + '/' + k, 5)}</div>` : ''}<div class="codigo" style="font-size:15px;word-break:break-all">${esc(dir + '/' + k)}</div><button class="btn sm" onclick="imprimirQRInternet('${k}','${n}')">Imprimir hoja con QR</button></div>`;
    const nombre = dir ? dir.replace(/^https:\/\//, '').split('.')[0] : '';
    c.insertAdjacentHTML('afterbegin', `<div class="card"><h2 style="margin-top:0">Dirección del personal con notificaciones</h2>
      ${!P.poliza ? `<div class="aviso">Las notificaciones al celular del personal vienen con la <b>póliza anual</b>. Para activarla comuníquese con Maxsel: WhatsApp 664 337 5433.</div>`
      : !dir ? `<div class="aviso">Encienda el <b>monitoreo desde el teléfono</b> (Configuración → Monitoreo remoto) para tener la dirección segura del personal.</div>`
      : `<p class="sub">Con esta dirección el personal usa su app con WiFi o con datos y le llegan notificaciones de cada trabajo nuevo. Escanee el QR, entre con su usuario, deje la app en la pantalla de inicio y toque <b>Activar notificaciones</b>.</p>
        <div class="row" style="gap:24px;flex-wrap:wrap;justify-content:center">${caja('limpieza', 'Limpieza')}${caja('mantenimiento', 'Mantenimiento')}</div>
        <div class="f" style="margin-top:12px;align-items:end"><label class="l">Nombre corto de la dirección (letras y números, sin espacios)<input id="tsNom" value="${esc(nombre)}" placeholder="hotelrivas"></label><button class="btn" onclick="cambiarNombreDir()">Cambiar</button></div>
        <div class="sub">Queda así: https://<b>${esc(nombre || 'hotelrivas')}</b>.${esc(dir.replace(/^https:\/\/[^.]+\./, '') || 'su-red.ts.net')}/limpieza</div>`}</div>`);
    return r;
  };
}
async function cambiarNombreDir() {
  const n = val('tsNom');
  await hacer(() => POST('/api/nube/nombre', { nombre: n }), 'Listo. La dirección nueva tarda unos minutos en funcionar.');
  setTimeout(() => cMantPortal(), 1500);
}
async function imprimirQRInternet(k, n) {
  const P = await GET('/api/push'), url = (P.direccion || '') + '/' + k;
  imprimirDoc(`<div class="rep" style="text-align:center"><div class="rep-enc"><b>${esc(CFG.hotel_nombre)}</b><span>APP DE ${n.toUpperCase()}</span><span>Para el celular del personal</span></div>
    <div style="margin:18px auto;width:fit-content">${qrSVG(url, 9)}</div><div style="font-size:20px;font-weight:800;margin-bottom:14px;word-break:break-all">${esc(url)}</div>
    <ol style="text-align:left;font-size:15px;line-height:1.8;max-width:560px;margin:0 auto"><li>Abra la cámara del celular y apunte a este código. Toque el enlace (funciona con WiFi o con datos).</li>
      <li>Entre con su usuario: ____________________ &nbsp; contraseña: ____________________</li>
      <li>Déjela en la pantalla de inicio: Android, menú ⋮ → <b>Agregar a la pantalla principal</b>; iPhone, <b>Compartir → Agregar a inicio</b>.</li>
      <li>Ábrala desde la pantalla de inicio y toque <b>Activar notificaciones</b> → <b>Permitir</b>.</li>
      <li>Cada trabajo nuevo le llega como notificación, aunque tenga la pantalla apagada.</li></ol></div>`, 'carta', 'App de ' + n);
}
