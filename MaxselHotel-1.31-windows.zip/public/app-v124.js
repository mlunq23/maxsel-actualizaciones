// Maxsel Hotel 1.24 — Configuración: barra fija "Guardar cambios" siempre a la vista y guardado automático al salir de la pantalla
'use strict';
const CFG_SUCIOS = new Set(); // botones "Guardar" con cambios pendientes
let cfgGuardando = false;
const esGuardar = (b) => b && b.tagName === 'BUTTON' && /^\s*Guardar/.test(b.textContent) && !b.closest('#modal');
// El botón Guardar que le toca a un campo: el primero que aparece después de él en la pantalla
function guardarDe(el) {
  const bs = [...document.querySelectorAll('#cfgc button')].filter(esGuardar);
  return bs.find((b) => el.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING) || null;
}
function barraCfg() {
  let bar = $('#cfgBarra');
  if (!bar) {
    document.body.insertAdjacentHTML('beforeend', `<div id="cfgBarra" hidden style="position:fixed;left:50%;transform:translateX(-50%);bottom:calc(16px + env(safe-area-inset-bottom,0px));z-index:900;display:flex;gap:12px;align-items:center;background:var(--panel,#fff);border:2px solid var(--pri,#1e40af);border-radius:14px;padding:10px 14px;box-shadow:0 10px 30px rgba(0,0,0,.25);max-width:calc(100vw - 32px);flex-wrap:wrap">
      <b>Tiene cambios sin guardar</b><button class="btn" onclick="cfgDescartar()">Descartar</button><button class="btn pri" onclick="cfgGuardarTodo()">Guardar cambios</button></div>`);
    bar = $('#cfgBarra');
  }
  bar.hidden = !(CFG_SUCIOS.size && vista === 'cfg' && $('#cfgc'));
}
function marcarCfg(e) {
  const t = e.target;
  if (!t || !t.closest || !t.closest('#cfgc') || t.type === 'file' || t.closest('#modal')) return;
  const b = guardarDe(t); if (!b) return;
  CFG_SUCIOS.add(b); barraCfg();
}
document.addEventListener('input', marcarCfg, true);
document.addEventListener('change', marcarCfg, true);
// Si el usuario toca un Guardar de la pantalla, ese ya no está pendiente
document.addEventListener('click', (e) => { const b = e.target.closest?.('button'); if (esGuardar(b) && CFG_SUCIOS.has(b)) { CFG_SUCIOS.delete(b); setTimeout(barraCfg, 0); } }, true);

async function cfgGuardarTodo(silencio) {
  if (cfgGuardando || !CFG_SUCIOS.size) return true;
  cfgGuardando = true;
  try {
    for (const b of [...CFG_SUCIOS]) {
      if (!document.body.contains(b)) { CFG_SUCIOS.delete(b); continue; }
      const f = b.getAttribute('onclick');
      CFG_SUCIOS.delete(b);
      // Corre la misma acción del botón y espera a que termine (para saber si se guardó)
      try { await (new Function('return (async () => { return ' + f.replace(/;\s*$/, '') + ' })()'))(); }
      catch (err) { CFG_SUCIOS.add(b); toast('No se guardó: ' + (err.message || err), true); return false; }
    }
    if (!silencio) toast('Cambios guardados');
    return true;
  } finally { cfgGuardando = false; barraCfg(); }
}
function cfgDescartar() { CFG_SUCIOS.clear(); barraCfg(); vCfg(); }

// Al salir de la pantalla (otro menú u otra pestaña de Configuración) se guarda solo lo que cambió
{
  const _ir = ir;
  ir = async function (v, ...a) {
    if (CFG_SUCIOS.size && vista === 'cfg') { const ok = await cfgGuardarTodo(true); if (ok) toast('Se guardaron sus cambios de Configuración'); else return; }
    CFG_SUCIOS.clear(); const r = await _ir(v, ...a); barraCfg(); return r;
  };
  const _vc = vCfg;
  let tabAnterior = typeof cfgTab !== 'undefined' ? cfgTab : null;
  vCfg = async function (...a) {
    if (CFG_SUCIOS.size && tabAnterior && tabAnterior !== cfgTab) {
      const nueva = cfgTab; cfgTab = tabAnterior; // guardar con la pestaña vieja todavía en pantalla
      const ok = await cfgGuardarTodo(true); cfgTab = nueva;
      if (ok) toast('Se guardaron sus cambios'); else { cfgTab = tabAnterior; return; }
    }
    CFG_SUCIOS.clear(); tabAnterior = cfgTab;
    const r = await _vc(...a); barraCfg(); return r;
  };
}
// Si cierran o recargan la ventana con cambios, el navegador avisa
window.addEventListener('beforeunload', (e) => { if (CFG_SUCIOS.size && vista === 'cfg') { e.preventDefault(); e.returnValue = ''; } });
