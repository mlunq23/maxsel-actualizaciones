// Maxsel Hotel 1.23 — rentas por semana: cada huésped elige qué día de la semana paga (independiente de cuándo entró)
'use strict';
const DIAS_PAGO = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
const fLocal = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:00`;
const fechaEntradaReg = () => { const v = $('#rEnt')?.value; const d = v ? new Date(v) : new Date(); return isNaN(d) ? new Date() : d; };

// ---------- Al registrar ----------
{
  const _rc = rCalc;
  rCalc = function (id, reset) {
    const r = _rc(id, reset);
    const m = document.querySelector('input[name=rM]:checked')?.value, res = $('#rRes');
    let box = $('#rDpBox');
    if (!box && res) {
      res.insertAdjacentHTML('beforebegin', `<div id="rDpBox" class="card" style="margin:8px 0;padding:10px 12px"><label class="l">Día de pago (cada semana)<select id="rDp" onchange="this.dataset.t=1;rCalc(${id})">${DIAS_PAGO.map((d, i) => `<option value="${i}">${d}</option>`).join('')}</select></label><div class="sub" id="rDpInfo"></div></div>`);
      box = $('#rDpBox');
    }
    if (!box) return r;
    box.hidden = m !== 'semana';
    if (m !== 'semana') return r;
    const ent = fechaEntradaReg(), sel = $('#rDp');
    if (!sel.dataset.t) sel.value = String(ent.getDay());
    const dp = Number(sel.value), k = (dp - ent.getDay() + 7) % 7, n = Math.max(1, parseInt(val('rC')) || 1), u = num('rU');
    if (!k) { $('#rDpInfo').textContent = `Paga cada ${DIAS_PAGO[dp].toLowerCase()} (el mismo día de la semana en que entra).`; return r; }
    const primero = u * k / 7, total = primero + u * (n - 1), pago1 = new Date(ent); pago1.setDate(pago1.getDate() + k);
    $('#rDpInfo').innerHTML = `Primer pago: <b>${k} día${k > 1 ? 's' : ''}</b> (hasta el ${DIAS_PAGO[dp].toLowerCase()} ${pago1.getDate()}/${pago1.getMonth() + 1}) = <b>${money(primero)}</b>${n > 1 ? ` + ${n - 1} semana(s) completas` : ''}. Después paga cada <b>${DIAS_PAGO[dp].toLowerCase()}</b> ${money(u)}.`;
    // El resumen y el anticipo se ajustan al prorrateo
    const extras = (($('#rLim')?.checked ? Number(CFG.cuota_limpieza) || 0 : 0) + Math.max(0, parseInt(val('rMas')) || 0) * (Number(CFG.cuota_mascota) || 0));
    if (!$('#rA').dataset.t) $('#rA').value = (total + extras).toFixed(2);
    // Resumen con el prorrateo: primer pago hasta su día, check out ese día a la hora elegida
    const sal = new Date(pago1); sal.setDate(sal.getDate() + 7 * (n - 1)); const [hh, mm] = String(val('rSal') || '13:00').split(':').map(Number); sal.setHours(hh || 0, mm || 0, 0, 0);
    const pend = total + extras - num('rA');
    res.innerHTML = `<span>Primer pago: ${k} día${k > 1 ? 's' : ''} (${money(u)} ÷ 7 × ${k})</span><b>${money(primero)}</b>${n > 1 ? `<span>${n - 1} semana(s) más × ${money(u)}</span><b>${money(u * (n - 1))}</b>` : ''}${extras ? `<span>Cuotas</span><b>${money(extras)}</b>` : ''}<span>Total</span><b class="big">${money(total + extras)}</b><span>Check out (su día de pago)</span><b>${fSal(sal)}</b><span>Queda por pagar</span><b style="color:${pend > 0.004 ? 'var(--ocup)' : 'var(--libre)'}">${money(Math.max(0, pend))}</b>`;
    return r;
  };
  const _api = api;
  api = function (metodo, url, body) {
    if (metodo === 'POST' && url === '/api/estancias' && body && body.modalidad === 'semana' && $('#rDp')) body = { ...body, dia_pago: Number($('#rDp').value) };
    return _api(metodo, url, body);
  };
}

// ---------- En la cuenta del huésped: ver y cambiar su día de pago ----------
{
  const _ve = verEstancia;
  verEstancia = async function (id, ...a) {
    const r = await _ve(id, ...a);
    try {
      const e = await GET('/api/estancias/' + id);
      if (!e.activa || e.modalidad !== 'semana') return r;
      const dp = e.dia_pago !== null && e.dia_pago !== undefined ? Number(e.dia_pago) : aF(e.salida_prevista).getDay();
      const caja = document.querySelector('#modal .mbody'); if (!caja || $('#dpCuenta')) return r;
      caja.insertAdjacentHTML('afterbegin', `<div id="dpCuenta" class="card" style="margin-bottom:10px;padding:10px 12px;display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">
        <div><div class="lbl">Día de pago</div><b style="font-size:17px">Cada ${DIAS_PAGO[dp].toLowerCase()}</b> <span class="sub">· próximo pago ${fdt(e.salida_prevista)}</span></div>
        ${puede('registrar') ? `<button class="btn sm op" onclick="diaPagoModal(${e.id},${dp},${Number(e.precio) || 0},'${e.salida_prevista}')">Cambiar día de pago</button>` : ''}</div>`);
    } catch { /* nada */ }
    return r;
  };
}
function diaPagoModal(eid, actual, precio, salida) {
  diaPagoModal.d = { eid, precio, salida };
  modal('Cambiar día de pago', `<label class="l">Nuevo día de pago<select id="dpN" onchange="diaPagoCalc()">${DIAS_PAGO.map((d, i) => `<option value="${i}" ${i === actual ? 'selected' : ''}>${d}</option>`).join('')}</select></label>
    <div class="calc" id="dpR"></div><div class="sub">Su próximo pago se recorre al día que elija y se le cargan los días de más (precio de la semana ÷ 7 por día). De ahí en adelante paga cada semana ese día.</div>`,
  `<button class="btn" onclick="verEstancia(${eid})">Volver</button><button class="btn pri" onclick="diaPagoOk()">Guardar</button>`);
  diaPagoCalc();
}
function diaPagoCalc() {
  const { precio, salida } = diaPagoModal.d, s = aF(salida), dp = Number(val('dpN')), k = (dp - s.getDay() + 7) % 7, n = new Date(s); n.setDate(n.getDate() + k);
  $('#dpR').innerHTML = k ? `<span>Días de más hasta el ${DIAS_PAGO[dp].toLowerCase()}</span><b>${k}</b><span>Se carga a su cuenta</span><b class="big">${money(precio * k / 7)}</b><span>Próximo pago</span><b>${fdt(fLocal(n))}</b>`
    : '<span>Es el mismo día de su próximo pago</span><b>Sin cargo</b>';
}
async function diaPagoOk() {
  const { eid } = diaPagoModal.d;
  const r = await hacer(() => POST(`/api/estancias/${eid}/dia-pago`, { dia_pago: Number(val('dpN')) }), 'Día de pago guardado');
  if (r?.cargo > 0) toast(`Se cargaron ${r.dias} día(s): ${money(r.cargo)}`);
  verEstancia(eid); vHab();
}
if (typeof TIPO_REN === 'object') TIPO_REN.dia_pago = 'Cambio de día de pago';
