// Servidor del sistema de gimnasio. Se abre en el navegador: http://localhost:3000
import http from 'node:http';
import https from 'node:https';
import zlib from 'node:zlib';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { execFile, spawn } from 'node:child_process';
import { createRequire } from 'node:module';
import { buscarFotosEnPc, busquedaPc } from './fotospc.js';
import { db, DATA_DIR, all, get, run, tx, cfg, cfgTodo, setCfg, CONFIG_DEFAULT, hoy, ahora, sumarDias, sumarMeses, diasEntre as diasHasta, r2, isoLocal, hashPass, checkPass, FOTOS_DIR, DOCS_DIR } from './db.js';
import {
  ErrorUsuario, estadoCliente, cotizarMembresia, conectarPantalla, avisarPantallas, procesarAcceso, eventoLector,
  sincronizarCliente, sincronizarEnSegundoPlano, iniciarImportacion, importacion, lector, lectorEstado, modoReal, iniciarConsultaEventos, infoPantallaCliente, puedeEntrar, textoEstado,
} from './negocio.js';
import { leerMultipart, Hikvision } from './hikvision.js';
import { PERMISOS, PERMISOS_ROL, permisosDe, limpiarPermisos } from './permisos.js';
import { crearSincronizador, iniciarSesion, URL_PAGINA } from './nube.js';
import { LICENCIA, revisarLicencia, estadoLicencia as estadoLicenciaBase, activarLicencia, codigoEquipo, MODO_DESARROLLO, limiteClientes, moduloActivo as moduloLicencia, NOMBRE_MODULO } from './licencia.js';

// 1.11.1: el módulo de ASISTENCIA solo se activa si la licencia lo trae (licencias versión 3 hechas con la casilla "Asistencia").
// Las licencias viejas (antes de la 1.9) ya no lo encienden. Se revisa aquí (y no solo en licencia.js) porque las
// actualizaciones por internet no cambian licencia.js (ahí va la llave pública de cada instalador).
let _verLic = { t: 0, v: 0 };
function versionLicencia() {
  if (Date.now() - _verLic.t < 10000) return _verLic.v;
  let v = 0;
  try {
    const c = fs.readFileSync(path.join(DATA_DIR, 'licencia.txt'), 'utf8').trim().toUpperCase().replace(/^GY1-?/, '').replace(/[^0-9A-Z]/g, '');
    const B = '0123456789ABCDEFGHJKMNPQRSTVWXYZ', a = B.indexOf(c[0]), b = B.indexOf(c[1]);
    if (a >= 0 && b >= 0) v = ((a << 3) | (b >> 2)) & 255;
  } catch { /* sin licencia */ }
  _verLic = { t: Date.now(), v };
  return v;
}
const moduloActivo = (k) => moduloLicencia(k) && (k !== 'asistencia' || MODO_DESARROLLO || versionLicencia() >= 3);
const estadoLicencia = () => { const e = estadoLicenciaBase(); return e.modulos ? { ...e, modulos: Object.fromEntries(Object.keys(e.modulos).map((k) => [k, moduloActivo(k)])) } : e; };
const DIR = path.dirname(fileURLToPath(import.meta.url));
const { qrSvg } = createRequire(import.meta.url)('./qr.cjs');
const PUBLIC = path.join(DIR, 'public');
const PUERTO = Number(process.env.PORT || 3030);
export const PRODUCTO = 'Maxsel Punto de Venta para Gimnasios';
const VERSION = '1.12.4';
const NIVEL = { cajero: 1, gerente: 2, admin: 3 };

// ---------- Utilidades HTTP ----------
function enviar(res, status, obj, headers = {}) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(body);
}
function leerCuerpo(req, max = 8 * 1024 * 1024) {
  return new Promise((ok, mal) => {
    const chunks = []; let n = 0;
    req.on('data', (c) => { n += c.length; if (n > max) { mal(new ErrorUsuario('Archivo demasiado grande', 413)); req.destroy(); } else chunks.push(c); });
    req.on('end', () => ok(Buffer.concat(chunks)));
    req.on('error', mal);
  });
}
const cookies = (req) => Object.fromEntries(String(req.headers.cookie || '').split(';').map((c) => c.trim().split('=')).filter((p) => p[0]));
const num = (v) => r2(Number(v) || 0);
const txt = (v) => (v === undefined || v === null ? null : String(v).trim());

const rutas = [];
const ruta = (metodo, patron, rol, fn) => rutas.push({ metodo, re: new RegExp('^' + patron.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), rol, fn });

// ---------- Licencia ----------
const clientesRegistrados = () => get('SELECT COUNT(*) n FROM clientes').n;
ruta('GET', '/api/licencia/estado', null, () => ({ ...estadoLicencia(), producto: PRODUCTO, version: VERSION, clientes: LICENCIA.activa ? clientesRegistrados() : null }));
// La licencia se vende por número máximo de clientes (100, 500, 1000…). 0 = sin límite.
function revisarCupoClientes(nuevos = 1) {
  const lim = limiteClientes(); if (!lim) return;
  const n = clientesRegistrados();
  if (n + nuevos > lim) throw new ErrorUsuario(`Su licencia permite hasta ${lim.toLocaleString('es-MX')} clientes y ya tiene ${n.toLocaleString('es-MX')} registrados. Para registrar más clientes pida a Maxsel una licencia más grande (o elimine clientes que ya no vienen).`, 403);
}
ruta('POST', '/api/licencia/activar', null, ({ body }) => {
  _verLic = { t: 0, v: 0 };
  try { return activarLicencia(body.clave); } catch (e) { throw new ErrorUsuario(e.message); }
});
const SIN_LICENCIA_OK = new Set(['/api/licencia/estado', '/api/licencia/activar']);
// Módulos que se venden aparte (se activan en la licencia): qué rutas le pertenecen a cada uno.
// "Asistencia" = checador de EMPLEADOS (1.9). La entrada de socios (lector facial) no es módulo: siempre va incluida.
const RUTAS_MODULO = [
  ['gastos', /^\/api\/(gastos|cuentas-pagar|proveedores|empleados)(\/|$)/],
  ['asistencia', /^\/api\/(asistencia|huella|festivos|relojes)(\/|$)/],
];
const REPORTES_MODULO = { cuentas: 'gastos', empleados: 'gastos' }; // reportes sueltos de /api/reportes/excel que son del módulo
const moduloDeRuta = (r0, q = {}) => (r0 === '/api/reportes/excel' ? REPORTES_MODULO[q.tipo] : RUTAS_MODULO.find(([, re]) => re.test(r0))?.[0]) || null;
const SIN_MODULO = (k) => `El módulo de ${NOMBRE_MODULO[k] || k} no está incluido en la licencia de este negocio. Para activarlo comuníquese con Maxsel.`;

// ---------- Sesión ----------
ruta('POST', '/api/login', null, ({ body, res, req }) => {
  const u = get('SELECT * FROM usuarios WHERE usuario=? AND activo=1', txt(body.usuario)?.toLowerCase());
  const ip = ipCliente(req);
  if (bloqueadoIp(ip)) throw new ErrorUsuario('Demasiados intentos. Espera 15 minutos.', 429);
  if (!u || !checkPass(body.password || '', u.pass_hash)) { fallaIp(ip); throw new ErrorUsuario('Usuario o contraseña incorrectos', 401); }
  if (req.publico && !new Set(permisosDe(u)).has('movil')) throw new ErrorUsuario('Ese usuario no tiene permiso para ver las ventas desde el celular.', 403);
  const token = crypto.randomBytes(24).toString('hex');
  run('INSERT INTO sesiones(token,usuario_id,creado) VALUES(?,?,?)', token, u.id, ahora());
  res.setHeader('Set-Cookie', `gym_s=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000`);
  return { id: u.id, nombre: u.nombre, rol: u.rol };
});
ruta('POST', '/api/logout', 'sesion', ({ req, res }) => {
  run('DELETE FROM sesiones WHERE token=?', cookies(req).gym_s);
  res.setHeader('Set-Cookie', 'gym_s=; Path=/; Max-Age=0');
  return { ok: true };
});
ruta('GET', '/api/yo', 'sesion', ({ u }) => ({
  id: u.id, nombre: u.nombre, rol: u.rol, gym: cfg('gym_nombre'), turno: turnoAbierto(u.id) || null, permisos: [...u.perm],
  licencia: estadoLicencia(), producto: PRODUCTO, version: VERSION,
}));

// ---------- Usuarios y permisos (solo administrador) ----------
ruta('GET', '/api/permisos', 'sesion', () => ({ lista: PERMISOS, roles: PERMISOS_ROL }));
ruta('GET', '/api/usuarios', 'usuarios', () => all('SELECT id,nombre,usuario,rol,activo,permisos FROM usuarios ORDER BY nombre')
  .map((x) => ({ ...x, personalizado: !!x.permisos && x.rol !== 'admin', permisos: permisosDe(x) })));
function permisosBody(body) {
  if (body.rol === 'admin' || body.permisos === undefined || body.permisos === null) return null;
  const l = limpiarPermisos(body.permisos);
  const rolBase = PERMISOS_ROL[body.rol] || [];
  // si son exactamente los del rol, no se guardan como personalizados
  if (l && l.length === rolBase.length && l.every((k) => rolBase.includes(k))) return null;
  return l ? JSON.stringify(l) : null;
}
ruta('POST', '/api/usuarios', 'usuarios', ({ body }) => {
  if (!txt(body.nombre) || !txt(body.usuario) || !body.password) throw new ErrorUsuario('Nombre, usuario y contraseña son obligatorios');
  if (!NIVEL[body.rol]) throw new ErrorUsuario('Rol inválido');
  if (get('SELECT id FROM usuarios WHERE usuario=?', txt(body.usuario).toLowerCase())) throw new ErrorUsuario('Ese nombre de usuario ya existe');
  return run('INSERT INTO usuarios(nombre,usuario,pass_hash,rol,permisos) VALUES(?,?,?,?,?)', txt(body.nombre), txt(body.usuario).toLowerCase(), hashPass(body.password), body.rol, permisosBody(body));
});
ruta('PUT', '/api/usuarios/:id', 'usuarios', ({ body, p, u }) => {
  const id = Number(p.id);
  const actual = get('SELECT * FROM usuarios WHERE id=?', id);
  if (!actual) throw new ErrorUsuario('Usuario no encontrado', 404);
  if (id === u.id && (body.activo === false || (body.rol && body.rol !== 'admin'))) throw new ErrorUsuario('No puedes desactivarte ni quitarte el rol de administrador a ti mismo');
  const rol = NIVEL[body.rol] ? body.rol : actual.rol;
  run('UPDATE usuarios SET nombre=COALESCE(?,nombre), rol=?, activo=COALESCE(?,activo), permisos=? WHERE id=?',
    txt(body.nombre), rol, body.activo === undefined ? null : body.activo ? 1 : 0, permisosBody({ ...body, rol }), id);
  if (body.password) run('UPDATE usuarios SET pass_hash=? WHERE id=?', hashPass(body.password), id);
  if (body.activo === false) run('DELETE FROM sesiones WHERE usuario_id=?', id);
  return { ok: true };
});
ruta('POST', '/api/mi-password', 'sesion', ({ body, u }) => {
  if (!checkPass(body.actual || '', u.pass_hash)) throw new ErrorUsuario('La contraseña actual no es correcta');
  if (String(body.nueva || '').length < 4) throw new ErrorUsuario('La nueva contraseña debe tener al menos 4 caracteres');
  run('UPDATE usuarios SET pass_hash=? WHERE id=?', hashPass(body.nueva), u.id);
  return { ok: true };
});

// ---------- Clave de súper usuario de Maxsel (igual que Maxsel Tech / Abarrotes) ----------
// Solo se guarda la huella SHA-256, nunca el texto de la contraseña.
const SUPER_HASH = '27486342e248a68acb426e94ae242e3483785c78fac2f971b602f09771629cfa';
const esSuper = (pw) => !!pw && crypto.createHash('sha256').update('maxsel-super|' + String(pw)).digest('hex') === SUPER_HASH;
// Bloqueo por intentos fallidos (6 errores = 15 minutos)
const fallasIp = new Map();
function ipCliente(req) { return (req.publico ? String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() : '') || String(req.socket?.remoteAddress || '').replace(/^::ffff:/, ''); }
function bloqueadoIp(ip) { const f = fallasIp.get(ip); return !!f && f.hasta > Date.now(); }
function fallaIp(ip) { const f = fallasIp.get(ip) || { n: 0, hasta: 0 }; if (++f.n >= 6) { f.hasta = Date.now() + 15 * 60 * 1000; f.n = 0; } fallasIp.set(ip, f); }

// ---------- Recuperar contraseña (desde la pantalla de entrar) ----------
// Un administrador le pone contraseña nueva a cualquier usuario. Si nadie recuerda la de un administrador, Maxsel lo hace con su clave de soporte.
ruta('GET', '/api/login/usuarios', null, ({ req }) => {
  if (req.publico) throw new ErrorUsuario('No disponible', 404);
  return all('SELECT id,nombre,usuario,rol FROM usuarios WHERE activo=1 ORDER BY (rol=\'admin\') DESC, nombre');
});
ruta('POST', '/api/recuperar', null, ({ body, req }) => {
  if (req.publico) throw new ErrorUsuario('No disponible', 404);
  const ip = ipCliente(req);
  if (bloqueadoIp(ip)) throw new ErrorUsuario('Demasiados intentos. Espera 15 minutos.', 429);
  const obj = get('SELECT * FROM usuarios WHERE id=? AND activo=1', Number(body.usuario_id));
  if (!obj) throw new ErrorUsuario('Elige el usuario');
  const nueva = String(body.nueva || '');
  if (nueva.length < 4) throw new ErrorUsuario('La contraseña nueva debe tener al menos 4 caracteres');
  const aut = String(body.autorizacion || '');
  const ok = esSuper(aut) || all(`SELECT pass_hash FROM usuarios WHERE rol='admin' AND activo=1`).some((a) => checkPass(aut, a.pass_hash));
  if (!ok) { fallaIp(ip); throw new ErrorUsuario('La contraseña de administrador (o la clave de soporte de Maxsel) no es correcta'); }
  run('UPDATE usuarios SET pass_hash=? WHERE id=?', hashPass(nueva), obj.id);
  run('DELETE FROM sesiones WHERE usuario_id=?', obj.id);
  return { ok: true, usuario: obj.usuario, nombre: obj.nombre };
});

// ---------- Reiniciar el sistema · solo Maxsel (botón oculto) ----------
// Borra ventas, turnos y cortes (p. ej. las ventas de prueba de la instalación). Lo vendido regresa al inventario.
// Usuarios, configuración, planes y licencia no se borran.
ruta('POST', '/api/sistema/reiniciar', 'sesion', ({ body, req }) => {
  const ip = ipCliente(req);
  if (bloqueadoIp(ip)) throw new ErrorUsuario('Demasiados intentos. Espera 15 minutos.', 429);
  if (!esSuper(body.clave)) { fallaIp(ip); throw new ErrorUsuario('Contraseña de Maxsel incorrecta', 403); }
  const op = { clientes: !!body.clientes, inventario: !!body.inventario };
  tx(() => {
    if (!op.inventario) {
      for (const it of all(`SELECT vi.producto_id, SUM(vi.cantidad) c FROM venta_items vi JOIN ventas v ON v.id=vi.venta_id WHERE vi.tipo='producto' AND vi.producto_id IS NOT NULL AND v.cancelada=0 GROUP BY vi.producto_id`))
        run('UPDATE productos SET existencia=existencia+? WHERE id=?', it.c, it.producto_id);
    }
    for (const t of ['venta_items', 'ventas', 'abonos', 'movimientos', 'turnos', 'membresias', 'visitas', 'avisos']) run(`DELETE FROM ${t}`);
    if (op.clientes) run('DELETE FROM clientes');
    if (op.inventario) run('DELETE FROM productos');
  });
  return { ok: true, ...op };
});

// ---------- Configuración ----------
ruta('GET', '/api/config', 'sesion', ({ u }) => {
  const c = cfgTodo();
  if (!u.perm.has('config')) delete c.hik_password; else c.hik_password = c.hik_password ? '********' : '';
  for (const k of Object.keys(c)) if (k.startsWith('nube_') && k !== 'nube_activo' && k !== 'nube_email') delete c[k];
  const ips = Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => i.address);
  return { ...c, _ips: ips, _puerto: PUERTO };
});
ruta('PUT', '/api/config', 'config', ({ body }) => {
  for (const k of Object.keys(CONFIG_DEFAULT)) {
    if (body[k] === undefined) continue;
    if (k === 'hik_password' && body[k] === '********') continue;
    if (k === 'hik_puerto' && String(body[k]).trim() === '8000') { setCfg(k, '80'); continue; } // el 8000 es del SDK/iVMS, no sirve
    setCfg(k, body[k]);
  }
  avisarPantallas({ tipo: 'config' });
  return { ok: true };
});

// ---------- Lector Hikvision ----------
ruta('GET', '/api/lector/estado', 'sesion', () => ({ ...lectorEstado, modo: cfg('hik_modo'), ip: cfg('hik_ip') }));
ruta('POST', '/api/lector/probar', 'config', async () => {
  if (cfg('hik_modo') !== 'real') throw new ErrorUsuario('Cambia el modo a "Lector real" y guarda antes de probar');
  if (!cfg('hik_ip')) throw new ErrorUsuario('Escribe la IP del lector y guarda');
  try {
    return await lector().info();
  } catch (e) {
    if (/contraseña/i.test(e.message)) throw e;
    const r = await buscarPuertoLector();
    if (r) return r;
    throw e;
  }
});
// Si el puerto está mal (por ejemplo 8000, que es del SDK/iVMS), se busca el puerto web del lector y se guarda
async function buscarPuertoLector() {
  const actual = Number(cfg('hik_puerto')) || 80;
  for (const puerto of [80, 8080, 81, 8081, 443].filter((x) => x !== actual)) {
    try {
      const h = new Hikvision({ ip: cfg('hik_ip'), puerto, usuario: cfg('hik_usuario'), password: cfg('hik_password'), puerta: cfg('hik_puerta') });
      const info = await h.info();
      setCfg('hik_puerto', puerto);
      return { ...info, puerto_corregido: puerto, puerto_anterior: actual };
    } catch (e2) {
      if (/contraseña/i.test(e2.message)) throw new ErrorUsuario(`El lector respondió en el puerto ${puerto}, pero el usuario o la contraseña no son correctos`);
    }
  }
  return null;
}
ruta('POST', '/api/lector/sincronizar-todos', 'config', async ({ body }) => {
  // los importados del lector se omiten (para no quitarles el acceso que ya tenían) salvo que se pida
  const ids = all(`SELECT id FROM clientes ${body.incluirImportados ? '' : 'WHERE importado=0'}`).map((c) => c.id);
  let ok = 0; const errores = [];
  for (const id of ids) {
    const r = await sincronizarCliente(id);
    if (r?.ok) ok++; else errores.push({ id, error: r?.error });
  }
  return { total: ids.length, ok, errores: errores.slice(0, 20) };
});
ruta('POST', '/api/lector/configurar-eventos', 'config', async ({ body }) => {
  const ip = txt(body.ip) || cfg('servidor_ip');
  if (!ip) throw new ErrorUsuario('Indica la IP de esta computadora');
  setCfg('servidor_ip', ip);
  await lector().configurarEnvioEventos(ip, PUERTO);
  return { ok: true };
});
ruta('POST', '/api/lector/importar', 'config', ({ body }) => iniciarImportacion({ vigencia: body.vigencia !== false, fotos: body.fotos !== false }));
// 1.12: buscar en ESTA computadora las fotos de los clientes que no tienen (iVMS-4200, Hik-Connect, carpetas de fotos)
ruta('POST', '/api/lector/fotos-pc', 'config', ({ body }) => {
  if (busquedaPc.activa || importacion.activa) throw new ErrorUsuario('Ya hay una búsqueda o importación en proceso');
  const carpeta = txt(body.carpeta);
  if (carpeta && !fs.existsSync(carpeta)) throw new ErrorUsuario('No existe la carpeta: ' + carpeta);
  buscarFotosEnPc({ carpeta }).catch(() => {});
  return { ...busquedaPc };
});
ruta('GET', '/api/lector/fotos-pc', 'config', () => ({ ...busquedaPc, segundos: busquedaPc.inicio ? Math.round((Date.now() - busquedaPc.inicio) / 1000) : 0,
  sin_foto: get(`SELECT COUNT(*) n FROM clientes WHERE foto IS NULL OR foto=''`).n }));
ruta('GET', '/api/lector/importar', 'config', () => ({ ...importacion, segundos: importacion.inicio ? Math.round((Date.now() - importacion.inicio) / 1000) : 0 }));
// Reinicia el programa (el servicio de Windows lo vuelve a arrancar solo en unos segundos)
ruta('POST', '/api/sistema/reiniciar', 'config', () => {
  if (!process.env.MAXSEL_SERVICIO) throw new ErrorUsuario('Solo funciona con el sistema instalado (servicio de Windows)');
  setTimeout(() => process.exit(0), 500);
  return { ok: true };
});
ruta('POST', '/api/lector/diagnostico', 'config', async () => {
  if (cfg('hik_modo') !== 'real') throw new ErrorUsuario('Cambia el modo a "Lector real" y guarda antes');
  return { texto: `${PRODUCTO} v${VERSION}\n${new Date().toLocaleString('es-MX')}\n` + await lector().diagnostico() };
});
ruta('POST', '/api/lector/hora', 'config', async () => { await lector().sincronizarHora(isoLocal()); return { ok: true }; });
ruta('POST', '/api/puerta/abrir', 'puerta', async ({ body, u }) => {
  if (modoReal()) await lector().abrirPuerta();
  const cid = body.cliente_id ? Number(body.cliente_id) : null;
  if (cid) {
    run('INSERT INTO visitas(cliente_id,fecha,resultado,motivo,origen) VALUES(?,?,?,?,?)', cid, ahora(), 'permitido', `Apertura manual por ${u.nombre}`, 'manual');
    avisarPantallas({ tipo: 'acceso', fecha: ahora(), resultado: 'permitido', motivo: null, origen: 'manual', ...infoPantallaCliente(cid) });
  } else {
    run('INSERT INTO visitas(cliente_id,fecha,resultado,motivo,origen) VALUES(?,?,?,?,?)', null, ahora(), 'permitido', `Apertura manual por ${u.nombre}${body.motivo ? ': ' + body.motivo : ''}`, 'manual');
  }
  return { ok: true, simulador: !modoReal() };
});

// ---------- Entrada manual (cuando el lector no reconoce la cara o no funciona) ----------
// Recepción busca al cliente por nombre, teléfono o número de socio y le da acceso.
// Si la membresía está vigente entra normal; si no, solo un usuario con permiso "puerta_forzar" lo deja pasar, con motivo.
ruta('GET', '/api/acceso/buscar', 'puerta', ({ q }) => {
  const t = (q.q || '').trim();
  if (!t) return [];
  const b = `%${t}%`, digitos = t.replace(/\D/g, '');
  const filas = all(`SELECT id, nombre, telefono, whatsapp, foto FROM clientes
    WHERE nombre LIKE ? OR CAST(id AS TEXT)=? OR (?<>'' AND (REPLACE(REPLACE(telefono,' ',''),'-','') LIKE ? OR REPLACE(REPLACE(whatsapp,' ',''),'-','') LIKE ?))
    ORDER BY CASE WHEN CAST(id AS TEXT)=? THEN 0 WHEN nombre LIKE ? THEN 1 ELSE 2 END, nombre LIMIT 8`,
    b, t, digitos, `%${digitos}%`, `%${digitos}%`, t, `${t}%`);
  return filas.map((c) => {
    const info = infoPantallaCliente(c.id);
    const ult = get(`SELECT fecha FROM visitas WHERE cliente_id=? AND resultado='permitido' ORDER BY fecha DESC LIMIT 1`, c.id);
    return { id: c.id, nombre: c.nombre, telefono: c.telefono || c.whatsapp || '', foto: info.cliente.foto, estado: info.estado.estado, plan: info.estado.plan,
      vence: info.estado.vence, mensaje: info.mensaje, saldo: info.saldo, puede_entrar: puedeEntrar(info.estado), ultima_visita: ult?.fecha || null };
  });
});
ruta('POST', '/api/acceso/manual', 'puerta', async ({ body, u }) => {
  const cid = Number(body.cliente_id);
  const info = cid ? infoPantallaCliente(cid) : null;
  if (!info) throw new ErrorUsuario('Cliente no encontrado', 404);
  const motivo = String(body.motivo || '').trim().slice(0, 200);
  const vigente = puedeEntrar(info.estado);
  if (!vigente) {
    if (!u.perm.has('puerta_forzar')) throw new ErrorUsuario(`${textoEstado(info.estado)}. Solo un gerente puede dejarlo pasar sin membresía vigente.`, 403);
    if (!motivo) throw new ErrorUsuario('Escribe el motivo para dejarlo pasar sin membresía vigente');
  }
  const abrir = body.abrir !== false;
  if (abrir && modoReal()) await lector().abrirPuerta();
  const texto = vigente
    ? `Entrada manual por ${u.nombre}${motivo ? ': ' + motivo : ' (no lo reconoció el lector)'}`
    : `PASÓ SIN MEMBRESÍA VIGENTE · autorizó ${u.nombre}: ${motivo}`;
  const fecha = ahora();
  run('INSERT INTO visitas(cliente_id,fecha,resultado,motivo,origen) VALUES(?,?,?,?,?)', cid, fecha, 'permitido', texto, 'manual');
  avisarPantallas({ tipo: 'acceso', fecha, resultado: 'permitido', motivo: null, alerta: vigente ? null : 'Acceso autorizado por recepción', origen: 'manual', ...infoPantallaCliente(cid) });
  return { ok: true, nombre: info.cliente.nombre, vigente, puerta: abrir ? (modoReal() ? 'abierta' : 'simulada') : 'no' };
});

// ---------- Clientes ----------
const CAMPOS_CLIENTE = ['nombre', 'direccion', 'colonia', 'cp', 'telefono', 'whatsapp', 'correo', 'escuela', 'notas'];
const urlDoc = (c, tipo) => (c[`doc_${tipo}`] ? `/evidencias/${c.id}/${tipo}?v=${encodeURIComponent(c[`doc_${tipo}`])}` : null);
function filaCliente(c) {
  return { ...c, ...estadoCliente(c.id), foto_url: c.foto ? `/fotos/${c.id}?v=${encodeURIComponent(c.foto)}` : null,
    doc_estudiante_url: urlDoc(c, 'estudiante'), doc_vecino_url: urlDoc(c, 'vecino'),
    pareja_nombre: c.pareja_id ? get('SELECT nombre FROM clientes WHERE id=?', c.pareja_id)?.nombre || null : null,
    saldo: r2(get('SELECT COALESCE(SUM(credito_pendiente),0) s FROM ventas WHERE cliente_id=? AND cancelada=0', c.id).s) };
}
ruta('GET', '/api/clientes', 'sesion', ({ q }) => {
  const b = `%${(q.q || '').trim()}%`;
  const filas = all(`SELECT * FROM clientes WHERE nombre LIKE ? OR telefono LIKE ? OR whatsapp LIKE ? OR CAST(id AS TEXT)=? ORDER BY nombre LIMIT ?`,
    b, b, b, (q.q || '').trim(), Number(q.limite) || 300);
  let lista = filas.map(filaCliente);
  if (q.estado) lista = lista.filter((c) => (q.estado === 'activo' ? ['activo', 'por_vencer'].includes(c.estado) : c.estado === q.estado));
  return lista;
});
ruta('GET', '/api/clientes/:id', 'sesion', ({ p }) => {
  const c = get('SELECT * FROM clientes WHERE id=?', Number(p.id));
  if (!c) throw new ErrorUsuario('Cliente no encontrado', 404);
  return {
    ...filaCliente(c),
    membresias: all(`SELECT m.*, p.nombre plan, pr.nombre promo, pc.nombre pareja FROM membresias m JOIN planes p ON p.id=m.plan_id
      LEFT JOIN promociones pr ON pr.id=m.promo_id LEFT JOIN clientes pc ON pc.id=m.pareja_cliente_id
      WHERE m.cliente_id=? ORDER BY m.fin DESC`, c.id),
    visitas: all('SELECT * FROM visitas WHERE cliente_id=? ORDER BY fecha DESC LIMIT 30', c.id),
    deudas: infoPantallaCliente(c.id).deudas,
    abonos: all('SELECT a.*, u.nombre cajero FROM abonos a LEFT JOIN usuarios u ON u.id=a.usuario_id WHERE cliente_id=? ORDER BY fecha DESC LIMIT 20', c.id),
  };
});

// Foto de credencial / comprobante como evidencia (estudiante o vecino de la zona)
// Logo del gimnasio: se guarda en datos/ y se muestra en la pantalla del cliente, el ticket y el celular
ruta('POST', '/api/config/logo', 'config', ({ body }) => {
  const { buf, ext } = imagenDe(body.imagen, 'El logo');
  const nombre = 'logo_gym.' + ext;
  for (const e of ['jpg', 'png']) { const f = path.join(DATA_DIR, 'logo_gym.' + e); if (fs.existsSync(f)) fs.unlinkSync(f); }
  fs.writeFileSync(path.join(DATA_DIR, nombre), buf);
  setCfg('gym_logo', nombre + '?v=' + Date.now());
  avisarPantallas({ tipo: 'config' });
  return { ok: true, logo: '/logo-gym?v=' + Date.now() };
});
ruta('DELETE', '/api/config/logo', 'config', () => {
  for (const e of ['jpg', 'png']) { const f = path.join(DATA_DIR, 'logo_gym.' + e); if (fs.existsSync(f)) fs.unlinkSync(f); }
  setCfg('gym_logo', '');
  avisarPantallas({ tipo: 'config' });
  return { ok: true };
});

function imagenDe(dataUrl, que = 'La foto de la credencial') {
  const buf = Buffer.from(String(dataUrl || '').replace(/^data:image\/\w+;base64,/, ''), 'base64');
  const jpg = buf.slice(0, 2).toString('hex') === 'ffd8', png = buf.slice(0, 4).toString('hex') === '89504e47';
  if (!jpg && !png) throw new ErrorUsuario(que + ' no es una imagen válida (usa JPG o PNG)');
  if (buf.length > 4 * 1024 * 1024) throw new ErrorUsuario(que + ' es demasiado grande (máximo 4 MB)');
  return { buf, ext: jpg ? 'jpg' : 'png' };
}
function guardarDoc(id, tipo, dataUrl) {
  const { buf, ext } = imagenDe(dataUrl);
  const ant = get(`SELECT doc_${tipo} f FROM clientes WHERE id=?`, id)?.f;
  const nombre = `${id}-${tipo}-${Date.now()}.${ext}`;
  fs.writeFileSync(path.join(DOCS_DIR, nombre), buf);
  if (ant) fs.rmSync(path.join(DOCS_DIR, ant), { force: true });
  run(`UPDATE clientes SET doc_${tipo}=?, doc_fecha=? WHERE id=?`, nombre, ahora(), id);
}
// Revisa que estudiante / vecino traigan su evidencia
function validarEvidencias(d, actual = {}) {
  if (d.estudiante && !d.doc_estudiante && !actual.doc_estudiante) throw new ErrorUsuario('Para registrarlo como ESTUDIANTE toma la foto de su credencial escolar vigente');
  if (d.vecino && !d.doc_vecino && !actual.doc_vecino) throw new ErrorUsuario('Para registrarlo como VECINO DE LA ZONA toma la foto de su INE o comprobante de domicilio');
  if (d.vecino && !txt(d.colonia) && !txt(d.cp)) throw new ErrorUsuario('Para vecino de la zona captura la colonia o el código postal');
}
// Número de la persona dentro del lector: el número de cliente, o uno libre si ya está ocupado
function asignarEmpleado(id) {
  let emp = String(id);
  if (get('SELECT id FROM clientes WHERE hik_empleado=? AND id<>?', emp, id)) {
    let n = 1; while (get('SELECT id FROM clientes WHERE hik_empleado=?', `MX${id}${n > 1 ? '-' + n : ''}`)) n++;
    emp = `MX${id}${n > 1 ? '-' + n : ''}`;
  }
  run('UPDATE clientes SET hik_empleado=? WHERE id=?', emp, id);
}
function insertarCliente(d) {
  const r = run(`INSERT INTO clientes(${CAMPOS_CLIENTE.join(',')},acepta_publicidad,estudiante,vecino,creado) VALUES(${CAMPOS_CLIENTE.map(() => '?').join(',')},?,?,?,?)`,
    ...CAMPOS_CLIENTE.map((k) => txt(d[k])), d.acepta_publicidad ? 1 : 0, d.estudiante ? 1 : 0, d.vecino ? 1 : 0, hoy());
  asignarEmpleado(r.id);
  if (d.estudiante && d.doc_estudiante) guardarDoc(r.id, 'estudiante', d.doc_estudiante);
  if (d.vecino && d.doc_vecino) guardarDoc(r.id, 'vecino', d.doc_vecino);
  return r.id;
}
ruta('POST', '/api/clientes', 'clientes', async ({ body }) => {
  if (!txt(body.nombre)) throw new ErrorUsuario('El nombre completo es obligatorio');
  validarEvidencias(body);
  const p2 = body.pareja;
  if (p2) {
    if (!txt(p2.nombre)) throw new ErrorUsuario('Escribe el nombre completo de la segunda persona (pareja)');
    validarEvidencias(p2);
  }
  revisarCupoClientes(p2 ? 2 : 1);
  const ids = tx(() => {
    const id1 = insertarCliente(body);
    let id2 = null;
    if (p2) {
      id2 = insertarCliente(p2);
      run('UPDATE clientes SET pareja_id=? WHERE id=?', id2, id1);
      run('UPDATE clientes SET pareja_id=? WHERE id=?', id1, id2);
    }
    return { id: id1, pareja_id: id2 };
  });
  sincronizarEnSegundoPlano(ids.id);
  if (ids.pareja_id) sincronizarEnSegundoPlano(ids.pareja_id);
  return ids;
});
ruta('PUT', '/api/clientes/:id', 'clientes_editar', async ({ body, p, u }) => {
  const id = Number(p.id);
  const actual = get('SELECT * FROM clientes WHERE id=?', id);
  if (!actual) throw new ErrorUsuario('Cliente no encontrado', 404);
  if (!txt(body.nombre)) throw new ErrorUsuario('El nombre completo es obligatorio');
  validarEvidencias(body, actual);
  run(`UPDATE clientes SET ${CAMPOS_CLIENTE.map((k) => k + '=?').join(',')}, acepta_publicidad=?, estudiante=?, vecino=? WHERE id=?`,
    ...CAMPOS_CLIENTE.map((k) => txt(body[k])), body.acepta_publicidad ? 1 : 0, body.estudiante ? 1 : 0, body.vecino ? 1 : 0, id);
  if (body.doc_estudiante) guardarDoc(id, 'estudiante', body.doc_estudiante);
  if (body.doc_vecino) guardarDoc(id, 'vecino', body.doc_vecino);
  if (body.pareja_id !== undefined) {
    const nueva = Number(body.pareja_id) || null;
    if (nueva === id) throw new ErrorUsuario('La pareja debe ser otra persona');
    tx(() => {
      run('UPDATE clientes SET pareja_id=NULL WHERE pareja_id=? OR id=?', id, id);
      if (nueva) {
        run('UPDATE clientes SET pareja_id=NULL WHERE pareja_id=?', nueva);
        run('UPDATE clientes SET pareja_id=? WHERE id=?', nueva, id);
        run('UPDATE clientes SET pareja_id=? WHERE id=?', id, nueva);
      }
    });
  }
  if (body.bloqueado !== undefined && !!body.bloqueado !== !!actual.bloqueado) {
    if (!u.perm.has('clientes_bloquear')) throw new ErrorUsuario('No tienes permiso para bloquear clientes', 403);
    run('UPDATE clientes SET bloqueado=? WHERE id=?', body.bloqueado ? 1 : 0, id);
  }
  return sincronizarCliente(id);
});
ruta('POST', '/api/clientes/:id/evidencia', 'clientes_editar', ({ body, p }) => {
  const id = Number(p.id);
  if (!['estudiante', 'vecino'].includes(body.tipo)) throw new ErrorUsuario('Tipo de evidencia inválido');
  if (!get('SELECT id FROM clientes WHERE id=?', id)) throw new ErrorUsuario('Cliente no encontrado', 404);
  guardarDoc(id, body.tipo, body.imagen);
  run(`UPDATE clientes SET ${body.tipo}=1 WHERE id=?`, id);
  return filaCliente(get('SELECT * FROM clientes WHERE id=?', id));
});
ruta('DELETE', '/api/clientes/:id', 'clientes_borrar', async ({ p }) => {
  const id = Number(p.id);
  const c = get('SELECT * FROM clientes WHERE id=?', id);
  if (!c) throw new ErrorUsuario('Cliente no encontrado', 404);
  if (get('SELECT id FROM ventas WHERE cliente_id=? AND credito_pendiente>0 AND cancelada=0', id)) throw new ErrorUsuario('No se puede borrar: el cliente tiene adeudos');
  if (modoReal()) { try { await lector().borrarUsuario(c.hik_empleado); } catch (e) { throw new ErrorUsuario('No se pudo borrar del lector: ' + e.message); } }
  if (c.foto) fs.rmSync(path.join(FOTOS_DIR, c.foto), { force: true });
  for (const f of [c.doc_estudiante, c.doc_vecino]) if (f) fs.rmSync(path.join(DOCS_DIR, f), { force: true });
  tx(() => {
    run('UPDATE clientes SET pareja_id=NULL WHERE pareja_id=?', id);
    run('DELETE FROM clientes WHERE id=?', id);
  });
  return { ok: true };
});
// Foto de rostro: llega como imagen JPG en base64 (tomada con cámara, archivo o el lector)
async function guardarFoto(id, jpg) {
  if (jpg.slice(0, 2).toString('hex') !== 'ffd8') throw new ErrorUsuario('La foto debe ser JPG');
  if (jpg.length > 200 * 1024) throw new ErrorUsuario('La foto pesa más de 200 KB, el lector no la acepta');
  const ant = get('SELECT foto FROM clientes WHERE id=?', id);
  if (!ant) throw new ErrorUsuario('Cliente no encontrado', 404);
  const nombre = `${id}-${Date.now()}.jpg`;
  fs.writeFileSync(path.join(FOTOS_DIR, nombre), jpg);
  if (ant.foto) fs.rmSync(path.join(FOTOS_DIR, ant.foto), { force: true });
  run('UPDATE clientes SET foto=?, cara_sync=0 WHERE id=?', nombre, id);
  const r = await sincronizarCliente(id);
  return { ...r, foto_url: `/fotos/${id}?v=${nombre}` };
}
ruta('POST', '/api/clientes/:id/foto', 'clientes', ({ body, p }) => {
  const b64 = String(body.imagen || '').replace(/^data:image\/\w+;base64,/, '');
  return guardarFoto(Number(p.id), Buffer.from(b64, 'base64'));
});
// El lector toma la foto y se regresa a la pantalla, que la ajusta al tamaño correcto y la guarda con /foto
ruta('POST', '/api/clientes/:id/capturar', 'clientes', async () => {
  if (!modoReal()) throw new ErrorUsuario('Captura desde el lector solo funciona con el lector real conectado. Usa la cámara de la computadora o sube una foto.');
  let jpg;
  try { jpg = await lector().capturarRostro(); }
  catch (e) {
    if (!e.sinConexion) throw e;
    // 1.12: sin conexión → se busca el puerto correcto del lector y se intenta una vez más
    const r = await buscarPuertoLector().catch(() => null);
    if (!r) throw new ErrorUsuario(e.message + '. Revisa en Configuración → Lector facial la IP y el puerto (normalmente 80) y presiona "Probar conexión". Mientras, usa "Tomar foto con cámara" o "Subir foto".');
    jpg = await lector().capturarRostro();
  }
  return { imagen: 'data:image/jpeg;base64,' + jpg.toString('base64') };
});
// ---------- 1.12.4: tomar la foto del rostro con el CELULAR (sin webcam) ----------
// La ficha del cliente muestra un código QR; el celular (en el mismo Wi-Fi) abre una página sencilla,
// toma la foto con su cámara y la manda. El enlace sirve 15 minutos y solo para ese cliente.
const fotosCelular = new Map(); // token → { id, vence, listo }
function ipsRed() {
  const ips = Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => i.address);
  const pref = cfg('servidor_ip');
  return [...new Set([pref, ...ips.filter((x) => /^(192\.168|10\.|172\.(1[6-9]|2\d|3[01]))/.test(x)), ...ips].filter(Boolean))];
}
ruta('POST', '/api/clientes/:id/foto-celular', 'clientes', ({ p }) => {
  const id = Number(p.id);
  if (!get('SELECT id FROM clientes WHERE id=?', id)) throw new ErrorUsuario('Cliente no encontrado', 404);
  for (const [t, v] of fotosCelular) if (v.vence < Date.now()) fotosCelular.delete(t);
  const token = crypto.randomBytes(12).toString('hex');
  fotosCelular.set(token, { id, vence: Date.now() + 15 * 60 * 1000, listo: false });
  const ips = ipsRed();
  if (!ips.length) throw new ErrorUsuario('Esta computadora no está conectada a una red (Wi-Fi o cable)');
  const urls = ips.map((ip) => `http://${ip}:${PUERTO}/celfoto/${token}`);
  return { token, url: urls[0], otras: urls.slice(1), qr: qrSvg(urls[0], 5) };
});
ruta('GET', '/api/foto-celular/:token', 'clientes', ({ p }) => {
  const v = fotosCelular.get(p.token);
  return { listo: !!v?.listo, vencido: !v || v.vence < Date.now() };
});
const PAGINA_CELFOTO = (nombre) => `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Foto del rostro</title><style>body{font-family:system-ui,sans-serif;margin:0;background:#111;color:#fff;text-align:center;padding:18px}
h1{font-size:22px;margin:6px 0}p{color:#ccc}.btn{display:block;width:100%;box-sizing:border-box;padding:18px;border-radius:14px;border:0;font-size:20px;font-weight:700;margin:12px 0;background:#e8590c;color:#fff}
.sec{background:#333}[hidden]{display:none!important}img{max-width:100%;max-height:55vh;border-radius:12px;margin-top:10px}#est{min-height:24px;font-size:18px}</style></head><body>
<h1>📸 Foto de ${nombre}</h1><p>De frente, con buena luz, sin gorra ni lentes oscuros. La cara completa.</p>
<label class="btn" id="lb">📷 Tomar foto<input id="f" type="file" accept="image/*" capture="user" hidden></label>
<img id="pv" hidden alt=""><p id="est"></p><button class="btn" id="ok" hidden>💾 Guardar foto</button><button class="btn sec" id="otra" hidden>🔁 Tomar otra</button>
<script>
let dato=null;const $=(i)=>document.getElementById(i);
$('f').onchange=async(e)=>{const a=e.target.files[0];if(!a)return;$('est').textContent='Preparando…';
 const img=await new Promise((ok,mal)=>{const i=new Image();i.onload=()=>ok(i);i.onerror=mal;i.src=URL.createObjectURL(a);});
 // recorte vertical 3:4 al centro y máximo 640 px, JPG de menos de 190 KB (lo que acepta el lector)
 const w0=img.naturalWidth,h0=img.naturalHeight;let w=Math.min(w0,h0*0.75),h=w/0.75;if(h>h0){h=h0;w=h*0.75;}
 const k=Math.min(1,640/h),c=document.createElement('canvas');c.width=Math.round(w*k);c.height=Math.round(h*k);
 c.getContext('2d').drawImage(img,(w0-w)/2,(h0-h)/2,w,h,0,0,c.width,c.height);
 let q=0.9;dato=c.toDataURL('image/jpeg',q);while(dato.length*0.75>190*1024&&q>0.35){q-=0.1;dato=c.toDataURL('image/jpeg',q);}
 $('pv').src=dato;$('pv').hidden=false;$('ok').hidden=false;$('otra').hidden=false;$('lb').style.display='none';$('est').textContent='¿Se ve bien?';};
$('otra').onclick=()=>{$('f').value='';$('f').click();};
$('ok').onclick=async()=>{$('ok').disabled=true;$('est').textContent='Guardando…';
 try{const r=await fetch(location.pathname,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({imagen:dato})});const j=await r.json();
  if(!r.ok)throw new Error(j.error||'Error');document.body.innerHTML='<h1 style="margin-top:30vh">✅ Foto guardada</h1><p>'+(j.ok===false?'Se guardó, pero el lector respondió: '+j.error:'Ya quedó registrada. Puedes cerrar esta página.')+'</p>';}
 catch(e){$('ok').disabled=false;$('est').textContent='❌ '+e.message;}};
</script></body></html>`;
async function paginaCelFoto(req, res, ruta) {
  const token = ruta.split('/')[2] || '';
  const v = fotosCelular.get(token);
  const html = (code, t) => { res.writeHead(code, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(t); };
  if (!v || v.vence < Date.now()) return html(410, '<meta name="viewport" content="width=device-width,initial-scale=1"><h2 style="font-family:sans-serif;text-align:center;margin-top:30vh">Este enlace ya venció.<br>Genera otro código en la computadora.</h2>');
  const c = get('SELECT nombre FROM clientes WHERE id=?', v.id);
  if (req.method === 'GET') return html(200, PAGINA_CELFOTO(String(c?.nombre || '').replace(/[<>&"]/g, '')));
  if (req.method === 'POST') {
    try {
      const body = JSON.parse((await leerCuerpo(req, 2 * 1024 * 1024)).toString() || '{}');
      const b64 = String(body.imagen || '').replace(/^data:image\/\w+;base64,/, '');
      const r = await guardarFoto(v.id, Buffer.from(b64, 'base64'));
      v.listo = true; v.vence = Math.min(v.vence, Date.now() + 60000);
      res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify(r));
    } catch (e) { res.writeHead(400, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ error: e.message })); }
  }
  html(405, '');
}
ruta('POST', '/api/clientes/:id/sincronizar', 'clientes', async ({ p }) => {
  run('UPDATE clientes SET cara_sync=0 WHERE id=?', Number(p.id));
  return sincronizarCliente(Number(p.id));
});
ruta('POST', '/api/clientes/:id/simular-entrada', 'sesion', ({ p }) => {
  if (modoReal()) throw new ErrorUsuario('El simulador solo está disponible en modo simulador');
  return procesarAcceso({ clienteId: Number(p.id), origen: 'simulador' });
});
ruta('POST', '/api/pantalla/prueba', 'config', ({ body }) => {
  const visitas = [1, 2, 4, 6, 9, 12].map((d) => ({ fecha: sumarDias(hoy(), -d) + ' 07:' + String(10 + d).padStart(2, '0') + ':00' }));
  const ok = body.resultado !== 'denegado';
  avisarPantallas({ tipo: 'acceso', prueba: true, fecha: ahora(), resultado: ok ? 'permitido' : 'denegado', motivo: ok ? null : 'Membresía vencida desde ' + sumarDias(hoy(), -3), origen: 'prueba',
    cliente: { id: 0, nombre: 'Cliente de prueba', foto: null }, estado: ok ? { estado: 'activo', vence: sumarDias(hoy(), 20), plan: 'Mensual', dias_restantes: 20 } : { estado: 'vencido', vence: sumarDias(hoy(), -3) },
    mensaje: '', visitas, deudas: [{ fecha: sumarDias(hoy(), -2) + ' 18:42:00', productos: 'Bebida isotónica 600 ml', pendiente: 30 }], saldo: 30 });
  return { ok: true };
});
ruta('POST', '/api/simular-desconocido', 'sesion', () => { procesarAcceso({ clienteId: null, origen: 'simulador' }); return { ok: true }; });

// ---------- Planes y promociones ----------
ruta('GET', '/api/planes', 'sesion', () => all('SELECT * FROM planes ORDER BY activo DESC, orden, id'));
ruta('POST', '/api/planes', 'planes', ({ body }) => {
  if (!txt(body.nombre) || !(num(body.precio) >= 0)) throw new ErrorUsuario('Nombre y precio son obligatorios');
  if (!(Number(body.dias) > 0 || Number(body.meses) > 0)) throw new ErrorUsuario('Indica la duración en días o en meses');
  return run('INSERT INTO planes(nombre,dias,meses,precio,orden) VALUES(?,?,?,?,?)', txt(body.nombre), Number(body.dias) || 0, Number(body.meses) || 0, num(body.precio), Number(body.orden) || 99);
});
ruta('PUT', '/api/planes/:id', 'planes', ({ body, p }) => {
  run('UPDATE planes SET nombre=?, dias=?, meses=?, precio=?, activo=? WHERE id=?', txt(body.nombre), Number(body.dias) || 0, Number(body.meses) || 0, num(body.precio), body.activo ? 1 : 0, Number(p.id));
  return { ok: true };
});
ruta('GET', '/api/promociones', 'sesion', () => all('SELECT pr.*, p.nombre plan FROM promociones pr LEFT JOIN planes p ON p.id=pr.plan_id ORDER BY pr.activo DESC, pr.nombre'));
function datosPromo(body) {
  if (!txt(body.nombre)) throw new ErrorUsuario('Ponle nombre a la promoción');
  if (!['estudiante', 'pareja', 'vecino', 'general'].includes(body.tipo)) throw new ErrorUsuario('Tipo inválido');
  if (!['porcentaje', 'monto', 'precio_fijo'].includes(body.descuento_tipo)) throw new ErrorUsuario('Tipo de descuento inválido');
  if (body.descuento_tipo === 'porcentaje' && (num(body.valor) <= 0 || num(body.valor) > 100)) throw new ErrorUsuario('El porcentaje debe ser entre 1 y 100');
  return [txt(body.nombre), body.tipo, body.descuento_tipo, num(body.valor), Number(body.plan_id) || null, txt(body.zonas), body.activo === false ? 0 : 1];
}
ruta('POST', '/api/promociones', 'planes', ({ body }) => run('INSERT INTO promociones(nombre,tipo,descuento_tipo,valor,plan_id,zonas,activo) VALUES(?,?,?,?,?,?,?)', ...datosPromo(body)));
ruta('PUT', '/api/promociones/:id', 'planes', ({ body, p }) => {
  run('UPDATE promociones SET nombre=?,tipo=?,descuento_tipo=?,valor=?,plan_id=?,zonas=?,activo=? WHERE id=?', ...datosPromo(body), Number(p.id));
  return { ok: true };
});
ruta('POST', '/api/membresias/cotizar', 'sesion', ({ body }) => cotizarMembresia(body));

// ---------- Productos ----------
ruta('GET', '/api/productos', 'sesion', ({ q }) => {
  const b = `%${(q.q || '').trim()}%`;
  return all(`SELECT * FROM productos WHERE (nombre LIKE ? OR codigo LIKE ?) ${q.todos ? '' : 'AND activo=1'} ORDER BY nombre LIMIT 500`, b, b);
});
ruta('GET', '/api/productos/codigo/:codigo', 'sesion', ({ p }) => {
  const r = get('SELECT * FROM productos WHERE codigo=? AND activo=1', decodeURIComponent(p.codigo));
  if (!r) throw new ErrorUsuario('No existe un producto con ese código', 404);
  return r;
});
function datosProducto(body) {
  if (!txt(body.nombre)) throw new ErrorUsuario('El nombre del producto es obligatorio');
  if (!(num(body.precio) > 0)) throw new ErrorUsuario('El precio de venta debe ser mayor a 0');
  return [txt(body.codigo) || null, txt(body.nombre), num(body.costo), num(body.precio), Number(body.existencia) || 0, Number(body.minimo) || 0, nombreDepto(body.area)];
}
// Departamento de la tienda: se crea solo si no existe
function nombreDepto(x) {
  const n = String(x ?? '').trim().replace(/\s+/g, ' ').slice(0, 60);
  if (!n || /^sin departamento$/i.test(n)) return null;
  const ya = get('SELECT nombre FROM departamentos WHERE lower(nombre)=lower(?)', n);
  if (ya) return ya.nombre;
  run('INSERT INTO departamentos(nombre, creado) VALUES(?,?)', n, ahora());
  return n;
}
ruta('POST', '/api/productos', 'productos_editar', ({ body }) => {
  const d = datosProducto(body);
  if (d[0] && get('SELECT id FROM productos WHERE codigo=?', d[0])) throw new ErrorUsuario('Ya existe un producto con ese código de barras');
  return run('INSERT INTO productos(codigo,nombre,costo,precio,existencia,minimo,area) VALUES(?,?,?,?,?,?,?)', ...d);
});
ruta('PUT', '/api/productos/:id', 'productos_editar', ({ body, p }) => {
  const d = datosProducto(body);
  if (d[0] && get('SELECT id FROM productos WHERE codigo=? AND id<>?', d[0], Number(p.id))) throw new ErrorUsuario('Ya existe otro producto con ese código de barras');
  run('UPDATE productos SET codigo=?,nombre=?,costo=?,precio=?,existencia=?,minimo=?,area=?,activo=? WHERE id=?', ...d, body.activo === false ? 0 : 1, Number(p.id));
  return { ok: true };
});
ruta('POST', '/api/productos/:id/entrada', 'productos_editar', ({ body, p }) => {
  const c = Number(body.cantidad);
  if (!c) throw new ErrorUsuario('Indica la cantidad');
  run('UPDATE productos SET existencia=existencia+?, costo=CASE WHEN ?>0 THEN ? ELSE costo END WHERE id=?', c, num(body.costo), num(body.costo), Number(p.id));
  return { ok: true };
});

// ---------- Departamentos de la tienda ----------
ruta('GET', '/api/departamentos', 'sesion', () => {
  const ps = all('SELECT area, COUNT(*) n, COALESCE(SUM(costo*MAX(existencia,0)),0) costo, COALESCE(SUM(precio*MAX(existencia,0)),0) venta FROM productos WHERE activo=1 GROUP BY area');
  const m = Object.fromEntries(ps.map((x) => [x.area || '', x]));
  return {
    lista: all('SELECT nombre FROM departamentos ORDER BY nombre COLLATE NOCASE').map((d) => ({ nombre: d.nombre, productos: m[d.nombre]?.n || 0, costo: r2(m[d.nombre]?.costo), venta: r2(m[d.nombre]?.venta) })),
    sin: { productos: m['']?.n || 0, costo: r2(m['']?.costo), venta: r2(m['']?.venta) },
  };
});
ruta('POST', '/api/departamentos', 'productos_editar', ({ body }) => {
  const n = nombreDepto(body.nombre); if (!n) throw new ErrorUsuario('Escribe el nombre del departamento');
  return { ok: true, nombre: n };
});
ruta('PUT', '/api/departamentos', 'productos_editar', ({ body }) => {
  const de = txt(body.de), a = String(body.a ?? '').trim().replace(/\s+/g, ' ').slice(0, 60);
  if (!de || !a) throw new ErrorUsuario('Escribe el nombre nuevo');
  tx(() => {
    const otro = get('SELECT nombre FROM departamentos WHERE lower(nombre)=lower(?) AND nombre<>?', a, de);
    if (otro) run('DELETE FROM departamentos WHERE nombre=?', de); else run('UPDATE departamentos SET nombre=? WHERE nombre=?', a, de);
    run('UPDATE productos SET area=? WHERE area=?', otro ? otro.nombre : a, de);
  });
  return { ok: true };
});
ruta('DELETE', '/api/departamentos', 'productos_editar', ({ q }) => {
  const n = txt(q.nombre); if (!n) throw new ErrorUsuario('Falta el departamento');
  return tx(() => { const c = run('UPDATE productos SET area=NULL WHERE area=?', n).changes; run('DELETE FROM departamentos WHERE nombre=?', n); return { ok: true, productos: c }; });
});

// ---------- Unidades de negocio: membresías y cada departamento de la tienda ----------
function unidadesNegocio(d, h) {
  const l = all(`SELECT CASE WHEN i.tipo='membresia' THEN 'Membresías' ELSE COALESCE(NULLIF(p.area,''),'Tienda (sin departamento)') END unidad,
      SUM(i.importe) total, SUM(CASE WHEN i.tipo='producto' THEN i.importe - i.costo*i.cantidad ELSE i.importe END) utilidad, SUM(i.cantidad) cantidad
    FROM venta_items i JOIN ventas v ON v.id=i.venta_id LEFT JOIN productos p ON p.id=i.producto_id
    WHERE v.cancelada=0 AND substr(v.fecha,1,10) BETWEEN ? AND ? GROUP BY 1 ORDER BY total DESC`, d, h).map((x) => ({ unidad: x.unidad, total: r2(x.total), utilidad: r2(x.utilidad), cantidad: x.cantidad }));
  const tot = r2(l.reduce((a, x) => a + x.total, 0));
  return l.map((x) => ({ ...x, pct: tot ? Math.round((x.total / tot) * 1000) / 10 : 0 }));
}
function ventasDepto(d, h) {
  return all(`SELECT COALESCE(NULLIF(p.area,''),'Sin departamento') departamento, COUNT(DISTINCT i.producto_id) productos, SUM(i.cantidad) cantidad, SUM(i.importe) importe, SUM(i.costo*i.cantidad) costo, SUM(i.importe - i.costo*i.cantidad) utilidad
    FROM venta_items i JOIN ventas v ON v.id=i.venta_id LEFT JOIN productos p ON p.id=i.producto_id
    WHERE i.tipo='producto' AND v.cancelada=0 AND substr(v.fecha,1,10) BETWEEN ? AND ? GROUP BY 1 ORDER BY importe DESC`, d, h);
}
// Últimos n meses terminando en el mes de "hasta": total por unidad de negocio en cada mes
function unidadesMeses(hasta, n = 6) {
  const [y, m] = hasta.slice(0, 7).split('-').map(Number), meses = [];
  for (let i = n - 1; i >= 0; i--) {
    const f = new Date(y, m - 1 - i, 1), k = `${f.getFullYear()}-${String(f.getMonth() + 1).padStart(2, '0')}`;
    const ult = new Date(f.getFullYear(), f.getMonth() + 1, 0).getDate();
    const u = unidadesNegocio(k + '-01', `${k}-${String(ult).padStart(2, '0')}`);
    meses.push({ mes: k, total: r2(u.reduce((a, x) => a + x.total, 0)), unidades: Object.fromEntries(u.map((x) => [x.unidad, x.total])) });
  }
  const nombres = [...new Set(meses.flatMap((x) => Object.keys(x.unidades)))];
  return { meses, unidades: nombres };
}

// ---------- Empleados: sueldos, nómina, vacaciones y descansos ----------
const TIPOS_DIA = { vacaciones: 'Vacaciones', descanso: 'Descanso', falta: 'Falta', permiso: 'Permiso', incapacidad: 'Incapacidad' };
const PERIODOS_PAGO = { semanal: 'Semanal', quincenal: 'Quincenal', mensual: 'Mensual' };
const diasRango = (a, b) => Math.round((new Date(b + 'T12:00:00') - new Date(a + 'T12:00:00')) / 86400000) + 1;
// Días de cada tipo que caen dentro del periodo [d, h]
function diasEmpleados(d, h) {
  const l = all(`SELECT e.*, x.nombre empleado FROM empleado_dias e JOIN empleados x ON x.id=e.empleado_id WHERE e.desde<=? AND e.hasta>=? ORDER BY e.desde`, h, d);
  return l.map((e) => ({ ...e, en_periodo: diasRango(e.desde < d ? d : e.desde, e.hasta > h ? h : e.hasta) }));
}
function resumenNomina(d, h) {
  const emps = all('SELECT * FROM empleados ORDER BY activo DESC, nombre COLLATE NOCASE');
  const pagos = all(`SELECT g.*, u.nombre usuario FROM gastos g LEFT JOIN usuarios u ON u.id=g.usuario_id WHERE g.empleado_id IS NOT NULL AND substr(g.fecha,1,10) BETWEEN ? AND ? ORDER BY g.fecha`, d, h).map(sinFirmas);
  const dias = diasEmpleados(d, h), anio = h.slice(0, 4);
  const lista = emps.map((x) => {
    const mis = dias.filter((e) => e.empleado_id === x.id), cuenta = (t) => mis.filter((e) => e.tipo === t).reduce((a, e) => a + e.en_periodo, 0);
    const vacAnio = get(`SELECT COALESCE(SUM(dias),0) s FROM empleado_dias WHERE empleado_id=? AND tipo='vacaciones' AND substr(desde,1,4)=?`, x.id, anio).s;
    return { id: x.id, nombre: x.nombre, puesto: x.puesto, sueldo: x.sueldo, periodo: x.periodo, descanso: x.descanso, activo: x.activo, telefono: x.telefono, ingreso: x.ingreso, vac_dias: x.vac_dias, notas: x.notas,
      pagado: r2(pagos.filter((g) => g.empleado_id === x.id).reduce((a, g) => a + g.monto, 0)), pagos_n: pagos.filter((g) => g.empleado_id === x.id).length,
      vacaciones: cuenta('vacaciones'), descansos: cuenta('descanso'), faltas: cuenta('falta'), permisos: cuenta('permiso'), incapacidades: cuenta('incapacidad'),
      vac_usadas: vacAnio, vac_restan: r2((x.vac_dias || 0) - vacAnio) };
  });
  const mensual = (e) => (e.periodo === 'semanal' ? e.sueldo * 52 / 12 : e.periodo === 'quincenal' ? e.sueldo * 2 : e.sueldo);
  return {
    empleados: lista, pagos, dias, total: r2(pagos.reduce((a, g) => a + g.monto, 0)),
    nomina_mensual: r2(emps.filter((e) => e.activo).reduce((a, e) => a + mensual(e), 0)), activos: emps.filter((e) => e.activo).length,
  };
}
ruta('GET', '/api/empleados', 'empleados', ({ q }) => {
  const per = /^\d{4}-\d{2}$/.test(q.mes || '') ? q.mes : periodoDe();
  const [y, m] = per.split('-').map(Number), ult = new Date(y, m, 0).getDate();
  return { mes: per, tipos: TIPOS_DIA, periodos: PERIODOS_PAGO, ...resumenNomina(per + '-01', `${per}-${String(ult).padStart(2, '0')}`) };
});
function datosEmpleado(b) {
  if (!txt(b.nombre)) throw new ErrorUsuario('Escribe el nombre del empleado');
  return [txt(b.nombre), txt(b.puesto), txt(b.telefono), num(b.sueldo), PERIODOS_PAGO[b.periodo] ? b.periodo : 'quincenal', txt(b.descanso), /^\d{4}-\d{2}-\d{2}$/.test(b.ingreso || '') ? b.ingreso : null,
    b.vac_dias === '' || b.vac_dias === undefined ? 12 : num(b.vac_dias), txt(b.notas)];
}
ruta('POST', '/api/empleados', 'empleados', ({ body }) => run('INSERT INTO empleados(nombre,puesto,telefono,sueldo,periodo,descanso,ingreso,vac_dias,notas,creado) VALUES(?,?,?,?,?,?,?,?,?,?)', ...datosEmpleado(body), ahora()));
ruta('PUT', '/api/empleados/:id', 'empleados', ({ body, p }) => {
  run('UPDATE empleados SET nombre=?,puesto=?,telefono=?,sueldo=?,periodo=?,descanso=?,ingreso=?,vac_dias=?,notas=?,activo=? WHERE id=?', ...datosEmpleado(body), body.activo === false || body.activo === 0 ? 0 : 1, Number(p.id));
  return { ok: true };
});
ruta('POST', '/api/empleados/:id/dias', 'empleados', ({ body, p, u }) => {
  const e = get('SELECT * FROM empleados WHERE id=?', Number(p.id)); if (!e) throw new ErrorUsuario('Empleado no encontrado', 404);
  if (!TIPOS_DIA[body.tipo]) throw new ErrorUsuario('Elige si es vacaciones, descanso, falta, permiso o incapacidad');
  const f = (x) => /^\d{4}-\d{2}-\d{2}$/.test(x || '');
  if (!f(body.desde)) throw new ErrorUsuario('Elige la fecha');
  const desde = body.desde, hasta = f(body.hasta) && body.hasta >= desde ? body.hasta : desde;
  const dias = diasRango(desde, hasta);
  if (dias > 120) throw new ErrorUsuario('El periodo es demasiado largo');
  return run('INSERT INTO empleado_dias(empleado_id,tipo,desde,hasta,dias,goce,notas,usuario_id,creado) VALUES(?,?,?,?,?,?,?,?,?)',
    e.id, body.tipo, desde, hasta, dias, body.goce === false || body.goce === 0 ? 0 : 1, txt(body.notas), u.id, ahora());
});
ruta('DELETE', '/api/empleados/dias/:id', 'empleados', ({ p }) => { run('DELETE FROM empleado_dias WHERE id=?', Number(p.id)); return { ok: true }; });
ruta('POST', '/api/empleados/:id/pago', 'empleados', ({ body, p, u }) => {
  const e = get('SELECT * FROM empleados WHERE id=?', Number(p.id)); if (!e) throw new ErrorUsuario('Empleado no encontrado', 404);
  const concepto = txt(body.concepto) || `Sueldo ${PERIODOS_PAGO[e.periodo]?.toLowerCase() || ''}`.trim();
  return registrarGasto({ ...body, nombre: `${concepto} · ${e.nombre}`, categoria: 'Sueldos y nómina', recibe: e.nombre }, u, e.id);
});

// ======================================================================
// 1.9 Asistencia de empleados (checador) — igual que en Maxsel Hotel
//   Número + NIP, huella DigitalPersona (herramientas\huella.exe) o reloj ZKTeco por red (ADMS).
//   Módulo aparte: se activa en la licencia ("Asistencia de empleados").
// ======================================================================
const TIPOS_CHECADA = { entrada: 'Entrada', descanso: 'Salida a comer', regreso: 'Regreso de comer', salida: 'Salida' };
// Vacaciones, permisos, etc. salen de los "días" que ya se registran en Empleados
const TIPO_DIA_ASIS = { vacaciones: () => 'vacaciones', descanso: () => 'descanso_extra', falta: () => 'falta_registrada', incapacidad: () => 'incapacidad', permiso: (x) => (x.goce === 0 ? 'permiso_sin_goce' : 'permiso_goce') };
const DIAS_PERIODO = { semanal: 7, catorcenal: 14, quincenal: 15, mensual: 30 };
const ent = (v) => Math.max(0, Math.round(Number(v) || 0));
const aFecha = (s) => { const [d, t = '00:00:00'] = String(s).split(/[ T]/); const [y, m, dd] = d.split('-').map(Number); const [h, mi, se] = t.split(':').map(Number); return new Date(y, m - 1, dd, h || 0, mi || 0, se || 0); };
const minDe = (hhmm) => { const [h, m] = String(hhmm || '').split(':').map(Number); return Number.isFinite(h) ? h * 60 + (m || 0) : null; };
const minDeFecha = (f) => minDe(String(f).slice(11, 16));
function horarioDe(e) { try { const h = JSON.parse(e.horario || 'null'); return h && typeof h === 'object' ? h : null; } catch { return null; } }
// Qué le toca: entrada → comida (si tiene tiempo de comida y aún falta más de 1 hora para su salida) → regreso → salida
function tipoEnFecha(empId, fecha) {
  const cs = all("SELECT tipo FROM checadas WHERE empleado_id=? AND anulada=0 AND substr(fecha,1,10)=? AND fecha<? ORDER BY fecha", empId, fecha.slice(0, 10), fecha), u = cs[cs.length - 1];
  if (!u || u.tipo === 'salida') return 'entrada';
  if (u.tipo === 'descanso') return 'regreso';
  if (u.tipo === 'regreso') return 'salida';
  const e = get('SELECT horario FROM empleados WHERE id=?', empId), H = e ? horarioDe(e) : null, h = H ? H[aFecha(fecha).getDay()] : null;
  if (h && num(h.descanso) > 0 && !cs.some((c) => c.tipo === 'descanso') && minDe(h.salida) !== null && minDeFecha(fecha) < minDe(h.salida) - 60) return 'descanso';
  return 'salida';
}
const siguienteTipo = (empId) => tipoEnFecha(empId, ahora() + 'z'); // 'z' para incluir la checada de este mismo segundo
const metodoChecador = () => (['nip', 'huella', 'ambos'].includes(cfg('asis_metodo')) ? cfg('asis_metodo') : 'ambos');
const puedeAsis = (u, ...k) => u.perm && k.some((x) => u.perm.has(x));
// Cálculo de un periodo para un empleado: estado de cada día, retardos, faltas y descuentos
function asistenciaDe(e, desde, hasta) {
  const C = { tol: num(cfg('asis_tolerancia')), modo: cfg('asis_desc_modo'), monto: num(cfg('asis_desc_monto')), doble: cfg('asis_desc_doble') === '1', nFalta: ent(cfg('asis_retardos_falta')), faltaDesc: cfg('asis_falta_desc') !== '0', festPago: num(cfg('asis_festivo_pago')) };
  const H = horarioDe(e), diario = e.sueldo ? e.sueldo / (DIAS_PERIODO[e.periodo] || 15) : 0;
  const fest = Object.fromEntries(all('SELECT * FROM festivos WHERE fecha BETWEEN ? AND ?', desde, hasta).map((x) => [x.fecha, x]));
  const inc = all('SELECT * FROM empleado_dias WHERE empleado_id=? AND hasta>=? AND desde<=?', e.id, desde, hasta);
  const chk = all('SELECT * FROM checadas WHERE empleado_id=? AND anulada=0 AND substr(fecha,1,10) BETWEEN ? AND ? ORDER BY fecha', e.id, desde, hasta);
  const porDia = {}; for (const c of chk) (porDia[c.fecha.slice(0, 10)] ||= []).push(c);
  const hoyS = hoy(), ahoraMin = minDeFecha(ahora()), dias = [];
  const R = { trabajados: 0, retardos: 0, min_tarde: 0, faltas: 0, faltas_retardos: 0, descansos: 0, festivos: 0, festivos_trabajados: 0, incidencias: {}, min_trabajados: 0, salidas_antes: 0,
    desc_retardos: 0, desc_faltas: 0, pago_festivos: 0, sueldo_diario: r2(diario) };
  for (let d = desde; d <= hasta; d = sumarDias(d, 1)) {
    const dow = aFecha(d).getDay(), h = H ? H[dow] : undefined, f = fest[d], i = inc.find((x) => x.desde <= d && x.hasta >= d), cs = porDia[d] || [];
    const ent1 = cs.find((c) => c.tipo === 'entrada'), sal = [...cs].reverse().find((c) => c.tipo === 'salida');
    let desc = 0; for (let k = 0; k < cs.length; k++) if (cs[k].tipo === 'descanso') { const r = cs.slice(k + 1).find((c) => c.tipo === 'regreso'); if (r) desc += minDeFecha(r.fecha) - minDeFecha(cs[k].fecha); }
    const trab = ent1 && sal && sal.fecha > ent1.fecha ? Math.max(0, minDeFecha(sal.fecha) - minDeFecha(ent1.fecha) - desc) : 0;
    const dia = { fecha: d, dow, horario: h || null, entrada: ent1?.fecha || null, salida: sal?.fecha || null, descanso_min: desc, trabajado_min: trab, checadas: cs.map((c) => ({ id: c.id, fecha: c.fecha, tipo: c.tipo, metodo: c.metodo })), estado: '', tarde: 0, descuento: 0, extra: 0, nota: '' };
    if (i) {
      const t = (TIPO_DIA_ASIS[i.tipo] || (() => i.tipo))(i);
      dia.estado = t; dia.nota = i.notas || '';
      if (t === 'falta_registrada') { R.faltas++; if (C.faltaDesc) { dia.descuento = diario; R.desc_faltas += diario; } }
      else { R.incidencias[t] = (R.incidencias[t] || 0) + 1; if (t === 'permiso_sin_goce') { dia.descuento = diario; R.desc_faltas += diario; } }
    } else if (f && f.descansa) { if (ent1) { dia.estado = 'festivo_trabajado'; dia.extra = diario * C.festPago; R.pago_festivos += dia.extra; R.festivos_trabajados++; R.trabajados++; } else { dia.estado = 'festivo'; R.festivos++; } dia.nota = f.nombre || ''; }
    else if (H === null) { dia.estado = ent1 ? 'asistencia' : 'sin_horario'; if (ent1) R.trabajados++; }
    else if (!h) { dia.estado = ent1 ? 'trabajo_descanso' : 'descanso'; if (ent1) R.trabajados++; else R.descansos++; }
    else if (!ent1) {
      const paso = d < hoyS || (d === hoyS && ahoraMin > (minDe(h.salida) ?? 1440));
      dia.estado = paso ? 'falta' : 'pendiente';
      if (paso) { R.faltas++; if (C.faltaDesc) { dia.descuento = diario; R.desc_faltas += diario; } }
    } else {
      R.trabajados++;
      const tarde = minDeFecha(ent1.fecha) - minDe(h.entrada);
      if (tarde > C.tol) {
        dia.estado = 'retardo'; dia.tarde = tarde; R.retardos++; R.min_tarde += tarde;
        const jornada = Math.max(60, (minDe(h.salida) - minDe(h.entrada)) - (num(h.descanso) || 0));
        const base = C.modo === 'fijo' ? C.monto : C.modo === 'minutos' ? (diario / jornada) * tarde : 0;
        dia.descuento = base * (C.doble ? 2 : 1); R.desc_retardos += dia.descuento;
      } else dia.estado = 'asistencia';
      if (sal && minDe(h.salida) !== null && minDeFecha(sal.fecha) < minDe(h.salida) - C.tol && sal.fecha.slice(0, 10) === d) { R.salidas_antes++; dia.nota = 'Salió antes'; }
    }
    R.min_trabajados += trab;
    dias.push(dia);
  }
  if (C.nFalta > 0) { R.faltas_retardos = Math.floor(R.retardos / C.nFalta); R.desc_faltas += R.faltas_retardos * diario; }
  for (const k of ['desc_retardos', 'desc_faltas', 'pago_festivos']) R[k] = r2(R[k]);
  R.total_descuento = r2(R.desc_retardos + R.desc_faltas);
  for (const x of dias) { x.descuento = r2(x.descuento); x.extra = r2(x.extra); }
  return { dias, resumen: R };
}
const empAsis = (e) => ({ id: e.id, nombre: e.nombre, puesto: e.puesto, numero: e.numero, sueldo: e.sueldo, periodo: e.periodo, horario: horarioDe(e), tiene_pin: !!e.pin, tiene_huella: !!e.huella, activo: e.activo });
function registrarChecada(e, tipoPedido, metodo, u) {
  const fecha = ahora();
  const tipo = TIPOS_CHECADA[tipoPedido] ? tipoPedido : tipoEnFecha(e.id, fecha);
  const ult = get('SELECT * FROM checadas WHERE empleado_id=? AND anulada=0 ORDER BY fecha DESC LIMIT 1', e.id);
  if (ult && ult.tipo === tipo && (aFecha(fecha) - aFecha(ult.fecha)) < 120000) throw new ErrorUsuario(`${e.nombre}: ya registró "${TIPOS_CHECADA[tipo]}" hace un momento`);
  run('INSERT INTO checadas(empleado_id,fecha,tipo,metodo,usuario_id) VALUES(?,?,?,?,?)', e.id, fecha, tipo, metodo, u?.id ?? null);
  const H = horarioDe(e), h = H ? H[aFecha(fecha).getDay()] : null;
  let aviso = '';
  if (tipo === 'entrada' && h && minDeFecha(fecha) - minDe(h.entrada) > num(cfg('asis_tolerancia'))) aviso = `Retardo de ${minDeFecha(fecha) - minDe(h.entrada)} minutos`;
  return { nombre: e.nombre, tipo, texto: TIPOS_CHECADA[tipo], fecha, aviso, siguiente: siguienteTipo(e.id), metodo };
}
// Checador con número + NIP
ruta('POST', '/api/asistencia/checar', 'sesion', ({ body, u }) => {
  if (!puedeAsis(u, 'checador', 'asistencia')) throw new ErrorUsuario('Este usuario no tiene permiso para usar el checador', 403);
  if (metodoChecador() === 'huella') throw new ErrorUsuario('El checador está configurado solo con huella');
  const numero = txt(body.numero)?.slice(0, 20);
  if (!numero) throw new ErrorUsuario('Escriba su número de empleado');
  const e = get('SELECT * FROM empleados WHERE numero=? AND activo=1', numero);
  if (!e || !e.pin || !checkPass(String(body.pin || ''), e.pin)) throw new ErrorUsuario('Número o NIP incorrecto');
  return registrarChecada(e, body.tipo, 'nip', u);
});
// ---------- Lector de huellas DigitalPersona (programa auxiliar herramientas\huella.exe) ----------
const HUELLA_EXE = path.join(DIR, 'herramientas', 'huella.exe');
let lectorHuellaOcupado = false;
function huellaExe(args, segundos) {
  if (process.platform !== 'win32' || !fs.existsSync(HUELLA_EXE)) return Promise.reject(new ErrorUsuario('El lector de huellas no está instalado en esta computadora. Use número y NIP.'));
  if (lectorHuellaOcupado) return Promise.reject(new ErrorUsuario('El lector está ocupado, intente en un momento'));
  lectorHuellaOcupado = true;
  return new Promise((ok, mal) => {
    execFile(HUELLA_EXE, args, { timeout: (segundos + 15) * 1000, windowsHide: true }, (err, stdout) => {
      lectorHuellaOcupado = false;
      const l = String(stdout || '').trim().split(/\r?\n/).filter(Boolean).pop();
      let r = null; try { r = JSON.parse(l); } catch { /* sin respuesta */ }
      if (!r) return mal(new ErrorUsuario(err?.killed ? 'El lector de huellas no respondió' : 'El lector de huellas no respondió (' + (err?.message || 'sin datos') + ')'));
      if (!r.ok) return mal(new ErrorUsuario(r.error || 'Error del lector de huellas'));
      ok(r);
    });
  });
}
const huellasRegistradas = () => get('SELECT COUNT(*) n FROM empleados WHERE activo=1 AND huella IS NOT NULL').n;
ruta('GET', '/api/huella/estado', 'sesion', async ({ u }) => {
  if (!puedeAsis(u, 'checador', 'asistencia')) throw new ErrorUsuario('Sin permiso', 403);
  const metodo = metodoChecador();
  if (process.platform !== 'win32' || !fs.existsSync(HUELLA_EXE)) return { metodo, instalado: false, registradas: huellasRegistradas() };
  try { const r = await huellaExe(['estado'], 5); return { metodo, instalado: true, lector: r.lector, registradas: huellasRegistradas() }; }
  catch (e) { return { metodo, instalado: true, error: e.message, registradas: huellasRegistradas() }; }
});
ruta('POST', '/api/huella/enrolar/:id', 'asistencia', async ({ p }) => {
  const e = get('SELECT id, nombre FROM empleados WHERE id=?', Number(p.id)); if (!e) throw new ErrorUsuario('No existe', 404);
  const r = await huellaExe(['enrolar', '20'], 8 * 20);
  run('UPDATE empleados SET huella=? WHERE id=?', r.plantilla, e.id);
  return { ok: true, muestras: r.muestras };
});
ruta('DELETE', '/api/huella/:id', 'asistencia', ({ p }) => { run('UPDATE empleados SET huella=NULL WHERE id=?', Number(p.id)); return { ok: true }; });
ruta('POST', '/api/huella/checar', 'sesion', async ({ body, u }) => {
  if (!puedeAsis(u, 'checador', 'asistencia')) throw new ErrorUsuario('Este usuario no tiene permiso para usar el checador', 403);
  if (metodoChecador() === 'nip') throw new ErrorUsuario('El checador está configurado solo con número y NIP');
  const L = all('SELECT id, huella FROM empleados WHERE activo=1 AND huella IS NOT NULL');
  if (!L.length) throw new ErrorUsuario('Ningún empleado tiene huella registrada. Regístrelas en Asistencia → Horarios, NIP y huella.');
  const tmp = path.join(os.tmpdir(), 'maxsel_gym_huellas_' + process.pid + '.txt');
  fs.writeFileSync(tmp, L.map((x) => x.id + '\t' + x.huella).join('\n'), 'utf8');
  let r;
  try { r = await huellaExe(['identificar', tmp, String(Math.min(30, Math.max(3, ent(body.segundos) || 10)))], 30); } finally { try { fs.unlinkSync(tmp); } catch { /* nada */ } }
  if (r.sinDedo) return { sinDedo: true };
  if (!r.id) return { noReconocida: true };
  const e = get('SELECT * FROM empleados WHERE id=? AND activo=1', Number(r.id));
  if (!e) return { noReconocida: true };
  return registrarChecada(e, body.tipo, 'huella', u);
});
// Quién está trabajando hoy
ruta('GET', '/api/asistencia/hoy', 'sesion', ({ u }) => {
  if (!puedeAsis(u, 'checador', 'asistencia')) throw new ErrorUsuario('Sin permiso', 403);
  const d = hoy();
  return all('SELECT * FROM empleados WHERE activo=1 ORDER BY nombre COLLATE NOCASE').map((e) => {
    const cs = all('SELECT fecha, tipo FROM checadas WHERE empleado_id=? AND anulada=0 AND substr(fecha,1,10)=? ORDER BY fecha', e.id, d);
    const a = puedeAsis(u, 'asistencia') ? asistenciaDe(e, d, d).dias[0] : null;
    return { id: e.id, nombre: e.nombre, puesto: e.puesto, ultima: cs[cs.length - 1] || null, checadas: cs, estado: a?.estado || null, tarde: a?.tarde || 0, horario: a?.horario || null };
  });
});
ruta('GET', '/api/asistencia/empleados', 'asistencia', () => all('SELECT * FROM empleados ORDER BY activo DESC, nombre COLLATE NOCASE').map(empAsis));
// Alta rápida de empleado desde Asistencia (por si el negocio no tiene el módulo de Gastos / Empleados)
ruta('POST', '/api/asistencia/empleados', 'asistencia', ({ body }) => {
  if (!txt(body.nombre)) throw new ErrorUsuario('Escriba el nombre del empleado');
  return run("INSERT INTO empleados(nombre,puesto,sueldo,periodo,creado) VALUES(?,?,?,?,?)", txt(body.nombre).slice(0, 100), txt(body.puesto)?.slice(0, 60) || null, num(body.sueldo), PERIODOS_PAGO[body.periodo] ? body.periodo : 'quincenal', ahora());
});
ruta('PUT', '/api/asistencia/empleados/:id', 'asistencia', ({ body, p }) => {
  const e = get('SELECT * FROM empleados WHERE id=?', Number(p.id)); if (!e) throw new ErrorUsuario('No existe', 404);
  const numero = txt(body.numero)?.slice(0, 20) || null;
  if (numero && get('SELECT id FROM empleados WHERE numero=? AND id<>?', numero, e.id)) throw new ErrorUsuario('Ese número ya lo tiene otro empleado');
  let horario = null;
  if (body.horario && typeof body.horario === 'object') {
    horario = {};
    for (let k = 0; k <= 6; k++) { const x = body.horario[k]; horario[k] = x && minDe(x.entrada) !== null && minDe(x.salida) !== null ? { entrada: x.entrada, salida: x.salida, descanso: ent(x.descanso) } : null; }
  }
  const pin = body.pin ? String(body.pin).trim() : '';
  if (pin && !/^\d{4,8}$/.test(pin)) throw new ErrorUsuario('El NIP debe ser de 4 a 8 números');
  run('UPDATE empleados SET numero=?, horario=?, pin=COALESCE(?, pin) WHERE id=?', numero, horario ? JSON.stringify(horario) : null, pin ? hashPass(pin) : null, e.id);
  return { ok: true };
});
ruta('GET', '/api/asistencia/checadas', 'asistencia', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d, emp = Number(q.empleado_id) || 0;
  return all(`SELECT c.*, e.nombre, u.nombre usuario FROM checadas c JOIN empleados e ON e.id=c.empleado_id LEFT JOIN usuarios u ON u.id=c.usuario_id
    WHERE substr(c.fecha,1,10) BETWEEN ? AND ? AND (?=0 OR c.empleado_id=?) ORDER BY c.fecha DESC LIMIT 2000`, d, h, emp, emp);
});
// Registro manual (olvidó checar) o corrección
ruta('POST', '/api/asistencia/checadas', 'asistencia', ({ body, u }) => {
  const e = get('SELECT id FROM empleados WHERE id=?', Number(body.empleado_id)); if (!e) throw new ErrorUsuario('Elija al empleado');
  if (!TIPOS_CHECADA[body.tipo]) throw new ErrorUsuario('Elija el tipo');
  const f = String(body.fecha || '').replace('T', ' ');
  if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}/.test(f)) throw new ErrorUsuario('Escriba fecha y hora');
  return { id: run('INSERT INTO checadas(empleado_id,fecha,tipo,metodo,usuario_id,nota) VALUES(?,?,?,?,?,?)', e.id, f.slice(0, 16) + ':00', body.tipo, 'manual', u.id, txt(body.nota)?.slice(0, 200) || 'Registro manual').id };
});
ruta('POST', '/api/asistencia/checadas/:id/anular', 'asistencia', ({ p }) => { run('UPDATE checadas SET anulada=1 WHERE id=?', Number(p.id)); return { ok: true }; });
ruta('GET', '/api/asistencia/reporte', 'asistencia', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d, emp = Number(q.empleado_id) || 0;
  if (d > h) throw new ErrorUsuario('La fecha inicial es mayor a la final');
  if (diasHasta(d, h) > 370) throw new ErrorUsuario('Máximo un año por reporte');
  return all(`SELECT * FROM empleados WHERE (?=0 OR id=?) AND (activo=1 OR id IN (SELECT empleado_id FROM checadas WHERE substr(fecha,1,10) BETWEEN ? AND ?)) ORDER BY nombre COLLATE NOCASE`, emp, emp, d, h)
    .map((e) => ({ empleado: empAsis(e), ...asistenciaDe(e, d, h) }));
});
// Descuentos y festivos para la nómina de un empleado
ruta('GET', '/api/asistencia/nomina/:id', 'sesion', ({ p, q, u }) => {
  if (!puedeAsis(u, 'asistencia', 'empleados')) throw new ErrorUsuario('Sin permiso', 403);
  const e = get('SELECT * FROM empleados WHERE id=?', Number(p.id)); if (!e) throw new ErrorUsuario('No existe', 404);
  const d = /^\d{4}-\d{2}-\d{2}$/.test(q.desde || '') ? q.desde : sumarDias(hoy(), -(DIAS_PERIODO[e.periodo] || 15) + 1), h = /^\d{4}-\d{2}-\d{2}$/.test(q.hasta || '') ? q.hasta : hoy();
  return { desde: d, hasta: h, con_horario: !!horarioDe(e), resumen: asistenciaDe(e, d, h <= hoy() ? h : hoy()).resumen };
});
ruta('GET', '/api/festivos', 'sesion', ({ q }) => all('SELECT * FROM festivos WHERE substr(fecha,1,4)=? ORDER BY fecha', String(q.anio || hoy().slice(0, 4))));
ruta('POST', '/api/festivos', 'asistencia', ({ body }) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(body.fecha || '')) throw new ErrorUsuario('Elija la fecha');
  run('INSERT INTO festivos(fecha,nombre,descansa) VALUES(?,?,?) ON CONFLICT(fecha) DO UPDATE SET nombre=excluded.nombre, descansa=excluded.descansa', body.fecha, txt(body.nombre)?.slice(0, 80) || 'Día festivo', body.descansa === false ? 0 : 1);
  return { ok: true };
});
ruta('DELETE', '/api/festivos/:id', 'asistencia', ({ p }) => { run('DELETE FROM festivos WHERE id=?', Number(p.id)); return { ok: true }; });
// Días de descanso obligatorio (Ley Federal del Trabajo, art. 74)
ruta('POST', '/api/festivos/ley', 'asistencia', ({ body }) => {
  const y = ent(body.anio) || Number(hoy().slice(0, 4)), f2 = (m, d) => `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  const lunes = (m, n) => { const d = new Date(y, m - 1, 1); while (d.getDay() !== 1) d.setDate(d.getDate() + 1); d.setDate(d.getDate() + 7 * (n - 1)); return f2(m, d.getDate()); };
  const L = [[f2(1, 1), 'Año Nuevo'], [lunes(2, 1), 'Día de la Constitución'], [lunes(3, 3), 'Natalicio de Benito Juárez'], [f2(5, 1), 'Día del Trabajo'], [f2(9, 16), 'Día de la Independencia'],
    [lunes(11, 3), 'Día de la Revolución'], [f2(12, 25), 'Navidad']];
  if ((y - 2024) % 6 === 0) L.push([f2(10, 1), 'Transmisión del Poder Ejecutivo Federal']);
  for (const [f, n] of L) run('INSERT OR IGNORE INTO festivos(fecha,nombre,descansa) VALUES(?,?,1)', f, n);
  return { agregados: L.length };
});
// Vacaciones y permisos: son los mismos "días" de Empleados
ruta('GET', '/api/asistencia/incidencias', 'asistencia', ({ q }) => all(`SELECT i.*, e.nombre FROM empleado_dias i JOIN empleados e ON e.id=i.empleado_id WHERE i.hasta>=? AND i.desde<=? ORDER BY i.desde DESC`, q.desde || '0000-00-00', q.hasta || '9999-12-31'));
ruta('POST', '/api/asistencia/incidencias', 'asistencia', ({ body, u }) => {
  const e = get('SELECT id FROM empleados WHERE id=?', Number(body.empleado_id)); if (!e) throw new ErrorUsuario('Elija al empleado');
  if (!TIPOS_DIA[body.tipo]) throw new ErrorUsuario('Elija el tipo');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(body.desde || '') || !/^\d{4}-\d{2}-\d{2}$/.test(body.hasta || '') || body.hasta < body.desde) throw new ErrorUsuario('Revise las fechas');
  return { id: run('INSERT INTO empleado_dias(empleado_id,tipo,desde,hasta,dias,goce,notas,usuario_id,creado) VALUES(?,?,?,?,?,?,?,?,?)', e.id, body.tipo, body.desde, body.hasta, diasRango(body.desde, body.hasta), body.goce === false || body.goce === 0 ? 0 : 1, txt(body.notas)?.slice(0, 200) || null, u.id, ahora()).id };
});
ruta('DELETE', '/api/asistencia/incidencias/:id', 'asistencia', ({ p }) => { run('DELETE FROM empleado_dias WHERE id=?', Number(p.id)); return { ok: true }; });
// Reglas de retardos y descuentos
const CLAVES_ASIS = ['asis_metodo', 'asis_tolerancia', 'asis_desc_modo', 'asis_desc_monto', 'asis_desc_doble', 'asis_retardos_falta', 'asis_falta_desc', 'asis_festivo_pago', 'reloj_estado'];
ruta('PUT', '/api/asistencia/reglas', 'asistencia', ({ body }) => { for (const k of CLAVES_ASIS) if (body[k] !== undefined) setCfg(k, String(body[k]).slice(0, 20)); return { ok: true }; });
// ---------- Reloj checador por red ZKTeco (protocolo ADMS / "push"): el reloj manda las checadas solo ----------
//   En el reloj: Menú → Comunicación → Servidor en la nube (ADMS): dirección = IP de esta computadora, puerto 3030
//   El número de usuario en el reloj (PIN) debe ser el mismo "Número para checar" del empleado
const TIPO_ZK = { 0: 'entrada', 1: 'salida', 2: 'descanso', 3: 'regreso', 4: 'entrada', 5: 'salida' };
function checadaReloj(sn, linea) {
  const [pin, fecha, estado] = linea.split('\t').map((x) => String(x || '').trim());
  if (!pin || !/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/.test(fecha || '')) return false;
  const e = get('SELECT * FROM empleados WHERE numero=? AND activo=1', pin); if (!e) return false;
  const f = fecha.length === 16 ? fecha + ':00' : fecha;
  if (get('SELECT id FROM checadas WHERE empleado_id=? AND fecha=?', e.id, f)) return false;
  const tipo = cfg('reloj_estado') === 'reloj' && TIPO_ZK[estado] ? TIPO_ZK[estado] : tipoEnFecha(e.id, f);
  run('INSERT INTO checadas(empleado_id,fecha,tipo,metodo,usuario_id,nota) VALUES(?,?,?,?,?,?)', e.id, f, tipo, 'reloj', null, 'Reloj ' + sn);
  return true;
}
const ipDe = (req) => String(req.socket?.remoteAddress || '').replace(/^::ffff:/, '');
function iclock(req, res, url, r0, cuerpo) {
  const sn = txt(url.searchParams.get('SN'))?.slice(0, 40), texto = (t, st = 200) => { res.writeHead(st, { 'Content-Type': 'text/plain' }); res.end(t); };
  if (!sn) return texto('ERROR', 400);
  const ya = get('SELECT * FROM relojes WHERE sn=?', sn);
  if (!ya) run('INSERT INTO relojes(sn,nombre,ip,ultimo,activo) VALUES(?,?,?,?,0)', sn, 'Reloj ' + sn, ipDe(req), ahora());
  else run('UPDATE relojes SET ip=?, ultimo=? WHERE sn=?', ipDe(req), ahora(), sn);
  const activo = ya?.activo === 1;
  if (r0 === '/iclock/cdata' && req.method === 'GET') {
    const tz = -new Date().getTimezoneOffset() / 60;
    return texto(`GET OPTION FROM: ${sn}\nATTLOGStamp=${ya?.stamp || 'None'}\nOPERLOGStamp=9999\nATTPHOTOStamp=None\nErrorDelay=60\nDelay=30\nTransTimes=00:00;14:05\nTransInterval=1\nTransFlag=TransData AttLog\nTimeZone=${tz}\nRealtime=1\nEncrypt=None\n`);
  }
  if (r0 === '/iclock/cdata' && req.method === 'POST') {
    // Mientras el administrador no active el reloj no se reciben checadas (el reloj las vuelve a mandar después)
    if (!activo) return texto('ERROR: reloj no autorizado', 403);
    if (url.searchParams.get('table') !== 'ATTLOG') return texto('OK');
    let n = 0; const lineas = cuerpo.toString('utf8').split(/\r?\n/).filter(Boolean);
    tx(() => { for (const l of lineas) if (checadaReloj(sn, l)) n++; });
    if (url.searchParams.get('Stamp')) run('UPDATE relojes SET stamp=? WHERE sn=?', url.searchParams.get('Stamp'), sn);
    return texto('OK: ' + lineas.length);
  }
  return texto('OK');
}
ruta('GET', '/api/relojes', 'asistencia', () => all('SELECT sn, nombre, ip, ultimo, activo FROM relojes ORDER BY ultimo DESC'));
ruta('PUT', '/api/relojes/:sn', 'asistencia', ({ p, body }) => { run('UPDATE relojes SET nombre=COALESCE(?,nombre), activo=? WHERE sn=?', txt(body.nombre)?.slice(0, 60) || null, body.activo ? 1 : 0, p.sn); return { ok: true }; });
ruta('DELETE', '/api/relojes/:sn', 'asistencia', ({ p }) => { run('DELETE FROM relojes WHERE sn=?', p.sn); return { ok: true }; });

// ---------- Proveedores y cuentas por pagar (cambian de color: se debe, vencida, pagada) ----------
const fechaOk = (x) => /^\d{4}-\d{2}-\d{2}$/.test(x || '');
function cxpJSON(c) {
  const saldo = r2(c.monto - c.pagado), dias = c.vence ? diasRango(hoy(), c.vence) - 1 : null;
  const estado = c.cancelada ? 'cancelada' : saldo <= 0.009 ? 'pagada' : dias !== null && dias < 0 ? 'vencida' : 'pendiente';
  return { ...c, saldo, dias, estado, por_vencer: estado === 'pendiente' && dias !== null && dias <= (Number(cfg('cxp_dias_aviso')) || 3) };
}
const SQL_CXP = 'SELECT c.*, pv.nombre proveedor FROM cuentas_pagar c LEFT JOIN proveedores pv ON pv.id=c.proveedor_id';
const cuentasAbiertas = () => all(`${SQL_CXP} WHERE c.cancelada=0 AND c.monto-c.pagado>0.009 ORDER BY c.vence IS NULL, c.vence, c.id`).map(cxpJSON);
function resumenCuentas(d, h) {
  const ab = cuentasAbiertas(), S = (l) => r2(l.reduce((a, c) => a + c.saldo, 0));
  const ven = ab.filter((c) => c.estado === 'vencida'), deb = ab.filter((c) => c.estado === 'pendiente');
  return {
    pendiente: S(deb), vencido: S(ven), n_pendiente: deb.length, n_vencido: ven.length, por_vencer: deb.filter((c) => c.por_vencer).length,
    nuevas: r2(get('SELECT COALESCE(SUM(monto),0) t FROM cuentas_pagar WHERE cancelada=0 AND fecha BETWEEN ? AND ?', d, h).t),
    pagado: r2(get('SELECT COALESCE(SUM(monto),0) t FROM cuentas_pagos WHERE substr(fecha,1,10) BETWEEN ? AND ?', d, h).t),
    lista: ab.map((c) => ({ id: c.id, proveedor: c.proveedor, concepto: c.concepto, factura: c.factura, fecha: c.fecha, vence: c.vence, monto: c.monto, pagado: c.pagado, saldo: c.saldo, estado: c.estado, dias: c.dias, por_vencer: c.por_vencer })),
  };
}
function limpiarProv(b) {
  const d = Object.fromEntries(['nombre', 'contacto', 'telefono', 'correo', 'rfc', 'surte', 'banco', 'cuenta', 'notas'].map((k) => [k, txt(b[k])]));
  if (!d.nombre) throw new ErrorUsuario('Escribe el nombre del proveedor');
  return d;
}
const PROV_C = ['nombre', 'contacto', 'telefono', 'correo', 'rfc', 'surte', 'banco', 'cuenta', 'notas'];
ruta('GET', '/api/proveedores', 'cuentas_pagar', ({ q }) => all(`SELECT p.*, (SELECT COALESCE(SUM(monto-pagado),0) FROM cuentas_pagar WHERE proveedor_id=p.id AND cancelada=0) debe,
    (SELECT COUNT(*) FROM cuentas_pagar WHERE proveedor_id=p.id AND cancelada=0 AND monto-pagado>0.009) abiertas,
    (SELECT COALESCE(SUM(monto),0) FROM gastos WHERE proveedor_id=p.id) pagado_total FROM proveedores p WHERE ${q.todos ? '1=1' : 'p.activo=1'} ORDER BY p.activo DESC, p.nombre COLLATE NOCASE`)
  .map((x) => ({ ...x, debe: r2(x.debe), pagado_total: r2(x.pagado_total) })));
ruta('POST', '/api/proveedores', 'cuentas_pagar', ({ body }) => { const d = limpiarProv(body); return run(`INSERT INTO proveedores(${PROV_C.join(',')},creado) VALUES(${PROV_C.map(() => '?').join(',')},?)`, ...PROV_C.map((k) => d[k]), ahora()); });
ruta('PUT', '/api/proveedores/:id', 'cuentas_pagar', ({ body, p }) => {
  const d = limpiarProv(body);
  run(`UPDATE proveedores SET ${PROV_C.map((k) => k + '=?').join(',')}, activo=? WHERE id=?`, ...PROV_C.map((k) => d[k]), body.activo === false || body.activo === 0 ? 0 : 1, Number(p.id));
  return { ok: true };
});
ruta('GET', '/api/cuentas-pagar', 'cuentas_pagar', ({ q }) => {
  const L = all(`${SQL_CXP} WHERE c.cancelada=0 ORDER BY c.vence IS NULL, c.vence, c.id`).map(cxpJSON);
  const f = q.estado || 'abiertas';
  return f === 'todas' ? L : f === 'abiertas' ? L.filter((c) => c.estado !== 'pagada') : L.filter((c) => c.estado === f);
});
ruta('GET', '/api/cuentas-pagar/avisos', 'sesion', ({ u }) => (u.perm.has('cuentas_pagar') ? cuentasAbiertas().filter((c) => c.estado === 'vencida' || c.por_vencer) : []));
ruta('GET', '/api/cuentas-pagar/:id', 'cuentas_pagar', ({ p }) => {
  const c = get(`${SQL_CXP} WHERE c.id=?`, Number(p.id)); if (!c) throw new ErrorUsuario('No existe', 404);
  return { ...cxpJSON(c), pagos: all('SELECT cp.*, g.pagado_con, g.notas, u.nombre usuario FROM cuentas_pagos cp LEFT JOIN gastos g ON g.id=cp.gasto_id LEFT JOIN usuarios u ON u.id=cp.usuario_id WHERE cp.cuenta_id=? ORDER BY cp.id', c.id) };
});
function limpiarCxp(b) {
  const d = { proveedor_id: Number(b.proveedor_id) || null, concepto: txt(b.concepto), factura: txt(b.factura), categoria: CATEGORIAS_GASTOS.includes(b.categoria) ? b.categoria : 'Proveedores', monto: num(b.monto),
    fecha: fechaOk(b.fecha) ? b.fecha : hoy(), vence: fechaOk(b.vence) ? b.vence : null, notas: txt(b.notas) };
  if (!d.concepto) throw new ErrorUsuario('Escribe qué se debe (concepto)');
  if (!(d.monto > 0)) throw new ErrorUsuario('Escribe el monto que se debe');
  return d;
}
ruta('POST', '/api/cuentas-pagar', 'cuentas_pagar', ({ body, u }) => {
  const d = limpiarCxp(body);
  return run('INSERT INTO cuentas_pagar(proveedor_id,concepto,factura,categoria,monto,fecha,vence,notas,usuario_id,creado) VALUES(?,?,?,?,?,?,?,?,?,?)', d.proveedor_id, d.concepto, d.factura, d.categoria, d.monto, d.fecha, d.vence, d.notas, u.id, ahora());
});
ruta('PUT', '/api/cuentas-pagar/:id', 'cuentas_pagar', ({ body, p }) => {
  const c = get('SELECT * FROM cuentas_pagar WHERE id=?', Number(p.id)); if (!c) throw new ErrorUsuario('No existe', 404);
  const d = limpiarCxp(body); if (d.monto < c.pagado - 0.009) throw new ErrorUsuario('Ya se pagaron $' + c.pagado.toFixed(2) + ': el monto no puede ser menor');
  run('UPDATE cuentas_pagar SET proveedor_id=?,concepto=?,factura=?,categoria=?,monto=?,fecha=?,vence=?,notas=? WHERE id=?', d.proveedor_id, d.concepto, d.factura, d.categoria, d.monto, d.fecha, d.vence, d.notas, c.id);
  return { ok: true };
});
ruta('DELETE', '/api/cuentas-pagar/:id', 'cuentas_pagar', ({ p }) => {
  const c = get('SELECT * FROM cuentas_pagar WHERE id=?', Number(p.id)); if (!c) throw new ErrorUsuario('No existe', 404);
  if (c.pagado > 0) throw new ErrorUsuario('Ya tiene pagos: no se puede cancelar');
  run('UPDATE cuentas_pagar SET cancelada=1 WHERE id=?', c.id); return { ok: true };
});
ruta('POST', '/api/cuentas-pagar/:id/pagar', 'cuentas_pagar', ({ body, p, u }) => tx(() => {
  const c = cxpJSON(get(`${SQL_CXP} WHERE c.id=?`, Number(p.id)) || {});
  if (!c.id || c.cancelada) throw new ErrorUsuario('No existe', 404);
  const monto = num(body.monto); if (!(monto > 0)) throw new ErrorUsuario('Escribe cuánto se paga');
  if (monto > c.saldo + 0.009) throw new ErrorUsuario('Solo se deben $' + c.saldo.toFixed(2));
  const g = registrarGasto({ nombre: `Pago a ${c.proveedor || 'proveedor'} · ${c.concepto}${c.factura ? ' · Fact. ' + c.factura : ''}${monto < c.saldo - 0.009 ? ' (abono)' : ''}`,
    categoria: c.categoria || 'Proveedores', monto, pagado_con: body.pagado_con, fecha: body.fecha, notas: body.notas, recibe: c.proveedor }, u, null, c.proveedor_id);
  run('INSERT INTO cuentas_pagos(cuenta_id,gasto_id,fecha,monto,usuario_id) VALUES(?,?,?,?,?)', c.id, g.id, g.fecha, monto, u.id);
  run('UPDATE cuentas_pagar SET pagado=pagado+? WHERE id=?', monto, c.id);
  return { gasto_id: g.id, saldo: r2(c.saldo - monto) };
}));

// ---------- Turnos de caja ----------
const turnoAbierto = (uid) => get(`SELECT * FROM turnos WHERE usuario_id=? AND estado='abierto'`, uid);
function exigirTurno(u) {
  const t = turnoAbierto(u.id);
  if (!t) throw new ErrorUsuario('Primero abre tu turno de caja');
  return t;
}
function esperado(t) {
  const v = get(`SELECT COALESCE(SUM(pago_efectivo - cambio),0) ef, COALESCE(SUM(pago_usd),0) usd, COALESCE(SUM(pago_tarjeta),0) tar, COALESCE(SUM(pago_transferencia),0) trf,
    COALESCE(SUM(pago_credito),0) cred, COALESCE(SUM(total),0) total, COUNT(*) n FROM ventas WHERE turno_id=? AND cancelada=0`, t.id);
  const a = get(`SELECT COALESCE(SUM(efectivo - cambio),0) ef, COALESCE(SUM(usd),0) usd, COALESCE(SUM(tarjeta),0) tar, COALESCE(SUM(transferencia),0) trf, COALESCE(SUM(monto),0) total, COUNT(*) n FROM abonos WHERE turno_id=?`, t.id);
  const m = get(`SELECT COALESCE(SUM(CASE WHEN tipo='entrada' THEN monto ELSE 0 END),0) ent, COALESCE(SUM(CASE WHEN tipo='retiro' THEN monto ELSE 0 END),0) ret,
    COALESCE(SUM(CASE WHEN tipo='gasto' THEN monto ELSE 0 END),0) gas FROM movimientos WHERE turno_id=?`, t.id);
  return {
    efectivo: r2(t.fondo_mxn + v.ef + a.ef + m.ent - m.ret - m.gas), usd: r2(v.usd + a.usd), tarjeta: r2(v.tar + a.tar), transferencia: r2(v.trf + a.trf),
    ventas_total: r2(v.total), ventas_n: v.n, credito: r2(v.cred), abonos_total: r2(a.total), abonos_n: a.n,
    entradas: r2(m.ent), retiros: r2(m.ret), gastos: r2(m.gas), fondo: t.fondo_mxn,
  };
}
ruta('GET', '/api/turno', 'pos', ({ u }) => turnoAbierto(u.id) || null);
ruta('POST', '/api/turno/abrir', 'pos', ({ body, u }) => {
  if (turnoAbierto(u.id)) throw new ErrorUsuario('Ya tienes un turno abierto');
  const tc = num(body.tipo_cambio);
  if (!(tc > 5 && tc < 50)) throw new ErrorUsuario('Escribe el tipo de cambio del dólar de hoy (ej. 17.50)');
  setCfg('tipo_cambio', tc);
  const r = run('INSERT INTO turnos(usuario_id,abierto,fondo_mxn,tipo_cambio) VALUES(?,?,?,?)', u.id, ahora(), num(body.fondo), tc);
  return get('SELECT * FROM turnos WHERE id=?', r.id);
});
// Retiros (el dueño o gerente se lleva efectivo), gastos (se paga algo con dinero de la caja) y entradas
const CATEGORIAS_GASTO = ['Proveedor / mercancía', 'Servicios (luz, agua, internet)', 'Renta', 'Sueldos y nómina', 'Limpieza', 'Mantenimiento y reparaciones', 'Papelería', 'Publicidad', 'Comida / consumo', 'Otro'];
ruta('POST', '/api/turno/movimiento', 'movimientos', ({ body, u }) => {
  const t = exigirTurno(u);
  if (!['retiro', 'gasto', 'entrada'].includes(body.tipo)) throw new ErrorUsuario('Elige si es retiro, gasto o entrada');
  if (!(num(body.monto) > 0)) throw new ErrorUsuario('Escribe el monto');
  if (!txt(body.concepto)) throw new ErrorUsuario('Escribe el concepto (para qué es el dinero)');
  const cat = body.tipo === 'gasto' ? (CATEGORIAS_GASTO.includes(body.categoria) ? body.categoria : 'Otro') : null;
  const id = run('INSERT INTO movimientos(turno_id,usuario_id,tipo,monto,concepto,fecha,categoria,recibe) VALUES(?,?,?,?,?,?,?,?)',
    t.id, u.id, body.tipo, num(body.monto), txt(body.concepto), ahora(), cat, txt(body.recibe) || null).id;
  return get('SELECT m.*, u.nombre cajero FROM movimientos m LEFT JOIN usuarios u ON u.id=m.usuario_id WHERE m.id=?', id);
});
ruta('GET', '/api/turno/movimientos', 'movimientos', ({ u }) => {
  const t = turnoAbierto(u.id);
  return { categorias: CATEGORIAS_GASTO, lista: t ? all('SELECT m.*, u.nombre cajero FROM movimientos m LEFT JOIN usuarios u ON u.id=m.usuario_id WHERE turno_id=? ORDER BY m.id DESC', t.id) : [] };
});
// Cierre a ciegas: el cajero declara lo que contó sin ver lo que debería haber
ruta('POST', '/api/turno/cerrar', 'pos', ({ body, u }) => {
  const t = exigirTurno(u);
  for (const k of ['efectivo', 'usd', 'tarjeta']) if (body[k] === undefined || body[k] === '' || Number(body[k]) < 0) throw new ErrorUsuario('Captura todo lo que contaste (pon 0 si no hay)');
  const e = esperado(t);
  run(`UPDATE turnos SET cerrado=?, decl_efectivo=?, decl_usd=?, decl_tarjeta=?, esp_efectivo=?, esp_usd=?, esp_tarjeta=?, notas=?, estado='cerrado' WHERE id=?`,
    ahora(), num(body.efectivo), num(body.usd), num(body.tarjeta), e.efectivo, e.usd, e.tarjeta, txt(body.notas), t.id);
  if (!u.perm.has('ver_corte') && !u.perm.has('cortes')) return { ok: true, id: t.id };
  return { ok: true, id: t.id, corte: detalleCorte(t.id) };
});
function detalleCorte(id) {
  const t = get('SELECT t.*, u.nombre cajero FROM turnos t JOIN usuarios u ON u.id=t.usuario_id WHERE t.id=?', id);
  if (!t) throw new ErrorUsuario('Turno no encontrado', 404);
  const e = esperado(t);
  const esp = t.estado === 'cerrado' ? { efectivo: t.esp_efectivo, usd: t.esp_usd, tarjeta: t.esp_tarjeta } : e;
  const dif = t.estado === 'cerrado' ? {
    efectivo: r2(t.decl_efectivo - esp.efectivo), usd: r2(t.decl_usd - esp.usd), tarjeta: r2(t.decl_tarjeta - esp.tarjeta),
    total_mxn: r2((t.decl_efectivo - esp.efectivo) + (t.decl_usd - esp.usd) * t.tipo_cambio + (t.decl_tarjeta - esp.tarjeta)),
  } : null;
  return {
    turno: t, resumen: e, esperado: esp, diferencia: dif,
    ventas: all(`SELECT v.*, c.nombre cliente, (SELECT GROUP_CONCAT(descripcion, ', ') FROM venta_items WHERE venta_id=v.id) detalle
      FROM ventas v LEFT JOIN clientes c ON c.id=v.cliente_id WHERE turno_id=? ORDER BY v.fecha`, id),
    abonos: all('SELECT a.*, c.nombre cliente FROM abonos a LEFT JOIN clientes c ON c.id=a.cliente_id WHERE turno_id=?', id),
    movimientos: all('SELECT m.*, u.nombre cajero FROM movimientos m LEFT JOIN usuarios u ON u.id=m.usuario_id WHERE turno_id=? ORDER BY m.fecha', id),
  };
}
ruta('GET', '/api/cortes', 'cortes', ({ q }) => {
  const desde = q.desde || sumarDias(hoy(), -30), hasta = q.hasta || hoy();
  return all(`SELECT t.*, u.nombre cajero FROM turnos t JOIN usuarios u ON u.id=t.usuario_id
    WHERE substr(t.abierto,1,10) BETWEEN ? AND ? ORDER BY t.abierto DESC`, desde, hasta).map((t) => {
    const e = esperado(t);
    return { ...t, ventas_total: e.ventas_total, ventas_n: e.ventas_n,
      dif_mxn: t.estado === 'cerrado' ? r2((t.decl_efectivo - t.esp_efectivo) + (t.decl_usd - t.esp_usd) * t.tipo_cambio + (t.decl_tarjeta - t.esp_tarjeta)) : null };
  });
});
ruta('GET', '/api/cortes/:id', 'cortes', ({ p }) => detalleCorte(Number(p.id)));

// ---------- Ventas ----------
ruta('POST', '/api/ventas', 'pos', ({ body, u }) => {
  const t = exigirTurno(u);
  const items = Array.isArray(body.items) ? body.items : [];
  if (!items.length) throw new ErrorUsuario('El carrito está vacío');
  const pg = body.pagos || {};
  const pago = { efectivo: num(pg.efectivo), usd: num(pg.usd), tarjeta: num(pg.tarjeta), transferencia: num(pg.transferencia), credito: num(pg.credito) };
  if (Object.values(pago).some((v) => v < 0)) throw new ErrorUsuario('Los pagos no pueden ser negativos');
  if (pago.credito > 0 && !u.perm.has('credito')) throw new ErrorUsuario('No tienes permiso para vender a crédito', 403);
  let clienteVenta = Number(body.cliente_id) || null;
  const sincronizar = new Set();
  // 1.12.2: descuento por artículo (en $ o en %), solo con el permiso "descuentos"
  const descuentoDe = (it, base) => {
    const v = num(it.desc_valor);
    if (!(v > 0)) return 0;
    if (!u.perm.has('descuentos')) throw new ErrorUsuario('No tienes permiso para aplicar descuentos', 403);
    if (it.desc_tipo === 'porcentaje') { if (v > 100) throw new ErrorUsuario('El descuento no puede ser más de 100%'); return r2(base * v / 100); }
    return r2(Math.min(v, base));
  };
  const txtDesc = (it, d) => (d > 0 ? ` · desc. ${it.desc_tipo === 'porcentaje' ? num(it.desc_valor) + '%' : '$' + d.toFixed(2)}` : '');

  const venta = tx(() => {
    const vid = run('INSERT INTO ventas(turno_id,usuario_id,cliente_id,fecha,tipo_cambio) VALUES(?,?,?,?,?)', t.id, u.id, clienteVenta, ahora(), t.tipo_cambio).id;
    let total = 0;
    for (const it of items) {
      if (it.tipo === 'producto') {
        const pr = get('SELECT * FROM productos WHERE id=?', Number(it.producto_id));
        const cant = Number(it.cantidad) || 0;
        if (!pr) throw new ErrorUsuario('Producto no encontrado');
        if (cant <= 0) throw new ErrorUsuario(`Cantidad inválida para ${pr.nombre}`);
        const bruto = r2(pr.precio * cant), d = descuentoDe(it, bruto), imp = r2(bruto - d);
        run('INSERT INTO venta_items(venta_id,tipo,producto_id,descripcion,cantidad,precio,costo,importe,descuento) VALUES(?,?,?,?,?,?,?,?,?)', vid, 'producto', pr.id, pr.nombre + txtDesc(it, d), cant, pr.precio, pr.costo, imp, d);
        run('UPDATE productos SET existencia=existencia-? WHERE id=?', cant, pr.id);
        total += imp;
      } else if (it.tipo === 'membresia') {
        const cot = cotizarMembresia(it);
        const d = descuentoDe(it, cot.total);
        if (d > 0) cot.total = r2(cot.total - d);
        run('INSERT INTO venta_items(venta_id,tipo,descripcion,cantidad,precio,importe,descuento) VALUES(?,?,?,?,?,?,?)', vid, 'membresia', `${cot.descripcion} (${cot.inicio} al ${cot.fin})${txtDesc(it, d)}`, 1, cot.total + d, cot.total, d);
        const precioPersona = cot.pareja_id ? r2(cot.total / 2) : cot.total;
        run('INSERT INTO membresias(cliente_id,plan_id,promo_id,inicio,fin,precio,venta_id,pareja_cliente_id,creado) VALUES(?,?,?,?,?,?,?,?,?)',
          cot.cliente_id, cot.plan_id, cot.promo_id, cot.inicio, cot.fin, precioPersona, vid, cot.pareja_id, ahora());
        sincronizar.add(cot.cliente_id);
        if (cot.pareja_id) {
          run('INSERT INTO membresias(cliente_id,plan_id,promo_id,inicio,fin,precio,venta_id,pareja_cliente_id,creado) VALUES(?,?,?,?,?,?,?,?,?)',
            cot.pareja_id, cot.plan_id, cot.promo_id, cot.pareja_fechas.inicio, cot.pareja_fechas.fin, precioPersona, vid, cot.cliente_id, ahora());
          sincronizar.add(cot.pareja_id);
        }
        if (!clienteVenta) clienteVenta = cot.cliente_id;
        total += cot.total;
      } else throw new ErrorUsuario('Artículo inválido en el carrito');
    }
    total = r2(total);
    const tc = t.tipo_cambio;
    const usdMxn = r2(pago.usd * tc);
    const pagado = r2(pago.efectivo + usdMxn + pago.tarjeta + pago.transferencia + pago.credito);
    if (pago.credito > 0 && !clienteVenta) throw new ErrorUsuario('Para dejar a crédito selecciona el cliente');
    if (pago.tarjeta + pago.transferencia + pago.credito > total + 0.009) throw new ErrorUsuario('Tarjeta, transferencia y crédito no pueden pasar del total (no se da cambio en esas formas de pago)');
    if (pagado < total - 0.009) throw new ErrorUsuario(`Falta por cobrar $${(total - pagado).toFixed(2)}`);
    const cambio = r2(pagado - total);
    if (cambio > pago.efectivo + usdMxn + 0.009) throw new ErrorUsuario('El cambio no puede ser mayor al efectivo recibido');
    run('UPDATE ventas SET cliente_id=?, total=?, pago_efectivo=?, pago_usd=?, pago_tarjeta=?, pago_transferencia=?, pago_credito=?, cambio=?, credito_pendiente=?, referencia=? WHERE id=?',
      clienteVenta, total, pago.efectivo, pago.usd, pago.tarjeta, pago.transferencia, pago.credito, cambio, pago.credito, txt(pg.referencia) || null, vid);
    return vid;
  });
  for (const id of sincronizar) sincronizarEnSegundoPlano(id);
  return ticketVenta(venta);
});
function ticketVenta(id) {
  const v = get('SELECT v.*, c.nombre cliente, u.nombre cajero FROM ventas v LEFT JOIN clientes c ON c.id=v.cliente_id LEFT JOIN usuarios u ON u.id=v.usuario_id WHERE v.id=?', id);
  return { ...v, items: all('SELECT * FROM venta_items WHERE venta_id=?', id) };
}
ruta('GET', '/api/ventas/:id', 'sesion', ({ p }) => ticketVenta(Number(p.id)));
ruta('GET', '/api/ventas', 'pos', ({ u, q }) => {
  const t = q.turno ? Number(q.turno) : turnoAbierto(u.id)?.id;
  if (q.turno && !u.perm.has('cortes')) throw new ErrorUsuario('Sin permiso', 403);
  return all(`SELECT v.*, c.nombre cliente, (SELECT GROUP_CONCAT(descripcion, ', ') FROM venta_items WHERE venta_id=v.id) detalle
    FROM ventas v LEFT JOIN clientes c ON c.id=v.cliente_id WHERE turno_id=? ORDER BY v.id DESC`, t || 0);
});
ruta('POST', '/api/ventas/:id/cancelar', 'cancelar', ({ p, body }) => {
  const v = get('SELECT v.*, t.estado FROM ventas v JOIN turnos t ON t.id=v.turno_id WHERE v.id=?', Number(p.id));
  if (!v || v.cancelada) throw new ErrorUsuario('Venta no encontrada o ya cancelada');
  if (v.estado !== 'abierto') throw new ErrorUsuario('Solo se pueden cancelar ventas de un turno abierto');
  if (v.credito_pendiente < v.pago_credito - 0.009) throw new ErrorUsuario('Esta venta a crédito ya tiene abonos, no se puede cancelar');
  const clientes = all('SELECT cliente_id FROM membresias WHERE venta_id=?', v.id).map((m) => m.cliente_id);
  tx(() => {
    for (const it of all(`SELECT * FROM venta_items WHERE venta_id=? AND tipo='producto'`, v.id)) run('UPDATE productos SET existencia=existencia+? WHERE id=?', it.cantidad, it.producto_id);
    run('UPDATE membresias SET cancelada=1 WHERE venta_id=?', v.id);
    run('UPDATE ventas SET cancelada=1, credito_pendiente=0 WHERE id=?', v.id);
  });
  for (const c of clientes) sincronizarEnSegundoPlano(c);
  return { ok: true, motivo: txt(body.motivo) };
});

// ---------- Crédito / adeudos ----------
ruta('GET', '/api/adeudos', 'adeudos', () => all(`SELECT c.id, c.nombre, c.telefono, c.whatsapp, SUM(v.credito_pendiente) saldo, MIN(v.fecha) desde, COUNT(*) ventas
  FROM ventas v JOIN clientes c ON c.id=v.cliente_id WHERE v.cancelada=0 AND v.credito_pendiente>0.009 GROUP BY c.id ORDER BY saldo DESC`));
ruta('POST', '/api/abonos', 'abonos', ({ body, u }) => {
  const t = exigirTurno(u);
  const cid = Number(body.cliente_id);
  const monto = num(body.monto);
  const saldo = r2(get('SELECT COALESCE(SUM(credito_pendiente),0) s FROM ventas WHERE cliente_id=? AND cancelada=0', cid).s);
  if (!(monto > 0)) throw new ErrorUsuario('Indica el monto a abonar');
  if (monto > saldo + 0.009) throw new ErrorUsuario(`El cliente solo debe $${saldo.toFixed(2)}`);
  const ef = num(body.efectivo), usd = num(body.usd), tar = num(body.tarjeta), trf = num(body.transferencia);
  const pagado = r2(ef + usd * t.tipo_cambio + tar + trf);
  if (tar + trf > monto + 0.009) throw new ErrorUsuario('Tarjeta y transferencia no pueden pasar del monto del abono');
  if (pagado < monto - 0.009) throw new ErrorUsuario(`Falta $${(monto - pagado).toFixed(2)} para cubrir el abono`);
  const cambio = r2(pagado - monto);
  return tx(() => {
    const r = run('INSERT INTO abonos(cliente_id,turno_id,usuario_id,fecha,monto,efectivo,usd,tarjeta,transferencia,referencia,cambio) VALUES(?,?,?,?,?,?,?,?,?,?,?)', cid, t.id, u.id, ahora(), monto, ef, usd, tar, trf, txt(body.referencia) || null, cambio);
    let resto = monto; // se aplica primero a las deudas más viejas
    for (const v of all('SELECT id, credito_pendiente FROM ventas WHERE cliente_id=? AND cancelada=0 AND credito_pendiente>0.009 ORDER BY fecha', cid)) {
      if (resto <= 0.009) break;
      const aplica = Math.min(resto, v.credito_pendiente);
      run('UPDATE ventas SET credito_pendiente=? WHERE id=?', r2(v.credito_pendiente - aplica), v.id);
      resto = r2(resto - aplica);
    }
    return { id: r.id, monto, cambio, efectivo: ef, usd, tarjeta: tar, transferencia: trf, saldo_nuevo: r2(saldo - monto), fecha: ahora(), cliente: get('SELECT nombre FROM clientes WHERE id=?', cid)?.nombre };
  });
});

// ---------- Gastos (fijos y varios) ----------
const CATEGORIAS_GASTOS = ['Agua', 'Luz', 'Internet', 'Teléfono', 'Renta', 'Sueldos y nómina', 'Mantenimiento', 'Limpieza', 'Publicidad', 'Impuestos y permisos', 'Proveedores', 'Equipo', 'Gastos varios'];
const periodoDe = (f) => String(f || hoy()).slice(0, 7);
// 1.9: gastos fijos como en Maxsel Hotel (compañía, contrato, referencia, cada cuánto se paga, vencimiento y colores)
const PERIODOS_FIJO = { semanal: 'Cada semana', catorcenal: 'Cada 14 días', quincenal: 'Cada quincena', mensual: 'Cada mes', bimestral: 'Cada 2 meses', trimestral: 'Cada 3 meses', semestral: 'Cada 6 meses', anual: 'Cada año', unico: 'Una sola vez' };
function siguienteVence(v, per) {
  const d = /^\d{4}-\d{2}-\d{2}$/.test(v || '') ? v : hoy();
  return { semanal: sumarDias(d, 7), catorcenal: sumarDias(d, 14), quincenal: sumarDias(d, 15), bimestral: sumarMeses(d, 2), trimestral: sumarMeses(d, 3), semestral: sumarMeses(d, 6), anual: sumarMeses(d, 12) }[per] || sumarMeses(d, 1);
}
function fijoJSON(f) {
  const dias = f.vence ? diasHasta(hoy(), f.vence) : null;
  const estado = dias === null ? 'sin_fecha' : dias < 0 ? 'vencido' : dias <= (f.dias_aviso ?? 5) ? 'por_vencer' : 'al_corriente';
  const pagos = all('SELECT g.id, g.folio, g.fecha, g.monto, g.metodo, g.notas, g.pagado_con, g.periodo FROM gastos g WHERE g.gasto_fijo_id=? ORDER BY g.fecha DESC LIMIT 24', f.id);
  const ult = pagos.slice(0, 6);
  return { ...f, dias, estado, pagos, promedio: ult.length ? r2(ult.reduce((a, x) => a + x.monto, 0) / ult.length) : 0 };
}
ruta('GET', '/api/gastos/fijos', 'gastos', () => ({ categorias: CATEGORIAS_GASTOS, periodos: PERIODOS_FIJO, lista: all('SELECT * FROM gastos_fijos ORDER BY activo DESC, vence IS NULL, vence, nombre').map(fijoJSON) }));
// Número rojo en el menú: gastos fijos vencidos o por vencer
ruta('GET', '/api/gastos/fijos/avisos', 'sesion', ({ u }) => (u.perm.has('gastos') ? all('SELECT * FROM gastos_fijos WHERE activo=1 AND vence IS NOT NULL').map(fijoJSON).filter((f) => f.estado === 'vencido' || f.estado === 'por_vencer').map(({ pagos, ...f }) => f) : []));
function datosFijo(body) {
  if (!txt(body.nombre)) throw new ErrorUsuario('Escribe qué es el gasto (ej. Luz CFE, Renta del local)');
  const vence = /^\d{4}-\d{2}-\d{2}$/.test(body.vence || '') ? body.vence : null;
  return { nombre: txt(body.nombre).slice(0, 80), categoria: CATEGORIAS_GASTOS.includes(body.categoria) ? body.categoria : 'Gastos varios', monto: num(body.monto), dia: vence ? Number(vence.slice(8)) : (Number(body.dia) || null),
    notas: txt(body.notas), proveedor: txt(body.proveedor)?.slice(0, 80) || null, contrato: txt(body.contrato)?.slice(0, 60) || null, referencia: txt(body.referencia)?.slice(0, 60) || null,
    periodo_pago: PERIODOS_FIJO[body.periodo_pago] ? body.periodo_pago : 'mensual', vence, dias_aviso: Math.max(0, Math.min(60, Number(body.dias_aviso ?? 5) || 0)), domiciliado: body.domiciliado ? 1 : 0 };
}
const FIJO_CAMPOS = ['nombre', 'categoria', 'monto', 'dia', 'notas', 'proveedor', 'contrato', 'referencia', 'periodo_pago', 'vence', 'dias_aviso', 'domiciliado'];
ruta('POST', '/api/gastos/fijos', 'gastos', ({ body }) => { const d = datosFijo(body); return run(`INSERT INTO gastos_fijos(${FIJO_CAMPOS.join(',')},activo,creado) VALUES(${FIJO_CAMPOS.map(() => '?').join(',')},1,?)`, ...FIJO_CAMPOS.map((k) => d[k]), ahora()); });
ruta('PUT', '/api/gastos/fijos/:id', 'gastos', ({ body, p }) => {
  if (body.activo !== undefined && Object.keys(body).length === 1) return run('UPDATE gastos_fijos SET activo=? WHERE id=?', body.activo ? 1 : 0, Number(p.id));
  const d = datosFijo(body);
  return run(`UPDATE gastos_fijos SET ${FIJO_CAMPOS.map((k) => k + '=?').join(',')}, activo=? WHERE id=?`, ...FIJO_CAMPOS.map((k) => d[k]), body.activo === false ? 0 : 1, Number(p.id));
});
ruta('DELETE', '/api/gastos/fijos/:id', 'gastos', ({ p }) => {
  const usado = get('SELECT COUNT(*) n FROM gastos WHERE gasto_fijo_id=?', Number(p.id)).n;
  if (usado) { run('UPDATE gastos_fijos SET activo=0 WHERE id=?', Number(p.id)); return { ok: true, desactivado: true }; }
  return run('DELETE FROM gastos_fijos WHERE id=?', Number(p.id));
});
// Pagar: se registra en Gastos y el vencimiento pasa al siguiente periodo
ruta('POST', '/api/gastos/fijos/:id/pagar', 'gastos', ({ body, p, u }) => {
  const f = get('SELECT * FROM gastos_fijos WHERE id=?', Number(p.id));
  if (!f) throw new ErrorUsuario('Ese gasto fijo ya no existe', 404);
  return tx(() => {
    const g = registrarGasto({ ...body, gasto_fijo_id: f.id, nombre: f.nombre, categoria: f.categoria, periodo: body.periodo,
      notas: [txt(body.periodo_txt), txt(body.notas)].filter(Boolean).join(' · ') || null, recibe: txt(body.recibe) || f.proveedor }, u);
    let siguiente = null;
    if (f.periodo_pago === 'unico') run('UPDATE gastos_fijos SET activo=0 WHERE id=?', f.id);
    else { siguiente = siguienteVence(f.vence, f.periodo_pago); run('UPDATE gastos_fijos SET vence=?, dia=? WHERE id=?', siguiente, Number(siguiente.slice(8)), f.id); }
    return { ...g, siguiente };
  });
});
// Resumen del mes: cada gasto fijo con su pago (si ya se hizo) y los gastos varios
ruta('GET', '/api/gastos', 'gastos', ({ q }) => {
  const per = /^\d{4}-\d{2}$/.test(q.mes || '') ? q.mes : periodoDe();
  const pagos = all('SELECT g.*, u.nombre usuario FROM gastos g LEFT JOIN usuarios u ON u.id=g.usuario_id WHERE g.periodo=? ORDER BY g.fecha DESC, g.id DESC', per).map(sinFirmas);
  const fijos = all('SELECT * FROM gastos_fijos WHERE activo=1 ORDER BY vence IS NULL, vence, nombre').map((f) => {
    const pg = pagos.filter((x) => x.gasto_fijo_id === f.id), fj = fijoJSON(f);
    return { ...fj, historial: fj.pagos, pagos: pg, pagado: r2(pg.reduce((a, x) => a + x.monto, 0)) };
  });
  const varios = pagos.filter((x) => !x.gasto_fijo_id || !fijos.some((f) => f.id === x.gasto_fijo_id));
  const porCat = {};
  for (const x of pagos) porCat[x.categoria || 'Gastos varios'] = r2((porCat[x.categoria || 'Gastos varios'] || 0) + x.monto);
  const hoyS = hoy();
  return {
    mes: per, categorias: CATEGORIAS_GASTOS, periodos: PERIODOS_FIJO, fijos, varios, pagos,
    total: r2(pagos.reduce((a, x) => a + x.monto, 0)),
    total_fijos: r2(fijos.reduce((a, f) => a + f.pagado, 0)), esperado_fijos: r2(fijos.reduce((a, f) => a + (f.monto || 0), 0)),
    pendientes: fijos.filter((f) => !f.pagos.length).length,
    vencidos: fijos.filter((f) => f.estado === 'vencido').length, por_vencer: fijos.filter((f) => f.estado === 'por_vencer').length,
    de_caja: r2(pagos.filter((x) => x.pagado_con === 'caja').reduce((a, x) => a + x.monto, 0)),
    por_categoria: Object.entries(porCat).map(([categoria, total]) => ({ categoria, total })).sort((a, b) => b.total - a.total),
    meses: all(`SELECT periodo, SUM(monto) total FROM gastos GROUP BY periodo ORDER BY periodo DESC LIMIT 12`),
  };
});
ruta('POST', '/api/gastos', 'gastos', ({ body, u }) => registrarGasto(body, u));
const sinFirmas = ({ firma_entrega, firma_recibe, ...g }) => ({ ...g, firmado: !!(firma_entrega && firma_recibe) });
const METODOS_GASTO = { efectivo: 'Efectivo', transferencia: 'Transferencia', tarjeta: 'Tarjeta', cheque: 'Cheque' };
// Firma dibujada en pantalla (imagen PNG)
function firmaPng(v) {
  if (!v) return null;
  if (!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(v) || v.length > 600000) throw new ErrorUsuario('La firma no es válida');
  return v;
}
// Folio consecutivo (G-000001)
function siguienteFolio(clave) {
  run('INSERT INTO folios(clave,n) VALUES(?,1) ON CONFLICT(clave) DO UPDATE SET n=n+1', clave);
  return `${clave}-${String(get('SELECT n FROM folios WHERE clave=?', clave).n).padStart(6, '0')}`;
}
function registrarGasto(body, u, empleadoId = null, proveedorId = null) {
  const monto = num(body.monto);
  if (!(monto > 0)) throw new ErrorUsuario('Escribe el monto del gasto');
  const fijo = body.gasto_fijo_id ? get('SELECT * FROM gastos_fijos WHERE id=?', Number(body.gasto_fijo_id)) : null;
  const nombre = txt(body.nombre) || fijo?.nombre;
  if (!nombre) throw new ErrorUsuario('Escribe el nombre del gasto');
  const categoria = CATEGORIAS_GASTOS.includes(body.categoria) ? body.categoria : (fijo?.categoria || 'Gastos varios');
  const fecha = /^\d{4}-\d{2}-\d{2}$/.test(body.fecha || '') ? body.fecha + ' ' + ahora().slice(11) : ahora();
  const periodo = /^\d{4}-\d{2}$/.test(body.periodo || '') ? body.periodo : periodoDe(fecha);
  const metodo = METODOS_GASTO[body.metodo] ? body.metodo : 'efectivo';
  const deCaja = body.pagado_con === 'caja';
  if (deCaja && metodo !== 'efectivo') throw new ErrorUsuario('Solo los pagos en efectivo pueden salir de la caja del turno');
  return tx(() => {
    let movId = null;
    if (deCaja) {
      if (!u.perm.has('movimientos')) throw new ErrorUsuario('No tienes permiso para sacar dinero de la caja', 403);
      const t = turnoAbierto(u.id);
      if (!t) throw new ErrorUsuario('Para pagarlo con dinero de la caja primero abre tu turno. Si se pagó por fuera (banco, dueño), elige "Pagado por fuera de la caja".');
      movId = run('INSERT INTO movimientos(turno_id,usuario_id,tipo,monto,concepto,fecha,categoria,recibe) VALUES(?,?,?,?,?,?,?,?)', t.id, u.id, 'gasto', monto, `${nombre}${fijo ? ' (gasto fijo)' : ''}`, ahora(), categoria, txt(body.recibe) || null).id;
    }
    const id = run('INSERT INTO gastos(fecha,periodo,nombre,categoria,monto,gasto_fijo_id,pagado_con,movimiento_id,usuario_id,notas,creado,empleado_id,proveedor_id,folio,metodo,entrega,recibe,firma_entrega,firma_recibe) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
      fecha, periodo, nombre, categoria, monto, fijo?.id || null, deCaja ? 'caja' : 'fuera', movId, u.id, txt(body.notas), ahora(), empleadoId, proveedorId,
      siguienteFolio('G'), metodo, txt(body.entrega)?.slice(0, 100) || u.nombre, txt(body.recibe)?.slice(0, 100) || null, firmaPng(body.firma_entrega), firmaPng(body.firma_recibe)).id;
    if (deCaja) avisarPantallas({ tipo: 'caja' });
    return sinFirmas(get('SELECT g.*, u.nombre usuario FROM gastos g LEFT JOIN usuarios u ON u.id=g.usuario_id WHERE g.id=?', id));
  });
}
ruta('DELETE', '/api/gastos/:id', 'gastos', ({ p }) => {
  const g = get('SELECT * FROM gastos WHERE id=?', Number(p.id));
  if (!g) throw new ErrorUsuario('Ese gasto ya no existe', 404);
  return tx(() => {
    if (g.movimiento_id) {
      const m = get('SELECT m.*, t.estado FROM movimientos m JOIN turnos t ON t.id=m.turno_id WHERE m.id=?', g.movimiento_id);
      if (m && m.estado === 'cerrado') throw new ErrorUsuario('Este gasto salió de una caja que ya se cerró; no se puede borrar. Registra una entrada de efectivo si fue un error.');
      if (m) run('DELETE FROM movimientos WHERE id=?', m.id);
    }
    run('DELETE FROM gastos WHERE id=?', g.id);
    return { ok: true };
  });
});

// Recibo de un gasto (con firmas) y agregar firmas después
ruta('GET', '/api/gastos/:id', 'gastos', ({ p }) => {
  const g = get('SELECT g.*, u.nombre usuario, e.nombre empleado, pv.nombre proveedor FROM gastos g LEFT JOIN usuarios u ON u.id=g.usuario_id LEFT JOIN empleados e ON e.id=g.empleado_id LEFT JOIN proveedores pv ON pv.id=g.proveedor_id WHERE g.id=?', Number(p.id));
  if (!g) throw new ErrorUsuario('Ese gasto ya no existe', 404);
  return { ...g, metodo_txt: METODOS_GASTO[g.metodo] || 'Efectivo' };
});
ruta('PUT', '/api/gastos/:id/firmas', 'gastos', ({ body, p }) => {
  const g = get('SELECT id FROM gastos WHERE id=?', Number(p.id)); if (!g) throw new ErrorUsuario('Ese gasto ya no existe', 404);
  run('UPDATE gastos SET firma_entrega=COALESCE(?,firma_entrega), firma_recibe=COALESCE(?,firma_recibe), recibe=COALESCE(?,recibe) WHERE id=?', firmaPng(body.firma_entrega), firmaPng(body.firma_recibe), txt(body.recibe)?.slice(0, 100) || null, g.id);
  return { ok: true };
});

// ---------- Avisos por WhatsApp ----------
ruta('GET', '/api/avisos', 'avisos', ({ q }) => {
  const dias = Number(q.dias) || 5, t = hoy();
  const base = `SELECT c.id, c.nombre, c.telefono, c.whatsapp, c.acepta_publicidad, m.fin,
      (SELECT MAX(fecha) FROM avisos a WHERE a.cliente_id=c.id AND a.tipo=?) ultimo_aviso
    FROM clientes c JOIN (SELECT cliente_id, MAX(fin) fin FROM membresias WHERE cancelada=0 GROUP BY cliente_id) m ON m.cliente_id=c.id
    WHERE COALESCE(c.whatsapp, c.telefono, '')<>''`;
  if (q.tipo === 'vencido') return all(base + ' AND m.fin BETWEEN ? AND ? ORDER BY m.fin DESC', 'vencido', sumarDias(t, -(Number(q.dias) || 30)), sumarDias(t, -1));
  if (q.tipo === 'publicidad') return all(`SELECT c.id, c.nombre, c.telefono, c.whatsapp, (SELECT MAX(fin) FROM membresias WHERE cliente_id=c.id AND cancelada=0) fin,
      (SELECT MAX(fecha) FROM avisos a WHERE a.cliente_id=c.id AND a.tipo='publicidad') ultimo_aviso
    FROM clientes c WHERE c.acepta_publicidad=1 AND COALESCE(c.whatsapp, c.telefono, '')<>'' ORDER BY c.nombre`);
  return all(base + ' AND m.fin BETWEEN ? AND ? ORDER BY m.fin', 'vence', t, sumarDias(t, dias));
});
// Mensajes y la imagen de publicidad se cambian desde el apartado de avisos
ruta('PUT', '/api/avisos/mensajes', 'avisos', ({ body }) => {
  for (const k of ['wa_vence', 'wa_vencida', 'wa_publicidad']) if (typeof body[k] === 'string') setCfg(k, body[k].slice(0, 1500));
  return { ok: true };
});
ruta('POST', '/api/avisos/imagen', 'avisos', ({ body }) => {
  const { buf, ext } = imagenDe(body.imagen, 'La imagen');
  for (const e of ['jpg', 'png']) { const f = path.join(DATA_DIR, 'publicidad.' + e); if (fs.existsSync(f)) fs.unlinkSync(f); }
  fs.writeFileSync(path.join(DATA_DIR, 'publicidad.' + ext), buf);
  setCfg('wa_imagen', 'publicidad.' + ext + '?v=' + Date.now());
  return { ok: true, imagen: cfg('wa_imagen') };
});
ruta('DELETE', '/api/avisos/imagen', 'avisos', () => {
  for (const e of ['jpg', 'png']) { const f = path.join(DATA_DIR, 'publicidad.' + e); if (fs.existsSync(f)) fs.unlinkSync(f); }
  setCfg('wa_imagen', '');
  return { ok: true };
});
ruta('POST', '/api/avisos', 'avisos', ({ body }) => run('INSERT INTO avisos(cliente_id,tipo,fecha) VALUES(?,?,?)', Number(body.cliente_id), txt(body.tipo), ahora()));

// ---------- Accesos y reportes ----------
ruta('GET', '/api/visitas', 'accesos', ({ q }) => all(`SELECT v.*, c.nombre FROM visitas v LEFT JOIN clientes c ON c.id=v.cliente_id
  WHERE substr(v.fecha,1,10)=? ORDER BY v.id DESC LIMIT 500`, q.fecha || hoy()));
ruta('GET', '/api/inicio', 'inicio', () => {
  const t = hoy();
  return {
    activos: all(`SELECT DISTINCT cliente_id FROM membresias WHERE cancelada=0 AND inicio<=? AND fin>=?`, t, t).length,
    vencen_semana: get(`SELECT COUNT(*) n FROM (SELECT cliente_id, MAX(fin) fin FROM membresias WHERE cancelada=0 GROUP BY cliente_id) WHERE fin BETWEEN ? AND ?`, t, sumarDias(t, 7)).n,
    visitas_hoy: get(`SELECT COUNT(DISTINCT cliente_id) n FROM visitas WHERE resultado='permitido' AND substr(fecha,1,10)=?`, t).n,
    ventas_hoy: r2(get(`SELECT COALESCE(SUM(total),0) s FROM ventas WHERE cancelada=0 AND substr(fecha,1,10)=?`, t).s),
    por_cobrar: r2(get('SELECT COALESCE(SUM(credito_pendiente),0) s FROM ventas WHERE cancelada=0').s),
    stock_bajo: all('SELECT id, nombre, existencia, minimo FROM productos WHERE activo=1 AND existencia<=minimo ORDER BY existencia LIMIT 10'),
    sin_sincronizar: get('SELECT COUNT(*) n FROM clientes WHERE sincronizado=0').n,
  };
});
ruta('GET', '/api/reportes', 'reportes', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || hoy();
  const rango = 'cancelada=0 AND substr(fecha,1,10) BETWEEN ? AND ?';
  return {
    ventas: get(`SELECT COUNT(*) n, COALESCE(SUM(total),0) total, COALESCE(SUM(pago_efectivo-cambio),0) efectivo, COALESCE(SUM(pago_usd),0) usd,
      COALESCE(SUM(pago_usd*tipo_cambio),0) usd_mxn, COALESCE(SUM(pago_tarjeta),0) tarjeta, COALESCE(SUM(pago_transferencia),0) transferencia, COALESCE(SUM(pago_credito),0) credito FROM ventas WHERE ${rango}`, d, h),
    abonos: get('SELECT COUNT(*) n, COALESCE(SUM(monto),0) total FROM abonos WHERE substr(fecha,1,10) BETWEEN ? AND ?', d, h),
    productos: all(`SELECT i.descripcion, SUM(i.cantidad) cantidad, SUM(i.importe) importe, SUM(i.importe - i.costo*i.cantidad) utilidad
      FROM venta_items i JOIN ventas v ON v.id=i.venta_id WHERE i.tipo='producto' AND v.${rango.replace('substr(fecha', 'substr(v.fecha')} GROUP BY i.producto_id ORDER BY importe DESC`, d, h),
    membresias: all(`SELECT p.nombre plan, COALESCE(pr.nombre,'Sin promoción') promo, COUNT(*) n, SUM(m.precio) total FROM membresias m
      JOIN planes p ON p.id=m.plan_id LEFT JOIN promociones pr ON pr.id=m.promo_id WHERE m.cancelada=0 AND m.venta_id IS NOT NULL AND substr(m.creado,1,10) BETWEEN ? AND ?
      GROUP BY p.id, pr.id ORDER BY total DESC`, d, h),
    visitas: all(`SELECT substr(fecha,1,10) dia, COUNT(DISTINCT cliente_id) personas, SUM(resultado='denegado') negados FROM visitas
      WHERE substr(fecha,1,10) BETWEEN ? AND ? GROUP BY dia ORDER BY dia`, d, h),
    nuevos: get('SELECT COUNT(*) n FROM clientes WHERE substr(creado,1,10) BETWEEN ? AND ?', d, h).n,
    movimientos: all(`SELECT tipo, COALESCE(categoria,'') categoria, COUNT(*) n, SUM(monto) total FROM movimientos WHERE substr(fecha,1,10) BETWEEN ? AND ? GROUP BY tipo, categoria ORDER BY tipo, total DESC`, d, h),
  };
});

// Datos completos para exportar a Excel (cada reporte por separado)
const formaPago = (v) => {
  const f = [];
  if (v.pago_efectivo - v.cambio > 0.009 || (v.pago_efectivo > 0 && !v.pago_usd && !v.pago_tarjeta && !v.pago_transferencia && !v.pago_credito)) f.push('Efectivo');
  if (v.pago_usd > 0) f.push('Dólares'); if (v.pago_tarjeta > 0) f.push('Tarjeta'); if (v.pago_transferencia > 0) f.push('Transferencia'); if (v.pago_credito > 0) f.push('Crédito');
  return f.join(' + ') || 'Efectivo';
};
// Lo usan Reportes (computadora) y el panel del celular
ruta('GET', '/api/reportes/excel', 'sesion', ({ q, u }) => {
  if (!u.perm.has('reportes') && !u.perm.has('movil')) throw new ErrorUsuario('No tienes permiso para ver reportes', 403);
  const d = q.desde || hoy(), h = q.hasta || hoy();
  if (q.tipo === 'cierre') {
    const n = diasEntre(d, h), antD = sumarDias(d, -n), antH = sumarDias(h, -n), t = hoy();
    const resumen = resumenRango(d, h), anterior = resumenRango(antD, antH);
    const dias = Object.fromEntries(all(`SELECT substr(fecha,1,10) k, COUNT(*) n, SUM(total) total, SUM(pago_efectivo-cambio) efectivo, SUM(pago_usd*tipo_cambio) usd_mxn, SUM(pago_tarjeta) tarjeta, SUM(pago_transferencia) transferencia, SUM(pago_credito) credito
      FROM ventas WHERE cancelada=0 AND substr(fecha,1,10) BETWEEN ? AND ? GROUP BY k`, d, h).map((r) => [r.k, r]));
    const diasIt = Object.fromEntries(all(`SELECT substr(v.fecha,1,10) k, SUM(CASE WHEN i.tipo='producto' THEN i.importe END) productos, SUM(CASE WHEN i.tipo='membresia' THEN i.importe END) membresias
      FROM venta_items i JOIN ventas v ON v.id=i.venta_id WHERE v.cancelada=0 AND substr(v.fecha,1,10) BETWEEN ? AND ? GROUP BY k`, d, h).map((r) => [r.k, r]));
    const diasAb = Object.fromEntries(all(`SELECT substr(fecha,1,10) k, SUM(monto) s FROM abonos WHERE substr(fecha,1,10) BETWEEN ? AND ? GROUP BY k`, d, h).map((r) => [r.k, r.s]));
    const diasMov = Object.fromEntries(all(`SELECT substr(fecha,1,10) k, SUM(CASE WHEN tipo='entrada' THEN monto ELSE -monto END) s FROM movimientos WHERE substr(fecha,1,10) BETWEEN ? AND ? GROUP BY k`, d, h).map((r) => [r.k, r.s]));
    const diasVis = Object.fromEntries(all(`SELECT substr(fecha,1,10) k, COUNT(DISTINCT cliente_id) p FROM visitas WHERE resultado='permitido' AND substr(fecha,1,10) BETWEEN ? AND ? GROUP BY k`, d, h).map((r) => [r.k, r.p]));
    const por_dia = [];
    for (let x = d; x <= h; x = sumarDias(x, 1)) {
      const v = dias[x] || {}, it = diasIt[x] || {};
      por_dia.push({ dia: x, n: v.n || 0, total: r2(v.total), productos: r2(it.productos), membresias: r2(it.membresias), efectivo: r2(v.efectivo), usd_mxn: r2(v.usd_mxn), tarjeta: r2(v.tarjeta), transferencia: r2(v.transferencia), credito: r2(v.credito),
        abonos: r2(diasAb[x]), caja: r2(diasMov[x]), personas: diasVis[x] || 0 });
    }
    return {
      desde: d, hasta: h, dias: n, generado: ahora(), gym: cfg('gym_nombre'), resumen, anterior: { desde: antD, hasta: antH, total: anterior.ventas.total, n: anterior.ventas.n },
      por_dia,
      canceladas: get(`SELECT COUNT(*) n, COALESCE(SUM(total),0) total FROM ventas WHERE cancelada=1 AND substr(fecha,1,10) BETWEEN ? AND ?`, d, h),
      membresias: all(`SELECT p.nombre plan, COALESCE(pr.nombre,'Sin promoción') promo, COUNT(*) n, SUM(m.precio) total FROM membresias m JOIN planes p ON p.id=m.plan_id LEFT JOIN promociones pr ON pr.id=m.promo_id
        WHERE m.cancelada=0 AND m.venta_id IS NOT NULL AND substr(m.creado,1,10) BETWEEN ? AND ? GROUP BY p.id, pr.id ORDER BY total DESC`, d, h),
      productos: all(`SELECT i.descripcion producto, SUM(i.cantidad) cantidad, SUM(i.importe) importe, SUM(i.costo*i.cantidad) costo, SUM(i.importe - i.costo*i.cantidad) utilidad FROM venta_items i JOIN ventas v ON v.id=i.venta_id
        WHERE i.tipo='producto' AND v.cancelada=0 AND substr(v.fecha,1,10) BETWEEN ? AND ? GROUP BY i.producto_id, i.descripcion ORDER BY importe DESC`, d, h),
      gastos: all(`SELECT tipo, COALESCE(categoria, CASE tipo WHEN 'retiro' THEN 'Retiro de efectivo' ELSE 'Entrada de efectivo' END) categoria, COUNT(*) n, SUM(monto) total
        FROM movimientos WHERE substr(fecha,1,10) BETWEEN ? AND ? GROUP BY tipo, 2 ORDER BY tipo, total DESC`, d, h),
      cortes: all(`SELECT t.id, t.abierto, t.cerrado, t.estado, t.tipo_cambio, u.nombre cajero, t.decl_efectivo, t.esp_efectivo, t.decl_usd, t.esp_usd, t.decl_tarjeta, t.esp_tarjeta FROM turnos t JOIN usuarios u ON u.id=t.usuario_id
        WHERE substr(t.abierto,1,10) BETWEEN ? AND ? ORDER BY t.abierto`, d, h).map((c) => ({ ...c, ventas: esperado(c).ventas_total,
        diferencia: c.estado === 'cerrado' ? r2((c.decl_efectivo - c.esp_efectivo) + (c.decl_usd - c.esp_usd) * c.tipo_cambio + (c.decl_tarjeta - c.esp_tarjeta)) : null })),
      cajeros: all(`SELECT u.nombre cajero, COUNT(*) n, SUM(v.total) total FROM ventas v JOIN usuarios u ON u.id=v.usuario_id WHERE v.cancelada=0 AND substr(v.fecha,1,10) BETWEEN ? AND ? GROUP BY u.id ORDER BY total DESC`, d, h),
      socios: {
        activos: all(`SELECT DISTINCT cliente_id FROM membresias WHERE cancelada=0 AND inicio<=? AND fin>=?`, t, t).length,
        activos_fin: all(`SELECT DISTINCT cliente_id FROM membresias WHERE cancelada=0 AND inicio<=? AND fin>=?`, h, h).length,
        activos_inicio: all(`SELECT DISTINCT cliente_id FROM membresias WHERE cancelada=0 AND inicio<=? AND fin>=?`, d, d).length,
        nuevos: get('SELECT COUNT(*) n FROM clientes WHERE substr(creado,1,10) BETWEEN ? AND ?', d, h).n,
        vencidos: get(`SELECT COUNT(*) n FROM (SELECT cliente_id, MAX(fin) fin FROM membresias WHERE cancelada=0 GROUP BY cliente_id) WHERE fin BETWEEN ? AND ?`, d, h).n,
        asistentes: get(`SELECT COUNT(DISTINCT cliente_id) n FROM visitas WHERE resultado='permitido' AND substr(fecha,1,10) BETWEEN ? AND ?`, d, h).n,
        entradas: get(`SELECT COUNT(*) n FROM visitas WHERE resultado='permitido' AND substr(fecha,1,10) BETWEEN ? AND ?`, d, h).n,
        total: get('SELECT COUNT(*) n FROM clientes').n,
      },
      por_cobrar: r2(get('SELECT COALESCE(SUM(credito_pendiente),0) s FROM ventas WHERE cancelada=0').s),
      por_cobrar_n: get('SELECT COUNT(DISTINCT cliente_id) n FROM ventas WHERE cancelada=0 AND credito_pendiente>0.009').n,
      inventario: get('SELECT COALESCE(SUM(costo*MAX(existencia,0)),0) costo, COALESCE(SUM(precio*MAX(existencia,0)),0) venta, SUM(existencia<=minimo) bajos FROM productos WHERE activo=1'),
      // Gastos del negocio registrados en el apartado Gastos (fijos y varios), por fecha de pago
      gastos_negocio: all(`SELECT g.fecha, g.nombre, g.categoria, g.monto, g.pagado_con, CASE WHEN g.gasto_fijo_id IS NULL THEN 0 ELSE 1 END fijo FROM gastos g WHERE substr(g.fecha,1,10) BETWEEN ? AND ? ORDER BY g.fecha`, d, h),
      gastos_negocio_cat: all(`SELECT COALESCE(categoria,'Gastos varios') categoria, COUNT(*) n, SUM(monto) total FROM gastos WHERE substr(fecha,1,10) BETWEEN ? AND ? GROUP BY 1 ORDER BY total DESC`, d, h),
      unidades: unidadesNegocio(d, h),
      unidades_meses: unidadesMeses(h, 6),
      departamentos: ventasDepto(d, h),
      nomina: resumenNomina(d, h),
      cuentas: resumenCuentas(d, h),
    };
  }
  if (q.tipo === 'gastos') {
    return {
      detalle: all(`SELECT m.*, u.nombre cajero FROM movimientos m LEFT JOIN usuarios u ON u.id=m.usuario_id WHERE substr(m.fecha,1,10) BETWEEN ? AND ? ORDER BY m.fecha`, d, h),
      por_categoria: all(`SELECT tipo, COALESCE(categoria, CASE tipo WHEN 'retiro' THEN 'Retiro de efectivo' ELSE 'Entrada de efectivo' END) categoria, COUNT(*) n, SUM(monto) total
        FROM movimientos WHERE substr(fecha,1,10) BETWEEN ? AND ? GROUP BY tipo, 2 ORDER BY tipo, total DESC`, d, h),
    };
  }
  if (q.tipo === 'cortes') {
    return {
      cortes: all(`SELECT t.*, u.nombre cajero FROM turnos t JOIN usuarios u ON u.id=t.usuario_id WHERE substr(t.abierto,1,10) BETWEEN ? AND ? ORDER BY t.abierto`, d, h)
        .map((t) => ({ ...t, ...Object.fromEntries(Object.entries(esperado(t)).map(([k, x]) => ['r_' + k, x])) })),
    };
  }
  if (q.tipo === 'adeudos') {
    return {
      clientes: all(`SELECT c.id, c.nombre, c.telefono, c.whatsapp, SUM(v.credito_pendiente) saldo, MIN(v.fecha) desde, MAX(v.fecha) ultima, COUNT(*) ventas
        FROM ventas v JOIN clientes c ON c.id=v.cliente_id WHERE v.cancelada=0 AND v.credito_pendiente>0.009 GROUP BY c.id ORDER BY saldo DESC`),
      detalle: all(`SELECT v.id ticket, v.fecha, c.nombre cliente, v.total, v.pago_credito, v.credito_pendiente, u.nombre cajero,
          (SELECT GROUP_CONCAT(CASE WHEN cantidad<>1 THEN printf('%g', cantidad) || ' x ' ELSE '' END || descripcion, ', ') FROM venta_items WHERE venta_id=v.id) detalle
        FROM ventas v JOIN clientes c ON c.id=v.cliente_id LEFT JOIN usuarios u ON u.id=v.usuario_id WHERE v.cancelada=0 AND v.credito_pendiente>0.009 ORDER BY c.nombre, v.fecha`),
    };
  }
  if (q.tipo === 'socios') {
    const t = hoy();
    return {
      hoy: t,
      lista: all(`SELECT c.id, c.nombre, c.telefono, c.whatsapp, c.correo, c.estudiante, c.vecino, c.bloqueado, m.fin, m.inicio,
          (SELECT p.nombre FROM membresias mm JOIN planes p ON p.id=mm.plan_id WHERE mm.cliente_id=c.id AND mm.cancelada=0 ORDER BY mm.fin DESC LIMIT 1) plan,
          (SELECT MAX(fecha) FROM visitas WHERE cliente_id=c.id AND resultado='permitido') ultima_visita
        FROM clientes c LEFT JOIN (SELECT cliente_id, MAX(fin) fin, MIN(inicio) inicio FROM membresias WHERE cancelada=0 GROUP BY cliente_id) m ON m.cliente_id=c.id
        ORDER BY m.fin IS NULL, m.fin`),
    };
  }
  if (q.tipo === 'inventario') {
    return { lista: all(`SELECT codigo, nombre, COALESCE(NULLIF(area,''),'Sin departamento') area, costo, precio, existencia, minimo, activo FROM productos ORDER BY activo DESC, area IS NULL, area COLLATE NOCASE, nombre COLLATE NOCASE`) };
  }
  if (q.tipo === 'empleados') return resumenNomina(d, h);
  if (q.tipo === 'cuentas') return { ...resumenCuentas(d, h), pagos: all(`SELECT cp.fecha, cp.monto, c.concepto, c.factura, pv.nombre proveedor, g.pagado_con FROM cuentas_pagos cp JOIN cuentas_pagar c ON c.id=cp.cuenta_id LEFT JOIN proveedores pv ON pv.id=c.proveedor_id LEFT JOIN gastos g ON g.id=cp.gasto_id WHERE substr(cp.fecha,1,10) BETWEEN ? AND ? ORDER BY cp.fecha`, d, h) };
  if (q.tipo === 'unidades') return { unidades: unidadesNegocio(d, h), meses: unidadesMeses(h, 12), departamentos: ventasDepto(d, h) };
  if (q.tipo === 'productos') {
    return {
      detalle: all(`SELECT v.id ticket, v.fecha, i.descripcion producto, p.codigo, i.cantidad, i.precio, i.costo, i.importe, (i.importe - i.costo*i.cantidad) utilidad,
          c.nombre cliente, u.nombre cajero, v.pago_efectivo, v.pago_usd, v.pago_tarjeta, v.pago_transferencia, v.pago_credito, v.cambio, v.referencia
        FROM venta_items i JOIN ventas v ON v.id=i.venta_id LEFT JOIN productos p ON p.id=i.producto_id LEFT JOIN clientes c ON c.id=v.cliente_id LEFT JOIN usuarios u ON u.id=v.usuario_id
        WHERE i.tipo='producto' AND v.cancelada=0 AND substr(v.fecha,1,10) BETWEEN ? AND ? ORDER BY v.fecha`, d, h).map((x) => ({ ...x, forma: formaPago(x) })),
      resumen: all(`SELECT p.codigo, i.descripcion producto, SUM(i.cantidad) cantidad, SUM(i.importe) importe, SUM(i.costo*i.cantidad) costo, SUM(i.importe - i.costo*i.cantidad) utilidad, p.existencia
        FROM venta_items i JOIN ventas v ON v.id=i.venta_id LEFT JOIN productos p ON p.id=i.producto_id
        WHERE i.tipo='producto' AND v.cancelada=0 AND substr(v.fecha,1,10) BETWEEN ? AND ? GROUP BY i.producto_id, i.descripcion ORDER BY importe DESC`, d, h),
    };
  }
  if (q.tipo === 'membresias') {
    return {
      detalle: all(`SELECT m.venta_id ticket, m.creado fecha, c.nombre cliente, c.telefono, p.nombre plan, COALESCE(pr.nombre,'') promo, COALESCE(pc.nombre,'') pareja,
          m.inicio, m.fin, m.precio, u.nombre cajero, c.estudiante, c.vecino
        FROM membresias m JOIN clientes c ON c.id=m.cliente_id JOIN planes p ON p.id=m.plan_id LEFT JOIN promociones pr ON pr.id=m.promo_id
        LEFT JOIN clientes pc ON pc.id=m.pareja_cliente_id LEFT JOIN ventas v ON v.id=m.venta_id LEFT JOIN usuarios u ON u.id=v.usuario_id
        WHERE m.cancelada=0 AND m.venta_id IS NOT NULL AND substr(m.creado,1,10) BETWEEN ? AND ? ORDER BY m.creado`, d, h),
      resumen: all(`SELECT p.nombre plan, COALESCE(pr.nombre,'Sin promoción') promo, COUNT(*) n, SUM(m.precio) total FROM membresias m
        JOIN planes p ON p.id=m.plan_id LEFT JOIN promociones pr ON pr.id=m.promo_id WHERE m.cancelada=0 AND m.venta_id IS NOT NULL AND substr(m.creado,1,10) BETWEEN ? AND ?
        GROUP BY p.id, pr.id ORDER BY total DESC`, d, h),
    };
  }
  if (q.tipo === 'asistencias') {
    return {
      detalle: all(`SELECT v.fecha, c.id cliente_id, COALESCE(c.nombre,'(sin cliente)') cliente, v.resultado, v.origen, v.motivo FROM visitas v
        LEFT JOIN clientes c ON c.id=v.cliente_id WHERE substr(v.fecha,1,10) BETWEEN ? AND ? ORDER BY v.fecha`, d, h),
      por_dia: all(`SELECT substr(fecha,1,10) dia, COUNT(DISTINCT CASE WHEN resultado='permitido' THEN cliente_id END) personas,
          SUM(resultado='permitido') entradas, SUM(resultado='denegado') negados FROM visitas WHERE substr(fecha,1,10) BETWEEN ? AND ? GROUP BY dia ORDER BY dia`, d, h),
      por_hora: all(`SELECT substr(fecha,12,2) hora, SUM(resultado='permitido') entradas FROM visitas WHERE substr(fecha,1,10) BETWEEN ? AND ? GROUP BY hora ORDER BY hora`, d, h),
      por_cliente: all(`SELECT c.id, c.nombre, COUNT(DISTINCT substr(v.fecha,1,10)) dias, COUNT(*) entradas, MAX(v.fecha) ultima FROM visitas v JOIN clientes c ON c.id=v.cliente_id
        WHERE v.resultado='permitido' AND substr(v.fecha,1,10) BETWEEN ? AND ? GROUP BY c.id ORDER BY dias DESC, c.nombre`, d, h),
    };
  }
  if (q.tipo === 'ventas') {
    return {
      tickets: all(`SELECT v.*, c.nombre cliente, u.nombre cajero, (SELECT GROUP_CONCAT(CASE WHEN cantidad<>1 THEN printf('%g', cantidad) || ' x ' ELSE '' END || descripcion, ', ') FROM venta_items WHERE venta_id=v.id) detalle,
          (SELECT COALESCE(SUM(importe),0) FROM venta_items WHERE venta_id=v.id AND tipo='producto') productos,
          (SELECT COALESCE(SUM(importe),0) FROM venta_items WHERE venta_id=v.id AND tipo='membresia') membresias
        FROM ventas v LEFT JOIN clientes c ON c.id=v.cliente_id LEFT JOIN usuarios u ON u.id=v.usuario_id
        WHERE substr(v.fecha,1,10) BETWEEN ? AND ? ORDER BY v.fecha`, d, h),
      abonos: all(`SELECT a.*, c.nombre cliente, u.nombre cajero FROM abonos a LEFT JOIN clientes c ON c.id=a.cliente_id LEFT JOIN usuarios u ON u.id=a.usuario_id
        WHERE substr(a.fecha,1,10) BETWEEN ? AND ? ORDER BY a.fecha`, d, h),
      cortes: all(`SELECT t.*, u.nombre cajero FROM turnos t JOIN usuarios u ON u.id=t.usuario_id WHERE substr(t.abierto,1,10) BETWEEN ? AND ? ORDER BY t.abierto`, d, h),
    };
  }
  throw new ErrorUsuario('Tipo de reporte inválido');
});

// ---------- Importar productos desde Excel ----------
ruta('POST', '/api/productos/importar', 'productos_editar', ({ body }) => {
  const filas = Array.isArray(body.filas) ? body.filas : [];
  if (!filas.length) throw new ErrorUsuario('No hay productos para importar');
  const n = (v) => { const x = Number(String(v ?? '').replace(/[$,\s]/g, '')); return isFinite(x) ? x : NaN; };
  const res = { nuevos: 0, actualizados: 0, errores: [] };
  tx(() => {
    for (const f of filas) {
      const codigo = txt(f.codigo) || null, nombre = txt(f.nombre);
      const precio = n(f.precio), costo = String(f.costo ?? '').trim() === '' ? null : n(f.costo);
      const exist = String(f.existencia ?? '').trim() === '' ? null : n(f.existencia), minimo = String(f.minimo ?? '').trim() === '' ? null : n(f.minimo);
      if (!nombre) { res.errores.push(`Fila ${f.fila}: falta el nombre`); continue; }
      if (!(precio > 0)) { res.errores.push(`Fila ${f.fila} (${nombre}): precio de venta inválido`); continue; }
      if ([costo, exist, minimo].some((x) => x !== null && isNaN(x))) { res.errores.push(`Fila ${f.fila} (${nombre}): costo, existencias o mínimo no es número`); continue; }
      const ya = codigo ? get('SELECT id FROM productos WHERE codigo=?', codigo) : get('SELECT id FROM productos WHERE codigo IS NULL AND lower(nombre)=lower(?)', nombre);
      if (ya) {
        run(`UPDATE productos SET nombre=?, precio=?, costo=COALESCE(?,costo), existencia=COALESCE(?,existencia), minimo=COALESCE(?,minimo), area=COALESCE(?,area), activo=1 WHERE id=?`,
          nombre, r2(precio), costo === null ? null : r2(costo), exist, minimo, nombreDepto(f.area), ya.id);
        res.actualizados++;
      } else {
        run('INSERT INTO productos(codigo,nombre,costo,precio,existencia,minimo,area) VALUES(?,?,?,?,?,?,?)', codigo, nombre, r2(costo || 0), r2(precio), exist || 0, minimo || 0, nombreDepto(f.area));
        res.nuevos++;
      }
    }
  });
  return res;
});

// ---------- Eventos que manda el lector (sin sesión) ----------
async function recibirEventoLector(req, res) {
  const buf = await leerCuerpo(req, 6 * 1024 * 1024);
  res.writeHead(200, { 'Content-Type': 'text/plain' }); res.end('OK');
  try {
    const ct = String(req.headers['content-type'] || '');
    const textos = ct.includes('multipart') ? leerMultipart(buf, ct).filter((p) => !p.tipo.includes('image')).map((p) => p.datos.toString()) : [buf.toString()];
    for (const t of textos) {
      const s = t.trim();
      if (s.startsWith('{')) {
        const j = JSON.parse(s);
        if (j.AccessControllerEvent) eventoLector({ ...j.AccessControllerEvent, dateTime: j.dateTime });
      } else if (s.startsWith('<')) {
        const v = (tag) => (new RegExp(`<${tag}>([^<]*)</${tag}>`).exec(s) || [])[1];
        if (v('majorEventType')) eventoLector({ majorEventType: v('majorEventType'), subEventType: v('subEventType'), employeeNoString: v('employeeNoString'), serialNo: v('serialNo'), dateTime: v('dateTime') });
      }
    }
    lectorEstado.ultimo = ahora();
  } catch (e) { console.error('Evento del lector no reconocido:', e.message); }
}

// ---------- Panel del dueño en el celular (/movil) ----------
// Totales de un periodo. "hastaHora" corta el último día a esa hora (para comparar "hoy hasta ahora" contra antes)
function resumenRango(d, h, hastaHora = '99') {
  const w = (c = 'fecha') => `substr(${c},1,10) BETWEEN ? AND ? AND (substr(${c},1,10) < ? OR substr(${c},12,2) <= ?)`;
  const p = [d, h, h, hastaHora];
  const v = get(`SELECT COUNT(*) n, COALESCE(SUM(total),0) total, COALESCE(SUM(pago_efectivo-cambio),0) efectivo, COALESCE(SUM(pago_usd),0) usd,
    COALESCE(SUM(pago_usd*tipo_cambio),0) usd_mxn, COALESCE(SUM(pago_tarjeta),0) tarjeta, COALESCE(SUM(pago_transferencia),0) transferencia, COALESCE(SUM(pago_credito),0) credito FROM ventas WHERE cancelada=0 AND ${w()}`, ...p);
  const it = get(`SELECT COALESCE(SUM(CASE WHEN i.tipo='producto' THEN i.importe END),0) productos, COALESCE(SUM(CASE WHEN i.tipo='membresia' THEN i.importe END),0) membresias,
    COALESCE(SUM(CASE WHEN i.tipo='producto' THEN i.importe - i.costo*i.cantidad END),0) utilidad, COALESCE(SUM(CASE WHEN i.tipo='membresia' THEN 1 END),0) membresias_n,
    COALESCE(SUM(CASE WHEN i.tipo='producto' THEN i.cantidad END),0) piezas
    FROM venta_items i JOIN ventas v ON v.id=i.venta_id WHERE v.cancelada=0 AND ${w('v.fecha')}`, ...p);
  const a = get(`SELECT COUNT(*) n, COALESCE(SUM(monto),0) total, COALESCE(SUM(efectivo-cambio),0) efectivo, COALESCE(SUM(usd),0) usd, COALESCE(SUM(tarjeta),0) tarjeta, COALESCE(SUM(transferencia),0) transferencia FROM abonos WHERE ${w()}`, ...p);
  const m = get(`SELECT COALESCE(SUM(CASE WHEN tipo='retiro' THEN monto END),0) retiros, COALESCE(SUM(CASE WHEN tipo='gasto' THEN monto END),0) gastos,
    COALESCE(SUM(CASE WHEN tipo='entrada' THEN monto END),0) entradas, COUNT(*) n FROM movimientos WHERE ${w()}`, ...p);
  const red = (o) => Object.fromEntries(Object.entries(o).map(([k, x]) => [k, typeof x === 'number' ? r2(x) : x]));
  return { ventas: red(v), items: red(it), abonos: red(a), caja: red(m), cobrado: r2(v.total - v.credito + a.total) };
}
const diasEntre = (d, h) => Math.round((new Date(h + 'T12:00:00') - new Date(d + 'T12:00:00')) / 86400000) + 1;
ruta('GET', '/api/movil/resumen', 'movil', ({ q }) => {
  const t = hoy(), esFecha = (x) => /^\d{4}-\d{2}-\d{2}$/.test(x || '');
  let d = esFecha(q.desde) ? q.desde : esFecha(q.fecha) ? q.fecha : t;
  let h = esFecha(q.hasta) ? q.hasta : d;
  if (h < d) [d, h] = [h, d];
  if (h > t) h = t;
  if (d > t) d = t;
  const n = diasEntre(d, h);
  if (n > 400) throw new ErrorUsuario('Elige un periodo de máximo un año');
  const incluyeHoy = h === t, hora = incluyeHoy ? ahora().slice(11, 13) : '99';
  // periodo anterior del mismo tamaño (si incluye hoy, se compara hasta la misma hora)
  const antD = sumarDias(d, -n), antH = sumarDias(h, -n);
  const sem = n === 1 ? resumenRango(sumarDias(d, -7), sumarDias(h, -7), hora).ventas.total : null;
  let grafica;
  if (n === 1) {
    grafica = { tipo: 'hora', valores: Array(24).fill(0) };
    for (const r of all(`SELECT CAST(substr(fecha,12,2) AS INTEGER) k, SUM(total) s FROM ventas WHERE cancelada=0 AND substr(fecha,1,10)=? GROUP BY k`, d)) grafica.valores[r.k] = r2(r.s);
  } else {
    const mapa = Object.fromEntries(all(`SELECT substr(fecha,1,10) k, SUM(total) s, COUNT(*) n FROM ventas WHERE cancelada=0 AND substr(fecha,1,10) BETWEEN ? AND ? GROUP BY k`, d, h).map((r) => [r.k, r]));
    grafica = { tipo: 'dia', valores: [] };
    for (let x = d; x <= h; x = sumarDias(x, 1)) grafica.valores.push({ dia: x, total: r2(mapa[x]?.s || 0), n: mapa[x]?.n || 0 });
  }
  return {
    gym: cfg('gym_nombre'), logo: cfg('gym_logo') ? '/logo-gym?' + String(cfg('gym_logo')).split('?')[1] : null, desde: d, hasta: h, dias: n, hoy: t, incluye_hoy: incluyeHoy, es_hoy: n === 1 && incluyeHoy, fecha: d, generado: ahora(),
    dia: resumenRango(d, h),
    anterior: { desde: antD, hasta: antH, total: resumenRango(antD, antH, hora).ventas.total },
    semana_pasada: sem,
    grafica,
    unidades: unidadesNegocio(d, h),
    unidades_meses: unidadesMeses(h, 6),
    cuentas: !moduloActivo('gastos') ? null : (() => { const c = resumenCuentas(d, h); return { ...c, lista: c.lista.filter((x) => x.estado === 'vencida' || x.por_vencer).slice(0, 20) }; })(),
    nomina: !moduloActivo('gastos') ? null : (() => { const n2 = resumenNomina(d, h); return { total: n2.total, nomina_mensual: n2.nomina_mensual, activos: n2.activos, dias: n2.dias.map((x) => ({ empleado: x.empleado, tipo: x.tipo, desde: x.desde, hasta: x.hasta, dias: x.en_periodo })), pagos: n2.pagos.map((g) => ({ fecha: g.fecha, nombre: g.nombre, monto: g.monto })) }; })(),
    turnos: all(`SELECT t.*, u.nombre cajero FROM turnos t JOIN usuarios u ON u.id=t.usuario_id WHERE t.estado='abierto' ORDER BY t.abierto`)
      .map((x) => { const e = esperado(x); return { id: x.id, cajero: x.cajero, abierto: x.abierto, ventas: e.ventas_total, ventas_n: e.ventas_n, efectivo: e.efectivo, usd: e.usd, tarjeta: e.tarjeta, transferencia: e.transferencia, retiros: r2(e.retiros + e.gastos) }; }),
    cortes: all(`SELECT t.id, t.abierto, t.cerrado, t.tipo_cambio, u.nombre cajero, t.decl_efectivo, t.esp_efectivo, t.decl_usd, t.esp_usd, t.decl_tarjeta, t.esp_tarjeta
      FROM turnos t JOIN usuarios u ON u.id=t.usuario_id WHERE t.estado='cerrado' AND substr(t.cerrado,1,10) BETWEEN ? AND ? ORDER BY t.cerrado DESC LIMIT 60`, d, h)
      .map((x) => ({ id: x.id, cajero: x.cajero, abierto: x.abierto, cerrado: x.cerrado,
        diferencia: r2((x.decl_efectivo - x.esp_efectivo) + (x.decl_usd - x.esp_usd) * x.tipo_cambio + (x.decl_tarjeta - x.esp_tarjeta)) })),
    ventas: all(`SELECT v.id, v.fecha, v.total, v.cancelada, v.pago_efectivo, v.pago_usd, v.pago_tarjeta, v.pago_transferencia, v.pago_credito, v.cambio, v.referencia, c.nombre cliente, u.nombre cajero,
      (SELECT GROUP_CONCAT(CASE WHEN tipo='producto' THEN printf('%g', cantidad) || ' x ' || descripcion ELSE descripcion END, ', ') FROM venta_items WHERE venta_id=v.id) detalle
      FROM ventas v LEFT JOIN clientes c ON c.id=v.cliente_id LEFT JOIN usuarios u ON u.id=v.usuario_id WHERE substr(v.fecha,1,10) BETWEEN ? AND ? ORDER BY v.id DESC LIMIT 100`, d, h)
      .map((x) => ({ ...x, forma: formaPago(x) })),
    abonos: all(`SELECT a.fecha, a.monto, c.nombre cliente, u.nombre cajero FROM abonos a LEFT JOIN clientes c ON c.id=a.cliente_id LEFT JOIN usuarios u ON u.id=a.usuario_id
      WHERE substr(a.fecha,1,10) BETWEEN ? AND ? ORDER BY a.id DESC LIMIT 50`, d, h),
    movimientos: all(`SELECT m.fecha, m.tipo, m.monto, m.concepto, m.categoria, m.recibe, u.nombre cajero FROM movimientos m LEFT JOIN usuarios u ON u.id=m.usuario_id
      WHERE substr(m.fecha,1,10) BETWEEN ? AND ? ORDER BY m.id DESC LIMIT 100`, d, h),
    productos: all(`SELECT i.descripcion, SUM(i.cantidad) cantidad, SUM(i.importe) importe, SUM(i.importe - i.costo*i.cantidad) utilidad FROM venta_items i JOIN ventas v ON v.id=i.venta_id
      WHERE i.tipo='producto' AND v.cancelada=0 AND substr(v.fecha,1,10) BETWEEN ? AND ? GROUP BY i.producto_id ORDER BY importe DESC LIMIT 15`, d, h),
    membresias: all(`SELECT p.nombre plan, COUNT(*) n, SUM(m.precio) total FROM membresias m JOIN planes p ON p.id=m.plan_id
      WHERE m.cancelada=0 AND m.venta_id IS NOT NULL AND substr(m.creado,1,10) BETWEEN ? AND ? GROUP BY p.id ORDER BY total DESC`, d, h),
    accesos: {
      personas: get(`SELECT COUNT(DISTINCT cliente_id) n FROM visitas WHERE resultado='permitido' AND substr(fecha,1,10) BETWEEN ? AND ?`, d, h).n,
      entradas: get(`SELECT COUNT(*) n FROM visitas WHERE resultado='permitido' AND substr(fecha,1,10) BETWEEN ? AND ?`, d, h).n,
      negados: get(`SELECT COUNT(*) n FROM visitas WHERE resultado<>'permitido' AND substr(fecha,1,10) BETWEEN ? AND ?`, d, h).n,
      ultimos: all(`SELECT v.fecha, v.resultado, v.motivo, c.nombre FROM visitas v LEFT JOIN clientes c ON c.id=v.cliente_id WHERE substr(v.fecha,1,10) BETWEEN ? AND ? ORDER BY v.id DESC LIMIT 15`, d, h),
    },
    socios: {
      activos: all(`SELECT DISTINCT cliente_id FROM membresias WHERE cancelada=0 AND inicio<=? AND fin>=?`, t, t).length,
      vencen_semana: get(`SELECT COUNT(*) n FROM (SELECT cliente_id, MAX(fin) fin FROM membresias WHERE cancelada=0 GROUP BY cliente_id) WHERE fin BETWEEN ? AND ?`, t, sumarDias(t, 7)).n,
      nuevos: get('SELECT COUNT(*) n FROM clientes WHERE substr(creado,1,10) BETWEEN ? AND ?', d, h).n,
    },
    modulos: estadoLicencia().modulos,
    gastos_negocio: !moduloActivo('gastos') ? null : get(`SELECT COUNT(*) n, COALESCE(SUM(monto),0) total FROM gastos WHERE substr(fecha,1,10) BETWEEN ? AND ?`, d, h),
    por_cobrar: r2(get('SELECT COALESCE(SUM(credito_pendiente),0) s FROM ventas WHERE cancelada=0').s),
    stock_bajo: all('SELECT nombre, existencia, minimo FROM productos WHERE activo=1 AND existencia<=minimo ORDER BY existencia LIMIT 15'),
  };
});

// ---------- Ver ventas desde el celular: SOLO por Tailscale Funnel (igual que Maxsel Tech) ----------
// Funnel publica https://<computadora>.<red>.ts.net y el celular entra SIN instalar nada.
// Seguridad: Funnel NO apunta al puerto normal del sistema sino a uno aparte (PUERTO_PUBLICO) que solo escucha
// en esta computadora y SOLO deja pasar el panel del celular (solo lectura) + entrar/salir.
// Cobrar, clientes, configuración, el lector, la base de datos… NO se pueden abrir desde internet.
const PUERTO_PUBLICO = PUERTO + 1;
function exeTailscale() {
  if (process.platform === 'win32') {
    for (const f of [path.join(process.env.ProgramFiles || 'C:\\Program Files', 'Tailscale', 'tailscale.exe'), path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Tailscale', 'tailscale.exe')]) { try { if (fs.existsSync(f)) return f; } catch { /* nada */ } }
    return '';
  }
  for (const d of String(process.env.PATH || '').split(path.delimiter)) { const f = path.join(d, 'tailscale'); try { if (d && fs.existsSync(f)) return f; } catch { /* nada */ } }
  return '';
}
const RE_LOGIN_TS = /https:\/\/login\.tailscale\.com\/\S+/;
function correrTS(seg, args) {
  return new Promise((resolve) => {
    const exe = exeTailscale();
    if (!exe) return resolve({ out: '', error: 'Tailscale no está instalado en esta computadora.' });
    let out = '', fin = false, c;
    try { c = spawn(exe, args, { windowsHide: true }); } catch (e) { return resolve({ out: '', error: String(e.message || e) }); }
    const terminar = (r) => { if (fin) return; fin = true; clearTimeout(t); clearInterval(iv); resolve(r); };
    c.stdout.on('data', (d) => { out += d; }); c.stderr.on('data', (d) => { out += d; });
    c.on('error', (e) => terminar({ out, error: String(e.message || e) }));
    c.on('close', (code) => terminar({ out, error: code === 0 ? '' : (out.trim() || 'código ' + code) }));
    // si Tailscale pide permitir Funnel en la cuenta, regresamos el enlace en lugar de esperar
    const iv = setInterval(() => { if (RE_LOGIN_TS.test(out)) { try { c.kill(); } catch { /* nada */ } terminar({ out, error: '' }); } }, 300);
    const t = setTimeout(() => { try { c.kill(); } catch { /* nada */ } terminar({ out, error: 'Tailscale no respondió a tiempo.' }); }, seg * 1000);
  });
}
async function estadoFunnel() {
  const exe = exeTailscale();
  const r = { instalado: !!exe, conectado: false, nombre: '', funnel: { activo: false, url: '' }, qr: '' };
  if (!exe) return r;
  const s = await correrTS(8, ['status', '--json']);
  try {
    const j = JSON.parse(s.out);
    r.conectado = j.BackendState === 'Running';
    r.nombre = String(j.Self?.DNSName || '').replace(/\.$/, '');
    if (!r.conectado && j.AuthURL) r.login = j.AuthURL;
  } catch { /* nada */ }
  if (r.nombre) r.funnel.url = `https://${r.nombre}/movil`;
  if (r.conectado) {
    const f = await correrTS(8, ['funnel', 'status', '--json']);
    r.funnel.activo = f.out.includes('127.0.0.1:' + PUERTO_PUBLICO) && f.out.includes('AllowFunnel');
  }
  if (r.funnel.activo) r.qr = qrSvg(r.funnel.url, 5);
  return r;
}
async function cambiarFunnel(activar) {
  const r = activar
    ? await correrTS(25, ['funnel', '--bg', '--https=443', 'http://127.0.0.1:' + PUERTO_PUBLICO])
    : await correrTS(15, ['funnel', '--https=443', 'off']);
  const m = r.out.match(RE_LOGIN_TS);
  if (m) return { habilitar: m[0].replace(/[.,)]+$/, '') };
  if (r.error) {
    let msg = r.error; const l = msg.toLowerCase();
    if (l.includes('access denied') || l.includes('operator') || l.includes('permission'))
      msg = 'Tailscale no dio permiso. Reinicia la computadora (el sistema corre como servicio con permisos) y vuelve a intentar. Detalle: ' + msg;
    return { error: msg };
  }
  return { ok: true };
}
ruta('GET', '/api/movil/acceso', 'config', async () => ({ ...(await estadoFunnel()), puerto: PUERTO }));
ruta('POST', '/api/movil/funnel', 'config', async ({ body }) => {
  const r = await cambiarFunnel(!!body.activar);
  if (r.error) throw new ErrorUsuario(r.error);
  if (r.habilitar) return r;
  return { ...(await estadoFunnel()), puerto: PUERTO };
});
// Lo único que se puede abrir desde internet (por Funnel)
const PUBLICO_ARCHIVOS = new Set(['/movil', '/movil.webmanifest', '/favicon.ico', '/icono.png', '/icono-192.png', '/icono-512.png', '/logo.png', '/logo-gym', '/pdf-escribir.js', '/reportes.js', '/xlsx-escribir.js']);
const PUBLICO_API = new Set(['POST /api/login', 'POST /api/logout', 'GET /api/yo', 'GET /api/movil/resumen', 'GET /api/reportes/excel', 'GET /api/pantalla/stream', 'GET /api/licencia/estado']);
function permitidoPublico(req, ruta) {
  if (ruta.startsWith('/api/')) return PUBLICO_API.has(req.method + ' ' + ruta);
  return req.method === 'GET' && PUBLICO_ARCHIVOS.has(ruta);
}

// ---------- Monitoreo en la nube (solo lectura para el dueño) ----------
// Totales de HOY que se suben a la nube (pequeños: entradas y ventas)
function resumenNube() {
  const t = hoy(), r = resumenRango(t, t);
  const turnos = all(`SELECT * FROM turnos WHERE estado='abierto'`);
  return {
    fecha: t, hora: ahora().slice(11, 16), gym: cfg('gym_nombre'),
    entradas: get(`SELECT COUNT(DISTINCT cliente_id) n FROM visitas WHERE resultado='permitido' AND substr(fecha,1,10)=?`, t).n,
    entradas_total: get(`SELECT COUNT(*) n FROM visitas WHERE resultado='permitido' AND substr(fecha,1,10)=?`, t).n,
    negados: get(`SELECT COUNT(*) n FROM visitas WHERE resultado<>'permitido' AND substr(fecha,1,10)=?`, t).n,
    ventas: r.ventas.total, tickets: r.ventas.n, efectivo: r.ventas.efectivo, usd: r.ventas.usd, usd_mxn: r.ventas.usd_mxn, tarjeta: r.ventas.tarjeta, transferencia: r.ventas.transferencia, credito: r.ventas.credito,
    membresias: r.items.membresias, membresias_n: r.items.membresias_n, productos: r.items.productos, abonos: r.abonos.total, cobrado: r.cobrado,
    retiros: r.caja.retiros, gastos_caja: r.caja.gastos,
    gastos_negocio: r2(get(`SELECT COALESCE(SUM(monto),0) s FROM gastos WHERE substr(fecha,1,10)=?`, t).s),
    cajas_abiertas: turnos.length, efectivo_en_cajas: r2(turnos.reduce((a, x) => a + esperado(x).efectivo, 0)),
    socios_activos: all(`SELECT DISTINCT cliente_id FROM membresias WHERE cancelada=0 AND inicio<=? AND fin>=?`, t, t).length,
    vencen_semana: get(`SELECT COUNT(*) n FROM (SELECT cliente_id, MAX(fin) fin FROM membresias WHERE cancelada=0 GROUP BY cliente_id) WHERE fin BETWEEN ? AND ?`, t, sumarDias(t, 7)).n,
    por_cobrar: r2(get('SELECT COALESCE(SUM(credito_pendiente),0) s FROM ventas WHERE cancelada=0').s),
    mes: r2(get(`SELECT COALESCE(SUM(total),0) s FROM ventas WHERE cancelada=0 AND substr(fecha,1,7)=?`, t.slice(0, 7)).s),
  };
}
// La nube pide un reporte: se ejecuta aquí mismo como si lo pidiera el administrador
const USUARIO_NUBE = { id: 0, nombre: 'Monitoreo en la nube', rol: 'admin', perm: new Set(PERMISOS_ROL.admin) };
async function ejecutarParaNube(url) {
  const u = new URL(url, 'http://x');
  const r = rutas.find((x) => x.metodo === 'GET' && x.re.test(u.pathname));
  if (!r) throw new Error('Reporte no encontrado');
  try { return await r.fn({ q: Object.fromEntries(u.searchParams), p: r.re.exec(u.pathname).groups || {}, u: USUARIO_NUBE, body: {} }); }
  catch (e) { throw new Error(e.message); }
}
const nube = crearSincronizador({ cfg, setCfg, resumenHoy: resumenNube, ejecutar: ejecutarParaNube, version: VERSION, equipo: os.hostname(), log: (m) => console.log(`[${ahora()}] ${m}`) });
ruta('GET', '/api/nube/estado', 'config', () => ({ activo: cfg('nube_activo') === '1', email: cfg('nube_email'), pagina: URL_PAGINA, ...nube.estado }));
ruta('POST', '/api/nube/conectar', 'config', async ({ body }) => {
  const email = txt(body.email)?.toLowerCase(), pass = String(body.password || '');
  if (!email || !pass) throw new ErrorUsuario('Escribe el correo y la contraseña que te dio Maxsel');
  let s;
  try { s = await iniciarSesion(email, pass); } catch (e) { throw new ErrorUsuario(e.message); }
  setCfg('nube_email', email); setCfg('nube_uid', s.uid); setCfg('nube_refresh', s.refresh); setCfg('nube_activo', '1');
  nube.reiniciar();
  await new Promise((ok) => setTimeout(ok, 2500));
  return { ok: true, ...nube.estado };
});
ruta('POST', '/api/nube/desconectar', 'config', () => { setCfg('nube_activo', '0'); setCfg('nube_refresh', ''); nube.detener(); return { ok: true }; });
ruta('POST', '/api/nube/subir', 'config', async () => { await nube.ahora(); return { ok: true, ...nube.estado }; });

// ---------- 1.10: actualizaciones por internet (igual que Maxsel POS y Maxsel Hotel) ----------
// Baja version.json de github.com/mlunq23/maxsel-actualizaciones (público, solo paquetes); el .zip trae los archivos del programa
// (sin node.exe, sin licencia y sin la carpeta datos). Se revisa la huella SHA-256 antes de instalar y se guarda un respaldo para regresar.
const UPD_BASE = 'https://raw.githubusercontent.com/mlunq23/maxsel-actualizaciones/main/', UPD_DIR = path.join(DATA_DIR, 'actualizacion');
const NO_TOCAR = /^(datos\/|node_modules\/|licencia\.js$|generador\/|node\.exe$)/i;
const verCmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 4; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
function httpsBajar(url, max, redirs = 0) {
  // Solo para pruebas de Maxsel: lee los paquetes de una carpeta local en vez de internet
  if (process.env.MAXSEL_UPD_PRUEBA) return Promise.resolve().then(() => fs.readFileSync(path.join(process.env.MAXSEL_UPD_PRUEBA, path.basename(url.split('?')[0]))));
  return new Promise((resolve, reject) => {
    if (!/^https:\/\/raw\.githubusercontent\.com\/mlunq23\/maxsel-actualizaciones\//.test(url)) return reject(new ErrorUsuario('Dirección no permitida'));
    https.get(url, { timeout: 30000, headers: { 'Cache-Control': 'no-cache', 'User-Agent': 'MaxselGimnasios/' + VERSION } }, (rs) => {
      if ([301, 302, 303, 307, 308].includes(rs.statusCode) && rs.headers.location && redirs < 4) { rs.resume(); return resolve(httpsBajar(new URL(rs.headers.location, url).href, max, redirs + 1)); }
      if (rs.statusCode !== 200) { rs.resume(); return reject(new ErrorUsuario('El servidor de Maxsel respondió ' + rs.statusCode)); }
      const ch = []; let n = 0;
      rs.on('data', (c) => { n += c.length; if (n > max) { rs.destroy(); reject(new ErrorUsuario('Archivo demasiado grande')); } else ch.push(c); });
      rs.on('end', () => resolve(Buffer.concat(ch))); rs.on('error', reject);
    }).on('timeout', function () { this.destroy(new ErrorUsuario('Sin respuesta (revise el internet)')); })
      .on('error', (e) => reject(e instanceof ErrorUsuario ? e : new ErrorUsuario(/ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ENETUNREACH|ECONNRESET/.test(e.code || '') ? 'Sin internet. Conecte la computadora a internet e intente de nuevo.' : e.message)));
  });
}
async function versionDisponible() {
  const j = JSON.parse((await httpsBajar(UPD_BASE + 'version.json?t=' + Date.now(), 256 * 1024)).toString('utf8'));
  const e = j.gym;
  if (!e || !e.ver) return { instalada: VERSION, hay: false };
  const hay = verCmp(e.ver, VERSION) > 0 && /^[\w.-]+\.zip$/.test(e.win || '') && /^[0-9a-f]{64}$/i.test(e.winSha || '');
  setCfg('upd_disponible', hay ? String(e.ver) : '');
  return { instalada: VERSION, disponible: String(e.ver), notas: String(e.notas || ''), hay, _e: e };
}
function leerZip(buf) {
  let e = buf.length - 22; while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) throw new ErrorUsuario('El paquete de actualización está dañado');
  const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const out = [];
  for (let i = 0; i < n; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new ErrorUsuario('El paquete de actualización está dañado');
    const met = buf.readUInt16LE(p + 10), cs = buf.readUInt32LE(p + 20), nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const nom = buf.toString('utf8', p + 46, p + 46 + nl).replace(/\\/g, '/'); p += 46 + nl + xl + cl;
    if (nom.endsWith('/')) continue;
    if (buf.readUInt32LE(lo) !== 0x04034b50) throw new ErrorUsuario('El paquete de actualización está dañado');
    const s0 = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28), raw = buf.subarray(s0, s0 + cs);
    const dat = met === 0 ? raw : met === 8 ? zlib.inflateRawSync(raw) : null;
    if (!dat) throw new ErrorUsuario('Formato de paquete no soportado');
    out.push({ nom, dat });
  }
  if (!out.length) throw new ErrorUsuario('El paquete de actualización viene vacío');
  return out;
}
let actualizando = false;
async function instalarActualizacion(u) {
  if (actualizando) throw new ErrorUsuario('Ya se está instalando una actualización');
  actualizando = true;
  try {
    const v = await versionDisponible();
    if (!v.hay) throw new ErrorUsuario(`Ya tiene la versión más reciente (${VERSION}).`);
    const zip = await httpsBajar(UPD_BASE + v._e.win, 80 * 1024 * 1024);
    if (crypto.createHash('sha256').update(zip).digest('hex') !== String(v._e.winSha).toLowerCase()) throw new ErrorUsuario('El archivo descargado no es válido. Intente de nuevo.');
    const archivos = leerZip(zip).filter((f) => !NO_TOCAR.test(f.nom) && !f.nom.split('/').includes('..'));
    if (!archivos.some((f) => f.nom === 'server.js')) throw new ErrorUsuario('El paquete de actualización no es de Maxsel Gimnasios');
    // Respaldo de lo que hay ahora (para regresar si algo falla)
    const bk = path.join(UPD_DIR, 'respaldo_' + VERSION); fs.rmSync(bk, { recursive: true, force: true }); fs.mkdirSync(bk, { recursive: true });
    const raiz = path.resolve(DIR) + path.sep, escritos = [];
    try {
      for (const f of archivos) {
        const d = path.resolve(DIR, f.nom); if (!d.startsWith(raiz)) continue;
        if (fs.existsSync(d)) { fs.mkdirSync(path.dirname(path.join(bk, f.nom)), { recursive: true }); fs.copyFileSync(d, path.join(bk, f.nom)); }
        fs.mkdirSync(path.dirname(d), { recursive: true }); fs.writeFileSync(d + '.nuevo', f.dat); escritos.push(d);
      }
      // se cambian todos juntos al final; si Windows o el antivirus tienen un archivo ocupado, se reintenta
      const espera = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
      for (const d of escritos) for (let i = 0; ; i++) { try { fs.renameSync(d + '.nuevo', d); break; } catch (e) { if (i >= 20) throw e; espera(300); } }
      // se comprueba que cada archivo quedó igual al del paquete antes de reiniciar
      const h = (b) => crypto.createHash('sha256').update(b).digest('hex');
      for (const f of archivos) { const d = path.resolve(DIR, f.nom); if (d.startsWith(raiz) && h(fs.readFileSync(d)) !== h(f.dat)) throw new Error('el archivo ' + f.nom + ' no quedó bien escrito'); }
    } catch (e) {
      for (const d of escritos) { try { fs.rmSync(d + '.nuevo', { force: true }); } catch { /* nada */ } }
      for (const f of archivos) { const b = path.join(bk, f.nom); if (fs.existsSync(b)) try { fs.copyFileSync(b, path.resolve(DIR, f.nom)); } catch { /* nada */ } }
      throw new ErrorUsuario('No se pudo instalar la actualización: ' + e.message);
    }
    fs.writeFileSync(path.join(UPD_DIR, 'estado.json'), JSON.stringify({ de: VERSION, a: v.disponible, fecha: ahora(), usuario: u?.nombre || '', archivos: escritos.length }));
    console.log(`  [${ahora()}] Actualización ${VERSION} → ${v.disponible} instalada (${escritos.length} archivos). Reiniciando...`);
    setTimeout(() => process.exit(0), 1500).unref?.();
    return { ok: true, de: VERSION, a: v.disponible, archivos: escritos.length, servicio: !!process.env.MAXSEL_SERVICIO };
  } finally { actualizando = false; }
}
ruta('GET', '/api/actualizacion', 'config', async () => { const { _e, ...v } = await versionDisponible(); return v; });
ruta('POST', '/api/actualizacion/instalar', 'config', ({ u }) => instalarActualizacion(u));
// Al arrancar después de actualizar: se anota en la bitácora
try {
  const f = path.join(UPD_DIR, 'estado.json');
  if (fs.existsSync(f)) {
    const i = JSON.parse(fs.readFileSync(f, 'utf8'));
    console.log(`  [${ahora()}] ` + (verCmp(VERSION, i.a) >= 0 ? `Actualizado de la versión ${i.de} a la ${VERSION} por ${i.usuario || '—'}` : `La actualización a la ${i.a} no quedó (sigue la ${VERSION})`));
    setCfg('upd_ultima', verCmp(VERSION, i.a) >= 0 ? `${i.de} → ${VERSION} el ${i.fecha} (${i.usuario || ''})` : '');
    fs.unlinkSync(f);
  }
  if (cfg('upd_disponible') && verCmp(cfg('upd_disponible'), VERSION) <= 0) setCfg('upd_disponible', '');
} catch { /* nada */ }
// Revisa solo si hay versión nueva (cada 6 horas, si hay internet) para avisarle al administrador
const revisarActualizacion = () => versionDisponible().catch(() => {});
setTimeout(revisarActualizacion, 90 * 1000).unref();
setInterval(revisarActualizacion, 6 * 60 * 60 * 1000).unref();

// ---------- Archivos estáticos ----------
const TIPOS = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.mp3': 'audio/mpeg' };
function estatico(res, archivo) {
  const ruta = path.join(PUBLIC, archivo);
  if (!ruta.startsWith(PUBLIC) || !fs.existsSync(ruta) || fs.statSync(ruta).isDirectory()) return false;
  res.writeHead(200, { 'Content-Type': TIPOS[path.extname(ruta)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
  fs.createReadStream(ruta).pipe(res);
  return true;
}

function usuarioDe(req) {
  const tk = cookies(req).gym_s;
  if (!tk) return null;
  return get('SELECT u.* FROM sesiones s JOIN usuarios u ON u.id=s.usuario_id WHERE s.token=? AND u.activo=1', tk) || null;
}

async function atender(req, res) {
  const url = new URL(req.url, 'http://x');
  let ruta;
  try { ruta = decodeURIComponent(url.pathname); } catch { res.writeHead(400); return res.end(); }
  try {
    if (req.publico) {
      res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Referrer-Policy', 'no-referrer'); res.setHeader('X-Frame-Options', 'DENY');
      if (req.method === 'GET' && (ruta === '/' || ruta === '/m')) { res.writeHead(302, { Location: '/movil' }); return res.end(); }
      if (!permitidoPublico(req, ruta)) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('No encontrado'); }
    }
    if (ruta.startsWith('/celfoto/') && !req.publico) {
      if (!LICENCIA.activa) { res.writeHead(403); return res.end(); }
      return await paginaCelFoto(req, res, ruta);
    }
    if (ruta === '/hik/eventos' && req.method === 'POST') {
      if (!LICENCIA.activa) { res.writeHead(200); return res.end('OK'); }
      return await recibirEventoLector(req, res);
    }
    if (ruta.startsWith('/iclock/')) {
      if (!LICENCIA.activa || !moduloActivo('asistencia')) { res.writeHead(403); return res.end('OK'); }
      const b = req.method === 'POST' ? await leerCuerpo(req, 5 * 1024 * 1024) : Buffer.alloc(0);
      return iclock(req, res, url, ruta, b);
    }
    if (ruta.startsWith('/api/') && !LICENCIA.activa && !SIN_LICENCIA_OK.has(ruta)) {
      return enviar(res, 402, { error: 'El sistema no tiene licencia activa. ' + (LICENCIA.motivo || ''), sinLicencia: true });
    }
    if (ruta.startsWith('/api/')) {
      const r = rutas.find((x) => x.metodo === req.method && x.re.test(ruta));
      if (!r) return enviar(res, 404, { error: 'Ruta no encontrada' });
      const u = usuarioDe(req);
      if (r.rol && !u) return enviar(res, 401, { error: 'Inicia sesión' });
      const mod = moduloDeRuta(ruta, Object.fromEntries(url.searchParams));
      if (mod && !moduloActivo(mod)) return enviar(res, 403, { error: SIN_MODULO(mod), modulo: mod });
      if (u) u.perm = new Set(permisosDe(u));
      if (req.publico && u && !u.perm.has('movil')) return enviar(res, 403, { error: 'Ese usuario no tiene permiso para ver las ventas desde el celular.' });
      if (r.rol && r.rol !== 'sesion' && !u.perm.has(r.rol)) return enviar(res, 403, { error: 'No tienes permiso para esto. Pídeselo al administrador.' });
      if (ruta === '/api/pantalla/stream') return conectarPantalla(res);
      let body = {};
      if (['POST', 'PUT', 'DELETE'].includes(req.method)) {
        const b = await leerCuerpo(req);
        if (b.length) { try { body = JSON.parse(b.toString()); } catch { throw new ErrorUsuario('Datos inválidos'); } }
      }
      const out = await r.fn({ req, res, body, u, p: r.re.exec(ruta).groups || {}, q: Object.fromEntries(url.searchParams) });
      // avisa a los celulares conectados que hubo movimiento en caja
      if (req.method !== 'GET' && /^\/api\/(ventas|abonos|turno)/.test(ruta)) avisarPantallas({ tipo: 'caja' });
      return enviar(res, 200, out === undefined ? { ok: true } : out);
    }
    if (ruta.startsWith('/fotos/')) {
      if (!usuarioDe(req)) { res.writeHead(401); return res.end(); }
      const c = get('SELECT foto FROM clientes WHERE id=?', Number(ruta.split('/')[2]));
      const f = c?.foto && path.join(FOTOS_DIR, c.foto);
      if (!f || !fs.existsSync(f)) { res.writeHead(404); return res.end(); }
      res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'private, max-age=86400' });
      return fs.createReadStream(f).pipe(res);
    }
    if (ruta.startsWith('/evidencias/')) {
      if (!usuarioDe(req)) { res.writeHead(401); return res.end(); }
      const [, , cid, tipo] = ruta.split('/');
      if (!['estudiante', 'vecino'].includes(tipo)) { res.writeHead(404); return res.end(); }
      const c = get(`SELECT doc_${tipo} f FROM clientes WHERE id=?`, Number(cid));
      const f = c?.f && path.join(DOCS_DIR, c.f);
      if (!f || !fs.existsSync(f)) { res.writeHead(404); return res.end(); }
      res.writeHead(200, { 'Content-Type': f.endsWith('.png') ? 'image/png' : 'image/jpeg', 'Cache-Control': 'private, max-age=86400' });
      return fs.createReadStream(f).pipe(res);
    }
    if (ruta === '/publicidad-img') {
      if (!usuarioDe(req)) { res.writeHead(401); return res.end(); }
      const f = String(cfg('wa_imagen') || '').split('?')[0], r = f && path.join(DATA_DIR, f);
      if (!r || !fs.existsSync(r)) { res.writeHead(404); return res.end(); }
      res.writeHead(200, { 'Content-Type': f.endsWith('.png') ? 'image/png' : 'image/jpeg', 'Cache-Control': 'no-cache' });
      return fs.createReadStream(r).pipe(res);
    }
    if (ruta === '/logo-gym') {
      const f = String(cfg('gym_logo') || '').split('?')[0], r = f && path.join(DATA_DIR, f);
      if (!r || !fs.existsSync(r)) { res.writeHead(404); return res.end(); }
      res.writeHead(200, { 'Content-Type': f.endsWith('.png') ? 'image/png' : 'image/jpeg', 'Cache-Control': 'no-cache' });
      return fs.createReadStream(r).pipe(res);
    }
    if (ruta === '/checador' && !moduloActivo('asistencia')) { res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end(SIN_MODULO('asistencia')); }
    if (ruta === '/checador' && estatico(res, 'checador.html')) return;
    if (ruta === '/pantalla' && estatico(res, 'pantalla.html')) return;
    if (ruta === '/movil' && estatico(res, 'movil.html')) return;
    if (ruta !== '/' && estatico(res, ruta.slice(1))) return;
    estatico(res, 'index.html') || (res.writeHead(404), res.end());
  } catch (e) {
    if (res.headersSent) return;
    if (e instanceof ErrorUsuario) return enviar(res, e.status, { error: e.message });
    if (e.message?.startsWith('El lector') || e.message?.includes('lector')) return enviar(res, 502, { error: e.message });
    if (['ECONNRESET', 'ECONNREFUSED', 'ETIMEDOUT', 'EHOSTUNREACH', 'EPIPE'].includes(e.code)) return enviar(res, 502, { error: 'No se pudo comunicar con el lector (' + e.code + '). Revisa la IP y que el puerto sea el HTTP del lector (normalmente 80).' });
    console.error(e);
    enviar(res, 500, { error: 'Error interno: ' + e.message });
  }
}
const servidor = http.createServer(atender);
// Servidor solo para Funnel (internet): escucha únicamente en esta computadora
const servidorPublico = http.createServer((req, res) => { req.publico = true; return atender(req, res); });
servidorPublico.on('error', (e) => console.error('  Puerto del celular (' + PUERTO_PUBLICO + '): ' + e.message));
ruta('GET', '/api/pantalla/stream', 'sesion', () => {});

revisarLicencia();
setInterval(revisarLicencia, 60 * 60 * 1000).unref();

servidor.listen(PUERTO, () => {
  servidorPublico.listen(PUERTO_PUBLICO, '127.0.0.1');
  iniciarConsultaEventos();
  nube.iniciar();
  console.log('\n  ==============================================');
  console.log(`   ${PRODUCTO} v${VERSION}`);
  console.log(`   [${new Date().toLocaleString('es-MX')}] Sistema iniciado`);
  console.log('   Código de equipo (para la licencia): ' + codigoEquipo());
  console.log('   Licencia: ' + (MODO_DESARROLLO ? 'MODO DESARROLLO' : LICENCIA.activa ? 'ACTIVA - ' + LICENCIA.cliente + (LICENCIA.expira ? ' (vence ' + LICENCIA.expira + ')' : ' (permanente)') : 'NO ACTIVADA'));
  console.log(`   Abre en el navegador:  http://localhost:${PUERTO}`);
  console.log(`   Pantalla de acceso:    http://localhost:${PUERTO}/pantalla`);
  if (!process.env.MAXSEL_SERVICIO) console.log('   No cierres esta ventana mientras uses el sistema');
  console.log('  ==============================================\n');
});
servidor.on('error', (e) => {
  if (e.code === 'EADDRINUSE') console.error(`\n  El puerto ${PUERTO} ya está en uso: el sistema probablemente ya está funcionando (servicio de Windows o en otra ventana).\n`);
  else console.error(e);
  process.exit(1);
});
