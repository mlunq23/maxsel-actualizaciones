// Permisos que el administrador puede habilitar o quitar a cada usuario
export const PERMISOS = [
  { grupo: 'Caja', clave: 'pos', texto: 'Punto de venta: vender y abrir/cerrar su turno' },
  { grupo: 'Caja', clave: 'credito', texto: 'Vender a crédito (cargar a la cuenta del cliente)' },
  { grupo: 'Caja', clave: 'abonos', texto: 'Cobrar abonos a cuentas' },
  { grupo: 'Caja', clave: 'movimientos', texto: 'Retiros, gastos y entradas de efectivo de la caja' },
  { grupo: 'Caja', clave: 'cancelar', texto: 'Cancelar ventas' },
  { grupo: 'Caja', clave: 'descuentos', texto: 'Aplicar descuentos a productos y membresías al vender' },
  { grupo: 'Caja', clave: 'ver_corte', texto: 'Ver lo que debería haber al cerrar su turno (si no, el cierre es a ciegas)' },
  { grupo: 'Clientes', clave: 'clientes', texto: 'Ver clientes y dar de alta clientes nuevos' },
  { grupo: 'Clientes', clave: 'clientes_editar', texto: 'Editar datos, fotos y evidencias de clientes' },
  { grupo: 'Clientes', clave: 'clientes_bloquear', texto: 'Bloquear o desbloquear el acceso de un cliente' },
  { grupo: 'Clientes', clave: 'clientes_borrar', texto: 'Eliminar clientes' },
  { grupo: 'Clientes', clave: 'adeudos', texto: 'Ver cuentas por cobrar' },
  { grupo: 'Clientes', clave: 'avisos', texto: 'Enviar avisos por WhatsApp' },
  { grupo: 'Acceso', clave: 'accesos', texto: 'Ver el registro de accesos' },
  { grupo: 'Acceso', clave: 'puerta', texto: 'Entrada manual: buscar al cliente y abrirle la puerta si no lo reconoce el lector' },
  { grupo: 'Acceso', clave: 'puerta_forzar', texto: 'Dejar pasar a un cliente SIN membresía vigente (con motivo)' },
  { grupo: 'Productos', clave: 'productos', texto: 'Ver productos y existencias' },
  { grupo: 'Productos', clave: 'productos_editar', texto: 'Dar de alta, editar, importar de Excel y meter mercancía' },
  { grupo: 'Administración', clave: 'inicio', texto: 'Ver el tablero de inicio (ventas del día, socios activos)' },
  { grupo: 'Administración', clave: 'planes', texto: 'Cambiar precios de membresías y promociones' },
  { grupo: 'Administración', clave: 'cortes', texto: 'Ver cortes de caja de todos los cajeros' },
  { grupo: 'Administración', clave: 'gastos', texto: 'Gastos: registrar gastos fijos (agua, luz, nómina…) y gastos varios' },
  { grupo: 'Administración', clave: 'cuentas_pagar', texto: 'Proveedores y cuentas por pagar' },
  { grupo: 'Administración', clave: 'empleados', texto: 'Empleados: sueldos, pago de nómina, vacaciones y descansos' },
  { grupo: 'Asistencia', clave: 'checador', texto: 'Usar el checador de entradas y salidas de empleados en esta computadora' },
  { grupo: 'Asistencia', clave: 'asistencia', texto: 'Asistencia: horarios, NIP, reportes, retardos, faltas, festivos y reglas' },
  { grupo: 'Administración', clave: 'reportes', texto: 'Ver reportes y exportarlos a Excel' },
  { grupo: 'Administración', clave: 'movil', texto: 'Ver ventas y reportes en tiempo real desde el celular' },
  { grupo: 'Administración', clave: 'usuarios', texto: 'Administrar usuarios y sus permisos' },
  { grupo: 'Administración', clave: 'config', texto: 'Configuración del sistema y del lector facial' },
];
const CAJERO = ['checador', 'pos', 'credito', 'abonos', 'movimientos', 'clientes', 'clientes_editar', 'adeudos', 'avisos', 'accesos', 'puerta', 'productos'];
const GERENTE = [...CAJERO, 'puerta_forzar', 'cancelar', 'descuentos', 'ver_corte', 'clientes_bloquear', 'productos_editar', 'inicio', 'planes', 'cortes', 'gastos', 'cuentas_pagar', 'empleados', 'asistencia', 'reportes', 'movil'];
export const PERMISOS_ROL = { cajero: CAJERO, gerente: GERENTE, admin: PERMISOS.map((p) => p.clave) };
const VALIDOS = new Set(PERMISOS.map((p) => p.clave));

// Permisos efectivos de un usuario. El administrador siempre tiene todo.
export function permisosDe(u) {
  if (!u) return [];
  if (u.rol === 'admin') return PERMISOS_ROL.admin;
  if (u.permisos) {
    try { const l = JSON.parse(u.permisos); if (Array.isArray(l)) return l.filter((k) => VALIDOS.has(k) && k !== 'usuarios' && k !== 'config'); } catch { /* usar los del rol */ }
  }
  return PERMISOS_ROL[u.rol] || [];
}
export const limpiarPermisos = (lista) => (Array.isArray(lista) ? [...new Set(lista.filter((k) => VALIDOS.has(k)))] : null);
