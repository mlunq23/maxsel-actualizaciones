// 1.18 NUBE (Tailscale Funnel) — monitoreo desde el teléfono, igual que Maxsel Tech / Abarrotes.
// Funnel publica https://<computadora>.<red>.ts.net y lo manda al puerto 3051, que solo escucha en
// esta computadora y solo deja CONSULTAR (ver server.js: req.desdeInternet). Nada que instalar en el teléfono.
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';

export function exeTailscale() {
  if (process.platform === 'win32') {
    const c = [path.join(process.env.ProgramFiles || 'C:\\Program Files', 'Tailscale', 'tailscale.exe'),
      path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Tailscale', 'tailscale.exe')];
    for (const f of c) { try { if (fs.existsSync(f)) return f; } catch {} }
    return '';
  }
  for (const d of String(process.env.PATH || '').split(path.delimiter)) { const f = path.join(d, 'tailscale'); try { if (fs.existsSync(f)) return f; } catch {} }
  return '';
}
const RE_LOGIN = /https:\/\/login\.tailscale\.com\/\S+/;
function correrTS(seg, args) {
  return new Promise((resolve) => {
    const exe = exeTailscale();
    if (!exe) return resolve({ out: '', error: 'Tailscale no está instalado en esta computadora.' });
    let out = '', fin = false, c;
    try { c = spawn(exe, args, { windowsHide: true }); } catch (e) { return resolve({ out: '', error: String(e.message || e) }); }
    const terminar = (r) => { if (fin) return; fin = true; clearTimeout(t); clearInterval(iv); resolve(r); };
    c.stdout.on('data', (d) => (out += d)); c.stderr.on('data', (d) => (out += d));
    c.on('error', (e) => terminar({ out, error: String(e.message || e) }));
    c.on('close', (code) => terminar({ out, error: code === 0 ? '' : (out.trim() || 'código ' + code) }));
    // si Tailscale pide habilitar Funnel en la cuenta, regresamos el enlace en lugar de esperar
    const iv = setInterval(() => { if (RE_LOGIN.test(out)) { try { c.kill(); } catch {} terminar({ out, error: '' }); } }, 300);
    const t = setTimeout(() => { try { c.kill(); } catch {} terminar({ out, error: 'Tailscale no respondió a tiempo.' }); }, seg * 1000);
  });
}
async function leerTailscale() {
  const exe = exeTailscale();
  const r = { instalado: !!exe, conectado: false, nombre: '', ip: '' };
  if (!exe) return r;
  const s = await correrTS(8, ['status', '--json']);
  try {
    const j = JSON.parse(s.out);
    r.conectado = j.BackendState === 'Running';
    r.nombre = String(j.Self?.DNSName || '').replace(/\.$/, '');
    r.ip = (j.Self?.TailscaleIPs || []).find((x) => !x.includes(':')) || '';
  } catch {}
  return r;
}
export async function estadoNube(puertoFunnel) {
  const ts = await leerTailscale();
  const out = { instalado: ts.instalado, conectado: ts.conectado, nombre: ts.nombre, ip: ts.ip, funnel: { activo: false, url: ts.nombre ? 'https://' + ts.nombre : '' } };
  if (ts.instalado && ts.conectado) {
    const f = await correrTS(8, ['funnel', 'status', '--json']);
    out.funnel.activo = f.out.includes('127.0.0.1:' + puertoFunnel) && f.out.includes('AllowFunnel');
  }
  return out;
}
export async function cambiarFunnel(activar, puertoFunnel) {
  const r = activar
    ? await correrTS(25, ['funnel', '--bg', '--https=443', 'http://127.0.0.1:' + puertoFunnel])
    : await correrTS(15, ['funnel', '--https=443', 'off']);
  const m = r.out.match(RE_LOGIN);
  if (m) return { habilitar: m[0].replace(/[.,)]+$/, '') };
  if (r.error) {
    let msg = r.error;
    if (/access denied|operator|permission/i.test(msg)) msg = 'Tailscale no dio permiso. Reinicie la computadora y vuelva a intentar. Detalle: ' + msg;
    return { error: msg };
  }
  return { ok: true };
}

// 1.21: nombre corto de esta computadora en Tailscale (cambia la dirección a https://<nombre>.<red>.ts.net)
export async function cambiarNombreTS(nombre) {
  const r = await correrTS(20, ['set', '--hostname=' + nombre]);
  return { error: r.error ? 'Tailscale no aceptó el nombre: ' + r.error : '' };
}
