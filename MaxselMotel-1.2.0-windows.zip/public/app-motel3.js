/* Maxsel Motel 1.2 — igual que Maxsel Tech / Maxsel Abarrotes:
   · "¿Olvidaste tu contraseña?" en la pantalla de entrada (un administrador o la clave de soporte de Maxsel)
   · Reinicio de ventas oculto: 7 toques seguidos a la versión al final de Configuración + contraseña de Maxsel
   · Monitoreo en la nube SOLO por la dirección web de Tailscale (Funnel), en 3 pasos y con código QR */

// ---------------- Entrar + recuperar contraseña ----------------
pantallaLogin = function () {
  clearInterval(timer);
  $('#raiz').innerHTML = `<div class="acceso"><form class="card" id="flog"><img src="logo.png" alt="Maxsel"><h1 style="text-align:center">Maxsel Motel</h1>
    <label class="l">Usuario<input id="lu" autocomplete="username" autocapitalize="off"></label>
    <label class="l">Contraseña<input id="lp" type="password" autocomplete="current-password"></label>
    <button class="btn pri" style="justify-content:center">Entrar</button>
    <div style="text-align:center"><a href="#" id="lolv" class="olvide">¿Olvidaste tu contraseña?</a></div><div id="lerr"></div></form></div>`;
  $('#lu').focus();
  $('#lolv').onclick = (e) => { e.preventDefault(); recuperarModal(); };
  $('#flog').onsubmit = async (e) => {
    e.preventDefault();
    try { await POST('/api/login', { usuario: val('lu'), password: $('#lp').value }); inicio(); }
    catch (er) { $('#lerr').innerHTML = `<div class="aviso bad">${esc(er.message)}</div>`; }
  };
};
async function recuperarModal() {
  let us;
  try { us = await (await fetch('/api/recuperar/usuarios')).json(); } catch { us = { error: 'No se pudo conectar con el sistema' }; }
  if (!Array.isArray(us)) return toast(us.error || 'No disponible', true);
  const escrito = String($('#lu')?.value || '').trim().toLowerCase();
  modal('Recuperar contraseña', `<div class="aviso">Un <b>administrador</b> le puede poner contraseña nueva a cualquier usuario. Si ningún administrador la recuerda, comuníquese con <b>Maxsel</b> (WhatsApp 664 337 5433) para que lo haga con su clave de soporte.</div>
    <div class="stack" style="gap:10px;margin-top:12px">
      <label class="l">Usuario que olvidó su contraseña<select id="rcU">${us.map((u) => `<option value="${u.id}" ${u.usuario === escrito ? 'selected' : ''}>${esc(u.nombre)} (${esc(u.usuario)} · ${esc(ROL_TXT[u.rol] || u.rol)})</option>`).join('')}</select></label>
      <label class="l">Contraseña de un administrador (o clave de soporte Maxsel)<input id="rcA" type="password" autocomplete="off"></label>
      <label class="l">Contraseña nueva (mínimo 6)<input id="rcN1" type="password" autocomplete="new-password"></label>
      <label class="l">Repita la contraseña nueva<input id="rcN2" type="password" autocomplete="new-password" onkeydown="if(event.key==='Enter')recuperarOk()"></label></div>
    <div id="rcE"></div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="recuperarOk()">Cambiar contraseña</button>`);
  $('#rcA').focus();
}
const ROL_TXT = { admin: 'Administrador', gerente: 'Gerente', recepcion: 'Recepción', monitor: 'Monitoreo', mantenimiento: 'Mantenimiento' };
async function recuperarOk() {
  const n1 = $('#rcN1').value, n2 = $('#rcN2').value, err = (m) => { $('#rcE').innerHTML = `<div class="aviso bad" style="margin-top:10px">${esc(m)}</div>`; };
  if (!$('#rcA').value) return err('Escriba la contraseña de un administrador');
  if (n1.length < 6) return err('La contraseña nueva debe tener al menos 6 caracteres');
  if (n1 !== n2) return err('Las contraseñas nuevas no coinciden');
  try {
    const r = await fetch('/api/recuperar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ usuario_id: Number(val('rcU')), autoriza: $('#rcA').value, nueva: n1 }) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { $('#rcA').value = ''; $('#rcA').focus(); return err(d.error || 'No se pudo cambiar'); }
    cerrar(); if ($('#lu')) { $('#lu').value = d.usuario; $('#lp').value = ''; $('#lp').focus(); }
    toast('Listo. Entre con la contraseña nueva de ' + d.nombre);
  } catch { err('No se pudo conectar con el sistema'); }
}

// ---------------- Reiniciar el sistema (oculto, solo Maxsel) ----------------
const _vCfgMotel = vCfg;
vCfg = async function () {
  await _vCfgMotel();
  if (!$('#verPie')) $('#main').insertAdjacentHTML('beforeend', `<div class="ver-pie" id="verPie" onclick="toqueVersion()">Maxsel Motel · versión ${esc(YO?.version || '')} · Maxsel Sistemas de Punto de Venta</div>`);
};
let _toques = [];
function toqueVersion() {
  const t = Date.now(); _toques = _toques.filter((x) => t - x < 4000); _toques.push(t);
  if (_toques.length >= 7) { _toques = []; reinicioModal(); }
}
function reinicioModal() {
  modal('🔒 Reiniciar el sistema · solo Maxsel', `<div class="aviso bad">Borra las <b>entradas, cobros, ventas de la tienda, turnos y cortes</b> (por ejemplo las pruebas de la instalación). Lo vendido regresa al inventario y los folios empiezan de nuevo.
      Habitaciones, tarifas, usuarios, configuración, licencia y la bitácora <b>no se borran</b>. Antes se guarda un respaldo.</div>
    <div class="stack" style="gap:6px;margin-top:12px">
      <label class="row" style="font-weight:600"><input type="checkbox" checked disabled> Entradas, cobros, ventas, turnos y cortes de caja</label>
      <label class="row" style="font-weight:600"><input type="checkbox" id="rsInv"> También el inventario (productos de la tienda)</label></div>
    <label class="l" style="margin-top:12px">Contraseña de Maxsel<input id="rsPass" type="password" autocomplete="off" placeholder="Solo la conoce Maxsel" onkeydown="if(event.key==='Enter')$('#rsOk').click()"></label>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn bad" id="rsOk" onclick="confirmar(this,reinicioOk)">Borrar y reiniciar</button>`);
  $('#rsPass').focus();
}
async function reinicioOk() {
  const clave = $('#rsPass').value;
  if (!clave) return toast('Escriba la contraseña de Maxsel', true);
  try {
    await POST('/api/maxsel/reiniciar', { clave, inventario: $('#rsInv').checked });
    cerrar(); toast('Sistema reiniciado. Vuelva a entrar.');
    setTimeout(() => { YO = null; pantallaLogin(); }, 1200);
  } catch (e) { $('#rsPass').value = ''; $('#rsPass').focus(); const b = $('#rsOk'); if (b) { delete b.dataset.armado; b.textContent = 'Borrar y reiniciar'; } }
}

// ---------------- Monitoreo en la nube: solo Tailscale Funnel (como Maxsel Tech) ----------------
function qrSVG(texto) {
  try { const q = qrcode(0, 'M'); q.addData(texto); q.make(); return q.createSvgTag({ cellSize: 5, margin: 2, scalable: true }); } catch { return ''; }
}
cRemoto = async function () {
  $('#cfgc').innerHTML = `<div class="stack" style="max-width:860px">
    <div class="card nube-card"><div class="nube-hd">${ico('wifi')}<div><h2 style="margin:0">Ver el motel desde el celular</h2>
      <div class="sub">Con la dirección web de Tailscale: se instala <b>solo en esta computadora</b>. En el celular no se instala nada; se abre como cualquier página.</div></div></div>
      <div id="webEst"><div class="sub">Revisando Tailscale…</div></div></div>
    <p class="sub" style="margin:0">Otras computadoras del motel (misma red): ${(CFG._ips || []).filter((i) => !i.tailscale).map((i) => `<b>http://${esc(i.ip)}:${CFG._puerto}</b>`).join(' · ') || '—'}</p></div>`;
  webPintar();
};
webPintar = async function (extra = '') {
  const el = $('#webEst'); if (!el) return;
  let w; try { w = await GET('/api/remoto/web'); } catch (e) { el.innerHTML = `<div class="aviso bad">${esc(e.message)}</div>`; return; }
  const quien = `<label class="l" style="max-width:560px;margin-top:14px">¿Quién puede entrar desde el celular?<select id="webRol" onchange="webRol()"><option value="dueno" ${w.roles !== 'todos' ? 'selected' : ''}>Solo el dueño: administrador, gerente y monitoreo (recomendado)</option><option value="todos" ${w.roles === 'todos' ? 'selected' : ''}>Todos los usuarios</option></select></label>`;
  if (w.activo) {
    const msg = encodeURIComponent(`Monitoreo de ${CFG.hotel_nombre}: ${w.url}\nEntre con su usuario y contraseña. En el menú del navegador elija "Agregar a pantalla de inicio".`);
    el.innerHTML = `${extra}<div class="nube-on"><div class="nube-qr">${qrSVG(w.url)}</div><div style="flex:1;min-width:240px">
        <div class="aviso ok" style="margin:0 0 10px"><b>✓ Activo.</b> Escanee el código con la cámara del celular o abra esta dirección (con datos o cualquier WiFi):</div>
        <div class="codigo web-url" id="webUrl">${esc(w.url)}</div>
        <div class="row"><button class="btn pri" onclick="copiarTexto('${esc(w.url)}')">Copiar dirección</button><a class="btn" href="https://wa.me/?text=${msg}" target="_blank" rel="noopener">Enviar por WhatsApp</a>
          <button class="btn bad" onclick="confirmar(this,webDesactivar)">Desactivar</button></div>
        <p class="sub">Entre con un usuario <b>Administrador</b>, <b>Gerente</b> o <b>Monitoreo</b>. En el celular: menú del navegador → <b>"Agregar a pantalla de inicio"</b>. Esta computadora debe estar encendida y con internet.</p></div></div>${quien}`;
    return;
  }
  const paso = (n, ok, titulo, cuerpo) => `<div class="npaso ${ok ? 'ok' : ''}"><span>${ok ? '✓' : n}</span><div><b>${titulo}</b><div class="sub">${cuerpo}</div></div></div>`;
  const p1 = paso(1, w.instalado, 'Instale Tailscale en esta computadora', w.instalado ? 'Instalado.' : `Es gratis. <a href="https://tailscale.com/download/windows" target="_blank" rel="noopener"><b>Descargar Tailscale para Windows</b></a>, instálelo y vuelva aquí.`);
  const p2 = paso(2, w.conectado, 'Inicie sesión en Tailscale', w.conectado ? `Conectado${w.cuenta ? ' como <b>' + esc(w.cuenta) + '</b>' : ''}.` : 'Clic en el icono de Tailscale junto al reloj → <b>Log in</b>, con una cuenta de Google del motel.');
  const p3 = paso(3, false, 'Active la dirección web', w.clave_default ? '<span class="malo">Primero cambie la contraseña del administrador (sigue siendo admin123): Configuración → Mi contraseña.</span>' : 'La primera vez Tailscale pide permiso: se abre una página, entre con la misma cuenta y presione <b>Enable</b>; regrese y presione otra vez Activar.');
  el.innerHTML = `${extra}<div class="npasos">${p1}${p2}${p3}</div>
    <div class="row" style="margin-top:12px"><button class="btn pri" id="webBtn" onclick="webActivar(this)" ${w.conectado && !w.clave_default ? '' : 'disabled'}>Activar dirección web</button><button class="btn" onclick="webPintar()">Volver a revisar</button></div>
    ${w.error ? `<div class="sub" style="margin-top:8px">${esc(w.error)}</div>` : ''}${quien}`;
};
