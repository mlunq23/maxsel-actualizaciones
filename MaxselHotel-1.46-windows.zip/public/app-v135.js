// Maxsel Hotel 1.35 — Rentas por semana/mes sin semanas dobles, tickets sin historial y moratorio por porcentaje
'use strict';

// ---------- Tickets: nunca "saldo a favor"; la leyenda de Maxsel no se parte a la mitad ----------
{
  const _imp = imprimir;
  imprimir = function (lineas, ...a) {
    if (Array.isArray(lineas)) {
      const marca = lineas._completo;
      lineas = lineas.map((l) => (/^SALDO A FAVOR\b/.test(String(l)) ? lin('SALDO', 'Al corriente') : l));
      if (marca) lineas._completo = true;
    }
    return _imp(lineas, ...a);
  };
}
pieCuenta = function (e) {
  const largo = e.modalidad === 'semana' || e.modalidad === 'mes', L = ['-'.repeat(W())];
  if (e.activa) L.push(lin(largo ? (e.saldo > 0.009 ? 'Renta cargada hasta' : 'Pagado hasta') : 'Check out', fechaTk(e.salida_prevista)));
  if (e.modalidad === 'semana' && e.dia_pago !== null && e.dia_pago !== undefined && typeof DIAS_PAGO !== 'undefined') L.push(lin('Día de pago', 'cada ' + DIAS_PAGO[Number(e.dia_pago)].toLowerCase()));
  L.push(e.saldo > 0.009 ? lin('SALDO PENDIENTE', money(e.saldo)) : lin('Saldo', 'Al corriente'));
  return L;
};

// ---------- Estado de cuenta y salida: solo el resumen, sin la lista de pagos anteriores ----------
{
  const _ie = imprimirEstancia;
  imprimirEstancia = async function (id, titulo, pago) {
    if (pago) return _ie(id, titulo, pago);
    const e = await GET('/api/estancias/' + id), raya = '-'.repeat(W());
    // 1.40: sin el tiempo hospedado ni los totales acumulados; solo el último pago, hasta cuándo está pagado y el saldo
    const L = [...cabeceraHuesped(e, titulo), ...(e.salida_real ? [lin('Salió', fechaTk(e.salida_real))] : [])];
    // El último cobro puede guardarse en varios renglones (renta, intereses, cuotas, varios métodos): se suman
    const ps = pagosDe(e).filter((p) => !p.cancela_id && !p.cancelado), ult = ps[ps.length - 1];
    if (ult) {
      const mismo = ps.filter((p) => p.fecha === ult.fecha), tot = mismo.reduce((a, p) => a + Number(p.monto || 0), 0), mets = [...new Set(mismo.map(metTk).filter(Boolean))];
      L.push(raya, 'ÚLTIMO PAGO', lin('Fecha', fechaTk(ult.fecha)), lin('Importe', money(tot)), ...(mets.length ? [lin('Forma de pago', mets.join(' y '))] : []));
    }
    if (e.deposito) L.push(raya, lin('Depósito en resguardo', money(e.deposito_saldo)));
    L.push(...pieCuenta(e), '', CFG.ticket_pie || '');
    imprimir(L);
  };
}

// ---------- Renovar: si ya está cargada la semana (el sistema la carga sola al llegar el día de pago), cobrar esa, no agregar otra ----------
{
  const _ext = extOk;
  let forzar = false;
  extOk = async function (id, ...a) {
    const m = document.querySelector('input[name=xM]:checked')?.value;
    if (!forzar) {
      try {
        const e = await GET('/api/estancias/' + id);
        if (e.saldo > 0.009 && (!m || m === e.modalidad) && ['semana', 'mes', 'dia'].includes(e.modalidad)) {
          const u = { semana: 'semana', mes: 'mes', dia: 'noche' }[e.modalidad];
          avisoExt(`<h3 style="margin:0 0 8px">Este huésped ya debe ${money(e.saldo)}</h3>
            <p>Su ${u} ya está cargada en la cuenta: el sistema la carga sola cuando llega su día de pago. Su cuenta ya llega hasta el <b>${fechaTk(e.salida_prevista)}</b>.</p>
            <p><b>Si viene a pagar su ${u}, toque "Cobrar lo que debe".</b> Si usa "Agregar otra ${u}" se le carga una ${u} más por adelantado.</p>`,
          [['Cobrar lo que debe', 'pri', () => { pagoModal(id, e.saldo); setTimeout(() => { const x = $('#aM'); if (x) { x.value = e.saldo.toFixed(2); x.dispatchEvent(new Event('input', { bubbles: true })); } }, 50); }],
            [`Agregar otra ${u}`, '', () => { forzar = true; extOk(id, ...a).finally(() => { forzar = false; }); }], ['Cancelar', '', () => {}]]);
          return;
        }
      } catch { /* si no se pudo revisar, sigue normal */ }
    }
    return _ext(id, ...a);
  };
}
function avisoExt(html, botones) {
  $('#avisoExt')?.remove();
  document.body.insertAdjacentHTML('beforeend', `<div id="avisoExt" style="position:fixed;inset:0;z-index:2000;background:rgba(0,0,0,.45);display:grid;place-items:center;padding:16px">
    <div class="card" style="max-width:520px;width:100%;padding:18px">${html}<div class="row" style="gap:8px;flex-wrap:wrap;justify-content:flex-end;margin-top:12px" id="avisoExtB"></div></div></div>`);
  for (const [t, c, fn] of botones) {
    const b = document.createElement('button'); b.className = 'btn ' + c; b.textContent = t;
    b.onclick = () => { $('#avisoExt')?.remove(); fn(); };
    $('#avisoExtB').appendChild(b);
  }
}

// ---------- Administrador: quitar una semana/mes cargado de más ----------
{
  const _ve = verEstancia;
  verEstancia = async function (id, ...a) {
    const r = await _ve(id, ...a);
    try {
      if (YO?.rol !== 'admin' || $('#quitarPer')) return r;
      const e = await GET('/api/estancias/' + id);
      if (!e.activa || !(e.cantidad > 1) || !['semana', 'mes', 'dia'].includes(e.modalidad)) return r;
      const u = { semana: 'semana', mes: 'mes', dia: 'noche' }[e.modalidad];
      $('#modal .mbody')?.insertAdjacentHTML('beforeend', `<div id="quitarPer" class="card" style="margin-top:10px;padding:10px 12px;display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:center">
        <div class="sub">¿Se le cargó una ${u} de más? (La cuenta llega hasta el ${fechaTk(e.salida_prevista)})</div>
        <button class="btn sm op" onclick="quitarPeriodo(${e.id},'${u}',${Number(e.precio) || 0})">Quitar 1 ${u} cargada de más</button></div>`);
    } catch { /* nada */ }
    return r;
  };
}
function quitarPeriodo(eid, u, precio) {
  modal(`Quitar 1 ${u}`, `<p>Se quita <b>1 ${u}</b> de la cuenta (${money(precio)}) y el "pagado hasta" regresa una ${u}. Úselo cuando se le cargó una ${u} dos veces.</p>
    <label class="l">Motivo<input id="qpM" placeholder="Ej. se cargó doble la semana del 13/11"></label>`,
  `<button class="btn" onclick="verEstancia(${eid})">Volver</button><button class="btn pri" onclick="quitarPeriodoOk(${eid})">Quitar</button>`);
}
async function quitarPeriodoOk(eid) {
  if (!val('qpM').trim()) return toast('Escriba el motivo', true);
  await hacer(() => POST(`/api/estancias/${eid}/quitar-periodo`, { motivo: val('qpM') }), 'Listo, se quitó');
  verEstancia(eid); vHab();
}

// ---------- Interés moratorio manual: por porcentaje de la renta ----------
if (typeof cargoModal === 'function') {
  const _cm = cargoModal;
  cargoModal = async function (eid, ...a) {
    const r = _cm(eid, ...a);
    try { cargoModal.precio = Number((await GET('/api/estancias/' + eid)).precio) || 0; } catch { cargoModal.precio = 0; }
    cargoSel();
    return r;
  };
  const _cs = cargoSel;
  cargoSel = function (soloTotal) {
    const o = cargoModal.ops.find((x) => x[0] === val('cgT')), mora = o && o[3] === 'mora';
    let box = $('#cgPctBox');
    if (!box && $('#cgD')) { $('#cgD').closest('.f').insertAdjacentHTML('afterend', `<div id="cgPctBox" class="card" style="margin:6px 0;padding:8px 12px"><label class="l">Porcentaje de la renta<input id="cgPct" type="number" min="0" step="0.5" value="${esc(CFG.mora_valor || '10')}" oninput="cargoSel(1)"></label><div class="sub" id="cgPctInfo"></div></div>`); box = $('#cgPctBox'); }
    if (box) box.hidden = !mora;
    if (mora && $('#cgPct')) {
      const pct = num('cgPct'), base = cargoModal.precio || 0;
      $('#cgM').value = (base * pct / 100).toFixed(2);
      if (!soloTotal || document.activeElement === $('#cgPct')) $('#cgD').value = `Interés moratorio ${pct}% por pago tardío`;
      $('#cgPctInfo').textContent = `${pct}% de la renta de ${money(base)} = ${money(base * pct / 100)}`;
      if (!soloTotal) return _cs(1);
    }
    return _cs(soloTotal);
  };
}
