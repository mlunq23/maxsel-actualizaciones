/* Maxsel Comedores Industriales — Ventana de cobro estilo punto de venta (la misma del gym, hotel y parking, tipo Eleventa).
   Se abre al cobrar productos en la Caja Comedor y en la Caja Tienda (F12). La checada de tarjeta y el vale no cambian.
   Formas de pago: efectivo, dólares, tarjeta, transferencia y mixto.
   F1 / Enter = cobrar e imprimir · F2 = cobrar sin imprimir · Esc = cancelar · letras = forma de pago
   Con o.siempreImprimir (opción "Imprimir el ticket automáticamente al cobrar") no aparece "Cobrar sin imprimir" y F2 también imprime. */
'use strict';
(function () {
  const CSS = `
  .vc-bg{--acc:var(--brand);
    position:fixed;inset:0;z-index:150;background:rgba(15,23,42,.58);display:flex;align-items:center;justify-content:center;padding:16px}
  .vc{background:var(--panel);border-radius:20px;box-shadow:0 30px 80px rgba(0,0,0,.35);display:grid;grid-template-columns:1fr 250px;width:min(980px,100%);max-height:calc(100vh - 32px);overflow:auto}
  .vc-main{padding:22px 26px}
  .vc-cab{display:flex;flex-direction:column;gap:2px;font-weight:800;font-size:15px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted)}
  .vc-cab small{text-transform:none;letter-spacing:0;font-weight:500}
  .vc-total{font-size:clamp(46px,7vw,72px);font-weight:800;text-align:center;letter-spacing:-.02em;margin:6px 0 0;color:var(--acc);font-variant-numeric:tabular-nums}
  .vc-usd{text-align:center;color:var(--muted);font-size:13px;margin-bottom:16px}
  .vc-mets{display:grid;grid-template-columns:repeat(auto-fit,minmax(104px,1fr));gap:10px;margin-bottom:16px}
  .vc-mets button{position:relative;border:2px solid var(--line);background:var(--panel);border-radius:14px;padding:14px 6px 10px;display:flex;flex-direction:column;align-items:center;gap:6px;cursor:pointer;font:inherit;font-weight:700;font-size:13px;color:var(--ink)}
  .vc-mets button svg{width:30px;height:30px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;color:var(--muted)}
  .vc-mets button.on{border-color:var(--acc);background:color-mix(in srgb,var(--acc) 10%,var(--panel));color:var(--acc)}
  .vc-mets button.on svg{color:var(--acc)}
  .vc kbd{font:600 10px/1 ui-monospace,monospace;border:1px solid currentColor;border-radius:4px;padding:2px 4px;opacity:.8;background:transparent;color:inherit;box-shadow:none}
  .vc-mets kbd{position:absolute;top:6px;right:6px}
  .vc-zona{min-height:140px}
  .vc-campo{display:flex;flex-direction:column;gap:6px;font-weight:700;font-size:13px;color:var(--muted)}
  .vc-campo input{font-size:30px;font-weight:800;padding:10px 14px;border-radius:12px;color:var(--ink);border:1px solid var(--line);width:100%;margin:0}
  .vc-mix{display:grid;grid-template-columns:1fr 1fr;gap:12px}.vc-mix .vc-campo input{font-size:22px}
  .vc-bill{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}
  .vc-bill button{border:1px solid var(--line);background:var(--bg);border-radius:10px;padding:10px 14px;font:inherit;font-weight:800;font-size:15px;cursor:pointer;color:var(--ink)}
  .vc-bill button:hover{border-color:var(--acc);color:var(--acc)}
  .vc-fijo{display:flex;justify-content:space-between;align-items:center;gap:12px;border:1px dashed var(--line);border-radius:12px;padding:14px 16px;margin-bottom:12px;color:var(--ink)}
  .vc-fijo b{font-size:26px}
  .vc-lado{background:var(--bg);border-left:1px solid var(--line);padding:22px 16px;display:flex;flex-direction:column;gap:10px;border-radius:0 20px 20px 0}
  .vc-b{display:flex;align-items:center;gap:10px;justify-content:flex-start;border:1px solid var(--line);background:var(--panel);border-radius:12px;padding:14px;font:inherit;font-weight:700;font-size:15px;cursor:pointer;color:var(--ink)}
  .vc-b.pri{background:var(--ok);color:#fff;border-color:var(--ok);font-size:16px;padding:18px 14px}
  .vc-b:disabled{opacity:.5;cursor:not-allowed}
  .vc-art{display:flex;flex-direction:column;align-items:center;text-align:center;gap:2px;margin-top:6px;font-weight:600;color:var(--muted)}
  .vc-art b{font-size:26px;color:var(--ink)}
  .vc-art b.cambio{font-size:38px;color:var(--ok)}.vc-art b.malo{font-size:30px;color:var(--bad)}
  .vc-nota{font-size:13px;color:var(--muted);margin:8px 0 0}
  .vc-sub{border:2px dashed var(--line);border-radius:14px;padding:10px 12px;margin:10px 0 4px;display:flex;align-items:center;gap:10px;flex-wrap:wrap}
  .vc-sub .t{font-weight:800;font-size:13px;color:var(--muted);text-transform:uppercase;letter-spacing:.04em;width:100%}
  .vc-sub input{flex:1;min-width:180px;font-size:20px;font-weight:700;padding:9px 12px;border-radius:10px;border:1px solid var(--line);margin:0}
  .vc-sub button{border:0;border-radius:10px;padding:11px 14px;font:inherit;font-weight:800;cursor:pointer;background:#5b3fb0;color:#fff;display:flex;align-items:center;gap:6px}
  .vc-sub.on{border:2px solid var(--ok);background:color-mix(in srgb,var(--ok) 9%,var(--panel))}
  .vc-sub.on.vale{border-color:#5b3fb0;background:#f3eefe}
  .vc-sub.on b{font-size:18px;flex:1}.vc-sub.on .m{font-size:22px;color:var(--ok)}.vc-sub.on.vale .m{color:#5b3fb0}
  .vc-sub.on button{background:transparent;color:var(--muted);border:1px solid var(--line);padding:7px 10px;font-size:13px}
  .vc-sub small{width:100%;color:var(--muted);font-size:12px}.vc-sub .err{color:var(--bad);font-weight:700}
  .vc-cubierto{border:2px solid var(--ok);border-radius:14px;padding:22px;text-align:center;font-size:20px;font-weight:800;color:var(--ok);background:color-mix(in srgb,var(--ok) 8%,var(--panel))}
  @media (max-width:760px){.vc{grid-template-columns:1fr}.vc-lado{border-left:0;border-top:1px solid var(--line);border-radius:0 0 20px 20px}}`;
  const st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);

  const METODOS = [
    ['efectivo', 'Efectivo', 'E', '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M6 9v.01M18 15v.01"/>'],
    ['dolares', 'Dólares', 'D', '<path d="M12 2v20M17 6.5c-1-1.3-2.7-2-5-2-3 0-4.5 1.5-4.5 3.5 0 4.5 10 2.5 10 7.5 0 2-1.8 3.5-5 3.5-2.4 0-4.2-.8-5.3-2.2"/>'],
    ['tarjeta', 'Tarjeta', 'T', '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h4"/>'],
    ['transferencia', 'Transferencia', 'R', '<path d="M4 8h13l-3-3M20 16H7l3 3"/>'],
    ['credito', 'A crédito', 'C', '<path d="M4 4h12a2 2 0 0 1 2 2v14l-4-2-4 2-4-2-4 2V6a2 2 0 0 1 2-2z"/><path d="M8 9h6M8 13h4"/>'],
    ['mixto', 'Mixto', 'M', '<circle cx="9" cy="9" r="5"/><circle cx="15" cy="15" r="5"/>'],
  ];
  const BILLETES = [20, 50, 100, 200, 500, 1000], BILL_USD = [1, 5, 10, 20, 50, 100];
  const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
  const dinero = (n) => '$' + Number(n || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const escV = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let VC = null;
  const $v = (s) => VC && VC.el.querySelector(s);
  const usdTotal = () => Math.ceil((VC.total / VC.tc) * 100) / 100;
  const aviso = (m) => { const z = VC && VC.el.querySelector('#vcRes'); if (z) { z.innerHTML = `<span>⚠</span><b class="malo" style="font-size:17px">${escV(m)}</b>`; } else alert(m); };

  // o: { total, tc, titulo, detalle, articulos, metodo,
  //      subsidio: { monto, aplicado: {tipo:'empleado'|'vale', tarjeta, nombre} | null, validar: async (tarjeta) => ({ tarjeta, nombre }) o error, alCambiar(sub) } }
  // Con "subsidio" (tienda) el cajero puede escanear la tarjeta del empleado o marcar vale DENTRO de esta ventana.
  // Regresa null si se cancela, o { valores: { efectivo, usd, tarjeta, transferencia, credito, referencia }, imprimir, recibido, cambio }
  window.ventanaCobro = function (o) {
    return new Promise((ok) => {
      if (VC) return ok(null);
      const tc = Number(o.tc || 0), base = r2(o.total), total = base;
      const mets = METODOS.filter((m) => (m[0] !== 'dolares' || tc > 0) && (m[0] !== 'credito' || o.credito));
      const bg = document.createElement('div'); bg.className = 'vc-bg';
      bg.innerHTML = `<div class="vc" role="dialog" aria-modal="true" aria-label="Cobrar">
        <div class="vc-main"><div class="vc-cab"><span>${escV(o.titulo || 'Cobrar')}</span>${o.detalle ? `<small>${escV(o.detalle)}</small>` : ''}</div>
          ${o.subsidio ? '<div class="vc-sub" id="vcSub"></div>' : ''}
          <div class="vc-total">${dinero(total)}</div><div class="vc-usd">${tc > 0 ? `US$${(Math.ceil((total / tc) * 100) / 100).toFixed(2)} · dólar a ${dinero(tc)}` : 'Sin tipo de cambio en el turno'}</div>
          <div class="vc-mets">${mets.map(([k, n, t, svg]) => `<button type="button" data-m="${k}"><svg viewBox="0 0 24 24">${svg}</svg><span>${n}</span><kbd>${t}</kbd></button>`).join('')}</div>
          <div class="vc-zona" id="vcZ"></div></div>
        <div class="vc-lado"><button type="button" class="vc-b pri" data-ok="1"><kbd>F1</kbd>${o.siempreImprimir ? 'Cobrar e imprimir ticket' : 'Cobrar e imprimir'}</button>${o.siempreImprimir ? '' : '<button type="button" class="vc-b" data-ok="0"><kbd>F2</kbd>Cobrar sin imprimir</button>'}<button type="button" class="vc-b" data-x><kbd>Esc</kbd>Cancelar</button>
          ${o.articulos !== undefined ? `<div class="vc-art"><span>Artículos</span><b>${o.articulos}</b></div>` : ''}
          <div class="vc-art" id="vcRes"></div></div></div>`;
      document.body.appendChild(bg);
      VC = { ...o, base, total, tc, ok, metodo: 'efectivo', el: bg, sub: o.subsidio ? { ...o.subsidio } : null };
      bg.querySelectorAll('.vc-mets button').forEach((b) => (b.onclick = () => vcMetodo(b.dataset.m, true)));
      bg.querySelectorAll('[data-ok]').forEach((b) => (b.onclick = () => vcOk(b.dataset.ok === '1')));
      bg.querySelector('[data-x]').onclick = vcCancelar;
      VC.metodo = o.metodo || 'efectivo';
      if (VC.sub) pintarSub(); else vcMetodo(VC.metodo);
    });
  };
  // ---------- Subsidio dentro de la ventana (tarjeta del empleado o vale) ----------
  function pintarSub(foco) {
    const S = VC.sub, box = $v('#vcSub'), ap = S.aplicado;
    const desc = ap ? r2(Math.min(VC.base, S.monto)) : 0;
    VC.total = r2(VC.base - desc);
    box.className = 'vc-sub' + (ap ? ' on' + (ap.tipo === 'vale' ? ' vale' : '') : '');
    box.innerHTML = ap
      ? `<span style="font-size:24px">${ap.tipo === 'vale' ? '🎟️' : '🎁'}</span><b>${ap.tipo === 'vale' ? 'Pago con vale' : escV(ap.nombre)}</b><span class="m">−${dinero(desc)}</span><button type="button" data-q>Quitar</button>
         <small>Subsidio de la empresa (${dinero(S.monto)} por día). Productos ${dinero(VC.base)}.</small>`
      : `<span class="t">🎁 Subsidio de la empresa · ${dinero(S.monto)}</span><input id="vcSubT" autocomplete="off" placeholder="Escanee la tarjeta del empleado"><button type="button" data-v>🎟️ Vale <kbd>V</kbd></button>
         <small id="vcSubM">Enter sin tarjeta = cobrar sin subsidio (público en general).</small>`;
    const q = box.querySelector('[data-q]'); if (q) q.onclick = () => cambiarSub(null);
    const v = box.querySelector('[data-v]'); if (v) v.onclick = () => cambiarSub({ tipo: 'vale', tarjeta: '', nombre: 'Pago con vale' });
    $v('.vc-total').textContent = dinero(VC.total);
    $v('.vc-usd').textContent = VC.total <= 0 ? 'Cubierto por el subsidio' : VC.tc > 0 ? `US$${usdTotal().toFixed(2)} · dólar a ${dinero(VC.tc)}` : 'Sin tipo de cambio en el turno';
    const cubierto = VC.total <= 0;
    $v('.vc-mets').style.display = cubierto ? 'none' : '';
    VC.el.querySelector('[data-ok="1"]').innerHTML = `<kbd>F1</kbd>${cubierto ? 'Registrar e imprimir' : 'Cobrar e imprimir'}${VC.siempreImprimir ? ' ticket' : ''}`;
    const sinImp = VC.el.querySelector('[data-ok="0"]');
    if (sinImp) sinImp.innerHTML = `<kbd>F2</kbd>${cubierto ? 'Registrar sin imprimir' : 'Cobrar sin imprimir'}`;
    if (cubierto) {
      $v('#vcZ').innerHTML = `<div class="vc-cubierto">✔ El subsidio cubre toda la compra<br><span style="font-size:14px;font-weight:600;color:var(--muted)">Presione F1 o Enter para registrar el consumo</span></div>`;
      $v('#vcRes').innerHTML = `<span>No paga</span><b class="cambio">$0.00</b>`;
      setTimeout(() => VC?.el.querySelector('.vc-b.pri')?.focus(), 0);
    } else {
      vcMetodo(VC.metodo);
      if (!ap && foco !== false) setTimeout(() => $v('#vcSubT')?.focus(), 0);
    }
  }
  function cambiarSub(nuevo) {
    VC.sub.aplicado = nuevo; VC.sub.alCambiar && VC.sub.alCambiar(nuevo); pintarSub(!nuevo);
  }
  async function validarTarjeta() {
    const i = $v('#vcSubT'), t = (i?.value || '').trim();
    if (!t) { pintarSub(false); $v('#vcZ input')?.focus(); return; } // sin tarjeta: pasa al pago
    i.disabled = true;
    try { const r = await VC.sub.validar(t); if (!VC) return; cambiarSub({ tipo: 'empleado', tarjeta: r.tarjeta, nombre: r.nombre }); }
    catch (e) { if (!VC) return; i.disabled = false; i.value = ''; const m = $v('#vcSubM'); if (m) { m.className = 'err'; m.textContent = '⛔ ' + e.message; } i.focus(); }
  }
  window.ventanaCobroAbierta = () => !!VC;

  function vcMetodo(m, foco) {
    if (!VC) return;
    VC.metodo = m; VC.el.querySelectorAll('.vc-mets button').forEach((b) => b.classList.toggle('on', b.dataset.m === m));
    const T = VC.total, z = $v('#vcZ');
    const campo = (id, label, extra = '') => `<label class="vc-campo"><span>${label}</span><input id="${id}" type="number" min="0" step="0.01" inputmode="decimal" ${extra}></label>`;
    if (m === 'efectivo') z.innerHTML = `${campo('vcPa', 'Pagó con (pesos)', `placeholder="${T.toFixed(2)}"`)}<div class="vc-bill"><button type="button" data-b="0">Exacto</button>${BILLETES.map((b) => `<button type="button" data-b="${b}">$${b}</button>`).join('')}</div>`;
    else if (m === 'dolares') z.innerHTML = `${campo('vcPa', 'Dólares recibidos (US$)', `placeholder="${usdTotal().toFixed(2)}"`)}<div class="vc-bill"><button type="button" data-b="0">Exacto</button>${BILL_USD.map((b) => `<button type="button" data-b="${b}">US$${b}</button>`).join('')}</div><p class="vc-nota">El cambio se entrega en pesos.</p>`;
    else if (m === 'tarjeta' || m === 'transferencia') z.innerHTML = `<div class="vc-fijo"><span>Se cobra con ${m === 'tarjeta' ? 'tarjeta (terminal bancaria)' : 'transferencia'}</span><b>${dinero(T)}</b></div><label class="vc-campo"><span>${m === 'tarjeta' ? 'Últimos 4 dígitos / autorización (opcional)' : 'Folio o referencia (opcional)'}</span><input id="vcRef" autocomplete="off" style="font-size:20px"></label>`;
    else if (m === 'credito') z.innerHTML = `<div class="vc-fijo"><span>Se carga a la cuenta de <b style="font-size:inherit">${escV(VC.credito)}</b></span><b>${dinero(T)}</b></div><p class="vc-nota">Queda como cuenta por cobrar; el cliente puede abonar después.</p>`;
    else z.innerHTML = `<div class="vc-mix">${campo('vcEf', 'Efectivo (pesos)')}${VC.tc > 0 ? campo('vcUs', 'Dólares (US$)') : ''}${campo('vcTa', 'Tarjeta')}${campo('vcTr', 'Transferencia')}${VC.credito ? campo('vcCr', 'A crédito (cuenta)') : ''}</div><label class="vc-campo" style="margin-top:10px"><span>Referencia de tarjeta / transferencia (opcional)</span><input id="vcRef" autocomplete="off" style="font-size:18px"></label>`;
    z.querySelectorAll('input[type=number]').forEach((i) => (i.oninput = vcCalc));
    z.querySelectorAll('[data-b]').forEach((b) => (b.onclick = () => vcBill(Number(b.dataset.b))));
    vcCalc();
    if (foco || !(VC.sub && !VC.sub.aplicado)) setTimeout(() => (z.querySelector('input') || VC?.el.querySelector('.vc-b.pri'))?.focus(), 0);
  }
  function vcBill(b) {
    const i = $v('#vcPa'); if (!i) return;
    if (!b) i.value = VC.metodo === 'dolares' ? usdTotal().toFixed(2) : VC.total.toFixed(2);
    else i.value = ((parseFloat(i.value) || 0) + b).toFixed(2); // se van sumando los billetes que da el cliente
    vcCalc(); i.focus();
  }
  function vcRecibido() {
    const m = VC.metodo, T = VC.total, g = (id) => parseFloat($v('#' + id)?.value) || 0, ref = $v('#vcRef')?.value.trim() || '';
    const base = { efectivo: 0, usd: 0, tarjeta: 0, transferencia: 0, credito: 0, referencia: '' };
    if (m === 'efectivo') { const p = g('vcPa') || T; return { v: { ...base, efectivo: p }, total: p }; }
    if (m === 'dolares') { const u = g('vcPa') || usdTotal(); return { v: { ...base, usd: u }, total: r2(u * VC.tc), usd: u }; }
    if (m === 'tarjeta') return { v: { ...base, tarjeta: T, referencia: ref ? 'Tarjeta ' + ref : '' }, total: T };
    if (m === 'transferencia') return { v: { ...base, transferencia: T, referencia: ref ? 'Transf. ' + ref : '' }, total: T };
    if (m === 'credito') return { v: { ...base, credito: T }, total: T };
    const v = { ...base, efectivo: g('vcEf'), usd: g('vcUs'), tarjeta: g('vcTa'), transferencia: g('vcTr'), credito: g('vcCr'), referencia: ref };
    return { v, total: r2(v.efectivo + v.usd * VC.tc + v.tarjeta + v.transferencia + v.credito), usd: v.usd };
  }
  function vcCalc() {
    if (!VC) return;
    const r = vcRecibido(), T = VC.total, falta = r2(T - r.total), el = $v('#vcRes');
    el.innerHTML = falta > 0.009 ? `<span>Faltan</span><b class="malo">${dinero(falta)}</b>` : `<span>Cambio</span><b class="cambio">${dinero(r.total - T)}</b>${r.usd ? `<small>Recibe US$${r.usd.toFixed(2)} = ${dinero(r.usd * VC.tc)}</small>` : ''}`;
    VC.onCambio && VC.onCambio({ pagado: r.total, dif: r2(r.total - T) });
  }
  function cerrar() { if (!VC) return; VC.el.remove(); VC = null; }
  function vcCancelar() { if (!VC) return; const ok = VC.ok; cerrar(); ok(null); }
  function vcOk(imprimir) {
    if (!VC) return;
    if (VC.siempreImprimir) imprimir = true; // ticket automático: todo cobro imprime
    const subsidio = VC.sub ? VC.sub.aplicado : null;
    if (VC.total <= 0) { const ok = VC.ok; cerrar(); ok({ valores: {}, imprimir, recibido: 0, cambio: 0, subsidio }); return; }
    const r = vcRecibido(), T = VC.total;
    if (r.total + 0.009 < T) { aviso('Faltan ' + dinero(T - r.total)); return; }
    if (r.v.tarjeta + r.v.transferencia + r.v.credito > T + 0.009) { aviso('Tarjeta, transferencia y crédito no pueden pasar del total (el cambio solo se da en efectivo)'); return; }
    const ok = VC.ok; cerrar();
    ok({ valores: r.v, imprimir, recibido: r.total, cambio: Math.max(0, r2(r.total - T)), subsidio });
  }
  document.addEventListener('keydown', (e) => {
    if (!VC) return;
    const k = e.key, a = document.activeElement, enTexto = a && a.closest && a.closest('.vc') && a.tagName === 'INPUT' && a.type !== 'number';
    if (a && a.id === 'vcSubT' && k === 'Enter') { e.preventDefault(); e.stopImmediatePropagation(); validarTarjeta(); return; }
    if (!enTexto && (k === 'v' || k === 'V') && VC.sub && !VC.sub.aplicado) { e.preventDefault(); e.stopImmediatePropagation(); cambiarSub({ tipo: 'vale', tarjeta: '', nombre: 'Pago con vale' }); return; }
    if (k === 'F1' || (k === 'Enter' && !(a && a.tagName === 'BUTTON'))) { e.preventDefault(); e.stopImmediatePropagation(); vcOk(true); return; }
    if (k === 'F2') { e.preventDefault(); e.stopImmediatePropagation(); vcOk(false); return; }
    if (k === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); vcCancelar(); return; }
    if (/^F\d+$/.test(k)) { e.preventDefault(); e.stopImmediatePropagation(); return; }
    if (!enTexto && k.length === 1 && /[a-z]/i.test(k) && !e.ctrlKey && !e.altKey) {
      const m = METODOS.find((x) => x[2] === k.toUpperCase() && VC.el.querySelector(`.vc-mets button[data-m="${x[0]}"]`));
      e.preventDefault(); e.stopImmediatePropagation(); if (m) vcMetodo(m[0], true);
    }
  }, true);
})();
