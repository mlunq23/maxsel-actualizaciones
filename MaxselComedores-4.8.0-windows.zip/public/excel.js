// Lector mínimo de archivos Excel (.xlsx) y CSV, sin internet ni librerías.
// Devuelve un arreglo de filas: [[celda, celda, ...], ...] de la primera hoja.
async function leerArchivoTabla(file) {
  const nombre = file.name.toLowerCase();
  if (nombre.endsWith('.xlsx')) return leerXLSX(await file.arrayBuffer());
  if (nombre.endsWith('.xls')) throw new Error('El formato .xls antiguo no es compatible. En Excel use "Guardar como" → "Libro de Excel (.xlsx)" o "CSV".');
  return leerCSV(await file.text());
}

function leerCSV(texto) {
  texto = texto.replace(/^﻿/, '');
  const primera = texto.split(/\r?\n/)[0] || '';
  const sep = [';', '\t', ','].sort((a, b) => primera.split(b).length - primera.split(a).length)[0];
  const filas = []; let fila = [], campo = '', comillas = false;
  for (let i = 0; i < texto.length; i++) {
    const ch = texto[i];
    if (comillas) {
      if (ch === '"' && texto[i + 1] === '"') { campo += '"'; i++; }
      else if (ch === '"') comillas = false;
      else campo += ch;
    } else if (ch === '"') comillas = true;
    else if (ch === sep) { fila.push(campo); campo = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && texto[i + 1] === '\n') i++;
      fila.push(campo); filas.push(fila); fila = []; campo = '';
    } else campo += ch;
  }
  if (campo || fila.length) { fila.push(campo); filas.push(fila); }
  return filas.filter(f => f.some(c => String(c).trim() !== ''));
}

async function leerXLSX(buf) {
  const archivos = await descomprimirZip(buf);
  const xml = t => new DOMParser().parseFromString(t, 'application/xml');
  const strings = [];
  if (archivos['xl/sharedStrings.xml']) {
    xml(archivos['xl/sharedStrings.xml']).querySelectorAll('si').forEach(si => {
      strings.push(Array.from(si.getElementsByTagName('t')).map(t => t.textContent).join(''));
    });
  }
  const hojaNombre = Object.keys(archivos).filter(k => /^xl\/worksheets\/sheet\d+\.xml$/.test(k)).sort()[0];
  if (!hojaNombre) throw new Error('No se encontró ninguna hoja en el archivo de Excel.');
  const hoja = xml(archivos[hojaNombre]);
  const filas = [];
  hoja.querySelectorAll('sheetData > row').forEach(r => {
    const fila = [];
    r.querySelectorAll('c').forEach(c => {
      const ref = c.getAttribute('r') || '';
      const col = ref.replace(/\d+/g, '').split('').reduce((n, l) => n * 26 + l.charCodeAt(0) - 64, 0) - 1;
      const tipo = c.getAttribute('t');
      const v = c.getElementsByTagName('v')[0];
      let val = '';
      if (tipo === 's' && v) val = strings[parseInt(v.textContent)] || '';
      else if (tipo === 'inlineStr') val = Array.from(c.getElementsByTagName('t')).map(t => t.textContent).join('');
      else if (v) val = v.textContent;
      fila[col >= 0 ? col : fila.length] = val;
    });
    for (let i = 0; i < fila.length; i++) if (fila[i] === undefined) fila[i] = '';
    if (fila.some(x => String(x).trim() !== '')) filas.push(fila);
  });
  return filas;
}

async function descomprimirZip(buf) {
  const dv = new DataView(buf); const u8 = new Uint8Array(buf);
  let eocd = -1;
  for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 66000); i--) {
    if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('El archivo no parece ser un Excel válido.');
  const total = dv.getUint16(eocd + 10, true);
  let p = dv.getUint32(eocd + 16, true);
  const out = {}; const dec = new TextDecoder();
  for (let n = 0; n < total; n++) {
    const metodo = dv.getUint16(p + 10, true);
    const tamComp = dv.getUint32(p + 20, true);
    const lenNom = dv.getUint16(p + 28, true), lenExtra = dv.getUint16(p + 30, true), lenCom = dv.getUint16(p + 32, true);
    const offLocal = dv.getUint32(p + 42, true);
    const nombre = dec.decode(u8.subarray(p + 46, p + 46 + lenNom));
    p += 46 + lenNom + lenExtra + lenCom;
    if (!/^xl\/(sharedStrings|worksheets\/sheet\d+)\.xml$/.test(nombre)) continue;
    const ini = offLocal + 30 + dv.getUint16(offLocal + 26, true) + dv.getUint16(offLocal + 28, true);
    const datos = u8.subarray(ini, ini + tamComp);
    if (metodo === 0) out[nombre] = dec.decode(datos);
    else {
      const ds = new DecompressionStream('deflate-raw');
      const stream = new Blob([datos]).stream().pipeThrough(ds);
      out[nombre] = await new Response(stream).text();
    }
  }
  return out;
}
