// =====================================================
//  SISTEMA DE COMEDOR INDUSTRIAL  v3  (base de datos SQLite)
//  Servidor local: no requiere internet ni instalar nada más.
// =====================================================
const _emit = process.emitWarning;
process.emitWarning = function (w, ...a) { if (String(w && w.message || w).includes('SQLite')) return; return _emit.call(process, w, ...a); };

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { DatabaseSync } = require('node:sqlite');
const https = require('https');
const zlib = require('zlib');

const VERSION = '4.10.0';
const ARRANQUE = Date.now().toString(36);          // cambia cada vez que se reinicia el sistema
const PORT = Number(process.env.PORT) || 3000;
const BASE_DIR = __dirname;
const DATA_DIR = path.join(BASE_DIR, 'datos');
const DB_FILE = path.join(DATA_DIR, 'comedor.db');
const JSON_VIEJO = path.join(DATA_DIR, 'base_de_datos.json');
const BACKUP_DIR = path.join(DATA_DIR, 'respaldos');
const ARCHIVO_DIR = path.join(DATA_DIR, 'archivo_historico');
const PUBLIC_DIR = path.join(__dirname, 'public');
const MAX_RESPALDOS = 30;

for (const d of [DATA_DIR, BACKUP_DIR, ARCHIVO_DIR]) if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });

// ---------- Utilidades ----------
const pad = n => String(n).padStart(2, '0');
const fechaLocal = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const horaLocal = d => pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
const r2 = n => Math.round((Number(n) || 0) * 100) / 100;
const limpiarTarjeta = t => String(t ?? '').trim().replace(/^0+(?=\d)/, '');
class ErrorUsuario extends Error { constructor(m, code = 400) { super(m); this.code = code; } }
function log(...a) { console.log('[' + fechaLocal(new Date()) + ' ' + horaLocal(new Date()) + ']', ...a); }

// ---------- Licencia ----------
// La clave pública la pone CREAR_INSTALADOR.bat. Solo quien tiene la clave privada (el generador) puede crear licencias.
const CLAVE_PUBLICA = 'MCowBQYDK2VwAyEAi/wAhM5arUYPIn255kBcHLBSZaSph5tg57HBbYNPPHI=';
const crypto = require('crypto');
const LIC_FILE = path.join(DATA_DIR, 'licencia.txt');
const B32 = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
function b32enc(buf) { let bits = 0, val = 0, out = ''; for (const b of buf) { val = (val << 8) | b; bits += 8; while (bits >= 5) { out += B32[(val >>> (bits - 5)) & 31]; bits -= 5; } } if (bits > 0) out += B32[(val << (5 - bits)) & 31]; return out; }
function b32dec(s) {
  s = String(s).toUpperCase().replace(/[^0-9A-Z]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1');
  const out = []; let bits = 0, val = 0;
  for (const ch of s) { const i = B32.indexOf(ch); if (i < 0) throw new Error('Carácter inválido'); val = (val << 5) | i; bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } }
  return Buffer.from(out);
}
let _equipo = null;
function idEquipoBytes() {
  if (_equipo) return _equipo;
  let base = '';
  try {
    if (process.platform === 'win32') {
      const r = require('child_process').execSync('reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid', { encoding: 'utf8', windowsHide: true });
      const m = r.match(/MachineGuid\s+REG_SZ\s+([0-9a-fA-F-]+)/); if (m) base = m[1].toLowerCase();
    }
  } catch (e) {}
  if (!base) base = os.hostname() + '|' + (os.cpus()[0] || {}).model + '|' + os.totalmem();
  _equipo = crypto.createHash('sha256').update('comedor-industrial|' + base).digest().subarray(0, 10);
  return _equipo;
}
const codigoEquipo = () => b32enc(idEquipoBytes()).match(/.{1,4}/g).join('-');
const DIA0 = Date.UTC(2020, 0, 1);
// Módulos que Maxsel vende aparte y se activan desde la licencia (un bit por módulo, igual en todos los sistemas Maxsel).
// Este sistema de comedor TODAVÍA NO TIENE módulo de Gastos ni de Asistencia (checador): los bits quedan reservados.
// (El consumo de empleados con tarjeta es parte del sistema base y NO depende de ningún módulo.)
const MODULOS = { gastos: 1, asistencia: 2 };
const NOMBRE_MODULO = { gastos: 'Gastos', asistencia: 'Asistencia (checador de empleados)' };
const MOD_TODOS = 255;
const modulosDe = b => Object.fromEntries(Object.entries(MODULOS).map(([k, bit]) => [k, !!(b & bit)]));
function modulosPrueba() { // en modo desarrollo se pueden apagar para probar: MAXSEL_SIN_MODULOS=gastos,asistencia
  const sin = String(process.env.MAXSEL_SIN_MODULOS || '').split(',').map(x => x.trim());
  return Object.fromEntries(Object.keys(MODULOS).map(k => [k, !sin.includes(k)]));
}
const moduloActivo = k => (LICENCIA.modulos ? LICENCIA.modulos[k] !== false : true);
// Rutas que pertenecen a cada módulo. Vacío: este sistema aún no tiene pantallas de Gastos ni de Asistencia.
// Cuando se agreguen, ponga aquí sus rutas, p. ej. ['gastos', /^\/api\/(admin\/)?gastos(\/|$)/]
const RUTAS_MODULO = [];
const moduloDeRuta = r0 => (RUTAS_MODULO.find(([, re]) => re.test(r0)) || [])[0] || null;
const SIN_MODULO = k => `El módulo de ${NOMBRE_MODULO[k] || k} no está incluido en la licencia de este negocio. Para activarlo comuníquese con Maxsel.`;
function leerLicencia(clave) {
  if (!clave) return { activa: false, motivo: 'Sin licencia' };
  try {
    const buf = b32dec(String(clave).replace(/^CI1-?/i, ''));
    // Versión 1: sin módulos (trae todo). Versión 2: un byte extra después del nombre con los módulos vendidos (va dentro de lo firmado).
    // Versión 3: además 2 bytes con la vigencia de la NUBE (monitoreo desde el teléfono): 0 = no incluida, 65535 = permanente, otro = días desde 2020-01-01.
    if (buf.length < 14 + 64 || ![1, 2, 3].includes(buf[0])) throw new Error();
    const nl = buf[13], extra = buf[0] === 3 ? 3 : buf[0] === 2 ? 1 : 0;
    if (buf.length < 14 + nl + extra + 64) throw new Error();
    const payload = buf.subarray(0, 14 + nl + extra), firma = buf.subarray(14 + nl + extra, 14 + nl + extra + 64);
    const pub = crypto.createPublicKey({ key: Buffer.from(CLAVE_PUBLICA, 'base64'), format: 'der', type: 'spki' });
    if (!crypto.verify(null, payload, pub, firma)) return { activa: false, motivo: 'La licencia no es válida para este instalador: fue hecha con OTRO generador de licencias (otra carpeta o copia). Use el generador de la misma carpeta con la que se creó el instalador.' };
    if (!payload.subarray(1, 11).equals(idEquipoBytes())) return { activa: false, motivo: 'Esta licencia es de OTRA computadora' };
    const dias = payload.readUInt16BE(11);
    const cliente = payload.subarray(14, 14 + nl).toString('utf8');
    const expira = dias ? new Date(DIA0 + dias * 86400000).toISOString().slice(0, 10) : null;
    const nd = extra === 3 ? payload.readUInt16BE(15 + nl) : 0;
    const nube = nd === 0 ? null : nd === 0xFFFF ? 'PERM' : new Date(DIA0 + nd * 86400000).toISOString().slice(0, 10);
    if (expira && expira < fechaLocal(new Date())) return { activa: false, cliente, expira, nube, motivo: 'La licencia VENCIÓ el ' + expira.split('-').reverse().join('/') };
    return { activa: true, cliente, expira, nube, modulos: modulosDe(extra ? payload[14 + nl] : MOD_TODOS) };
  } catch (e) { return { activa: false, motivo: 'La clave de licencia está incompleta o mal escrita' }; }
}
const MODO_DESARROLLO = CLAVE_PUBLICA.startsWith('__');
let LICENCIA = { activa: false };
function revisarLicencia() {
  if (MODO_DESARROLLO) { LICENCIA = { activa: true, cliente: 'Modo desarrollo', expira: null, modulos: modulosPrueba() }; return; }
  let clave = ''; try { clave = fs.readFileSync(LIC_FILE, 'utf8').trim(); } catch (e) {}
  LICENCIA = leerLicencia(clave);
}

// ---------- Nube (Tailscale + Funnel): monitoreo desde el teléfono, igual que Maxsel Tech ----------
// - Con la app de Tailscale en el teléfono: http://<ip-tailscale>:3000/monitor
// - SIN instalar nada en el teléfono: Tailscale Funnel publica https://<computadora>.<red>.ts.net/monitor
// Seguridad: Funnel NO apunta al sistema (3000) sino a un puerto aparte (3002) que solo escucha en esta computadora
// y SOLO deja pasar el monitor (solo lectura, con el PIN de administrador). Cobrar, checar, configuración,
// respaldos… NO se pueden alcanzar desde internet. La nube tiene vigencia (va en la licencia) igual que la póliza.
const NUBE_FILE = path.join(DATA_DIR, 'licencia_nube.txt');
const PUERTO_NUBE = 3002;
function hoyNube() { // la fecha no puede ir hacia atrás (si alguien atrasa el reloj para alargar la nube)
  let hoy = fechaLocal(new Date());
  try { const vista = cfg().nube_reloj || ''; if (vista > hoy) hoy = vista; else if (vista !== hoy) setCfg('nube_reloj', hoy); } catch (e) {}
  return hoy;
}
function licenciaNube() {
  if (MODO_DESARROLLO && !process.env.MAXSEL_NUBE_PRUEBA) return { equipo: codigoEquipo(), incluida: true, activa: true, permanente: true, vence: '', dias: 99999, vencida: false };
  let otra = ''; try { otra = fs.readFileSync(NUBE_FILE, 'utf8').trim(); } catch (e) {}
  let base = ''; try { base = fs.readFileSync(LIC_FILE, 'utf8').trim(); } catch (e) {}
  let f = null;
  for (const c of [base, otra, process.env.MAXSEL_NUBE_PRUEBA || '']) {
    const n = c ? leerLicencia(c).nube : null;
    if (n === 'PERM' || f === 'PERM') f = 'PERM'; else if (n && (!f || n > f)) f = n;
  }
  const equipo = codigoEquipo();
  if (!f) return { equipo, incluida: false, activa: false, vence: '', dias: 0, vencida: false, permanente: false };
  if (f === 'PERM') return { equipo, incluida: true, activa: true, vence: '', dias: 99999, vencida: false, permanente: true };
  const dias = Math.round((Date.parse(f + 'T00:00:00Z') - Date.parse(hoyNube() + 'T00:00:00Z')) / 86400000);
  return { equipo, incluida: true, activa: dias >= 0, vence: f, dias, vencida: dias < 0, permanente: false };
}
const esEstaPC = req => ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress || '');
function soloEstaPC(req) { if (!esEstaPC(req)) throw new ErrorUsuario('La nube solo se configura desde la computadora principal del comedor.', 403); }
function exeTailscale() {
  const c = process.platform === 'win32'
    ? [path.join(process.env.ProgramFiles || 'C:\\Program Files', 'Tailscale', 'tailscale.exe'), path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Tailscale', 'tailscale.exe')]
    : String(process.env.PATH || '').split(path.delimiter).map(d => path.join(d, 'tailscale'));
  return c.find(f => { try { return fs.existsSync(f); } catch (e) { return false; } }) || '';
}
const RE_TS_LOGIN = /https:\/\/login\.tailscale\.com\/\S+/;
function correrTS(seg, args) {
  return new Promise(resolve => {
    const exe = exeTailscale();
    if (!exe) return resolve({ out: '', error: 'Tailscale no está instalado en esta computadora.' });
    let out = '', fin = false, c;
    try { c = require('child_process').spawn(exe, args, { windowsHide: true }); } catch (e) { return resolve({ out: '', error: String(e.message || e) }); }
    const terminar = r => { if (fin) return; fin = true; clearTimeout(t); clearInterval(iv); resolve(r); };
    c.stdout.on('data', d => out += d); c.stderr.on('data', d => out += d);
    c.on('error', e => terminar({ out, error: String(e.message || e) }));
    c.on('close', code => terminar({ out, error: code === 0 ? '' : (out.trim() || 'código ' + code) }));
    // si Tailscale pide habilitar Funnel en la cuenta, regresamos el enlace en lugar de esperar
    const iv = setInterval(() => { if (RE_TS_LOGIN.test(out)) { try { c.kill(); } catch (e) {} terminar({ out, error: '' }); } }, 300);
    const t = setTimeout(() => { try { c.kill(); } catch (e) {} terminar({ out, error: 'Tailscale no respondió a tiempo.' }); }, seg * 1000);
  });
}
async function estadoNube() {
  const exe = exeTailscale(), o = { instalado: !!exe, conectado: false, nombre: '', ip: '', redLocal: '', funnel: { activo: false, url: '' } };
  if (!exe) return o;
  const s = await correrTS(8, ['status', '--json']);
  try {
    const j = JSON.parse(s.out);
    o.conectado = j.BackendState === 'Running';
    o.nombre = String((j.Self && j.Self.DNSName) || '').replace(/\.$/, '');
    o.ip = ((j.Self && j.Self.TailscaleIPs) || []).find(x => !x.includes(':')) || '';
  } catch (e) {}
  if (o.ip) o.redLocal = 'http://' + o.ip + ':' + PORT + '/monitor';
  if (o.nombre) o.funnel.url = 'https://' + o.nombre + '/monitor';
  if (o.conectado) {
    const f = await correrTS(8, ['funnel', 'status', '--json']);
    o.funnel.activo = f.out.includes('127.0.0.1:' + PUERTO_NUBE) && f.out.includes('AllowFunnel');
  }
  return o;
}
async function cambiarFunnel(activar) {
  const r = activar ? await correrTS(13, ['funnel', '--bg', '--https=443', 'http://127.0.0.1:' + PUERTO_NUBE])
    : await correrTS(15, ['funnel', '--https=443', 'off']);
  const m = r.out.match(RE_TS_LOGIN);
  if (m) return { habilitar: m[0].replace(/[.,)]+$/, '') };
  if (r.error) {
    const l = r.error.toLowerCase();
    return { error: (l.includes('access denied') || l.includes('operator') || l.includes('permission'))
      ? 'Tailscale no dio permiso. Reinicie la computadora y vuelva a intentar. Detalle: ' + r.error : r.error };
  }
  return { ok: true };
}
// ----- Monitor (solo lectura): sesiones con el PIN de administrador -----
const sesionesMonitor = new Map(), fallasMonitor = new Map();
let fallasGlobales = { n: 0, desde: Date.now() };
function ipCliente(req) { return String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || 'local'; }
function sesionMonitor(req) {
  const a = String(req.headers.authorization || ''), t = a.startsWith('Bearer ') ? a.slice(7) : '';
  const s = sesionesMonitor.get(t);
  if (!s) return null;
  if (s.vence < Date.now()) { sesionesMonitor.delete(t); return null; }
  return s;
}
function datosMonitor() {
  const hoy = diaServicio(), c = cfg();
  const n = (sql, ...p) => uno(sql, ...p).n || 0;
  const cons = (est, tipo) => n(`SELECT COUNT(*) n FROM consumos WHERE diaServicio=? AND estacion=? AND IFNULL(tipo,'empleado')=?`, hoy, est, tipo);
  const ventasHoy = todos('SELECT * FROM ventas WHERE diaServicio=?', hoy);
  const suma = (est, f) => r2(ventasHoy.filter(v => v.estacion === est).reduce((a, v) => a + f(v), 0));
  const porTurno = { Día: 0, Tarde: 0, Noche: 0 };
  todos('SELECT turno, COUNT(*) n FROM consumos WHERE diaServicio=? GROUP BY turno', hoy).forEach(r => { if (r.turno) porTurno[r.turno] = r.n; });
  const semana = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(hoy + 'T12:00:00'); d.setDate(d.getDate() - i); const f = fechaLocal(d);
    semana.push({ dia: f, comidas: n("SELECT COUNT(*) n FROM consumos WHERE diaServicio=? AND estacion='comedor'", f),
      tienda: n("SELECT COUNT(*) n FROM consumos WHERE diaServicio=? AND estacion='tienda'", f),
      ventas: r2(n('SELECT SUM(total-IFNULL(subsidio,0)) n FROM ventas WHERE diaServicio=?', f)) });
  }
  const abiertos = todos("SELECT * FROM turnos WHERE estado='abierto' ORDER BY id").map(t => ({ estacion: t.estacion, cajero: t.cajero, apertura: t.apertura, fondo: t.fondo }));
  const cortes = todos("SELECT * FROM turnos WHERE estado<>'abierto' ORDER BY id DESC LIMIT 8").map(turnoPublico).map(t => ({
    estacion: t.estacion, cajero: t.cajero, apertura: t.apertura, cierre: t.cierre,
    esperado: t.esperado && t.esperado.efectivo != null ? t.esperado.efectivo : null, diferencia: t.diferencia && t.diferencia.efectivo != null ? t.diferencia.efectivo : null }));
  const ultimos = todos('SELECT hora, nombre, estacion, tipo, turno FROM consumos WHERE diaServicio=? ORDER BY id DESC LIMIT 15', hoy);
  const bajos = todos('SELECT nombre, estacion, stock, minimo FROM productos WHERE activo=1 AND controlStock=1 AND minimo>0 AND stock<=minimo ORDER BY stock LIMIT 30');
  const pagos = desglosePagos(ventasHoy);
  return {
    negocio: c.empresa || 'Comedor Industrial', version: VERSION, dia: hoy, actualizado: Date.now(),
    comedor: { comidas: cons('comedor', 'empleado'), vales: cons('comedor', 'vale'), extras: suma('comedor', v => v.total), tickets: ventasHoy.filter(v => v.estacion === 'comedor').length },
    tienda: { subsidios: cons('tienda', 'empleado'), vales: cons('tienda', 'vale'), cobrado: suma('tienda', v => v.total - (v.subsidio || 0)), tickets: ventasHoy.filter(v => v.estacion === 'tienda').length },
    pagos: { efectivo: pagos.efectivo, dolares: pagos.dolaresUSD, dolaresMXN: pagos.dolaresMXN, tarjeta: pagos.tarjeta, transferencia: pagos.transferencia },
    porTurno, semana, abiertos, cortes, ultimos, bajos,
    empleadosActivos: n('SELECT COUNT(*) n FROM empleados WHERE activo=1')
  };
}
// Rutas del monitor: sirven en el sistema (3000, por la red o Tailscale) y en el puerto de internet (3002, Funnel)
async function manejarMonitor(req, res, url) {
  const p = url.pathname;
  if (!(p === '/monitor' || p === '/monitor/' || p.startsWith('/api/monitor/') || (p === '/monitor-qr.js'))) return false;
  if (p === '/monitor-qr.js') { servirArchivo(req, res, '/qrcode.js'); return true; }
  const lic = licenciaNube();
  if (!lic.activa) {
    if (!p.startsWith('/api/')) {
      res.writeHead(402, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Maxsel</title><body style="font-family:system-ui,sans-serif;background:#f4f1ee;margin:0"><div style="background:#1f6f4a;color:#fff;padding:18px 20px;font-weight:800;font-size:20px">Maxsel Comedores Industriales</div><div style="max-width:420px;margin:40px auto;background:#fff;border-radius:14px;padding:24px;text-align:center;border:1px solid #e3ddd6"><h2 style="margin:0 0 8px">Servicio de nube ' + (lic.vencida ? 'vencido' : 'no activo') + '</h2><p style="color:#5a6878;line-height:1.5">El monitoreo desde el teléfono no está activo. Para ' + (lic.vencida ? 'renovarlo' : 'activarlo') + ' comuníquese con Maxsel: WhatsApp 664 337 5433.</p></div></body>');
      return true;
    }
    send(res, 402, { error: 'El monitoreo desde el teléfono no está activo o ya venció. Renuévelo con Maxsel.', vencido: true }); return true;
  }
  if (req.method === 'GET' && (p === '/monitor' || p === '/monitor/')) {
    fs.readFile(path.join(PUBLIC_DIR, 'monitor.html'), (err, d) => {
      if (err) { res.writeHead(404); return res.end('No encontrado'); }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Frame-Options': 'DENY' }); res.end(d);
    });
    return true;
  }
  if (req.method === 'POST' && p === '/api/monitor/login') {
    const ip = ipCliente(req), f = fallasMonitor.get(ip) || { n: 0, hasta: 0 };
    if (Date.now() - fallasGlobales.desde > 3600000) fallasGlobales = { n: 0, desde: Date.now() };
    if (f.hasta > Date.now() || fallasGlobales.n >= 30) { send(res, 429, { error: 'Demasiados intentos. Espere 15 minutos.' }); return true; }
    const b = await readBody(req);
    if (!pinAdminOk(b.pin)) {
      f.n++; fallasGlobales.n++; if (f.n >= 5) { f.hasta = Date.now() + 15 * 60000; f.n = 0; } fallasMonitor.set(ip, f);
      log('Monitor: PIN incorrecto desde ' + ip);
      send(res, 401, { error: 'PIN incorrecto' }); return true;
    }
    fallasMonitor.delete(ip);
    const token = crypto.randomBytes(24).toString('hex');
    sesionesMonitor.set(token, { vence: Date.now() + 12 * 3600000, ip });
    log('Monitor: entrada desde ' + ip);
    send(res, 200, { token, negocio: cfg().empresa || '' }); return true;
  }
  if (req.method === 'POST' && p === '/api/monitor/salir') {
    sesionesMonitor.delete(String(req.headers.authorization || '').slice(7)); send(res, 200, { ok: true }); return true;
  }
  if (req.method === 'GET' && p === '/api/monitor/estado') {
    if (!sesionMonitor(req)) { send(res, 401, { error: 'Vuelva a entrar' }); return true; }
    send(res, 200, datosMonitor()); return true;
  }
  send(res, 404, { error: 'No encontrado' }); return true;
}
function iniciarServidorNube() {
  const srv = http.createServer(async (req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Referrer-Policy', 'no-referrer');
    const url = new URL(req.url, 'http://x');
    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/m')) { res.writeHead(302, { Location: '/monitor' }); return res.end(); }
    if (req.method === 'GET' && ['/logo.png', '/favicon.ico', '/icono.png'].includes(url.pathname)) return servirArchivo(req, res, url.pathname);
    try { if (await manejarMonitor(req, res, url)) return; } catch (e) { return send(res, 500, { error: 'Error' }); }
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('No encontrado');
  });
  srv.on('error', e => log('Nube: no se pudo abrir el puerto ' + PUERTO_NUBE + ' (' + e.code + ')'));
  srv.listen(PUERTO_NUBE, '127.0.0.1');
}
// si la nube vence, se apaga sola el acceso desde internet
async function revisarNube() {
  try {
    if (licenciaNube().activa || !exeTailscale()) return;
    sesionesMonitor.clear();
    const f = await correrTS(8, ['funnel', 'status', '--json']);
    if (f.out.includes('127.0.0.1:' + PUERTO_NUBE)) { await cambiarFunnel(false); log('Nube vencida: se apagó el acceso desde internet'); }
  } catch (e) {}
}

// ---------- Base de datos ----------
let db;
const ESQUEMA = `
CREATE TABLE IF NOT EXISTS config (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS empleados (tarjeta TEXT PRIMARY KEY, nombre TEXT NOT NULL, turno TEXT, activo INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS cajeros (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, pin TEXT NOT NULL, activo INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS productos (id INTEGER PRIMARY KEY AUTOINCREMENT, estacion TEXT, nombre TEXT, precio REAL, activo INTEGER DEFAULT 1,
  controlStock INTEGER DEFAULT 0, stock INTEGER DEFAULT 0, minimo INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS turnos (id INTEGER PRIMARY KEY AUTOINCREMENT, estacion TEXT, cajeroId INTEGER, cajero TEXT, apertura TEXT, diaServicio TEXT,
  fondo REAL, tipoCambio REAL, estado TEXT, cierre TEXT, declarado TEXT, esperado TEXT, diferencia TEXT);
CREATE TABLE IF NOT EXISTS consumos (id INTEGER PRIMARY KEY AUTOINCREMENT, fecha TEXT, hora TEXT, diaServicio TEXT, tarjeta TEXT, nombre TEXT,
  turno TEXT, estacion TEXT, turnoCajaId INTEGER, cajero TEXT);
CREATE TABLE IF NOT EXISTS ventas (id INTEGER PRIMARY KEY AUTOINCREMENT, fecha TEXT, hora TEXT, diaServicio TEXT, estacion TEXT, turnoCajaId INTEGER,
  cajero TEXT, tarjeta TEXT, nombre TEXT, items TEXT, total REAL, metodo TEXT, recibido REAL, tipoCambio REAL, cambio REAL);
CREATE TABLE IF NOT EXISTS movimientos (id INTEGER PRIMARY KEY AUTOINCREMENT, fecha TEXT, hora TEXT, productoId INTEGER, producto TEXT, tipo TEXT,
  cantidad INTEGER, stockFinal INTEGER, nota TEXT);
CREATE INDEX IF NOT EXISTS ix_cons_dia_tarjeta ON consumos(diaServicio, tarjeta);
CREATE INDEX IF NOT EXISTS ix_cons_turno ON consumos(turnoCajaId);
CREATE INDEX IF NOT EXISTS ix_ventas_dia ON ventas(diaServicio);
CREATE INDEX IF NOT EXISTS ix_ventas_turno ON ventas(turnoCajaId);
CREATE INDEX IF NOT EXISTS ix_turnos_estado ON turnos(estacion, estado);
CREATE INDEX IF NOT EXISTS ix_mov_fecha ON movimientos(fecha);
CREATE INDEX IF NOT EXISTS ix_mov_prod ON movimientos(productoId);
`;
const CONFIG_INICIAL = { empresa: 'Comedor Industrial', pinAdmin: '1234', horaInicioDia: '5', consumosPorDia: '1', tipoCambio: '18', tipoCambioFecha: '',
  mesesHistorial: '3', carpetaRespaldoExtra: '', ultimoMantenimiento: '', subsidioTienda: '80', precioComida: '0', imprimirAuto: '1' };

function abrirDB() {
  db = new DatabaseSync(DB_FILE);
  db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA foreign_keys=OFF; PRAGMA busy_timeout=5000;');
  db.exec(ESQUEMA);
  const ins = db.prepare('INSERT OR IGNORE INTO config(k,v) VALUES(?,?)');
  for (const [k, v] of Object.entries(CONFIG_INICIAL)) ins.run(k, v);
  if (!uno('SELECT COUNT(*) n FROM cajeros').n && !fs.existsSync(JSON_VIEJO)) db.prepare('INSERT INTO cajeros(nombre,pin) VALUES(?,?)').run('Cajero 1', '1111');
  if (!uno('SELECT COUNT(*) n FROM productos').n && !fs.existsSync(JSON_VIEJO)) {
    const p = db.prepare('INSERT INTO productos(estacion,nombre,precio) VALUES(?,?,?)');
    [['comedor', 'Tortillas (orden)', 10], ['comedor', 'Plato desechable', 3], ['comedor', 'Vaso desechable', 2], ['comedor', 'Tenedor / cuchara', 2],
     ['tienda', 'Refresco 600ml', 22], ['tienda', 'Sabritas', 20], ['tienda', 'Dulce', 5], ['tienda', 'Agua 1L', 15]].forEach(x => p.run(...x));
  }
  migrarJSON();
  // columnas nuevas (v3.1)
  const cols = todos('PRAGMA table_info(productos)').map(c => c.name);
  if (!cols.includes('codigo')) ejecutar("ALTER TABLE productos ADD COLUMN codigo TEXT DEFAULT ''");
  if (!cols.includes('costo')) ejecutar('ALTER TABLE productos ADD COLUMN costo REAL DEFAULT 0');
  db.exec('CREATE INDEX IF NOT EXISTS ix_prod_codigo ON productos(codigo)');
  // v4: vales y tipo de consumo
  const colsC = todos('PRAGMA table_info(consumos)').map(c => c.name);
  if (!colsC.includes('tipo')) ejecutar("ALTER TABLE consumos ADD COLUMN tipo TEXT DEFAULT 'empleado'");
  db.exec(`CREATE TABLE IF NOT EXISTS vales (id INTEGER PRIMARY KEY AUTOINCREMENT, folio TEXT UNIQUE, nombre TEXT, fecha TEXT, emitido TEXT,
    nota TEXT, estado TEXT DEFAULT 'pendiente', consumoId INTEGER, usadoEn TEXT, estacion TEXT, cajero TEXT);
    CREATE INDEX IF NOT EXISTS ix_vales_fecha ON vales(fecha); CREATE INDEX IF NOT EXISTS ix_cons_tipo ON consumos(tipo);`);
  // v4.5: subsidio en pesos para la tienda (cada consumo guarda su monto; la venta guarda cuánto pagó el subsidio)
  if (!colsC.includes('monto')) ejecutar('ALTER TABLE consumos ADD COLUMN monto REAL DEFAULT 0');
  if (!colsC.includes('ventaId')) ejecutar('ALTER TABLE consumos ADD COLUMN ventaId INTEGER');
  const colsV = todos('PRAGMA table_info(ventas)').map(c => c.name);
  if (!colsV.includes('subsidio')) ejecutar('ALTER TABLE ventas ADD COLUMN subsidio REAL DEFAULT 0');
  if (!colsV.includes('consumoId')) ejecutar('ALTER TABLE ventas ADD COLUMN consumoId INTEGER');
  // v4.6: cobro estilo punto de venta — cada venta guarda cuánto entró por cada forma de pago (permite pago mixto)
  if (!colsV.includes('pagoEfectivo')) {
    for (const c of ['pagoEfectivo', 'pagoUsd', 'pagoTarjeta', 'pagoTransferencia']) ejecutar(`ALTER TABLE ventas ADD COLUMN ${c} REAL DEFAULT 0`);
    ejecutar("ALTER TABLE ventas ADD COLUMN referencia TEXT DEFAULT ''");
    // ventas anteriores: se pasa lo que ya tenían a las columnas nuevas (no cambia ningún corte)
    ejecutar("UPDATE ventas SET pagoEfectivo=recibido WHERE metodo='efectivo'");
    ejecutar("UPDATE ventas SET pagoUsd=recibido WHERE metodo='dolares'");
    ejecutar("UPDATE ventas SET pagoTarjeta=recibido WHERE metodo='tarjeta'");
  }
}
// Reparte cada venta en lo que realmente se quedó de cada forma de pago (el cambio sale primero del efectivo y luego de lo recibido en dólares)
function desglosePagos(ventas) {
  const o = { efectivo: 0, dolaresMXN: 0, dolaresUSD: 0, tarjeta: 0, transferencia: 0, cambio: 0, cambioPorDolares: 0, pesosRecibidos: 0 };
  for (const v of ventas) {
    const pe = v.pagoEfectivo || 0, pu = v.pagoUsd || 0, tc = v.tipoCambio || 0, c = v.cambio || 0;
    const ce = Math.min(c, pe), cu = c - ce;
    o.efectivo += pe - ce; o.dolaresMXN += pu * tc - cu; o.dolaresUSD += pu; o.tarjeta += v.pagoTarjeta || 0; o.transferencia += v.pagoTransferencia || 0;
    o.cambio += c; o.cambioPorDolares += cu; o.pesosRecibidos += pe;
  }
  for (const k in o) o[k] = r2(o[k]);
  return o;
}
const subsidioTienda = () => Math.max(0, r2(cfg().subsidioTienda));
function cerrarDB() { try { db.close(); } catch (e) {} }
const uno = (sql, ...p) => db.prepare(sql).get(...p);
const todos = (sql, ...p) => db.prepare(sql).all(...p).map(x => ({ ...x }));
const ejecutar = (sql, ...p) => db.prepare(sql).run(...p);
function transaccion(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { try { db.exec('ROLLBACK'); } catch (x) {} throw e; }
}
function cfg() { const o = {}; todos('SELECT k,v FROM config').forEach(r => o[r.k] = r.v); return o; }
const setCfg = (k, v) => ejecutar('INSERT INTO config(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v', k, String(v));

// Pasa la información del sistema anterior (archivo .json) a SQLite, una sola vez.
function migrarJSON() {
  if (!fs.existsSync(JSON_VIEJO)) return;
  log('Pasando la información anterior a la nueva base de datos...');
  const j = JSON.parse(fs.readFileSync(JSON_VIEJO, 'utf8'));
  transaccion(() => {
    const c = j.config || {};
    for (const k of Object.keys(CONFIG_INICIAL)) if (c[k] !== undefined && c[k] !== null) setCfg(k, c[k]);
    const e = db.prepare('INSERT OR REPLACE INTO empleados(tarjeta,nombre,turno,activo) VALUES(?,?,?,?)');
    (j.empleados || []).forEach(x => e.run(limpiarTarjeta(x.tarjeta), x.nombre, x.turno || 'Día', x.activo === false ? 0 : 1));
    const cj = db.prepare('INSERT OR REPLACE INTO cajeros(id,nombre,pin,activo) VALUES(?,?,?,?)');
    (j.cajeros || []).forEach(x => cj.run(x.id, x.nombre, String(x.pin), x.activo === false ? 0 : 1));
    if (!(j.cajeros || []).length && !uno('SELECT COUNT(*) n FROM cajeros').n) cj.run(1, 'Cajero 1', '1111', 1);
    const p = db.prepare('INSERT OR REPLACE INTO productos(id,estacion,nombre,precio,activo,controlStock,stock,minimo) VALUES(?,?,?,?,?,?,?,?)');
    (j.productos || []).forEach(x => p.run(x.id, x.estacion, x.nombre, x.precio, x.activo === false ? 0 : 1, x.controlStock ? 1 : 0, x.stock || 0, x.minimo || 0));
    const t = db.prepare('INSERT OR REPLACE INTO turnos(id,estacion,cajeroId,cajero,apertura,diaServicio,fondo,tipoCambio,estado,cierre,declarado,esperado,diferencia) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)');
    (j.turnosCaja || []).forEach(x => t.run(x.id, x.estacion, x.cajeroId, x.cajero, x.apertura, x.diaServicio || x.apertura.slice(0, 10), x.fondo, x.tipoCambio, x.estado, x.cierre,
      x.declarado ? JSON.stringify(x.declarado) : null, x.esperado ? JSON.stringify(x.esperado) : null, x.diferencia ? JSON.stringify(x.diferencia) : null));
    const co = db.prepare('INSERT OR REPLACE INTO consumos(id,fecha,hora,diaServicio,tarjeta,nombre,turno,estacion,turnoCajaId,cajero) VALUES(?,?,?,?,?,?,?,?,?,?)');
    (j.consumos || []).forEach(x => co.run(x.id, x.fecha, x.hora, x.diaServicio, limpiarTarjeta(x.tarjeta), x.nombre, x.turno, x.estacion, x.turnoCajaId ?? null, x.cajero ?? null));
    const v = db.prepare('INSERT OR REPLACE INTO ventas(id,fecha,hora,diaServicio,estacion,turnoCajaId,cajero,tarjeta,nombre,items,total,metodo,recibido,tipoCambio,cambio) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
    (j.ventas || []).forEach(x => v.run(x.id, x.fecha, x.hora, x.diaServicio, x.estacion, x.turnoCajaId ?? null, x.cajero ?? null, x.tarjeta || '', x.nombre,
      JSON.stringify(x.items || []), x.total, x.metodo || 'efectivo', x.recibido ?? x.pago ?? x.total, x.tipoCambio ?? null, x.cambio || 0));
    const m = db.prepare('INSERT OR REPLACE INTO movimientos(id,fecha,hora,productoId,producto,tipo,cantidad,stockFinal,nota) VALUES(?,?,?,?,?,?,?,?,?)');
    (j.movimientos || []).forEach(x => m.run(x.id, x.fecha, x.hora, x.productoId, x.producto, x.tipo, x.cantidad, x.stockFinal, x.nota || ''));
  });
  fs.renameSync(JSON_VIEJO, JSON_VIEJO.replace('.json', '_migrado_' + Date.now() + '.json'));
  log('Información anterior migrada correctamente.');
}

// ---------- Fechas de servicio ----------
function diaServicio(d = new Date()) {
  return fechaLocal(new Date(d.getTime() - (Number(cfg().horaInicioDia) || 0) * 3600 * 1000));
}
function normalizarTurno(t) {
  const s = String(t || '').trim().toLowerCase();
  if (s.startsWith('t') || s === '2' || s.includes('vesp')) return 'Tarde';
  if (s.startsWith('n') || s === '3' || s.includes('noc')) return 'Noche';
  return 'Día';
}
const empleadoDe = t => { const e = uno('SELECT * FROM empleados WHERE tarjeta=?', limpiarTarjeta(t)); return e ? { ...e, activo: !!e.activo } : null; };
const consumosHoy = t => todos("SELECT * FROM consumos WHERE diaServicio=? AND tarjeta=? AND IFNULL(tipo,'empleado')='empleado' ORDER BY id", diaServicio(), limpiarTarjeta(t));
const turnoAbierto = est => uno("SELECT * FROM turnos WHERE estacion=? AND estado='abierto' ORDER BY id DESC LIMIT 1", est);
function exigirTurno(id, estacion) {
  const t = uno('SELECT * FROM turnos WHERE id=?', Number(id));
  if (!t || t.estado !== 'abierto' || t.estacion !== estacion) throw new ErrorUsuario('No hay un turno abierto en esta caja. Abra turno primero.', 409);
  return t;
}
function estadoVale(folio) {
  const f = String(folio || '').trim().toUpperCase();
  const v = uno('SELECT * FROM vales WHERE folio=?', f);
  if (!v) return { valido: false, motivo: 'El vale ' + f + ' no existe. Revise el folio.' };
  const vale = { ...v }, hoy = diaServicio();
  if (v.estado === 'usado') return { valido: false, vale, motivo: `El vale ${f} YA SE USÓ el ${v.usadoEn} en ${String(v.estacion).toUpperCase()}` };
  if (v.estado === 'cancelado') return { valido: false, vale, motivo: `El vale ${f} fue CANCELADO por administración` };
  if (v.fecha > hoy) return { valido: false, vale, motivo: `El vale ${f} es para el día ${v.fecha.split('-').reverse().join('/')}, todavía no se puede usar` };
  if (v.fecha < hoy) return { valido: false, vale, motivo: `El vale ${f} VENCIÓ: era para el día ${v.fecha.split('-').reverse().join('/')}` };
  return { valido: true, vale };
}
function producto(id) { const p = uno('SELECT * FROM productos WHERE id=?', Number(id)); return p ? { ...p, activo: !!p.activo, controlStock: !!p.controlStock } : null; }
function registrarMov(p, tipo, cantidad, nota) {
  const n = new Date();
  ejecutar('INSERT INTO movimientos(fecha,hora,productoId,producto,tipo,cantidad,stockFinal,nota) VALUES(?,?,?,?,?,?,?,?)', fechaLocal(n), horaLocal(n), p.id, p.nombre, tipo, cantidad, p.stock, nota || '');
}
function calcularEsperado(t) {
  const s = (sql) => uno(sql, t.id).n || 0;
  const vs = todos('SELECT * FROM ventas WHERE turnoCajaId=?', t.id), d = desglosePagos(vs);
  return {
    // lo que físicamente debe haber: fondo + pesos recibidos − todo el cambio entregado
    efectivo: r2(t.fondo + d.pesosRecibidos - d.cambio), tarjeta: d.tarjeta, dolares: d.dolaresUSD, transferencia: d.transferencia,
    ventasEfectivo: d.efectivo, ventasDolaresMXN: d.dolaresMXN, cambioDadoPorDolares: d.cambioPorDolares,
    subsidio: r2(vs.reduce((a, v) => a + (v.subsidio || 0), 0)), cobrado: r2(vs.reduce((a, v) => a + v.total - (v.subsidio || 0), 0)),
    totalVentas: r2(vs.reduce((a, v) => a + v.total, 0)), numVentas: vs.length,
    consumos: s("SELECT COUNT(*) n FROM consumos WHERE turnoCajaId=? AND IFNULL(tipo,'empleado')='empleado'"), vales: s("SELECT COUNT(*) n FROM consumos WHERE turnoCajaId=? AND tipo='vale'")
  };
}
function turnoPublico(t) {
  const js = x => x ? JSON.parse(x) : null;
  const o = { ...t, declarado: js(t.declarado), esperado: js(t.esperado), diferencia: js(t.diferencia) };
  if (o.estado === 'abierto') o.esperado = calcularEsperado(t);
  return o;
}
const ventaPublica = v => ({ ...v, items: JSON.parse(v.items || '[]') });

// ---------- Respaldos y mantenimiento ----------
function crearRespaldo(destino) {
  if (fs.existsSync(destino)) fs.unlinkSync(destino);
  db.exec(`VACUUM INTO '${destino.replace(/'/g, "''")}'`);
  return destino;
}
function listaRespaldos() {
  return fs.readdirSync(BACKUP_DIR).filter(f => f.endsWith('.db')).sort().reverse()
    .map(f => { const st = fs.statSync(path.join(BACKUP_DIR, f)); return { nombre: f, tamano: st.size, fecha: st.mtime.toISOString() }; });
}
function respaldoDiario(forzar) {
  const nombre = 'respaldo_' + fechaLocal(new Date()) + '.db';
  const f = path.join(BACKUP_DIR, nombre);
  if (fs.existsSync(f) && !forzar) return;
  crearRespaldo(f);
  log('Respaldo creado: ' + nombre);
  // borrar respaldos viejos (se quedan los últimos 30)
  const auto = fs.readdirSync(BACKUP_DIR).filter(x => /^respaldo_\d{4}-\d{2}-\d{2}\.db$/.test(x)).sort();
  while (auto.length > MAX_RESPALDOS) fs.unlinkSync(path.join(BACKUP_DIR, auto.shift()));
  copiarRespaldoExtra(f);
}
function copiarRespaldoExtra(f) {
  const extra = (cfg().carpetaRespaldoExtra || '').trim();
  if (!extra) return;
  try {
    if (!fs.existsSync(extra)) return log('Carpeta de respaldo extra no disponible: ' + extra);
    fs.copyFileSync(f, path.join(extra, 'ComedorIndustrial_' + path.basename(f)));
    const viejos = fs.readdirSync(extra).filter(x => /^ComedorIndustrial_respaldo_\d{4}-\d{2}-\d{2}\.db$/.test(x)).sort();
    while (viejos.length > MAX_RESPALDOS) fs.unlinkSync(path.join(extra, viejos.shift()));
    log('Respaldo copiado también a: ' + extra);
  } catch (e) { log('No se pudo copiar el respaldo extra: ' + e.message); }
}
// Guarda en archivos CSV lo más viejo que el historial y lo quita de la base de datos
function limpiarHistorial() {
  const meses = Math.max(1, Number(cfg().mesesHistorial) || 3);
  const lim = new Date(); lim.setMonth(lim.getMonth() - meses);
  const corte = fechaLocal(lim);
  const csv = (filas) => '﻿' + filas.map(r => r.map(c => { const s = String(c ?? ''); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }).join(',')).join('\r\n');
  const cons = todos('SELECT * FROM consumos WHERE diaServicio < ? ORDER BY id', corte);
  const vent = todos('SELECT * FROM ventas WHERE diaServicio < ? ORDER BY id', corte);
  if (!cons.length && !vent.length) return;
  const sello = fechaLocal(new Date());
  if (cons.length) fs.writeFileSync(path.join(ARCHIVO_DIR, `consumos_hasta_${corte}_${sello}.csv`),
    csv([['Fecha', 'Hora', 'Lugar', 'Tipo', 'No. Tarjeta / Folio', 'Nombre', 'Subsidio']].concat(cons.map(c => [c.fecha.split('-').reverse().join('/'), c.hora, c.estacion === 'tienda' ? 'Tienda' : 'Comedor', c.tipo === 'vale' ? 'Vale' : 'Empleado', c.tarjeta, c.nombre, c.monto || 0]))));
  if (vent.length) fs.writeFileSync(path.join(ARCHIVO_DIR, `ventas_hasta_${corte}_${sello}.csv`),
    csv([['Ticket', 'Fecha', 'Hora', 'Caja', 'Cajero', 'Método', 'Total', 'Subsidio', 'Recibido', 'Cambio', 'Cliente', 'Productos']]
      .concat(vent.map(v => [v.id, v.fecha, v.hora, v.estacion, v.cajero, v.metodo, v.total, v.subsidio || 0, v.recibido, v.cambio, v.nombre, JSON.parse(v.items || '[]').map(i => i.cant + ' x ' + i.nombre).join('; ')]))));
  transaccion(() => {
    ejecutar('DELETE FROM consumos WHERE diaServicio < ?', corte);
    ejecutar('DELETE FROM vales WHERE fecha < ?', corte);
    ejecutar('DELETE FROM ventas WHERE diaServicio < ?', corte);
    ejecutar('DELETE FROM movimientos WHERE fecha < ?', corte);
    ejecutar("DELETE FROM turnos WHERE estado='cerrado' AND diaServicio < ?", corte);
  });
  log(`Historial: se archivaron ${cons.length} consumos y ${vent.length} ventas anteriores a ${corte}`);
}
function mantenimiento() {
  try {
    const hoy = fechaLocal(new Date());
    respaldoDiario(false);
    if (cfg().ultimoMantenimiento !== hoy) {
      limpiarHistorial();
      db.exec('PRAGMA optimize');
      setCfg('ultimoMantenimiento', hoy);
    }
  } catch (e) { log('Error en mantenimiento: ' + e.message); }
}
function esSQLite(buf) { return buf.length > 100 && buf.slice(0, 16).toString('latin1') === 'SQLite format 3\u0000'; }
function restaurarDesde(bufOArchivo) {
  const tmp = path.join(DATA_DIR, 'restaurando.db');
  if (Buffer.isBuffer(bufOArchivo)) fs.writeFileSync(tmp, bufOArchivo); else fs.copyFileSync(bufOArchivo, tmp);
  // validar que sea un respaldo de este sistema
  try {
    const prueba = new DatabaseSync(tmp, { readOnly: true });
    const r = prueba.prepare("SELECT COUNT(*) n FROM sqlite_master WHERE type='table' AND name IN ('empleados','consumos','ventas','turnos','productos')").get();
    const ok = prueba.prepare('PRAGMA integrity_check').get();
    prueba.close();
    if (r.n < 5) throw new Error('El archivo no es un respaldo de este sistema');
    if (Object.values(ok)[0] !== 'ok') throw new Error('El respaldo está dañado');
  } catch (e) { try { fs.unlinkSync(tmp); } catch (x) {} throw new ErrorUsuario(e.message.includes('respaldo') ? e.message : 'El archivo no es un respaldo válido'); }
  // guardar copia del estado actual por seguridad
  crearRespaldo(path.join(BACKUP_DIR, 'antes_de_restaurar_' + fechaLocal(new Date()) + '_' + horaLocal(new Date()).replace(/:/g, '') + '.db'));
  cerrarDB();
  for (const ext of ['-wal', '-shm']) { try { fs.unlinkSync(DB_FILE + ext); } catch (e) {} }
  fs.renameSync(tmp, DB_FILE);
  abrirDB();
  log('Respaldo restaurado');
}


// ---------- 4.8: actualizaciones por internet (igual que Maxsel POS, Hotel y Gimnasios) ----------
// Baja version.json de github.com/mlunq23/maxsel-actualizaciones (público, solo paquetes), sección "comedor".
// El .zip trae solo el programa (server.js y public\*): nunca la base de datos, la licencia, los respaldos ni node.exe.
// Se revisa la huella SHA-256 antes de instalar, se guarda un respaldo de la base de datos y de los archivos para regresar.
const UPD_BASE = 'https://raw.githubusercontent.com/mlunq23/maxsel-actualizaciones/main/', UPD_DIR = path.join(DATA_DIR, 'actualizacion');
const NO_TOCAR = /^(datos\/|node_modules\/|generador\/|licencia)/i;
const verCmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 4; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
function httpsBajar(url, max, redirs = 0) {
  // Solo para pruebas de Maxsel: lee los paquetes de una carpeta local en vez de internet
  if (process.env.MAXSEL_UPD_PRUEBA) return Promise.resolve().then(() => fs.readFileSync(path.join(process.env.MAXSEL_UPD_PRUEBA, path.basename(url.split('?')[0]))));
  return new Promise((resolve, reject) => {
    if (!/^https:\/\/raw\.githubusercontent\.com\/mlunq23\/maxsel-actualizaciones\//.test(url)) return reject(new ErrorUsuario('Dirección no permitida'));
    https.get(url, { timeout: 30000, headers: { 'Cache-Control': 'no-cache', 'User-Agent': 'MaxselComedores/' + VERSION } }, rs => {
      if ([301, 302, 303, 307, 308].includes(rs.statusCode) && rs.headers.location && redirs < 4) { rs.resume(); return resolve(httpsBajar(new URL(rs.headers.location, url).href, max, redirs + 1)); }
      if (rs.statusCode !== 200) { rs.resume(); return reject(new ErrorUsuario('El servidor de Maxsel respondió ' + rs.statusCode)); }
      const ch = []; let n = 0;
      rs.on('data', c => { n += c.length; if (n > max) { rs.destroy(); reject(new ErrorUsuario('Archivo demasiado grande')); } else ch.push(c); });
      rs.on('end', () => resolve(Buffer.concat(ch))); rs.on('error', reject);
    }).on('timeout', function () { this.destroy(new ErrorUsuario('Sin respuesta (revise el internet)')); })
      .on('error', e => reject(e instanceof ErrorUsuario ? e : new ErrorUsuario(/ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ENETUNREACH|ECONNRESET/.test(e.code || '') ? 'Sin internet. Conecte la computadora a internet e intente de nuevo.' : e.message)));
  });
}
async function versionDisponible() {
  const j = JSON.parse((await httpsBajar(UPD_BASE + 'version.json?t=' + Date.now(), 256 * 1024)).toString('utf8'));
  const e = j.comedor;
  if (!e || !e.ver) { setCfg('upd_disponible', ''); return { instalada: VERSION, hay: false }; }
  const hay = verCmp(e.ver, VERSION) > 0 && /^[\w.-]+\.zip$/.test(e.win || '') && /^[0-9a-f]{64}$/i.test(e.winSha || '');
  setCfg('upd_disponible', hay ? String(e.ver) : ''); setCfg('upd_revisado', fechaLocal(new Date()) + ' ' + horaLocal(new Date()));
  return { instalada: VERSION, disponible: String(e.ver), notas: String(e.notas || ''), hay, _e: e };
}
function leerZip(buf) {
  let e = buf.length - 22; while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) throw new ErrorUsuario('El paquete de actualización está dañado');
  const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const out = [];
  for (let i = 0; i < n; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new ErrorUsuario('El paquete de actualización está dañado');
    const met = buf.readUInt16LE(p + 10), cs = buf.readUInt32LE(p + 20), nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const nom = buf.toString('utf8', p + 46, p + 46 + nl).replace(/\\/g, '/'); p += 46 + nl + xl + cl;
    if (nom.endsWith('/')) continue;
    if (buf.readUInt32LE(lo) !== 0x04034b50) throw new ErrorUsuario('El paquete de actualización está dañado');
    const s0 = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28), raw = buf.subarray(s0, s0 + cs);
    const dat = met === 0 ? raw : met === 8 ? zlib.inflateRawSync(raw) : null;
    if (!dat) throw new ErrorUsuario('Formato de paquete no soportado');
    out.push({ nom, dat });
  }
  if (!out.length) throw new ErrorUsuario('El paquete de actualización viene vacío');
  return out;
}
// Windows o el antivirus a veces tienen un archivo ocupado unos segundos: se reintenta
function conReintento(fn) {
  for (let i = 0; ; i++) {
    try { return fn(); } catch (e) {
      if (i >= 12 || !/EBUSY|EPERM|EACCES/.test(e.code || '')) throw e;
      const fin = Date.now() + 500; while (Date.now() < fin) { /* espera corta */ }
    }
  }
}
const sha = d => crypto.createHash('sha256').update(d).digest('hex');
let actualizando = false;
async function instalarActualizacion() {
  if (actualizando) throw new ErrorUsuario('Ya se está instalando una actualización');
  actualizando = true;
  try {
    const v = await versionDisponible();
    if (!v.hay) throw new ErrorUsuario(`Ya tiene la versión más reciente (${VERSION}).`);
    const zip = await httpsBajar(UPD_BASE + v._e.win, 80 * 1024 * 1024);
    if (sha(zip) !== String(v._e.winSha).toLowerCase()) throw new ErrorUsuario('El archivo descargado no es válido. Intente de nuevo.');
    const archivos = leerZip(zip).filter(f => !NO_TOCAR.test(f.nom) && !f.nom.split('/').includes('..'));
    if (!archivos.some(f => f.nom === 'server.js') || !archivos.some(f => f.nom === 'public/index.html')) throw new ErrorUsuario('El paquete de actualización no es de Maxsel Comedores Industriales');
    const srv = archivos.find(f => f.nom === 'server.js').dat.toString('utf8');
    const kp = /const CLAVE_PUBLICA = '([^']*)'/.exec(srv);
    if (!kp || kp[1].startsWith('__') || kp[1].length < 40) throw new ErrorUsuario('El paquete de actualización no está protegido con licencia. Avise a Maxsel.');
    // 1) respaldo de la información (por si acaso) y de los archivos actuales del programa
    fs.mkdirSync(UPD_DIR, { recursive: true });
    try { crearRespaldo(path.join(BACKUP_DIR, 'antes_de_actualizar_' + VERSION + '_' + fechaLocal(new Date()) + '.db')); } catch (e) { log('No se pudo respaldar antes de actualizar: ' + e.message); }
    const bk = path.join(UPD_DIR, 'respaldo_' + VERSION); fs.rmSync(bk, { recursive: true, force: true }); fs.mkdirSync(bk, { recursive: true });
    const raiz = path.resolve(BASE_DIR) + path.sep, escritos = [];
    try {
      // 2) se escriben los archivos nuevos al lado (.nuevo) y se cambian todos juntos al final
      for (const f of archivos) {
        const d = path.resolve(BASE_DIR, f.nom); if (!d.startsWith(raiz)) continue;
        if (fs.existsSync(d)) { fs.mkdirSync(path.dirname(path.join(bk, f.nom)), { recursive: true }); fs.copyFileSync(d, path.join(bk, f.nom)); }
        fs.mkdirSync(path.dirname(d), { recursive: true }); fs.writeFileSync(d + '.nuevo', f.dat); escritos.push({ d, f });
      }
      for (const x of escritos) conReintento(() => fs.renameSync(x.d + '.nuevo', x.d));
      // 3) se comprueba que todo quedó bien
      for (const x of escritos) if (sha(fs.readFileSync(x.d)) !== sha(x.f.dat)) throw new Error('el archivo ' + x.f.nom + ' no quedó igual');
    } catch (e) {
      for (const x of escritos) { try { fs.rmSync(x.d + '.nuevo', { force: true }); } catch (_) {} }
      for (const f of archivos) { const b = path.join(bk, f.nom); if (fs.existsSync(b)) try { conReintento(() => fs.copyFileSync(b, path.resolve(BASE_DIR, f.nom))); } catch (_) {} }
      throw new ErrorUsuario('No se pudo instalar la actualización (se dejó la versión anterior): ' + e.message);
    }
    fs.writeFileSync(path.join(UPD_DIR, 'estado.json'), JSON.stringify({ de: VERSION, a: v.disponible, fecha: fechaLocal(new Date()) + ' ' + horaLocal(new Date()), archivos: escritos.length }));
    log(`Actualización ${VERSION} → ${v.disponible} instalada (${escritos.length} archivos). Reiniciando...`);
    setTimeout(() => { try { db.exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (e) {} cerrarDB(); process.exit(0); }, 1500);
    return { ok: true, de: VERSION, a: v.disponible, archivos: escritos.length, servicio: !!process.env.MAXSEL_SERVICIO };
  } finally { actualizando = false; }
}
// Al arrancar después de actualizar: se anota el resultado para mostrarlo en Configuración
function anotarActualizacion() {
  try {
    const f = path.join(UPD_DIR, 'estado.json');
    if (fs.existsSync(f)) {
      const i = JSON.parse(fs.readFileSync(f, 'utf8'));
      const ok = verCmp(VERSION, i.a) >= 0;
      setCfg('upd_ultima', ok ? `Se actualizó de la versión ${i.de} a la ${VERSION} el ${i.fecha}` : `La actualización a la ${i.a} no quedó (sigue la ${VERSION})`);
      log(ok ? `Sistema actualizado de ${i.de} a ${VERSION}` : `La actualización a ${i.a} no quedó`);
      fs.unlinkSync(f);
    }
    if (cfg().upd_disponible && verCmp(cfg().upd_disponible, VERSION) <= 0) setCfg('upd_disponible', '');
  } catch (e) { /* nada */ }
}

// ---------- API ----------
function send(res, code, obj, extra) {
  res.writeHead(code, Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, extra || {}));
  res.end(JSON.stringify(obj));
}
function readBody(req, limite = 2e6, crudo = false) {
  return new Promise((resolve, reject) => {
    const partes = []; let n = 0;
    req.on('data', c => { n += c.length; if (n > limite) { reject(new ErrorUsuario('Archivo demasiado grande', 413)); req.destroy(); } else partes.push(c); });
    req.on('end', () => {
      const buf = Buffer.concat(partes);
      if (crudo) return resolve(buf);
      try { resolve(buf.length ? JSON.parse(buf.toString('utf8')) : {}); } catch (e) { reject(new ErrorUsuario('Datos inválidos')); }
    });
    req.on('error', reject);
  });
}
// Clave de soporte de Maxsel (la misma de Maxsel Tech y Abarrotes): solo se guarda su huella SHA-256, nunca el texto.
// Sirve para entrar a Administración, recuperar PINs olvidados y reiniciar las ventas (botón oculto).
const SOPORTE_HASH = '27486342e248a68acb426e94ae242e3483785c78fac2f971b602f09771629cfa';
const esSoporte = pw => !!pw && crypto.createHash('sha256').update('maxsel-super|' + String(pw)).digest('hex') === SOPORTE_HASH;
const pinAdminOk = pw => String(pw ?? '') === String(cfg().pinAdmin) || esSoporte(pw);
const esAdmin = req => pinAdminOk(req.headers['x-pin']);
// Freno contra adivinar PINs: máximo 8 intentos fallidos cada 10 minutos por computadora
const intentos = new Map();
function frenoIntentos(req, fallo) {
  const ip = req.socket.remoteAddress || '?', ahora = Date.now();
  const l = (intentos.get(ip) || []).filter(t => ahora - t < 10 * 60 * 1000);
  if (fallo) l.push(ahora);
  intentos.set(ip, l);
  if (l.length >= 8) throw new ErrorUsuario('Demasiados intentos. Espere 10 minutos y vuelva a intentar.', 429);
}
function soloAdmin(req) { if (!esAdmin(req)) throw new ErrorUsuario('No autorizado', 401); }

// Cancela una venta: regresa productos al inventario y, si se pagó con subsidio, también quita ese consumo
function cancelarVenta(id) {
  return transaccion(() => {
    const v = uno('SELECT * FROM ventas WHERE id=?', Number(id));
    if (!v) throw new ErrorUsuario('No existe');
    const t = uno('SELECT estado FROM turnos WHERE id=?', v.turnoCajaId);
    if (t && t.estado === 'cerrado') throw new ErrorUsuario('No se puede cancelar: el turno de esa venta ya se cerró (corte hecho).');
    JSON.parse(v.items || '[]').forEach(it => {
      const p = producto(it.id);
      if (p && p.controlStock) { ejecutar('UPDATE productos SET stock=stock+? WHERE id=?', it.cant, p.id); p.stock += it.cant; registrarMov(p, 'cancelacion', it.cant, 'Cancelación venta #' + v.id); }
    });
    if (v.consumoId) ejecutar('DELETE FROM consumos WHERE id=?', v.consumoId);
    ejecutar('DELETE FROM ventas WHERE id=?', v.id);
    return { ok: true };
  });
}

const rutas = {
  'GET /api/info': () => { const c = cfg(); return { empresa: c.empresa, diaServicio: diaServicio(), tipoCambio: Number(c.tipoCambio), tipoCambioFecha: c.tipoCambioFecha, subsidioTienda: subsidioTienda(), imprimirAuto: c.imprimirAuto !== '0', version: VERSION, updDisponible: c.upd_disponible || '', arranque: ARRANQUE }; },
  // Direcciones de esta computadora en la red (para conectar la tienda)
  'GET /api/red': () => ({ puerto: PORT, ips: Object.values(os.networkInterfaces()).flat().filter(i => i && i.family === 'IPv4' && !i.internal).map(i => i.address) }),
  'GET /api/ping': () => ({ ok: true, arranque: ARRANQUE, licencia: !!LICENCIA.activa }),
  'GET /api/licencia/estado': () => {
    const diasRest = LICENCIA.expira ? Math.ceil((new Date(LICENCIA.expira + 'T23:59:59') - new Date()) / 86400000) : null;
    return { activa: !!LICENCIA.activa, codigoEquipo: codigoEquipo(), huella: MODO_DESARROLLO ? '' : crypto.createHash('sha256').update(CLAVE_PUBLICA).digest('hex').slice(0, 8).toUpperCase(), cliente: LICENCIA.cliente || '', expira: LICENCIA.expira || null, diasRestantes: diasRest, motivo: LICENCIA.motivo || '', desarrollo: MODO_DESARROLLO, modulos: LICENCIA.modulos || modulosDe(MOD_TODOS) };
  },
  'POST /api/licencia/activar': (req, b) => {
    const clave = String(b.clave || '').replace(/\s+/g, '').toUpperCase();
    const r = leerLicencia(clave);
    if (!r.activa) throw new ErrorUsuario(r.motivo);
    fs.writeFileSync(LIC_FILE, clave);
    revisarLicencia(); log('Licencia activada para: ' + r.cliente + (r.nube ? ' (incluye nube hasta ' + r.nube + ')' : ''));
    return { ok: true, cliente: r.cliente, expira: r.expira, modulos: r.modulos };
  },
  // ----- Nube (Tailscale + Funnel): monitoreo desde el teléfono, igual que Maxsel Tech -----
  'GET /api/nube/licencia': () => licenciaNube(),
  'GET /api/nube': async (req) => { soloAdmin(req); soloEstaPC(req); const lic = licenciaNube(); if (!lic.activa) return { licencia: lic }; return { ...(await estadoNube()), licencia: lic }; },
  'POST /api/nube/licencia': (req, b) => {
    soloAdmin(req); soloEstaPC(req);
    const clave = String(b.clave || '').replace(/\s+/g, '').toUpperCase();
    const r = leerLicencia(clave);
    if (!r.nube) throw new ErrorUsuario(r.motivo && !r.cliente ? r.motivo : 'Esa licencia no incluye la nube. Pida a Maxsel una licencia con nube para el código ' + codigoEquipo() + '.');
    if (r.nube !== 'PERM' && r.nube < hoyNube()) throw new ErrorUsuario('Esa licencia de nube ya venció el ' + r.nube.split('-').reverse().join('/') + '. Pida una nueva a Maxsel.');
    fs.writeFileSync(NUBE_FILE, clave);
    if (r.activa && !MODO_DESARROLLO) { fs.writeFileSync(LIC_FILE, clave); revisarLicencia(); }
    log('Nube activada / renovada hasta ' + (r.nube === 'PERM' ? 'siempre' : r.nube));
    return { ok: true, licencia: licenciaNube() };
  },
  'POST /api/nube/funnel': async (req, b) => {
    soloAdmin(req); soloEstaPC(req);
    if (b.activar && !licenciaNube().activa) throw new ErrorUsuario('El servicio de nube no está activo o ya venció. Renuévelo con Maxsel.', 402);
    const r = await cambiarFunnel(!!b.activar);
    if (r.error) throw new ErrorUsuario(r.error);
    if (r.habilitar) return r;
    log('Acceso desde internet (Funnel) ' + (b.activar ? 'ACTIVADO' : 'desactivado'));
    return { ...(await estadoNube()), licencia: licenciaNube() };
  },

  // ----- Turnos de caja -----
  'GET /api/cajeros': () => todos('SELECT id,nombre FROM cajeros WHERE activo=1 ORDER BY nombre'),
  'GET /api/turno': (req, b, q) => {
    const t = turnoAbierto(q.estacion);
    if (!t) return { turno: null, tipoCambio: Number(cfg().tipoCambio) };
    return { turno: { id: t.id, estacion: t.estacion, cajeroId: t.cajeroId, cajero: t.cajero, apertura: t.apertura, tipoCambio: t.tipoCambio } };
  },
  'POST /api/turno/abrir': (req, b) => {
    if (!['comedor', 'tienda'].includes(b.estacion)) throw new ErrorUsuario('Caja inválida');
    const c = uno('SELECT * FROM cajeros WHERE id=? AND activo=1', Number(b.cajeroId));
    if (!c) throw new ErrorUsuario('Seleccione un cajero');
    if (String(b.pin) !== String(c.pin)) throw new ErrorUsuario('PIN del cajero incorrecto', 401);
    const tc = r2(b.tipoCambio), fondo = r2(b.fondo);
    if (!(tc > 0)) throw new ErrorUsuario('Escriba el tipo de cambio del día');
    if (fondo < 0) throw new ErrorUsuario('Fondo inválido');
    return transaccion(() => {
      if (turnoAbierto(b.estacion)) throw new ErrorUsuario('Ya hay un turno abierto en esta caja', 409);
      const n = new Date();
      setCfg('tipoCambio', tc); setCfg('tipoCambioFecha', fechaLocal(n));
      const r = ejecutar("INSERT INTO turnos(estacion,cajeroId,cajero,apertura,diaServicio,fondo,tipoCambio,estado) VALUES(?,?,?,?,?,?,?,'abierto')",
        b.estacion, c.id, c.nombre, fechaLocal(n) + ' ' + horaLocal(n), diaServicio(n), fondo, tc);
      const t = uno('SELECT * FROM turnos WHERE id=?', r.lastInsertRowid);
      return { ok: true, turno: { id: t.id, estacion: t.estacion, cajeroId: t.cajeroId, cajero: t.cajero, apertura: t.apertura, tipoCambio: t.tipoCambio } };
    });
  },
  // Corte ciego: el cajero solo declara lo que tiene; no recibe totales.
  'POST /api/turno/cerrar': (req, b) => {
    return transaccion(() => {
      const t = uno("SELECT * FROM turnos WHERE id=? AND estado='abierto'", Number(b.turnoId));
      if (!t) throw new ErrorUsuario('El turno ya está cerrado');
      const c = uno('SELECT * FROM cajeros WHERE id=?', t.cajeroId);
      if (!((c && String(b.pin) === String(c.pin)) || pinAdminOk(b.pin))) throw new ErrorUsuario('PIN incorrecto', 401);
      for (const k of ['efectivo', 'tarjeta', 'dolares']) if (b[k] === '' || b[k] == null || isNaN(Number(b[k])) || Number(b[k]) < 0) throw new ErrorUsuario('Escriba las tres cantidades (use 0 si no tiene)');
      const n = new Date();
      const dec = { efectivo: r2(b.efectivo), tarjeta: r2(b.tarjeta), dolares: r2(b.dolares) };
      const esp = calcularEsperado(t);
      const dif = { efectivo: r2(dec.efectivo - esp.efectivo), tarjeta: r2(dec.tarjeta - esp.tarjeta), dolares: r2(dec.dolares - esp.dolares) };
      const cierre = fechaLocal(n) + ' ' + horaLocal(n);
      ejecutar("UPDATE turnos SET estado='cerrado', cierre=?, declarado=?, esperado=?, diferencia=? WHERE id=?", cierre, JSON.stringify(dec), JSON.stringify(esp), JSON.stringify(dif), t.id);
      return { ok: true, cajero: t.cajero, cierre, declarado: dec };
    });
  },

  // ----- Operación de caja -----
  'POST /api/escanear': (req, b) => {
    const emp = empleadoDe(b.tarjeta);
    if (!emp) throw new ErrorUsuario('Tarjeta no registrada: ' + b.tarjeta, 404);
    if (!emp.activo) throw new ErrorUsuario('Empleado dado de baja: ' + emp.nombre, 403);
    const hoy = consumosHoy(emp.tarjeta);
    return { empleado: emp, consumosHoy: hoy, puedeConsumir: hoy.length < (Number(cfg().consumosPorDia) || 1), subsidioTienda: subsidioTienda() };
  },
  'POST /api/consumo': (req, b) => transaccion(() => {
    const t = exigirTurno(b.turnoId, b.estacion);
    if (b.estacion === 'tienda' && subsidioTienda() > 0) throw new ErrorUsuario('En la tienda el subsidio se aplica al cobrar los productos. Actualice la pantalla.', 409);
    const emp = empleadoDe(b.tarjeta);
    if (!emp) throw new ErrorUsuario('Tarjeta no registrada', 404);
    if (!emp.activo) throw new ErrorUsuario('Empleado dado de baja', 403);
    const hoy = consumosHoy(emp.tarjeta);
    if (hoy.length >= (Number(cfg().consumosPorDia) || 1)) {
      const u = hoy[hoy.length - 1];
      throw new ErrorUsuario(`${emp.nombre} YA CONSUMIÓ HOY en ${u.estacion.toUpperCase()} a las ${u.hora}`, 409);
    }
    const n = new Date();
    const c = { fecha: fechaLocal(n), hora: horaLocal(n), diaServicio: diaServicio(n), tarjeta: emp.tarjeta, nombre: emp.nombre, turno: emp.turno, estacion: b.estacion, turnoCajaId: t.id, cajero: t.cajero };
    const r = ejecutar("INSERT INTO consumos(fecha,hora,diaServicio,tarjeta,nombre,turno,estacion,turnoCajaId,cajero,tipo) VALUES(?,?,?,?,?,?,?,?,?,'empleado')", ...Object.values(c));
    return { ok: true, consumo: { id: Number(r.lastInsertRowid), tipo: 'empleado', ...c } };
  }),

  // ----- Vales (personas en semana de prueba, aún sin tarjeta) -----
  // PAGO CON VALE: un clic, sin capturar nada. Cuenta como consumo tipo "vale".
  'POST /api/vale/registrar': (req, b) => transaccion(() => {
    const t = exigirTurno(b.turnoId, b.estacion);
    if (b.estacion === 'tienda' && subsidioTienda() > 0) throw new ErrorUsuario('En la tienda el vale se aplica al cobrar los productos. Actualice la pantalla.', 409);
    const n = new Date();
    const c = { fecha: fechaLocal(n), hora: horaLocal(n), diaServicio: diaServicio(n), tarjeta: '', nombre: 'Pago con vale', turno: '', estacion: b.estacion, turnoCajaId: t.id, cajero: t.cajero };
    const r = ejecutar("INSERT INTO consumos(fecha,hora,diaServicio,tarjeta,nombre,turno,estacion,turnoCajaId,cajero,tipo) VALUES(?,?,?,?,?,?,?,?,?,'vale')", ...Object.values(c));
    return { ok: true, consumo: { id: Number(r.lastInsertRowid), tipo: 'vale', ...c } };
  }),
  'POST /api/vale/consultar': (req, b) => estadoVale(b.folio),
  'POST /api/vale/canjear': (req, b) => transaccion(() => {
    const t = exigirTurno(b.turnoId, b.estacion);
    const e = estadoVale(b.folio);
    if (!e.valido) throw new ErrorUsuario(e.motivo, 409);
    const v = e.vale, n = new Date();
    const c = { fecha: fechaLocal(n), hora: horaLocal(n), diaServicio: diaServicio(n), tarjeta: v.folio, nombre: v.nombre, turno: '', estacion: b.estacion, turnoCajaId: t.id, cajero: t.cajero };
    const r = ejecutar("INSERT INTO consumos(fecha,hora,diaServicio,tarjeta,nombre,turno,estacion,turnoCajaId,cajero,tipo) VALUES(?,?,?,?,?,?,?,?,?,'vale')", ...Object.values(c));
    ejecutar("UPDATE vales SET estado='usado', consumoId=?, usadoEn=?, estacion=?, cajero=? WHERE id=?", Number(r.lastInsertRowid), c.fecha + ' ' + c.hora, b.estacion, t.cajero, v.id);
    return { ok: true, consumo: { id: Number(r.lastInsertRowid), tipo: 'vale', ...c } };
  }),
  'POST /api/venta': (req, b) => transaccion(() => {
    const t = exigirTurno(b.turnoId, b.estacion);
    const items = []; let total = 0;
    for (const it of b.items || []) {
      const p = producto(it.id);
      const cant = Math.max(1, parseInt(it.cant) || 1);
      if (!p || p.estacion !== b.estacion) continue;
      if (p.controlStock && p.stock < cant) throw new ErrorUsuario(`Sin existencia suficiente de "${p.nombre}" (quedan ${p.stock})`, 409);
      items.push({ id: p.id, codigo: p.codigo || '', nombre: p.nombre, precio: p.precio, costo: p.costo || 0, cant });
      total += p.precio * cant;
    }
    if (!items.length) throw new ErrorUsuario('No hay productos en la venta');
    total = r2(total);
    // Subsidio de la tienda: el empleado (o el vale) tiene derecho a "x" pesos por día
    let emp = b.tarjeta ? empleadoDe(b.tarjeta) : null, subsidio = 0, tipoSub = null;
    if (b.subsidio === 'empleado' || b.subsidio === 'vale') {
      if (b.estacion !== 'tienda') throw new ErrorUsuario('El subsidio en pesos solo aplica en la tienda');
      const tope = subsidioTienda();
      if (!(tope > 0)) throw new ErrorUsuario('El subsidio de la tienda está desactivado en Configuración');
      if (b.subsidio === 'empleado') {
        if (!emp) throw new ErrorUsuario('Tarjeta no registrada', 404);
        if (!emp.activo) throw new ErrorUsuario('Empleado dado de baja: ' + emp.nombre, 403);
        const hoy = consumosHoy(emp.tarjeta);
        if (hoy.length >= (Number(cfg().consumosPorDia) || 1)) {
          const u = hoy[hoy.length - 1];
          throw new ErrorUsuario(`${emp.nombre} YA USÓ SU SUBSIDIO HOY en ${u.estacion.toUpperCase()} a las ${u.hora}`, 409);
        }
      } else emp = null;
      tipoSub = b.subsidio; subsidio = r2(Math.min(total, tope));
    }
    const aPagar = r2(total - subsidio);
    // Formas de pago (ventana de cobro): efectivo, dólares, tarjeta, transferencia o varias a la vez (mixto)
    let pg = b.pagos;
    if (!pg) { // compatibilidad con pantallas anteriores
      const rv = b.recibido === '' || b.recibido == null ? null : r2(b.recibido);
      pg = { efectivo: b.metodo === 'efectivo' ? (rv ?? aPagar) : 0, usd: b.metodo === 'dolares' ? rv : 0, tarjeta: b.metodo === 'tarjeta' ? aPagar : 0, transferencia: 0 };
    }
    const num = x => { const n = r2(x); return n > 0 ? n : 0; };
    let pe = num(pg.efectivo), pu = num(pg.usd), pt = num(pg.tarjeta), pr = num(pg.transferencia);
    const referencia = String(pg.referencia || '').trim().slice(0, 60);
    let metodo, recibido = 0, cambio = 0;
    if (aPagar <= 0) { metodo = 'subsidio'; pe = pu = pt = pr = 0; }
    else {
      const usados = [pe > 0 && 'efectivo', pu > 0 && 'dolares', pt > 0 && 'tarjeta', pr > 0 && 'transferencia'].filter(Boolean);
      if (!usados.length) throw new ErrorUsuario('Seleccione la forma de pago');
      if (pu > 0 && !(t.tipoCambio > 0)) throw new ErrorUsuario('El turno no tiene tipo de cambio');
      if (r2(pt + pr) > aPagar + 0.009) throw new ErrorUsuario('Tarjeta y transferencia no pueden pasar del total (el cambio solo se da en efectivo)');
      const pagado = r2(pe + pu * t.tipoCambio + pt + pr);
      if (pagado + 0.009 < aPagar) throw new ErrorUsuario(`Faltan ${r2(aPagar - pagado)} pesos`);
      cambio = r2(pagado - aPagar);
      metodo = usados.length > 1 ? 'mixto' : usados[0];
      recibido = metodo === 'dolares' ? pu : pagado;
    }
    items.forEach(it => {
      const p = producto(it.id);
      if (p.controlStock) { ejecutar('UPDATE productos SET stock=stock-? WHERE id=?', it.cant, p.id); p.stock -= it.cant; registrarMov(p, 'venta', -it.cant, 'Venta'); }
    });
    const n = new Date();
    const nombreCli = emp ? emp.nombre : tipoSub === 'vale' ? 'Pago con vale' : 'Público general';
    const r = ejecutar('INSERT INTO ventas(fecha,hora,diaServicio,estacion,turnoCajaId,cajero,tarjeta,nombre,items,total,metodo,recibido,tipoCambio,cambio,subsidio,pagoEfectivo,pagoUsd,pagoTarjeta,pagoTransferencia,referencia) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
      fechaLocal(n), horaLocal(n), diaServicio(n), b.estacion, t.id, t.cajero, emp ? emp.tarjeta : '', nombreCli,
      JSON.stringify(items), total, metodo, recibido, pu > 0 ? t.tipoCambio : null, cambio, subsidio, pe, pu, pt, pr, referencia);
    const ventaId = Number(r.lastInsertRowid);
    let consumo = null;
    if (tipoSub) {
      const c = { fecha: fechaLocal(n), hora: horaLocal(n), diaServicio: diaServicio(n), tarjeta: emp ? emp.tarjeta : '', nombre: emp ? emp.nombre : 'Pago con vale',
        turno: emp ? emp.turno : '', estacion: b.estacion, turnoCajaId: t.id, cajero: t.cajero, tipo: tipoSub, monto: subsidioTienda(), ventaId };
      const rc = ejecutar('INSERT INTO consumos(fecha,hora,diaServicio,tarjeta,nombre,turno,estacion,turnoCajaId,cajero,tipo,monto,ventaId) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)', ...Object.values(c));
      consumo = { id: Number(rc.lastInsertRowid), ...c };
      ejecutar('UPDATE ventas SET consumoId=? WHERE id=?', consumo.id, ventaId);
    }
    return { ok: true, venta: { id: ventaId, fecha: fechaLocal(n), hora: horaLocal(n), estacion: b.estacion, cajero: t.cajero, cliente: nombreCli, items, total, subsidio, aPagar, metodo, recibido, cambio,
      pagoEfectivo: pe, pagoUsd: pu, pagoTarjeta: pt, pagoTransferencia: pr, tipoCambio: t.tipoCambio, referencia }, consumo };
  }),
  'GET /api/productos': (req, b, q) => {
    let sql = 'SELECT * FROM productos WHERE 1=1'; const p = [];
    if (q.estacion) { sql += ' AND estacion=?'; p.push(q.estacion); }
    if (!q.todos) sql += ' AND activo=1';
    return todos(sql + ' ORDER BY estacion, nombre', ...p).map(x => ({ ...x, activo: !!x.activo, controlStock: !!x.controlStock }));
  },
  'GET /api/recientes': (req, b, q) => ({
    consumos: todos('SELECT * FROM consumos WHERE turnoCajaId=? ORDER BY id DESC LIMIT 15', Number(q.turnoId) || 0),
    totalConsumos: uno("SELECT COUNT(*) n FROM consumos WHERE turnoCajaId=? AND IFNULL(tipo,'empleado')='empleado'", Number(q.turnoId) || 0).n,
    totalVales: uno("SELECT COUNT(*) n FROM consumos WHERE turnoCajaId=? AND tipo='vale'", Number(q.turnoId) || 0).n,
    totalSubsidio: r2(uno('SELECT SUM(monto) n FROM consumos WHERE turnoCajaId=?', Number(q.turnoId) || 0).n || 0)
  }),

  // ----- ADMIN -----
  'POST /api/login': (req, b) => {
    frenoIntentos(req, false);
    if (!pinAdminOk(b.pin)) { frenoIntentos(req, true); throw new ErrorUsuario('PIN incorrecto', 401); }
    if (esSoporte(b.pin)) log('Entró a Administración el soporte de Maxsel');
    return { ok: true, soporte: esSoporte(b.pin) };
  },
  // ¿Olvidó su PIN? Un PIN nuevo para el administrador o un cajero, autorizado con el PIN del administrador
  // o con la clave de soporte de Maxsel (si nadie recuerda el del administrador).
  'POST /api/recuperar': (req, b) => {
    frenoIntentos(req, false);
    const nuevo = String(b.nuevo || '').trim();
    if (!/^\d{4,8}$/.test(nuevo)) throw new ErrorUsuario('El PIN nuevo debe ser de 4 a 8 números');
    if (nuevo !== String(b.nuevo2 || '').trim()) throw new ErrorUsuario('Los PIN nuevos no coinciden');
    if (!pinAdminOk(b.autoriza)) { frenoIntentos(req, true); throw new ErrorUsuario('El PIN del administrador (o la clave de soporte de Maxsel) no es correcto', 401); }
    if (b.quien === 'admin') {
      setCfg('pinAdmin', nuevo);
      log('Se cambió el PIN de administrador desde "¿Olvidó su PIN?"' + (esSoporte(b.autoriza) ? ' (soporte Maxsel)' : ''));
      return { ok: true, nombre: 'Administrador' };
    }
    const c = uno('SELECT * FROM cajeros WHERE id=?', Number(b.quien));
    if (!c) throw new ErrorUsuario('Elija el usuario');
    ejecutar('UPDATE cajeros SET pin=? WHERE id=?', nuevo, c.id);
    log('Se cambió el PIN del cajero ' + c.nombre + ' desde "¿Olvidó su PIN?"' + (esSoporte(b.autoriza) ? ' (soporte Maxsel)' : ''));
    return { ok: true, nombre: c.nombre };
  },
  'GET /api/admin/empleados': (req) => { soloAdmin(req); return todos('SELECT * FROM empleados ORDER BY nombre').map(e => ({ ...e, activo: !!e.activo })); },
  'POST /api/admin/empleado': (req, b) => {
    soloAdmin(req);
    const t = limpiarTarjeta(b.tarjeta), nombre = String(b.nombre || '').trim();
    if (!t || !nombre) throw new ErrorUsuario('Tarjeta y nombre son obligatorios');
    transaccion(() => {
      const orig = limpiarTarjeta(b.tarjetaOriginal || '');
      if (orig && orig !== t) {
        if (empleadoDe(t)) throw new ErrorUsuario('Ya existe otro empleado con esa tarjeta');
        ejecutar('DELETE FROM empleados WHERE tarjeta=?', orig);
      }
      ejecutar('INSERT INTO empleados(tarjeta,nombre,turno,activo) VALUES(?,?,?,?) ON CONFLICT(tarjeta) DO UPDATE SET nombre=excluded.nombre, turno=excluded.turno, activo=excluded.activo',
        t, nombre, normalizarTurno(b.turno), b.activo === false ? 0 : 1);
    });
    return { ok: true };
  },
  'POST /api/admin/empleado/borrar': (req, b) => { soloAdmin(req); ejecutar('DELETE FROM empleados WHERE tarjeta=?', limpiarTarjeta(b.tarjeta)); return { ok: true }; },
  'POST /api/admin/importar': (req, b) => {
    soloAdmin(req);
    let nuevos = 0, actualizados = 0, bajas = 0; const errores = [];
    transaccion(() => {
      ejecutar('CREATE TEMP TABLE IF NOT EXISTS vistos(t TEXT PRIMARY KEY)'); ejecutar('DELETE FROM vistos');
      const v = db.prepare('INSERT OR IGNORE INTO vistos VALUES(?)');
      const up = db.prepare('INSERT INTO empleados(tarjeta,nombre,turno,activo) VALUES(?,?,?,1) ON CONFLICT(tarjeta) DO UPDATE SET nombre=excluded.nombre, turno=excluded.turno, activo=1');
      (b.filas || []).forEach((f, i) => {
        const t = limpiarTarjeta(f.tarjeta), nombre = String(f.nombre || '').trim();
        if (!t || !nombre) { errores.push(`Fila ${i + 2}: falta tarjeta o nombre`); return; }
        if (empleadoDe(t)) actualizados++; else nuevos++;
        up.run(t, nombre, normalizarTurno(f.turno)); v.run(t);
      });
      if (b.modo === 'reemplazar') bajas = Number(ejecutar('UPDATE empleados SET activo=0 WHERE activo=1 AND tarjeta NOT IN (SELECT t FROM vistos)').changes);
    });
    return { ok: true, nuevos, actualizados, bajas, errores };
  },
  'GET /api/admin/cajeros': (req) => { soloAdmin(req); return todos('SELECT id,nombre,activo FROM cajeros ORDER BY nombre').map(c => ({ ...c, activo: !!c.activo })); },
  'POST /api/admin/cajero': (req, b) => {
    soloAdmin(req);
    const nombre = String(b.nombre || '').trim(), pin = String(b.pin || '').trim();
    if (!nombre) throw new ErrorUsuario('Escriba el nombre del cajero');
    if (pin && !/^\d{4,8}$/.test(pin)) throw new ErrorUsuario('El PIN debe ser de 4 a 8 números');
    if (b.id) {
      ejecutar('UPDATE cajeros SET nombre=?, activo=? WHERE id=?', nombre, b.activo === false ? 0 : 1, Number(b.id));
      if (pin) ejecutar('UPDATE cajeros SET pin=? WHERE id=?', pin, Number(b.id));
    } else {
      if (!pin) throw new ErrorUsuario('Escriba un PIN de 4 a 8 números');
      ejecutar('INSERT INTO cajeros(nombre,pin) VALUES(?,?)', nombre, pin);
    }
    return { ok: true };
  },
  'POST /api/admin/producto': (req, b) => {
    soloAdmin(req);
    if (!String(b.nombre || '').trim() || !['comedor', 'tienda'].includes(b.estacion)) throw new ErrorUsuario('Datos incompletos');
    const precio = Number(b.precio);
    if (isNaN(precio) || precio < 0) throw new ErrorUsuario('Precio inválido');
    const costo = b.costo === '' || b.costo == null ? 0 : Number(b.costo);
    if (isNaN(costo) || costo < 0) throw new ErrorUsuario('Precio de costo inválido');
    const codigo = String(b.codigo || '').trim();
    const existencia = b.existencia === '' || b.existencia == null ? null : parseInt(b.existencia);
    if (existencia !== null && (isNaN(existencia) || existencia < 0)) throw new ErrorUsuario('Existencia inválida');
    const controlStock = b.controlStock || existencia !== null && existencia > 0;
    const datos = [b.nombre.trim(), r2(precio), r2(costo), codigo, b.estacion, b.activo === false ? 0 : 1, controlStock ? 1 : 0, Math.max(0, parseInt(b.minimo) || 0)];
    transaccion(() => {
      if (codigo) {
        const otro = uno('SELECT id,nombre FROM productos WHERE codigo=? AND id<>?', codigo, Number(b.id) || 0);
        if (otro) throw new ErrorUsuario(`El código ${codigo} ya lo tiene el producto "${otro.nombre}"`);
      }
      let id = Number(b.id);
      const antes = id ? producto(id) : null;
      if (id) ejecutar('UPDATE productos SET nombre=?, precio=?, costo=?, codigo=?, estacion=?, activo=?, controlStock=?, minimo=? WHERE id=?', ...datos, id);
      else id = Number(ejecutar('INSERT INTO productos(nombre,precio,costo,codigo,estacion,activo,controlStock,minimo,stock) VALUES(?,?,?,?,?,?,?,?,0)', ...datos).lastInsertRowid);
      const p = producto(id);
      if (existencia !== null && existencia !== p.stock) {
        const dif = existencia - p.stock;
        ejecutar('UPDATE productos SET stock=? WHERE id=?', existencia, id); p.stock = existencia;
        const primeraVez = !antes || (!antes.controlStock && !uno('SELECT 1 x FROM movimientos WHERE productoId=? LIMIT 1', id));
        registrarMov(p, primeraVez ? 'entrada' : 'ajuste', dif, primeraVez ? 'Existencia inicial' : 'Cambio de existencia');
      }
    });
    return { ok: true };
  },
  // Importar productos desde Excel: Código | Nombre | Costo | Venta | Existencia | Mínimo
  'POST /api/admin/productos/importar': (req, b) => {
    soloAdmin(req);
    const estacion = ['comedor', 'tienda'].includes(b.estacion) ? b.estacion : 'tienda';
    const num = v => { const s = String(v ?? '').replace(/[$,\s]/g, ''); return s === '' ? null : Number(s); };
    let nuevos = 0, actualizados = 0; const errores = [];
    transaccion(() => {
      (b.filas || []).forEach((f, i) => {
        let codigo = String(f.codigo ?? '').trim();
        if (/e\+/i.test(codigo) && !isNaN(Number(codigo))) codigo = BigInt(Math.round(Number(codigo))).toString();
        const nombre = String(f.nombre ?? '').trim();
        const costo = num(f.costo), precio = num(f.precio), exist = num(f.existencia), minimo = num(f.minimo);
        const fila = f.fila || (i + 1);
        if (!nombre) { errores.push(`Fila ${fila}: falta el nombre`); return; }
        if (precio === null || isNaN(precio) || precio < 0) { errores.push(`Fila ${fila} (${nombre}): precio de venta inválido`); return; }
        if (costo !== null && (isNaN(costo) || costo < 0)) { errores.push(`Fila ${fila} (${nombre}): precio de costo inválido`); return; }
        if (exist !== null && (isNaN(exist) || exist < 0)) { errores.push(`Fila ${fila} (${nombre}): existencia inválida`); return; }
        let esNuevo = false;
        let p = codigo ? uno('SELECT * FROM productos WHERE codigo=?', codigo) : uno("SELECT * FROM productos WHERE lower(nombre)=lower(?) AND estacion=? AND IFNULL(codigo,'')=''", nombre, estacion);
        if (p) {
          ejecutar('UPDATE productos SET nombre=?, precio=?, costo=COALESCE(?,costo), minimo=COALESCE(?,minimo), activo=1 WHERE id=?', nombre, r2(precio), costo === null ? null : r2(costo), minimo === null ? null : Math.round(minimo), p.id);
          actualizados++;
        } else {
          const r = ejecutar('INSERT INTO productos(estacion,codigo,nombre,precio,costo,minimo,stock,controlStock,activo) VALUES(?,?,?,?,?,?,0,1,1)',
            estacion, codigo, nombre, r2(precio), r2(costo || 0), Math.round(minimo || 0));
          p = { id: Number(r.lastInsertRowid), stock: 0, controlStock: 0 }; nuevos++; esNuevo = true;
        }
        if (exist !== null) {
          const nuevo = Math.round(exist), pr = producto(p.id), dif = nuevo - pr.stock;
          ejecutar('UPDATE productos SET stock=?, controlStock=1 WHERE id=?', nuevo, p.id);
          if (dif !== 0) { pr.stock = nuevo; registrarMov(pr, esNuevo || !p.controlStock ? 'entrada' : 'ajuste', dif, esNuevo ? 'Existencia inicial (Excel)' : 'Importado desde Excel'); }
        }
      });
    });
    return { ok: true, nuevos, actualizados, errores };
  },
  'POST /api/admin/producto/borrar': (req, b) => { soloAdmin(req); ejecutar('DELETE FROM productos WHERE id=?', Number(b.id)); return { ok: true }; },
  'POST /api/admin/inventario': (req, b) => {
    soloAdmin(req);
    return transaccion(() => {
      const p = producto(b.productoId);
      if (!p) throw new ErrorUsuario('Seleccione un producto');
      const cant = parseInt(b.cantidad);
      if (isNaN(cant)) throw new ErrorUsuario('Cantidad inválida');
      let nuevo, mov;
      if (b.tipo === 'entrada') { if (cant <= 0) throw new ErrorUsuario('La cantidad debe ser mayor a 0'); nuevo = p.stock + cant; mov = cant; }
      else if (b.tipo === 'salida') { if (cant <= 0) throw new ErrorUsuario('La cantidad debe ser mayor a 0'); nuevo = p.stock - cant; mov = -cant; }
      else if (b.tipo === 'ajuste') { if (cant < 0) throw new ErrorUsuario('Conteo inválido'); nuevo = cant; mov = cant - p.stock; }
      else throw new ErrorUsuario('Tipo inválido');
      ejecutar('UPDATE productos SET stock=?, controlStock=1 WHERE id=?', nuevo, p.id);
      p.stock = nuevo;
      registrarMov(p, b.tipo, mov, b.nota || { entrada: 'Compra / entrada', salida: 'Merma / salida', ajuste: 'Conteo físico' }[b.tipo]);
      return { ok: true, stock: nuevo };
    });
  },
  'GET /api/admin/movimientos': (req, b, q) => {
    soloAdmin(req);
    return q.productoId ? todos('SELECT * FROM movimientos WHERE productoId=? ORDER BY id DESC LIMIT 1000', Number(q.productoId))
      : todos('SELECT * FROM movimientos ORDER BY id DESC LIMIT 1000');
  },
  'GET /api/admin/inventario/reporte': (req, b, q) => {
    soloAdmin(req);
    const desde = q.desde || diaServicio(), hasta = q.hasta || diaServicio();
    const prods = todos('SELECT * FROM productos ' + (q.estacion ? 'WHERE estacion=? ' : '') + 'ORDER BY estacion, nombre', ...(q.estacion ? [q.estacion] : []));
    const vendidos = {};
    todos('SELECT items FROM ventas WHERE diaServicio BETWEEN ? AND ?', desde, hasta).forEach(v => JSON.parse(v.items || '[]').forEach(it => {
      const x = vendidos[it.id] = vendidos[it.id] || { cant: 0, importe: 0, costo: 0 };
      x.cant += it.cant; x.importe += it.cant * it.precio; x.costo += it.cant * (it.costo || 0);
    }));
    const movRango = {}, movDespues = {};
    todos('SELECT productoId, tipo, SUM(cantidad) n FROM movimientos WHERE fecha BETWEEN ? AND ? GROUP BY productoId, tipo', desde, hasta)
      .forEach(m => { (movRango[m.productoId] = movRango[m.productoId] || {})[m.tipo] = m.n; });
    todos('SELECT productoId, SUM(cantidad) n FROM movimientos WHERE fecha > ? GROUP BY productoId', hasta).forEach(m => movDespues[m.productoId] = m.n);
    const filas = prods.map(p => {
      const m = movRango[p.id] || {}, v = vendidos[p.id] || { cant: 0, importe: 0, costo: 0 };
      const neto = Object.values(m).reduce((s, n) => s + n, 0);
      const final = p.stock - (movDespues[p.id] || 0);
      return { id: p.id, codigo: p.codigo || '', nombre: p.nombre, estacion: p.estacion, costo: p.costo || 0, precio: p.precio, controlStock: !!p.controlStock, minimo: p.minimo,
        inicial: final - neto, entradas: m.entrada || 0, vendidos: v.cant, salidas: -(m.salida || 0), ajustes: m.ajuste || 0,
        final, actual: p.stock, importe: r2(v.importe), costoVendido: r2(v.costo), ganancia: r2(v.importe - v.costo) };
    });
    return { desde, hasta, filas };
  },
  'GET /api/admin/turnos': (req, b, q) => {
    soloAdmin(req);
    return todos("SELECT * FROM turnos WHERE estado='abierto' OR (substr(apertura,1,10) BETWEEN ? AND ?) ORDER BY (estado='abierto') DESC, id DESC LIMIT 500",
      q.desde || '0000', q.hasta || '9999').map(turnoPublico);
  },
  'POST /api/admin/consumo/cancelar': (req, b) => {
    soloAdmin(req);
    const co = uno('SELECT * FROM consumos WHERE id=?', Number(b.id));
    if (co && co.ventaId && uno('SELECT id FROM ventas WHERE id=?', co.ventaId)) return cancelarVenta(co.ventaId);
    transaccion(() => {
      ejecutar("UPDATE vales SET estado='pendiente', consumoId=NULL, usadoEn=NULL, estacion=NULL, cajero=NULL WHERE consumoId=?", Number(b.id));
      ejecutar('DELETE FROM consumos WHERE id=?', Number(b.id));
    });
    return { ok: true };
  },
  // Vales: emitir, listar, cancelar
  'POST /api/admin/vales/emitir': (req, b) => {
    soloAdmin(req);
    const nombre = String(b.nombre || '').trim().replace(/\s+/g, ' ');
    if (!nombre) throw new ErrorUsuario('Escriba el nombre de la persona');
    const dias = Math.min(31, Math.max(1, parseInt(b.dias) || 1));
    const porDia = Math.min(5, Math.max(1, parseInt(b.porDia) || 1));
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(b.desde || ''))) throw new ErrorUsuario('Seleccione la fecha de inicio');
    const n = new Date(), emitidos = [];
    transaccion(() => {
      for (let d = 0; d < dias; d++) {
        const f = new Date(b.desde + 'T12:00:00'); f.setDate(f.getDate() + d);
        for (let k = 0; k < porDia; k++) {
          const r = ejecutar("INSERT INTO vales(nombre,fecha,emitido,nota,estado) VALUES(?,?,?,?,'pendiente')", nombre, fechaLocal(f), fechaLocal(n) + ' ' + horaLocal(n), String(b.nota || '').trim());
          const folio = 'V' + String(r.lastInsertRowid).padStart(6, '0');
          ejecutar('UPDATE vales SET folio=? WHERE id=?', folio, r.lastInsertRowid);
          emitidos.push(uno('SELECT * FROM vales WHERE id=?', r.lastInsertRowid));
        }
      }
    });
    return { ok: true, vales: emitidos.map(v => ({ ...v })) };
  },
  'GET /api/admin/vales': (req, b, q) => {
    soloAdmin(req);
    let sql = 'SELECT * FROM vales WHERE fecha BETWEEN ? AND ?'; const p = [q.desde || '0000', q.hasta || '9999'];
    if (q.buscar) { sql += ' AND (nombre LIKE ? OR folio LIKE ?)'; p.push('%' + q.buscar + '%', '%' + q.buscar + '%'); }
    const hoy = diaServicio();
    return todos(sql + ' ORDER BY fecha DESC, id DESC LIMIT 2000', ...p).map(v => ({ ...v, estado: v.estado === 'pendiente' && v.fecha < hoy ? 'vencido' : v.estado }));
  },
  'POST /api/admin/vale/cancelar': (req, b) => {
    soloAdmin(req);
    const v = uno('SELECT * FROM vales WHERE id=?', Number(b.id));
    if (!v) throw new ErrorUsuario('No existe');
    if (v.estado === 'usado') throw new ErrorUsuario('Ese vale ya se usó. Si fue un error, cancele el consumo en Reportes.');
    ejecutar("UPDATE vales SET estado='cancelado' WHERE id=?", v.id);
    return { ok: true };
  },
  'POST /api/admin/venta/cancelar': (req, b) => { soloAdmin(req); return cancelarVenta(Number(b.id)); },
  'GET /api/admin/config': (req) => {
    soloAdmin(req); const c = cfg();
    return { empresa: c.empresa, horaInicioDia: Number(c.horaInicioDia), consumosPorDia: Number(c.consumosPorDia), tipoCambio: Number(c.tipoCambio),
      tipoCambioFecha: c.tipoCambioFecha, mesesHistorial: Number(c.mesesHistorial), carpetaRespaldoExtra: c.carpetaRespaldoExtra, subsidioTienda: subsidioTienda(), precioComida: r2(c.precioComida), imprimirAuto: c.imprimirAuto !== '0' };
  },
  'POST /api/admin/config': (req, b) => {
    soloAdmin(req);
    if (b.empresa) setCfg('empresa', String(b.empresa).trim());
    if (b.pinAdmin) { if (!/^\d{4,8}$/.test(String(b.pinAdmin))) throw new ErrorUsuario('El PIN debe ser de 4 a 8 números'); setCfg('pinAdmin', b.pinAdmin); }
    if (b.horaInicioDia !== undefined) setCfg('horaInicioDia', Math.min(23, Math.max(0, parseInt(b.horaInicioDia) || 0)));
    if (b.consumosPorDia !== undefined) setCfg('consumosPorDia', Math.max(1, parseInt(b.consumosPorDia) || 1));
    if (b.tipoCambio !== undefined && Number(b.tipoCambio) > 0) { setCfg('tipoCambio', r2(b.tipoCambio)); setCfg('tipoCambioFecha', fechaLocal(new Date())); }
    if (b.subsidioTienda !== undefined && b.subsidioTienda !== '') {
      const m = r2(b.subsidioTienda);
      if (isNaN(m) || m < 0 || m > 10000) throw new ErrorUsuario('El subsidio de la tienda debe ser una cantidad entre 0 y 10,000 pesos');
      setCfg('subsidioTienda', m);
    }
    if (b.precioComida !== undefined && b.precioComida !== '') {
      const m = r2(b.precioComida);
      if (isNaN(m) || m < 0 || m > 10000) throw new ErrorUsuario('El precio por comida debe ser una cantidad entre 0 y 10,000 pesos');
      setCfg('precioComida', m);
    }
    // Ticket automático al cobrar (encendido por defecto)
    if (b.imprimirAuto !== undefined) setCfg('imprimirAuto', b.imprimirAuto === false || b.imprimirAuto === '0' || b.imprimirAuto === 0 ? '0' : '1');
    if (b.mesesHistorial !== undefined) setCfg('mesesHistorial', Math.min(24, Math.max(1, parseInt(b.mesesHistorial) || 3)));
    if (b.carpetaRespaldoExtra !== undefined) {
      const c = String(b.carpetaRespaldoExtra).trim();
      if (c && !fs.existsSync(c)) throw new ErrorUsuario('No se encontró la carpeta: ' + c + '. Revise que la USB esté conectada o que la ruta esté bien escrita.');
      setCfg('carpetaRespaldoExtra', c);
    }
    return { ok: true };
  },
  // Impacto económico de cada unidad de negocio (para la gráfica de pastel) y comparación con meses anteriores
  'GET /api/admin/unidades': (req, b, q) => {
    soloAdmin(req);
    const desde = q.desde || diaServicio(), hasta = q.hasta || diaServicio(), precio = r2(cfg().precioComida);
    const calcular = (d, h) => {
      const n = (sql) => uno(sql, d, h).n || 0;
      const comidas = n("SELECT COUNT(*) n FROM consumos WHERE diaServicio BETWEEN ? AND ? AND estacion='comedor'");
      return {
        comidas, valesComedor: n("SELECT COUNT(*) n FROM consumos WHERE diaServicio BETWEEN ? AND ? AND estacion='comedor' AND tipo='vale'"),
        unidades: [
          { clave: 'comidas', unidad: 'Comedor · comidas subsidiadas', total: r2(comidas * precio) },
          { clave: 'extras', unidad: 'Comedor · venta de extras', total: r2(n("SELECT SUM(total) n FROM ventas WHERE diaServicio BETWEEN ? AND ? AND estacion='comedor'")) },
          { clave: 'subsidio', unidad: 'Tienda · subsidio de la empresa', total: r2(n("SELECT SUM(monto) n FROM consumos WHERE diaServicio BETWEEN ? AND ? AND estacion='tienda'")) },
          { clave: 'tienda', unidad: 'Tienda · venta a clientes', total: r2(n("SELECT SUM(total-IFNULL(subsidio,0)) n FROM ventas WHERE diaServicio BETWEEN ? AND ? AND estacion='tienda'")) }
        ]
      };
    };
    const actual = calcular(desde, hasta), tot = actual.unidades.reduce((a, x) => a + x.total, 0);
    actual.unidades.forEach(x => { x.pct = tot ? Math.round(x.total / tot * 1000) / 10 : 0; });
    // últimos 6 meses (los que sigan guardados en el sistema)
    const meses = [], base = new Date(hasta + 'T12:00:00');
    for (let i = 5; i >= 0; i--) {
      const d = new Date(base.getFullYear(), base.getMonth() - i, 1), f = new Date(d.getFullYear(), d.getMonth() + 1, 0);
      const c = calcular(fechaLocal(d), fechaLocal(f));
      const m = { mes: fechaLocal(d).slice(0, 7), unidades: {}, total: 0 };
      c.unidades.forEach(x => { m.unidades[x.unidad] = x.total; m.total = r2(m.total + x.total); });
      meses.push(m);
    }
    return { desde, hasta, precioComida: precio, comidas: actual.comidas, unidades: actual.unidades, total: r2(tot), meses: { unidades: actual.unidades.map(x => x.unidad), meses } };
  },
  'GET /api/admin/reporte': (req, b, q) => {
    soloAdmin(req);
    const desde = q.desde || diaServicio(), hasta = q.hasta || diaServicio();
    // Por turno de un cajero, o por rango de fechas (opcionalmente solo una caja)
    const turnoSel = q.turno ? uno('SELECT * FROM turnos WHERE id=?', Number(q.turno)) : null;
    if (q.turno && !turnoSel) throw new ErrorUsuario('Ese turno no existe');
    let W, P;
    if (turnoSel) { W = 'turnoCajaId = ?'; P = [turnoSel.id]; }
    else if (q.caja === 'comedor' || q.caja === 'tienda') { W = 'diaServicio BETWEEN ? AND ? AND estacion = ?'; P = [desde, hasta, q.caja]; }
    else { W = 'diaServicio BETWEEN ? AND ?'; P = [desde, hasta]; }
    const n = (sql) => uno(sql, ...P).n || 0;
    const resumen = {
      consumosComedor: n(`SELECT COUNT(*) n FROM consumos WHERE ${W} AND estacion='comedor' AND IFNULL(tipo,'empleado')='empleado'`),
      consumosTienda: n(`SELECT COUNT(*) n FROM consumos WHERE ${W} AND estacion='tienda' AND IFNULL(tipo,'empleado')='empleado'`),
      valesComedor: n(`SELECT COUNT(*) n FROM consumos WHERE ${W} AND estacion='comedor' AND tipo='vale'`),
      valesTienda: n(`SELECT COUNT(*) n FROM consumos WHERE ${W} AND estacion='tienda' AND tipo='vale'`),
      porTurno: { Día: 0, Tarde: 0, Noche: 0 },
      ventasComedor: r2(n(`SELECT SUM(total) n FROM ventas WHERE ${W} AND estacion='comedor'`)),
      ventasTienda: r2(n(`SELECT SUM(total) n FROM ventas WHERE ${W} AND estacion='tienda'`)),

      subsidioEmpleados: r2(n(`SELECT SUM(monto) n FROM consumos WHERE ${W} AND IFNULL(tipo,'empleado')='empleado'`)),
      subsidioVales: r2(n(`SELECT SUM(monto) n FROM consumos WHERE ${W} AND tipo='vale'`)),
    };
    { const d = desglosePagos(todos(`SELECT * FROM ventas WHERE ${W}`, ...P));
      Object.assign(resumen, { efectivo: d.efectivo, tarjeta: d.tarjeta, transferencia: d.transferencia, dolaresMXN: d.dolaresMXN, dolaresUSD: d.dolaresUSD }); }
    todos(`SELECT turno, COUNT(*) n FROM consumos WHERE ${W} GROUP BY turno`, ...P).forEach(r => resumen.porTurno[r.turno] = r.n);
    const ventas = todos(`SELECT * FROM ventas WHERE ${W} ORDER BY id`, ...P).map(ventaPublica);
    const productos = {};
    ventas.forEach(v => v.items.forEach(it => {
      const k = v.estacion + '|' + it.nombre;
      productos[k] = productos[k] || { estacion: v.estacion, nombre: it.nombre, cant: 0, total: 0 };
      productos[k].cant += it.cant; productos[k].total = r2(productos[k].total + it.cant * it.precio);
    }));
    const E = `${W} AND IFNULL(tipo,'empleado')='empleado'`, V = `${W} AND tipo='vale'`;
    const totalConsumos = n(`SELECT COUNT(*) n FROM consumos WHERE ${E}`);
    const totalVales = n(`SELECT COUNT(*) n FROM consumos WHERE ${V}`);
    const consumos = q.todos ? todos(`SELECT * FROM consumos WHERE ${E} ORDER BY id`, ...P)
      : todos(`SELECT * FROM consumos WHERE ${E} ORDER BY id DESC LIMIT 2000`, ...P).reverse();
    const vales = q.todos ? todos(`SELECT * FROM consumos WHERE ${V} ORDER BY id`, ...P)
      : todos(`SELECT * FROM consumos WHERE ${V} ORDER BY id DESC LIMIT 2000`, ...P).reverse();
    return { desde, hasta, turno: turnoSel ? turnoPublico(turnoSel) : null, caja: q.caja || '', resumen, consumos, totalConsumos, vales, totalVales, ventas, productos: Object.values(productos) };
  },
  // ----- Respaldos -----
  'GET /api/admin/respaldos': (req) => {
    soloAdmin(req);
    const st = fs.statSync(DB_FILE);
    const c = uno('SELECT (SELECT COUNT(*) FROM consumos) consumos, (SELECT COUNT(*) FROM ventas) ventas, (SELECT COUNT(*) FROM empleados) empleados, (SELECT MIN(diaServicio) FROM consumos) desde');
    return { lista: listaRespaldos(), carpeta: BACKUP_DIR, archivoHistorico: ARCHIVO_DIR, baseDatos: { tamano: st.size, ...c }, carpetaExtra: cfg().carpetaRespaldoExtra };
  },
  // Actualizaciones por internet (solo administrador)
  'GET /api/admin/actualizacion': async (req) => { soloAdmin(req); const { _e, ...v } = await versionDisponible(); return { ...v, ultima: cfg().upd_ultima || '' }; },
  'POST /api/admin/actualizacion/instalar': (req) => { soloAdmin(req); return instalarActualizacion(); },
  // Reiniciar el sistema (botón oculto, solo Maxsel): borra consumos, vales, ventas, turnos y cortes —p. ej. las pruebas de
  // la instalación—. Lo vendido regresa al inventario. Antes se guarda un respaldo completo por si hiciera falta regresar.
  'POST /api/admin/reiniciar': (req, b) => {
    soloAdmin(req);
    frenoIntentos(req, false);
    if (!esSoporte(b.clave)) { frenoIntentos(req, true); throw new ErrorUsuario('Contraseña de Maxsel incorrecta', 401); }
    const sello = fechaLocal(new Date()) + '_' + horaLocal(new Date()).replace(/:/g, '');
    crearRespaldo(path.join(BACKUP_DIR, 'antes_de_reiniciar_' + sello + '.db'));
    const cuenta = t => uno(`SELECT COUNT(*) n FROM ${t}`).n;
    const r = { consumos: cuenta('consumos'), ventas: cuenta('ventas'), turnos: cuenta('turnos') };
    transaccion(() => {
      if (!b.productos) { // lo vendido regresa al inventario
        for (const v of todos('SELECT items FROM ventas')) for (const it of JSON.parse(v.items || '[]')) ejecutar('UPDATE productos SET stock=stock+? WHERE id=? AND controlStock=1', Number(it.cant) || 0, Number(it.id));
      }
      for (const t of ['consumos', 'ventas', 'turnos', 'movimientos', 'vales']) ejecutar(`DELETE FROM ${t}`);
      if (b.empleados) ejecutar('DELETE FROM empleados');
      if (b.productos) ejecutar('DELETE FROM productos');
      const tablas = ['consumos', 'ventas', 'turnos', 'movimientos', 'vales'].concat(b.productos ? ['productos'] : []);
      try { ejecutar(`DELETE FROM sqlite_sequence WHERE name IN (${tablas.map(() => '?').join(',')})`, ...tablas); } catch (e) { /* sin folios guardados */ }
    });
    log(`Sistema reiniciado por Maxsel: ${r.consumos} consumos, ${r.ventas} ventas y ${r.turnos} turnos borrados` + (b.empleados ? ', también empleados' : '') + (b.productos ? ', también productos' : '') + '. Respaldo: antes_de_reiniciar_' + sello + '.db');
    return { ok: true, ...r, respaldo: 'antes_de_reiniciar_' + sello + '.db' };
  },
  'POST /api/admin/respaldo/crear': (req) => { soloAdmin(req); respaldoDiario(true); return { ok: true }; },
  'POST /api/admin/respaldo/restaurar-guardado': (req, b) => {
    soloAdmin(req);
    const nombre = path.basename(String(b.nombre || ''));
    const f = path.join(BACKUP_DIR, nombre);
    if (!nombre.endsWith('.db') || !fs.existsSync(f)) throw new ErrorUsuario('No existe ese respaldo');
    restaurarDesde(f);
    return { ok: true };
  }
};

// Rutas especiales (archivos)
async function rutaEspecial(req, res, url) {
  // Acceso directo (.url) para poner en el escritorio de la computadora de la tienda
  if (req.method === 'GET' && url.pathname === '/acceso-directo.url') {
    const ip = /^[\d.]+$/.test(url.searchParams.get('ip') || '') ? url.searchParams.get('ip') : 'localhost';
    const txt = `[InternetShortcut]\r\nURL=http://${ip}:${PORT}/\r\nIconIndex=0\r\nIconFile=http://${ip}:${PORT}/favicon.ico\r\n`;
    res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Disposition': 'attachment; filename="Maxsel Comedores Industriales.url"' });
    res.end(txt); return true;
  }
  if (req.method === 'GET' && url.pathname === '/api/admin/respaldo/descargar') {
    if (!pinAdminOk(url.searchParams.get('pin'))) { send(res, 401, { error: 'No autorizado' }); return true; }
    const tmp = path.join(DATA_DIR, 'descarga_temporal.db');
    crearRespaldo(tmp);
    const nombre = 'Respaldo_Comedor_' + fechaLocal(new Date()) + '_' + horaLocal(new Date()).replace(/:/g, '') + '.db';
    res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Disposition': `attachment; filename="${nombre}"`, 'Content-Length': fs.statSync(tmp).size });
    fs.createReadStream(tmp).pipe(res).on('finish', () => { try { fs.unlinkSync(tmp); } catch (e) {} });
    return true;
  }
  if (req.method === 'POST' && url.pathname === '/api/admin/respaldo/restaurar') {
    try {
      soloAdmin(req);
      const buf = await readBody(req, 2e9, true);
      if (!esSQLite(buf)) throw new ErrorUsuario('Ese archivo no es un respaldo del sistema (debe terminar en .db)');
      restaurarDesde(buf);
      send(res, 200, { ok: true });
    } catch (e) { send(res, e.code || 500, { error: e.message }); }
    return true;
  }
  return false;
}

// ---------- Archivos de la pantalla ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css', '.png': 'image/png', '.ico': 'image/x-icon', '.svg': 'image/svg+xml' };
function servirArchivo(req, res, pathname) {
  let file = pathname === '/' ? '/index.html' : pathname;
  file = path.normalize(path.join(PUBLIC_DIR, file));
  if (!file.startsWith(PUBLIC_DIR)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('No encontrado'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
}

function abrirNavegador() {
  const { exec } = require('child_process');
  if (process.platform === 'win32') exec('cmd /c start "" "http://localhost:' + PORT + '"');
}

// ---------- Arranque ----------
try { abrirDB(); }
catch (e) {
  console.error('\n  ERROR AL ABRIR LA BASE DE DATOS: ' + e.message);
  console.error('  Puede restaurar un respaldo copiando un archivo de "datos\\respaldos" sobre "datos\\comedor.db".\n');
  setTimeout(() => process.exit(1), 60000);
  throw e;
}
revisarLicencia();
if (!LICENCIA.activa) log('SISTEMA SIN LICENCIA. Código de equipo: ' + codigoEquipo());
mantenimiento();
setInterval(mantenimiento, 30 * 60 * 1000);
anotarActualizacion();
// Revisa solo si hay versión nueva (al minuto y medio de arrancar y cada 6 horas, si hay internet) para avisar en Administración
const revisarActualizacion = () => { if (LICENCIA.activa) versionDisponible().catch(() => {}); };
setTimeout(revisarActualizacion, 90 * 1000).unref();
setInterval(revisarActualizacion, 6 * 60 * 60 * 1000).unref();
setInterval(revisarLicencia, 60 * 60 * 1000);
iniciarServidorNube();
setTimeout(revisarNube, 20 * 1000).unref();
setInterval(revisarNube, 30 * 60 * 1000).unref();

const servidor = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname.startsWith('/api/admin/respaldo') && !LICENCIA.activa) return send(res, 402, { error: 'Sin licencia', sinLicencia: true });
    const mod = moduloDeRuta(url.pathname);   // módulos vendidos aparte (Gastos / Asistencia) que la licencia no incluye
    if (mod && !moduloActivo(mod)) return send(res, 403, { error: SIN_MODULO(mod), modulo: mod });
    if (await rutaEspecial(req, res, url)) return;
    if (LICENCIA.activa && await manejarMonitor(req, res, url)) return;
    const handler = rutas[req.method + ' ' + url.pathname];
    if (url.pathname.startsWith('/api/') && !LICENCIA.activa && !['/api/ping', '/api/licencia/estado', '/api/licencia/activar', '/api/info'].includes(url.pathname))
      return send(res, 402, { error: 'El sistema no tiene licencia activa. ' + (LICENCIA.motivo || ''), sinLicencia: true });
    if (!handler) return servirArchivo(req, res, url.pathname);
    const body = req.method === 'POST' ? await readBody(req) : {};
    send(res, 200, await handler(req, body, Object.fromEntries(url.searchParams)));
  } catch (e) {
    if (e instanceof ErrorUsuario) return send(res, e.code, { error: e.message });
    log('Error: ' + (e.stack || e.message));
    send(res, 500, { error: 'Error interno: ' + e.message });
  }
});
servidor.keepAliveTimeout = 65000;
servidor.on('error', e => {
  if (e.code === 'EADDRINUSE') {
    // ¿Es nuestro sistema el que ya está abierto?
    http.get('http://127.0.0.1:' + PORT + '/api/ping', r => {
      log('El sistema ya estaba abierto. Abriendo el navegador...'); abrirNavegador(); setTimeout(() => process.exit(0), 1500);
    }).on('error', () => {
      console.error('\n  OTRO PROGRAMA ESTÁ USANDO EL PUERTO ' + PORT + '. Cierre ese programa o reinicie la computadora.\n');
      setTimeout(() => process.exit(1), 60000);
    });
  } else console.error(e);
});
process.on('uncaughtException', e => log('Error inesperado (el sistema sigue funcionando): ' + (e.stack || e.message)));
function apagar() { log('Cerrando el sistema...'); try { db.exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (e) {} cerrarDB(); process.exit(0); }
process.on('SIGINT', apagar); process.on('SIGTERM', apagar);

servidor.listen(PORT, '0.0.0.0', () => {
  if (process.env.NO_ABRIR !== '1') abrirNavegador();
  console.log('==============================================');
  console.log('  SISTEMA DE COMEDOR INDUSTRIAL v' + VERSION + ' - ENCENDIDO');
  console.log('==============================================');
  console.log('  En ESTA computadora abra:  http://localhost:' + PORT);
  Object.values(os.networkInterfaces()).flat().filter(i => i && i.family === 'IPv4' && !i.internal)
    .forEach(i => console.log('  En la OTRA computadora abra:  http://' + i.address + ':' + PORT));
  console.log('');
  console.log('  Código de equipo (para la licencia): ' + codigoEquipo());
  console.log('  Licencia: ' + (LICENCIA.activa ? 'ACTIVA - ' + LICENCIA.cliente + (LICENCIA.expira ? ' (vence ' + LICENCIA.expira + ')' : ' (permanente)') : 'NO ACTIVADA'));
  console.log('');
  console.log('  NO CIERRE ESTA VENTANA mientras se use el sistema.');
  console.log('  (puede minimizarla)');
  console.log('==============================================');
});
