// Servidor de Maxsel Hotel. Se abre en el navegador: http://localhost:3050
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';
import { execFile } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import zlib from 'node:zlib';
import https from 'node:https';
import { DatabaseSync } from 'node:sqlite';
import { db as dbMain, DATA_DIR, IMPORT_PENDIENTE, SE_IMPORTO } from './db.js';
import { all, get, run, tx, cfg, cfgTodo, setCfg, CONFIG_DEFAULT, hoy, ahora, aFecha, salidaPrevista, r2, hashPass, checkPass, siguienteFolio, respaldar, RESPALDOS_DIR, FOTOS_DIR, CONTRATO_BASE } from './db.js';
import { PERMISOS, PERMISOS_ROL, permisosDe, limpiarPermisos } from './permisos.js';
import { imprimirOps, abrirCajon, listarImpresoras, hayImpresora } from './impresora.js';
import { estadoNube, cambiarFunnel } from './nube.js';
import { LICENCIA, revisarLicencia, estadoLicencia, activarLicencia, codigoEquipo, MODO_DESARROLLO, moduloActivo, NOMBRE_MODULO, nubeLicencia } from './licencia2.js';

const DIR = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(DIR, 'public');
const PUERTO = Number(process.env.PORT || 3050);
export const PRODUCTO = 'Maxsel Hotel';
const VERSION = '1.21';
const METODOS = ['efectivo', 'dolares', 'tarjeta', 'transferencia'];
const METODOS_GASTO = ['efectivo', 'tarjeta', 'transferencia'];
const EN_CAJA = ['efectivo', 'dolares'];
const MODALIDADES = ['rato', 'noche', 'dia', 'semana', 'mes'];
const NOMBRE_MOD = { rato: 'rato', noche: 'noche', dia: 'día', semana: 'semana', mes: 'mes' };
const AMENIDADES = ['wifi', 'tv', 'ac', 'ventilador', 'agua', 'cocina', 'parrilla', 'refri', 'micro', 'minibar', 'jacuzzi', 'estacionamiento', 'lavadora', 'balcon', 'mascotas'];
const CLASES = ['habitacion', 'departamento', 'local'];
const CAMAS = ['individual', 'matrimonial', 'queen', 'king', 'litera', 'sofacama'];

class ErrorUsuario extends Error { constructor(m, status = 400) { super(m); this.status = status; } }

// ---------- Utilidades HTTP ----------
function enviar(res, status, obj, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(obj));
}
function leerCuerpo(req, max = 30 * 1024 * 1024) {
  return new Promise((ok, mal) => {
    const chunks = []; let n = 0;
    req.on('data', (c) => { n += c.length; if (n > max) { mal(new ErrorUsuario('Datos demasiado grandes', 413)); req.destroy(); } else chunks.push(c); });
    req.on('end', () => ok(Buffer.concat(chunks))); req.on('error', mal);
  });
}
const cookies = (req) => Object.fromEntries(String(req.headers.cookie || '').split(';').map((c) => c.trim().split('=')).filter((p) => p[0]));
const num = (v) => r2(Number(v) || 0);
const ent = (v, min = 0) => Math.max(min, Math.floor(Number(v) || 0));
const txt = (v, max = 200) => (v === undefined || v === null ? null : String(v).trim().slice(0, max) || null);
const ipDe = (req) => (req.desdeInternet ? String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'internet' : String(req.socket.remoteAddress || '').replace(/^::ffff:/, ''));

// Red local, Tailscale (100.64.0.0/10) y la propia computadora
function ipPrivada(ip) {
  // 1.18: la red de Tailscale (100.64.x.x / fd7a:115c:a1e0::) ya no entra directo; desde fuera solo por Funnel
  if (/^fd7a:115c:a1e0:/i.test(ip)) return false;
  if (ip === '::1' || ip.startsWith('127.') || ip.startsWith('10.') || ip.startsWith('192.168.') || /^fe80:|^fd/i.test(ip)) return true;
  const m = /^172\.(\d+)\./.exec(ip); if (m && +m[1] >= 16 && +m[1] <= 31) return true;
  return false;
}

const rutas = [];
const ruta = (metodo, patron, rol, fn) => rutas.push({ metodo, re: new RegExp('^' + patron.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), rol, fn });
// Permiso que pide cada ruta: null = sin sesión · 'todos' = cualquier usuario · 'sesion' = ver (todos menos mantenimiento)
// 'vermant' = ver el panel de mantenimiento · 'mant' = reportar o atender mantenimiento · cualquier otro = clave de permisos.js
function autorizado(u, rol) {
  if (rol === 'todos' || rol === 'vermant') return true;
  if (rol === 'sesion') return !['mantenimiento', 'limpieza'].includes(u.rol);
  if (rol === 'mant') return u.perm.has('mant_reportar') || u.perm.has('mant_atender');
  return u.perm.has(rol);
}
const TEXTO_PERMISO = Object.fromEntries(PERMISOS.map((x) => [x.clave, x.texto]));

// ---------- Licencia ----------
ruta('GET', '/api/licencia/estado', null, () => ({ ...estadoLicencia(), producto: PRODUCTO, version: VERSION }));
ruta('POST', '/api/licencia/activar', null, ({ body }) => { try { return activarLicencia(body.clave); } catch (e) { throw new ErrorUsuario(e.message); } });
const SIN_LICENCIA_OK = new Set(['/api/licencia/estado', '/api/licencia/activar']);
// Módulos que se venden aparte (se activan en la licencia): qué rutas le pertenecen a cada uno
const RUTAS_MODULO = [
  ['gastos', /^\/api\/(gastos|gastos-fijos|cuentas-pagar|proveedores|empleados|nomina)(\/|$)/],
  ['asistencia', /^\/api\/(asistencia|huella|festivos|incidencias|relojes)(\/|$)/],
];
const moduloDeRuta = (r0) => RUTAS_MODULO.find(([, re]) => re.test(r0))?.[0] || null;
const SIN_MODULO = (k) => `El módulo de ${NOMBRE_MODULO[k] || k} no está incluido en la licencia de este negocio. Para activarlo comuníquese con Maxsel.`;

// ---------- Sesión ----------
const intentos = new Map(); // ip -> {n, hasta}
ruta('POST', '/api/login', null, ({ body, res, req }) => {
  const ip = ipDe(req), it = intentos.get(ip) || { n: 0, hasta: 0 };
  if (it.hasta > Date.now()) throw new ErrorUsuario('Demasiados intentos. Espere 10 minutos.', 429);
  const u = get('SELECT * FROM usuarios WHERE usuario=? AND activo=1', txt(body.usuario)?.toLowerCase());
  if (!u || !checkPass(body.password || '', u.pass_hash)) {
    it.n++; if (it.n >= 8) { it.hasta = Date.now() + 10 * 60000; it.n = 0; } intentos.set(ip, it);
    throw new ErrorUsuario('Usuario o contraseña incorrectos', 401);
  }
  intentos.delete(ip);
  if (req.desdeInternet && !['admin', 'gerente', 'monitor'].includes(u.rol)) throw new ErrorUsuario('Desde fuera del hotel solo pueden entrar usuarios de tipo Administrador, Gerente o Monitoreo.', 403);
  const token = crypto.randomBytes(24).toString('hex');
  run('INSERT INTO sesiones(token,usuario_id,creado,ip) VALUES(?,?,?,?)', token, u.id, ahora(), ip);
  res.setHeader('Set-Cookie', `htl_s=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=2592000${req.desdeInternet ? '; Secure' : ''}`);
  return { id: u.id, nombre: u.nombre, rol: u.rol };
});
// 1.18: clave de soporte de Maxsel (igual que Maxsel Tech y Abarrotes). Solo se guarda la huella, nunca el texto.
const SUPER_HASH = '27486342e248a68acb426e94ae242e3483785c78fac2f971b602f09771629cfa';
const esClaveMaxsel = (pw) => !!pw && crypto.timingSafeEqual(Buffer.from(crypto.createHash('sha256').update('maxsel-super|' + String(pw)).digest('hex')), Buffer.from(SUPER_HASH));
// 1.18: ¿Olvidó su contraseña? Un administrador (o Maxsel con su clave de soporte) le pone una nueva
const intentosRec = new Map();
ruta('POST', '/api/recuperar-password', null, ({ body, req }) => {
  if (req.desdeInternet) throw new ErrorUsuario('Esto solo se puede hacer en la computadora del hotel', 403);
  const ip = ipDe(req), it = intentosRec.get(ip) || { n: 0, hasta: 0 };
  if (it.hasta > Date.now()) throw new ErrorUsuario('Demasiados intentos. Espere 15 minutos.', 429);
  const u = get('SELECT * FROM usuarios WHERE usuario=? AND activo=1', txt(body.usuario)?.toLowerCase());
  if (!u) throw new ErrorUsuario('No existe ese usuario (o está desactivado)');
  const nueva = String(body.nueva || '');
  if (nueva.length < 6) throw new ErrorUsuario('La contraseña nueva debe tener al menos 6 caracteres');
  const aut = String(body.autoriza || '');
  const porMaxsel = esClaveMaxsel(aut);
  const admin = porMaxsel ? null : all("SELECT * FROM usuarios WHERE rol='admin' AND activo=1").find((a) => checkPass(aut, a.pass_hash));
  if (!porMaxsel && !admin) {
    it.n++; if (it.n >= 5) { it.hasta = Date.now() + 15 * 60000; it.n = 0; } intentosRec.set(ip, it);
    throw new ErrorUsuario('La contraseña de administrador (o la clave de soporte de Maxsel) no es correcta', 401);
  }
  intentosRec.delete(ip);
  run('UPDATE usuarios SET pass_hash=? WHERE id=?', hashPass(nueva), u.id);
  run('DELETE FROM sesiones WHERE usuario_id=?', u.id);
  try { run('INSERT INTO auditoria(fecha,usuario_id,usuario,accion,ruta,detalle,ip) VALUES(?,?,?,?,?,?,?)', ahora(), admin?.id ?? null, porMaxsel ? 'Soporte Maxsel' : admin.nombre,
    `Cambió la contraseña olvidada de ${u.nombre} (${u.usuario})`, 'POST /api/recuperar-password', '{}', ip); } catch { /* nada */ }
  return { ok: true, usuario: u.usuario, nombre: u.nombre };
});
ruta('POST', '/api/logout', 'todos', ({ req, res }) => {
  run('DELETE FROM sesiones WHERE token=?', cookies(req).htl_s);
  res.setHeader('Set-Cookie', 'htl_s=; Path=/; Max-Age=0');
});
ruta('GET', '/api/yo', 'todos', ({ u, req }) => ({ remoto: !!req.desdeInternet, id: u.id, nombre: u.nombre, rol: u.rol, permisos: [...u.perm], turno: turnoAbierto(u.id) || null, hotel: cfg('hotel_nombre'), licencia: estadoLicencia(), producto: PRODUCTO, version: VERSION }));
ruta('POST', '/api/mi-password', 'todos', ({ body, u }) => {
  if (!checkPass(body.actual || '', u.pass_hash)) throw new ErrorUsuario('La contraseña actual no es correcta');
  if (String(body.nueva || '').length < 6) throw new ErrorUsuario('La nueva contraseña debe tener al menos 6 caracteres');
  run('UPDATE usuarios SET pass_hash=? WHERE id=?', hashPass(body.nueva), u.id);
});

// ---------- Usuarios ----------
const ROLES = ['admin', 'gerente', 'recepcion', 'monitor', 'mantenimiento', 'limpieza'];
const PERSONAL = ['mantenimiento', 'limpieza']; // usuarios que solo ven su panel en el celular
ruta('GET', '/api/permisos', 'todos', () => ({ lista: PERMISOS, roles: PERMISOS_ROL }));
ruta('GET', '/api/usuarios', 'usuarios', () => all('SELECT id,nombre,usuario,rol,activo,permisos,desc_max_pct,desc_max_monto FROM usuarios ORDER BY nombre')
  .map((x) => ({ ...x, personalizado: !!x.permisos && x.rol !== 'admin', permisos: permisosDe(x) })));
// Si los permisos marcados son exactamente los del tipo de usuario, no se guardan como personalizados
function permisosBody(body, rol) {
  if (rol === 'admin' || !Array.isArray(body.permisos)) return null;
  const l = limpiarPermisos(body.permisos), base = PERMISOS_ROL[rol] || [];
  if (l.length === base.length && l.every((k) => base.includes(k))) return null;
  return JSON.stringify(l);
}
ruta('POST', '/api/usuarios', 'usuarios', ({ body }) => {
  if (!txt(body.nombre) || !txt(body.usuario) || !body.password) throw new ErrorUsuario('Nombre, usuario y contraseña son obligatorios');
  if (String(body.password).length < 6) throw new ErrorUsuario('La contraseña debe tener al menos 6 caracteres');
  if (!ROLES.includes(body.rol)) throw new ErrorUsuario('Tipo de usuario inválido');
  if (get('SELECT id FROM usuarios WHERE usuario=?', txt(body.usuario).toLowerCase())) throw new ErrorUsuario('Ese nombre de usuario ya existe');
  const nu = run('INSERT INTO usuarios(nombre,usuario,pass_hash,rol,permisos) VALUES(?,?,?,?,?)', txt(body.nombre), txt(body.usuario).toLowerCase(), hashPass(body.password), body.rol, permisosBody(body, body.rol));
  run('UPDATE usuarios SET desc_max_pct=?, desc_max_monto=? WHERE id=?', Math.min(100, Math.max(0, num(body.desc_max_pct))), Math.max(0, num(body.desc_max_monto)), nu.id);
  return nu;
});
ruta('PUT', '/api/usuarios/:id', 'usuarios', ({ body, p, u }) => {
  const id = Number(p.id), a = get('SELECT * FROM usuarios WHERE id=?', id);
  if (!a) throw new ErrorUsuario('Usuario no encontrado', 404);
  if (id === u.id && (body.activo === false || (body.rol && body.rol !== 'admin'))) throw new ErrorUsuario('No puede desactivarse ni quitarse el rol de administrador a sí mismo');
  const rol = ROLES.includes(body.rol) ? body.rol : a.rol;
  run('UPDATE usuarios SET nombre=COALESCE(?,nombre), rol=?, activo=COALESCE(?,activo), permisos=? WHERE id=?', txt(body.nombre), rol, body.activo === undefined ? null : body.activo ? 1 : 0,
    body.permisos === undefined ? a.permisos : permisosBody(body, rol), id);
  if (body.desc_max_pct !== undefined || body.desc_max_monto !== undefined) run('UPDATE usuarios SET desc_max_pct=?, desc_max_monto=? WHERE id=?', Math.min(100, Math.max(0, num(body.desc_max_pct))), Math.max(0, num(body.desc_max_monto)), id);
  if (body.password) {
    if (String(body.password).length < 6) throw new ErrorUsuario('La contraseña debe tener al menos 6 caracteres');
    run('UPDATE usuarios SET pass_hash=? WHERE id=?', hashPass(body.password), id);
  }
  if (body.activo === false || body.password) run('DELETE FROM sesiones WHERE usuario_id=? AND usuario_id<>?', id, u.id);
});

// ---------- Configuración ----------
function ipsEquipo() {
  return Object.entries(os.networkInterfaces()).flatMap(([n, l]) => (l || []).filter((i) => i.family === 'IPv4' && !i.internal).map((i) => ({ ip: i.address, nombre: n, tailscale: /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(i.address) || /tailscale/i.test(n) })));
}
// 1.18 Monitoreo desde el teléfono: solo por Tailscale Funnel (igual que Maxsel Tech)
const PUERTO_NUBE = Number(process.env.PUERTO_FUNNEL) || PUERTO + 1;
const soloEnHotel = (req) => { if (req.desdeInternet) throw new ErrorUsuario('Esto solo se puede hacer en la computadora del hotel.', 403); };
// 1.19: el monitoreo desde el teléfono viene en la licencia (póliza anual) y se apaga solo al vencer
const SIN_POLIZA = 'El monitoreo desde el teléfono es parte de la póliza anual de mantenimiento y no está activo en esta licencia. Para activarlo o renovarlo comuníquese con Maxsel: WhatsApp 664 337 5433.';
ruta('GET', '/api/nube', 'config', async ({ req }) => {
  soloEnHotel(req);
  const lic = nubeLicencia();
  if (!lic.activa) return { licencia: lic };
  return { ...(await estadoNube(PUERTO_NUBE)), licencia: lic };
});
ruta('POST', '/api/nube/funnel', 'config', async ({ req, body }) => {
  soloEnHotel(req);
  if (body.activar && !nubeLicencia().activa) throw new ErrorUsuario(SIN_POLIZA, 402);
  const r = await cambiarFunnel(!!body.activar, PUERTO_NUBE);
  if (r.error) throw new ErrorUsuario(r.error);
  if (r.habilitar) return r;
  return { ...(await estadoNube(PUERTO_NUBE)), licencia: nubeLicencia() };
});
async function revisarPoliza() { // si venció la póliza, se quita Funnel de esta computadora
  try {
    if (nubeLicencia().activa) return;
    const e = await estadoNube(PUERTO_NUBE);
    if (e.funnel?.activo) { await cambiarFunnel(false, PUERTO_NUBE); console.log('Monitoreo remoto desactivado: la póliza no está activa'); }
    run('DELETE FROM sesiones WHERE ip NOT LIKE \'10.%\' AND ip NOT LIKE \'192.168.%\' AND ip NOT LIKE \'172.%\' AND ip NOT LIKE \'127.%\' AND ip NOT LIKE \'::1\'');
  } catch (e) { console.error('Revisar póliza:', e.message); }
}
setTimeout(revisarPoliza, 20000); setInterval(revisarPoliza, 30 * 60000);
ruta('GET', '/api/config', 'todos', () => ({ ...cfgTodo(), _contrato_base: CONTRATO_BASE, _clasif_base: CONFIG_DEFAULT.gastos_clasificacion, _ips: ipsEquipo(), _puerto: PUERTO, _amenidades: AMENIDADES, _camas: CAMAS }));
// 1.8 El servicio de limpieza es un producto de tipo servicio en la tienda (se vende aparte o se carga a la habitación)
function servicioLimpieza() {
  const precio = num(cfg('cuota_limpieza')), ya = get("SELECT * FROM productos WHERE codigo='SERV-LIMPIEZA'");
  if (ya) run('UPDATE productos SET precio=CASE WHEN ?>0 THEN ? ELSE precio END, activo=CASE WHEN ?>0 THEN 1 ELSE activo END, servicio=1 WHERE id=?', precio, precio, precio, ya.id);
  else if (precio > 0) run("INSERT INTO productos(codigo,nombre,costo,precio,existencia,minimo,area,servicio) VALUES('SERV-LIMPIEZA','Servicio de limpieza',0,?,0,0,'Servicios',1)", precio);
}
try { servicioLimpieza(); } catch (e) { console.error('Servicio de limpieza:', e.message); }
ruta('PUT', '/api/config', 'config', ({ body }) => {
  delete body.ticket_logo_maxsel; delete body.deposito_plazo_desde; delete body.upd_disponible; // el logo de Maxsel al final del ticket es obligatorio
  for (const k of Object.keys(CONFIG_DEFAULT)) if (body[k] !== undefined) setCfg(k, txt(body[k], k === 'ticket_logo' ? 200000 : ['contrato_clausulas', 'gastos_clasificacion', 'multas_lista', 'unidades_negocio', 'tienda_areas', 'maxsel_contacto', 'aviso_privacidad'].includes(k) ? 60000 : 300) ?? '');
  if (body.permitir_internet !== undefined) setCfg('permitir_internet', body.permitir_internet ? '1' : '0');
  if (body.cuota_limpieza !== undefined) servicioLimpieza();
});

// ---------- Habitaciones ----------
function limpiarHab(b, sinPrecio = false) {
  const camas = {};
  for (const c of CAMAS) { const n = ent(b.camas?.[c]); if (n) camas[c] = Math.min(n, 20); }
  const d = {
    numero: txt(b.numero, 20), nombre: txt(b.nombre, 60), clase: CLASES.includes(b.clase) ? b.clase : 'habitacion', piso: txt(b.piso, 20) || '', unidad: txt(b.unidad, 60),
    camas: JSON.stringify(camas), recamaras: Math.min(ent(b.recamaras, 1), 20), banos: Math.min(ent(b.banos, 0), 20), capacidad: Math.min(ent(b.capacidad, 1), 50),
    amenidades: JSON.stringify((Array.isArray(b.amenidades) ? b.amenidades : []).filter((a) => AMENIDADES.includes(a))),
    precio_rato: num(b.precio_rato), precio_noche: num(b.precio_noche), precio_dia: num(b.precio_dia), precio_semana: num(b.precio_semana), precio_mes: num(b.precio_mes),
  };
  if (!d.numero) throw new ErrorUsuario('Escriba el número o nombre corto de la habitación');
  if (!sinPrecio && !(d.precio_rato > 0 || d.precio_noche > 0 || d.precio_dia > 0 || d.precio_semana > 0 || d.precio_mes > 0)) throw new ErrorUsuario('Ponga al menos un precio (rato, noche, día, semana o mes)');
  return d;
}
const habJSON = (h) => h && ({ ...h, camas: JSON.parse(h.camas || '{}'), amenidades: JSON.parse(h.amenidades || '[]') });
// ---------- Habitaciones en lote (1.3): crear o importar muchas de golpe y editar varias a la vez ----------
const HAB_COLS = 'nombre=?,clase=?,piso=?,camas=?,recamaras=?,banos=?,capacidad=?,amenidades=?,precio_rato=?,precio_noche=?,precio_dia=?,precio_semana=?,precio_mes=?,unidad=?';
const habVals = (d) => [d.nombre, d.clase, d.piso, d.camas, d.recamaras, d.banos, d.capacidad, d.amenidades, d.precio_rato, d.precio_noche, d.precio_dia, d.precio_semana, d.precio_mes, d.unidad];
// Precio fijo de visita por habitación: solo gerente o administrador (permiso "autorizar")
function fijarVisita(id, b, u) {
  if (b.precio_visita === undefined || !u?.perm?.has('autorizar')) return;
  const v = b.precio_visita === '' || b.precio_visita === null ? null : num(b.precio_visita);
  run('UPDATE habitaciones SET precio_visita=? WHERE id=?', v, id);
}
ruta('POST', '/api/habitaciones/lote', 'habitaciones', ({ body, u }) => tx(() => {
  const lista = Array.isArray(body.habitaciones) ? body.habitaciones : [];
  if (!lista.length) throw new ErrorUsuario('No hay habitaciones para crear');
  if (lista.length > 2000) throw new ErrorUsuario('Máximo 2000 habitaciones por vez');
  const actualizar = body.existentes === 'actualizar', res = { creadas: 0, actualizadas: 0, saltadas: [] }, vistos = new Set();
  lista.forEach((b, i) => {
    let d; try { d = limpiarHab(b, true); } catch (e) { throw new ErrorUsuario(`Renglón ${i + 1}: ${e.message}`); }
    const k = d.numero.toLowerCase();
    if (vistos.has(k)) throw new ErrorUsuario(`La habitación ${d.numero} viene repetida en la lista`);
    vistos.add(k);
    const ya = get('SELECT id FROM habitaciones WHERE numero=? AND activo=1', d.numero);
    if (ya) {
      if (!actualizar) { res.saltadas.push(d.numero); return; }
      run(`UPDATE habitaciones SET ${HAB_COLS} WHERE id=?`, ...habVals(d), ya.id); fijarVisita(ya.id, b, u); res.actualizadas++; return;
    }
    const viejo = get('SELECT id FROM habitaciones WHERE numero=? AND activo=0', d.numero);
    let nid;
    if (viejo) { run(`UPDATE habitaciones SET ${HAB_COLS},estado='libre',nota=NULL,activo=1 WHERE id=?`, ...habVals(d), viejo.id); nid = viejo.id; }
    else nid = run(`INSERT INTO habitaciones(numero,nombre,clase,piso,camas,recamaras,banos,capacidad,amenidades,precio_rato,precio_noche,precio_dia,precio_semana,precio_mes,unidad) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, d.numero, ...habVals(d)).id;
    fijarVisita(nid, b, u);
    res.creadas++;
  });
  return res;
}));
ruta('PUT', '/api/habitaciones/lote', 'habitaciones', ({ body, u }) => tx(() => {
  const lista = Array.isArray(body.habitaciones) ? body.habitaciones : [];
  const nums = new Map();
  for (const b of lista) {
    const id = Number(b.id), d = limpiarHab(b, true);
    if (!get('SELECT id FROM habitaciones WHERE id=? AND activo=1', id)) throw new ErrorUsuario('La habitación ' + d.numero + ' ya no existe');
    if (nums.has(d.numero.toLowerCase())) throw new ErrorUsuario('El número ' + d.numero + ' está repetido');
    nums.set(d.numero.toLowerCase(), id);
  }
  for (const b of lista) {
    const id = Number(b.id), d = limpiarHab(b, true);
    const otro = get('SELECT id FROM habitaciones WHERE numero=? AND id<>? AND activo=1', d.numero, id);
    if (otro && !lista.some((x) => Number(x.id) === otro.id)) throw new ErrorUsuario('Ya existe la habitación ' + d.numero);
    run(`UPDATE habitaciones SET numero=?,${HAB_COLS} WHERE id=?`, '~' + id + '~' + d.numero, ...habVals(d), id); // número temporal por si se intercambian
    fijarVisita(id, b, u);
  }
  for (const b of lista) run("UPDATE habitaciones SET numero=substr(numero, instr(substr(numero,2),'~')+2) WHERE id=? AND numero LIKE '~%'", Number(b.id));
  return { guardadas: lista.length };
}));
ruta('GET', '/api/habitaciones', 'vermant', () => all('SELECT * FROM habitaciones WHERE activo=1').map(habJSON));
ruta('POST', '/api/habitaciones', 'habitaciones', ({ body, u }) => {
  const d = limpiarHab(body);
  if (get('SELECT id FROM habitaciones WHERE numero=? AND activo=1', d.numero)) throw new ErrorUsuario('Ya existe la habitación ' + d.numero);
  const viejo = get('SELECT id FROM habitaciones WHERE numero=? AND activo=0', d.numero);
  if (viejo) { run(`UPDATE habitaciones SET ${HAB_COLS},estado='libre',nota=NULL,activo=1 WHERE id=?`, ...habVals(d), viejo.id); fijarVisita(viejo.id, body, u); return { id: viejo.id }; }
  const r = run(`INSERT INTO habitaciones(numero,nombre,clase,piso,camas,recamaras,banos,capacidad,amenidades,precio_rato,precio_noche,precio_dia,precio_semana,precio_mes,unidad) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, d.numero, ...habVals(d));
  fijarVisita(r.id, body, u); return r;
});
ruta('PUT', '/api/habitaciones/:id', 'habitaciones', ({ body, p, u }) => {
  const id = Number(p.id), d = limpiarHab(body);
  if (get('SELECT id FROM habitaciones WHERE numero=? AND id<>? AND activo=1', d.numero, id)) throw new ErrorUsuario('Ya existe la habitación ' + d.numero);
  run(`UPDATE habitaciones SET numero=?,${HAB_COLS} WHERE id=?`, d.numero, ...habVals(d), id);
  fijarVisita(id, body, u);
});
ruta('DELETE', '/api/habitaciones/:id', 'habitaciones', ({ p }) => {
  const h = get('SELECT * FROM habitaciones WHERE id=?', Number(p.id));
  if (!h) throw new ErrorUsuario('No existe', 404);
  if (h.estado === 'ocupada') throw new ErrorUsuario('No se puede borrar una habitación ocupada');
  run('UPDATE habitaciones SET activo=0 WHERE id=?', h.id); // se conserva para el historial
});
ruta('POST', '/api/habitaciones/:id/estado', 'estados', ({ body, p, u }) => {
  const h = get('SELECT * FROM habitaciones WHERE id=? AND activo=1', Number(p.id));
  if (!h) throw new ErrorUsuario('No existe', 404);
  if (!['libre', 'limpieza', 'mant'].includes(body.estado)) throw new ErrorUsuario('Estado inválido');
  if (h.estado === 'ocupada') throw new ErrorUsuario('La habitación está ocupada. Primero registre la salida del huésped.');
  run('UPDATE habitaciones SET estado=?, nota=? WHERE id=?', body.estado, body.estado === 'mant' ? txt(body.nota) : null, h.id);
  run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), h.id, body.estado, txt(body.nota), u.id);
  // Mandar a mantenimiento crea el reporte para el personal de mantenimiento
  if (body.estado === 'mant' && !get("SELECT id FROM mantenimiento WHERE habitacion_id=? AND estado<>'terminado' AND COALESCE(tipo,'reparacion')<>'limpieza'", h.id))
    nuevoReporte({ habitacion_id: h.id, titulo: txt(body.nota, 120) || 'Revisión general', prioridad: 'normal' }, u.id);
});

// ---------- Estancias (registro del huésped en la habitación) ----------
const consumo = (eid) => get('SELECT COALESCE(SUM(importe),0) t FROM cargos WHERE estancia_id=?', eid).t;
const pagado = (eid) => get('SELECT COALESCE(SUM(monto),0) t FROM pagos WHERE estancia_id=?', eid).t;
function resumenEstancia(e) {
  if (!e) return null;
  const c = consumo(e.id), pg = pagado(e.id);
  const dep = get(`SELECT COALESCE(SUM(CASE WHEN tipo='recibido' THEN monto END),0) rec, COALESCE(SUM(CASE WHEN tipo='devuelto' THEN monto END),0) dev,
    COALESCE(SUM(CASE WHEN tipo='retenido' THEN monto END),0) ret FROM depositos WHERE estancia_id=?`, e.id);
  return { ...e, consumo: r2(c), pagado: r2(pg), saldo: r2(e.total_hospedaje + c - pg), vencida: e.activa && aFecha(e.salida_prevista) < new Date(),
    deposito: r2(dep.rec), deposito_devuelto: r2(dep.dev), deposito_retenido: r2(dep.ret), deposito_saldo: r2(dep.rec - dep.dev - dep.ret) };
}
const precioDe = (h, m) => h['precio_' + m] || 0;
// Registro de cada renta, extensión o cambio (para contar ratos, noches, días, semanas y meses en el corte)
function anotarRenta(eid, uid, modalidad, cantidad, precio, tipo) {
  run('INSERT INTO rentas(estancia_id,fecha,turno_id,usuario_id,modalidad,cantidad,precio,importe,tipo) VALUES(?,?,?,?,?,?,?,?,?)',
    eid, ahora(), turnoAbierto(uid)?.id ?? null, uid, modalidad, cantidad, precio, r2(precio * cantidad), tipo);
}
// ---------- Caja: turnos, dólares y cajón ----------
const turnoAbierto = (uid) => get("SELECT * FROM turnos WHERE usuario_id=? AND estado='abierto' ORDER BY id DESC LIMIT 1", uid);
function turnoCaja(uid) {
  const t = turnoAbierto(uid);
  if (!t && cfg('exigir_turno') !== '0') throw new ErrorUsuario('Primero abra su turno de caja (botón "Abrir turno" arriba).');
  return t || null;
}
const tcDe = (t) => (t?.tipo_cambio > 0 ? t.tipo_cambio : num(cfg('tipo_cambio')) || 18);
let cajonPendiente = false;
const pedirCajon = () => { cajonPendiente = true; };
// Reparte un cobro entre formas de pago: pesos en efectivo, dólares, tarjeta y transferencia.
// Lo que sobra se entrega de cambio en pesos (primero se descuenta de los pesos recibidos, luego de los dólares).
function repartir(monto, partes, tc) {
  const ef = Math.max(0, num(partes.efectivo)), usd = Math.max(0, num(partes.usd)), ta = Math.max(0, num(partes.tarjeta)), tr = Math.max(0, num(partes.transferencia));
  const eq = r2(usd * tc), total = r2(ef + eq + ta + tr);
  if (total + 0.009 < monto) throw new ErrorUsuario(`Faltan $${(monto - total).toFixed(2)}: recibió $${total.toFixed(2)}${usd ? ` (US$${usd} × ${tc} = $${eq.toFixed(2)})` : ''} y el cobro es de $${monto.toFixed(2)}`);
  if (ta + tr > monto + 0.009) throw new ErrorUsuario('Lo cobrado con tarjeta y transferencia no puede pasar del total');
  const cambio = r2(total - monto), c1 = Math.min(cambio, ef), c2 = r2(cambio - c1);
  const filas = [];
  if (ef > 0 && ef - c1 > 0.004) filas.push({ metodo: 'efectivo', monto: r2(ef - c1), usd: 0, cambio: 0 });
  if (usd > 0) filas.push({ metodo: 'dolares', monto: r2(eq - c2), usd, cambio: c2 });
  if (ta > 0) filas.push({ metodo: 'tarjeta', monto: ta, usd: 0, cambio: 0 });
  if (tr > 0) filas.push({ metodo: 'transferencia', monto: tr, usd: 0, cambio: 0 });
  return { filas, cambio, usd, total };
}
// Convierte la forma de pago que manda la pantalla en partes: un solo método, dólares o "mixto" (se llenan los montos de cada método)
function partesDe(monto, metodo, usd, partes, tc) {
  if (metodo === 'mixto') {
    const p = partes || {};
    // Si no se escribió nada en ninguna forma, se toma como pago exacto en efectivo
    if (!(num(p.efectivo) > 0 || num(p.usd) > 0 || num(p.tarjeta) > 0 || num(p.transferencia) > 0)) return { efectivo: monto };
    return p;
  }
  if (!METODOS.includes(metodo)) throw new ErrorUsuario('Elija la forma de pago');
  if (metodo === 'dolares') return { usd: num(usd) || r2(Math.ceil((monto / tc) * 100) / 100) };
  return { [metodo]: monto };
}
// ---------- 1.8 Cargos extra: multas, intereses moratorios, cuotas de limpieza y por mascota ----------
const TIPOS_CARGO = { multa: 'Multa', mora: 'Interés moratorio', limpieza: 'Cuota de limpieza', mascota: 'Cuota por mascota', otro: 'Otro cargo' };
const EXTRAS = Object.keys(TIPOS_CARGO);
const cargar = (eid, tipo, descripcion, importe, cantidad, uid) => run('INSERT INTO cargos(estancia_id,fecha,descripcion,cantidad,importe,tipo,usuario_id) VALUES(?,?,?,?,?,?,?)', eid, ahora(), descripcion, cantidad || 1, r2(importe), tipo, uid ?? null);
const pendienteExtra = (eid, tipo) => r2(get('SELECT COALESCE(SUM(importe),0) t FROM cargos WHERE estancia_id=? AND tipo=?', eid, tipo).t - get('SELECT COALESCE(SUM(monto),0) t FROM pagos WHERE estancia_id=? AND concepto=?', eid, tipo).t);
// 1.20: servicio de limpieza pagado por el huésped -> tarea para el personal de limpieza (no cambia el estado de la habitación)
function limpiezaPagada(e, desc, imp, nota, uid) {
  const h = get('SELECT numero FROM habitaciones WHERE id=?', e.habitacion_id);
  const d = `El huésped pagó el servicio de limpieza ($${num(imp).toFixed(2)}). La habitación ${h?.numero ?? ''} está ocupada: toque antes de entrar.` + (nota ? ' Nota: ' + nota : '');
  return run("INSERT INTO mantenimiento(folio,habitacion_id,titulo,descripcion,prioridad,estado,alta,alta_usuario,tipo,subtipo,ligado,estancia_id) VALUES(?,?,?,?,?,?,?,?,'limpieza','habitacion',0,?)",
    siguienteFolio('mant'), e.habitacion_id, 'Servicio de limpieza pagado', d, 'alta', 'pendiente', ahora(), uid, e.id).id;
}
// Cobro a la caja (hospedaje, anticipos, tienda, visitas)
function pagar(monto, metodo, concepto, estanciaId, ventaId, uid, nota, usd, partes) {
  monto = num(monto); if (!(monto > 0)) return { cambio: 0 };
  const t = turnoCaja(uid), tc = tcDe(t);
  const rp = repartir(monto, partesDe(monto, metodo, usd, partes, tc), tc);
  const modalidad = concepto === 'hospedaje' && estanciaId ? get('SELECT modalidad FROM estancias WHERE id=?', estanciaId)?.modalidad : null;
  // 1.8: los abonos y la liquidación pagan primero multas, intereses y cuotas pendientes (así cada ingreso sale en su renglón del reporte)
  const cola = concepto === 'hospedaje' && estanciaId && /^(Abono|Liquidación|Anticipo al registrar)/.test(nota || '')
    ? EXTRAS.map((k) => [k, pendienteExtra(estanciaId, k)]).filter((x) => x[1] > 0.004) : [];
  for (const f of rp.filas) {
    let resto = f.monto; const partes = [];
    while (resto > 0.004 && cola.length) { const c = cola[0], a = r2(Math.min(resto, c[1])); partes.push([c[0], a]); c[1] = r2(c[1] - a); resto = r2(resto - a); if (c[1] <= 0.004) cola.shift(); }
    if (resto > 0.004 || !partes.length) partes.push([concepto, r2(resto)]);
    partes.forEach(([con, m], i) => run('INSERT INTO pagos(fecha,monto,metodo,concepto,estancia_id,venta_id,usuario_id,nota,turno_id,usd,tc,cambio,modalidad) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
      ahora(), m, f.metodo, con, estanciaId, ventaId, uid, (con !== concepto ? TIPOS_CARGO[con] + ' · ' : '') + (nota || '') || null, t?.id ?? null, f.usd && f.monto ? r2(f.usd * m / f.monto) : 0, f.usd ? tc : 0, i === 0 ? f.cambio : 0, con === 'hospedaje' ? modalidad : null));
    if (EN_CAJA.includes(f.metodo)) pedirCajon();
  }
  return { cambio: rp.cambio, usd: rp.usd, tc, total: rp.total, filas: rp.filas };
}

const p2_ = (n) => String(n).padStart(2, '0');
const fechaHoraDe = (d) => `${d.getFullYear()}-${p2_(d.getMonth() + 1)}-${p2_(d.getDate())} ${p2_(d.getHours())}:${p2_(d.getMinutes())}:${p2_(d.getSeconds())}`;
// Nueva salida al agregar n periodos con el mismo precio. Mes se cuenta desde el inicio (para no recorrer el día de pago);
// lo demás se suma a la salida actual (respeta la hora de check out elegida).
function sumarPeriodos(e, inicio, cantTotal, n) {
  if (e.modalidad === 'mes') return salidaPrevista(inicio, 'mes', cantTotal, cfg('hora_salida'), e.hora_checkout);
  if (e.modalidad === 'rato') { const d = aFecha(e.salida_prevista); d.setMinutes(d.getMinutes() + Math.round((num(cfg('horas_rato')) || 3) * 60) * n); return fechaHoraDe(d); }
  if (e.modalidad === 'dia' && cfg('dia_24h') === '1') { const d = aFecha(e.salida_prevista); d.setDate(d.getDate() + n); return fechaHoraDe(d); }
  const d = aFecha(e.salida_prevista); d.setDate(d.getDate() + (e.modalidad === 'semana' ? 7 : 1) * n); return fechaHoraDe(d);
}
// ---------- 1.7.2 Cobro automático: si llegó la hora del check out y no se registró la salida, se carga otro periodo ----------
// (otro rato, otra noche, otro día, otra semana u otro mes al mismo precio). El cargo queda en la cuenta y se cobra al salir.
function cobrosVencidos() {
  if (cfg('cobro_auto') === '0') return 0;
  const tol = Math.max(0, num(cfg('cobro_auto_tolerancia'))) * 60000, ya = new Date();
  const turno = get("SELECT id FROM turnos WHERE estado='abierto' ORDER BY id DESC LIMIT 1")?.id ?? null;
  let total = 0;
  for (const e0 of all('SELECT * FROM estancias WHERE activa=1 AND precio>0')) {
    let e = e0, vueltas = 0;
    while (aFecha(e.salida_prevista).getTime() + tol < ya.getTime() && vueltas++ < 60) {
      tx(() => {
        const inicio = e.inicio_tramo || e.entrada, cant = e.cantidad + 1, nueva = sumarPeriodos(e, inicio, cant, 1);
        const dsc = e.desc_renueva ? r2(Math.min(e.precio, num(e.desc_periodo))) : 0; // 1.16: descuento que se repite
        run('UPDATE estancias SET cantidad=?, total_hospedaje=?, salida_prevista=?, cobros_auto=COALESCE(cobros_auto,0)+1, descuento=COALESCE(descuento,0)+? WHERE id=?', cant, r2(e.total_hospedaje + e.precio - dsc), nueva, dsc, e.id);
        run('INSERT INTO rentas(estancia_id,fecha,turno_id,usuario_id,modalidad,cantidad,precio,importe,tipo) VALUES(?,?,?,?,?,?,?,?,?)',
          e.id, ahora(), turno, e.usuario_id, e.modalidad, 1, e.precio, r2(e.precio - dsc), 'automatico');
        run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), e.habitacion_id, 'ocupada',
          `No se registró la salida a las ${e.salida_prevista.slice(11, 16)}: se cobró otro periodo (${NOMBRE_MOD[e.modalidad]}) de $${r2(e.precio).toFixed(2)}`, e.usuario_id);
      });
      e = get('SELECT * FROM estancias WHERE id=?', e.id); total++;
    }
  }
  return total;
}
// Interés moratorio: rentas por semana o mes (deptos., locales) que siguen sin pagarse N días después de generarse
function morasVencidas() {
  if (cfg('mora_activa') !== '1') return 0;
  // Solo rentas por semana o por mes (hotel por semana/mes, departamentos del callejón, otros deptos. y locales).
  // Nunca a ratos, noches ni días.
  const LARGAS = ['semana', 'mes'], gracia = Math.max(0, num(cfg('mora_dias'))) * 86400000, ya = Date.now();
  const tipo = cfg('mora_tipo') === 'fijo' ? 'fijo' : 'porcentaje', valor = num(cfg('mora_valor'));
  let n = 0;
  if (!(valor > 0)) return 0;
  for (const e of all("SELECT * FROM estancias WHERE activa=1 AND modalidad IN ('semana','mes')")) {
    // Cada renta vencida (también las que el sistema cobró solo porque no se cerró la renta) lleva su propio interés
    const vencidas = all('SELECT * FROM rentas WHERE estancia_id=? AND id>? ORDER BY id DESC', e.id, e.mora_renta_id || 0)
      .filter((x) => LARGAS.includes(x.modalidad || e.modalidad) && aFecha(x.fecha).getTime() + gracia <= ya);
    if (!vencidas.length) continue;
    tx(() => {
      // El adeudo se reparte de la renta más nueva a la más vieja (los pagos cubren primero lo más viejo)
      let resta = resumenEstancia(e).saldo;
      for (const ult of vencidas) {
        if (!(resta > 0.009)) break;
        const base = Math.min(resta, ult.importe || e.precio); resta -= base;
        const monto = tipo === 'fijo' ? valor : r2(base * valor / 100);
        if (!(monto > 0)) continue;
        cargar(e.id, 'mora', tipo === 'fijo' ? `Interés moratorio por pago tardío (${NOMBRE_MOD[ult.modalidad || e.modalidad] || 'renta'} del ${ult.fecha.slice(0, 10)})` : `Interés moratorio ${valor}% por pago tardío de ${NOMBRE_MOD[ult.modalidad || e.modalidad] || 'renta'} (${ult.fecha.slice(0, 10)}, adeudo $${base.toFixed(2)})`, monto, 1, null);
        run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), e.habitacion_id, 'ocupada', `Interés moratorio de $${monto.toFixed(2)} por renta del ${ult.fecha.slice(0, 10)} no pagada a tiempo`, null);
        n++;
      }
      run('UPDATE estancias SET mora_renta_id=? WHERE id=?', vencidas[0].id, e.id);
    });
  }
  return n;
}
setInterval(() => { try { cobrosVencidos(); morasVencidas(); } catch (err) { console.error('Cobro automático:', err.message); } }, 60 * 1000).unref();

ruta('GET', '/api/tablero', 'sesion', () => {
  try { cobrosVencidos(); morasVencidas(); sincronizarLimpieza(); } catch { /* nada */ }
  const habs = all('SELECT * FROM habitaciones WHERE activo=1').map(habJSON);
  const activas = all('SELECT * FROM estancias WHERE activa=1').map(resumenEstancia);
  const porHab = Object.fromEntries(activas.map((e) => [e.habitacion_id, e]));
  const dentro = all('SELECT habitacion_id, COUNT(*) n FROM visitantes WHERE salida IS NULL GROUP BY habitacion_id');
  const vis = Object.fromEntries(dentro.map((v) => [v.habitacion_id, v.n]));
  const mt = Object.fromEntries(all("SELECT habitacion_id, COUNT(*) n FROM mantenimiento WHERE estado<>'terminado' AND COALESCE(tipo,'reparacion')<>'limpieza' GROUP BY habitacion_id").map((x) => [x.habitacion_id, x.n]));
  return { habitaciones: habs.map((h) => ({ ...h, estancia: porHab[h.id] || null, visitantes: vis[h.id] || 0, reportes: mt[h.id] || 0 })), config: cfgTodo(), ahora: ahora() };
});

// 1.15: al registrar, solo el administrador puede poner otra fecha y hora de ingreso (huéspedes que ya estaban antes de usar el sistema, o capturas atrasadas)
function fechaIngreso(body, u) {
  const ya = ahora(); body._capturado = ya;
  const t = String(body.fecha_entrada || '').trim();
  if (!t) return ya;
  if (u.rol !== 'admin') throw new ErrorUsuario('Solo el administrador puede cambiar la fecha de ingreso');
  const mt = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{1,2}):(\d{2})/.exec(t);
  if (!mt) throw new ErrorUsuario('La fecha de ingreso no es válida');
  const d = new Date(+mt[1], +mt[2] - 1, +mt[3], +mt[4], +mt[5], 0);
  if (isNaN(d) || d.getMonth() !== +mt[2] - 1 || d.getDate() !== +mt[3]) throw new ErrorUsuario('La fecha de ingreso no es válida');
  if (d.getTime() > Date.now() + 5 * 60000) throw new ErrorUsuario('La fecha de ingreso no puede ser después de hoy. Para una llegada futura use Reservaciones.');
  if (d.getTime() < Date.now() - 400 * 86400000) throw new ErrorUsuario('La fecha de ingreso no puede ser de hace más de un año');
  const f = fechaHoraDe(d);
  return Math.abs(d.getTime() - Date.now()) < 60000 ? ya : f;
}
// 1.17: huésped que ya estaba desde antes. Se generan las rentas de cada periodo con su fecha real (no entran al corte de hoy)
// y se capturan los pagos que hizo antes de usar el sistema, con su día, cantidad y forma de pago.
function ingresoAnterior(eid, body, u) {
  const ya = Date.now(), tol = Math.max(0, num(cfg('cobro_auto_tolerancia'))) * 60000;
  let e = get('SELECT * FROM estancias WHERE id=?', eid);
  run("UPDATE rentas SET fecha=?, turno_id=NULL WHERE id=(SELECT MIN(id) FROM rentas WHERE estancia_id=?)", e.entrada, eid);
  let n = 0;
  while (e.precio > 0 && aFecha(e.salida_prevista).getTime() + tol < ya && n < 400) {
    const inicio = e.inicio_tramo || e.entrada, cant = e.cantidad + 1;
    const dsc = e.desc_renueva ? r2(Math.min(e.precio, num(e.desc_periodo))) : 0;
    run('UPDATE estancias SET cantidad=?, total_hospedaje=?, salida_prevista=?, descuento=COALESCE(descuento,0)+? WHERE id=?', cant, r2(e.total_hospedaje + e.precio - dsc), sumarPeriodos(e, inicio, cant, 1), dsc, eid);
    run('INSERT INTO rentas(estancia_id,fecha,turno_id,usuario_id,modalidad,cantidad,precio,importe,tipo) VALUES(?,?,?,?,?,?,?,?,?)', eid, e.salida_prevista, null, u.id, e.modalidad, 1, e.precio, r2(e.precio - dsc), 'anterior');
    e = get('SELECT * FROM estancias WHERE id=?', eid); n++;
  }
  // El interés moratorio solo corre de aquí en adelante (no por los meses viejos que se capturan)
  run('UPDATE estancias SET mora_renta_id=(SELECT MAX(id) FROM rentas WHERE estancia_id=?) WHERE id=?', eid, eid);
  const lista = Array.isArray(body.pagos_previos) ? body.pagos_previos.slice(0, 200) : [];
  const desde = e.entrada.slice(0, 10), hoyS = hoy();
  let total = 0;
  lista.forEach((x, i) => {
    const f = String(x.fecha || '').slice(0, 10), monto = r2(num(x.monto));
    if (!(monto > 0)) return;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(f) || isNaN(aFecha(f))) throw new ErrorUsuario(`Pago anterior ${i + 1}: escriba la fecha`);
    if (f < desde) throw new ErrorUsuario(`Pago anterior ${i + 1}: la fecha (${f}) es antes de que entrara el huésped`);
    if (f > hoyS) throw new ErrorUsuario(`Pago anterior ${i + 1}: la fecha no puede ser después de hoy`);
    const metodo = ['efectivo', 'tarjeta', 'transferencia', 'dolares'].includes(x.metodo) ? x.metodo : 'efectivo';
    run('INSERT INTO pagos(fecha,monto,metodo,concepto,estancia_id,venta_id,usuario_id,nota,turno_id,usd,tc,cambio,modalidad) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
      f + ' 12:00:00', monto, metodo, 'hospedaje', eid, null, u.id, ('Pago anterior al sistema' + (txt(x.nota, 80) ? ' · ' + txt(x.nota, 80) : '')), null, 0, 0, 0, e.modalidad);
    total = r2(total + monto);
  });
  if (n || total) run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), e.habitacion_id, 'ocupada',
    `Huésped desde ${e.entrada.slice(0, 10)}: van ${e.cantidad} periodo(s) de renta hasta hoy${total ? ` y se capturaron pagos anteriores por $${total.toFixed(2)}` : ''}`, u.id);
}
ruta('POST', '/api/estancias', 'registrar', ({ body, u }) => tx(() => {
  const h = get('SELECT * FROM habitaciones WHERE id=? AND activo=1', Number(body.habitacion_id));
  if (!h) throw new ErrorUsuario('Habitación no encontrada');
  if (h.estado !== 'libre') throw new ErrorUsuario('La habitación no está disponible');
  reservaDeHoy(h.id, body); // 1.9: habitaciones apartadas
  const huesped = txt(body.huesped, 100);
  if (!huesped) throw new ErrorUsuario('Escriba el nombre del huésped');
  const m = MODALIDADES.includes(body.modalidad) ? body.modalidad : null;
  if (!m) throw new ErrorUsuario('Elija el tipo de renta: rato, noche, día, semana o mes');
  const cant = Math.min(ent(body.cantidad, 1), 365), precio = body.precio !== undefined && body.precio !== '' ? num(body.precio) : precioDe(h, m);
  if (!(precio > 0)) throw new ErrorUsuario('Esta habitación no tiene precio por ' + NOMBRE_MOD[m]);
  revisarNoDeseado(body, u); // 1.10: clientes no deseados
  const desc = calcularDescuento(body, r2(precio * cant), u); // 1.10: descuento con límite por usuario
  const entrada = fechaIngreso(body, u), folio = siguienteFolio('estancia');
  // Hora de check out que dice el huésped (HH:MM). Rato: se toma el día de hoy o mañana a esa hora.
  const hco = /^\d{1,2}:\d{2}$/.test(String(body.hora_checkout || '')) ? String(body.hora_checkout).padStart(5, '0') : null;
  let salida = salidaPrevista(entrada, m, cant, cfg('hora_salida'), hco);
  if (hco && m === 'rato') {
    const d = aFecha(entrada), [hh, mm] = hco.split(':').map(Number); d.setHours(hh, mm, 0, 0);
    if (d <= aFecha(entrada)) d.setDate(d.getDate() + 1);
    salida = fechaHoraDe(d);
  }
  const r = run(`INSERT INTO estancias(folio,habitacion_id,huesped,telefono,identificacion,procedencia,placas,personas,modalidad,cantidad,precio,total_hospedaje,entrada,salida_prevista,notas,usuario_id,domicilio,inicio_tramo,hospedaje_previo,turno_id)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?)`, folio, h.id, huesped, txt(body.telefono, 30), txt(body.identificacion, 60), txt(body.procedencia, 80), txt(body.placas, 20),
    Math.min(ent(body.personas, 1), 50), m, cant, precio, r2(precio * cant), entrada, salida, txt(body.notas, 300), u.id, txt(body.domicilio, 200), entrada, turnoAbierto(u.id)?.id ?? null);
  if (hco && m !== 'rato') run('UPDATE estancias SET hora_checkout=? WHERE id=?', hco, r.id);

  anotarRenta(r.id, u.id, m, cant, precio, 'entrada');
  // 1.10: habitación de llegada, base de huéspedes, aviso de privacidad y descuento
  run('UPDATE estancias SET hab_inicial_id=?, huesped_id=?, aviso_privacidad=? WHERE id=?', h.id, guardarHuesped(body, entrada), body.acepto_aviso ? entrada : null, r.id);
  if (desc) {
    run('UPDATE estancias SET total_hospedaje=?, descuento=?, descuento_tipo=?, descuento_valor=?, descuento_motivo=?, descuento_usuario=? WHERE id=?', r2(precio * cant - desc.monto), desc.monto, desc.tipo, desc.valor, desc.motivo, u.id, r.id);
    run("UPDATE rentas SET importe=? WHERE id=(SELECT MAX(id) FROM rentas WHERE estancia_id=?)", r2(precio * cant - desc.monto), r.id);
    // 1.16: el descuento se repite en cada renovación (mismo tipo de renta y mismo precio) hasta que el huésped desocupa
    if (body.descuento_renueva && m !== 'rato') run('UPDATE estancias SET desc_renueva=1, desc_periodo=? WHERE id=?', r2(desc.tipo === 'pct' ? precio * desc.valor / 100 : desc.monto / cant), r.id);
  }
  if (entrada !== body._capturado) { // 1.15: el administrador cambió la fecha de ingreso
    run('UPDATE estancias SET entrada_registro=?, entrada_por=? WHERE id=?', body._capturado, u.id, r.id);
    run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', body._capturado, h.id, 'ocupada',
      `Fecha de ingreso puesta a mano por ${u.nombre}: ${entrada.slice(0, 16)} (se capturó el ${body._capturado.slice(0, 16)})`, u.id);
  }
  if (entrada !== body._capturado) ingresoAnterior(r.id, body, u); // 1.17: periodos que ya corrieron y pagos que ya hizo
  // 1.8 Cuota por mascota
  // La limpieza ya no se cobra al registrar: es un servicio de la tienda o se carga desde la cuenta (Multa o cargo)
  const nm = Math.min(ent(body.mascotas), 10);
  if (nm > 0) { run('UPDATE estancias SET mascotas=? WHERE id=?', nm, r.id); if (num(cfg('cuota_mascota')) > 0) cargar(r.id, 'mascota', `Cuota por mascota (${nm})`, num(cfg('cuota_mascota')) * nm, nm, u.id); }
  const pago = pagar(body.pago, body.metodo, 'hospedaje', r.id, null, u.id, 'Anticipo al registrar', body.usd, body.partes);
  const dep = num(body.deposito) > 0 ? recibirDeposito(r.id, body.deposito, body.metodo_deposito || body.metodo, u.id, body.usd_deposito, body.partes_deposito) : null;
  run("UPDATE habitaciones SET estado='ocupada', nota=NULL WHERE id=?", h.id);
  if (body.reservacion_id) reservaLlego(body.reservacion_id, r.id, h.id); // 1.9: el anticipo pasa a su cuenta
  return { id: r.id, pago, deposito: dep };
}));
function estanciaActiva(id) {
  const e = get('SELECT * FROM estancias WHERE id=?', Number(id));
  if (!e) throw new ErrorUsuario('Registro no encontrado', 404);
  if (!e.activa) throw new ErrorUsuario('Este huésped ya salió');
  return e;
}
ruta('GET', '/api/estancias/:id', 'sesion', ({ p }) => {
  const e = resumenEstancia(get('SELECT * FROM estancias WHERE id=?', Number(p.id)));
  if (!e) throw new ErrorUsuario('Registro no encontrado', 404);
  return {
    ...e, habitacion: habJSON(get('SELECT * FROM habitaciones WHERE id=?', e.habitacion_id)),
    cargos: all('SELECT * FROM cargos WHERE estancia_id=? ORDER BY fecha', e.id),
    pagos: all('SELECT p.*, u.nombre usuario FROM pagos p LEFT JOIN usuarios u ON u.id=p.usuario_id WHERE estancia_id=? ORDER BY fecha', e.id),
    visitantes: all('SELECT * FROM visitantes WHERE estancia_id=? ORDER BY entrada DESC', e.id),
    depositos: all('SELECT d.*, u.nombre usuario FROM depositos d LEFT JOIN usuarios u ON u.id=d.usuario_id WHERE estancia_id=? ORDER BY d.id', e.id).map(({ firma, ...d }) => ({ ...d, firmado: !!firma })),
    titular_deposito: titularDeposito(e),
    contratos: all('SELECT id, folio, fecha FROM contratos WHERE estancia_id=? ORDER BY id DESC', e.id),
    cambios: all('SELECT c.*, ha.numero de_num, hb.numero a_num, u.nombre usuario FROM cambios_habitacion c LEFT JOIN habitaciones ha ON ha.id=c.de_id LEFT JOIN habitaciones hb ON hb.id=c.a_id LEFT JOIN usuarios u ON u.id=c.usuario_id WHERE c.estancia_id=? ORDER BY c.id', e.id),
    hab_inicial: e.hab_inicial_id ? get('SELECT numero FROM habitaciones WHERE id=?', e.hab_inicial_id)?.numero : null,
    descuento_por: e.descuento_usuario ? get('SELECT nombre FROM usuarios WHERE id=?', e.descuento_usuario)?.nombre : null,
    no_deseado: e.huesped_id ? !!get('SELECT bloqueado FROM huespedes WHERE id=?', e.huesped_id)?.bloqueado : false,
  };
});
ruta('PUT', '/api/estancias/:id', 'registrar', ({ p, body }) => {
  const e = estanciaActiva(p.id);
  run('UPDATE estancias SET huesped=COALESCE(?,huesped), telefono=?, identificacion=?, procedencia=?, placas=?, personas=?, notas=?, domicilio=? WHERE id=?',
    txt(body.huesped, 100), txt(body.telefono, 30), txt(body.identificacion, 60), txt(body.procedencia, 80), txt(body.placas, 20), Math.min(ent(body.personas, 1), 50), txt(body.notas, 300), txt(body.domicilio, 200), e.id);
});
ruta('POST', '/api/estancias/:id/extender', 'registrar', ({ p, body, u }) => tx(() => {
  const e = estanciaActiva(p.id), n = Math.min(ent(body.cantidad, 1), 365);
  const nueva = MODALIDADES.includes(body.modalidad) ? body.modalidad : e.modalidad;
  const inicio = e.inicio_tramo || e.entrada, previo = e.hospedaje_previo || 0;
  let importe;
  if (nueva !== e.modalidad) {
    // Cambio de tipo de renta (ej. de día a semana): lo ya generado se conserva y la nueva renta empieza donde terminaba la anterior
    const h = get('SELECT * FROM habitaciones WHERE id=?', e.habitacion_id);
    const precio = body.precio !== undefined && body.precio !== '' ? num(body.precio) : precioDe(h, nueva);
    if (!(precio > 0)) throw new ErrorUsuario('Esta habitación no tiene precio por ' + NOMBRE_MOD[nueva] + '. Escríbalo en "Precio".');
    const desde = e.salida_prevista, total = r2(e.total_hospedaje + precio * n);
    run('UPDATE estancias SET modalidad=?, cantidad=?, precio=?, hospedaje_previo=?, inicio_tramo=?, total_hospedaje=?, salida_prevista=?, desc_renueva=0 WHERE id=?',
      nueva, n, precio, e.total_hospedaje, desde, total, salidaPrevista(desde, nueva, n, cfg('hora_salida'), e.hora_checkout), e.id);
    anotarRenta(e.id, u.id, nueva, n, precio, 'cambio');
    importe = precio * n;
  } else {
    const cant = e.cantidad + n, precio = body.precio !== undefined && body.precio !== '' ? num(body.precio) : e.precio;
    // Si cambian el precio en la extensión, lo anterior se queda al precio anterior
    // 1.16: lo ya cobrado se conserva tal cual (antes, al renovar se perdía el descuento del primer periodo)
    const dsc = precio === e.precio && e.desc_renueva ? r2(Math.min(precio, num(e.desc_periodo)) * n) : 0;
    if (precio !== e.precio) {
      run('UPDATE estancias SET cantidad=?, precio=?, hospedaje_previo=?, inicio_tramo=?, total_hospedaje=?, salida_prevista=?, desc_renueva=0 WHERE id=?',
        n, precio, e.total_hospedaje, e.salida_prevista, r2(e.total_hospedaje + precio * n), salidaPrevista(e.salida_prevista, e.modalidad, n, cfg('hora_salida'), e.hora_checkout), e.id);
    } else {
      run('UPDATE estancias SET cantidad=?, total_hospedaje=?, salida_prevista=?, descuento=COALESCE(descuento,0)+? WHERE id=?', cant, r2(e.total_hospedaje + e.precio * n - dsc), sumarPeriodos(e, inicio, cant, n), dsc, e.id);
    }
    anotarRenta(e.id, u.id, e.modalidad, n, precio, 'extension');
    if (dsc) run("UPDATE rentas SET importe=? WHERE id=(SELECT MAX(id) FROM rentas WHERE estancia_id=?)", r2(precio * n - dsc), e.id);
    importe = r2(precio * n - dsc);
  }
  const pago = body.metodo ? pagar(body.pago ?? importe, body.metodo, 'hospedaje', e.id, null, u.id, nueva !== e.modalidad ? 'Cambio a renta por ' + NOMBRE_MOD[nueva] : 'Extensión', body.usd, body.partes) : null;
  return { ok: true, pago };
}));
ruta('POST', '/api/estancias/:id/pago', 'caja', ({ p, body, u }) => {
  const e = estanciaActiva(p.id);
  if (!(num(body.monto) > 0)) throw new ErrorUsuario('Escriba un monto mayor a cero');
  return pagar(body.monto, body.metodo, 'hospedaje', e.id, null, u.id, body.nota === 'anticipo' ? 'Anticipo' : 'Abono', body.usd, body.partes);
});
ruta('POST', '/api/estancias/:id/cargo', 'registrar', ({ p, body, u }) => tx(() => {
  const e = estanciaActiva(p.id), tipo = EXTRAS.includes(body.tipo) ? body.tipo : null;
  if (!tipo) throw new ErrorUsuario('Elija qué se va a cobrar');
  const cant = Math.max(1, Math.min(ent(body.cantidad, 1), 50)), unit = num(body.monto), imp = r2(unit * cant);
  if (!(imp > 0)) throw new ErrorUsuario('Escriba el monto');
  const desc = txt(body.descripcion, 120) || TIPOS_CARGO[tipo];
  // 1.20: el servicio de limpieza se cobra al momento y le aparece a Limpieza como tarea de esa habitación
  if (tipo === 'limpieza' && !(body.cobrar && body.metodo)) throw new ErrorUsuario('El servicio de limpieza se cobra al momento: elija cómo paga el huésped');
  const c = cargar(e.id, tipo, desc, imp, cant, u.id);
  if (tipo === 'limpieza') limpiezaPagada(e, desc, imp, txt(body.nota, 300), u.id); if (tipo === 'limpieza') avisarYa();
  if (tipo === 'mascota') run('UPDATE estancias SET mascotas=COALESCE(mascotas,0)+? WHERE id=?', cant, e.id);
  run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), e.habitacion_id, 'ocupada', `${desc}: $${imp.toFixed(2)}${txt(body.nota, 150) ? ' · ' + txt(body.nota, 150) : ''}`, u.id);
  const pago = body.cobrar && body.metodo ? pagar(imp, body.metodo, tipo, e.id, null, u.id, desc, body.usd, body.partes) : null;
  return { id: c.id, pago, limpieza: tipo === 'limpieza' };
}));
ruta('DELETE', '/api/cargos/:id', 'autorizar', ({ p, u }) => tx(() => {
  const c = get('SELECT * FROM cargos WHERE id=?', Number(p.id));
  if (!c || c.venta_id) throw new ErrorUsuario('Ese cargo no se puede quitar aquí (las ventas se cancelan en Tienda)');
  const e = estanciaActiva(c.estancia_id);
  if (get('SELECT COALESCE(SUM(monto),0) t FROM pagos WHERE estancia_id=? AND concepto=?', e.id, c.tipo).t > get('SELECT COALESCE(SUM(importe),0) t FROM cargos WHERE estancia_id=? AND tipo=? AND id<>?', e.id, c.tipo, c.id).t + 0.009)
    throw new ErrorUsuario('Ese cargo ya se pagó. Para devolverlo registre un egreso de caja.');
  run('DELETE FROM cargos WHERE id=?', c.id);
  run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), e.habitacion_id, 'ocupada', `Se quitó: ${c.descripcion} ($${num(c.importe).toFixed(2)})`, u.id);
}));
ruta('POST', '/api/estancias/:id/cambiar', 'registrar', ({ p, body, u }) => tx(() => {
  const e = estanciaActiva(p.id), nueva = get("SELECT * FROM habitaciones WHERE id=? AND activo=1 AND estado='libre'", Number(body.habitacion_id));
  if (!nueva) throw new ErrorUsuario('La habitación nueva no está disponible');
  run("UPDATE habitaciones SET estado='limpieza' WHERE id=?", e.habitacion_id);
  run("UPDATE habitaciones SET estado='ocupada' WHERE id=?", nueva.id);
  run('UPDATE estancias SET habitacion_id=? WHERE id=?', nueva.id, e.id);
  run('UPDATE visitantes SET habitacion_id=? WHERE estancia_id=? AND salida IS NULL', nueva.id, e.id);
  const motivo = txt(body.motivo, 200);
  run('INSERT INTO cambios_habitacion(estancia_id,de_id,a_id,fecha,usuario_id,motivo) VALUES(?,?,?,?,?,?)', e.id, e.habitacion_id, nueva.id, ahora(), u.id, motivo);
  run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), e.habitacion_id, 'limpieza', `Cambio de habitación del huésped a la ${nueva.numero}${motivo ? ' (' + motivo + ')' : ''}`, u.id);
}));
ruta('POST', '/api/estancias/:id/salida', 'registrar', ({ p, body, u }) => tx(() => {
  const e = resumenEstancia(estanciaActiva(p.id));
  let pago = null;
  if (e.saldo > 0) {
    if (!body.metodo) throw new ErrorUsuario('El huésped debe ' + e.saldo.toFixed(2) + '. Elija cómo paga.');
    pago = pagar(e.saldo, body.metodo, 'hospedaje', e.id, null, u.id, 'Liquidación al salir', body.usd, body.partes);
  }
  const t = ahora();
  run('UPDATE estancias SET activa=0, salida_real=? WHERE id=?', t, e.id);
  run('UPDATE visitantes SET salida=? WHERE estancia_id=? AND salida IS NULL', t, e.id);
  run("UPDATE habitaciones SET estado='limpieza' WHERE id=?", e.habitacion_id);
  run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', t, e.habitacion_id, 'limpieza', 'Salida del huésped', u.id);
  return { id: e.id, pago };
}));
ruta('GET', '/api/estancias', 'sesion', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d, b = '%' + (q.q || '') + '%';
  return all(`SELECT e.*, hb.numero FROM estancias e JOIN habitaciones hb ON hb.id=e.habitacion_id
    WHERE (substr(e.entrada,1,10) <= ? AND COALESCE(substr(e.salida_real,1,10),'9999') >= ?) AND (e.huesped LIKE ? OR e.placas LIKE ? OR hb.numero LIKE ?)
    ORDER BY e.entrada DESC LIMIT 500`, h, d, b, b, b).map(resumenEstancia);
});

// ---------- Firmas y fotos ----------
function firma(v) {
  if (!v) return null;
  if (!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(v) || v.length > 600000) throw new ErrorUsuario('La firma no es válida');
  return v;
}
function guardarFotos(lista, mantId, tipo, uid) {
  for (const f of (Array.isArray(lista) ? lista : []).slice(0, 8)) {
    const m = /^data:image\/(jpeg|png);base64,([A-Za-z0-9+/=]+)$/.exec(String(f));
    if (!m) throw new ErrorUsuario('Una de las fotos no es válida');
    const buf = Buffer.from(m[2], 'base64');
    if (buf.length > 6 * 1024 * 1024) throw new ErrorUsuario('Una foto pesa demasiado');
    const archivo = `m${mantId}_${Date.now()}_${crypto.randomBytes(4).toString('hex')}.${m[1] === 'png' ? 'png' : 'jpg'}`;
    fs.writeFileSync(path.join(FOTOS_DIR, archivo), buf);
    run('INSERT INTO mant_fotos(mant_id,tipo,archivo,fecha,usuario_id) VALUES(?,?,?,?,?)', mantId, tipo, archivo, ahora(), uid);
  }
}

// ---------- Depósitos ----------
function recibirDeposito(eid, monto, metodo, uid, usd, partes) {
  monto = num(monto);
  if (!(monto > 0)) throw new ErrorUsuario('Escriba el monto del depósito');
  const t = turnoCaja(uid), tc = tcDe(t), folio = siguienteFolio('deposito');
  const rp = repartir(monto, partesDe(monto, metodo, usd, partes, tc), tc);
  let id = null;
  for (const f of rp.filas) {
    const r = run('INSERT INTO depositos(estancia_id,fecha,tipo,monto,metodo,folio,usuario_id,turno_id,usd,tc,cambio) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
      eid, ahora(), 'recibido', f.monto, f.metodo, folio, uid, t?.id ?? null, f.usd, f.usd ? tc : 0, f.cambio);
    id = id || r.id;
    if (EN_CAJA.includes(f.metodo)) pedirCajon();
  }
  if (id) run('UPDATE depositos SET recibido=? WHERE id=?', rp.total, id);
  return { id, cambio: rp.cambio };
}
ruta('POST', '/api/estancias/:id/deposito', 'depositos', ({ p, body, u }) => {
  const e = estanciaActiva(p.id);
  return recibirDeposito(e.id, body.monto, body.metodo, u.id, body.usd, body.partes);
});
// Al desocupar: se retiene lo de los daños y se devuelve el resto
ruta('POST', '/api/estancias/:id/deposito/liquidar', 'depositos', ({ p, body, u }) => tx(() => {
  const e = resumenEstancia(get('SELECT * FROM estancias WHERE id=?', Number(p.id)));
  if (!e) throw new ErrorUsuario('Registro no encontrado', 404);
  const retener = num(body.retener), devolver = num(body.devolver);
  if (retener < 0 || devolver < 0) throw new ErrorUsuario('Montos inválidos');
  if (!(retener + devolver > 0)) throw new ErrorUsuario('Escriba cuánto se retiene o se devuelve');
  if (retener + devolver > e.deposito_saldo + 0.001) throw new ErrorUsuario('Solo quedan ' + e.deposito_saldo.toFixed(2) + ' de depósito');
  const out = {};
  if (retener > 0) {
    const motivo = txt(body.motivo, 300);
    if (!motivo) throw new ErrorUsuario('Escriba el motivo de la retención (qué daños o faltantes hubo)');
    let tk = null;
    if (body.crear_reporte) tk = nuevoReporte({ habitacion_id: e.habitacion_id, titulo: 'Daños al desocupar: ' + motivo.slice(0, 80), descripcion: motivo, prioridad: 'alta', estancia_id: e.id }, u.id);
    out.retenido = run('INSERT INTO depositos(estancia_id,fecha,tipo,monto,motivo,ticket_id,folio,usuario_id) VALUES(?,?,?,?,?,?,?,?)', e.id, ahora(), 'retenido', retener, motivo, tk, siguienteFolio('deposito'), u.id).id;
  }
  if (devolver > 0) {
    if (e.activa) throw new ErrorUsuario('El depósito se devuelve únicamente al concluir la estancia. Registre primero la salida del huésped.');
    const lim = limiteDeposito(e);
    if (lim && hoy() > lim) throw new ErrorUsuario(`Ya pasó el plazo para reclamar el depósito: desocupó el ${e.salida_real.slice(0, 10).split('-').reverse().join('/')} y tenía hasta el ${lim.split('-').reverse().join('/')} (${Math.max(1, Math.floor(Number(cfg('deposito_dias_reclamo')) || 7))} días). El depósito ya no se devuelve.`);
    if (!METODOS.includes(body.metodo)) throw new ErrorUsuario('Elija cómo se devuelve el depósito');
    const t = turnoCaja(u.id), tc = tcDe(t), dol = body.metodo === 'dolares' ? r2(devolver / tc) : 0;
    if (EN_CAJA.includes(body.metodo)) pedirCajon();
    out.devuelto = run('INSERT INTO depositos(estancia_id,fecha,tipo,monto,metodo,recibe,firma,folio,usuario_id,turno_id,usd,tc) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
      e.id, ahora(), 'devuelto', devolver, body.metodo, titularDeposito(e), firma(body.firma), siguienteFolio('deposito'), u.id, t?.id ?? null, dol, dol ? tc : 0).id;
  }
  return out;
}));
// 1.12: plazo para reclamar el depósito después de desocupar (aplica a salidas desde que se instaló esta versión)
if (!cfg('deposito_plazo_desde')) setCfg('deposito_plazo_desde', hoy());
// Solo se devuelve al titular del contrato (o al huésped registrado si no hubo contrato)
const titularDeposito = (e) => get('SELECT arrendatario FROM contratos WHERE estancia_id=? AND arrendatario IS NOT NULL ORDER BY id DESC LIMIT 1', e.id)?.arrendatario || e.huesped;
function limiteDeposito(e) {
  if (!e?.salida_real) return null;
  const sal = e.salida_real.slice(0, 10); if (sal < (cfg('deposito_plazo_desde') || '9999')) return null;
  const n = (Math.max(1, Math.floor(Number(cfg('deposito_dias_reclamo')) || 7))); const x = aFecha(sal); x.setDate(x.getDate() + n);
  return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
}
// Pasado el plazo, lo que quedó en resguardo se retiene solo (ya no se devuelve)
function depositosVencidos() {
  const n = (Math.max(1, Math.floor(Number(cfg('deposito_dias_reclamo')) || 7)));
  for (const x of all(`SELECT e.id, e.salida_real, SUM(CASE WHEN d.tipo='recibido' THEN d.monto ELSE -d.monto END) saldo FROM estancias e JOIN depositos d ON d.estancia_id=e.id
    WHERE e.salida_real IS NOT NULL AND substr(e.salida_real,1,10) >= ? GROUP BY e.id HAVING saldo > 0.009`, cfg('deposito_plazo_desde') || '9999')) {
    const lim = limiteDeposito(x); if (!lim || hoy() <= lim) continue;
    run('INSERT INTO depositos(estancia_id,fecha,tipo,monto,motivo,folio,usuario_id) VALUES(?,?,?,?,?,?,?)', x.id, ahora(), 'retenido', r2(x.saldo),
      `No se reclamó en ${n} días después de desocupar (vencía el ${lim.split('-').reverse().join('/')})`, siguienteFolio('deposito'), null);
  }
}
setTimeout(() => { try { depositosVencidos(); } catch (e) { console.error('Depósitos vencidos:', e.message); } }, 20000).unref();
setInterval(() => { try { depositosVencidos(); } catch (e) { console.error('Depósitos vencidos:', e.message); } }, 60 * 60 * 1000).unref();
ruta('GET', '/api/depositos/:id', 'sesion', ({ p }) => {
  const d = get('SELECT d.*, u.nombre usuario FROM depositos d LEFT JOIN usuarios u ON u.id=d.usuario_id WHERE d.id=?', Number(p.id));
  if (!d) throw new ErrorUsuario('No existe', 404);
  // Un depósito pagado con varios métodos se guarda en varias filas con el mismo folio: el recibo las junta
  if (d.tipo === 'recibido' && d.folio) {
    const g = all("SELECT * FROM depositos WHERE estancia_id=? AND folio=? AND tipo='recibido'", d.estancia_id, d.folio);
    if (g.length > 1) Object.assign(d, { monto: r2(g.reduce((s, x) => s + x.monto, 0)), usd: r2(g.reduce((s, x) => s + (x.usd || 0), 0)), tc: Math.max(...g.map((x) => x.tc || 0)), metodo: 'mixto' });
    const rec = Math.max(...g.map((x) => x.recibido || 0));
    d.recibido = rec > 0 ? rec : r2(d.monto + g.reduce((s, x) => s + (x.cambio || 0), 0));
    d.cambio_total = r2(d.recibido - d.monto);
  }
  const e = resumenEstancia(get('SELECT * FROM estancias WHERE id=?', d.estancia_id));
  return { ...d, titular: titularDeposito(e), dias_reclamo: (Math.max(1, Math.floor(Number(cfg('deposito_dias_reclamo')) || 7))), limite_reclamo: limiteDeposito(e), estancia: e, habitacion: habJSON(get('SELECT * FROM habitaciones WHERE id=?', e.habitacion_id)), movimientos: all('SELECT id,fecha,tipo,monto,metodo,motivo FROM depositos WHERE estancia_id=? ORDER BY id', e.id) };
});

// ---------- Gastos ----------
ruta('GET', '/api/gastos', 'sesion', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d;
  return all(`SELECT g.id,g.folio,g.fecha,g.concepto,g.categoria,g.grupo,g.empleado_id,g.proveedor_id,g.factura,g.periodo,em.nombre empleado,pv.nombre proveedor,g.monto,g.metodo,g.entrega,g.recibe,g.nota,g.cancelado,hb.numero, u.nombre usuario,
    (g.firma_recibe IS NOT NULL) firmado FROM gastos g LEFT JOIN habitaciones hb ON hb.id=g.habitacion_id LEFT JOIN usuarios u ON u.id=g.usuario_id
    LEFT JOIN empleados em ON em.id=g.empleado_id LEFT JOIN proveedores pv ON pv.id=g.proveedor_id
    WHERE substr(g.fecha,1,10) BETWEEN ? AND ? ORDER BY g.fecha DESC`, d, h);
});
ruta('GET', '/api/gastos/:id', 'sesion', ({ p }) => {
  const g = get('SELECT g.*, hb.numero, u.nombre usuario, em.nombre empleado, pv.nombre proveedor FROM gastos g LEFT JOIN habitaciones hb ON hb.id=g.habitacion_id LEFT JOIN usuarios u ON u.id=g.usuario_id LEFT JOIN empleados em ON em.id=g.empleado_id LEFT JOIN proveedores pv ON pv.id=g.proveedor_id WHERE g.id=?', Number(p.id));
  if (!g) throw new ErrorUsuario('No existe', 404);
  return g;
});
// ---------- Clasificación de gastos (1.5) ----------
function clasificacion() {
  return String(cfg('gastos_clasificacion') || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((l) => {
    const i = l.indexOf(':'), grupo = (i >= 0 ? l.slice(0, i) : l).trim();
    return { grupo, conceptos: (i >= 0 ? l.slice(i + 1) : '').split(',').map((x) => x.trim()).filter(Boolean) };
  }).filter((g) => g.grupo);
}
// Categorías de versiones anteriores
const GRUPO_VIEJO = { 'mantenimiento': 'Mantenimiento', 'limpieza': 'Compras', 'servicios (luz, agua, gas)': 'Servicios', 'internet y cable': 'Servicios', 'insumos y blancos': 'Compras', 'sueldos': 'Nómina y personal', 'gastos fijos': 'Servicios' };
function grupoDe(categoria) {
  const c = String(categoria || '').trim().toLowerCase();
  if (!c) return 'Otros';
  for (const g of clasificacion()) if (g.grupo.toLowerCase() === c || g.conceptos.some((x) => x.toLowerCase() === c)) return g.grupo;
  return GRUPO_VIEJO[c] || 'Otros';
}
// Gastos guardados antes de la 1.5: se les asigna su clasificación
for (const g of all("SELECT id, categoria FROM gastos WHERE grupo IS NULL OR grupo=''")) run('UPDATE gastos SET grupo=? WHERE id=?', grupoDe(g.categoria), g.id);
function crearGasto(b, uid) {
  const concepto = txt(b.concepto, 200), monto = num(b.monto);
  if (!concepto) throw new ErrorUsuario('Escriba el concepto del gasto');
  if (!(monto > 0)) throw new ErrorUsuario('Escriba el monto del gasto');
  if (!METODOS_GASTO.includes(b.metodo)) throw new ErrorUsuario('Elija cómo se pagó');
  // Si quien lo registra tiene turno abierto, el gasto sale de su caja (salvo que se indique que se pagó por fuera)
  const t = b.fuera_de_caja ? null : turnoAbierto(uid);
  if (t && b.metodo === 'efectivo') pedirCajon();
  const categoria = txt(b.categoria, 60), grupo = txt(b.grupo, 60) || grupoDe(categoria);
  const emp = Number(b.empleado_id) ? get('SELECT id, nombre FROM empleados WHERE id=?', Number(b.empleado_id)) : null;
  const prov = Number(b.proveedor_id) ? get('SELECT id, nombre FROM proveedores WHERE id=?', Number(b.proveedor_id)) : null;
  if (!b.recibe && (emp || prov)) b.recibe = (emp || prov).nombre;
  return run(`INSERT INTO gastos(folio,fecha,concepto,categoria,monto,metodo,entrega,recibe,firma_entrega,firma_recibe,habitacion_id,ticket_id,nota,usuario_id,turno_id,fijo_id,grupo,empleado_id,proveedor_id,factura,periodo)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, siguienteFolio('gasto'), ahora(), concepto, categoria, monto, b.metodo, txt(b.entrega, 100), txt(b.recibe, 100),
    firma(b.firma_entrega), firma(b.firma_recibe), Number(b.habitacion_id) || null, Number(b.ticket_id) || null, txt(b.nota, 300), uid, t?.id ?? null, Number(b.fijo_id) || null, grupo, emp?.id ?? null, prov?.id ?? null, txt(b.factura, 80), txt(b.periodo, 80)).id;
}

// ---------- Empleados y proveedores (1.6) ----------
const PERIODOS_PAGO = ['semanal', 'catorcenal', 'quincenal', 'mensual'];
function limpiarEmp(b) {
  const d = { nombre: txt(b.nombre, 100), puesto: txt(b.puesto, 60), telefono: txt(b.telefono, 30), ingreso: /^\d{4}-\d{2}-\d{2}$/.test(b.ingreso || '') ? b.ingreso : null,
    sueldo: num(b.sueldo), periodo_pago: PERIODOS_PAGO.includes(b.periodo_pago) ? b.periodo_pago : 'semanal', nss: txt(b.nss, 20), rfc: txt(b.rfc, 15), curp: txt(b.curp, 20),
    domicilio: txt(b.domicilio, 200), emergencia: txt(b.emergencia, 120), notas: txt(b.notas, 300) };
  if (!d.nombre) throw new ErrorUsuario('Escriba el nombre del empleado');
  return d;
}
const EMP_COLS = 'nombre=?,puesto=?,telefono=?,ingreso=?,sueldo=?,periodo_pago=?,nss=?,rfc=?,curp=?,domicilio=?,emergencia=?,notas=?';
const empVals = (d) => [d.nombre, d.puesto, d.telefono, d.ingreso, d.sueldo, d.periodo_pago, d.nss, d.rfc, d.curp, d.domicilio, d.emergencia, d.notas];
function limpiarProv(b) {
  const d = { nombre: txt(b.nombre, 100), contacto: txt(b.contacto, 100), telefono: txt(b.telefono, 30), correo: txt(b.correo, 100), rfc: txt(b.rfc, 15), surte: txt(b.surte, 200),
    banco: txt(b.banco, 60), cuenta: txt(b.cuenta, 40), notas: txt(b.notas, 300) };
  if (!d.nombre) throw new ErrorUsuario('Escriba el nombre del proveedor');
  return d;
}
const PROV_COLS = 'nombre=?,contacto=?,telefono=?,correo=?,rfc=?,surte=?,banco=?,cuenta=?,notas=?';
const provVals = (d) => [d.nombre, d.contacto, d.telefono, d.correo, d.rfc, d.surte, d.banco, d.cuenta, d.notas];
// Lista para elegir en "Nuevo gasto" (sin datos privados): cualquiera que registre gastos
ruta('GET', '/api/empleados/lista', 'gastos', () => all('SELECT id, nombre, puesto, sueldo, periodo_pago FROM empleados WHERE activo=1 ORDER BY nombre'));
ruta('GET', '/api/proveedores/lista', 'gastos', () => all('SELECT id, nombre, surte FROM proveedores WHERE activo=1 ORDER BY nombre'));
// Catálogo completo con lo pagado en el periodo
const pagadoA = (col, id, d, h) => get(`SELECT COUNT(*) n, COALESCE(SUM(monto),0) t FROM gastos WHERE ${col}=? AND cancelado=0 AND substr(fecha,1,10) BETWEEN ? AND ?`, id, d, h);
ruta('GET', '/api/empleados', 'personal', ({ q }) => {
  const d = q.desde || hoy().slice(0, 8) + '01', h = q.hasta || hoy();
  return all(`SELECT * FROM empleados WHERE ${q.todos ? '1=1' : 'activo=1'} ORDER BY activo DESC, nombre`).map((e) => ({ ...e, pagado: pagadoA('empleado_id', e.id, d, h) }));
});
ruta('GET', '/api/proveedores', 'personal', ({ q }) => {
  const d = q.desde || hoy().slice(0, 8) + '01', h = q.hasta || hoy();
  return all(`SELECT * FROM proveedores WHERE ${q.todos ? '1=1' : 'activo=1'} ORDER BY activo DESC, nombre`).map((x) => ({ ...x, pagado: pagadoA('proveedor_id', x.id, d, h) }));
});
function historial(col, id) {
  const pagos = all(`SELECT id, folio, fecha, concepto, grupo, categoria, metodo, monto, factura, periodo FROM gastos WHERE ${col}=? AND cancelado=0 ORDER BY fecha DESC LIMIT 300`, id);
  const porTipo = {}; for (const g of pagos) porTipo[g.categoria || 'Otros'] = r2((porTipo[g.categoria || 'Otros'] || 0) + g.monto);
  return { pagos, porTipo, total: r2(pagos.reduce((s, g) => s + g.monto, 0)) };
}
ruta('GET', '/api/empleados/:id', 'personal', ({ p }) => { const e = get('SELECT * FROM empleados WHERE id=?', Number(p.id)); if (!e) throw new ErrorUsuario('No existe', 404); return { ...e, ...historial('empleado_id', e.id) }; });
ruta('GET', '/api/proveedores/:id', 'personal', ({ p }) => { const x = get('SELECT * FROM proveedores WHERE id=?', Number(p.id)); if (!x) throw new ErrorUsuario('No existe', 404); return { ...x, ...historial('proveedor_id', x.id) }; });
ruta('POST', '/api/empleados', 'personal', ({ body }) => ({ id: run(`INSERT INTO empleados(nombre,puesto,telefono,ingreso,sueldo,periodo_pago,nss,rfc,curp,domicilio,emergencia,notas,creado) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`, ...empVals(limpiarEmp(body)), ahora()).id }));
ruta('PUT', '/api/empleados/:id', 'personal', ({ body, p }) => { run(`UPDATE empleados SET ${EMP_COLS}, activo=? WHERE id=?`, ...empVals(limpiarEmp(body)), body.activo === false || body.activo === 0 ? 0 : 1, Number(p.id)); });
ruta('POST', '/api/proveedores', 'personal', ({ body }) => ({ id: run(`INSERT INTO proveedores(nombre,contacto,telefono,correo,rfc,surte,banco,cuenta,notas,creado) VALUES(?,?,?,?,?,?,?,?,?,?)`, ...provVals(limpiarProv(body)), ahora()).id }));
ruta('PUT', '/api/proveedores/:id', 'personal', ({ body, p }) => { run(`UPDATE proveedores SET ${PROV_COLS}, activo=? WHERE id=?`, ...provVals(limpiarProv(body)), body.activo === false || body.activo === 0 ? 0 : 1, Number(p.id)); });
// Nómina de todos de una vez: un gasto por empleado (sueldo + bonos), con un mismo periodo
ruta('POST', '/api/nomina', 'personal', ({ body, u }) => tx(() => {
  const lineas = Array.isArray(body.lineas) ? body.lineas : [], periodo = txt(body.periodo, 80), metodo = METODOS_GASTO.includes(body.metodo) ? body.metodo : 'efectivo';
  if (!periodo) throw new ErrorUsuario('Escriba el periodo que se paga (ej. Semana del 6 al 12 de octubre)');
  const grupoNom = clasificacion().find((g) => /n[oó]mina|personal/i.test(g.grupo))?.grupo || 'Nómina y personal';
  const ids = [];
  for (const l of lineas) {
    const e = get('SELECT * FROM empleados WHERE id=? AND activo=1', Number(l.empleado_id)); if (!e) continue;
    for (const [cat, monto] of [['Nómina', l.sueldo], ['Bono de puntualidad', l.puntualidad], ['Bonos para empleados', l.bono], ['Días festivos', l.festivos], ['Tiempo extra', l.extra]]) {
      if (!(num(monto) > 0)) continue;
      ids.push(crearGasto({ concepto: `${cat} · ${e.nombre} · ${periodo}`, categoria: cat, grupo: grupoNom, monto, metodo, empleado_id: e.id, periodo, recibe: e.nombre, entrega: u.nombre, fuera_de_caja: !!body.fuera_de_caja,
        nota: num(l.descuento) > 0 && cat === 'Nómina' ? 'Descuento aplicado: $' + num(l.descuento).toFixed(2) + (ent(l.retardos) || ent(l.faltas) ? ` (${ent(l.retardos)} retardo(s), ${ent(l.faltas)} falta(s))` : '') : null }, u.id));
    }
    // 1.8: renglón de nómina con sus descuentos de asistencia (para reportes y cierre de mes)
    run('INSERT INTO nomina_lineas(fecha,periodo,empleado_id,sueldo,descuento,desc_retardos,desc_faltas,retardos,faltas,puntualidad,bono,festivos,extra,total,usuario_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
      ahora(), periodo, e.id, num(l.bruto ?? l.sueldo), num(l.descuento), num(l.desc_retardos), num(l.desc_faltas), ent(l.retardos), ent(l.faltas), num(l.puntualidad), num(l.bono), num(l.festivos), num(l.extra),
      r2(num(l.sueldo) + num(l.puntualidad) + num(l.bono) + num(l.festivos) + num(l.extra)), u.id);
  }
  if (!ids.length) throw new ErrorUsuario('No hay montos para pagar');
  return { gastos: ids.length };
}));

// ---------- Control de asistencia (1.7) ----------
const TIPOS_CHECADA = { entrada: 'Entrada', descanso: 'Salida a comer', regreso: 'Regreso de comer', salida: 'Salida' };
const TIPOS_INCID = { vacaciones: 'Vacaciones', permiso_goce: 'Permiso con goce', permiso_sin_goce: 'Permiso sin goce', incapacidad: 'Incapacidad', falta_justificada: 'Falta justificada', descanso_extra: 'Descanso extra' };
const DIAS_PERIODO = { semanal: 7, catorcenal: 14, quincenal: 15, mensual: 30 };
const minDe = (hhmm) => { const [h, m] = String(hhmm || '').split(':').map(Number); return Number.isFinite(h) ? h * 60 + (m || 0) : null; };
const minDeFecha = (f) => { const t = String(f).slice(11, 16); return minDe(t); };
const fechaMas = (d, n) => { const x = aFecha(d); x.setDate(x.getDate() + n); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`; };
function horarioDe(e) { try { const h = JSON.parse(e.horario || 'null'); return h && typeof h === 'object' ? h : null; } catch { return null; } }
// Qué le toca: entrada → comida (si tiene tiempo de comida y aún falta más de 1 hora para su salida) → regreso → salida
function siguienteTipo(empId) {
  const cs = all("SELECT tipo FROM checadas WHERE empleado_id=? AND anulada=0 AND substr(fecha,1,10)=? ORDER BY fecha", empId, hoy()), u = cs[cs.length - 1];
  if (!u || u.tipo === 'salida') return 'entrada';
  if (u.tipo === 'descanso') return 'regreso';
  if (u.tipo === 'regreso') return 'salida';
  const e = get('SELECT horario FROM empleados WHERE id=?', empId), H = e ? horarioDe(e) : null, h = H ? H[new Date().getDay()] : null;
  if (h && num(h.descanso) > 0 && !cs.some((c) => c.tipo === 'descanso') && minDe(h.salida) !== null && minDeFecha(ahora()) < minDe(h.salida) - 60) return 'descanso';
  return 'salida';
}
const metodoChecador = () => (['nip', 'huella', 'ambos'].includes(cfg('asis_metodo')) ? cfg('asis_metodo') : 'ambos');
const puedeAsis = (u, ...k) => u.perm && k.some((x) => u.perm.has(x));
// Cálculo de un periodo para un empleado: estado de cada día, retardos, faltas y descuentos
function asistenciaDe(e, desde, hasta) {
  const C = { tol: num(cfg('asis_tolerancia')), modo: cfg('asis_desc_modo'), monto: num(cfg('asis_desc_monto')), doble: cfg('asis_desc_doble') === '1', nFalta: ent(cfg('asis_retardos_falta')), faltaDesc: cfg('asis_falta_desc') !== '0', festPago: num(cfg('asis_festivo_pago')) };
  const H = horarioDe(e), diario = e.sueldo ? e.sueldo / (DIAS_PERIODO[e.periodo_pago] || 7) : 0;
  const fest = Object.fromEntries(all('SELECT * FROM festivos WHERE fecha BETWEEN ? AND ?', desde, hasta).map((x) => [x.fecha, x]));
  const inc = all('SELECT * FROM incidencias WHERE empleado_id=? AND hasta>=? AND desde<=?', e.id, desde, hasta);
  const chk = all('SELECT * FROM checadas WHERE empleado_id=? AND anulada=0 AND substr(fecha,1,10) BETWEEN ? AND ? ORDER BY fecha', e.id, desde, hasta);
  const porDia = {}; for (const c of chk) (porDia[c.fecha.slice(0, 10)] ||= []).push(c);
  const hoyS = hoy(), ahoraMin = minDeFecha(ahora()), dias = [];
  const R = { trabajados: 0, retardos: 0, min_tarde: 0, faltas: 0, faltas_retardos: 0, descansos: 0, festivos: 0, festivos_trabajados: 0, incidencias: {}, min_trabajados: 0, salidas_antes: 0,
    desc_retardos: 0, desc_faltas: 0, pago_festivos: 0, sueldo_diario: r2(diario) };
  for (let d = desde; d <= hasta; d = fechaMas(d, 1)) {
    const dow = aFecha(d).getDay(), h = H ? H[dow] : undefined, f = fest[d], i = inc.find((x) => x.desde <= d && x.hasta >= d), cs = porDia[d] || [];
    const ent1 = cs.find((c) => c.tipo === 'entrada'), sal = [...cs].reverse().find((c) => c.tipo === 'salida');
    let desc = 0; for (let k = 0; k < cs.length; k++) if (cs[k].tipo === 'descanso') { const r = cs.slice(k + 1).find((c) => c.tipo === 'regreso'); if (r) desc += minDeFecha(r.fecha) - minDeFecha(cs[k].fecha); }
    const trab = ent1 && sal && sal.fecha > ent1.fecha ? Math.max(0, minDeFecha(sal.fecha) - minDeFecha(ent1.fecha) - desc) : 0;
    const dia = { fecha: d, dow, horario: h || null, entrada: ent1?.fecha || null, salida: sal?.fecha || null, descanso_min: desc, trabajado_min: trab, checadas: cs.map((c) => ({ id: c.id, fecha: c.fecha, tipo: c.tipo, metodo: c.metodo })), estado: '', tarde: 0, descuento: 0, extra: 0, nota: '' };
    if (i) { dia.estado = i.tipo; dia.nota = i.nota || ''; R.incidencias[i.tipo] = (R.incidencias[i.tipo] || 0) + 1; if (i.tipo === 'permiso_sin_goce') { dia.descuento = diario; R.desc_faltas += diario; } }
    else if (f && f.descansa) { if (ent1) { dia.estado = 'festivo_trabajado'; dia.extra = diario * C.festPago; R.pago_festivos += dia.extra; R.festivos_trabajados++; R.trabajados++; } else { dia.estado = 'festivo'; R.festivos++; } dia.nota = f.nombre || ''; }
    else if (H === null) { dia.estado = ent1 ? 'asistencia' : 'sin_horario'; if (ent1) R.trabajados++; }
    else if (!h) { dia.estado = ent1 ? 'trabajo_descanso' : 'descanso'; if (ent1) R.trabajados++; else R.descansos++; }
    else if (!ent1) {
      const paso = d < hoyS || (d === hoyS && ahoraMin > (minDe(h.salida) ?? 1440));
      dia.estado = paso ? 'falta' : 'pendiente';
      if (paso) { R.faltas++; if (C.faltaDesc) { dia.descuento = diario; R.desc_faltas += diario; } }
    } else {
      R.trabajados++;
      const tarde = minDeFecha(ent1.fecha) - minDe(h.entrada);
      if (tarde > C.tol) {
        dia.estado = 'retardo'; dia.tarde = tarde; R.retardos++; R.min_tarde += tarde;
        const jornada = Math.max(60, (minDe(h.salida) - minDe(h.entrada)) - (num(h.descanso) || 0));
        const base = C.modo === 'fijo' ? C.monto : C.modo === 'minutos' ? (diario / jornada) * tarde : 0;
        dia.descuento = base * (C.doble ? 2 : 1); R.desc_retardos += dia.descuento;
      } else dia.estado = 'asistencia';
      if (sal && minDe(h.salida) !== null && minDeFecha(sal.fecha) < minDe(h.salida) - C.tol && sal.fecha.slice(0, 10) === d) { R.salidas_antes++; dia.nota = 'Salió antes'; }
    }
    R.min_trabajados += trab;
    dias.push(dia);
  }
  if (C.nFalta > 0) { R.faltas_retardos = Math.floor(R.retardos / C.nFalta); R.desc_faltas += R.faltas_retardos * diario; }
  for (const k of ['desc_retardos', 'desc_faltas', 'pago_festivos']) R[k] = r2(R[k]);
  R.total_descuento = r2(R.desc_retardos + R.desc_faltas);
  for (const x of dias) { x.descuento = r2(x.descuento); x.extra = r2(x.extra); }
  return { dias, resumen: R };
}
const empAsis = (e) => ({ id: e.id, nombre: e.nombre, puesto: e.puesto, numero: e.numero, sueldo: e.sueldo, periodo_pago: e.periodo_pago, horario: horarioDe(e), tiene_pin: !!e.pin, tiene_huella: !!e.huella, activo: e.activo });
// Checador: número + NIP (y huella cuando se conecte el lector)
ruta('POST', '/api/asistencia/checar', 'sesion', ({ body, u }) => {
  if (!puedeAsis(u, 'checador', 'asistencia')) throw new ErrorUsuario('Este usuario no tiene permiso para usar el checador', 403);
  if (metodoChecador() === 'huella') throw new ErrorUsuario('El checador está configurado solo con huella');
  const numero = txt(body.numero, 20);
  if (!numero) throw new ErrorUsuario('Escriba su número de empleado');
  const e = get('SELECT * FROM empleados WHERE numero=? AND activo=1', numero);
  if (!e || !e.pin || !checkPass(String(body.pin || ''), e.pin)) throw new ErrorUsuario('Número o NIP incorrecto');
  return registrarChecada(e, body.tipo, 'nip', u);
});
function registrarChecada(e, tipoPedido, metodo, u) {
  const tipo = TIPOS_CHECADA[tipoPedido] ? tipoPedido : siguienteTipo(e.id);
  const ult = get('SELECT * FROM checadas WHERE empleado_id=? AND anulada=0 ORDER BY fecha DESC LIMIT 1', e.id);
  if (ult && ult.tipo === tipo && (new Date() - aFecha(ult.fecha)) < 120000) throw new ErrorUsuario(`${e.nombre}: ya registró "${TIPOS_CHECADA[tipo]}" hace un momento`);
  const fecha = ahora();
  run('INSERT INTO checadas(empleado_id,fecha,tipo,metodo,usuario_id) VALUES(?,?,?,?,?)', e.id, fecha, tipo, metodo, u.id);
  const H = horarioDe(e), h = H ? H[new Date().getDay()] : null;
  let aviso = '';
  if (tipo === 'entrada' && h && minDeFecha(fecha) - minDe(h.entrada) > num(cfg('asis_tolerancia'))) aviso = `Retardo de ${minDeFecha(fecha) - minDe(h.entrada)} minutos`;
  return { nombre: e.nombre, tipo, texto: TIPOS_CHECADA[tipo], fecha, aviso, siguiente: siguienteTipo(e.id), metodo };
}
// ---------- Lector de huellas DigitalPersona (programa auxiliar herramientas\huella.exe) ----------
const HUELLA_EXE = path.join(path.dirname(fileURLToPath(import.meta.url)), 'herramientas', 'huella.exe');
let lectorOcupado = false;
function huella(args, segundos) {
  if (process.platform !== 'win32' || !fs.existsSync(HUELLA_EXE)) return Promise.reject(new ErrorUsuario('El lector de huellas no está instalado en esta computadora. Use número y NIP.'));
  if (lectorOcupado) return Promise.reject(new ErrorUsuario('El lector está ocupado, intente en un momento'));
  lectorOcupado = true;
  return new Promise((ok, mal) => {
    execFile(HUELLA_EXE, args, { timeout: (segundos + 15) * 1000, windowsHide: true }, (err, stdout) => {
      lectorOcupado = false;
      const l = String(stdout || '').trim().split(/\r?\n/).filter(Boolean).pop();
      let r = null; try { r = JSON.parse(l); } catch { /* sin respuesta */ }
      if (!r) return mal(new ErrorUsuario(err?.killed ? 'El lector no respondió' : 'El lector no respondió (' + (err?.message || 'sin datos') + ')'));
      if (!r.ok) return mal(new ErrorUsuario(r.error || 'Error del lector'));
      ok(r);
    });
  });
}
ruta('GET', '/api/huella/estado', 'sesion', async ({ u }) => {
  if (!puedeAsis(u, 'checador', 'asistencia')) throw new ErrorUsuario('Sin permiso', 403);
  const metodo = metodoChecador();
  if (process.platform !== 'win32' || !fs.existsSync(HUELLA_EXE)) return { metodo, instalado: false, registradas: get("SELECT COUNT(*) n FROM empleados WHERE activo=1 AND huella IS NOT NULL").n };
  try { const r = await huella(['estado'], 5); return { metodo, instalado: true, lector: r.lector, registradas: get("SELECT COUNT(*) n FROM empleados WHERE activo=1 AND huella IS NOT NULL").n }; }
  catch (e) { return { metodo, instalado: true, error: e.message, registradas: get("SELECT COUNT(*) n FROM empleados WHERE activo=1 AND huella IS NOT NULL").n }; }
});
ruta('POST', '/api/huella/enrolar/:id', 'asistencia', async ({ p }) => {
  const e = get('SELECT id, nombre FROM empleados WHERE id=?', Number(p.id)); if (!e) throw new ErrorUsuario('No existe', 404);
  const r = await huella(['enrolar', '20'], 8 * 20);
  run('UPDATE empleados SET huella=? WHERE id=?', r.plantilla, e.id);
  return { ok: true, muestras: r.muestras };
});
ruta('DELETE', '/api/huella/:id', 'asistencia', ({ p }) => { run('UPDATE empleados SET huella=NULL WHERE id=?', Number(p.id)); });
ruta('POST', '/api/huella/checar', 'sesion', async ({ body, u }) => {
  if (!puedeAsis(u, 'checador', 'asistencia')) throw new ErrorUsuario('Este usuario no tiene permiso para usar el checador', 403);
  if (metodoChecador() === 'nip') throw new ErrorUsuario('El checador está configurado solo con número y NIP');
  const L = all('SELECT id, huella FROM empleados WHERE activo=1 AND huella IS NOT NULL');
  if (!L.length) throw new ErrorUsuario('Ningún empleado tiene huella registrada. Regístrelas en Asistencia → Empleados.');
  const tmp = path.join(os.tmpdir(), 'maxsel_huellas_' + process.pid + '.txt');
  fs.writeFileSync(tmp, L.map((x) => x.id + '\t' + x.huella).join('\n'), 'utf8');
  let r;
  try { r = await huella(['identificar', tmp, String(Math.min(30, Math.max(3, ent(body.segundos) || 10)))], 30); } finally { try { fs.unlinkSync(tmp); } catch { /* nada */ } }
  if (r.sinDedo) return { sinDedo: true };
  if (!r.id) return { noReconocida: true };
  const e = get('SELECT * FROM empleados WHERE id=? AND activo=1', Number(r.id));
  if (!e) return { noReconocida: true };
  return registrarChecada(e, body.tipo, 'huella', u);
});
// Quién está trabajando hoy
ruta('GET', '/api/asistencia/hoy', 'sesion', ({ u }) => {
  if (!puedeAsis(u, 'checador', 'asistencia')) throw new ErrorUsuario('Sin permiso', 403);
  const d = hoy();
  return all('SELECT * FROM empleados WHERE activo=1 ORDER BY nombre').map((e) => {
    const cs = all('SELECT fecha, tipo FROM checadas WHERE empleado_id=? AND anulada=0 AND substr(fecha,1,10)=? ORDER BY fecha', e.id, d);
    const a = puedeAsis(u, 'asistencia') ? asistenciaDe(e, d, d).dias[0] : null;
    return { id: e.id, nombre: e.nombre, puesto: e.puesto, ultima: cs[cs.length - 1] || null, checadas: cs, estado: a?.estado || null, tarde: a?.tarde || 0, horario: a?.horario || null };
  });
});
ruta('GET', '/api/asistencia/empleados', 'asistencia', () => all('SELECT * FROM empleados ORDER BY activo DESC, nombre').map(empAsis));
ruta('PUT', '/api/asistencia/empleados/:id', 'asistencia', ({ body, p }) => {
  const e = get('SELECT * FROM empleados WHERE id=?', Number(p.id)); if (!e) throw new ErrorUsuario('No existe', 404);
  const numero = txt(body.numero, 20);
  if (numero && get('SELECT id FROM empleados WHERE numero=? AND id<>?', numero, e.id)) throw new ErrorUsuario('Ese número ya lo tiene otro empleado');
  let horario = null;
  if (body.horario && typeof body.horario === 'object') {
    horario = {};
    for (let k = 0; k <= 6; k++) { const x = body.horario[k]; horario[k] = x && minDe(x.entrada) !== null && minDe(x.salida) !== null ? { entrada: x.entrada, salida: x.salida, descanso: ent(x.descanso) } : null; }
  }
  const pin = body.pin ? String(body.pin).trim() : '';
  if (pin && !/^\d{4,8}$/.test(pin)) throw new ErrorUsuario('El NIP debe ser de 4 a 8 números');
  run('UPDATE empleados SET numero=?, horario=?, pin=COALESCE(?, pin) WHERE id=?', numero, horario ? JSON.stringify(horario) : null, pin ? hashPass(pin) : null, e.id);
});
ruta('GET', '/api/asistencia/checadas', 'asistencia', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d, emp = Number(q.empleado_id) || 0;
  return all(`SELECT c.*, e.nombre, u.nombre usuario FROM checadas c JOIN empleados e ON e.id=c.empleado_id LEFT JOIN usuarios u ON u.id=c.usuario_id
    WHERE substr(c.fecha,1,10) BETWEEN ? AND ? AND (?=0 OR c.empleado_id=?) ORDER BY c.fecha DESC LIMIT 2000`, d, h, emp, emp);
});
// Registro manual (olvidó checar) o corrección
ruta('POST', '/api/asistencia/checadas', 'asistencia', ({ body, u }) => {
  const e = get('SELECT id FROM empleados WHERE id=?', Number(body.empleado_id)); if (!e) throw new ErrorUsuario('Elija al empleado');
  if (!TIPOS_CHECADA[body.tipo]) throw new ErrorUsuario('Elija el tipo');
  const f = String(body.fecha || '').replace('T', ' ');
  if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}/.test(f)) throw new ErrorUsuario('Escriba fecha y hora');
  return { id: run('INSERT INTO checadas(empleado_id,fecha,tipo,metodo,usuario_id,nota) VALUES(?,?,?,?,?,?)', e.id, f.slice(0, 16) + ':00', body.tipo, 'manual', u.id, txt(body.nota, 200) || 'Registro manual').id };
});
ruta('POST', '/api/asistencia/checadas/:id/anular', 'asistencia', ({ p }) => { run('UPDATE checadas SET anulada=1 WHERE id=?', Number(p.id)); });
ruta('GET', '/api/asistencia/reporte', 'asistencia', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d, emp = Number(q.empleado_id) || 0;
  if (d > h) throw new ErrorUsuario('La fecha inicial es mayor a la final');
  if ((aFecha(h) - aFecha(d)) / 86400000 > 370) throw new ErrorUsuario('Máximo un año por reporte');
  return all(`SELECT * FROM empleados WHERE (?=0 OR id=?) AND (activo=1 OR id IN (SELECT empleado_id FROM checadas WHERE substr(fecha,1,10) BETWEEN ? AND ?)) ORDER BY nombre`, emp, emp, d, h)
    .map((e) => ({ empleado: empAsis(e), ...asistenciaDe(e, d, h) }));
});
ruta('GET', '/api/festivos', 'sesion', ({ q }) => all('SELECT * FROM festivos WHERE substr(fecha,1,4)=? ORDER BY fecha', String(q.anio || hoy().slice(0, 4))));
ruta('POST', '/api/festivos', 'asistencia', ({ body }) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(body.fecha || '')) throw new ErrorUsuario('Elija la fecha');
  run('INSERT INTO festivos(fecha,nombre,descansa) VALUES(?,?,?) ON CONFLICT(fecha) DO UPDATE SET nombre=excluded.nombre, descansa=excluded.descansa', body.fecha, txt(body.nombre, 80) || 'Día festivo', body.descansa === false ? 0 : 1);
});
ruta('DELETE', '/api/festivos/:id', 'asistencia', ({ p }) => { run('DELETE FROM festivos WHERE id=?', Number(p.id)); });
// Días de descanso obligatorio (Ley Federal del Trabajo, art. 74)
ruta('POST', '/api/festivos/ley', 'asistencia', ({ body }) => {
  const y = ent(body.anio) || Number(hoy().slice(0, 4)), f2 = (m, d) => `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  const lunes = (m, n) => { const d = new Date(y, m - 1, 1); while (d.getDay() !== 1) d.setDate(d.getDate() + 1); d.setDate(d.getDate() + 7 * (n - 1)); return f2(m, d.getDate()); };
  const L = [[f2(1, 1), 'Año Nuevo'], [lunes(2, 1), 'Día de la Constitución'], [lunes(3, 3), 'Natalicio de Benito Juárez'], [f2(5, 1), 'Día del Trabajo'], [f2(9, 16), 'Día de la Independencia'],
    [lunes(11, 3), 'Día de la Revolución'], [f2(12, 25), 'Navidad']];
  if ((y - 2024) % 6 === 0) L.push([f2(10, 1), 'Transmisión del Poder Ejecutivo Federal']);
  for (const [f, n] of L) run('INSERT OR IGNORE INTO festivos(fecha,nombre,descansa) VALUES(?,?,1)', f, n);
  return { agregados: L.length };
});
ruta('GET', '/api/incidencias', 'asistencia', ({ q }) => all(`SELECT i.*, e.nombre FROM incidencias i JOIN empleados e ON e.id=i.empleado_id WHERE i.hasta>=? AND i.desde<=? ORDER BY i.desde DESC`, q.desde || '0000-00-00', q.hasta || '9999-12-31'));
ruta('POST', '/api/incidencias', 'asistencia', ({ body, u }) => {
  if (!get('SELECT id FROM empleados WHERE id=?', Number(body.empleado_id))) throw new ErrorUsuario('Elija al empleado');
  if (!TIPOS_INCID[body.tipo]) throw new ErrorUsuario('Elija el tipo');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(body.desde || '') || !/^\d{4}-\d{2}-\d{2}$/.test(body.hasta || '') || body.hasta < body.desde) throw new ErrorUsuario('Revise las fechas');
  return { id: run('INSERT INTO incidencias(empleado_id,tipo,desde,hasta,nota,usuario_id,creado) VALUES(?,?,?,?,?,?,?)', Number(body.empleado_id), body.tipo, body.desde, body.hasta, txt(body.nota, 200), u.id, ahora()).id };
});
ruta('DELETE', '/api/incidencias/:id', 'asistencia', ({ p }) => { run('DELETE FROM incidencias WHERE id=?', Number(p.id)); });

// ---------- Cierre de mes (1.7): todo el mes desglosado ----------
function rangoMes(mes) {
  if (!/^\d{4}-\d{2}$/.test(mes || '')) throw new ErrorUsuario('Elija el mes');
  const [y, m] = mes.split('-').map(Number), dias = new Date(y, m, 0).getDate();
  return { desde: `${mes}-01`, hasta: `${mes}-${String(dias).padStart(2, '0')}`, dias, y, m };
}
function totalesMes(d, h) {
  const S = (sql, ...a) => r2(get(`SELECT COALESCE(SUM(${sql}),0) v ` + a.shift(), ...a).v);
  const hosp = S('monto', "FROM pagos WHERE concepto='hospedaje' AND substr(fecha,1,10) BETWEEN ? AND ?", d, h), tienda = S('monto', "FROM pagos WHERE concepto='tienda' AND substr(fecha,1,10) BETWEEN ? AND ?", d, h);
  const visita = S('monto', "FROM pagos WHERE concepto='visita' AND substr(fecha,1,10) BETWEEN ? AND ?", d, h), gastos = S('monto', 'FROM gastos WHERE cancelado=0 AND substr(fecha,1,10) BETWEEN ? AND ?', d, h);
  const otros = S('monto', `FROM pagos WHERE concepto IN ('multa','mora','limpieza','mascota','otro') AND substr(fecha,1,10) BETWEEN ? AND ?`, d, h);
  return { hospedaje: hosp, tienda, visitas: visita, otros, ingresos: r2(hosp + tienda + visita + otros), gastos, utilidad: r2(hosp + tienda + visita + otros - gastos) };
}
function cierreDatos(mes) { const c = cierreBase(mes); return { ...c, extra: extrasPeriodo(c.desde, c.hasta) }; }
function cierreBase(mes) {
  const { desde: d, hasta: h, dias, y, m } = rangoMes(mes);
  const S = (sql, ...a) => r2(get(`SELECT COALESCE(SUM(${sql}),0) v ` + a.shift(), ...a).v);
  const B = 'substr(fecha,1,10) BETWEEN ? AND ?';
  const habs = all('SELECT id, numero, nombre, clase FROM habitaciones WHERE activo=1');
  const pagos = all(`SELECT p.*, u.nombre usuario FROM pagos p LEFT JOIN usuarios u ON u.id=p.usuario_id WHERE substr(p.fecha,1,10) BETWEEN ? AND ?`, d, h);
  const sum = (l, f = () => true) => r2(l.filter(f).reduce((s, x) => s + x.monto, 0));
  // Ingresos por día
  const porDia = []; const estancias = all('SELECT id, habitacion_id, entrada, COALESCE(salida_real, salida_prevista) sale, modalidad FROM estancias WHERE substr(entrada,1,10)<=? AND substr(COALESCE(salida_real, salida_prevista),1,10)>=?', h, d);
  for (let i = 1; i <= dias; i++) {
    const f = `${mes}-${String(i).padStart(2, '0')}`, l = pagos.filter((x) => x.fecha.slice(0, 10) === f);
    const ocup = new Set(estancias.filter((e) => e.entrada.slice(0, 10) <= f && e.sale.slice(0, 10) > f).map((e) => e.habitacion_id)).size;
    const usadas = new Set(estancias.filter((e) => e.entrada.slice(0, 10) <= f && e.sale.slice(0, 10) >= f).map((e) => e.habitacion_id)).size;
    porDia.push({ fecha: f, hospedaje: sum(l, (x) => x.concepto === 'hospedaje'), tienda: sum(l, (x) => x.concepto === 'tienda'), visitas: sum(l, (x) => x.concepto === 'visita'), total: sum(l),
      efectivo: sum(l, (x) => x.metodo === 'efectivo'), dolares: sum(l, (x) => x.metodo === 'dolares'), tarjeta: sum(l, (x) => x.metodo === 'tarjeta'), transferencia: sum(l, (x) => x.metodo === 'transferencia'),
      gastos: S('monto', `FROM gastos WHERE cancelado=0 AND substr(fecha,1,10)=?`, f), ocupadas: ocup, usadas, entradas: get('SELECT COUNT(*) n FROM estancias WHERE substr(entrada,1,10)=?', f).n });
  }
  const nH = habs.length, capacidad = nH * dias, nochesOcup = porDia.reduce((s, x) => s + x.ocupadas, 0);
  // Rentas por tipo
  const rentas = Object.fromEntries(MODALIDADES.map((k) => [k, { n: 0, unidades: 0, generado: 0, cobrado: 0 }]));
  for (const x of all(`SELECT modalidad, COUNT(*) n, SUM(cantidad) c, SUM(importe) i FROM rentas WHERE ${B} GROUP BY modalidad`, d, h)) if (rentas[x.modalidad]) Object.assign(rentas[x.modalidad], { n: x.n, unidades: x.c, generado: r2(x.i) });
  for (const x of pagos) if (x.concepto === 'hospedaje' && rentas[x.modalidad]) rentas[x.modalidad].cobrado = r2(rentas[x.modalidad].cobrado + x.monto);
  const hospSinTipo = sum(pagos, (x) => x.concepto === 'hospedaje' && !x.modalidad);
  // Por habitación
  const porHab = habs.map((hb) => ({ numero: hb.numero, nombre: hb.nombre, rentas: get(`SELECT COUNT(*) n FROM rentas r JOIN estancias e ON e.id=r.estancia_id WHERE e.habitacion_id=? AND substr(r.fecha,1,10) BETWEEN ? AND ?`, hb.id, d, h).n,
    cobrado: S('p.monto', `FROM pagos p JOIN estancias e ON e.id=p.estancia_id WHERE e.habitacion_id=? AND p.concepto='hospedaje' AND substr(p.fecha,1,10) BETWEEN ? AND ?`, hb.id, d, h),
    noches: porDia.reduce((s, x, i) => s + (estancias.some((e) => e.habitacion_id === hb.id && e.entrada.slice(0, 10) <= x.fecha && e.sale.slice(0, 10) > x.fecha) ? 1 : 0), 0) })).sort((a, b) => b.cobrado - a.cobrado);
  // Tienda
  const items = all(`SELECT i.descripcion, SUM(i.cantidad) cantidad, SUM(i.importe) importe, SUM(i.costo*i.cantidad) costo FROM venta_items i JOIN ventas v ON v.id=i.venta_id WHERE v.cancelada=0 AND substr(v.fecha,1,10) BETWEEN ? AND ? GROUP BY i.descripcion ORDER BY importe DESC`, d, h);
  const tienda = { ventas: get(`SELECT COUNT(*) n, COALESCE(SUM(total),0) t FROM ventas WHERE cancelada=0 AND estancia_id IS NULL AND ${B}`, d, h), cargadas: get(`SELECT COUNT(*) n, COALESCE(SUM(total),0) t FROM ventas WHERE cancelada=0 AND estancia_id IS NOT NULL AND ${B}`, d, h),
    canceladas: get(`SELECT COUNT(*) n, COALESCE(SUM(total),0) t FROM ventas WHERE cancelada=1 AND ${B}`, d, h), productos: items.map((x) => ({ ...x, importe: r2(x.importe), costo: r2(x.costo), utilidad: r2(x.importe - x.costo) })),
    venta: r2(items.reduce((s, x) => s + x.importe, 0)), costo: r2(items.reduce((s, x) => s + x.costo, 0)),
    entradas: all(`SELECT p.nombre, SUM(m.cantidad) cantidad, SUM(m.cantidad*p.costo) costo FROM movimientos m JOIN productos p ON p.id=m.producto_id WHERE m.tipo='entrada' AND substr(m.fecha,1,10) BETWEEN ? AND ? GROUP BY p.id ORDER BY costo DESC`, d, h),
    inventario: r2(get('SELECT COALESCE(SUM(existencia*costo),0) v FROM productos WHERE activo=1').v) };
  tienda.utilidad = r2(tienda.venta - tienda.costo);
  // Depósitos
  const dep = (t) => get(`SELECT COUNT(DISTINCT COALESCE(folio,id)) n, COALESCE(SUM(monto),0) t FROM depositos WHERE tipo=? AND ${B}`, t, d, h);
  const depositos = { recibidos: dep('recibido'), devueltos: dep('devuelto'), retenidos: dep('retenido'), resguardo: r2(get(`SELECT COALESCE(SUM(CASE WHEN tipo='recibido' THEN monto ELSE -monto END),0) t FROM depositos WHERE substr(fecha,1,10)<=?`, h).t) };
  // Gastos
  const gl = all(`SELECT g.*, em.nombre empleado, pv.nombre proveedor FROM gastos g LEFT JOIN empleados em ON em.id=g.empleado_id LEFT JOIN proveedores pv ON pv.id=g.proveedor_id WHERE g.cancelado=0 AND substr(g.fecha,1,10) BETWEEN ? AND ? ORDER BY g.fecha`, d, h);
  const porGrupo = {}; for (const g of gl) { const k = g.grupo || 'Otros', x = porGrupo[k] || (porGrupo[k] = { total: 0, n: 0, conceptos: {} }); x.total = r2(x.total + g.monto); x.n++; const c = x.conceptos[g.categoria || 'Otros'] || (x.conceptos[g.categoria || 'Otros'] = { n: 0, total: 0 }); c.n++; c.total = r2(c.total + g.monto); }
  const agr = (campo) => { const o = {}; for (const g of gl) if (g[campo]) { const x = o[g[campo]] || (o[g[campo]] = { n: 0, total: 0 }); x.n++; x.total = r2(x.total + g.monto); } return Object.entries(o).map(([nombre, v]) => ({ nombre, ...v })).sort((a, b) => b.total - a.total); };
  const porMetodoG = {}; for (const g of gl) porMetodoG[g.metodo] = r2((porMetodoG[g.metodo] || 0) + g.monto);
  // Nómina por empleado (gastos de la clasificación de personal)
  const nomina = {}; for (const g of gl) if (g.empleado_id) { const x = nomina[g.empleado] || (nomina[g.empleado] = { total: 0, conceptos: {} }); x.total = r2(x.total + g.monto); x.conceptos[g.categoria || 'Otros'] = r2((x.conceptos[g.categoria || 'Otros'] || 0) + g.monto); }
  // Asistencia
  const asistencia = all('SELECT * FROM empleados WHERE activo=1 OR id IN (SELECT empleado_id FROM checadas WHERE substr(fecha,1,10) BETWEEN ? AND ?) ORDER BY nombre', d, h).map((e) => ({ nombre: e.nombre, puesto: e.puesto, ...asistenciaDe(e, d, h <= hoy() ? h : hoy()).resumen }));
  // Caja
  const turnos = all(`SELECT id FROM turnos WHERE substr(apertura,1,10) BETWEEN ? AND ? ORDER BY id`, d, h).map((x) => { const r = resumenTurno(x.id); return { id: r.turno.id, usuario: r.turno.usuario, apertura: r.turno.apertura, cierre: r.turno.cierre, cobrado: r.cobrado, dif: r.dif, movimientos: r.movimientos, gastos: r.gastos.efectivo }; });
  const movCaja = { ingresos: S('monto', `FROM caja_mov WHERE tipo='ingreso' AND moneda='MXN' AND ${B}`, d, h), egresos: S('monto', `FROM caja_mov WHERE tipo='retiro' AND moneda='MXN' AND ${B}`, d, h) };
  const T = totalesMes(d, h), mesAnt = m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, '0')}`, ra = rangoMes(mesAnt), Ta = totalesMes(ra.desde, ra.hasta);
  const nochesAnt = (() => { const e2 = all('SELECT habitacion_id, entrada, COALESCE(salida_real, salida_prevista) sale FROM estancias WHERE substr(entrada,1,10)<=? AND substr(COALESCE(salida_real, salida_prevista),1,10)>=?', ra.hasta, ra.desde); let n = 0; for (let i = 1; i <= ra.dias; i++) { const f = `${mesAnt}-${String(i).padStart(2, '0')}`; n += new Set(e2.filter((e) => e.entrada.slice(0, 10) <= f && e.sale.slice(0, 10) > f).map((e) => e.habitacion_id)).size; } return n; })();
  return {
    mes, desde: d, hasta: h, dias, hotel: cfg('hotel_nombre'), generado: ahora(), totales: T,
    anterior: { mes: mesAnt, ...Ta, ocupacion: nH ? r2(nochesAnt / (nH * ra.dias) * 100) : 0 },
    ocupacion: { habitaciones: nH, capacidad, noches: nochesOcup, porcentaje: capacidad ? r2(nochesOcup / capacidad * 100) : 0, promedio_noche: nochesOcup ? r2(T.hospedaje / nochesOcup) : 0, revpar: capacidad ? r2(T.hospedaje / capacidad) : 0,
      entradas: get(`SELECT COUNT(*) n FROM estancias WHERE substr(entrada,1,10) BETWEEN ? AND ?`, d, h).n, salidas: get(`SELECT COUNT(*) n FROM estancias WHERE substr(salida_real,1,10) BETWEEN ? AND ?`, d, h).n,
      activas_al_cierre: estancias.filter((e) => e.entrada.slice(0, 10) <= h && e.sale.slice(0, 10) > h).length },
    rentas, hospedaje_sin_tipo: hospSinTipo, porDia, porHab,
    porMetodo: Object.fromEntries(METODOS.map((k) => [k, sum(pagos, (x) => x.metodo === k)])), usd: r2(pagos.reduce((s, x) => s + (x.usd || 0), 0)), usd_pesos: r2(pagos.reduce((s, x) => s + (x.usd || 0) * (x.tc || 0), 0)), cambio: r2(pagos.reduce((s, x) => s + (x.cambio || 0), 0)),
    porUsuario: Object.entries(pagos.reduce((o, x) => { o[x.usuario || '—'] = r2((o[x.usuario || '—'] || 0) + x.monto); return o; }, {})).map(([nombre, total]) => ({ nombre, total })).sort((a, b) => b.total - a.total),
    visitas: { registradas: get(`SELECT COUNT(*) n FROM visitantes WHERE substr(entrada,1,10) BETWEEN ? AND ?`, d, h).n, cobradas: get(`SELECT COUNT(*) n FROM visitantes WHERE cobro>0 AND substr(entrada,1,10) BETWEEN ? AND ?`, d, h).n, total: T.visitas },
    tienda, depositos,
    gastos: { total: T.gastos, n: gl.length, porGrupo, porMetodo: porMetodoG, porEmpleado: agr('empleado'), porProveedor: agr('proveedor'), fijos: gl.filter((g) => g.fijo_id).map((g) => ({ concepto: g.concepto, fecha: g.fecha, monto: g.monto })),
      lista: gl.map((g) => ({ folio: g.folio, fecha: g.fecha, concepto: g.concepto, grupo: g.grupo, categoria: g.categoria, monto: g.monto, metodo: g.metodo, empleado: g.empleado, proveedor: g.proveedor, factura: g.factura, recibe: g.recibe })) },
    nomina: Object.entries(nomina).map(([nombre, v]) => ({ nombre, ...v })).sort((a, b) => b.total - a.total), asistencia,
    caja: { turnos, ...movCaja, diferencia_mxn: r2(turnos.reduce((s, t) => s + (t.dif?.mxn || 0), 0)), diferencia_usd: r2(turnos.reduce((s, t) => s + (t.dif?.usd || 0), 0)) },
    mantenimiento: { reportados: get(`SELECT COUNT(*) n FROM mantenimiento WHERE substr(alta,1,10) BETWEEN ? AND ?`, d, h).n, terminados: get(`SELECT COUNT(*) n FROM mantenimiento WHERE estado='terminado' AND substr(cierre,1,10) BETWEEN ? AND ?`, d, h).n,
      abiertos: get("SELECT COUNT(*) n FROM mantenimiento WHERE estado<>'terminado' AND COALESCE(tipo,'reparacion')<>'limpieza'").n, costo: S('costo', 'FROM mantenimiento WHERE substr(cierre,1,10) BETWEEN ? AND ?', d, h) },
    por_cobrar: all("SELECT e.id FROM estancias e WHERE e.activa=1").map((e) => resumenEstancia(get('SELECT * FROM estancias WHERE id=?', e.id))).filter((e) => e.saldo > 0).reduce((s, e) => r2(s + e.saldo), 0),
  };
}
ruta('GET', '/api/cierre', 'reportes', ({ q }) => {
  const g = get('SELECT c.*, u.nombre usuario FROM cierres c LEFT JOIN usuarios u ON u.id=c.usuario_id WHERE mes=?', q.mes);
  if (g && !q.actual) return { ...JSON.parse(g.datos), cerrado: { fecha: g.fecha, usuario: g.usuario, notas: g.notas } };
  return { ...cierreDatos(q.mes), cerrado: null };
});
ruta('GET', '/api/cierres', 'reportes', () => all('SELECT c.mes, c.fecha, c.notas, u.nombre usuario FROM cierres c LEFT JOIN usuarios u ON u.id=c.usuario_id ORDER BY mes DESC'));
// Cerrar el mes: guarda una foto de todos los números para consultarla después tal cual
ruta('POST', '/api/cierre', 'config', ({ body, u }) => {
  const datos = cierreDatos(body.mes);
  if (datos.hasta >= hoy()) throw new ErrorUsuario('El mes todavía no termina. Puede ver el reporte, pero el cierre se hace cuando acabe el mes.');
  run('INSERT INTO cierres(mes,fecha,usuario_id,notas,datos) VALUES(?,?,?,?,?) ON CONFLICT(mes) DO UPDATE SET fecha=excluded.fecha, usuario_id=excluded.usuario_id, notas=excluded.notas, datos=excluded.datos',
    body.mes, ahora(), u.id, txt(body.notas, 500), JSON.stringify(datos));
  return { ok: true };
});

// ---------- Gastos fijos (1.4): luz, agua, internet, renta… con vencimiento y aviso ----------
const PERIODOS = { semanal: [0, 7], quincenal: [0, 15], mensual: [1, 0], bimestral: [2, 0], trimestral: [3, 0], semestral: [6, 0], anual: [12, 0], unico: [0, 0] };
function siguienteVence(vence, periodo) {
  const [m, d] = PERIODOS[periodo] || [1, 0], f = aFecha(vence || hoy());
  if (m) { const dia = f.getDate(); f.setDate(1); f.setMonth(f.getMonth() + m); f.setDate(Math.min(dia, new Date(f.getFullYear(), f.getMonth() + 1, 0).getDate())); } else f.setDate(f.getDate() + d);
  return `${f.getFullYear()}-${String(f.getMonth() + 1).padStart(2, '0')}-${String(f.getDate()).padStart(2, '0')}`;
}
function fijoJSON(g) {
  const dias = g.vence ? Math.round((aFecha(g.vence) - aFecha(hoy())) / 86400000) : null;
  const pagos = all('SELECT id, folio, fecha, monto, metodo, nota FROM gastos WHERE fijo_id=? AND cancelado=0 ORDER BY fecha DESC LIMIT 12', g.id);
  const ult = pagos.slice(0, 3), promedio = ult.length ? r2(ult.reduce((s, x) => s + x.monto, 0) / ult.length) : 0;
  const estado = !g.activo ? 'inactivo' : dias === null ? 'sin_fecha' : dias < 0 ? 'vencido' : dias <= (g.dias_aviso ?? 5) ? 'por_vencer' : 'al_corriente';
  return { ...g, dias, estado, pagos, promedio, ultimo: pagos[0] || null };
}
function limpiarFijo(b) {
  const d = { nombre: txt(b.nombre, 80), categoria: txt(b.categoria, 60), proveedor: txt(b.proveedor, 80), contrato: txt(b.contrato, 60), referencia: txt(b.referencia, 80),
    monto: num(b.monto), periodo: PERIODOS[b.periodo] ? b.periodo : 'mensual', vence: /^\d{4}-\d{2}-\d{2}$/.test(b.vence || '') ? b.vence : null,
    dias_aviso: Math.min(ent(b.dias_aviso, 0), 60), domiciliado: b.domiciliado ? 1 : 0, notas: txt(b.notas, 300) };
  if (!d.nombre) throw new ErrorUsuario('Escriba qué es (ej. Luz, Agua, Internet)');
  if (!d.vence) throw new ErrorUsuario('Ponga la fecha en que vence el próximo pago');
  return d;
}
const FIJO_COLS = 'nombre=?,categoria=?,proveedor=?,contrato=?,referencia=?,monto=?,periodo=?,vence=?,dias_aviso=?,domiciliado=?,notas=?';
const fijoVals = (d) => [d.nombre, d.categoria, d.proveedor, d.contrato, d.referencia, d.monto, d.periodo, d.vence, d.dias_aviso, d.domiciliado, d.notas];
ruta('GET', '/api/gastos-fijos', 'gastos', () => all('SELECT * FROM gastos_fijos WHERE activo=1 ORDER BY vence').map(fijoJSON));
// Avisos para el menú y la pantalla de habitaciones
ruta('GET', '/api/gastos-fijos/avisos', 'sesion', ({ u }) => {
  if (!u.perm.has('gastos') && !u.perm.has('reportes')) return [];
  return all('SELECT * FROM gastos_fijos WHERE activo=1 ORDER BY vence').map(fijoJSON).filter((g) => g.estado === 'vencido' || g.estado === 'por_vencer')
    .map(({ id, nombre, vence, dias, estado, monto, domiciliado }) => ({ id, nombre, vence, dias, estado, monto, domiciliado }));
});
ruta('POST', '/api/gastos-fijos', 'gastos', ({ body }) => {
  const d = limpiarFijo(body);
  return { id: run(`INSERT INTO gastos_fijos(nombre,categoria,proveedor,contrato,referencia,monto,periodo,vence,dias_aviso,domiciliado,notas,creado) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`, ...fijoVals(d), ahora()).id };
});
ruta('PUT', '/api/gastos-fijos/:id', 'gastos', ({ body, p }) => { run(`UPDATE gastos_fijos SET ${FIJO_COLS} WHERE id=?`, ...fijoVals(limpiarFijo(body)), Number(p.id)); });
ruta('DELETE', '/api/gastos-fijos/:id', 'gastos', ({ p }) => { run('UPDATE gastos_fijos SET activo=0 WHERE id=?', Number(p.id)); });
// Pagar: registra el gasto (con folio) y mueve el vencimiento al siguiente periodo
ruta('POST', '/api/gastos-fijos/:id/pagar', 'gastos', ({ body, p, u }) => tx(() => {
  const g = get('SELECT * FROM gastos_fijos WHERE id=? AND activo=1', Number(p.id));
  if (!g) throw new ErrorUsuario('No existe', 404);
  const periodoTxt = txt(body.periodo_txt, 60);
  const id = crearGasto({ concepto: g.nombre + (g.proveedor ? ' (' + g.proveedor + ')' : '') + (periodoTxt ? ' · ' + periodoTxt : ''), categoria: g.categoria || 'Gastos fijos', monto: body.monto,
    metodo: body.metodo, nota: [g.contrato ? 'Contrato ' + g.contrato : '', txt(body.nota, 200)].filter(Boolean).join(' · '), fijo_id: g.id, fuera_de_caja: !!body.fuera_de_caja, recibe: g.proveedor }, u.id);
  if (g.periodo === 'unico') run('UPDATE gastos_fijos SET activo=0 WHERE id=?', g.id);
  else run('UPDATE gastos_fijos SET vence=? WHERE id=?', siguienteVence(g.vence, g.periodo), g.id);
  return { id, siguiente: get('SELECT vence FROM gastos_fijos WHERE id=?', g.id).vence };
}));
ruta('POST', '/api/gastos', 'gastos', ({ body, u }) => {
  // Opcional (1.8): los gastos pagados en efectivo con dinero de la caja también piden clave de gerente
  if (cfg('autoriza_gastos') === '1' && body.metodo === 'efectivo' && !body.fuera_de_caja && turnoAbierto(u.id)) autorizacion(u, body.autoriza);
  return { id: crearGasto(body, u.id) };
});
ruta('PUT', '/api/gastos/:id/firmas', 'gastos', ({ body, p }) => {
  const g = get('SELECT * FROM gastos WHERE id=?', Number(p.id)); if (!g) throw new ErrorUsuario('No existe', 404);
  run('UPDATE gastos SET firma_entrega=COALESCE(?,firma_entrega), firma_recibe=COALESCE(?,firma_recibe), recibe=COALESCE(?,recibe) WHERE id=?', firma(body.firma_entrega), firma(body.firma_recibe), txt(body.recibe, 100), g.id);
});
ruta('POST', '/api/gastos/:id/cancelar', 'cancelar', ({ p }) => { run('UPDATE gastos SET cancelado=1 WHERE id=?', Number(p.id)); });

// ---------- Contratos de arrendamiento ----------
ruta('GET', '/api/contratos', 'sesion', ({ q }) => all(`SELECT c.id,c.folio,c.fecha,c.arrendatario,c.inicio,c.fin,c.modalidad,c.renta,c.deposito, e.activa, e.salida_prevista, e.salida_real, hb.numero, hb.clase,
  (c.firma_arrendatario IS NOT NULL) firmado FROM contratos c JOIN estancias e ON e.id=c.estancia_id JOIN habitaciones hb ON hb.id=e.habitacion_id
  WHERE (? = '' OR c.arrendatario LIKE ? OR hb.numero LIKE ?) ORDER BY e.activa DESC, c.id DESC LIMIT 300`, q.q || '', '%' + (q.q || '') + '%', '%' + (q.q || '') + '%'));
ruta('GET', '/api/contratos/:id', 'sesion', ({ p }) => {
  const c = get('SELECT * FROM contratos WHERE id=?', Number(p.id)); if (!c) throw new ErrorUsuario('No existe', 404);
  const e = resumenEstancia(get('SELECT * FROM estancias WHERE id=?', c.estancia_id));
  return { ...c, estancia: e, habitacion: habJSON(get('SELECT * FROM habitaciones WHERE id=?', e.habitacion_id)) };
});
ruta('POST', '/api/contratos', 'contratos', ({ body, u }) => {
  const e = get('SELECT * FROM estancias WHERE id=?', Number(body.estancia_id));
  if (!e) throw new ErrorUsuario('Registro de huésped no encontrado');
  if (!txt(body.texto, 60000)) throw new ErrorUsuario('El contrato está vacío');
  if (!txt(body.arrendatario, 100)) throw new ErrorUsuario('Escriba el nombre del arrendatario');
  return run(`INSERT INTO contratos(folio,estancia_id,fecha,arrendatario,identificacion,domicilio,telefono,inicio,fin,modalidad,renta,deposito,dia_pago,texto,firma_arrendador,firma_arrendatario,usuario_id)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, siguienteFolio('contrato'), e.id, ahora(), txt(body.arrendatario, 100), txt(body.identificacion, 80), txt(body.domicilio, 200), txt(body.telefono, 30),
    txt(body.inicio, 20), txt(body.fin, 20), MODALIDADES.includes(body.modalidad) ? body.modalidad : e.modalidad, num(body.renta), num(body.deposito), txt(body.dia_pago, 100),
    txt(body.texto, 60000), firma(body.firma_arrendador), firma(body.firma_arrendatario), u.id);
});
ruta('PUT', '/api/contratos/:id/firmas', 'contratos', ({ body, p }) => {
  const c = get('SELECT id FROM contratos WHERE id=?', Number(p.id)); if (!c) throw new ErrorUsuario('No existe', 404);
  run('UPDATE contratos SET firma_arrendador=COALESCE(?,firma_arrendador), firma_arrendatario=COALESCE(?,firma_arrendatario) WHERE id=?', firma(body.firma_arrendador), firma(body.firma_arrendatario), c.id);
});

// ---------- Mantenimiento (reportes con fotos) ----------
const PRIORIDADES = ['baja', 'normal', 'alta', 'urgente'];
function nuevoReporte(b, uid, fotos) {
  const titulo = txt(b.titulo, 120);
  if (!titulo) throw new ErrorUsuario('Escriba qué hay que reparar');
  const id = run('INSERT INTO mantenimiento(folio,habitacion_id,titulo,descripcion,prioridad,estado,alta,alta_usuario,estancia_id) VALUES(?,?,?,?,?,?,?,?,?)',
    siguienteFolio('mant'), Number(b.habitacion_id) || null, titulo, txt(b.descripcion, 1000), PRIORIDADES.includes(b.prioridad) ? b.prioridad : 'normal', 'pendiente', ahora(), uid, Number(b.estancia_id) || null).id;
  if (fotos) guardarFotos(fotos, id, 'reporte', uid);
  avisarYa();
  return id;
}
const SQL_MANT = `SELECT m.*, hb.numero, hb.clase, us.nombre asignado_nombre, ua.nombre alta_nombre, ut.nombre atiende_nombre, uc.nombre cierre_nombre,
  (SELECT COUNT(*) FROM mant_fotos f WHERE f.mant_id=m.id AND f.tipo='reporte') fotos_reporte,
  (SELECT COUNT(*) FROM mant_fotos f WHERE f.mant_id=m.id AND f.tipo='evidencia') fotos_evidencia,
  (SELECT archivo FROM mant_fotos f WHERE f.mant_id=m.id ORDER BY (f.tipo='evidencia') DESC, f.id DESC LIMIT 1) foto
  FROM mantenimiento m LEFT JOIN habitaciones hb ON hb.id=m.habitacion_id LEFT JOIN usuarios ua ON ua.id=m.alta_usuario
  LEFT JOIN usuarios ut ON ut.id=m.atiende_usuario LEFT JOIN usuarios uc ON uc.id=m.cierre_usuario LEFT JOIN usuarios us ON us.id=m.asignado_a`;
// 1.14: cada quien ve lo suyo — limpieza solo tickets de limpieza, mantenimiento solo reparaciones
const tipoDeRol = (u) => (u?.rol === 'limpieza' ? 'limpieza' : u?.rol === 'mantenimiento' ? 'reparacion' : null);
const puedeTicket = (u, m) => { const t = tipoDeRol(u); return !t || (t === 'limpieza') === (m.tipo === 'limpieza'); };
ruta('GET', '/api/mant', 'vermant', ({ q, u }) => {
  try { sincronizarLimpieza(); } catch { /* nada */ }
  const tipo = tipoDeRol(u) || q.tipo;
  const T = tipo === 'limpieza' ? " AND m.tipo='limpieza'" : tipo === 'reparacion' ? " AND COALESCE(m.tipo,'reparacion')<>'limpieza'" : '';
  const personal = PERSONAL.includes(u?.rol);
  if (q.estado === 'terminados') {
    const d = q.desde || hoy(), h = q.hasta || d;
    // el personal ve lo que terminó él mismo ("ya hice")
    return all(SQL_MANT + " WHERE m.estado='terminado' AND substr(m.cierre,1,10) BETWEEN ? AND ?" + T + (personal ? ' AND (m.cierre_usuario=? OR m.atiende_usuario=?)' : '') + " ORDER BY m.cierre DESC LIMIT 300", d, h, ...(personal ? [u.id, u.id] : []));
  }
  // el personal ve lo que le toca: lo asignado a él y lo que no tiene a nadie asignado (lo suyo primero)
  return all(SQL_MANT + " WHERE m.estado<>'terminado'" + T + (personal ? ' AND (m.asignado_a IS NULL OR m.asignado_a=?)' : '') + ` ORDER BY ${personal ? '(m.asignado_a IS NULL), ' : ''}CASE m.prioridad WHEN 'urgente' THEN 0 WHEN 'alta' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END, m.alta`, ...(personal ? [u.id] : []));
});
// Personal al que se le puede asignar un trabajo
ruta('GET', '/api/mant/personal', 'mant_reportar', () => all("SELECT id, nombre, rol FROM usuarios WHERE activo=1 AND rol IN ('mantenimiento','limpieza') ORDER BY rol, nombre"));
// Cambiar la prioridad (urgencia) o a quién le toca un trabajo — recepción, gerente o administrador
ruta('PUT', '/api/mant/:id', 'mant_reportar', ({ p, body, u }) => {
  if (PERSONAL.includes(u.rol)) throw new ErrorUsuario('Solo recepción, el gerente o el administrador cambian la prioridad', 403);
  const m = get('SELECT * FROM mantenimiento WHERE id=?', Number(p.id)); if (!m) throw new ErrorUsuario('No existe', 404);
  if (m.estado === 'terminado') throw new ErrorUsuario('El trabajo ya está terminado');
  const pr = PRIORIDADES.includes(body.prioridad) ? body.prioridad : m.prioridad;
  let asig = m.asignado_a;
  if (body.asignado_a !== undefined) {
    asig = Number(body.asignado_a) || null;
    if (asig) { const x = get("SELECT rol FROM usuarios WHERE id=? AND activo=1 AND rol IN ('mantenimiento','limpieza')", asig); if (!x) throw new ErrorUsuario('Esa persona no es de mantenimiento ni de limpieza'); if ((x.rol === 'limpieza') !== (m.tipo === 'limpieza')) throw new ErrorUsuario(m.tipo === 'limpieza' ? 'Una limpieza se asigna a alguien de limpieza' : 'Una reparación se asigna a alguien de mantenimiento'); }
  }
  run('UPDATE mantenimiento SET prioridad=?, asignado_a=? WHERE id=?', pr, asig, m.id);
  // 1.21: si se le asigna a alguien o se vuelve urgente, se le avisa al celular
  if ((asig && asig !== m.asignado_a) || (pr === 'urgente' && m.prioridad !== 'urgente')) { run('UPDATE mantenimiento SET avisado=NULL WHERE id=?', m.id); avisarYa(); }
  return get(SQL_MANT + ' WHERE m.id=?', m.id);
});
ruta('GET', '/api/mant/:id', 'vermant', ({ p, u }) => {
  const m = get(SQL_MANT + ' WHERE m.id=?', Number(p.id)); if (!m) throw new ErrorUsuario('No existe', 404);
  if (!puedeTicket(u, m)) throw new ErrorUsuario('Ese trabajo no le corresponde', 403);
  return { ...m, fotos: all('SELECT f.*, u.nombre usuario FROM mant_fotos f LEFT JOIN usuarios u ON u.id=f.usuario_id WHERE mant_id=? ORDER BY f.id', m.id) };
});
const SUBTIPOS_L = ['habitacion', 'area', 'lavanderia', 'otro'];
const limpiarBlancos = (o) => { const r = {}; for (const [k, v] of Object.entries(o && typeof o === 'object' ? o : {})) { const nom = txt(k, 40), n = Math.min(ent(v), 9999); if (nom && n > 0) r[nom] = n; } return r; };
ruta('POST', '/api/mant', 'mant_reportar', ({ body, u }) => tx(() => {
  if (u.rol === 'limpieza') body = { ...body, tipo: 'limpieza' };
  const r = altaMant(body, u);
  // 1.14: al levantarlo, recepción puede dejarlo asignado a alguien
  if (r?.id && !r.existente && body.asignado_a && !PERSONAL.includes(u.rol)) {
    const x = get("SELECT rol FROM usuarios WHERE id=? AND activo=1 AND rol IN ('mantenimiento','limpieza')", Number(body.asignado_a));
    const m = get('SELECT tipo FROM mantenimiento WHERE id=?', r.id);
    if (x && (x.rol === 'limpieza') === (m.tipo === 'limpieza')) run('UPDATE mantenimiento SET asignado_a=? WHERE id=?', Number(body.asignado_a), r.id);
  }
  return r;
}));
function altaMant(body, u) {
  const h = body.habitacion_id ? get('SELECT * FROM habitaciones WHERE id=? AND activo=1', Number(body.habitacion_id)) : null;
  if (body.tipo === 'limpieza') {
    const sub = SUBTIPOS_L.includes(body.subtipo) ? body.subtipo : h ? 'habitacion' : 'area';
    if (sub === 'habitacion' && !h) throw new ErrorUsuario('Elija la habitación');
    const fotos = Array.isArray(body.fotos) ? body.fotos : [];
    const empiezo = !!body.empiezo || sub === 'lavanderia';
    if (sub === 'lavanderia' && !fotos.length && cfg('limpieza_foto_obligatoria') !== '0') throw new ErrorUsuario('Tome una foto de los blancos que manda a lavar');
    // La habitación ya tiene su ticket de limpieza abierto: se usa ese
    if (sub === 'habitacion') {
      const ab = get("SELECT id FROM mantenimiento WHERE habitacion_id=? AND tipo='limpieza' AND estado<>'terminado'", h.id);
      if (ab) {
        if (fotos.length) guardarFotos(fotos, ab.id, 'reporte', u.id);
        if (txt(body.descripcion)) run("UPDATE mantenimiento SET descripcion=TRIM(COALESCE(descripcion,'') || ' ' || ?) WHERE id=?", txt(body.descripcion, 500), ab.id);
        if (empiezo) run("UPDATE mantenimiento SET estado='proceso', inicio=COALESCE(inicio,?), atiende_usuario=? WHERE id=?", ahora(), u.id, ab.id);
        return { id: ab.id, existente: true };
      }
    }
    let titulo = txt(body.titulo, 120), blancos = null;
    if (sub === 'lavanderia') {
      const b = limpiarBlancos(body.blancos), tot = Object.values(b).reduce((a, n) => a + n, 0);
      if (!tot) throw new ErrorUsuario('Anote cuántas piezas manda a lavar');
      blancos = JSON.stringify(Object.fromEntries(Object.entries(b).map(([k, n]) => [k, { env: n }])));
      titulo = titulo || `Blancos a lavar: ${tot} pieza${tot === 1 ? '' : 's'}`;
    }
    titulo = titulo || (sub === 'habitacion' ? 'Limpieza de habitación' : sub === 'area' ? 'Limpieza de ' + (txt(body.area, 60) || 'área común') : 'Limpieza');
    const id = nuevoReporte({ ...body, habitacion_id: sub === 'habitacion' ? h.id : null, titulo }, u.id, fotos);
    run('UPDATE mantenimiento SET tipo=?, area=?, subtipo=?, blancos=?, destino=?, ligado=? WHERE id=?', 'limpieza', sub === 'habitacion' ? null : txt(body.area, 80),
      sub, blancos, txt(body.destino, 80), sub === 'habitacion' && h.estado === 'limpieza' ? 1 : 0, id);
    if (empiezo) run("UPDATE mantenimiento SET estado='proceso', inicio=?, atiende_usuario=? WHERE id=?", ahora(), u.id, id);
    return { id };
  }
  const id = nuevoReporte(body, u.id, body.fotos);
  run('UPDATE mantenimiento SET tipo=?, area=? WHERE id=?', 'reparacion', h ? null : txt(body.area, 80), id);
  if (h && body.poner_en_mant && h.estado !== 'ocupada' && h.estado !== 'mant') {
    run("UPDATE habitaciones SET estado='mant', nota=? WHERE id=?", txt(body.titulo, 120), h.id);
    run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), h.id, 'mant', txt(body.titulo, 120), u.id);
  }
  return { id };
}
ruta('POST', '/api/mant/:id/atender', 'mant_atender', ({ p, u }) => {
  const m = get('SELECT * FROM mantenimiento WHERE id=?', Number(p.id));
  if (m && !puedeTicket(u, m)) throw new ErrorUsuario('Ese trabajo no le corresponde', 403);
  if (!m || m.estado === 'terminado') throw new ErrorUsuario('El reporte ya está terminado');
  run("UPDATE mantenimiento SET estado='proceso', inicio=COALESCE(inicio,?), atiende_usuario=? WHERE id=?", ahora(), u.id, m.id);
});
ruta('POST', '/api/mant/:id/fotos', 'mant', ({ p, body, u }) => {
  const m = get('SELECT * FROM mantenimiento WHERE id=?', Number(p.id)); if (!m) throw new ErrorUsuario('No existe', 404);
  if (m && !puedeTicket(u, m)) throw new ErrorUsuario('Ese trabajo no le corresponde', 403);
  guardarFotos(body.fotos, m.id, body.tipo === 'evidencia' ? 'evidencia' : 'reporte', u.id);
});
ruta('POST', '/api/mant/:id/cerrar', 'mant_atender', ({ p, body, u }) => tx(() => {
  const m = get('SELECT * FROM mantenimiento WHERE id=?', Number(p.id));
  if (m && !puedeTicket(u, m)) throw new ErrorUsuario('Ese trabajo no le corresponde', 403);
  if (!m || m.estado === 'terminado') throw new ErrorUsuario('El reporte ya está terminado');
  if (m.tipo === 'limpieza') {
    const nf = (Array.isArray(body.fotos) ? body.fotos.length : 0) + get("SELECT COUNT(*) n FROM mant_fotos WHERE mant_id=? AND tipo='evidencia'", m.id).n;
    if (!nf && cfg('limpieza_foto_obligatoria') !== '0') throw new ErrorUsuario(m.subtipo === 'lavanderia' ? 'Tome una foto de los blancos que regresaron' : 'Tome al menos una foto de cómo quedó limpio');
    if (m.subtipo === 'lavanderia') {
      const env = (() => { try { return JSON.parse(m.blancos || '{}'); } catch { return {}; } })(), rec = body.recibidos && typeof body.recibidos === 'object' ? body.recibidos : {};
      let tE = 0, tR = 0; const faltan = [];
      for (const [k, v] of Object.entries(env)) { v.rec = Math.min(ent(rec[k]), 9999); tE += v.env; tR += v.rec; if (v.rec < v.env) faltan.push(`${v.env - v.rec} ${k.toLowerCase()}`); }
      run('UPDATE mantenimiento SET blancos=? WHERE id=?', JSON.stringify(env), m.id);
      body = { ...body, nota: `Regresaron ${tR} de ${tE} pieza(s)${faltan.length ? '. FALTAN: ' + faltan.join(', ') : ', completas'}.${txt(body.nota) ? ' ' + txt(body.nota, 800) : ''}` };
    }
  }
  const nota = txt(body.nota, 1000);
  if (!nota) throw new ErrorUsuario(m.tipo === 'limpieza' ? 'Escriba qué se limpió' : 'Escriba qué se hizo para repararlo');
  guardarFotos(body.fotos, m.id, 'evidencia', u.id);
  const costo = num(body.costo);
  let gasto = null;
  if (costo > 0 && body.registrar_gasto) {
    const hb = m.habitacion_id ? get('SELECT numero FROM habitaciones WHERE id=?', m.habitacion_id) : null;
    gasto = crearGasto({ concepto: `Mantenimiento${hb ? ' hab. ' + hb.numero : ''}: ${m.titulo}`, categoria: 'Mantenimiento', monto: costo, metodo: METODOS_GASTO.includes(body.metodo) ? body.metodo : 'efectivo',
      recibe: u.nombre, habitacion_id: m.habitacion_id, ticket_id: m.id, nota }, u.id);
  }
  const t = ahora();
  run("UPDATE mantenimiento SET estado='terminado', inicio=COALESCE(inicio,?), atiende_usuario=COALESCE(atiende_usuario,?), cierre=?, cierre_usuario=?, nota_cierre=?, costo=?, gasto_id=? WHERE id=?",
    t, u.id, t, u.id, nota, costo, gasto, m.id);
  // 1.10: ticket de limpieza terminado = la habitación queda lista para rentar
  if (m.tipo === 'limpieza' && m.habitacion_id) {
    const h = get('SELECT * FROM habitaciones WHERE id=?', m.habitacion_id);
    if (h?.estado === 'limpieza') { run("UPDATE habitaciones SET estado='libre', nota=NULL WHERE id=?", h.id); run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', t, h.id, 'libre', 'Limpieza terminada (ticket ' + m.folio + ')', u.id); }
  }
  // Si la habitación estaba en mantenimiento y ya no tiene pendientes, pasa a limpieza (o lista)
  if (m.habitacion_id && !get("SELECT id FROM mantenimiento WHERE habitacion_id=? AND estado<>'terminado' AND COALESCE(tipo,'reparacion')<>'limpieza'", m.habitacion_id)) {
    const h = get('SELECT * FROM habitaciones WHERE id=?', m.habitacion_id);
    if (h?.estado === 'mant') {
      const nuevo = body.estado_hab === 'libre' ? 'libre' : 'limpieza';
      run('UPDATE habitaciones SET estado=?, nota=NULL WHERE id=?', nuevo, h.id);
      run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', t, h.id, nuevo, 'Reparado: ' + m.titulo, u.id);
    }
  }
}));

// ---------- Turnos de caja ----------
function resumenTurno(id) {
  const t = get('SELECT t.*, u.nombre usuario FROM turnos t LEFT JOIN usuarios u ON u.id=t.usuario_id WHERE t.id=?', id);
  if (!t) throw new ErrorUsuario('Turno no encontrado', 404);
  const S = (sql, ...a) => r2(get(`SELECT COALESCE(SUM(${sql}),0) v ` + a.shift(), ...a).v);
  const pag = (m) => S('monto', "FROM pagos WHERE turno_id=? AND metodo=?", id, m);
  const p = { efectivo: pag('efectivo'), dolares: pag('dolares'), tarjeta: pag('tarjeta'), transferencia: pag('transferencia'),
    usd: S('usd', "FROM pagos WHERE turno_id=? AND metodo='dolares'", id), cambio: S('cambio', 'FROM pagos WHERE turno_id=?', id) };
  const conceptos = Object.fromEntries(all('SELECT concepto, COUNT(*) n, SUM(monto) t FROM pagos WHERE turno_id=? GROUP BY concepto', id).map((x) => [x.concepto, { n: x.n, total: r2(x.t) }]));
  const dep = (tipo, m) => S('monto', 'FROM depositos WHERE turno_id=? AND tipo=? AND metodo=?', id, tipo, m);
  const depUsd = (tipo) => S('usd', "FROM depositos WHERE turno_id=? AND tipo=? AND metodo='dolares'", id, tipo);
  const dr = { efectivo: dep('recibido', 'efectivo'), dolares: dep('recibido', 'dolares'), usd: depUsd('recibido'), tarjeta: dep('recibido', 'tarjeta'), transferencia: dep('recibido', 'transferencia'),
    cambio: S('cambio', "FROM depositos WHERE turno_id=? AND tipo='recibido'", id) };
  const dd = { efectivo: dep('devuelto', 'efectivo'), dolares: dep('devuelto', 'dolares'), usd: depUsd('devuelto'), tarjeta: dep('devuelto', 'tarjeta'), transferencia: dep('devuelto', 'transferencia') };
  const g = { efectivo: S('monto', "FROM gastos WHERE turno_id=? AND cancelado=0 AND metodo='efectivo'", id), total: S('monto', 'FROM gastos WHERE turno_id=? AND cancelado=0', id) };
  const mv = (tipo, mon) => S('monto', 'FROM caja_mov WHERE turno_id=? AND tipo=? AND moneda=?', id, tipo, mon);
  const m = { ing_mxn: mv('ingreso', 'MXN'), ret_mxn: mv('retiro', 'MXN'), ing_usd: mv('ingreso', 'USD'), ret_usd: mv('retiro', 'USD') };
  const esperado = {
    mxn: r2(t.fondo_mxn + p.efectivo - p.cambio + dr.efectivo - dr.cambio - dd.efectivo - g.efectivo + m.ing_mxn - m.ret_mxn),
    usd: r2(t.fondo_usd + p.usd + dr.usd - dd.usd + m.ing_usd - m.ret_usd),
    tarjeta: r2(p.tarjeta + dr.tarjeta - dd.tarjeta),
    transferencia: r2(p.transferencia + dr.transferencia - dd.transferencia),
  };
  const dif = t.estado === 'cerrado' ? { mxn: r2(t.decl_mxn - esperado.mxn), usd: r2(t.decl_usd - esperado.usd), tarjeta: r2(t.decl_tarjeta - esperado.tarjeta), transferencia: r2(t.decl_transferencia - esperado.transferencia) } : null;
  // Cuántos de cada cosa (1.4)
  const rentas = Object.fromEntries(MODALIDADES.map((k) => [k, { n: 0, cantidad: 0, importe: 0, cobrado: 0 }]));
  for (const x of all('SELECT modalidad, COUNT(*) n, SUM(cantidad) c, SUM(importe) i FROM rentas WHERE turno_id=? GROUP BY modalidad', id)) if (rentas[x.modalidad]) Object.assign(rentas[x.modalidad], { n: x.n, cantidad: x.c, importe: r2(x.i) });
  for (const x of all("SELECT modalidad, SUM(monto) t FROM pagos WHERE turno_id=? AND concepto='hospedaje' GROUP BY modalidad", id)) if (rentas[x.modalidad]) rentas[x.modalidad].cobrado = r2(x.t);
  const sinMod = S('monto', "FROM pagos WHERE turno_id=? AND concepto='hospedaje' AND modalidad IS NULL", id);
  const visitas = { n: get('SELECT COUNT(*) n FROM visitantes WHERE turno_id=? AND cobro>0', id).n, t: S('monto', "FROM pagos WHERE turno_id=? AND concepto='visita'", id) };
  const tienda = { ventas: get('SELECT COUNT(*) n, COALESCE(SUM(total),0) t FROM ventas WHERE turno_id=? AND cancelada=0 AND estancia_id IS NULL', id),
    cargadas: get('SELECT COUNT(*) n, COALESCE(SUM(total),0) t FROM ventas WHERE turno_id=? AND cancelada=0 AND estancia_id IS NOT NULL', id),
    productos: all('SELECT i.descripcion, SUM(i.cantidad) cantidad, SUM(i.importe) importe FROM venta_items i JOIN ventas v ON v.id=i.venta_id WHERE v.turno_id=? AND v.cancelada=0 GROUP BY i.descripcion ORDER BY importe DESC', id) };
  const depN = (tipo) => get('SELECT COUNT(DISTINCT COALESCE(folio, id)) n, COALESCE(SUM(monto),0) t FROM depositos WHERE turno_id=? AND tipo=?', id, tipo);
  const cuentas = { rentas, hospedaje_sin_tipo: sinMod, visitas: { n: visitas.n, total: r2(visitas.t) }, tienda,
    depositos: { recibidos: depN('recibido'), devueltos: depN('devuelto'), retenidos: depN('retenido') },
    dolares: { usd: r2(p.usd + dr.usd), tc: t.tipo_cambio, pesos: r2((p.usd + dr.usd) * t.tipo_cambio), cambio: r2(p.cambio + dr.cambio) } };
  return {
    turno: t, pagos: p, conceptos, depositos: { recibidos: dr, devueltos: dd }, gastos: g, movimientos: m, esperado, dif, cuentas,
    cobrado: r2(p.efectivo + p.dolares + p.tarjeta + p.transferencia),
    lista_mov: all('SELECT m.*, a.nombre autorizo FROM caja_mov m LEFT JOIN usuarios a ON a.id=m.autorizo_id WHERE m.turno_id=? ORDER BY m.id', id),
  };
}
const ocultarEsperado = (r) => ({ ...r, esperado: null, dif: null, ciego: true });
// Detalle para el Excel (de un turno o de un periodo)
function detalle(where, ...a) {
  const W = (alias) => where.replace(/\$/g, alias);
  return {
    rentas: all(`SELECT r.fecha, hb.numero, e.huesped, e.folio, r.modalidad, r.cantidad, r.precio, r.importe, r.tipo, u.nombre usuario FROM rentas r JOIN estancias e ON e.id=r.estancia_id
      JOIN habitaciones hb ON hb.id=e.habitacion_id LEFT JOIN usuarios u ON u.id=r.usuario_id WHERE ${W('r')} ORDER BY r.fecha`, ...a),
    pagos: all(`SELECT p.fecha, p.concepto, p.modalidad, p.metodo, p.monto, p.usd, p.tc, p.cambio, p.nota, hb.numero, COALESCE(e.huesped, rv.huesped) huesped, u.nombre usuario FROM pagos p LEFT JOIN estancias e ON e.id=p.estancia_id
      LEFT JOIN reservaciones rv ON rv.id=p.reservacion_id LEFT JOIN habitaciones hb ON hb.id=COALESCE(e.habitacion_id, rv.habitacion_id) LEFT JOIN usuarios u ON u.id=p.usuario_id WHERE ${W('p')} ORDER BY p.fecha`, ...a),
    ventas: all(`SELECT v.folio, v.fecha, i.descripcion, i.cantidad, i.precio, i.importe, v.metodo, hb.numero FROM venta_items i JOIN ventas v ON v.id=i.venta_id LEFT JOIN estancias e ON e.id=v.estancia_id
      LEFT JOIN habitaciones hb ON hb.id=e.habitacion_id WHERE v.cancelada=0 AND ${W('v')} ORDER BY v.fecha`, ...a),
    depositos: all(`SELECT d.fecha, d.folio, d.tipo, d.metodo, d.monto, d.usd, d.motivo, hb.numero, e.huesped FROM depositos d JOIN estancias e ON e.id=d.estancia_id JOIN habitaciones hb ON hb.id=e.habitacion_id
      WHERE ${W('d')} ORDER BY d.fecha`, ...a),
    gastos: all(`SELECT g.folio, g.fecha, g.concepto, g.grupo, g.categoria, g.metodo, g.monto, g.recibe, g.factura, g.periodo, em.nombre empleado, pv.nombre proveedor FROM gastos g LEFT JOIN empleados em ON em.id=g.empleado_id LEFT JOIN proveedores pv ON pv.id=g.proveedor_id WHERE g.cancelado=0 AND ${W('g')} ORDER BY g.fecha`, ...a),
  };
}
// Corte detallado en PDF: solo el administrador (permiso "usuarios" solo lo tiene el administrador)
ruta('GET', '/api/turnos/:id/completo', 'usuarios', ({ p }) => {
  const t = get('SELECT * FROM turnos WHERE id=?', Number(p.id));
  if (!t) throw new ErrorUsuario('Turno no encontrado', 404);
  return { ...resumenTurno(t.id), detalle: detalle('$.turno_id=?', t.id), visitantes: all('SELECT v.nombre, v.entrada, v.cobro, hb.numero FROM visitantes v LEFT JOIN habitaciones hb ON hb.id=v.habitacion_id WHERE v.turno_id=? AND v.cobro>0 ORDER BY v.entrada', t.id),
    movimientos_caja: all('SELECT * FROM caja_mov WHERE turno_id=? ORDER BY id', t.id) };
});
ruta('GET', '/api/turnos/:id/detalle', 'sesion', ({ p, u }) => {
  const t = get('SELECT * FROM turnos WHERE id=?', Number(p.id));
  if (!t) throw new ErrorUsuario('Turno no encontrado', 404);
  if (t.usuario_id !== u.id && !u.perm.has('cortes')) throw new ErrorUsuario('Su usuario no puede ver cortes de otros usuarios', 403);
  const r = resumenTurno(t.id);
  return { ...(u.perm.has('ver_corte') || t.estado === 'cerrado' ? r : ocultarEsperado(r)), detalle: detalle('$.turno_id=?', t.id), visitantes: all('SELECT v.nombre, v.entrada, v.cobro, hb.numero FROM visitantes v LEFT JOIN habitaciones hb ON hb.id=v.habitacion_id WHERE v.turno_id=? AND v.cobro>0 ORDER BY v.entrada', t.id),
    movimientos_caja: all('SELECT * FROM caja_mov WHERE turno_id=? ORDER BY id', t.id) };
});
ruta('GET', '/api/turno', 'todos', ({ u }) => {
  const t = turnoAbierto(u.id);
  if (!t) return { turno: null, tipo_cambio: num(cfg('tipo_cambio')), exigir: cfg('exigir_turno') !== '0' };
  const r = resumenTurno(t.id);
  return u.perm.has('ver_corte') ? r : ocultarEsperado(r);
});
ruta('POST', '/api/turno/abrir', 'caja', async ({ u, body }) => {
  if (turnoAbierto(u.id)) throw new ErrorUsuario('Ya tiene un turno abierto');
  // 1.10: el tipo de cambio lo pone el administrador en Configuración; el cajero ya no lo escribe
  const tc = num(body.tipo_cambio) > 0 && u.perm.has('config') ? num(body.tipo_cambio) : num(cfg('tipo_cambio'));
  if (!(tc > 0)) throw new ErrorUsuario('Falta el tipo de cambio del dólar: el administrador lo pone en Configuración → Impresora y caja');
  const r = run('INSERT INTO turnos(usuario_id,apertura,fondo_mxn,fondo_usd,tipo_cambio) VALUES(?,?,?,?,?)', u.id, ahora(), Math.max(0, num(body.fondo_mxn)), Math.max(0, num(body.fondo_usd)), tc);
  setCfg('tipo_cambio', tc);
  // Abre el cajón para colocar el fondo de caja
  const cajon = await abrirCajon();
  return { turno: get('SELECT * FROM turnos WHERE id=?', r.id), cajon };
});
ruta('POST', '/api/turno/tipo-cambio', 'config', ({ u, body }) => {
  const t = turnoAbierto(u.id); if (!t) throw new ErrorUsuario('No tiene turno abierto');
  const tc = num(body.tipo_cambio); if (!(tc > 0)) throw new ErrorUsuario('Tipo de cambio inválido');
  run('UPDATE turnos SET tipo_cambio=? WHERE id=?', tc, t.id); setCfg('tipo_cambio', tc);
});
// Autorización con clave de gerente o administrador (para egresos de caja)
function autorizacion(u, a) {
  if (cfg('autoriza_egresos') === '0') return null;
  if (u.perm.has('autorizar')) return u;
  const us = txt(a?.usuario, 60)?.toLowerCase(), x = us ? get('SELECT * FROM usuarios WHERE usuario=? AND activo=1', us) : null;
  if (!us || !a?.password) throw new ErrorUsuario('Este egreso necesita la clave de un gerente o del administrador', 403);
  if (!x || !checkPass(String(a.password), x.pass_hash)) throw new ErrorUsuario('Usuario o contraseña del gerente incorrectos', 403);
  if (!new Set(permisosDe(x)).has('autorizar')) throw new ErrorUsuario(x.nombre + ' no puede autorizar egresos (solo gerente o administrador)', 403);
  return x;
}
ruta('POST', '/api/turno/movimiento', 'movimientos', ({ u, body }) => {
  const t = turnoAbierto(u.id); if (!t) throw new ErrorUsuario('Primero abra su turno de caja');
  const tipo = body.tipo === 'ingreso' ? 'ingreso' : 'retiro', moneda = body.moneda === 'USD' ? 'USD' : 'MXN', monto = num(body.monto);
  if (!(monto > 0)) throw new ErrorUsuario('Escriba el monto');
  const motivo = txt(body.motivo, 200); if (!motivo) throw new ErrorUsuario('Escriba el motivo');
  const aut = tipo === 'retiro' ? autorizacion(u, body.autoriza) : null;
  pedirCajon();
  return run('INSERT INTO caja_mov(turno_id,usuario_id,fecha,tipo,moneda,monto,motivo,autorizo_id) VALUES(?,?,?,?,?,?,?,?)', t.id, u.id, ahora(), tipo, moneda, monto, motivo, aut?.id ?? null);
});
ruta('POST', '/api/turno/cerrar', 'caja', ({ u, body }) => {
  const t = turnoAbierto(u.id); if (!t) throw new ErrorUsuario('No tiene turno abierto');
  const v = ['decl_mxn', 'decl_usd', 'decl_tarjeta', 'decl_transferencia'].map((k) => body[k]);
  if (v.some((x) => x === '' || x === undefined || x === null || !(Number(x) >= 0))) throw new ErrorUsuario('Cuente y escriba: efectivo en pesos, dólares, vouchers de tarjeta y transferencias (0 si no hay)');
  run("UPDATE turnos SET decl_mxn=?, decl_usd=?, decl_tarjeta=?, decl_transferencia=?, notas=?, cierre=?, estado='cerrado' WHERE id=?", num(v[0]), num(v[1]), num(v[2]), num(v[3]), txt(body.notas, 500), ahora(), t.id);
  const r = resumenTurno(t.id);
  return u.perm.has('ver_corte') ? r : ocultarEsperado(r);
});
ruta('GET', '/api/turnos', 'cortes', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d;
  return all("SELECT t.id FROM turnos t WHERE substr(t.apertura,1,10) <= ? AND COALESCE(substr(t.cierre,1,10),'9999') >= ? ORDER BY t.id DESC LIMIT 200", h, d).map((x) => resumenTurno(x.id));
});
ruta('GET', '/api/turnos/:id', 'todos', ({ p, u }) => {
  const r = resumenTurno(Number(p.id));
  if (r.turno.usuario_id !== u.id && !u.perm.has('cortes')) throw new ErrorUsuario('Solo puede ver sus propios cortes', 403);
  return u.perm.has('ver_corte') || u.perm.has('cortes') ? r : ocultarEsperado(r);
});

// ---------- Impresora de tickets y cajón ----------
ruta('POST', '/api/imprimir', 'todos', async ({ body }) => imprimirOps(Array.isArray(body.ops) ? body.ops.slice(0, 600) : [], false));
ruta('POST', '/api/cajon', 'cajon', async () => abrirCajon());
ruta('GET', '/api/impresoras', 'config', async () => { try { return { lista: await listarImpresoras() }; } catch (e) { return { lista: [], error: e.message }; } });

// ---------- Visitantes ----------
ruta('GET', '/api/visitantes', 'sesion', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d;
  return {
    dentro: all('SELECT v.*, hb.numero, e.huesped FROM visitantes v LEFT JOIN habitaciones hb ON hb.id=v.habitacion_id LEFT JOIN estancias e ON e.id=v.estancia_id WHERE v.salida IS NULL ORDER BY v.entrada DESC'),
    historial: all(`SELECT v.*, hb.numero, e.huesped FROM visitantes v LEFT JOIN habitaciones hb ON hb.id=v.habitacion_id LEFT JOIN estancias e ON e.id=v.estancia_id
      WHERE v.salida IS NOT NULL AND substr(v.entrada,1,10) BETWEEN ? AND ? ORDER BY v.entrada DESC LIMIT 500`, d, h),
  };
});
ruta('POST', '/api/visitantes', 'visitantes', ({ body, u }) => {
  const nombre = txt(body.nombre, 100);
  if (!nombre) throw new ErrorUsuario('Escriba el nombre del visitante');
  const e = get('SELECT * FROM estancias WHERE habitacion_id=? AND activa=1', Number(body.habitacion_id));
  if (!e) throw new ErrorUsuario('Esa habitación no tiene huésped');
  // Precio fijo: el de la habitación (o el general). Solo gerente o administrador puede cobrar otra cantidad.
  const hb = get('SELECT * FROM habitaciones WHERE id=?', e.habitacion_id), fijo = hb.precio_visita !== null && hb.precio_visita !== undefined ? num(hb.precio_visita) : num(cfg('precio_visita'));
  const cobro = u.perm.has('autorizar') && body.cobro !== undefined && body.cobro !== '' ? num(body.cobro) : fijo;
  return tx(() => {
    const r = run('INSERT INTO visitantes(nombre,identificacion,habitacion_id,estancia_id,motivo,entrada,usuario_id,cobro,turno_id) VALUES(?,?,?,?,?,?,?,?,?)', nombre, txt(body.identificacion, 60), e.habitacion_id, e.id, txt(body.motivo, 100), ahora(), u.id, cobro, turnoAbierto(u.id)?.id ?? null);
    // El cobro de la visita no se suma a la cuenta del huésped: entra directo a caja
    const pg = cobro > 0 ? pagar(cobro, body.metodo, 'visita', null, null, u.id, 'Visita: ' + nombre + ' · hab. ' + get('SELECT numero FROM habitaciones WHERE id=?', e.habitacion_id).numero, body.usd, body.partes) : null;
    return { id: r.id, pago: pg };
  });
});
ruta('POST', '/api/visitantes/:id/salida', 'visitantes', ({ p }) => { run('UPDATE visitantes SET salida=? WHERE id=? AND salida IS NULL', ahora(), Number(p.id)); });

// ---------- Productos e inventario ----------
ruta('GET', '/api/productos', 'sesion', () => all('SELECT * FROM productos WHERE activo=1 ORDER BY nombre'));
function limpiarProd(b) {
  const d = { codigo: txt(b.codigo, 40), nombre: txt(b.nombre, 80), costo: num(b.costo), precio: num(b.precio), minimo: num(b.minimo), area: txt(b.area, 60), servicio: b.servicio ? 1 : 0 };
  if (!d.nombre) throw new ErrorUsuario('Escriba el nombre del producto');
  if (!(d.precio > 0)) throw new ErrorUsuario('Escriba el precio de venta');
  return d;
}
ruta('POST', '/api/productos', 'productos', ({ body, u }) => tx(() => {
  const d = limpiarProd(body), ex = num(body.existencia);
  if (d.codigo && get('SELECT id FROM productos WHERE codigo=? AND activo=1', d.codigo)) throw new ErrorUsuario('Ya existe un producto con ese código');
  const r = run('INSERT INTO productos(codigo,nombre,costo,precio,existencia,minimo,area,servicio) VALUES(?,?,?,?,?,?,?,?)', d.codigo, d.nombre, d.costo, d.precio, d.servicio ? 0 : ex, d.minimo, d.area, d.servicio);
  if (ex && !d.servicio) run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', ahora(), r.id, 'entrada', ex, 'Alta del producto', u.id);
  return r;
}));
ruta('PUT', '/api/productos/:id', 'productos', ({ body, p, u }) => tx(() => {
  const a = get('SELECT * FROM productos WHERE id=?', Number(p.id)); if (!a) throw new ErrorUsuario('No existe', 404);
  const d = limpiarProd(body);
  if (d.codigo && get('SELECT id FROM productos WHERE codigo=? AND id<>? AND activo=1', d.codigo, a.id)) throw new ErrorUsuario('Ya existe un producto con ese código');
  run('UPDATE productos SET codigo=?,nombre=?,costo=?,precio=?,minimo=?,area=?,servicio=? WHERE id=?', d.codigo, d.nombre, d.costo, d.precio, d.minimo, d.area, d.servicio, a.id);
  if (!d.servicio && body.existencia !== undefined && num(body.existencia) !== a.existencia) {
    run('UPDATE productos SET existencia=? WHERE id=?', num(body.existencia), a.id);
    run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', ahora(), a.id, 'ajuste', r2(num(body.existencia) - a.existencia), txt(body.motivo) || 'Ajuste de inventario', u.id);
  }
}));
// 1.8 Importar productos de Excel: si el código (o el nombre) ya existe se actualiza; la existencia se suma o se reemplaza
ruta('POST', '/api/productos/importar', 'productos', ({ body, u }) => tx(() => {
  const lista = Array.isArray(body.productos) ? body.productos.slice(0, 5000) : [], modo = body.existencia === 'reemplazar' ? 'reemplazar' : 'sumar';
  const res = { creados: 0, actualizados: 0, errores: [] };
  lista.forEach((b, i) => {
    let d; try { d = limpiarProd(b); } catch (e) { res.errores.push(`Renglón ${i + 2}: ${e.message}`); return; }
    const ex = b.existencia === undefined || b.existencia === '' ? null : num(b.existencia);
    const a = (d.codigo && get('SELECT * FROM productos WHERE codigo=? AND activo=1', d.codigo)) || get('SELECT * FROM productos WHERE lower(nombre)=lower(?) AND activo=1', d.nombre);
    if (a) {
      run('UPDATE productos SET codigo=COALESCE(?,codigo),nombre=?,costo=CASE WHEN ?>0 THEN ? ELSE costo END,precio=?,minimo=?,area=COALESCE(?,area) WHERE id=?', d.codigo, d.nombre, d.costo, d.costo, d.precio, d.minimo, d.area, a.id);
      if (ex !== null) {
        const nueva = modo === 'sumar' ? r2(a.existencia + ex) : ex;
        if (nueva !== a.existencia) { run('UPDATE productos SET existencia=? WHERE id=?', nueva, a.id); run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', ahora(), a.id, modo === 'sumar' ? 'entrada' : 'ajuste', r2(nueva - a.existencia), 'Importado de Excel', u.id); }
      }
      res.actualizados++;
    } else {
      const r = run('INSERT INTO productos(codigo,nombre,costo,precio,existencia,minimo,area) VALUES(?,?,?,?,?,?,?)', d.codigo, d.nombre, d.costo, d.precio, ex || 0, d.minimo, d.area);
      if (ex) run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', ahora(), r.id, 'entrada', ex, 'Importado de Excel', u.id);
      res.creados++;
    }
  });
  return res;
}));
ruta('DELETE', '/api/productos/:id', 'productos', ({ p }) => { run('UPDATE productos SET activo=0 WHERE id=?', Number(p.id)); });
ruta('POST', '/api/productos/:id/entrada', 'inventario', ({ body, p, u }) => tx(() => {
  const a = get('SELECT * FROM productos WHERE id=? AND activo=1', Number(p.id)); if (!a) throw new ErrorUsuario('No existe', 404);
  const c = num(body.cantidad); if (!(c > 0)) throw new ErrorUsuario('Escriba la cantidad que llegó');
  run('UPDATE productos SET existencia=existencia+?, costo=CASE WHEN ?>0 THEN ? ELSE costo END WHERE id=?', c, num(body.costo), num(body.costo), a.id);
  run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', ahora(), a.id, 'entrada', c, txt(body.nota) || 'Compra', u.id);
}));
ruta('GET', '/api/movimientos', 'sesion', () => all(`SELECT m.*, p.nombre producto, u.nombre usuario FROM movimientos m LEFT JOIN productos p ON p.id=m.producto_id
  LEFT JOIN usuarios u ON u.id=m.usuario_id ORDER BY m.id DESC LIMIT 100`));

// ---------- Ventas de tienda ----------
ruta('POST', '/api/ventas', 'vender', ({ body, u }) => tx(() => {
  const items = Array.isArray(body.items) ? body.items : [];
  if (!items.length) throw new ErrorUsuario('La cuenta está vacía');
  const metodo = body.metodo;
  let estancia = null;
  if (metodo === 'habitacion') {
    estancia = get('SELECT * FROM estancias WHERE habitacion_id=? AND activa=1', Number(body.habitacion_id));
    if (!estancia) throw new ErrorUsuario('Esa habitación no tiene huésped');
  } else if (!METODOS.includes(metodo) && metodo !== 'mixto') throw new ErrorUsuario('Forma de pago inválida');
  const lineas = items.map((it) => {
    const pr = get('SELECT * FROM productos WHERE id=? AND activo=1', Number(it.producto_id)), c = num(it.cantidad);
    if (!pr) throw new ErrorUsuario('Un producto ya no existe');
    if (!(c > 0)) throw new ErrorUsuario('Cantidad inválida');
    if (!pr.servicio && pr.existencia < c) throw new ErrorUsuario(`Solo quedan ${pr.existencia} de ${pr.nombre}`);
    if (estancia && pr.codigo === 'SERV-LIMPIEZA') throw new ErrorUsuario('El servicio de limpieza se cobra al momento: véndalo desde la habitación (botón "Servicio de limpieza") para que le aparezca a Limpieza');
    return { pr, c, importe: r2(pr.precio * c) };
  });
  const total = r2(lineas.reduce((s, l) => s + l.importe, 0)), recibido = metodo === 'efectivo' ? num(body.recibido) : 0;
  if (metodo === 'efectivo' && recibido && recibido < total) throw new ErrorUsuario('El efectivo recibido no alcanza');
  const t = estancia ? turnoAbierto(u.id) : turnoCaja(u.id);
  const folio = siguienteFolio('venta'), fecha = ahora();
  const v = run('INSERT INTO ventas(folio,fecha,total,metodo,estancia_id,recibido,cambio,usuario_id,turno_id) VALUES(?,?,?,?,?,?,?,?,?)', folio, fecha, total, metodo, estancia?.id, recibido, recibido ? r2(recibido - total) : 0, u.id, t?.id ?? null);
  for (const l of lineas) {
    run('INSERT INTO venta_items(venta_id,producto_id,descripcion,cantidad,precio,costo,importe) VALUES(?,?,?,?,?,?,?)', v.id, l.pr.id, l.pr.nombre, l.c, l.pr.precio, l.pr.costo, l.importe);
    if (!l.pr.servicio) {
      run('UPDATE productos SET existencia=existencia-? WHERE id=?', l.c, l.pr.id);
      run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', fecha, l.pr.id, 'venta', -l.c, 'Venta ' + folio, u.id);
    }
    // El servicio de limpieza cargado a la habitación cuenta como "Cuota de limpieza" en los reportes
    if (estancia) run('INSERT INTO cargos(estancia_id,fecha,descripcion,cantidad,importe,venta_id,tipo,usuario_id) VALUES(?,?,?,?,?,?,?,?)', estancia.id, fecha, l.pr.nombre, l.c, l.importe, v.id, l.pr.codigo === 'SERV-LIMPIEZA' ? 'limpieza' : 'consumo', u.id);
  }
  if (!estancia) {
    const pg = pagar(total, metodo, 'tienda', null, v.id, u.id, null, body.usd, metodo === 'efectivo' && recibido ? { efectivo: recibido } : body.partes);
    const metFinal = pg.filas.length === 1 ? pg.filas[0].metodo : 'mixto';
    run('UPDATE ventas SET recibido=?, cambio=?, metodo=? WHERE id=?', pg.total, pg.cambio, metFinal, v.id);
  }
  if (txt(body.nota, 300)) run('UPDATE ventas SET nota=? WHERE id=?', txt(body.nota, 300), v.id);
  return { ...ticketVenta(v.id), pago: get('SELECT SUM(usd) usd, MAX(tc) tc, SUM(cambio) cambio FROM pagos WHERE venta_id=?', v.id) || null, formas: all('SELECT metodo, monto, usd FROM pagos WHERE venta_id=?', v.id) };
}));
function ticketVenta(id) {
  const v = get('SELECT v.*, u.nombre usuario, hb.numero FROM ventas v LEFT JOIN usuarios u ON u.id=v.usuario_id LEFT JOIN estancias e ON e.id=v.estancia_id LEFT JOIN habitaciones hb ON hb.id=e.habitacion_id WHERE v.id=?', id);
  return { ...v, items: all('SELECT * FROM venta_items WHERE venta_id=?', id) };
}
ruta('GET', '/api/ventas', 'sesion', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d;
  return all(`SELECT v.*, u.nombre usuario, hb.numero FROM ventas v LEFT JOIN usuarios u ON u.id=v.usuario_id LEFT JOIN estancias e ON e.id=v.estancia_id LEFT JOIN habitaciones hb ON hb.id=e.habitacion_id
    WHERE substr(v.fecha,1,10) BETWEEN ? AND ? ORDER BY v.fecha DESC`, d, h).map((v) => ({ ...v, items: all('SELECT descripcion, cantidad, importe FROM venta_items WHERE venta_id=?', v.id) }));
});
ruta('POST', '/api/ventas/:id/cancelar', 'cancelar', ({ p, u }) => tx(() => {
  const v = get('SELECT * FROM ventas WHERE id=?', Number(p.id));
  if (!v || v.cancelada) throw new ErrorUsuario('La venta no existe o ya está cancelada');
  for (const it of all('SELECT * FROM venta_items WHERE venta_id=?', v.id)) {
    run('UPDATE productos SET existencia=existencia+? WHERE id=?', it.cantidad, it.producto_id);
    run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', ahora(), it.producto_id, 'cancelacion', it.cantidad, 'Cancelación venta ' + v.folio, u.id);
  }
  run('DELETE FROM cargos WHERE venta_id=?', v.id);
  run('DELETE FROM pagos WHERE venta_id=?', v.id);
  run('UPDATE ventas SET cancelada=1 WHERE id=?', v.id);
}));

// ======================================================================
// Hotel 1.9: RESERVACIONES A FUTURO
// Apartar una habitación para otra fecha (con o sin anticipo). El día que llega, la entrada se hace desde la
// reservación con sus datos y el anticipo ya queda abonado a su cuenta. No deja apartar la misma habitación dos veces.
// ======================================================================
run(`CREATE TABLE IF NOT EXISTS reservaciones (id INTEGER PRIMARY KEY, folio TEXT, habitacion_id INTEGER NOT NULL, huesped TEXT NOT NULL, telefono TEXT,
  personas INTEGER DEFAULT 1, llegada TEXT NOT NULL, hora_llegada TEXT, salida TEXT NOT NULL, modalidad TEXT NOT NULL, cantidad INTEGER DEFAULT 1, precio REAL DEFAULT 0,
  total REAL DEFAULT 0, anticipo REAL DEFAULT 0, origen TEXT, notas TEXT, estado TEXT DEFAULT 'pendiente', estancia_id INTEGER, creado TEXT, usuario_id INTEGER,
  cancelado TEXT, cancelo_id INTEGER, motivo TEXT, devuelto REAL DEFAULT 0)`);
run('CREATE INDEX IF NOT EXISTS ix_res_fechas ON reservaciones(estado, llegada, salida)');
if (!all('PRAGMA table_info(pagos)').some((c) => c.name === 'reservacion_id')) run('ALTER TABLE pagos ADD COLUMN reservacion_id INTEGER');
const RES_MODS = ['noche', 'dia', 'semana', 'mes'];
const ORIGENES_RES = ['Teléfono', 'WhatsApp', 'En persona', 'Facebook', 'Booking', 'Airbnb', 'Expedia', 'Otro'];
const fechaOk = (f) => /^\d{4}-\d{2}-\d{2}$/.test(String(f || '')) && !isNaN(aFecha(f));
// Fecha de salida de la reservación (solo el día): la misma cuenta que al registrar
const salidaRes = (llegada, m, n) => salidaPrevista(llegada + ' 15:00:00', m, n, cfg('hora_salida')).slice(0, 10);
// Reservaciones que se enciman con [llegada, salida) en esa habitación (la salida no cuenta: ese día se puede volver a rentar)
const encimadas = (habId, llegada, salida, sinId = 0) => all(`SELECT * FROM reservaciones WHERE habitacion_id=? AND estado='pendiente' AND id<>? AND llegada<? AND salida>?`, habId, sinId, salida, llegada);
function resJSON(r) {
  if (!r) return r;
  const h = get('SELECT numero, nombre, clase FROM habitaciones WHERE id=?', r.habitacion_id) || {};
  const t = hoy();
  const aviso = r.estado !== 'pendiente' ? '' : r.llegada < t ? 'no_llego' : r.llegada === t ? 'hoy' : r.llegada === sumarDias(t, 1) ? 'manana' : '';
  return { ...r, numero: h.numero, hab_nombre: h.nombre, clase: h.clase, saldo: r2(r.total - r.anticipo), aviso };
}
const sumarDias = (f, n) => { const d = aFecha(f); d.setDate(d.getDate() + n); return fechaHoraDe(d).slice(0, 10); };
function limpiarRes(b, actual = {}) {
  const d = {
    habitacion_id: Number(b.habitacion_id ?? actual.habitacion_id) || 0, huesped: txt(b.huesped ?? actual.huesped, 100), telefono: txt(b.telefono ?? actual.telefono, 30),
    personas: Math.min(ent(b.personas ?? actual.personas, 1) || 1, 50), llegada: String(b.llegada ?? actual.llegada ?? ''), hora_llegada: /^\d{1,2}:\d{2}$/.test(String(b.hora_llegada ?? actual.hora_llegada ?? '')) ? String(b.hora_llegada ?? actual.hora_llegada).padStart(5, '0') : null,
    modalidad: RES_MODS.includes(b.modalidad ?? actual.modalidad) ? (b.modalidad ?? actual.modalidad) : null, cantidad: Math.min(ent(b.cantidad ?? actual.cantidad, 1) || 1, 365),
    origen: ORIGENES_RES.includes(b.origen ?? actual.origen) ? (b.origen ?? actual.origen) : null, notas: txt(b.notas ?? actual.notas, 300),
  };
  const h = get('SELECT * FROM habitaciones WHERE id=? AND activo=1', d.habitacion_id);
  if (!h) throw new ErrorUsuario('Elija la habitación');
  if (!d.huesped) throw new ErrorUsuario('Escriba el nombre de quien reserva');
  if (!fechaOk(d.llegada)) throw new ErrorUsuario('Elija la fecha de llegada');
  if (!actual.id && d.llegada < hoy()) throw new ErrorUsuario('La fecha de llegada ya pasó');
  if (!d.modalidad) throw new ErrorUsuario('Elija si es por noche, día, semana o mes');
  d.precio = b.precio !== undefined && b.precio !== '' ? num(b.precio) : actual.id && d.modalidad === actual.modalidad && d.habitacion_id === actual.habitacion_id ? actual.precio : precioDe(h, d.modalidad);
  if (!(d.precio > 0)) throw new ErrorUsuario(`La habitación ${h.numero} no tiene precio por ${NOMBRE_MOD[d.modalidad]}`);
  d.salida = salidaRes(d.llegada, d.modalidad, d.cantidad);
  d.total = r2(d.precio * d.cantidad);
  const ch = encimadas(h.id, d.llegada, d.salida, actual.id || 0)[0];
  if (ch) throw new ErrorUsuario(`La habitación ${h.numero} ya está apartada para ${ch.huesped} del ${ch.llegada.split('-').reverse().join('/')} al ${ch.salida.split('-').reverse().join('/')}`);
  return { d, h };
}
// Anticipo: entra a la caja como hospedaje y queda ligado a la reservación (al llegar pasa a la cuenta del huésped)
function cobrarAnticipo(resId, folio, monto, b, uid) {
  if (!(num(monto) > 0)) return null;
  const antes = get('SELECT COALESCE(MAX(id),0) m FROM pagos').m;
  const pg = pagar(monto, b.metodo || 'mixto', 'hospedaje', null, null, uid, 'Anticipo de reservación ' + folio, b.usd, b.partes);
  run('UPDATE pagos SET reservacion_id=? WHERE id>?', resId, antes);
  run('UPDATE reservaciones SET anticipo=anticipo+? WHERE id=?', num(monto), resId);
  return pg;
}
ruta('GET', '/api/reservaciones', 'sesion', ({ q }) => {
  const d = fechaOk(q.desde) ? q.desde : hoy(), h = fechaOk(q.hasta) ? q.hasta : sumarDias(d, 60);
  const est = ['pendiente', 'llego', 'cancelada', 'no_llego'].includes(q.estado) ? q.estado : null;
  const l = all(`SELECT * FROM reservaciones WHERE ${est ? 'estado=? AND' : ''} llegada<=? AND salida>=? ORDER BY llegada, id`, ...(est ? [est] : []), h, d);
  // Las pendientes que ya debieron llegar siempre se muestran (para marcarlas)
  const atras = est && est !== 'pendiente' ? [] : all("SELECT * FROM reservaciones WHERE estado='pendiente' AND llegada<? AND salida<? ORDER BY llegada", hoy(), d);
  return [...atras, ...l].map(resJSON);
});
ruta('GET', '/api/reservaciones/calendario', 'sesion', ({ q }) => {
  const d = fechaOk(q.desde) ? q.desde : hoy(), dias = Math.min(Math.max(ent(q.dias, 1) || 14, 7), 62), h = sumarDias(d, dias);
  return {
    desde: d, hasta: h, dias,
    habitaciones: all('SELECT id, numero, nombre, clase, piso, unidad, estado FROM habitaciones WHERE activo=1').sort((a, b) => String(a.numero).localeCompare(String(b.numero), 'es', { numeric: true })),
    reservas: all("SELECT * FROM reservaciones WHERE estado='pendiente' AND llegada<? AND salida>? ORDER BY llegada", h, d).map(resJSON),
    estancias: all('SELECT id, habitacion_id, huesped, modalidad, entrada, salida_prevista FROM estancias WHERE activa=1'),
  };
});
ruta('GET', '/api/reservaciones/:id', 'sesion', ({ p }) => {
  const r = resJSON(get('SELECT * FROM reservaciones WHERE id=?', Number(p.id))); if (!r) throw new ErrorUsuario('La reservación no existe', 404);
  return { ...r, pagos: all('SELECT p.*, u.nombre usuario FROM pagos p LEFT JOIN usuarios u ON u.id=p.usuario_id WHERE p.reservacion_id=? ORDER BY p.id', r.id), usuario: get('SELECT nombre FROM usuarios WHERE id=?', r.usuario_id)?.nombre };
});
// Revisa disponibilidad antes de guardar (la pantalla la usa mientras se captura)
ruta('POST', '/api/reservaciones/revisar', 'sesion', ({ body }) => {
  try { const { d, h } = limpiarRes({ ...body, huesped: body.huesped || 'x' }, body.id ? get('SELECT * FROM reservaciones WHERE id=?', Number(body.id)) || {} : {});
    const e = get('SELECT huesped, salida_prevista FROM estancias WHERE habitacion_id=? AND activa=1', h.id);
    const ocupada = e && e.salida_prevista.slice(0, 10) > d.llegada ? `Ojo: ahorita la ocupa ${e.huesped} y su salida es el ${e.salida_prevista.slice(0, 10).split('-').reverse().join('/')}` : '';
    return { ok: true, salida: d.salida, total: d.total, precio: d.precio, aviso: ocupada };
  } catch (er) { if (er instanceof ErrorUsuario) return { ok: false, error: er.message }; throw er; }
});
ruta('POST', '/api/reservaciones', 'registrar', ({ body, u }) => tx(() => {
  const { d } = limpiarRes(body);
  revisarNoDeseado(body, u); // 1.10
  const folio = 'R-' + siguienteFolio('reservacion');
  const r = run(`INSERT INTO reservaciones(folio,habitacion_id,huesped,telefono,personas,llegada,hora_llegada,salida,modalidad,cantidad,precio,total,origen,notas,creado,usuario_id)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, folio, d.habitacion_id, d.huesped, d.telefono, d.personas, d.llegada, d.hora_llegada, d.salida, d.modalidad, d.cantidad, d.precio, d.total, d.origen, d.notas, ahora(), u.id);
  if (num(body.anticipo) > 0 && !u.perm.has('caja')) throw new ErrorUsuario('Su usuario no tiene permiso para cobrar el anticipo');
  const pago = cobrarAnticipo(r.id, folio, body.anticipo, body, u.id);
  return { ...resJSON(get('SELECT * FROM reservaciones WHERE id=?', r.id)), pago };
}));
ruta('PUT', '/api/reservaciones/:id', 'registrar', ({ body, p }) => tx(() => {
  const a = get('SELECT * FROM reservaciones WHERE id=?', Number(p.id)); if (!a) throw new ErrorUsuario('La reservación no existe', 404);
  if (a.estado !== 'pendiente') throw new ErrorUsuario('Solo se pueden cambiar las reservaciones pendientes');
  const { d } = limpiarRes(body, a);
  run('UPDATE reservaciones SET habitacion_id=?,huesped=?,telefono=?,personas=?,llegada=?,hora_llegada=?,salida=?,modalidad=?,cantidad=?,precio=?,total=?,origen=?,notas=? WHERE id=?',
    d.habitacion_id, d.huesped, d.telefono, d.personas, d.llegada, d.hora_llegada, d.salida, d.modalidad, d.cantidad, d.precio, d.total, d.origen, d.notas, a.id);
  return resJSON(get('SELECT * FROM reservaciones WHERE id=?', a.id));
}));
ruta('POST', '/api/reservaciones/:id/anticipo', 'caja', ({ body, p, u }) => tx(() => {
  const a = get('SELECT * FROM reservaciones WHERE id=?', Number(p.id)); if (!a || a.estado !== 'pendiente') throw new ErrorUsuario('La reservación no está pendiente');
  if (!(num(body.monto) > 0)) throw new ErrorUsuario('Escriba el anticipo');
  return { pago: cobrarAnticipo(a.id, a.folio, body.monto, body, u.id), ...resJSON(get('SELECT * FROM reservaciones WHERE id=?', a.id)) };
}));
// Cancelar (o "no llegó"): el anticipo se queda o se devuelve (sale de la caja)
ruta('POST', '/api/reservaciones/:id/cancelar', 'registrar', ({ body, p, u }) => tx(() => {
  const a = get('SELECT * FROM reservaciones WHERE id=?', Number(p.id)); if (!a || a.estado !== 'pendiente') throw new ErrorUsuario('La reservación no está pendiente');
  const estado = body.no_llego ? 'no_llego' : 'cancelada', dev = Math.min(num(body.devolver), a.anticipo);
  if (dev > 0) {
    if (!u.perm.has('caja')) throw new ErrorUsuario('Su usuario no tiene permiso para devolver dinero de la caja');
    const met = ['efectivo', 'transferencia', 'tarjeta'].includes(body.metodo_devolucion) ? body.metodo_devolucion : 'efectivo';
    const t = turnoCaja(u.id);
    run('INSERT INTO pagos(fecha,monto,metodo,concepto,usuario_id,nota,turno_id,usd,tc,cambio,reservacion_id) VALUES(?,?,?,?,?,?,?,0,0,0,?)', ahora(), -dev, met, 'hospedaje', u.id, `Devolución de anticipo ${a.folio}`, t?.id ?? null, a.id);
    if (met === 'efectivo') pedirCajon();
  }
  run('UPDATE reservaciones SET estado=?, cancelado=?, cancelo_id=?, motivo=?, devuelto=? WHERE id=?', estado, ahora(), u.id, txt(body.motivo, 200), dev, a.id);
  return resJSON(get('SELECT * FROM reservaciones WHERE id=?', a.id));
}));
// Al registrar la entrada desde la reservación: se marca "llegó" y el anticipo pasa a la cuenta del huésped
function reservaLlego(resId, estanciaId, habId) {
  const a = get('SELECT * FROM reservaciones WHERE id=?', Number(resId) || 0); if (!a || a.estado !== 'pendiente') return;
  run("UPDATE reservaciones SET estado='llego', estancia_id=?, habitacion_id=? WHERE id=?", estanciaId, habId, a.id);
  run('UPDATE pagos SET estancia_id=? WHERE reservacion_id=? AND estancia_id IS NULL', estanciaId, a.id);
}
// Al registrar sin reservación: no deja dar una habitación que hoy está apartada para otra persona
function reservaDeHoy(habId, body) {
  if (body.reservacion_id) {
    const a = get("SELECT * FROM reservaciones WHERE id=? AND estado='pendiente'", Number(body.reservacion_id));
    if (!a) throw new ErrorUsuario('La reservación ya no está pendiente');
    return;
  }
  if (body.ignorar_reserva) return;
  const r = get("SELECT * FROM reservaciones WHERE habitacion_id=? AND estado='pendiente' AND llegada<=? AND salida>? ORDER BY llegada LIMIT 1", habId, hoy(), hoy());
  if (r) throw new ErrorUsuario(`Esta habitación está reservada para ${r.huesped} (folio ${r.folio}). Si es esa persona, regístrela desde Reservaciones; si no, elija otra habitación.`);
}

// ======================================================================
// Hotel 1.9: reservaciones en reportes y cierre · calendarios de Booking.com / Airbnb (iCal)
// ======================================================================
if (!all('PRAGMA table_info(reservaciones)').some((c) => c.name === 'ical_uid')) { run('ALTER TABLE reservaciones ADD COLUMN ical_uid TEXT'); run('ALTER TABLE reservaciones ADD COLUMN ical_fuente_id INTEGER'); }
run(`CREATE TABLE IF NOT EXISTS ical_fuentes (id INTEGER PRIMARY KEY, habitacion_id INTEGER NOT NULL, canal TEXT NOT NULL DEFAULT 'Booking', url TEXT NOT NULL,
  activo INTEGER DEFAULT 1, ultimo TEXT, resultado TEXT, eventos INTEGER DEFAULT 0)`);
run('CREATE INDEX IF NOT EXISTS ix_res_ical ON reservaciones(ical_fuente_id, ical_uid)');
run('CREATE INDEX IF NOT EXISTS ix_pagos_resv ON pagos(reservacion_id)');
const CANALES = ['Booking', 'Airbnb', 'Expedia', 'Otro'];

// Resumen de reservaciones del periodo (reportes y cierre de mes)
function resvPeriodo(d, h) {
  const B = 'substr(creado,1,10) BETWEEN ? AND ?';
  const porOrigen = all(`SELECT COALESCE(origen,'Sin dato') nombre, COUNT(*) n, COALESCE(SUM(total),0) total FROM reservaciones WHERE ${B} GROUP BY 1 ORDER BY 2 DESC`, d, h).map((x) => ({ ...x, total: r2(x.total) }));
  const ant = get('SELECT COUNT(*) n, COALESCE(SUM(monto),0) t FROM pagos WHERE reservacion_id IS NOT NULL AND monto>0 AND substr(fecha,1,10) BETWEEN ? AND ?', d, h);
  const dev = get('SELECT COUNT(*) n, COALESCE(SUM(-monto),0) t FROM pagos WHERE reservacion_id IS NOT NULL AND monto<0 AND substr(fecha,1,10) BETWEEN ? AND ?', d, h);
  const cerr = (est) => get('SELECT COUNT(*) n, COALESCE(SUM(anticipo-devuelto),0) ret, COALESCE(SUM(devuelto),0) dev FROM reservaciones WHERE estado=? AND substr(cancelado,1,10) BETWEEN ? AND ?', est, d, h);
  const c = cerr('cancelada'), ns = cerr('no_llego');
  const lista = all(`SELECT * FROM reservaciones WHERE ${B} OR llegada BETWEEN ? AND ? OR substr(cancelado,1,10) BETWEEN ? AND ? ORDER BY llegada, id`, d, h, d, h, d, h).map((r) => ({ ...resJSON(r), retenido: ['cancelada', 'no_llego'].includes(r.estado) ? r2(r.anticipo - r.devuelto) : 0 }));
  return {
    hechas: get(`SELECT COUNT(*) n FROM reservaciones WHERE ${B}`, d, h).n, por_origen: porOrigen,
    llegaron: get("SELECT COUNT(*) n FROM reservaciones WHERE estado='llego' AND llegada BETWEEN ? AND ?", d, h).n,
    anticipos: { n: ant.n, total: r2(ant.t) }, devoluciones: { n: dev.n, total: r2(dev.t) },
    canceladas: { n: c.n, retenido: r2(c.ret), devuelto: r2(c.dev) }, noshow: { n: ns.n, retenido: r2(ns.ret), devuelto: r2(ns.dev) }, retenido_total: r2(c.ret + ns.ret),
    pendientes: get("SELECT COUNT(*) n FROM reservaciones WHERE estado='pendiente'").n,
    anticipos_por_aplicar: r2(get("SELECT COALESCE(SUM(anticipo),0) t FROM reservaciones WHERE estado='pendiente'").t), lista,
  };
}
ruta('GET', '/api/reporte/reservaciones', 'reportes', ({ q }) => resvPeriodo(q.desde || hoy().slice(0, 8) + '01', q.hasta || hoy()));
{
  const _ext = extrasPeriodo;
  extrasPeriodo = function (d, h) { return { ..._ext(d, h), reservaciones: resvPeriodo(d, h) }; };
}

// ---------- Calendarios iCal ----------
const icalTxt = (s) => String(s || '').replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n');
function tokenIcal() { let t = cfg('ical_token'); if (!t) { t = crypto.randomBytes(12).toString('hex'); setCfg('ical_token', t); } return t; }
// Días ocupados o reservados de una habitación (para que Booking / Airbnb los cierren)
function icalHabitacion(h, excluir) {
  const L = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Maxsel Hotel//Reservaciones//ES', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', `X-WR-CALNAME:${icalTxt(cfg('hotel_nombre') + ' ' + h.numero)}`];
  const sello = new Date().toISOString().replace(/[-:]/g, '').slice(0, 15) + 'Z';
  const ev = (uid, ini, fin, t) => {
    const a = ini.slice(0, 10), b = fin.slice(0, 10) > a ? fin.slice(0, 10) : sumarDias(a, 1);
    L.push('BEGIN:VEVENT', `UID:${uid}@maxsel-hotel`, `DTSTAMP:${sello}`, `DTSTART;VALUE=DATE:${a.replace(/-/g, '')}`, `DTEND;VALUE=DATE:${b.replace(/-/g, '')}`, `SUMMARY:${icalTxt(t)}`, 'END:VEVENT');
  };
  for (const r of all("SELECT * FROM reservaciones WHERE habitacion_id=? AND estado='pendiente' AND salida >= ?", h.id, hoy()))
    if (!excluir || r.origen !== excluir) ev('res-' + r.id, r.llegada, r.salida, 'Reservado');
  for (const e of all('SELECT * FROM estancias WHERE habitacion_id=? AND activa=1', h.id)) ev('est-' + e.id, e.entrada, e.salida_prevista, 'Ocupado');
  L.push('END:VCALENDAR');
  return L.join('\r\n') + '\r\n';
}
// Lee un calendario .ics y regresa sus eventos {uid, inicio, fin, titulo}
function leerIcal(texto) {
  const lineas = String(texto).replace(/\r?\n[ \t]/g, '').split(/\r?\n/), out = [];
  let ev = null;
  const f = (x) => { const m = /^(\d{4})(\d{2})(\d{2})/.exec(x); return m ? `${m[1]}-${m[2]}-${m[3]}` : null; };
  for (const l of lineas) {
    if (l === 'BEGIN:VEVENT') ev = {};
    else if (l === 'END:VEVENT') { if (ev?.inicio) out.push(ev); ev = null; }
    else if (ev) {
      const i = l.indexOf(':'); if (i < 0) continue;
      const k = l.slice(0, i).split(';')[0].toUpperCase(), v = l.slice(i + 1).trim();
      if (k === 'UID') ev.uid = v; else if (k === 'DTSTART') ev.inicio = f(v); else if (k === 'DTEND') ev.fin = f(v);
      else if (k === 'SUMMARY') ev.titulo = v.replace(/\\([,;])/g, '$1').replace(/\\n/g, ' ');
      else if (k === 'DESCRIPTION') ev.desc = v.replace(/\\n/g, ' ').replace(/\\([,;])/g, '$1').slice(0, 250);
    }
  }
  return out.map((e) => ({ ...e, uid: e.uid || `${e.inicio}-${e.fin}`, fin: e.fin && e.fin > e.inicio ? e.fin : sumarDias(e.inicio, 1) }));
}
// Las reservaciones de Booking / Airbnb entran como reservaciones pendientes (el pago lo maneja la plataforma o se cobra al llegar)
function aplicarIcal(fu, eventos) {
  const h = get('SELECT * FROM habitaciones WHERE id=?', fu.habitacion_id); if (!h) return { nuevas: 0, cambios: 0, canceladas: 0, choques: 0 };
  let nuevas = 0, cambios = 0, canceladas = 0, choques = 0;
  const vistos = new Set(), t = hoy();
  for (const e of eventos) {
    if (e.fin <= t || /@maxsel-hotel$/.test(e.uid)) continue; // ya pasó, o es nuestro propio bloqueo que regresa
    vistos.add(e.uid);
    const noches = Math.max(1, Math.round((aFecha(e.fin + ' 12:00:00') - aFecha(e.inicio + ' 12:00:00')) / 86400000));
    const ya = get('SELECT * FROM reservaciones WHERE ical_fuente_id=? AND ical_uid=?', fu.id, e.uid);
    if (ya) {
      if (ya.estado === 'pendiente' && (ya.llegada !== e.inicio || ya.salida !== e.fin)) { run('UPDATE reservaciones SET llegada=?, salida=?, cantidad=?, total=precio*? WHERE id=?', e.inicio, e.fin, noches, noches, ya.id); cambios++; }
      continue;
    }
    if (encimadas(h.id, e.inicio, e.fin).length) choques++;
    const nombre = (e.titulo || '').replace(/^(CLOSED - Not available|Not available|Reserved|Airbnb \(Not available\)|Blocked)$/i, '').trim() || `Huésped de ${fu.canal}`;
    const precio = h.precio_noche || 0;
    run(`INSERT INTO reservaciones(folio,habitacion_id,huesped,personas,llegada,hora_llegada,salida,modalidad,cantidad,precio,total,origen,notas,creado,ical_uid,ical_fuente_id)
      VALUES(?,?,?,1,?,?,?,'noche',?,?,?,?,?,?,?,?)`, 'R-' + siguienteFolio('reservacion'), h.id, txt(nombre, 100), e.inicio, cfg('reserva_hora_llegada') || '15:00', e.fin, noches, precio, r2(precio * noches),
    fu.canal, txt(`Viene de ${fu.canal}: revise en la extranet si ya pagó.${e.desc ? ' ' + e.desc : ''}`, 300), ahora(), e.uid, fu.id);
    nuevas++;
  }
  // Si ya no aparece en la plataforma (y todavía no llega), se canceló allá
  for (const r of all("SELECT * FROM reservaciones WHERE ical_fuente_id=? AND estado='pendiente' AND llegada > ?", fu.id, t))
    if (!vistos.has(r.ical_uid)) { run("UPDATE reservaciones SET estado='cancelada', cancelado=?, motivo=? WHERE id=?", ahora(), `Cancelada en ${fu.canal}`, r.id); canceladas++; }
  return { nuevas, cambios, canceladas, choques };
}
async function sincronizarIcal(soloId) {
  const res = [];
  for (const fu of all(`SELECT * FROM ical_fuentes WHERE activo=1 ${soloId ? 'AND id=' + Number(soloId) : ''}`)) {
    let resultado;
    try {
      const ctl = new AbortController(), tm = setTimeout(() => ctl.abort(), 20000);
      const r = await fetch(fu.url, { signal: ctl.signal, headers: { 'User-Agent': 'MaxselHotel/1.9' } }).finally(() => clearTimeout(tm));
      if (!r.ok) throw new Error('la plataforma respondió ' + r.status);
      const texto = await r.text();
      if (!/BEGIN:VCALENDAR/.test(texto)) throw new Error('la dirección no es un calendario (.ics)');
      const ev = leerIcal(texto), x = tx(() => aplicarIcal(fu, ev));
      resultado = `OK · ${ev.length} evento(s) · ${x.nuevas} nueva(s), ${x.cambios} cambio(s), ${x.canceladas} cancelada(s)${x.choques ? ` · ¡${x.choques} se enciman con otra reservación!` : ''}`;
      run('UPDATE ical_fuentes SET ultimo=?, resultado=?, eventos=? WHERE id=?', ahora(), resultado, ev.length, fu.id);
    } catch (e) {
      resultado = 'Error: ' + (e.name === 'AbortError' ? 'la plataforma no contestó' : e.message);
      run('UPDATE ical_fuentes SET ultimo=?, resultado=? WHERE id=?', ahora(), resultado, fu.id);
    }
    res.push({ id: fu.id, resultado });
  }
  return res;
}
setInterval(() => { sincronizarIcal().catch(() => {}); }, 30 * 60 * 1000).unref();
setTimeout(() => { sincronizarIcal().catch(() => {}); }, 20000).unref();
ruta('GET', '/api/ical', 'config', () => ({ token: tokenIcal(), publico: cfg('ical_publico') === '1', fuentes: all('SELECT f.*, h.numero FROM ical_fuentes f JOIN habitaciones h ON h.id=f.habitacion_id ORDER BY h.numero') }));
ruta('POST', '/api/ical/fuentes', 'config', ({ body }) => {
  const h = get('SELECT * FROM habitaciones WHERE id=?', Number(body.habitacion_id)); if (!h) throw new ErrorUsuario('Elija la habitación');
  const url = String(body.url || '').trim().replace(/^webcal:\/\//i, 'https://');
  if (!/^https?:\/\/\S+$/i.test(url)) throw new ErrorUsuario('Pegue el enlace del calendario (empieza con https://)');
  return { id: run('INSERT INTO ical_fuentes(habitacion_id,canal,url) VALUES(?,?,?)', h.id, CANALES.includes(body.canal) ? body.canal : 'Booking', url.slice(0, 1000)).id };
});
ruta('DELETE', '/api/ical/fuentes/:id', 'config', ({ p }) => { run('DELETE FROM ical_fuentes WHERE id=?', Number(p.id)); });
ruta('POST', '/api/ical/sincronizar', 'registrar', async ({ body }) => sincronizarIcal(body.id));
ruta('POST', '/api/ical/token', 'config', () => { setCfg('ical_token', crypto.randomBytes(12).toString('hex')); return { token: cfg('ical_token') }; });
// Calendario público de cada habitación: /ical/<clave>/<número>.ics  (?excluir=Booking para no regresarle sus propias reservaciones)
function icalPublico(res, url, r0) {
  const m = /^\/ical\/([a-f0-9]{16,64})\/([^/]+)\.ics$/.exec(r0);
  if (!m || !cfg('ical_token') || m[1] !== cfg('ical_token')) { res.writeHead(404); return res.end(); }
  const h = get('SELECT * FROM habitaciones WHERE numero=? AND activo=1', m[2]);
  if (!h) { res.writeHead(404); return res.end(); }
  const exc = CANALES.includes(url.searchParams.get('excluir')) ? url.searchParams.get('excluir') : null;
  res.writeHead(200, { 'Content-Type': 'text/calendar; charset=utf-8', 'Cache-Control': 'no-cache' });
  res.end(icalHabitacion(h, exc));
}

// ======================================================================
// Hotel 1.10: cambios de habitación · huéspedes por identificación y lista de no deseados · aviso de privacidad
//             tickets de limpieza · bitácora de movimientos · descuentos con límite por usuario · tipo de cambio
// ======================================================================
{
  const cols = (t) => all(`PRAGMA table_info(${t})`).map((c) => c.name);
  const add = (t, c, def) => { if (!cols(t).includes(c)) run(`ALTER TABLE ${t} ADD COLUMN ${c} ${def}`); };
  run(`CREATE TABLE IF NOT EXISTS cambios_habitacion (id INTEGER PRIMARY KEY, estancia_id INTEGER NOT NULL, de_id INTEGER, a_id INTEGER, fecha TEXT, usuario_id INTEGER, motivo TEXT)`);
  run('CREATE INDEX IF NOT EXISTS ix_cambios_est ON cambios_habitacion(estancia_id)');
  run('CREATE INDEX IF NOT EXISTS ix_cambios_fecha ON cambios_habitacion(fecha)');
  run(`CREATE TABLE IF NOT EXISTS huespedes (id INTEGER PRIMARY KEY, id_norm TEXT, identificacion TEXT, tipo_id TEXT, nombre TEXT NOT NULL, nombre_norm TEXT, telefono TEXT, tel_norm TEXT,
    domicilio TEXT, procedencia TEXT, placas TEXT, notas TEXT, visitas INTEGER DEFAULT 0, primera TEXT, ultima TEXT, creado TEXT, aviso TEXT,
    bloqueado INTEGER DEFAULT 0, motivo_bloqueo TEXT, bloqueo_fecha TEXT, bloqueo_usuario INTEGER)`);
  run('CREATE UNIQUE INDEX IF NOT EXISTS ux_hues_id ON huespedes(id_norm) WHERE id_norm IS NOT NULL');
  run('CREATE INDEX IF NOT EXISTS ix_hues_tel ON huespedes(tel_norm)');
  run('CREATE INDEX IF NOT EXISTS ix_hues_nom ON huespedes(nombre_norm)');
  run('CREATE INDEX IF NOT EXISTS ix_hues_bloq ON huespedes(bloqueado)');
  add('estancias', 'hab_inicial_id', 'INTEGER'); add('estancias', 'huesped_id', 'INTEGER'); add('estancias', 'aviso_privacidad', 'TEXT');
  add('estancias', 'descuento', 'REAL DEFAULT 0'); add('estancias', 'descuento_tipo', 'TEXT'); add('estancias', 'descuento_valor', 'REAL DEFAULT 0');
  add('estancias', 'descuento_motivo', 'TEXT'); add('estancias', 'descuento_usuario', 'INTEGER');
  add('usuarios', 'desc_max_pct', 'REAL DEFAULT 0'); add('usuarios', 'desc_max_monto', 'REAL DEFAULT 0');
  add('mantenimiento', 'tipo', "TEXT DEFAULT 'reparacion'"); add('mantenimiento', 'area', 'TEXT');
  run('UPDATE estancias SET hab_inicial_id=habitacion_id WHERE hab_inicial_id IS NULL');
  run(`CREATE TABLE IF NOT EXISTS auditoria (id INTEGER PRIMARY KEY, fecha TEXT, usuario_id INTEGER, usuario TEXT, accion TEXT, ruta TEXT, detalle TEXT, ip TEXT)`);
  run('CREATE INDEX IF NOT EXISTS ix_audit_fecha ON auditoria(fecha)');
  run('CREATE INDEX IF NOT EXISTS ix_estancias_hues ON estancias(huesped_id)');
}

// ---------- Huéspedes por identificación y lista de clientes no deseados ----------
const sinAcentos = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '');
const normId = (s) => { const t = sinAcentos(s).toUpperCase().replace(/[^A-Z0-9]/g, ''); return t.length >= 4 ? t : null; };
const normTel = (s) => { const t = String(s || '').replace(/\D/g, ''); return t.length >= 7 ? t.slice(-10) : null; };
const normNom = (s) => { const t = sinAcentos(s).toLowerCase().replace(/[^a-z0-9ñ ]/g, ' ').replace(/\s+/g, ' ').trim(); return t.length >= 5 ? t : null; };
const huespedJSON = (h) => h && ({ ...h, bloqueo_por: h.bloqueo_usuario ? get('SELECT nombre FROM usuarios WHERE id=?', h.bloqueo_usuario)?.nombre : null });
// Busca si la persona está en la lista de no deseados (por identificación, teléfono o nombre completo)
function noDeseado({ identificacion, telefono, huesped, nombre }) {
  const i = normId(identificacion), t = normTel(telefono), n = normNom(huesped || nombre);
  if (i) { const r = get('SELECT * FROM huespedes WHERE bloqueado=1 AND id_norm=?', i); if (r) return { ...huespedJSON(r), por: 'identificación' }; }
  if (t) { const r = get('SELECT * FROM huespedes WHERE bloqueado=1 AND tel_norm=?', t); if (r) return { ...huespedJSON(r), por: 'teléfono' }; }
  if (n) { const r = get('SELECT * FROM huespedes WHERE bloqueado=1 AND nombre_norm=?', n); if (r) return { ...huespedJSON(r), por: 'nombre' }; }
  return null;
}
// Al registrar: si es un cliente no deseado se detiene (solo gerente o administrador puede autorizarlo)
function revisarNoDeseado(body, u) {
  const nd = noDeseado(body);
  if (!nd) return null;
  if (body.autorizar_no_deseado && u.perm.has('autorizar')) return nd;
  throw new ErrorUsuario(`CLIENTE NO DESEADO: ${nd.nombre} (coincide por ${nd.por}). Motivo: ${nd.motivo_bloqueo || 'sin motivo'}. Solo un gerente o el administrador puede autorizar que se registre.`, 409);
}
// Guarda o actualiza al huésped en la base (por su identificación)
function guardarHuesped(b, cuando) {
  const i = normId(b.identificacion); if (!i) return null;
  const ya = get('SELECT * FROM huespedes WHERE id_norm=?', i);
  const d = { nombre: txt(b.huesped || b.nombre, 100), telefono: txt(b.telefono, 30), domicilio: txt(b.domicilio, 200), procedencia: txt(b.procedencia, 80), placas: txt(b.placas, 20), tipo_id: txt(b.tipo_id, 40) };
  if (ya) {
    run(`UPDATE huespedes SET nombre=COALESCE(?,nombre), nombre_norm=COALESCE(?,nombre_norm), telefono=COALESCE(?,telefono), tel_norm=COALESCE(?,tel_norm), domicilio=COALESCE(?,domicilio),
      procedencia=COALESCE(?,procedencia), placas=COALESCE(?,placas), tipo_id=COALESCE(?,tipo_id), identificacion=COALESCE(?,identificacion), visitas=visitas+?, ultima=?, aviso=COALESCE(?,aviso) WHERE id=?`,
    d.nombre, normNom(d.nombre), d.telefono, normTel(d.telefono), d.domicilio, d.procedencia, d.placas, d.tipo_id, txt(b.identificacion, 60), cuando ? 1 : 0, cuando || ya.ultima, b.acepto_aviso ? ahora() : null, ya.id);
    return ya.id;
  }
  if (!d.nombre) return null;
  return run(`INSERT INTO huespedes(id_norm,identificacion,tipo_id,nombre,nombre_norm,telefono,tel_norm,domicilio,procedencia,placas,visitas,primera,ultima,creado,aviso) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    i, txt(b.identificacion, 60), d.tipo_id, d.nombre, normNom(d.nombre), d.telefono, normTel(d.telefono), d.domicilio, d.procedencia, d.placas, cuando ? 1 : 0, cuando, cuando, ahora(), b.acepto_aviso ? ahora() : null).id;
}
// Mientras se captura el registro: datos guardados de ese huésped y alerta si es no deseado
ruta('GET', '/api/huespedes/revisar', 'sesion', ({ q }) => {
  const i = normId(q.identificacion);
  const h = i ? get('SELECT * FROM huespedes WHERE id_norm=?', i) : null;
  return { huesped: h ? { nombre: h.nombre, telefono: h.telefono, domicilio: h.domicilio, procedencia: h.procedencia, placas: h.placas, tipo_id: h.tipo_id, visitas: h.visitas, ultima: h.ultima } : null, no_deseado: noDeseado(q) };
});
ruta('GET', '/api/huespedes', 'sesion', ({ q }) => {
  const w = [], a = [];
  if (q.no_deseados) w.push('bloqueado=1');
  if (q.q) { const t = '%' + q.q + '%', n = '%' + (normNom(q.q) || sinAcentos(q.q).toLowerCase()) + '%'; w.push('(nombre LIKE ? OR nombre_norm LIKE ? OR identificacion LIKE ? OR telefono LIKE ? OR placas LIKE ?)'); a.push(t, n, t, t, t); }
  return all(`SELECT * FROM huespedes ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY ${q.no_deseados ? 'bloqueo_fecha DESC' : 'COALESCE(ultima, creado) DESC'} LIMIT 500`, ...a).map(huespedJSON);
});
ruta('GET', '/api/huespedes/:id', 'sesion', ({ p }) => {
  const h = huespedJSON(get('SELECT * FROM huespedes WHERE id=?', Number(p.id))); if (!h) throw new ErrorUsuario('No existe', 404);
  const estancias = all(`SELECT e.id, e.folio, e.entrada, e.salida_real, e.salida_prevista, e.modalidad, e.cantidad, e.total_hospedaje, e.activa, hb.numero FROM estancias e JOIN habitaciones hb ON hb.id=e.habitacion_id
    WHERE e.huesped_id=? OR (? IS NOT NULL AND e.identificacion IS NOT NULL AND upper(replace(replace(replace(e.identificacion,' ',''),'-',''),'.',''))=?) ORDER BY e.entrada DESC LIMIT 200`, h.id, h.id_norm, h.id_norm);
  return { ...h, estancias };
});
// Alta manual (por ejemplo, una persona que no debe hospedarse aunque nunca haya venido)
ruta('POST', '/api/huespedes', 'registrar', ({ body, u }) => tx(() => {
  const nombre = txt(body.nombre, 100); if (!nombre) throw new ErrorUsuario('Escriba el nombre');
  if (body.bloqueado && !u.perm.has('lista_negra')) throw new ErrorUsuario('Su usuario no puede agregar clientes no deseados');
  if (body.bloqueado && !txt(body.motivo_bloqueo)) throw new ErrorUsuario('Escriba el motivo');
  const i = normId(body.identificacion);
  let id = i ? get('SELECT id FROM huespedes WHERE id_norm=?', i)?.id : null;
  if (!id) id = run('INSERT INTO huespedes(id_norm,identificacion,tipo_id,nombre,nombre_norm,telefono,tel_norm,domicilio,procedencia,placas,notas,creado) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
    i, txt(body.identificacion, 60), txt(body.tipo_id, 40), nombre, normNom(nombre), txt(body.telefono, 30), normTel(body.telefono), txt(body.domicilio, 200), txt(body.procedencia, 80), txt(body.placas, 20), txt(body.notas, 300), ahora()).id;
  if (body.bloqueado) run('UPDATE huespedes SET bloqueado=1, motivo_bloqueo=?, bloqueo_fecha=?, bloqueo_usuario=? WHERE id=?', txt(body.motivo_bloqueo, 300), ahora(), u.id, id);
  return { id };
}));
ruta('PUT', '/api/huespedes/:id', 'registrar', ({ p, body }) => {
  const h = get('SELECT * FROM huespedes WHERE id=?', Number(p.id)); if (!h) throw new ErrorUsuario('No existe', 404);
  const nombre = txt(body.nombre, 100) || h.nombre, i = body.identificacion !== undefined ? normId(body.identificacion) : h.id_norm;
  if (i && i !== h.id_norm && get('SELECT id FROM huespedes WHERE id_norm=? AND id<>?', i, h.id)) throw new ErrorUsuario('Esa identificación ya está registrada con otro huésped');
  run('UPDATE huespedes SET nombre=?, nombre_norm=?, id_norm=?, identificacion=?, tipo_id=?, telefono=?, tel_norm=?, domicilio=?, procedencia=?, placas=?, notas=? WHERE id=?',
    nombre, normNom(nombre), i, body.identificacion !== undefined ? txt(body.identificacion, 60) : h.identificacion, txt(body.tipo_id, 40), txt(body.telefono, 30), normTel(body.telefono), txt(body.domicilio, 200), txt(body.procedencia, 80), txt(body.placas, 20), txt(body.notas, 300), h.id);
});
ruta('POST', '/api/huespedes/:id/bloquear', 'lista_negra', ({ p, body, u }) => {
  const motivo = txt(body.motivo, 300); if (!motivo) throw new ErrorUsuario('Escriba el motivo (por ejemplo: dañó la habitación, no pagó, problemas con otros huéspedes)');
  run('UPDATE huespedes SET bloqueado=1, motivo_bloqueo=?, bloqueo_fecha=?, bloqueo_usuario=? WHERE id=?', motivo, ahora(), u.id, Number(p.id));
});
ruta('POST', '/api/huespedes/:id/desbloquear', 'lista_negra', ({ p }) => { run('UPDATE huespedes SET bloqueado=0, motivo_bloqueo=NULL WHERE id=?', Number(p.id)); });
// Desde la cuenta de un huésped: agregarlo a no deseados aunque no haya dado identificación
ruta('POST', '/api/estancias/:id/no-deseado', 'lista_negra', ({ p, body, u }) => tx(() => {
  const e = get('SELECT * FROM estancias WHERE id=?', Number(p.id)); if (!e) throw new ErrorUsuario('No existe', 404);
  const motivo = txt(body.motivo, 300); if (!motivo) throw new ErrorUsuario('Escriba el motivo');
  let id = e.huesped_id || guardarHuesped(e, null);
  if (!id) id = run('INSERT INTO huespedes(identificacion,nombre,nombre_norm,telefono,tel_norm,domicilio,procedencia,placas,creado) VALUES(?,?,?,?,?,?,?,?,?)',
    e.identificacion, e.huesped, normNom(e.huesped), e.telefono, normTel(e.telefono), e.domicilio, e.procedencia, e.placas, ahora()).id;
  run('UPDATE huespedes SET bloqueado=1, motivo_bloqueo=?, bloqueo_fecha=?, bloqueo_usuario=? WHERE id=?', motivo, ahora(), u.id, id);
  run('UPDATE estancias SET huesped_id=? WHERE id=?', id, e.id);
  return { id };
}));

// ---------- Descuentos: el gerente y el administrador hasta el máximo del hotel; recepción hasta su propio límite ----------
function limiteDescuento(u) {
  if (u.rol === 'admin' || u.rol === 'gerente') return { pct: num(cfg('desc_max_pct')), monto: num(cfg('desc_max_monto')), general: true };
  const x = get('SELECT desc_max_pct, desc_max_monto FROM usuarios WHERE id=?', u.id) || {};
  return { pct: num(x.desc_max_pct), monto: num(x.desc_max_monto), general: false };
}
function calcularDescuento(body, base, u) {
  const v = num(body.descuento_valor), tipo = body.descuento_tipo === 'monto' ? 'monto' : 'pct';
  if (!(v > 0)) return null;
  const motivo = txt(body.descuento_motivo, 200);
  if (!motivo) throw new ErrorUsuario('Escriba el motivo del descuento');
  const monto = r2(Math.min(base, tipo === 'pct' ? base * v / 100 : v)), pct = base > 0 ? monto / base * 100 : 0;
  const L = limiteDescuento(u);
  // Por porcentaje se revisa el máximo en %; por cantidad, el máximo en pesos (el del hotel en 0 = sin límite en pesos, pero sin pasar del % máximo)
  const quien = L.general ? 'del hotel' : 'para su usuario';
  if (tipo === 'pct') {
    if (!(L.pct > 0)) throw new ErrorUsuario(L.general ? 'Los descuentos por porcentaje están desactivados (máximo del hotel en 0%).' : 'Su usuario no puede hacer descuentos por porcentaje. Pídale al gerente o al administrador.');
    if (v > L.pct + 0.001) throw new ErrorUsuario(`El descuento máximo ${quien} es ${L.pct}% (${money(base * L.pct / 100)} en esta renta)`);
  } else if (L.monto > 0) {
    if (monto > L.monto + 0.001) throw new ErrorUsuario(`El descuento máximo ${quien} es de ${money(L.monto)}`);
  } else if (!L.general) throw new ErrorUsuario('Su usuario no puede hacer descuentos en pesos. Pídale al gerente o al administrador.');
  else if (!(L.pct > 0) || pct > L.pct + 0.001) throw new ErrorUsuario(`El descuento máximo del hotel es ${L.pct}% (${money(base * L.pct / 100)} en esta renta)`);
  return { monto, tipo, valor: v, motivo };
}
const money = (n) => '$' + (Number(n) || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
ruta('GET', '/api/descuento/limite', 'sesion', ({ u }) => limiteDescuento(u));

// ---------- 1.21: avisos al celular del personal de limpieza y mantenimiento ----------
// Cada empleado se suscribe a su propio tema privado en la app gratuita "ntfy" (Android y iPhone).
// Cuando hay un trabajo nuevo (o se le asigna uno), el servidor le manda la notificación aunque tenga la pantalla apagada.
const AVISO_SERVIDOR = () => (cfg('aviso_servidor') || 'https://ntfy.sh').replace(/\/+$/, '');
function mandarAviso(tema, titulo, mensaje, prioridad) {
  return new Promise((resolve) => {
    if (!tema) return resolve(false);
    let u; try { u = new URL(AVISO_SERVIDOR()); } catch { return resolve(false); }
    const cuerpo = JSON.stringify({ topic: tema, title: titulo, message: mensaje, priority: prioridad, tags: ['bell'] });
    const mod = u.protocol === 'http:' ? http : https;
    const rq = mod.request({ hostname: u.hostname, port: u.port || undefined, path: (u.pathname === '/' ? '' : u.pathname) + '/', method: 'POST', timeout: 15000,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(cuerpo), 'User-Agent': 'MaxselHotel/' + VERSION } }, (rs) => { rs.resume(); resolve(rs.statusCode < 300); });
    rq.on('error', () => resolve(false)); rq.on('timeout', () => { rq.destroy(); resolve(false); });
    rq.end(cuerpo);
  });
}
// A quién le toca: la persona asignada, o todo el personal de ese tipo (limpieza o mantenimiento)
function destinatarios(m) {
  if (m.asignado_a) return all("SELECT id, nombre, aviso_tema FROM usuarios WHERE id=? AND activo=1 AND aviso_tema IS NOT NULL", m.asignado_a);
  return all("SELECT id, nombre, aviso_tema FROM usuarios WHERE activo=1 AND aviso_tema IS NOT NULL AND rol=?", m.tipo === 'limpieza' ? 'limpieza' : 'mantenimiento');
}
let avisando = false;
async function avisarPendientes() {
  if (avisando) return; avisando = true;
  try {
    const l = all(`SELECT m.*, h.numero, ua.rol alta_rol FROM mantenimiento m LEFT JOIN habitaciones h ON h.id=m.habitacion_id LEFT JOIN usuarios ua ON ua.id=m.alta_usuario
      WHERE m.estado<>'terminado' AND m.avisado IS NULL ORDER BY m.id LIMIT 30`);
    for (const m of l) {
      run("UPDATE mantenimiento SET avisado=? WHERE id=?", ahora(), m.id);
      const limp = m.tipo === 'limpieza';
      const titulo = (m.prioridad === 'urgente' ? 'URGENTE · ' : '') + (limp ? 'Limpieza' : 'Mantenimiento') + (m.numero ? ' · Hab. ' + m.numero : m.area ? ' · ' + m.area : '');
      const msg = (m.titulo || '') + (m.descripcion ? '\n' + String(m.descripcion).slice(0, 300) : '') + '\nFolio ' + m.folio;
      const prio = m.prioridad === 'urgente' ? 5 : m.prioridad === 'alta' ? 4 : 3;
      for (const d of destinatarios(m)) if (!(m.alta_usuario && m.alta_usuario === d.id)) await mandarAviso(d.aviso_tema, titulo, msg, prio);
    }
  } catch (e) { console.error('Avisos al celular:', e.message); } finally { avisando = false; }
}
setInterval(() => { avisarPendientes(); }, 20 * 1000).unref();
function avisarYa() { setTimeout(() => { avisarPendientes(); }, 300); }
ruta('GET', '/api/avisos', 'todos', ({ u }) => {
  const x = get('SELECT aviso_tema FROM usuarios WHERE id=?', u.id);
  return { activo: !!x?.aviso_tema, tema: x?.aviso_tema || null, servidor: AVISO_SERVIDOR() };
});
ruta('POST', '/api/avisos/activar', 'todos', async ({ u }) => {
  let t = get('SELECT aviso_tema FROM usuarios WHERE id=?', u.id)?.aviso_tema;
  if (!t) { t = 'maxsel-' + crypto.randomBytes(12).toString('hex'); run('UPDATE usuarios SET aviso_tema=? WHERE id=?', t, u.id); }
  return { activo: true, tema: t, servidor: AVISO_SERVIDOR() };
});
ruta('POST', '/api/avisos/prueba', 'todos', async ({ u }) => {
  const t = get('SELECT aviso_tema FROM usuarios WHERE id=?', u.id)?.aviso_tema;
  if (!t) throw new ErrorUsuario('Primero active las notificaciones');
  const ok = await mandarAviso(t, 'Maxsel Hotel · prueba', 'Hola ' + u.nombre + ', así le van a llegar sus trabajos nuevos.', 4);
  if (!ok) throw new ErrorUsuario('No se pudo mandar. Revise que la computadora del hotel tenga internet.');
  return { ok: true };
});
ruta('POST', '/api/avisos/desactivar', 'todos', ({ u }) => { run('UPDATE usuarios SET aviso_tema=NULL WHERE id=?', u.id); return { activo: false }; });

// ---------- Tickets de limpieza (habitaciones y áreas comunes), junto con mantenimiento ----------
// Cada habitación que queda "en limpieza" tiene su ticket; al marcarla lista (o al cerrar el ticket con su evidencia) se cierra solo.
// 1.11: tareas de limpieza con evidencia (habitación, área común, lavandería de blancos, otro)
{
  const c = all('PRAGMA table_info(mantenimiento)').map((x) => x.name);
  for (const [k, t] of [['subtipo', 'TEXT'], ['blancos', 'TEXT'], ['destino', 'TEXT'], ['ligado', 'INTEGER DEFAULT 0']]) if (!c.includes(k)) run(`ALTER TABLE mantenimiento ADD COLUMN ${k} ${t}`);
  run("UPDATE mantenimiento SET subtipo=CASE WHEN habitacion_id IS NOT NULL THEN 'habitacion' ELSE 'area' END WHERE tipo='limpieza' AND subtipo IS NULL");
  run("UPDATE mantenimiento SET ligado=1 WHERE tipo='limpieza' AND alta_usuario IS NULL AND COALESCE(ligado,0)=0 AND estado<>'terminado'");
}
setCfg('ticket_logo_maxsel', '1'); // si alguien lo había quitado, vuelve a salir
function sincronizarLimpieza() {
  if (cfg('tickets_limpieza') === '0') return;
  const t = ahora();
  for (const h of all(`SELECT h.id, h.numero FROM habitaciones h WHERE h.activo=1 AND h.estado='limpieza'
    AND NOT EXISTS (SELECT 1 FROM mantenimiento m WHERE m.habitacion_id=h.id AND m.tipo='limpieza' AND m.estado<>'terminado')`)) {
    const id = run("INSERT INTO mantenimiento(folio,habitacion_id,titulo,descripcion,prioridad,estado,alta,alta_usuario,tipo,subtipo,ligado) VALUES(?,?,?,?,?,?,?,?,'limpieza','habitacion',1)",
      siguienteFolio('mant'), h.id, 'Limpieza de habitación', 'Se levantó solo al quedar la habitación en limpieza.', 'normal', 'pendiente', t, null).id;
    void id;
  }
  // La marcaron lista (o volvió a ocuparse) sin cerrar el ticket: se cierra con la nota de quién la liberó
  for (const m of all(`SELECT m.*, h.estado FROM mantenimiento m JOIN habitaciones h ON h.id=m.habitacion_id WHERE m.tipo='limpieza' AND m.estado<>'terminado' AND h.estado<>'limpieza' AND (m.ligado=1 OR m.alta_usuario IS NULL)`)) {
    const b = get("SELECT b.usuario_id, u.nombre FROM bitacora b LEFT JOIN usuarios u ON u.id=b.usuario_id WHERE b.habitacion_id=? AND b.estado='libre' ORDER BY b.id DESC LIMIT 1", m.habitacion_id);
    run("UPDATE mantenimiento SET estado='terminado', inicio=COALESCE(inicio,?), cierre=?, cierre_usuario=?, nota_cierre=? WHERE id=?", t, t, b?.usuario_id ?? null,
      m.estado === 'libre' ? `Marcada lista en recepción${b?.nombre ? ' por ' + b.nombre : ''} (sin fotos)` : 'La habitación se volvió a ocupar', m.id);
  }
}
setInterval(() => { try { sincronizarLimpieza(); } catch (e) { console.error('Limpieza:', e.message); } }, 60 * 1000).unref();
setTimeout(() => { try { sincronizarLimpieza(); } catch { /* nada */ } }, 5000).unref();

// ---------- Tipo de cambio: solo el administrador lo cambia (aplica a las cajas abiertas) ----------
ruta('PUT', '/api/tipo-cambio', 'config', ({ body }) => {
  const tc = num(body.tipo_cambio); if (!(tc > 0)) throw new ErrorUsuario('Tipo de cambio inválido');
  setCfg('tipo_cambio', tc);
  run("UPDATE turnos SET tipo_cambio=? WHERE estado='abierto'", tc);
  return { tipo_cambio: tc };
});

// ---------- Reportes: cambios de habitación y descuentos ----------
function cambiosPeriodo(d, h) {
  return all(`SELECT c.*, e.folio, e.huesped, ha.numero de_num, hb.numero a_num, hi.numero inicial, u.nombre usuario FROM cambios_habitacion c JOIN estancias e ON e.id=c.estancia_id
    LEFT JOIN habitaciones ha ON ha.id=c.de_id LEFT JOIN habitaciones hb ON hb.id=c.a_id LEFT JOIN habitaciones hi ON hi.id=e.hab_inicial_id LEFT JOIN usuarios u ON u.id=c.usuario_id
    WHERE substr(c.fecha,1,10) BETWEEN ? AND ? ORDER BY c.fecha`, d, h);
}
function descuentosPeriodo(d, h) {
  const l = all(`SELECT e.id, e.folio, e.entrada fecha, e.huesped, e.descuento, e.descuento_tipo, e.descuento_valor, e.descuento_motivo, e.total_hospedaje, hb.numero, u.nombre usuario FROM estancias e
    LEFT JOIN habitaciones hb ON hb.id=e.habitacion_id LEFT JOIN usuarios u ON u.id=e.descuento_usuario WHERE e.descuento>0 AND substr(e.entrada,1,10) BETWEEN ? AND ? ORDER BY e.entrada`, d, h);
  const porUsuario = {}; for (const x of l) { const k = x.usuario || '—', y = porUsuario[k] || (porUsuario[k] = { usuario: k, n: 0, total: 0 }); y.n++; y.total = r2(y.total + x.descuento); }
  return { n: l.length, total: r2(l.reduce((s, x) => s + x.descuento, 0)), por_usuario: Object.values(porUsuario), lista: l };
}
ruta('GET', '/api/reporte/cambios', 'reportes', ({ q }) => cambiosPeriodo(q.desde || hoy(), q.hasta || q.desde || hoy()));
{
  const blancosDe = (m) => { try { return JSON.parse(m.blancos || '{}'); } catch { return {}; } };
  // 1.11: limpieza del periodo (por tipo, por persona y blancos a lavandería)
  var limpiezaPeriodo = function (d, h) {
    const L = all(`SELECT m.id, m.folio, m.titulo, m.subtipo, m.habitacion_id, m.area, m.blancos, m.destino, m.alta, m.cierre, m.nota_cierre, hb.numero, uc.nombre cierre_nombre,
      (SELECT COUNT(*) FROM mant_fotos f WHERE f.mant_id=m.id AND f.tipo='evidencia') fotos
      FROM mantenimiento m LEFT JOIN habitaciones hb ON hb.id=m.habitacion_id LEFT JOIN usuarios uc ON uc.id=m.cierre_usuario
      WHERE m.tipo='limpieza' AND m.estado='terminado' AND substr(m.cierre,1,10) BETWEEN ? AND ? ORDER BY m.cierre`, d, h);
    const por = { habitacion: 0, area: 0, lavanderia: 0, otro: 0 }, pers = {}, faltan = {}; let env = 0, rec = 0, conFoto = 0;
    for (const m of L) {
      const s2 = m.subtipo || (m.habitacion_id ? 'habitacion' : 'area'); por[s2] = (por[s2] || 0) + 1; if (m.fotos) conFoto++;
      const n = m.cierre_nombre || '—'; pers[n] = pers[n] || { nombre: n, habitacion: 0, area: 0, lavanderia: 0, otro: 0, total: 0 }; pers[n][s2]++; pers[n].total++;
      if (s2 === 'lavanderia') for (const [k, v] of Object.entries(blancosDe(m))) { env += v.env || 0; rec += v.rec ?? 0; if ((v.rec ?? 0) < v.env) faltan[k] = (faltan[k] || 0) + v.env - (v.rec ?? 0); }
    }
    let fuera = 0; for (const m of all("SELECT blancos FROM mantenimiento WHERE tipo='limpieza' AND subtipo='lavanderia' AND estado<>'terminado'")) for (const v of Object.values(blancosDe(m))) fuera += v.env || 0;
    return { total: L.length, por, con_foto: conFoto, personas: Object.values(pers).sort((a, b) => b.total - a.total),
      blancos: { enviadas: env, regresaron: rec, faltan: Object.entries(faltan).map(([k, n]) => ({ pieza: k, n })), en_lavanderia: fuera },
      lista: L.filter((m) => m.subtipo && m.subtipo !== 'habitacion').map((m) => ({ ...m, blancos: blancosDe(m) })) };
  };
  const _ext2 = extrasPeriodo;
  extrasPeriodo = function (d, h) { return { ..._ext2(d, h), cambios: cambiosPeriodo(d, h), descuentos: descuentosPeriodo(d, h), limpieza: limpiezaPeriodo(d, h) }; };
}

// ---------- Bitácora de movimientos (quién hizo qué y cuándo) ----------
const ACCIONES = [
  ['POST /api/login', 'Entró al sistema'], ['POST /api/logout', 'Salió del sistema'],
  ['POST /api/estancias', 'Registró huésped'], ['PUT /api/estancias/:id', 'Cambió datos del huésped'], ['POST /api/estancias/:id/extender', 'Extendió / cambió la renta'],
  ['POST /api/estancias/:id/cambiar', 'Cambió de habitación al huésped'], ['POST /api/estancias/:id/salida', 'Registró la salida'], ['POST /api/estancias/:id/pago', 'Cobró / abonó a la cuenta'],
  ['POST /api/estancias/:id/cargo', 'Cargó multa o cuota'], ['DELETE /api/cargos/:id', 'Quitó una multa o cargo'], ['POST /api/estancias/:id/deposito', 'Depósito en garantía'],
  ['POST /api/estancias/:id/no-deseado', 'Agregó a clientes no deseados'],
  ['POST /api/visitantes', 'Registró visitante'], ['POST /api/ventas', 'Venta de tienda'], ['POST /api/ventas/:id/cancelar', 'Canceló venta'],
  ['POST /api/turno/abrir', 'Abrió turno de caja'], ['POST /api/turno/cerrar', 'Cerró turno de caja'], ['POST /api/turno/movimiento', 'Ingreso / egreso de caja'],
  ['PUT /api/tipo-cambio', 'Cambió el tipo de cambio'], ['POST /api/gastos', 'Registró gasto'], ['POST /api/gastos/:id/cancelar', 'Canceló gasto'],
  ['POST /api/habitaciones/:id/estado', 'Cambió estado de habitación'], ['POST /api/habitaciones', 'Agregó habitación'], ['PUT /api/habitaciones/:id', 'Cambió habitación / precios'],
  ['POST /api/habitaciones/lote', 'Agregó o importó habitaciones'], ['PUT /api/habitaciones/lote', 'Cambió varias habitaciones'], ['DELETE /api/habitaciones/:id', 'Borró habitación'],
  ['POST /api/reservaciones', 'Hizo reservación'], ['PUT /api/reservaciones/:id', 'Cambió reservación'], ['POST /api/reservaciones/:id/anticipo', 'Anticipo de reservación'],
  ['POST /api/reservaciones/:id/cancelar', 'Canceló reservación'], ['POST /api/mant', 'Levantó ticket de mantenimiento / limpieza'], ['POST /api/mant/:id/cerrar', 'Cerró ticket de mantenimiento / limpieza'],
  ['POST /api/usuarios', 'Creó usuario'], ['PUT /api/usuarios/:id', 'Cambió usuario / permisos'], ['PUT /api/config', 'Cambió la configuración'],
  ['POST /api/huespedes', 'Dio de alta un huésped'], ['PUT /api/huespedes/:id', 'Cambió datos de un huésped'], ['POST /api/huespedes/:id/bloquear', 'Puso en clientes no deseados'],
  ['POST /api/huespedes/:id/desbloquear', 'Quitó de clientes no deseados'], ['POST /api/productos', 'Agregó producto'], ['PUT /api/productos/:id', 'Cambió producto'],
  ['DELETE /api/productos/:id', 'Borró producto'], ['POST /api/productos/:id/entrada', 'Entrada de mercancía'], ['POST /api/gastos-fijos/:id/pagar', 'Pagó gasto fijo'], ['POST /api/cuentas-pagar/:id/pagar', 'Pagó cuenta a proveedor'], ['POST /api/estancias/:id/deposito/liquidar', 'Devolvió / retuvo depósito'], ['POST /api/visitantes/:id/salida', 'Salida de visitante'], ['POST /api/cajon', 'Abrió el cajón'], ['POST /api/contratos', 'Hizo contrato'], ['POST /api/empleados', 'Agregó empleado'], ['PUT /api/empleados/:id', 'Cambió empleado'], ['POST /api/licencia/activar', 'Activó licencia'], ['POST /api/mi-password', 'Cambió su contraseña'], ['POST /api/reservaciones/:id/anticipo', 'Anticipo de reservación'], ['POST /api/inventarios', 'Conteo de inventario'], ['POST /api/nomina', 'Pagó nómina'],
  ['POST /api/cierre', 'Cerró el mes'], ['POST /api/respaldos', 'Hizo respaldo'],
].map(([k, t]) => { const [m, r] = k.split(' '); return { m, re: new RegExp('^' + r.replace(/:id/g, '\\d+') + '$'), t }; });
const SECRETO = /pass|clave|token|firma|foto|logo|imagen|huella|plantilla|nueva|autoriza/i;
function limpiarDetalle(b, nivel = 0) {
  if (b === null || b === undefined) return b;
  if (typeof b === 'string') return b.length > 120 ? b.slice(0, 120) + '…' : b;
  if (typeof b !== 'object') return b;
  if (Array.isArray(b)) return b.length > 8 ? [...b.slice(0, 8).map((x) => limpiarDetalle(x, nivel + 1)), `…y ${b.length - 8} más`] : b.map((x) => limpiarDetalle(x, nivel + 1));
  if (nivel > 2) return '…';
  const o = {}; for (const [k, v] of Object.entries(b)) o[k] = SECRETO.test(k) ? (v ? '[oculto]' : v) : limpiarDetalle(v, nivel + 1);
  return o;
}
function auditar(u, req, r0, body, out) {
  try {
    const a = ACCIONES.find((x) => x.m === req.method && x.re.test(r0));
    const extra = [];
    const hb = body?.habitacion_id ? get('SELECT numero FROM habitaciones WHERE id=?', Number(body.habitacion_id))?.numero : null;
    if (hb) extra.push('hab. ' + hb);
    if (body?.huesped) extra.push(String(body.huesped).slice(0, 60));
    const est = /\/api\/estancias\/(\d+)/.exec(r0); if (est && !hb) { const e = get('SELECT e.huesped, h.numero FROM estancias e JOIN habitaciones h ON h.id=e.habitacion_id WHERE e.id=?', Number(est[1])); if (e) extra.push('hab. ' + e.numero + ' · ' + e.huesped); }
    for (const k of ['monto', 'pago', 'anticipo', 'total', 'costo']) if (num(body?.[k]) > 0) { extra.push(money(body[k])); break; }
    if (body?.descuento_valor > 0) extra.push(`descuento ${body.descuento_tipo === 'monto' ? money(body.descuento_valor) : body.descuento_valor + '%'} (${body.descuento_motivo || ''})`);
    if (body?.motivo) extra.push(String(body.motivo).slice(0, 80));
    if (!u && body?.usuario) { const x = get('SELECT id, nombre FROM usuarios WHERE usuario=?', String(body.usuario).toLowerCase()); if (x) u = { id: x.id, nombre: x.nombre }; }
    const usuario = u ? u.nombre : (body?.usuario ? 'usuario ' + String(body.usuario).slice(0, 40) : '—');
    run('INSERT INTO auditoria(fecha,usuario_id,usuario,accion,ruta,detalle,ip) VALUES(?,?,?,?,?,?,?)', ahora(), u?.id ?? null, usuario,
      (a ? a.t : req.method + ' ' + r0.replace(/^\/api\//, '')) + (extra.length ? ' · ' + extra.join(' · ') : ''), req.method + ' ' + r0, JSON.stringify(limpiarDetalle(body || {})).slice(0, 800), ipDe(req));
  } catch (e) { console.error('Bitácora:', e.message); }
}
ruta('GET', '/api/auditoria', 'bitacora', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d, w = ['substr(fecha,1,10) BETWEEN ? AND ?'], a = [d, h];
  if (q.usuario_id) { w.push('usuario_id=?'); a.push(Number(q.usuario_id)); }
  if (q.q) { w.push('(accion LIKE ? OR detalle LIKE ?)'); a.push('%' + q.q + '%', '%' + q.q + '%'); }
  return { lista: all(`SELECT * FROM auditoria WHERE ${w.join(' AND ')} ORDER BY id DESC LIMIT 3000`, ...a), usuarios: all('SELECT id, nombre FROM usuarios ORDER BY nombre') };
});
const SIN_BITACORA = /^(POST \/api\/(importar|actualizacion\/instalar|asistencia\/checar|huella\/checar|reservaciones\/revisar|imprimir|ical\/sincronizar|recuperar-password))$/;

// ---------- 1.13: actualizaciones por internet (igual que Maxsel POS) ----------
// Baja version.json de github.com/mlunq23/maxsel-actualizaciones (público, solo paquetes); el .zip trae los archivos del programa
// (sin node.exe, sin licencia y sin la carpeta datos). Se revisa la huella SHA-256 antes de instalar y se guarda un respaldo para regresar.
const UPD_BASE = 'https://raw.githubusercontent.com/mlunq23/maxsel-actualizaciones/main/', UPD_DIR = path.join(DATA_DIR, 'actualizacion');
const NO_TOCAR = /^(datos\/|node_modules\/|licencia\.js$|generador\/)/i;
const verCmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 4; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
function httpsBajar(url, max, redirs = 0) {
  // Solo para pruebas de Maxsel: lee los paquetes de una carpeta local en vez de internet
  if (process.env.MAXSEL_UPD_PRUEBA) return Promise.resolve().then(() => fs.readFileSync(path.join(process.env.MAXSEL_UPD_PRUEBA, path.basename(url.split('?')[0]))));
  return new Promise((resolve, reject) => {
    if (!/^https:\/\/raw\.githubusercontent\.com\/mlunq23\/maxsel-actualizaciones\//.test(url)) return reject(new ErrorUsuario('Dirección no permitida'));
    https.get(url, { timeout: 30000, headers: { 'Cache-Control': 'no-cache', 'User-Agent': 'MaxselHotel/' + VERSION } }, (rs) => {
      if ([301, 302, 303, 307, 308].includes(rs.statusCode) && rs.headers.location && redirs < 4) { rs.resume(); return resolve(httpsBajar(new URL(rs.headers.location, url).href, max, redirs + 1)); }
      if (rs.statusCode !== 200) { rs.resume(); return reject(new ErrorUsuario('El servidor de Maxsel respondió ' + rs.statusCode)); }
      const ch = []; let n = 0;
      rs.on('data', (c) => { n += c.length; if (n > max) { rs.destroy(); reject(new ErrorUsuario('Archivo demasiado grande')); } else ch.push(c); });
      rs.on('end', () => resolve(Buffer.concat(ch))); rs.on('error', reject);
    }).on('timeout', function () { this.destroy(new ErrorUsuario('Sin respuesta (revise el internet)')); })
      .on('error', (e) => reject(e instanceof ErrorUsuario ? e : new ErrorUsuario(/ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ENETUNREACH|ECONNRESET/.test(e.code || '') ? 'Sin internet. Conecte la computadora a internet e intente de nuevo.' : e.message)));
  });
}
async function versionDisponible() {
  const j = JSON.parse((await httpsBajar(UPD_BASE + 'version.json?t=' + Date.now(), 256 * 1024)).toString('utf8'));
  const e = j.hotel;
  if (!e || !e.ver) return { instalada: VERSION, hay: false };
  const hay = verCmp(e.ver, VERSION) > 0 && /^[\w.-]+\.zip$/.test(e.win || '') && /^[0-9a-f]{64}$/i.test(e.winSha || '');
  setCfg('upd_disponible', hay ? String(e.ver) : '');
  return { instalada: VERSION, disponible: String(e.ver), notas: String(e.notas || ''), hay, _e: e };
}
function leerZip(buf) {
  let e = buf.length - 22; while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) throw new ErrorUsuario('El paquete de actualización está dañado');
  const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const out = [];
  for (let i = 0; i < n; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new ErrorUsuario('El paquete de actualización está dañado');
    const met = buf.readUInt16LE(p + 10), cs = buf.readUInt32LE(p + 20), nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const nom = buf.toString('utf8', p + 46, p + 46 + nl).replace(/\\/g, '/'); p += 46 + nl + xl + cl;
    if (nom.endsWith('/')) continue;
    if (buf.readUInt32LE(lo) !== 0x04034b50) throw new ErrorUsuario('El paquete de actualización está dañado');
    const s0 = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28), raw = buf.subarray(s0, s0 + cs);
    const dat = met === 0 ? raw : met === 8 ? zlib.inflateRawSync(raw) : null;
    if (!dat) throw new ErrorUsuario('Formato de paquete no soportado');
    out.push({ nom, dat });
  }
  if (!out.length) throw new ErrorUsuario('El paquete de actualización viene vacío');
  return out;
}
let actualizando = false;
async function instalarActualizacion(u) {
  if (actualizando) throw new ErrorUsuario('Ya se está instalando una actualización');
  actualizando = true;
  try {
    const v = await versionDisponible();
    if (!v.hay) throw new ErrorUsuario(`Ya tiene la versión más reciente (${VERSION}).`);
    const zip = await httpsBajar(UPD_BASE + v._e.win, 80 * 1024 * 1024);
    if (crypto.createHash('sha256').update(zip).digest('hex') !== String(v._e.winSha).toLowerCase()) throw new ErrorUsuario('El archivo descargado no es válido. Intente de nuevo.');
    const archivos = leerZip(zip).filter((f) => !NO_TOCAR.test(f.nom) && !f.nom.split('/').includes('..'));
    if (!archivos.some((f) => f.nom === 'server.js')) throw new ErrorUsuario('El paquete de actualización no es de Maxsel Hotel');
    // Respaldo de lo que hay ahora (para regresar si algo falla)
    const bk = path.join(UPD_DIR, 'respaldo_' + VERSION); fs.rmSync(bk, { recursive: true, force: true }); fs.mkdirSync(bk, { recursive: true });
    const raiz = path.resolve(DIR) + path.sep, escritos = [];
    try {
      for (const f of archivos) {
        const d = path.resolve(DIR, f.nom); if (!d.startsWith(raiz)) continue;
        if (fs.existsSync(d)) { fs.mkdirSync(path.dirname(path.join(bk, f.nom)), { recursive: true }); fs.copyFileSync(d, path.join(bk, f.nom)); }
        fs.mkdirSync(path.dirname(d), { recursive: true }); fs.writeFileSync(d + '.nuevo', f.dat); escritos.push(d);
      }
      // se cambian todos juntos al final; si Windows o el antivirus tienen un archivo ocupado, se reintenta
      const espera = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
      for (const d of escritos) for (let i = 0; ; i++) { try { fs.renameSync(d + '.nuevo', d); break; } catch (e) { if (i >= 20) throw e; espera(300); } }
      // se comprueba que cada archivo quedó igual al del paquete antes de reiniciar
      const h = (b) => crypto.createHash('sha256').update(b).digest('hex');
      for (const f of archivos) { const d = path.resolve(DIR, f.nom); if (d.startsWith(raiz) && h(fs.readFileSync(d)) !== h(f.dat)) throw new Error('el archivo ' + f.nom + ' no quedó bien escrito'); }
    } catch (e) {
      for (const d of escritos) { try { fs.rmSync(d + '.nuevo', { force: true }); } catch { /* nada */ } }
      for (const f of archivos) { const b = path.join(bk, f.nom); if (fs.existsSync(b)) try { fs.copyFileSync(b, path.resolve(DIR, f.nom)); } catch { /* nada */ } }
      throw new ErrorUsuario('No se pudo instalar la actualización: ' + e.message);
    }
    fs.writeFileSync(path.join(UPD_DIR, 'estado.json'), JSON.stringify({ de: VERSION, a: v.disponible, fecha: ahora(), usuario: u?.nombre || '', archivos: escritos.length }));
    console.log(`  [${ahora()}] Actualización ${VERSION} → ${v.disponible} instalada (${escritos.length} archivos). Reiniciando...`);
    setTimeout(() => process.exit(0), 1500).unref?.();
    return { ok: true, de: VERSION, a: v.disponible, archivos: escritos.length, servicio: !!process.env.MAXSEL_SERVICIO };
  } finally { actualizando = false; }
}
ruta('GET', '/api/actualizacion', 'config', async () => { const { _e, ...v } = await versionDisponible(); return v; });
ruta('POST', '/api/actualizacion/instalar', 'config', ({ u }) => instalarActualizacion(u));
// Al arrancar después de actualizar: se anota en la bitácora
try {
  const f = path.join(UPD_DIR, 'estado.json');
  if (fs.existsSync(f)) {
    const i = JSON.parse(fs.readFileSync(f, 'utf8'));
    run('INSERT INTO auditoria(fecha,usuario_id,usuario,accion,ruta,detalle,ip) VALUES(?,?,?,?,?,?,?)', ahora(), null, i.usuario || '—',
      verCmp(VERSION, i.a) >= 0 ? `Actualizó el sistema de la versión ${i.de} a la ${VERSION}` : `La actualización a la ${i.a} no quedó (sigue la ${VERSION})`, 'POST /api/actualizacion/instalar', JSON.stringify(i).slice(0, 800), '');
    fs.unlinkSync(f);
  }
  if (cfg('upd_disponible') && verCmp(cfg('upd_disponible'), VERSION) <= 0) setCfg('upd_disponible', '');
} catch { /* nada */ }
// Revisa solo si hay versión nueva (cada 6 horas, si hay internet) para avisarle al administrador
const revisarActualizacion = () => versionDisponible().catch(() => {});
setTimeout(revisarActualizacion, 90 * 1000).unref();
setInterval(revisarActualizacion, 6 * 60 * 60 * 1000).unref();

// ---------- 1.12: comparativo de ventas (línea de tiempo y % contra el periodo anterior) ----------
const isoD = (dt) => `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
const difDias = (a, b) => Math.round((aFecha(b) - aFecha(a)) / 864e5);
const pct = (a, b) => (b > 0 ? Math.round(((a - b) / b) * 1000) / 10 : a > 0 ? null : 0);
function periodoVentas(d, h, gran) {
  const n = difDias(d, h) + 1, pagos = all("SELECT substr(fecha,1,10) f, concepto, monto FROM pagos WHERE substr(fecha,1,10) BETWEEN ? AND ?", d, h);
  const cubo = (f) => (gran === 'dia' ? difDias(d, f) : gran === 'semana' ? Math.floor(difDias(d, f) / 7) : (Number(f.slice(0, 4)) - Number(d.slice(0, 4))) * 12 + Number(f.slice(5, 7)) - Number(d.slice(5, 7)));
  const nb = cubo(h) + 1, serie = Array.from({ length: nb }, (_, i) => ({ i, desde: gran === 'dia' ? sumarDias(d, i) : gran === 'semana' ? sumarDias(d, i * 7) : null, total: 0, hospedaje: 0, tienda: 0, otros: 0 }));
  if (gran === 'mes') serie.forEach((x, i) => { const dt = aFecha(d.slice(0, 7) + '-01'); dt.setMonth(dt.getMonth() + i); x.desde = isoD(dt) < d ? d : isoD(dt); });
  const T = { total: 0, hospedaje: 0, tienda: 0, visitas: 0, otros: 0 }, dow = [0, 0, 0, 0, 0, 0, 0], porDia = {};
  for (const p of pagos) {
    const k = p.concepto === 'hospedaje' ? 'hospedaje' : p.concepto === 'tienda' ? 'tienda' : 'otros', b = serie[cubo(p.f)];
    if (b) { b.total += p.monto; b[k] += p.monto; }
    T.total += p.monto; if (p.concepto === 'visita') T.visitas += p.monto; else T[k] += p.monto;
    dow[aFecha(p.f).getDay()] += p.monto; porDia[p.f] = (porDia[p.f] || 0) + p.monto;
  }
  serie.forEach((x) => { for (const k of ['total', 'hospedaje', 'tienda', 'otros']) x[k] = r2(x[k]); });
  for (const k in T) T[k] = r2(T[k]);
  const rentas = get('SELECT COUNT(*) n FROM estancias WHERE substr(entrada,1,10) BETWEEN ? AND ?', d, h).n;
  // Noches ocupadas dentro del periodo (para la ocupación)
  let noches = 0; const fin = sumarDias(h, 1);
  for (const e of all("SELECT substr(entrada,1,10) a, substr(COALESCE(salida_real, salida_prevista),1,10) b FROM estancias WHERE substr(entrada,1,10)<=? AND substr(COALESCE(salida_real, salida_prevista),1,10)>=?", h, d)) {
    const a = e.a > d ? e.a : d, b = e.b < fin ? e.b : fin; noches += Math.max(0, difDias(a, b)) || (e.a === e.b && e.a >= d && e.a <= h ? 1 : 0);
  }
  const nh = get('SELECT COUNT(*) n FROM habitaciones WHERE activo=1').n || 1;
  const nDow = [0, 0, 0, 0, 0, 0, 0]; for (let i = 0; i < n; i++) nDow[aFecha(sumarDias(d, i)).getDay()]++;
  const dias = Object.entries(porDia).sort((a, b) => b[1] - a[1]);
  return { desde: d, hasta: h, dias: n, serie, totales: T, rentas, noches, ocupacion: Math.min(100, Math.round((noches / (nh * n)) * 1000) / 10),
    tarifa: rentas ? r2(T.hospedaje / rentas) : 0, diario: r2(T.total / n), dow: dow.map((v, i) => (nDow[i] ? r2(v / nDow[i]) : 0)),
    mejor: dias[0] ? { fecha: dias[0][0], total: r2(dias[0][1]) } : null };
}
ruta('GET', '/api/reporte/tendencia', 'reportes', ({ q }) => {
  const d = /^\d{4}-\d{2}-\d{2}$/.test(q.desde || '') ? q.desde : hoy(), h = /^\d{4}-\d{2}-\d{2}$/.test(q.hasta || '') && q.hasta >= d ? q.hasta : d;
  const n = difDias(d, h) + 1, gran = n <= 45 ? 'dia' : n <= 210 ? 'semana' : 'mes';
  // Un solo día se compara contra el mismo día de la semana pasada; si no, contra el mismo número de días anteriores
  const pd = n === 1 ? sumarDias(d, -7) : sumarDias(d, -n), ph = n === 1 ? sumarDias(h, -7) : sumarDias(d, -1);
  const A = periodoVentas(d, h, gran), B = periodoVentas(pd, ph, gran);
  const yd = String(Number(d.slice(0, 4)) - 1) + d.slice(4), yh = String(Number(h.slice(0, 4)) - 1) + h.slice(4);
  const hayAnio = get('SELECT COUNT(*) n FROM pagos WHERE substr(fecha,1,10) <= ?', yh).n > 0 && /^\d{4}-\d{2}-\d{2}$/.test(yd) && !isNaN(aFecha(yd)) && !isNaN(aFecha(yh));
  const Y = hayAnio ? periodoVentas(yd, yh, gran) : null;
  const cambio = { total: pct(A.totales.total, B.totales.total), hospedaje: pct(A.totales.hospedaje, B.totales.hospedaje), tienda: pct(A.totales.tienda, B.totales.tienda),
    rentas: pct(A.rentas, B.rentas), tarifa: pct(A.tarifa, B.tarifa), ocupacion: Math.round((A.ocupacion - B.ocupacion) * 10) / 10, anio: Y ? pct(A.totales.total, Y.totales.total) : null };
  // Lectura breve, en palabras
  const M = (v) => money(v), sube = (v) => (v === null ? 'sin ventas antes para comparar' : v > 0 ? `${v}% más` : v < 0 ? `${Math.abs(v)}% menos` : 'igual');
  const DIAS = ['domingos', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábados'];
  const analisis = [];
  const contra = n === 1 ? 'el mismo día de la semana pasada' : `los ${n} días anteriores`;
  analisis.push(B.totales.total > 0 ? `Cobró ${M(A.totales.total)}: ${sube(cambio.total)} que ${contra} (${M(B.totales.total)}).` : `Cobró ${M(A.totales.total)}. En ${contra} no hubo ventas para comparar.`);
  const dif = [['hospedaje', A.totales.hospedaje - B.totales.hospedaje], ['tienda', A.totales.tienda - B.totales.tienda], ['visitas, multas y otros', A.totales.visitas + A.totales.otros - B.totales.visitas - B.totales.otros]].sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]));
  if (Math.abs(dif[0][1]) >= 1) analisis.push(`Lo que más ${dif[0][1] > 0 ? 'subió' : 'bajó'} fue ${dif[0][0]}: ${M(Math.abs(dif[0][1]))} ${dif[0][1] > 0 ? 'más' : 'menos'}.`);
  analisis.push(`Ocupación ${A.ocupacion}% (${cambio.ocupacion > 0 ? '+' : ''}${cambio.ocupacion} puntos) · ${A.rentas} rentas a ${M(A.tarifa)} en promedio${cambio.tarifa !== null && B.rentas ? ` (${cambio.tarifa > 0 ? '+' : ''}${cambio.tarifa}%)` : ''}.`);
  if (n >= 7) { const mx = A.dow.indexOf(Math.max(...A.dow)), mn = A.dow.indexOf(Math.min(...A.dow)); if (A.dow[mx] > 0) analisis.push(`Los ${DIAS[mx]} son el mejor día (${M(A.dow[mx])} en promedio) y los ${DIAS[mn]} el más flojo (${M(A.dow[mn])}).`); }
  if (Y && Y.totales.total > 0) analisis.push(`Contra las mismas fechas del año pasado: ${sube(cambio.anio)} (${M(Y.totales.total)}).`);
  return { gran, actual: A, anterior: B, anio: Y ? { desde: Y.desde, hasta: Y.hasta, totales: Y.totales } : null, cambio, analisis };
});

// ---------- Reportes ----------
ruta('GET', '/api/reporte/detalle', 'reportes', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d;
  return { ...detalle('substr($.fecha,1,10) BETWEEN ? AND ?', d, h),
    visitantes: all('SELECT v.nombre, v.identificacion, v.entrada, v.salida, v.cobro, hb.numero FROM visitantes v LEFT JOIN habitaciones hb ON hb.id=v.habitacion_id WHERE substr(v.entrada,1,10) BETWEEN ? AND ? ORDER BY v.entrada', d, h),
    turnos: all("SELECT t.id FROM turnos t WHERE substr(t.apertura,1,10) BETWEEN ? AND ? ORDER BY t.id", d, h).map((x) => resumenTurno(x.id)) };
});
ruta('GET', '/api/reporte', 'reportes', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d;
  const habs = all('SELECT * FROM habitaciones WHERE activo=1').map(habJSON);
  const activas = all('SELECT e.*, hb.numero FROM estancias e JOIN habitaciones hb ON hb.id=e.habitacion_id WHERE e.activa=1 ORDER BY hb.numero').map(resumenEstancia);
  const pagos = all('SELECT p.*, u.nombre usuario FROM pagos p LEFT JOIN usuarios u ON u.id=p.usuario_id WHERE substr(p.fecha,1,10) BETWEEN ? AND ?', d, h);
  const suma = (f) => r2(pagos.filter(f).reduce((s, x) => s + x.monto, 0));
  const porMetodo = Object.fromEntries(METODOS.map((m) => [m, suma((x) => x.metodo === m)]));
  const porUsuario = {}; for (const x of pagos) porUsuario[x.usuario || '—'] = r2((porUsuario[x.usuario || '—'] || 0) + x.monto);
  const porModalidad = Object.fromEntries(MODALIDADES.map((m) => [m, activas.filter((e) => e.modalidad === m).length]));
  const rentas = Object.fromEntries(MODALIDADES.map((k) => [k, { n: 0, cantidad: 0, importe: 0, cobrado: 0 }]));
  for (const x of all('SELECT modalidad, COUNT(*) n, SUM(cantidad) c, SUM(importe) i FROM rentas WHERE substr(fecha,1,10) BETWEEN ? AND ? GROUP BY modalidad', d, h)) if (rentas[x.modalidad]) Object.assign(rentas[x.modalidad], { n: x.n, cantidad: x.c, importe: r2(x.i) });
  for (const x of pagos) if (x.concepto === 'hospedaje' && rentas[x.modalidad]) rentas[x.modalidad].cobrado = r2(rentas[x.modalidad].cobrado + x.monto);
  return {
    desde: d, hasta: h, rentas, visitasCobradas: { n: get('SELECT COUNT(*) n FROM visitantes WHERE cobro>0 AND substr(entrada,1,10) BETWEEN ? AND ?', d, h).n, total: suma((x) => x.concepto === 'visita') },
    habitaciones: habs.map((x) => ({ id: x.id, numero: x.numero, nombre: x.nombre, clase: x.clase, estado: x.estado, nota: x.nota })),
    huespedes: activas, porModalidad,
    cobrado: { hospedaje: suma((x) => x.concepto === 'hospedaje'), tienda: suma((x) => x.concepto === 'tienda'), visita: suma((x) => x.concepto === 'visita'), total: suma(() => true), porMetodo, porUsuario,
      usd: r2(pagos.reduce((t, x) => t + (x.usd || 0), 0)), cambio: r2(pagos.reduce((t, x) => t + (x.cambio || 0), 0)) },
    turnosAbiertos: all("SELECT t.id, t.apertura, u.nombre FROM turnos t JOIN usuarios u ON u.id=t.usuario_id WHERE t.estado='abierto'"),
    entradas: get('SELECT COUNT(*) n FROM estancias WHERE substr(entrada,1,10) BETWEEN ? AND ?', d, h).n,
    salidas: get('SELECT COUNT(*) n FROM estancias WHERE substr(salida_real,1,10) BETWEEN ? AND ?', d, h).n,
    visitantes: get('SELECT COUNT(*) n FROM visitantes WHERE substr(entrada,1,10) BETWEEN ? AND ?', d, h).n,
    ventasTienda: get('SELECT COUNT(*) n, COALESCE(SUM(total),0) t FROM ventas WHERE cancelada=0 AND substr(fecha,1,10) BETWEEN ? AND ?', d, h),
    cargosHabitacion: r2(get('SELECT COALESCE(SUM(c.importe),0) t FROM cargos c WHERE substr(c.fecha,1,10) BETWEEN ? AND ?', d, h).t),
    porSurtir: all('SELECT nombre, existencia, minimo FROM productos WHERE activo=1 AND COALESCE(servicio,0)=0 AND existencia<=minimo ORDER BY nombre'),
    gastos: (() => {
      const l = all('SELECT categoria, grupo, metodo, monto FROM gastos WHERE cancelado=0 AND substr(fecha,1,10) BETWEEN ? AND ?', d, h);
      const porEmpleado = all('SELECT em.nombre, COUNT(*) n, SUM(g.monto) t FROM gastos g JOIN empleados em ON em.id=g.empleado_id WHERE g.cancelado=0 AND substr(g.fecha,1,10) BETWEEN ? AND ? GROUP BY em.id ORDER BY t DESC', d, h);
      const porProveedor = all('SELECT pv.nombre, COUNT(*) n, SUM(g.monto) t FROM gastos g JOIN proveedores pv ON pv.id=g.proveedor_id WHERE g.cancelado=0 AND substr(g.fecha,1,10) BETWEEN ? AND ? GROUP BY pv.id ORDER BY t DESC', d, h);
      const porCategoria = {}, porMetodo = {}, porGrupo = {};
      for (const g of l) {
        porCategoria[g.categoria || 'Otros'] = r2((porCategoria[g.categoria || 'Otros'] || 0) + g.monto); porMetodo[g.metodo] = r2((porMetodo[g.metodo] || 0) + g.monto);
        const k = g.grupo || 'Otros', x = porGrupo[k] || (porGrupo[k] = { total: 0, n: 0, conceptos: {} });
        x.total = r2(x.total + g.monto); x.n++; x.conceptos[g.categoria || 'Otros'] = r2((x.conceptos[g.categoria || 'Otros'] || 0) + g.monto);
      }
      return { total: r2(l.reduce((s, g) => s + g.monto, 0)), n: l.length, porCategoria, porMetodo, porGrupo, porEmpleado, porProveedor };
    })(),
    depositos: (() => {
      const sumT = (t) => r2(get('SELECT COALESCE(SUM(monto),0) t FROM depositos WHERE tipo=? AND substr(fecha,1,10) BETWEEN ? AND ?', t, d, h).t);
      const porMetodo = (t) => Object.fromEntries(all('SELECT metodo, SUM(monto) t FROM depositos WHERE tipo=? AND substr(fecha,1,10) BETWEEN ? AND ? GROUP BY metodo', t, d, h).map((x) => [x.metodo, r2(x.t)]));
      const enGuarda = r2(get(`SELECT COALESCE(SUM(CASE WHEN tipo='recibido' THEN monto ELSE -monto END),0) t FROM depositos`).t);
      return { cambio: r2(get("SELECT COALESCE(SUM(cambio),0) t FROM depositos WHERE tipo='recibido' AND substr(fecha,1,10) BETWEEN ? AND ?", d, h).t), recibidos: sumT('recibido'), devueltos: sumT('devuelto'), retenidos: sumT('retenido'), recibidosMetodo: porMetodo('recibido'), devueltosMetodo: porMetodo('devuelto'), enGuarda,
        pendientes: all(`SELECT e.id, e.huesped, e.salida_real, hb.numero, SUM(CASE WHEN d.tipo='recibido' THEN d.monto ELSE -d.monto END) saldo FROM depositos d JOIN estancias e ON e.id=d.estancia_id
          JOIN habitaciones hb ON hb.id=e.habitacion_id WHERE e.activa=0 GROUP BY e.id HAVING saldo > 0.009 ORDER BY e.salida_real`) };
    })(),
    mantenimiento: { abiertos: get("SELECT COUNT(*) n FROM mantenimiento WHERE estado<>'terminado' AND COALESCE(tipo,'reparacion')<>'limpieza'").n, terminados: get("SELECT COUNT(*) n FROM mantenimiento WHERE estado='terminado' AND substr(cierre,1,10) BETWEEN ? AND ?", d, h).n },
    bitacora: all(`SELECT b.*, hb.numero, u.nombre usuario FROM bitacora b LEFT JOIN habitaciones hb ON hb.id=b.habitacion_id LEFT JOIN usuarios u ON u.id=b.usuario_id
      WHERE substr(b.fecha,1,10) BETWEEN ? AND ? ORDER BY b.id DESC LIMIT 200`, d, h),
  };
});


// ======================================================================
// 1.8 Cuentas por pagar a proveedores
// ======================================================================
function cxpJSON(c) {
  const saldo = r2(c.monto - c.pagado), dias = c.vence ? Math.round((aFecha(c.vence) - aFecha(hoy())) / 86400000) : null;
  const estado = c.cancelada ? 'cancelada' : saldo <= 0.009 ? 'pagada' : dias !== null && dias < 0 ? 'vencida' : 'pendiente';
  return { ...c, saldo, dias, estado, por_vencer: estado === 'pendiente' && dias !== null && dias <= (ent(cfg('cxp_dias_aviso')) || 3) };
}
const SQL_CXP = 'SELECT c.*, pv.nombre proveedor FROM cuentas_pagar c LEFT JOIN proveedores pv ON pv.id=c.proveedor_id';
ruta('GET', '/api/cuentas-pagar', 'cuentas_pagar', ({ q }) => {
  const L = all(`${SQL_CXP} WHERE c.cancelada=0 ORDER BY c.vence IS NULL, c.vence, c.id`).map(cxpJSON);
  const f = q.estado || 'abiertas';
  return f === 'todas' ? L : f === 'abiertas' ? L.filter((c) => c.estado !== 'pagada') : L.filter((c) => c.estado === f);
});
ruta('GET', '/api/cuentas-pagar/avisos', 'sesion', ({ u }) => (u.perm.has('cuentas_pagar') ? all(`${SQL_CXP} WHERE c.cancelada=0 AND c.monto-c.pagado>0.009`).map(cxpJSON).filter((c) => c.estado === 'vencida' || c.por_vencer) : []));
ruta('GET', '/api/cuentas-pagar/:id', 'cuentas_pagar', ({ p }) => {
  const c = get(`${SQL_CXP} WHERE c.id=?`, Number(p.id)); if (!c) throw new ErrorUsuario('No existe', 404);
  return { ...cxpJSON(c), pagos: all('SELECT cp.*, g.folio, g.metodo, u.nombre usuario FROM cuentas_pagos cp LEFT JOIN gastos g ON g.id=cp.gasto_id LEFT JOIN usuarios u ON u.id=cp.usuario_id WHERE cp.cuenta_id=? ORDER BY cp.id', c.id) };
});
function limpiarCxp(b) {
  const d = { proveedor_id: Number(b.proveedor_id) || null, concepto: txt(b.concepto, 200), factura: txt(b.factura, 80), categoria: txt(b.categoria, 60) || 'Pago a proveedores', monto: num(b.monto),
    fecha: /^\d{4}-\d{2}-\d{2}$/.test(b.fecha || '') ? b.fecha : hoy(), vence: /^\d{4}-\d{2}-\d{2}$/.test(b.vence || '') ? b.vence : null, notas: txt(b.notas, 300) };
  if (!d.concepto) throw new ErrorUsuario('Escriba qué se debe (concepto)');
  if (!(d.monto > 0)) throw new ErrorUsuario('Escriba el monto que se debe');
  d.grupo = grupoDe(d.categoria);
  return d;
}
ruta('POST', '/api/cuentas-pagar', 'cuentas_pagar', ({ body, u }) => {
  const d = limpiarCxp(body);
  return run('INSERT INTO cuentas_pagar(proveedor_id,concepto,factura,categoria,grupo,monto,fecha,vence,notas,usuario_id,creado) VALUES(?,?,?,?,?,?,?,?,?,?,?)', d.proveedor_id, d.concepto, d.factura, d.categoria, d.grupo, d.monto, d.fecha, d.vence, d.notas, u.id, ahora());
});
ruta('PUT', '/api/cuentas-pagar/:id', 'cuentas_pagar', ({ body, p }) => {
  const c = get('SELECT * FROM cuentas_pagar WHERE id=?', Number(p.id)); if (!c) throw new ErrorUsuario('No existe', 404);
  const d = limpiarCxp(body); if (d.monto < c.pagado - 0.009) throw new ErrorUsuario('Ya se pagaron $' + c.pagado.toFixed(2) + ': el monto no puede ser menor');
  run('UPDATE cuentas_pagar SET proveedor_id=?,concepto=?,factura=?,categoria=?,grupo=?,monto=?,fecha=?,vence=?,notas=? WHERE id=?', d.proveedor_id, d.concepto, d.factura, d.categoria, d.grupo, d.monto, d.fecha, d.vence, d.notas, c.id);
});
ruta('DELETE', '/api/cuentas-pagar/:id', 'cuentas_pagar', ({ p }) => {
  const c = get('SELECT * FROM cuentas_pagar WHERE id=?', Number(p.id)); if (!c) throw new ErrorUsuario('No existe', 404);
  if (c.pagado > 0) throw new ErrorUsuario('Ya tiene pagos: no se puede cancelar');
  run('UPDATE cuentas_pagar SET cancelada=1 WHERE id=?', c.id);
});
ruta('POST', '/api/cuentas-pagar/:id/pagar', 'cuentas_pagar', ({ body, p, u }) => tx(() => {
  const c = cxpJSON(get(`${SQL_CXP} WHERE c.id=?`, Number(p.id)) || {});
  if (!c.id || c.cancelada) throw new ErrorUsuario('No existe', 404);
  const monto = num(body.monto); if (!(monto > 0)) throw new ErrorUsuario('Escriba cuánto se paga');
  if (monto > c.saldo + 0.009) throw new ErrorUsuario('Solo se deben $' + c.saldo.toFixed(2));
  const gid = crearGasto({ concepto: `Pago a ${c.proveedor || 'proveedor'} · ${c.concepto}${c.factura ? ' · Fact. ' + c.factura : ''}${monto < c.saldo - 0.009 ? ' (abono)' : ''}`, categoria: c.categoria, grupo: c.grupo, monto, metodo: body.metodo,
    proveedor_id: c.proveedor_id, factura: c.factura, nota: txt(body.nota, 200), fuera_de_caja: !!body.fuera_de_caja, recibe: c.proveedor }, u.id);
  run('INSERT INTO cuentas_pagos(cuenta_id,gasto_id,fecha,monto,usuario_id) VALUES(?,?,?,?,?)', c.id, gid, ahora(), monto, u.id);
  run('UPDATE cuentas_pagar SET pagado=pagado+? WHERE id=?', monto, c.id);
  return { gasto_id: gid, saldo: r2(c.saldo - monto) };
}));

// ======================================================================
// 1.8 Nómina: descuentos de asistencia listos para pagar
// ======================================================================
ruta('GET', '/api/nomina/asistencia', 'personal', ({ q }) => {
  const d = /^\d{4}-\d{2}-\d{2}$/.test(q.desde || '') ? q.desde : fechaMas(hoy(), -6), h = /^\d{4}-\d{2}-\d{2}$/.test(q.hasta || '') ? q.hasta : hoy();
  return all('SELECT * FROM empleados WHERE activo=1 ORDER BY nombre').map((e) => ({ empleado_id: e.id, nombre: e.nombre, con_horario: !!horarioDe(e), resumen: asistenciaDe(e, d, h <= hoy() ? h : hoy()).resumen }));
});

// ======================================================================
// 1.8 Reloj checador por red ZKTeco (protocolo ADMS / "push"): el reloj manda las checadas solo
//   En el reloj: Menú → Comunicación → Servidor en la nube (ADMS): dirección = IP de esta computadora, puerto 3050
//   El número de usuario en el reloj (PIN) debe ser el mismo "Número para checar" del empleado
// ======================================================================
const TIPO_ZK = { 0: 'entrada', 1: 'salida', 2: 'descanso', 3: 'regreso', 4: 'entrada', 5: 'salida' };
function tipoEnFecha(empId, fecha) {
  const cs = all("SELECT tipo FROM checadas WHERE empleado_id=? AND anulada=0 AND substr(fecha,1,10)=? AND fecha<? ORDER BY fecha", empId, fecha.slice(0, 10), fecha), u = cs[cs.length - 1];
  if (!u || u.tipo === 'salida') return 'entrada';
  if (u.tipo === 'descanso') return 'regreso';
  if (u.tipo === 'regreso') return 'salida';
  const e = get('SELECT horario FROM empleados WHERE id=?', empId), H = e ? horarioDe(e) : null, h = H ? H[aFecha(fecha).getDay()] : null;
  if (h && num(h.descanso) > 0 && !cs.some((c) => c.tipo === 'descanso') && minDe(h.salida) !== null && minDeFecha(fecha) < minDe(h.salida) - 60) return 'descanso';
  return 'salida';
}
function checadaReloj(sn, linea) {
  const [pin, fecha, estado] = linea.split('\t').map((x) => String(x || '').trim());
  if (!pin || !/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/.test(fecha || '')) return false;
  const e = get('SELECT * FROM empleados WHERE numero=? AND activo=1', pin); if (!e) return false;
  const f = fecha.length === 16 ? fecha + ':00' : fecha;
  if (get('SELECT id FROM checadas WHERE empleado_id=? AND fecha=?', e.id, f)) return false;
  const tipo = cfg('reloj_estado') === 'reloj' && TIPO_ZK[estado] ? TIPO_ZK[estado] : tipoEnFecha(e.id, f);
  run('INSERT INTO checadas(empleado_id,fecha,tipo,metodo,usuario_id,nota) VALUES(?,?,?,?,?,?)', e.id, f, tipo, 'reloj', null, 'Reloj ' + sn);
  return true;
}
function iclock(req, res, url, r0, cuerpo) {
  const sn = txt(url.searchParams.get('SN'), 40), texto = (t, st = 200) => { res.writeHead(st, { 'Content-Type': 'text/plain' }); res.end(t); };
  if (!sn) return texto('ERROR', 400);
  const ya = get('SELECT * FROM relojes WHERE sn=?', sn);
  if (!ya) run('INSERT INTO relojes(sn,nombre,ip,ultimo,activo) VALUES(?,?,?,?,0)', sn, 'Reloj ' + sn, ipDe(req), ahora());
  else run('UPDATE relojes SET ip=?, ultimo=? WHERE sn=?', ipDe(req), ahora(), sn);
  const activo = ya?.activo === 1;
  if (r0 === '/iclock/cdata' && req.method === 'GET') {
    const tz = -new Date().getTimezoneOffset() / 60;
    return texto(`GET OPTION FROM: ${sn}\nATTLOGStamp=${ya?.stamp || 'None'}\nOPERLOGStamp=9999\nATTPHOTOStamp=None\nErrorDelay=60\nDelay=30\nTransTimes=00:00;14:05\nTransInterval=1\nTransFlag=TransData AttLog\nTimeZone=${tz}\nRealtime=1\nEncrypt=None\n`);
  }
  if (r0 === '/iclock/cdata' && req.method === 'POST') {
    // Mientras el administrador no active el reloj no se reciben checadas (el reloj las vuelve a mandar después)
    if (!activo) return texto('ERROR: reloj no autorizado', 403);
    const tabla = url.searchParams.get('table');
    if (tabla !== 'ATTLOG') return texto('OK');
    let n = 0; const lineas = cuerpo.toString('utf8').split(/\r?\n/).filter(Boolean);
    tx(() => { for (const l of lineas) if (checadaReloj(sn, l)) n++; });
    if (url.searchParams.get('Stamp')) run('UPDATE relojes SET stamp=? WHERE sn=?', url.searchParams.get('Stamp'), sn);
    return texto('OK: ' + lineas.length);
  }
  return texto('OK');
}
ruta('GET', '/api/relojes', 'asistencia', () => all('SELECT sn, nombre, ip, ultimo, activo FROM relojes ORDER BY ultimo DESC'));
ruta('PUT', '/api/relojes/:sn', 'asistencia', ({ p, body }) => { run('UPDATE relojes SET nombre=COALESCE(?,nombre), activo=? WHERE sn=?', txt(body.nombre, 60), body.activo ? 1 : 0, p.sn); });
ruta('DELETE', '/api/relojes/:sn', 'asistencia', ({ p }) => { run('DELETE FROM relojes WHERE sn=?', p.sn); });

// ======================================================================
// 1.8 Unidades de negocio, otros ingresos, gráfica de pastel y venta promedio diaria
// ======================================================================
const unidadesCfg = () => String(cfg('unidades_negocio') || 'Hotel').split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
const unidadDe = (h) => h.unidad || (h.clase === 'local' ? (unidadesCfg().find((x) => /local/i.test(x)) || 'Locales comerciales') : (unidadesCfg()[0] || 'Hotel'));
function extrasPeriodo(d, h) {
  const B = (a) => `substr(${a}.fecha,1,10) BETWEEN ? AND ?`;
  const habs = all('SELECT * FROM habitaciones WHERE activo=1 OR id IN (SELECT habitacion_id FROM estancias WHERE substr(entrada,1,10)<=?)', h);
  const uh = Object.fromEntries(habs.map((x) => [x.id, unidadDe(x)]));
  const nombres = [...new Set([...unidadesCfg(), ...Object.values(uh)])];
  const U = Object.fromEntries(nombres.map((n) => [n, { nombre: n, habitaciones: 0, ocupadas: 0, rentas: 0, generado: 0, cobrado: 0, cortas: 0, largas: 0, extras: 0 }]));
  for (const x of habs) if (x.activo) { U[uh[x.id]].habitaciones++; if (x.estado === 'ocupada') U[uh[x.id]].ocupadas++; }
  for (const r of all(`SELECT r.modalidad, r.importe, e.habitacion_id FROM rentas r JOIN estancias e ON e.id=r.estancia_id WHERE ${B('r')}`, d, h)) {
    const x = U[uh[r.habitacion_id] || nombres[0]]; x.rentas++; x.generado = r2(x.generado + r.importe); if (['semana', 'mes'].includes(r.modalidad)) x.largas = r2(x.largas + r.importe); else x.cortas = r2(x.cortas + r.importe);
  }
  const pagos = all(`SELECT p.concepto, p.monto, p.fecha, e.habitacion_id FROM pagos p LEFT JOIN estancias e ON e.id=p.estancia_id WHERE ${B('p')}`, d, h);
  for (const p of pagos) if (p.habitacion_id && uh[p.habitacion_id] && p.concepto === 'hospedaje') U[uh[p.habitacion_id]].cobrado = r2(U[uh[p.habitacion_id]].cobrado + p.monto);
  // Multas, intereses y cuotas
  const cargos = all(`SELECT c.*, hb.numero, hb.id hid, e.huesped, us.nombre usuario FROM cargos c JOIN estancias e ON e.id=c.estancia_id JOIN habitaciones hb ON hb.id=e.habitacion_id LEFT JOIN usuarios us ON us.id=c.usuario_id
    WHERE c.tipo IN ('multa','mora','limpieza','mascota','otro') AND ${B('c')} ORDER BY c.fecha`, d, h);
  const tipos = Object.fromEntries(EXTRAS.map((k) => [k, { nombre: TIPOS_CARGO[k], n: 0, generado: 0, cobrado: 0, conceptos: {} }]));
  for (const c of cargos) {
    const x = tipos[c.tipo]; x.n++; x.generado = r2(x.generado + c.importe);
    const k = c.tipo === 'mora' ? 'Interés moratorio' : c.descripcion, y = x.conceptos[k] || (x.conceptos[k] = { n: 0, total: 0 }); y.n++; y.total = r2(y.total + c.importe);
    if (uh[c.hid]) U[uh[c.hid]].extras = r2(U[uh[c.hid]].extras + c.importe);
  }
  for (const p of pagos) if (tipos[p.concepto]) tipos[p.concepto].cobrado = r2(tipos[p.concepto].cobrado + p.monto);
  // Tienda por área y visitas
  const tienda = all(`SELECT COALESCE(pr.area,'Sin área') area, SUM(i.cantidad) cantidad, SUM(i.importe) importe, SUM(i.costo*i.cantidad) costo FROM venta_items i JOIN ventas v ON v.id=i.venta_id LEFT JOIN productos pr ON pr.id=i.producto_id
    WHERE v.cancelada=0 AND ${B('v')} GROUP BY 1 ORDER BY importe DESC`, d, h).map((x) => ({ ...x, importe: r2(x.importe), costo: r2(x.costo), utilidad: r2(x.importe - x.costo) }));
  const ventaTienda = r2(tienda.reduce((s, x) => s + x.importe, 0));
  const visitas = all(`SELECT hb.numero, COUNT(*) n, SUM(v.cobro) total FROM visitantes v JOIN habitaciones hb ON hb.id=v.habitacion_id WHERE v.cobro>0 AND substr(v.entrada,1,10) BETWEEN ? AND ? GROUP BY hb.id ORDER BY total DESC`, d, h);
  const visitasTot = r2(pagos.filter((p) => p.concepto === 'visita').reduce((s, p) => s + p.monto, 0));
  // Gráfica de pastel: lo que generó cada unidad de negocio y cada tipo de ingreso
  const pastel = [...Object.values(U).filter((x) => x.generado > 0).map((x) => ({ nombre: x.nombre + ' (rentas)', valor: x.generado })),
    { nombre: 'Tienda', valor: ventaTienda }, { nombre: 'Visitas', valor: visitasTot },
    ...EXTRAS.map((k) => ({ nombre: { multa: 'Multas', mora: 'Intereses moratorios', limpieza: 'Cuotas de limpieza', mascota: 'Cuotas por mascota', otro: 'Otros cargos' }[k], valor: tipos[k].generado }))].filter((x) => x.valor > 0);
  const totPastel = r2(pastel.reduce((s, x) => s + x.valor, 0));
  pastel.forEach((x) => { x.pct = totPastel ? r2(x.valor / totPastel * 100) : 0; });
  pastel.sort((a, b) => b.valor - a.valor);
  // Venta promedio diaria (días transcurridos del periodo)
  const fin = h < hoy() ? h : hoy(), nd = Math.max(1, Math.round((aFecha(fin) - aFecha(d)) / 86400000) + 1);
  const porDia = {}; for (const p of pagos) porDia[p.fecha.slice(0, 10)] = r2((porDia[p.fecha.slice(0, 10)] || 0) + p.monto);
  const cob = r2(pagos.reduce((s, p) => s + p.monto, 0)), dl = Object.entries(porDia).sort((a, b) => b[1] - a[1]);
  const S = (f) => r2(pagos.filter(f).reduce((s, p) => s + p.monto, 0));
  const promedio = { dias: nd, total: cob, diario: r2(cob / nd), hospedaje: r2(S((p) => p.concepto === 'hospedaje') / nd), tienda: r2(S((p) => p.concepto === 'tienda') / nd), visitas: r2(visitasTot / nd),
    otros: r2(S((p) => tipos[p.concepto]) / nd), generado_diario: r2(totPastel / nd), mejor: dl[0] ? { fecha: dl[0][0], total: dl[0][1] } : null, peor: dl.length ? { fecha: dl[dl.length - 1][0], total: dl[dl.length - 1][1] } : null,
    unidades: Object.values(U).map((x) => ({ nombre: x.nombre, diario: r2(x.cobrado / nd) })) };
  // Cuentas por pagar
  const cx = all(`${SQL_CXP} WHERE c.cancelada=0`).map(cxpJSON);
  const cuentas = { pendiente: r2(cx.filter((c) => c.estado === 'pendiente').reduce((s, c) => s + c.saldo, 0)), vencido: r2(cx.filter((c) => c.estado === 'vencida').reduce((s, c) => s + c.saldo, 0)),
    n_pendientes: cx.filter((c) => c.estado === 'pendiente').length, n_vencidas: cx.filter((c) => c.estado === 'vencida').length,
    pagado: r2(get(`SELECT COALESCE(SUM(monto),0) t FROM cuentas_pagos WHERE substr(fecha,1,10) BETWEEN ? AND ?`, d, h).t),
    nuevas: r2(get(`SELECT COALESCE(SUM(monto),0) t FROM cuentas_pagar WHERE cancelada=0 AND fecha BETWEEN ? AND ?`, d, h).t),
    lista: cx.filter((c) => c.estado !== 'pagada' || (c.fecha >= d && c.fecha <= h)).map((c) => ({ proveedor: c.proveedor, concepto: c.concepto, factura: c.factura, fecha: c.fecha, vence: c.vence, monto: c.monto, pagado: c.pagado, saldo: c.saldo, estado: c.estado, dias: c.dias })) };
  // Nómina: descuentos aplicados por retardos y faltas
  const nomina = all(`SELECT em.nombre, COUNT(*) pagos, SUM(n.sueldo) sueldo, SUM(n.descuento) descuento, SUM(n.desc_retardos) desc_retardos, SUM(n.desc_faltas) desc_faltas, SUM(n.retardos) retardos, SUM(n.faltas) faltas, SUM(n.total) total
    FROM nomina_lineas n JOIN empleados em ON em.id=n.empleado_id WHERE ${B('n')} GROUP BY em.id ORDER BY em.nombre`, d, h).map((x) => ({ ...x, sueldo: r2(x.sueldo), descuento: r2(x.descuento), desc_retardos: r2(x.desc_retardos), desc_faltas: r2(x.desc_faltas), total: r2(x.total) }));
  // Egresos de caja y quién los autorizó
  const egresos = all(`SELECT m.fecha, m.moneda, m.monto, m.motivo, u.nombre usuario, a.nombre autorizo FROM caja_mov m LEFT JOIN usuarios u ON u.id=m.usuario_id LEFT JOIN usuarios a ON a.id=m.autorizo_id WHERE m.tipo='retiro' AND ${B('m')} ORDER BY m.fecha`, d, h);
  const g = (re) => r2(get(`SELECT COALESCE(SUM(monto),0) t FROM gastos WHERE cancelado=0 AND substr(fecha,1,10) BETWEEN ? AND ? AND (${re})`, d, h).t);
  return {
    unidades: Object.values(U), tipos, cargos: cargos.map((c) => ({ fecha: c.fecha, numero: c.numero, huesped: c.huesped, tipo: c.tipo, descripcion: c.descripcion, cantidad: c.cantidad, importe: c.importe, usuario: c.usuario })),
    tienda_areas: tienda, venta_tienda: ventaTienda, visitas_hab: visitas, visitas_total: visitasTot, pastel, total_generado: totPastel, promedio, cuentas, nomina, egresos,
    conteos: all("SELECT i.folio, i.fecha, i.area, i.productos, i.faltantes, i.sobrantes, i.valor_faltante, i.valor_sobrante, u.nombre usuario FROM inventarios i LEFT JOIN usuarios u ON u.id=i.usuario_id WHERE substr(i.fecha,1,10) BETWEEN ? AND ? ORDER BY i.fecha", d, h),
    marketing: g("grupo LIKE '%arketing%' OR categoria LIKE '%ublicidad%' OR categoria LIKE '%arketing%'"), lavanderia: g("categoria LIKE '%avander%' OR concepto LIKE '%avander%'"),
  };
}
ruta('GET', '/api/reporte/extra', 'reportes', ({ q }) => { const d = q.desde || hoy(); return extrasPeriodo(d, q.hasta || d); });


// ======================================================================
// 1.8 Tienda: departamentos (áreas) y conteo de inventario físico
// ======================================================================
const areasCfg = () => String(cfg('tienda_areas') || '').split(',').map((x) => x.trim()).filter(Boolean);
const guardarAreas = (l) => setCfg('tienda_areas', [...new Set(l.map((x) => String(x).trim()).filter(Boolean))].join(', '));
ruta('GET', '/api/tienda/areas', 'sesion', () => {
  const usados = Object.fromEntries(all("SELECT COALESCE(NULLIF(area,''),'') a, COUNT(*) n FROM productos WHERE activo=1 GROUP BY 1").map((x) => [x.a, x.n]));
  const l = [...new Set([...areasCfg(), ...Object.keys(usados).filter(Boolean)])].sort((a, b) => a.localeCompare(b, 'es'));
  return { areas: l.map((n) => ({ nombre: n, productos: usados[n] || 0 })), sin_area: usados[''] || 0 };
});
ruta('POST', '/api/tienda/areas', 'productos', ({ body }) => {
  const n = txt(body.nombre, 60); if (!n) throw new ErrorUsuario('Escriba el nombre del departamento');
  if (areasCfg().some((x) => x.toLowerCase() === n.toLowerCase())) throw new ErrorUsuario('Ese departamento ya existe');
  guardarAreas([...areasCfg(), n]);
});
ruta('PUT', '/api/tienda/areas', 'productos', ({ body }) => tx(() => {
  const de = txt(body.de, 60), a = txt(body.a, 60); if (!de || !a) throw new ErrorUsuario('Escriba el nombre nuevo');
  run('UPDATE productos SET area=? WHERE area=?', a, de);
  guardarAreas([...areasCfg().filter((x) => x !== de), a]);
}));
ruta('DELETE', '/api/tienda/areas', 'productos', ({ q }) => tx(() => {
  const n = txt(q.nombre, 60); if (!n) throw new ErrorUsuario('Falta el departamento');
  const r = run('UPDATE productos SET area=NULL WHERE area=?', n);
  guardarAreas(areasCfg().filter((x) => x !== n));
  return { productos: r.changes };
}));
// Conteo físico: compara lo contado contra el sistema, guarda faltantes y sobrantes y (si se pide) ajusta las existencias
ruta('POST', '/api/inventarios', 'inventario', ({ body, u }) => tx(() => {
  const L = (Array.isArray(body.lineas) ? body.lineas : []).filter((l) => l.contado !== '' && l.contado !== null && l.contado !== undefined && Number.isFinite(Number(l.contado)));
  if (!L.length) throw new ErrorUsuario('Capture al menos un producto contado');
  // Solo quien puede editar productos (gerente / administrador) ajusta las existencias; los demás solo registran el conteo
  const aplicar = body.aplicar !== false && u.perm.has('productos'), folio = siguienteFolio('inventario'), fecha = ahora();
  const r = run('INSERT INTO inventarios(folio,fecha,usuario_id,area,notas,aplicado) VALUES(?,?,?,?,?,?)', folio, fecha, u.id, txt(body.area, 60), txt(body.notas, 300), aplicar ? 1 : 0);
  let F = 0, S = 0, VF = 0, VS = 0;
  for (const l of L) {
    const p = get('SELECT * FROM productos WHERE id=? AND activo=1', Number(l.producto_id)); if (!p || p.servicio) continue;
    const c = r2(num(l.contado)), d = r2(c - p.existencia);
    run('INSERT INTO inventario_lineas(inventario_id,producto_id,codigo,nombre,area,sistema,contado,diferencia,costo,precio) VALUES(?,?,?,?,?,?,?,?,?,?)', r.id, p.id, p.codigo, p.nombre, p.area, p.existencia, c, d, p.costo, p.precio);
    if (d < 0) { F += -d; VF += -d * p.costo; } else if (d > 0) { S += d; VS += d * p.costo; }
    if (aplicar && d !== 0) {
      run('UPDATE productos SET existencia=? WHERE id=?', c, p.id);
      run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', fecha, p.id, 'ajuste', d, `Conteo físico ${folio}${d < 0 ? ' (faltante)' : ' (sobrante)'}`, u.id);
    }
  }
  run('UPDATE inventarios SET productos=?, faltantes=?, sobrantes=?, valor_faltante=?, valor_sobrante=? WHERE id=?', L.length, r2(F), r2(S), r2(VF), r2(VS), r.id);
  return { id: r.id, folio };
}));
ruta('GET', '/api/inventarios', 'inventario', () => all('SELECT i.*, u.nombre usuario FROM inventarios i LEFT JOIN usuarios u ON u.id=i.usuario_id ORDER BY i.id DESC LIMIT 200'));
ruta('GET', '/api/inventarios/:id', 'inventario', ({ p }) => {
  const i = get('SELECT i.*, u.nombre usuario FROM inventarios i LEFT JOIN usuarios u ON u.id=i.usuario_id WHERE i.id=?', Number(p.id)); if (!i) throw new ErrorUsuario('No existe', 404);
  return { ...i, lineas: all('SELECT * FROM inventario_lineas WHERE inventario_id=? ORDER BY area, nombre', i.id) };
});

// ---------- Respaldos ----------
ruta('GET', '/api/respaldos', 'config', () => fs.readdirSync(RESPALDOS_DIR).filter((f) => f.endsWith('.db')).sort().reverse().slice(0, 40)
  .map((f) => ({ archivo: f, tam: fs.statSync(path.join(RESPALDOS_DIR, f)).size })));
ruta('POST', '/api/respaldos', 'config', () => ({ archivo: respaldar('manual'), carpeta: RESPALDOS_DIR }));

// ---------- v1.11: pasar toda la información a otra computadora ----------
const EXP_FIRMA = 'MAXSEL-HOTEL-EXPORTAR-1';
// Movimientos (lo que se genera al usar el sistema). "Solo configuración" los borra para dejar el hotel limpio
const TABLAS_MOV = ['sesiones', 'estancias', 'cargos', 'pagos', 'visitantes', 'ventas', 'venta_items', 'movimientos', 'bitacora', 'gastos', 'depositos', 'contratos', 'mantenimiento', 'mant_fotos',
  'turnos', 'caja_mov', 'checadas', 'incidencias', 'cierres', 'rentas', 'inventarios', 'inventario_lineas', 'cuentas_pagar', 'cuentas_pagos', 'nomina_lineas', 'reservaciones', 'cambios_habitacion', 'auditoria'];
// Se quedan los de la computadora que recibe (cada computadora tiene su impresora)
const CFG_LOCAL = ['impresora_tipo', 'impresora_nombre', 'impresora_ip', 'impresora_puerto', 'impresora_corte', 'abrir_cajon', 'ticket_ancho'];
const verNum = (v) => String(v || '0').split('.').map((x) => Number(x) || 0).reduce((a, x) => a * 1000 + x, 0);
function resumenDb(x) {
  const tablas = new Set(x.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((r) => r.name));
  const n = (t, w = '') => (tablas.has(t) ? Number(x.prepare(`SELECT COUNT(*) n FROM "${t}" ${w}`).get().n) : 0);
  return { habitaciones: n('habitaciones'), productos: n('productos'), usuarios: n('usuarios', 'WHERE activo=1'), empleados: n('empleados'), estancias: n('estancias'),
    ventas: n('ventas'), reservaciones: n('reservaciones'), gastos: n('gastos'), no_deseados: n('huespedes', 'WHERE bloqueado=1') };
}
// 1.16: Reiniciar ventas (empezar de cero sin perder la configuración), como en Maxsel POS.
const TABLAS_REINICIO = TABLAS_MOV.filter((t) => !['sesiones', 'auditoria'].includes(t));
ruta('GET', '/api/reiniciar', 'config', () => {
  const n = (sql) => Number(get(sql)?.n || 0);
  return { hospedados: n('SELECT COUNT(*) n FROM estancias WHERE activa=1'), rentas: n('SELECT COUNT(*) n FROM estancias'), ventas: n('SELECT COUNT(*) n FROM ventas'),
    cortes: n('SELECT COUNT(*) n FROM turnos'), gastos: n('SELECT COUNT(*) n FROM gastos'), reservaciones: n("SELECT COUNT(*) n FROM reservaciones WHERE estado NOT IN ('cancelada','llego','no_llego')") };
});
// 1.18: oculto (7 toques a la versión al pie de Configuración) y solo con la contraseña de Maxsel
const intentosRei = new Map();
ruta('POST', '/api/reiniciar', 'config', ({ body, u, req }) => {
  if (req.desdeInternet) throw new ErrorUsuario('Esto solo se puede hacer en la computadora del hotel', 403);
  const ip = ipDe(req), it = intentosRei.get(ip) || { n: 0, hasta: 0 };
  if (it.hasta > Date.now()) throw new ErrorUsuario('Demasiados intentos. Espere 15 minutos.', 429);
  if (!esClaveMaxsel(body.clave)) {
    it.n++; if (it.n >= 5) { it.hasta = Date.now() + 15 * 60000; it.n = 0; } intentosRei.set(ip, it);
    throw new ErrorUsuario('Contraseña de Maxsel incorrecta', 401);
  }
  intentosRei.delete(ip);
  const hosp = Number(get('SELECT COUNT(*) n FROM estancias WHERE activa=1')?.n || 0);
  if (hosp && !body.con_hospedados) throw new ErrorUsuario(`Hay ${hosp} huésped(es) hospedado(s). Deles salida primero, o marque la casilla para borrarlos también.`);
  const respaldo = respaldar('antes_de_reiniciar');
  const tablas = new Set(all("SELECT name FROM sqlite_master WHERE type='table'").map((r) => r.name));
  tx(() => {
    for (const t of TABLAS_REINICIO) if (tablas.has(t)) run(`DELETE FROM "${t}"`);
    if (tablas.has('sqlite_sequence')) run(`DELETE FROM sqlite_sequence WHERE name IN (${TABLAS_REINICIO.map((t) => `'${t}'`).join(',')})`);
    run("UPDATE habitaciones SET estado='libre', nota=NULL");
    if (tablas.has('huespedes')) run('UPDATE huespedes SET visitas=0, primera=NULL, ultima=NULL');
    for (const r of all("SELECT clave FROM config WHERE clave LIKE 'folio\\_%' ESCAPE '\\'")) setCfg(r.clave, '0');
    run('INSERT INTO auditoria(fecha,usuario_id,usuario,accion,ruta,detalle,ip) VALUES(?,?,?,?,?,?,?)', ahora(), u.id, u.nombre,
      'Reinició las ventas (empezó de cero)', 'POST /api/reiniciar', JSON.stringify({ respaldo, hospedados: hosp }), '');
  });
  return { ok: true, respaldo, carpeta: RESPALDOS_DIR };
});
function armarExportacion(modo, u) {
  const tmp = path.join(RESPALDOS_DIR, `exportando_${Date.now()}.db`);
  dbMain.exec(`VACUUM INTO '${tmp.replace(/'/g, "''")}'`);
  try {
    const x = new DatabaseSync(tmp);
    let resumen;
    try {
      x.exec('DELETE FROM sesiones');
      if (modo === 'config') {
        const tablas = new Set(x.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((r) => r.name));
        for (const t of TABLAS_MOV) if (tablas.has(t)) x.exec(`DELETE FROM "${t}"`);
        if (tablas.has('huespedes')) x.exec('DELETE FROM huespedes WHERE COALESCE(bloqueado,0)=0; UPDATE huespedes SET visitas=0, primera=NULL, ultima=NULL');
        x.exec("UPDATE habitaciones SET estado='libre'");
        x.exec("DELETE FROM config WHERE clave LIKE 'folio\\_%' ESCAPE '\\'");
        if (tablas.has('sqlite_sequence')) x.exec(`DELETE FROM sqlite_sequence WHERE name IN (${TABLAS_MOV.map((t) => `'${t}'`).join(',')})`);
      }
      resumen = resumenDb(x);
      x.exec('VACUUM');
    } finally { x.close(); }
    const fotos = {};
    if (modo === 'todo') for (const f of fs.readdirSync(FOTOS_DIR)) { const p = path.join(FOTOS_DIR, f); if (fs.statSync(p).isFile()) fotos[f] = fs.readFileSync(p).toString('base64'); }
    const datos = { firma: EXP_FIRMA, version: VERSION, fecha: ahora(), modo, hotel: cfg('hotel_nombre') || '', usuario: u.nombre, resumen, fotos: Object.keys(fotos).length, db: fs.readFileSync(tmp).toString('base64'), archivos: fotos };
    return zlib.gzipSync(Buffer.from(JSON.stringify(datos)));
  } finally { try { fs.unlinkSync(tmp); } catch { /* nada */ } }
}
ruta('GET', '/api/exportar', 'config', ({ res, q, u }) => {
  const modo = q.modo === 'config' ? 'config' : 'todo';
  const buf = armarExportacion(modo, u);
  const nombre = `Maxsel Hotel - ${modo === 'config' ? 'configuracion' : 'informacion completa'} ${hoy()}.maxsel`;
  try { run('INSERT INTO auditoria(fecha,usuario_id,usuario,accion,ruta,detalle,ip) VALUES(?,?,?,?,?,?,?)', ahora(), u.id, u.nombre, modo === 'config' ? 'Exportó la configuración (sin movimientos)' : 'Exportó toda la información', 'GET /api/exportar', '{}', ''); } catch { /* nada */ }
  res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': buf.length, 'Cache-Control': 'no-store', 'Content-Disposition': `attachment; filename="${nombre}"` });
  res.end(buf);
});
ruta('POST', '/api/importar', 'config', ({ body, q, u, req }) => {
  if (!Buffer.isBuffer(body._raw) || !body._raw.length) throw new ErrorUsuario('Elija el archivo .maxsel que exportó');
  let d;
  try { d = JSON.parse(zlib.gunzipSync(body._raw).toString()); } catch { throw new ErrorUsuario('El archivo no es una exportación de Maxsel Hotel o está dañado'); }
  if (d.firma !== EXP_FIRMA || !d.db) throw new ErrorUsuario('El archivo no es una exportación de Maxsel Hotel');
  if (verNum(d.version) > verNum(VERSION)) throw new ErrorUsuario(`El archivo viene de la versión ${d.version} y esta computadora tiene la ${VERSION}. Instale primero la versión nueva aquí.`);
  const tmp = path.join(DATA_DIR, 'importar_revisando.db');
  fs.writeFileSync(tmp, Buffer.from(d.db, 'base64'));
  try {
    const x = new DatabaseSync(tmp);
    try {
      if (x.prepare('PRAGMA integrity_check').get().integrity_check !== 'ok') throw new ErrorUsuario('La información del archivo está dañada');
      const tablas = new Set(x.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((r) => r.name));
      if (!tablas.has('habitaciones') || !tablas.has('usuarios') || !tablas.has('config')) throw new ErrorUsuario('El archivo no es una exportación de Maxsel Hotel');
      if (!x.prepare("SELECT COUNT(*) n FROM usuarios WHERE activo=1 AND rol='admin'").get().n) throw new ErrorUsuario('El archivo no tiene ningún usuario administrador activo');
      x.exec('DELETE FROM sesiones');
      if (q.conservar !== '0') { const up = x.prepare('INSERT INTO config(clave,valor) VALUES(?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor'); for (const k of CFG_LOCAL) up.run(k, cfg(k) ?? ''); }
    } finally { x.close(); }
  } catch (e) { try { fs.unlinkSync(tmp); } catch { /* nada */ } if (e instanceof ErrorUsuario) throw e; throw new ErrorUsuario('No se pudo leer la información del archivo: ' + e.message); }
  const respaldo = respaldar('antes_de_importar');
  let nf = 0;
  for (const [f, b64] of Object.entries(d.archivos || {})) { const nom = path.basename(f); if (!/^[\w.-]+$/.test(nom)) continue; fs.writeFileSync(path.join(FOTOS_DIR, nom), Buffer.from(b64, 'base64')); nf++; }
  fs.renameSync(tmp, IMPORT_PENDIENTE);
  fs.writeFileSync(path.join(DATA_DIR, 'importar_info.json'), JSON.stringify({ fecha: ahora(), usuario: u.nombre, origen: d.hotel, exportado: d.fecha, modo: d.modo, ip: ipDe(req) }));
  console.log(`  [${ahora()}] Importación de "${d.hotel}" (${d.modo}) por ${u.nombre}. Respaldo previo: ${respaldo}. Reiniciando...`);
  setTimeout(() => process.exit(0), 1500).unref?.();
  return { ok: true, respaldo, fotos: nf, modo: d.modo, hotel: d.hotel, fecha: d.fecha, resumen: d.resumen, servicio: !!process.env.MAXSEL_SERVICIO };
});
// Al arrancar con información importada: deja constancia en la bitácora
if (SE_IMPORTO) {
  try {
    const f = path.join(DATA_DIR, 'importar_info.json'), i = fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : {};
    run('INSERT INTO auditoria(fecha,usuario_id,usuario,accion,ruta,detalle,ip) VALUES(?,?,?,?,?,?,?)', ahora(), null, i.usuario || '—',
      `Importó información de otra computadora${i.origen ? ' (' + i.origen + ')' : ''} · ${i.modo === 'config' ? 'solo configuración' : 'información completa'}`, 'POST /api/importar', JSON.stringify(i).slice(0, 800), i.ip || '');
    fs.unlinkSync(f);
  } catch { /* nada */ }
}

// ---------- Archivos estáticos ----------
const TIPOS = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json' };
function estatico(res, archivo) {
  const r = path.join(PUBLIC, archivo);
  if (!r.startsWith(PUBLIC) || !fs.existsSync(r) || fs.statSync(r).isDirectory()) return false;
  res.writeHead(200, { 'Content-Type': TIPOS[path.extname(r)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Frame-Options': 'DENY' });
  fs.createReadStream(r).pipe(res);
  return true;
}
function usuarioDe(req, res) {
  const tk = cookies(req).htl_s;
  if (!tk) return null;
  const u = get('SELECT u.*, s.creado sesion_creada FROM sesiones s JOIN usuarios u ON u.id=s.usuario_id WHERE s.token=? AND u.activo=1', tk) || null;
  // Sesión que se renueva sola (la pantalla del checador queda abierta semanas)
  if (u && res && u.sesion_creada < fechaMas(hoy(), -1)) {
    run('UPDATE sesiones SET creado=? WHERE token=?', ahora(), tk);
    res.setHeader('Set-Cookie', `htl_s=${tk}; HttpOnly; SameSite=Strict; Path=/; Max-Age=2592000`);
  }
  return u;
}

async function manejar(req, res) {
  const url = new URL(req.url, 'http://x');
  const r0 = decodeURIComponent(url.pathname);
  try {
    // 1.18: desde el teléfono por Tailscale Funnel (internet): solo consultar
    if (req.desdeInternet) {
      res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Referrer-Policy', 'no-referrer'); res.setHeader('X-Frame-Options', 'DENY');
      if (r0.startsWith('/ical/')) return icalPublico(res, url, r0);
      if (r0.startsWith('/iclock/') || r0 === '/checador') { res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('No disponible desde internet'); }
      if (r0.startsWith('/api/')) {
        if (req.method !== 'GET' && !['/api/login', '/api/logout'].includes(r0)) return enviar(res, 403, { error: 'Desde el teléfono (fuera del hotel) solo se puede consultar. Para hacer cambios use la computadora del hotel.' });
        const rr = rutas.find((x) => x.metodo === req.method && x.re.test(r0));
        if (rr && ['config', 'usuarios'].includes(rr.rol) && r0 !== '/api/config') return enviar(res, 403, { error: 'Esto solo se puede ver en la computadora del hotel.' });
      }
    }
    // Desde internet (fuera de la red local o Tailscale) solo si el administrador lo permite
    if (r0.startsWith('/ical/') && (ipPrivada(ipDe(req)) || cfg('ical_publico') === '1' || cfg('permitir_internet') === '1')) return icalPublico(res, url, r0);
    if (!req.desdeInternet && !ipPrivada(ipDe(req))) { // 1.18: desde internet solo por Tailscale Funnel
      res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Acceso desde internet desactivado. Active el acceso desde el teléfono en Configuración → Monitoreo remoto (Tailscale Funnel).');
    }
    if (r0.startsWith('/iclock/') && !moduloActivo('asistencia')) { res.writeHead(403); return res.end('OK'); }
    if (r0 === '/checador' && !moduloActivo('asistencia')) { // 1.19.1: el checador solo abre si la licencia trae Asistencia
      res.writeHead(403, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Checador · Maxsel Hotel</title><body style="font-family:system-ui,sans-serif;background:#f4f1ee;margin:0"><div style="background:#cd6628;color:#fff;padding:18px 20px;font-weight:800;font-size:20px">Maxsel Hotel · Checador</div><div style="max-width:460px;margin:40px auto;background:#fff;border-radius:14px;padding:24px;text-align:center;border:1px solid #e3ddd6"><h2 style="margin:0 0 8px">Módulo de Asistencia no incluido</h2><p style="color:#5a6878;line-height:1.5">El checador de empleados (entradas, salidas, retardos y faltas) se activa con la licencia. Para agregarlo comuníquese con Maxsel.</p><p style="font-weight:700">WhatsApp 664 337 5433</p></div></body>');
    }
    if (r0.startsWith('/iclock/')) { const b = req.method === 'POST' ? await leerCuerpo(req, 5 * 1024 * 1024) : Buffer.alloc(0); return iclock(req, res, url, r0, b); }
    if (r0.startsWith('/api/')) {
      if (!LICENCIA.activa && !SIN_LICENCIA_OK.has(r0)) return enviar(res, 402, { error: 'El sistema no tiene licencia activa. ' + (LICENCIA.motivo || ''), sinLicencia: true });
      const mod = moduloDeRuta(r0);
      if (mod && !moduloActivo(mod)) return enviar(res, 403, { error: SIN_MODULO(mod), modulo: mod });
      const r = rutas.find((x) => x.metodo === req.method && x.re.test(r0));
      if (!r) return enviar(res, 404, { error: 'Ruta no encontrada' });
      const u = usuarioDe(req, res);
      if (r.rol && !u) return enviar(res, 401, { error: 'Inicie sesión' });
      if (u) u.perm = new Set(permisosDe(u));
      if (r.rol && !autorizado(u, r.rol)) return enviar(res, 403, { error: TEXTO_PERMISO[r.rol] ? `Su usuario no tiene permiso para: ${TEXTO_PERMISO[r.rol].toLowerCase()}. Pídaselo al administrador.` : 'Su usuario no tiene permiso para esto.' });
      let body = {};
      if (['POST', 'PUT', 'DELETE'].includes(req.method)) {
        const bin = /octet-stream/.test(req.headers['content-type'] || '') && r.rol === 'config';
        const b = await leerCuerpo(req, bin ? 600 * 1024 * 1024 : undefined);
        if (bin) body = { _raw: b };
        else if (b.length) { try { body = JSON.parse(b.toString()); } catch { throw new ErrorUsuario('Datos inválidos'); } }
      }
      cajonPendiente = false;
      const out = await r.fn({ req, res, body, u, p: r.re.exec(r0).groups || {}, q: Object.fromEntries(url.searchParams) });
      if (req.method !== 'GET' && !SIN_BITACORA.test(req.method + ' ' + r0)) auditar(u, req, r0, body, out);
      // Cobro o salida de efectivo: manda el pulso para abrir el cajón de dinero
      if (cajonPendiente) { cajonPendiente = false; abrirCajon().catch(() => {}); }
      if (res.headersSent) return;
      return enviar(res, 200, out === undefined ? { ok: true } : out);
    }
    if (r0.startsWith('/fotos/')) {
      if (!usuarioDe(req)) { res.writeHead(401); return res.end(); }
      const f = path.join(FOTOS_DIR, path.basename(r0));
      if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
      res.writeHead(200, { 'Content-Type': f.endsWith('.png') ? 'image/png' : 'image/jpeg', 'Cache-Control': 'private, max-age=86400' });
      return fs.createReadStream(f).pipe(res);
    }
    if (r0 === '/checador' && estatico(res, 'checador.html')) return;
    if (r0 !== '/' && estatico(res, r0.slice(1))) return;
    estatico(res, 'index.html') || (res.writeHead(404), res.end());
  } catch (e) {
    if (res.headersSent) return;
    if (e instanceof ErrorUsuario) return enviar(res, e.status, { error: e.message });
    console.error(e);
    enviar(res, 500, { error: 'Error interno: ' + e.message });
  }
}
const servidor = http.createServer(manejar);
// 1.18: puerto para Tailscale Funnel. Solo escucha en esta computadora; Funnel lo publica en https://<computadora>.<red>.ts.net
const servidorFunnel = http.createServer((req, res) => {
  req.desdeInternet = true;
  if (!nubeLicencia().activa) { // póliza vencida o no incluida: no se entra desde internet
    if (String(req.url || '').startsWith('/api/')) return enviar(res, 402, { error: SIN_POLIZA, vencido: true });
    res.writeHead(402, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    return res.end('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Maxsel Hotel</title><body style="font-family:system-ui,sans-serif;background:#f4f1ee;margin:0"><div style="background:#cd6628;color:#fff;padding:18px 20px;font-weight:800;font-size:20px">Maxsel Hotel</div><div style="max-width:420px;margin:40px auto;background:#fff;border-radius:14px;padding:24px;text-align:center;border:1px solid #e3ddd6"><h2 style="margin:0 0 8px">Monitoreo remoto no activo</h2><p style="color:#5a6878;line-height:1.5">El acceso desde el teléfono es parte de la póliza anual de mantenimiento. Para activarlo o renovarlo comuníquese con Maxsel.</p><p style="font-weight:700">WhatsApp 664 337 5433</p></div></body>');
  }
  manejar(req, res);
});
servidorFunnel.on('error', (e) => console.error('Puerto del monitoreo remoto:', e.message));
servidorFunnel.listen(PUERTO_NUBE, '127.0.0.1');

revisarLicencia();
setInterval(revisarLicencia, 60 * 60 * 1000).unref();
const respaldoDiario = () => { try { const f = respaldar('diario'); if (f) console.log('  Respaldo diario: ' + f); } catch (e) { console.error('No se pudo respaldar:', e.message); } };
setTimeout(respaldoDiario, 15000).unref();
setInterval(respaldoDiario, 60 * 60 * 1000).unref();
setInterval(() => { try { run("DELETE FROM sesiones WHERE creado < datetime('now','localtime','-30 days')"); } catch { /* nada */ } }, 6 * 3600 * 1000).unref();

servidor.listen(PUERTO, '0.0.0.0', () => {
  console.log('\n  ==============================================');
  console.log(`   ${PRODUCTO} v${VERSION}`);
  console.log(`   [${new Date().toLocaleString('es-MX')}] Sistema iniciado`);
  console.log('   Código de equipo (para la licencia): ' + codigoEquipo());
  console.log('   Licencia: ' + (MODO_DESARROLLO ? 'MODO DESARROLLO' : LICENCIA.activa ? 'ACTIVA - ' + LICENCIA.cliente + (LICENCIA.expira ? ' (vence ' + LICENCIA.expira + ')' : ' (permanente)') : 'NO ACTIVADA'));
  console.log(`   Abra en el navegador:  http://localhost:${PUERTO}`);
  for (const i of ipsEquipo()) console.log(`   ${i.tailscale ? 'Monitoreo (Tailscale)' : 'Otras computadoras '}:  http://${i.ip}:${PUERTO}`);
  if (!process.env.MAXSEL_SERVICIO) console.log('   No cierre esta ventana mientras use el sistema');
  console.log('  ==============================================\n');
});
servidor.on('error', (e) => {
  if (e.code === 'EADDRINUSE') console.error(`\n  El puerto ${PUERTO} ya está en uso: el sistema probablemente ya está funcionando.\n`);
  else console.error(e);
  process.exit(1);
});
