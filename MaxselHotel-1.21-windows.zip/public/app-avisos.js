// Maxsel Hotel 1.21 — botón "Activar notificaciones" para el personal de limpieza y mantenimiento.
// Las notificaciones llegan con la app gratuita "ntfy" (Android y iPhone), aunque el celular tenga la pantalla apagada.
// Con la app del hotel abierta, además suena y vibra cuando llega un trabajo nuevo.
'use strict';
let AVISO_CEL = null;
const esPersonal = () => YO && (YO.rol === 'limpieza' || YO.rol === 'mantenimiento');
async function cargarAvisos() { try { AVISO_CEL = await GET('/api/avisos'); } catch { AVISO_CEL = null; } return AVISO_CEL; }

if (typeof vMant === 'function') {
  const _vm = vMant;
  vMant = async function (...a) {
    const r = await _vm(...a);
    if (esPersonal()) {
      if (!AVISO_CEL) await cargarAvisos();
      const fila = document.querySelector('#main .top .row');
      if (fila && !document.getElementById('btnAvisos')) {
        fila.insertAdjacentHTML('beforeend', AVISO_CEL?.activo
          ? `<button class="btn op" id="btnAvisos" onclick="avisosModal()">Notificaciones activas</button>`
          : `<button class="btn op" id="btnAvisos" onclick="avisosModal()" style="border-color:var(--pri,#1e40af)">Activar notificaciones</button>`);
      }
    }
    return r;
  };
}

function avisosModal() {
  const a = AVISO_CEL || {}, host = String(a.servidor || 'https://ntfy.sh').replace(/^https?:\/\//, '');
  const and = 'https://play.google.com/store/apps/details?id=io.heckel.ntfy', ios = 'https://apps.apple.com/app/ntfy/id1625396347';
  if (!a.activo) {
    modal('Activar notificaciones', `<p>Para que le llegue un aviso al celular cada vez que le manden un trabajo, aunque tenga la pantalla apagada:</p>
      <ol style="padding-left:20px;line-height:1.6">
        <li>Instale la app gratuita <b>ntfy</b>: <a href="${and}" target="_blank" rel="noopener">Android</a> · <a href="${ios}" target="_blank" rel="noopener">iPhone</a></li>
        <li>Regrese aquí y toque <b>Activar</b>.</li>
      </ol>`, `<button class="btn" onclick="cerrar()">Ahora no</button><button class="btn pri" onclick="avisosActivar()">Activar</button>`);
    return;
  }
  const enlace = `ntfy://${host}/${a.tema}`;
  modal('Notificaciones', `<p><b>Paso 1.</b> Si no la tiene, instale la app gratuita <b>ntfy</b>: <a href="${and}" target="_blank" rel="noopener">Android</a> · <a href="${ios}" target="_blank" rel="noopener">iPhone</a></p>
    <p><b>Paso 2.</b> Toque este botón para suscribirse a sus avisos:</p>
    <p><a class="btn pri" href="${enlace}" style="display:inline-block;text-decoration:none">Suscribirme en ntfy</a></p>
    <p class="sub">Si el botón no abre la app: en ntfy toque <b>+</b>, escriba este nombre y toque Suscribirse:</p>
    <div class="row" style="gap:8px;flex-wrap:wrap"><code id="avTema" style="user-select:all;padding:8px 10px;border:1px solid var(--line,#ddd);border-radius:8px;word-break:break-all">${esc(a.tema)}</code><button class="btn sm" onclick="avisosCopiar()">Copiar</button></div>
    ${host !== 'ntfy.sh' ? `<p class="sub">Servidor: ${esc(host)} (en ntfy, "Usar otro servidor")</p>` : ''}
    <p><b>Paso 3.</b> Toque <b>Mandar prueba</b>: debe sonarle una notificación en unos segundos.</p>
    <p class="sub">Este nombre es solo suyo: no lo comparta. Con la app del hotel abierta también suena y vibra.</p>`,
  `<button class="btn bad" onclick="avisosQuitar()">Desactivar</button><button class="btn" onclick="cerrar()">Cerrar</button><button class="btn pri" onclick="avisosPrueba()">Mandar prueba</button>`);
}
async function avisosActivar() { AVISO_CEL = await hacer(() => POST('/api/avisos/activar', {})); if (AVISO_CEL) { avisosModal(); sonidoCel(true); vMant(); } }
async function avisosPrueba() { const r = await hacer(() => POST('/api/avisos/prueba', {}), 'Prueba enviada'); if (r) toast('Prueba enviada. Si no le llegó, revise el paso 2.'); }
async function avisosQuitar() { await hacer(() => POST('/api/avisos/desactivar', {}), 'Notificaciones desactivadas'); await cargarAvisos(); cerrar(); vMant(); }
function avisosCopiar() {
  const t = AVISO_CEL?.tema || '';
  try { navigator.clipboard.writeText(t).then(() => toast('Copiado'), () => toast('Mantenga presionado el nombre para copiarlo')); } catch { toast('Mantenga presionado el nombre para copiarlo'); }
}

// ---------- Con la app abierta: suena y vibra cuando llega un trabajo nuevo ----------
let ctxSonidoCel = null;
function sonidoCel(soloPreparar) {
  try {
    ctxSonidoCel = ctxSonidoCel || new (window.AudioContext || window.webkitAudioContext)();
    if (ctxSonidoCel.state === 'suspended') ctxSonidoCel.resume();
    if (soloPreparar) return;
    [0, 0.25, 0.5].forEach((t) => { const o = ctxSonidoCel.createOscillator(), g = ctxSonidoCel.createGain(); o.frequency.value = 880; g.gain.value = 0.25; o.connect(g); g.connect(ctxSonidoCel.destination); o.start(ctxSonidoCel.currentTime + t); o.stop(ctxSonidoCel.currentTime + t + 0.15); });
  } catch { /* sin sonidoCel */ }
}
document.addEventListener('click', () => sonidoCel(true), { once: true, capture: true });
let vistosCel = null;
setInterval(async () => {
  if (!esPersonal() || document.hidden) return;
  try {
    const l = await GET('/api/mant?x=1'), ids = new Set(l.map((m) => m.id));
    if (vistosCel) {
      const nuevos = l.filter((m) => !vistosCel.has(m.id));
      if (nuevos.length) {
        sonidoCel(); try { navigator.vibrate?.([300, 150, 300]); } catch { /* nada */ }
        const m = nuevos[0]; toast(`Trabajo nuevo${m.numero ? ' · Hab. ' + m.numero : ''}: ${m.titulo}`);
        if (typeof vista !== 'undefined' && vista === 'mant' && $('#modal').hidden) vMant().catch(() => {});
      }
    }
    vistosCel = ids;
  } catch { /* sin conexión */ }
}, 15000);
