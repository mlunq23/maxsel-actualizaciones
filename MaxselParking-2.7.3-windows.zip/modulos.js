// Módulos que se venden aparte y se encienden desde la LICENCIA (PK1-…), uno por bit:
//   bit 1 = Gastos (gastos y gastos fijos)
//   bit 2 = reservado (asistencia, este sistema no la tiene)
//   bit 4 = Publicidad (renta de espacios publicitarios / lonas): solo para negocios que lo usan
// Licencias versión 2 traen el byte de módulos (firmado). Las licencias viejas (versión 1) no lo traen:
// 2.7.3: para ellas TODOS los módulos quedan apagados (Gastos y Publicidad solo con una licencia que los traiga).
// Va aparte de licencia.js para que llegue también con la actualización por internet (licencia.js no se actualiza así).
'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const DIR = __dirname;
const MODULOS = { gastos: 1, publicidad: 4 };
const NOMBRE = { gastos: 'Gastos', publicidad: 'Publicidad (renta de lonas)' };
const V1 = 0; // licencias viejas: sin módulos
const B32 = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
let LIC_FILE = null, LIC = null, _cache = null, _cacheClave = null;

function b32dec(s) {
  s = String(s).toUpperCase().replace(/[^0-9A-Z]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1');
  const out = []; let bits = 0, val = 0;
  for (const ch of s) { const i = B32.indexOf(ch); if (i < 0) throw new Error(); val = (val << 5) | i; bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } }
  return Buffer.from(out);
}
let _pub = null;
function clavePublica() {
  if (_pub !== null) return _pub;
  try { _pub = (/CLAVE_PUBLICA = '([^']+)'/.exec(fs.readFileSync(path.join(DIR, 'licencia.js'), 'utf8')) || [])[1] || ''; } catch { _pub = ''; }
  return _pub;
}
const desarrollo = () => { const k = clavePublica(); return !k || k.startsWith('__'); };

// Byte de módulos de una licencia ya verificada por su firma (null si no se puede leer)
function byteDe(clave) {
  try {
    const buf = b32dec(String(clave || '').trim().replace(/^PK1-?/i, ''));
    if (buf.length < 14 + 64 || (buf[0] !== 1 && buf[0] !== 2)) return null;
    const nl = buf[13], extra = buf[0] === 2 ? 1 : 0;
    const payload = buf.subarray(0, 14 + nl + extra), firma = buf.subarray(14 + nl + extra, 14 + nl + extra + 64);
    const k = crypto.createPublicKey({ key: Buffer.from(clavePublica(), 'base64'), format: 'der', type: 'spki' });
    if (!crypto.verify(null, payload, k, firma)) return null;
    return extra ? payload[14 + nl] : V1;
  } catch { return null; }
}

function todos() {
  if (desarrollo()) { // pruebas: MAXSEL_SIN_MODULOS=publicidad,gastos apaga módulos
    const sin = String(process.env.MAXSEL_SIN_MODULOS || '').split(',').map((x) => x.trim().toLowerCase());
    return Object.fromEntries(Object.keys(MODULOS).map((k) => [k, !sin.includes(k)]));
  }
  if (LIC && LIC.L && !LIC.L.LICENCIA.activa) return Object.fromEntries(Object.keys(MODULOS).map((k) => [k, false]));
  let clave = ''; try { if (LIC_FILE) clave = fs.readFileSync(LIC_FILE, 'utf8').trim(); } catch { /* sin archivo */ }
  if (clave !== _cacheClave) { _cacheClave = clave; const b = byteDe(clave); _cache = b === null ? 0 : b; }
  return Object.fromEntries(Object.entries(MODULOS).map(([k, bit]) => [k, !!(_cache & bit)]));
}
const activo = (k) => (k in MODULOS ? !!todos()[k] : true);
function iniciarModulos(dataDir, lic) { LIC_FILE = path.join(dataDir, 'licencia.txt'); LIC = lic; _cacheClave = null; }
module.exports = { MODULOS, NOMBRE, todos, activo, iniciarModulos, byteDe };
