'use strict';
/*
 * MAXSEL PARKING v2 - Maxsel Punto de Venta para Estacionamientos
 * Servidor local: Node.js 22.13+ (sin dependencias externas, usa SQLite integrado)
 */
const _emit = process.emitWarning;
process.emitWarning = (w, ...a) => (String(w).includes('SQLite') ? null : _emit.call(process, w, ...a));
const http = require('node:http');
const https = require('node:https');
const zlib = require('node:zlib');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const os = require('node:os');
const crypto = require('node:crypto');
const { execFile, exec } = require('node:child_process');
const { DatabaseSync } = require('node:sqlite');
const LIC = require('./licencia.js');
const { crearFunnel } = require('./funnel.js');
const { poliza, iniciarPoliza } = require('./poliza.js');
const MOD = require('./modulos.js');

const VERSION = '2.7.3';
const PRODUCTO = 'Maxsel Punto de Venta para Estacionamientos';
const PORT = Number(process.env.PORT || 3040);
const DATA_DIR = process.env.MAXSEL_DATOS || path.join(__dirname, 'datos');
const PUBLIC_DIR = path.join(__dirname, 'public');
fs.mkdirSync(DATA_DIR, { recursive: true });
LIC.iniciar(DATA_DIR);
MOD.iniciarModulos(DATA_DIR, LIC);
iniciarPoliza(DATA_DIR);

const db = new DatabaseSync(path.join(DATA_DIR, 'parking.db'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');

/* ============================ ESQUEMA ============================ */
db.exec(`
CREATE TABLE IF NOT EXISTS config (clave TEXT PRIMARY KEY, valor TEXT);
CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, usuario TEXT UNIQUE NOT NULL,
  pass TEXT NOT NULL, rol TEXT NOT NULL DEFAULT 'cajero', permisos TEXT NOT NULL DEFAULT '[]',
  activo INTEGER NOT NULL DEFAULT 1, creado INTEGER);
CREATE TABLE IF NOT EXISTS tarifas (
  id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, modo TEXT NOT NULL DEFAULT 'hora',
  precio_hora REAL DEFAULT 0, horas_bloque REAL DEFAULT 12, precio_bloque REAL DEFAULT 0,
  excedente TEXT DEFAULT 'hora', precio_hora_extra REAL DEFAULT 0, tolerancia_min INTEGER DEFAULT 10,
  minutos_gratis INTEGER DEFAULT 0, tope REAL DEFAULT 0, es_mesero INTEGER DEFAULT 0,
  activo INTEGER DEFAULT 1, orden INTEGER DEFAULT 0, escalones TEXT DEFAULT '[]');
CREATE TABLE IF NOT EXISTS convenios (
  id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, tipo TEXT NOT NULL DEFAULT 'porcentaje',
  valor REAL DEFAULT 0, tarifa_id INTEGER, notas TEXT DEFAULT '', activo INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS turnos (
  id INTEGER PRIMARY KEY AUTOINCREMENT, usuario_id INTEGER NOT NULL, apertura INTEGER NOT NULL, cierre INTEGER,
  fondo_pesos REAL DEFAULT 0, fondo_usd REAL DEFAULT 0, tipo_cambio REAL DEFAULT 0,
  decl_pesos REAL, decl_usd REAL, decl_tarjeta REAL, notas TEXT DEFAULT '', estado TEXT DEFAULT 'abierto');
CREATE TABLE IF NOT EXISTS clientes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, telefono TEXT DEFAULT '', tipo TEXT DEFAULT 'mesero',
  tarifa_id INTEGER, notas TEXT DEFAULT '', vigente_desde INTEGER, vigente_hasta INTEGER, activo INTEGER DEFAULT 1, creado INTEGER);
CREATE TABLE IF NOT EXISTS vehiculos (
  id INTEGER PRIMARY KEY AUTOINCREMENT, cliente_id INTEGER NOT NULL, placas TEXT DEFAULT '', marca TEXT DEFAULT '',
  modelo TEXT DEFAULT '', color TEXT DEFAULT '', activo INTEGER DEFAULT 1);
CREATE INDEX IF NOT EXISTS ix_veh_cliente ON vehiculos(cliente_id);
CREATE TABLE IF NOT EXISTS pension_periodos (
  id INTEGER PRIMARY KEY AUTOINCREMENT, cliente_id INTEGER, plan TEXT, desde INTEGER, hasta INTEGER,
  monto REAL, pago_id INTEGER, fecha INTEGER, usuario_id INTEGER);
CREATE TABLE IF NOT EXISTS productos (
  id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, tipo TEXT DEFAULT 'servicio', precio REAL DEFAULT 0,
  activo INTEGER DEFAULT 1, orden INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS tickets (
  id INTEGER PRIMARY KEY AUTOINCREMENT, placas TEXT DEFAULT '', marca TEXT DEFAULT '', modelo TEXT DEFAULT '',
  color TEXT DEFAULT '', modo_ingreso TEXT DEFAULT 'rapido', cliente TEXT DEFAULT 'normal',
  tarifa_id INTEGER, tarifa_cobro_id INTEGER, cliente_id INTEGER, vehiculo_id INTEGER, entrada INTEGER NOT NULL, salida INTEGER,
  estado TEXT DEFAULT 'dentro', minutos INTEGER, subtotal REAL DEFAULT 0, descuento REAL DEFAULT 0,
  cargo_perdido REAL DEFAULT 0, extras_total REAL DEFAULT 0, total REAL DEFAULT 0, convenio_id INTEGER,
  cortesia_para TEXT, cortesia_motivo TEXT, perdido INTEGER DEFAULT 0, perdido_datos TEXT, cancel_motivo TEXT, notas TEXT DEFAULT '',
  usuario_entrada INTEGER, usuario_salida INTEGER, turno_entrada INTEGER, turno_salida INTEGER);
CREATE INDEX IF NOT EXISTS ix_tickets_estado ON tickets(estado);
CREATE INDEX IF NOT EXISTS ix_tickets_entrada ON tickets(entrada);
CREATE INDEX IF NOT EXISTS ix_tickets_salida ON tickets(salida);
CREATE TABLE IF NOT EXISTS pagos (
  id INTEGER PRIMARY KEY AUTOINCREMENT, turno_id INTEGER, usuario_id INTEGER, concepto TEXT,
  ticket_id INTEGER, cliente_id INTEGER, total REAL, monto_extras REAL DEFAULT 0, detalle TEXT DEFAULT '',
  pesos REAL DEFAULT 0, usd REAL DEFAULT 0, tipo_cambio REAL DEFAULT 0, usd_mxn REAL DEFAULT 0, tarjeta REAL DEFAULT 0,
  tarjeta_ref TEXT DEFAULT '', mp_order_id TEXT DEFAULT '', cambio REAL DEFAULT 0, fecha INTEGER, cancelado INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS ix_pagos_fecha ON pagos(fecha);
CREATE TABLE IF NOT EXISTS movimientos (
  id INTEGER PRIMARY KEY AUTOINCREMENT, turno_id INTEGER, usuario_id INTEGER, tipo TEXT, moneda TEXT,
  monto REAL, motivo TEXT, fecha INTEGER);
CREATE TABLE IF NOT EXISTS bitacora (
  id INTEGER PRIMARY KEY AUTOINCREMENT, fecha INTEGER, usuario_id INTEGER, accion TEXT, detalle TEXT);
`);

// Migración desde la versión 1 (pensionados -> clientes con vehículos)
(function migrar() {
  const cols = (t) => db.prepare(`PRAGMA table_info(${t})`).all().map((c) => c.name);
  const agrega = (t, c, def) => { if (!cols(t).includes(c)) db.exec(`ALTER TABLE ${t} ADD COLUMN ${c} ${def}`); };
  agrega('tarifas', 'escalones', "TEXT DEFAULT '[]'");
  for (const [c, d] of [['cliente_id', 'INTEGER'], ['vehiculo_id', 'INTEGER'], ['cortesia_para', 'TEXT'], ['extras_total', 'REAL DEFAULT 0']]) agrega('tickets', c, d);
  for (const [c, d] of [['cliente_id', 'INTEGER'], ['monto_extras', 'REAL DEFAULT 0'], ['detalle', "TEXT DEFAULT ''"]]) agrega('pagos', c, d);
  const tablas = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((t) => t.name);
  if (tablas.includes('pensionados') && !db.prepare('SELECT COUNT(*) n FROM clientes').get().n) {
    db.exec('BEGIN');
    for (const p of db.prepare('SELECT * FROM pensionados').all()) {
      db.prepare('INSERT INTO clientes(id,nombre,telefono,tipo,notas,vigente_desde,vigente_hasta,activo,creado) VALUES(?,?,?,?,?,?,?,?,?)')
        .run(p.id, p.nombre, p.telefono, 'pension', p.notas, p.vigente_desde, p.vigente_hasta, p.activo, p.creado);
      if (p.placas || p.marca) db.prepare('INSERT INTO vehiculos(cliente_id,placas,marca,modelo,color) VALUES(?,?,?,?,?)').run(p.id, p.placas, p.marca, p.modelo, p.color);
    }
    if (cols('tickets').includes('pensionado_id')) db.exec('UPDATE tickets SET cliente_id=pensionado_id WHERE cliente_id IS NULL');
    if (cols('pagos').includes('pensionado_id')) db.exec('UPDATE pagos SET cliente_id=pensionado_id WHERE cliente_id IS NULL');
    db.exec('COMMIT');
  }
  if (cols('pension_periodos').includes('pensionado_id')) {
    db.exec(`ALTER TABLE pension_periodos RENAME TO pension_periodos_v1;
      CREATE TABLE pension_periodos (id INTEGER PRIMARY KEY AUTOINCREMENT, cliente_id INTEGER, plan TEXT, desde INTEGER, hasta INTEGER, monto REAL, pago_id INTEGER, fecha INTEGER, usuario_id INTEGER);
      INSERT INTO pension_periodos SELECT id, pensionado_id, plan, desde, hasta, monto, pago_id, fecha, usuario_id FROM pension_periodos_v1;`);
  }
  agrega('clientes', 'pension_categoria', 'TEXT');
  agrega('pension_periodos', 'categoria', 'TEXT');
  agrega('tickets', 'foto', 'TEXT');
  agrega('productos', 'precio_libre', 'INTEGER DEFAULT 0');
  agrega('productos', 'rapido', 'INTEGER DEFAULT 0');
  agrega('productos', 'codigo', "TEXT DEFAULT ''");
  agrega('pagos', 'transferencia', 'REAL DEFAULT 0');
  db.exec(`CREATE TABLE IF NOT EXISTS gastos (
    id INTEGER PRIMARY KEY AUTOINCREMENT, fecha INTEGER NOT NULL, categoria TEXT NOT NULL, concepto TEXT DEFAULT '', monto REAL NOT NULL,
    origen TEXT DEFAULT 'fuera', turno_id INTEGER, movimiento_id INTEGER, usuario_id INTEGER, cancelado INTEGER DEFAULT 0, creado INTEGER);
    CREATE INDEX IF NOT EXISTS ix_gastos_fecha ON gastos(fecha);
    CREATE TABLE IF NOT EXISTS gastos_fijos (
      id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, categoria TEXT NOT NULL, monto REAL DEFAULT 0, frecuencia TEXT DEFAULT 'mensual',
      dia INTEGER DEFAULT 1, mes_ref INTEGER DEFAULT 1, activo INTEGER DEFAULT 1, notas TEXT DEFAULT '', creado INTEGER);
    CREATE TABLE IF NOT EXISTS espacios_pub (
      id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, ubicacion TEXT DEFAULT '', medidas TEXT DEFAULT '', precio_mensual REAL DEFAULT 0,
      notas TEXT DEFAULT '', activo INTEGER DEFAULT 1, orden INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS rentas_pub (
      id INTEGER PRIMARY KEY AUTOINCREMENT, espacio_id INTEGER NOT NULL, cliente TEXT NOT NULL, telefono TEXT DEFAULT '', anuncio TEXT DEFAULT '',
      desde INTEGER NOT NULL, hasta INTEGER NOT NULL, meses REAL DEFAULT 1, monto REAL NOT NULL, pago_id INTEGER, fecha INTEGER, usuario_id INTEGER, cancelado INTEGER DEFAULT 0);
    CREATE INDEX IF NOT EXISTS ix_rentas_esp ON rentas_pub(espacio_id);`);
  agrega('gastos', 'gasto_fijo_id', 'INTEGER');
})();

/* ============================ CONFIGURACIÓN ============================ */
function sembrar230() {
  const cfg = getConfig();
  if (cfg.semillas_230) return;
  const ins = db.prepare('INSERT INTO productos(nombre, tipo, precio, activo, orden, precio_libre, rapido) VALUES(?,?,?,?,?,?,?)');
  const existe = (n) => db.prepare('SELECT id FROM productos WHERE lower(nombre)=lower(?)').get(n);
  const lavados = db.prepare("SELECT id FROM productos WHERE lower(nombre) LIKE '%lavad%'").all();
  if (lavados.length) db.prepare(`UPDATE productos SET rapido=1 WHERE id IN (${lavados.map((x) => x.id).join(',')})`).run();
  else ins.run('Lavado de auto', 'servicio', 100, 1, 50, 0, 1);
  for (const [n, precio, libre] of [['Uso de baño', 10, 0]]) if (!existe(n)) ins.run(n, 'servicio', precio, 1, 50, libre, 1);
  const cats = cfg.pension_categorias.slice();
  if (!cats.some((c) => /ambulante/i.test(c.nombre))) cats.push({ id: 'carro-ambulante', nombre: 'Carro ambulante', precios: {} });
  setConfig({ pension_categorias: cats, semillas_230: true });
}
const CONFIG_DEFAULT = {
  upd_disponible: '',             // 2.6: versión nueva disponible por internet (la llena el sistema)
  upd_ultima: '',
  empresa_nombre: 'ESTACIONAMIENTO MAXSEL',
  empresa_direccion: 'Calle, número, colonia, ciudad',
  empresa_telefono: '',
  empresa_rfc: '',
  capacidad: 50,
  bloquear_lleno: false,
  politicas:
    'El estacionamiento no se hace responsable por objetos dejados dentro del vehículo.\n' +
    'No nos hacemos responsables por daños ocasionados por fenómenos naturales, robo total con violencia o actos de vandalismo.\n' +
    'Conserve su boleto: es indispensable para retirar su vehículo.\n' +
    'Horario de servicio: 24 horas.',
  costo_boleto_perdido: 150,
  imprimir_politicas: true,
  boleto_perdido_texto: 'El boleto perdido tiene un costo adicional al tiempo de estancia.',
  boleto_perdido_politicas:
    'Para entregar un vehículo sin boleto se requiere identificación oficial vigente y tarjeta de circulación a nombre de quien recoge.\n' +
    'Quien firma declara bajo protesta de decir verdad que es el propietario o persona autorizada para retirar el vehículo y libera al estacionamiento de cualquier responsabilidad.',
  mensaje_pago: '¡Gracias por su visita!',
  ticket_logo_maxsel: true,       // logo chico de Maxsel al final del ticket
  maxsel_contacto: '',            // contacto de Maxsel al final del ticket (un renglón por línea)
  pantalla_bienvenida: 'Bienvenido',
  pantalla_gracias: '¡Gracias por su visita, buen camino!',
  tarifa_default_id: 1,
  tarifa_mesero_id: 4,
  tarifa_rapida_id: 0, // 0 = la misma que clientes normales
  tipo_cambio_default: 18.0,
  mostrar_diferencia_cajero: false,
  preguntar_copia_cajero: true,
  imprimir_auto: true, // el ticket se imprime solo al cobrar (sin opción de "Cobrar sin imprimir")
  impresora_tipo: 'ninguna', // ninguna | windows (impresora instalada en Windows) | ip
  impresora_ip: '192.168.1.100',
  impresora_puerto: 9100,
  impresora_nombre: 'POS-80',
  impresora_columnas: 42,         // 2.5.2: 42 cabe en todas las de 80 mm (Epson, Bixolon, Star); las genéricas aceptan 48
  impresora_corte: 'parcial', // parcial | total
  impresora_acentos: true,    // 2.7.2: false = imprime sin acentos (para impresoras que sacan letras raras)
  abrir_cajon_efectivo: true,
  relay_tipo: 'ninguno', // ninguno | http | serial
  relay_url: 'http://192.168.1.50/abrir?token=1234',
  relay_metodo: 'GET',
  relay_puerto_com: 'COM3',
  relay_on_hex: 'A00101A2',
  relay_off_hex: 'A00100A1',
  relay_pulso_ms: 1000,
  abrir_pluma_al_cobrar: true,
  abrir_pluma_al_ingresar: false,
  mp_access_token: '',
  mp_terminal_id: '',
  mp_refresh_token: '', // 2.7.2: conexión con "Iniciar sesión en Mercado Pago" (sin copiar el Access Token)
  mp_token_vence: 0,
  mp_via: '',           // oauth | manual
  pension_precios: { semana: 300, quincena: 550, mes: 1000, trimestre: 2800, semestre: 5400, anual: 10000 },
  // Planes de pensión habilitados (sólo los palomeados aparecen al cobrar)
  pension_planes: ['semana', 'quincena', 'mes', 'trimestre', 'semestre', 'anual', 'personalizado'],
  // Tipos de pensión con su propio precio por plan (carro, camioneta, carro de hotdog…)
  pension_categorias: null,
  // Cortesías: si la lista tiene nombres, sólo se puede dar cortesía a ellos (ej. Sushi)
  cortesia_lista: [],
  // Gastos
  gastos_categorias: ['Mantenimiento', 'Luz', 'Agua', 'Internet', 'Varios'],
  // Cámara de entrada (foto del carro)
  camara_tipo: 'ninguna', // ninguna | ip | usb
  camara_url: '',
  camara_usuario: '',
  camara_password: '',
  camara_dias: 90,
  // 2.5 Lectura de placas: ninguno | nube (Plate Recognizer con la foto de la cámara IP) | camara (cámara LPR que manda la placa)
  lpr_modo: 'ninguno',
  lpr_token: '',
  lpr_regiones: 'mx,us-ca',
  lpr_al_ingreso: true,
  lpr_min_confianza: 0.5,
  lpr_clave: '',
  // Control de acceso
  bloquear_pension_vencida: false,
  semillas_230: false,
};
const CONFIG_SECRETA = ['mp_access_token', 'mp_refresh_token', 'camara_password', 'lpr_token', 'lpr_clave'];

function getConfig() {
  const cfg = { ...CONFIG_DEFAULT };
  for (const r of db.prepare('SELECT clave, valor FROM config').all()) {
    try { cfg[r.clave] = JSON.parse(r.valor); } catch { cfg[r.clave] = r.valor; }
  }
  if (!Array.isArray(cfg.pension_categorias) || !cfg.pension_categorias.length)
    cfg.pension_categorias = [{ id: 'carro', nombre: 'Carro', precios: { ...(cfg.pension_precios || {}) } }];
  if (!Array.isArray(cfg.pension_planes) || !cfg.pension_planes.length) cfg.pension_planes = ['mes'];
  return cfg;
}
function limpiaCategorias(lista) {
  const usados = new Set();
  return (Array.isArray(lista) ? lista : []).map((c, i) => {
    const nombre = String(c && c.nombre || '').trim().slice(0, 40);
    if (!nombre) return null;
    let id = String(c.id || '').trim() || nombre.toLowerCase().normalize('NFD').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'cat' + i;
    while (usados.has(id)) id += '_';
    usados.add(id);
    const precios = {};
    for (const p of Object.keys(PLANES)) if (p !== 'personalizado' && num(c.precios && c.precios[p]) > 0) precios[p] = r2(num(c.precios[p]));
    return { id, nombre, precios };
  }).filter(Boolean);
}
function limpiaLista(a, max = 40) {
  return [...new Set((Array.isArray(a) ? a : String(a || '').split(/[\n,]/)).map((x) => String(x).trim().slice(0, max)).filter(Boolean))];
}
function setConfig(obj) {
  if ('cortesia_lista' in obj) obj.cortesia_lista = limpiaLista(obj.cortesia_lista, 80);
  if ('gastos_categorias' in obj) { obj.gastos_categorias = limpiaLista(obj.gastos_categorias); if (!obj.gastos_categorias.length) obj.gastos_categorias = ['Varios']; }
  if ('camara_tipo' in obj && !['ninguna', 'ip', 'usb'].includes(obj.camara_tipo)) obj.camara_tipo = 'ninguna';
  if ('lpr_modo' in obj && !['ninguno', 'nube', 'camara'].includes(obj.lpr_modo)) obj.lpr_modo = 'ninguno';
  if ('lpr_min_confianza' in obj) obj.lpr_min_confianza = Math.min(1, Math.max(0, num(obj.lpr_min_confianza, 0.5)));
  delete obj.lpr_clave; // la clave se cambia con su botón
  if ('mp_access_token' in obj && obj.mp_access_token !== '********' && !('mp_via' in obj)) { obj.mp_via = obj.mp_access_token ? 'manual' : ''; obj.mp_refresh_token = ''; obj.mp_token_vence = 0; }
  if ('impresora_columnas' in obj) obj.impresora_columnas = Math.max(24, Math.min(64, Math.round(num(obj.impresora_columnas, 42)) || 42));
  if ('pension_categorias' in obj) { obj.pension_categorias = limpiaCategorias(obj.pension_categorias); if (!obj.pension_categorias.length) fallo('Debe haber al menos un tipo de pensión'); }
  if ('pension_planes' in obj) { obj.pension_planes = (Array.isArray(obj.pension_planes) ? obj.pension_planes : []).filter((p) => PLANES[p]); if (!obj.pension_planes.length) fallo('Habilite al menos un plan de pensión'); }
  const st = db.prepare('INSERT INTO config(clave, valor) VALUES(?, ?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor');
  for (const [k, v] of Object.entries(obj)) {
    if (!(k in CONFIG_DEFAULT)) continue;
    if (CONFIG_SECRETA.includes(k) && v === '********') continue;
    st.run(k, JSON.stringify(v));
  }
}

/* ============================ PERMISOS ============================ */
const PERMISOS = {
  ingreso_rapido: 'Ingreso rápido de vehículos',
  ingreso_manual: 'Ingreso manual (marca, modelo, color, placas)',
  cobrar: 'Cobrar boletos',
  boleto_perdido: 'Cobrar boleto perdido',
  aplicar_convenio: 'Aplicar convenios con negocios',
  cambiar_tarifa: 'Cambiar la tarifa al cobrar',
  cortesia: 'Dar cortesías (salida sin costo)',
  cancelar_ticket: 'Cancelar boletos',
  reimprimir: 'Reimprimir boletos y comprobantes',
  vender_productos: 'Vender productos y servicios',
  pensiones_cobrar: 'Cobrar pensiones',
  clientes_admin: 'Registrar clientes, meseros y sus vehículos',
  movimientos: 'Retiros e ingresos de efectivo en caja',
  gastos: 'Registrar gastos (mantenimiento, luz, agua, internet…)',
  publicidad: 'Rentar y cobrar espacios publicitarios (lonas)',
  abrir_pluma: 'Abrir pluma / puerta manualmente',
  ver_diferencias: 'Ver faltantes y sobrantes en su propio corte',
  reportes: 'Ver reportes',
  productos_admin: 'Administrar productos y servicios',
  convenios_admin: 'Administrar convenios',
  tarifas_admin: 'Administrar tarifas',
  configuracion: 'Configuración del sistema',
  usuarios: 'Usuarios y permisos',
  bitacora: 'Ver bitácora de movimientos',
};
const PERMISOS_ROL = {
  cajero: ['ingreso_rapido', 'ingreso_manual', 'cobrar', 'boleto_perdido', 'aplicar_convenio', 'reimprimir', 'vender_productos', 'pensiones_cobrar'],
  supervisor: ['ingreso_rapido', 'ingreso_manual', 'cobrar', 'boleto_perdido', 'aplicar_convenio', 'cambiar_tarifa', 'cortesia',
    'cancelar_ticket', 'reimprimir', 'vender_productos', 'pensiones_cobrar', 'clientes_admin', 'movimientos', 'abrir_pluma', 'ver_diferencias', 'reportes', 'bitacora'],
};
function permisosDe(u) {
  if (u.rol === 'admin') return Object.keys(PERMISOS);
  let p = []; try { p = JSON.parse(u.permisos || '[]'); } catch { /* */ }
  return p.map((x) => (x === 'pensiones_admin' ? 'clientes_admin' : x));
}

/* ============================ SEMILLA ============================ */
function hashPass(p) {
  const salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.scryptSync(String(p), salt, 64).toString('hex');
}
function checkPass(p, h) {
  const [salt, key] = String(h).split(':');
  const k2 = crypto.scryptSync(String(p), salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(key, 'hex'), Buffer.from(k2, 'hex'));
}
if (!db.prepare('SELECT COUNT(*) n FROM usuarios').get().n) {
  db.prepare('INSERT INTO usuarios(nombre, usuario, pass, rol, permisos, creado) VALUES(?,?,?,?,?,?)')
    .run('Administrador', 'admin', hashPass('admin'), 'admin', '[]', Date.now());
  db.prepare('INSERT INTO usuarios(nombre, usuario, pass, rol, permisos, creado) VALUES(?,?,?,?,?,?)')
    .run('Cajero 1', 'cajero', hashPass('1234'), 'cajero', JSON.stringify(PERMISOS_ROL.cajero), Date.now());
}
if (!db.prepare('SELECT COUNT(*) n FROM tarifas').get().n) {
  const st = db.prepare(`INSERT INTO tarifas(nombre, modo, precio_hora, horas_bloque, precio_bloque, excedente, precio_hora_extra,
    tolerancia_min, minutos_gratis, tope, es_mesero, orden, escalones) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  st.run('Normal (por hora)', 'hora', 20, 12, 0, 'hora', 0, 10, 0, 0, 0, 1, '[]');
  st.run('12 horas', 'bloque', 0, 12, 100, 'hora', 20, 10, 0, 0, 0, 2, '[]');
  st.run('Día completo (24 h)', 'bloque', 0, 24, 150, 'bloque', 0, 15, 0, 0, 0, 3, '[]');
  st.run('Mesero 12 horas', 'bloque', 0, 12, 50, 'hora', 15, 15, 0, 0, 1, 4, '[]');
  st.run('Precio por hora (escalonada)', 'escalonada', 0, 12, 0, 'hora', 15, 10, 0, 0, 0, 5, '[30,20,20,15]');
  st.run('Evento (precio fijo)', 'fija', 0, 12, 100, 'hora', 0, 0, 0, 0, 0, 6, '[]');
}
if (!db.prepare('SELECT COUNT(*) n FROM convenios').get().n) {
  const st = db.prepare('INSERT INTO convenios(nombre, tipo, valor, tarifa_id, notas) VALUES(?,?,?,?,?)');
  st.run('Restaurante (ejemplo)', 'horas', 2, null, '2 horas gratis con sello del restaurante');
  st.run('Plaza (ejemplo)', 'porcentaje', 50, null, '50% de descuento');
}
if (!db.prepare('SELECT COUNT(*) n FROM productos').get().n) {
  const st = db.prepare('INSERT INTO productos(nombre, tipo, precio, orden) VALUES(?,?,?,?)');
  st.run('Lavado exterior', 'servicio', 120, 1);
  st.run('Lavado completo', 'servicio', 200, 2);
  st.run('Agua embotellada', 'producto', 20, 3);
}

/* ============================ UTILIDADES ============================ */
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const num = (n, d = 0) => (Number.isFinite(Number(n)) ? Number(n) : d);
const money = (n) => '$' + r2(n).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const folio = (id) => String(id).padStart(6, '0');
const hora12 = (d) => { d = new Date(d); const h = d.getHours(); return String(h % 12 || 12).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0') + (h < 12 ? ' a.m.' : ' p.m.'); };
const fechaHora = (ms) => (ms ? new Date(ms).toLocaleDateString('es-MX', { day: '2-digit', month: '2-digit', year: 'numeric' }) + ', ' + hora12(ms) : '');
function tiempoTxt(min) {
  min = Math.max(0, Math.round(min));
  const d = Math.floor(min / 1440), h = Math.floor((min % 1440) / 60), m = min % 60;
  return (d ? d + 'd ' : '') + (h || d ? h + 'h ' : '') + m + 'min';
}
const limpiaPlaca = (p) => String(p || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
const SQL_PLACA = "REPLACE(REPLACE(UPPER(placas),'-',''),' ','')";
function bitacora(uid, accion, detalle) {
  db.prepare('INSERT INTO bitacora(fecha, usuario_id, accion, detalle) VALUES(?,?,?,?)')
    .run(Date.now(), uid || null, accion, typeof detalle === 'string' ? detalle : JSON.stringify(detalle || ''));
}
function tx(fn) {
  db.exec('BEGIN');
  try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; }
}
class ErrorUsuario extends Error { constructor(msg, code = 400) { super(msg); this.code = code; } }
const fallo = (msg, code) => { throw new ErrorUsuario(msg, code); };
const jsonArr = (s) => { try { const a = JSON.parse(s || '[]'); return Array.isArray(a) ? a : []; } catch { return []; } };

/* ============================ CÁLCULO DE TARIFAS ============================ */
// Horas completas + 1 si los minutos sobrantes rebasan la tolerancia
function horasCobradas(min, tol) {
  const h = Math.floor(min / 60), r = min % 60;
  return h + (r > tol ? 1 : 0);
}
// Escalonada: precio capturado a mano para cada hora (hora 1, hora 2, ...) y después precio por hora adicional
function costoEscalonado(t, horas) {
  const esc = jsonArr(t.escalones).map(Number);
  let monto = 0;
  for (let i = 0; i < horas; i++) monto += i < esc.length ? esc[i] : num(t.precio_hora_extra);
  return monto;
}
function calcularTarifa(t, minutos) {
  const min = Math.max(0, Math.ceil(minutos));
  const tol = num(t.tolerancia_min);
  if (min <= num(t.minutos_gratis)) return { monto: 0, detalle: `Dentro de ${t.minutos_gratis} min sin costo` };
  if (t.modo === 'fija') return { monto: r2(t.precio_bloque), detalle: `Precio fijo ${money(t.precio_bloque)}` };
  if (t.modo === 'hora' || t.modo === 'escalonada') {
    const esc = t.modo === 'escalonada';
    const costo = (h) => (esc ? costoEscalonado(t, h) : h * num(t.precio_hora));
    const hrs = Math.max(1, horasCobradas(min, tol));
    let monto = costo(hrs);
    let detalle = esc ? `${hrs} h según tabla de precios por hora` : `${hrs} h × ${money(t.precio_hora)}`;
    if (num(t.tope) > 0) {
      const dias = Math.floor(min / 1440), resto = min - dias * 1440;
      const hResto = dias ? horasCobradas(resto, tol) : Math.max(1, horasCobradas(resto, tol));
      const conTope = dias * t.tope + Math.min(t.tope, costo(hResto));
      if (conTope < monto) { monto = conTope; detalle += ` (tope de ${money(t.tope)} por día)`; }
    }
    return { monto: r2(monto), detalle };
  }
  // modo bloque (12 h, 24 h, etc.)
  const B = Math.max(1, num(t.horas_bloque, 12) * 60);
  if (t.excedente === 'bloque') {
    const n = Math.max(1, Math.floor(min / B) + ((min % B) > tol ? 1 : 0));
    return { monto: r2(n * t.precio_bloque), detalle: `${n} × ${t.horas_bloque} h × ${money(t.precio_bloque)}` };
  }
  if (min <= B + tol) return { monto: r2(t.precio_bloque), detalle: `Bloque ${t.horas_bloque} h ${money(t.precio_bloque)}` };
  const extra = horasCobradas(min - B, tol);
  return {
    monto: r2(num(t.precio_bloque) + extra * num(t.precio_hora_extra)),
    detalle: `Bloque ${t.horas_bloque} h ${money(t.precio_bloque)} + ${extra} h extra × ${money(t.precio_hora_extra)}`,
  };
}
function describeTarifa(t) {
  if (!t) return '';
  const tol = ` · tolerancia ${t.tolerancia_min} min`;
  if (t.modo === 'fija') return `Precio fijo ${money(t.precio_bloque)}`;
  if (t.modo === 'escalonada') {
    const esc = jsonArr(t.escalones);
    return esc.map((p, i) => `${i + 1}a hora ${money(p)}`).join(', ') + `; hora adicional ${money(t.precio_hora_extra)}` + tol + (t.tope > 0 ? ` · tope ${money(t.tope)}/día` : '');
  }
  if (t.modo === 'hora') return `${money(t.precio_hora)} por hora` + tol + (t.tope > 0 ? ` · tope ${money(t.tope)}/día` : '');
  if (t.excedente === 'bloque') return `${money(t.precio_bloque)} cada ${t.horas_bloque} h` + tol;
  return `${money(t.precio_bloque)} por ${t.horas_bloque} h, después ${money(t.precio_hora_extra)}/hora` + tol;
}
const getTarifa = (id) => db.prepare('SELECT * FROM tarifas WHERE id=?').get(id);
const getConvenio = (id) => db.prepare('SELECT * FROM convenios WHERE id=?').get(id);
const getTicket = (id) => db.prepare('SELECT * FROM tickets WHERE id=?').get(Number(id));
const getCliente = (id) => (id ? db.prepare('SELECT * FROM clientes WHERE id=?').get(Number(id)) : null);
const pensionVigente = (c, ahora = Date.now()) => !!(c && c.activo && c.vigente_hasta && c.vigente_hasta >= ahora);

// Productos y servicios agregados a una cuenta
function armarExtras(items) {
  const out = [];
  for (const it of Array.isArray(items) ? items : []) {
    const p = db.prepare('SELECT * FROM productos WHERE id=? AND activo=1').get(Number(it.producto_id));
    const cant = Math.max(0, Math.round(num(it.cantidad, 1)));
    if (!p || !cant) continue;
    const precio = p.precio_libre ? r2(num(it.precio)) : r2(p.precio);
    if (p.precio_libre && !(precio > 0)) fallo(`Escriba el importe de ${p.nombre}`);
    const nombre = p.precio_libre && String(it.nota || '').trim() ? `${p.nombre} (${String(it.nota).trim().slice(0, 40)})` : p.nombre;
    out.push({ producto_id: p.id, nombre, tipo: p.tipo, precio, cantidad: cant, importe: r2(precio * cant) });
  }
  return out;
}

function cotizar(tk, opt = {}) {
  const cfg = getConfig();
  const ahora = opt.ahora || Date.now();
  const minutos = Math.max(0, (ahora - tk.entrada) / 60000);
  const extras = armarExtras(opt.extras);
  const extras_total = r2(extras.reduce((s, e) => s + e.importe, 0));
  const r = { folio: folio(tk.id), ticket_id: tk.id, entrada: tk.entrada, salida: ahora, minutos: Math.round(minutos), tiempo: tiempoTxt(minutos),
    subtotal: 0, descuento: 0, cargo_perdido: 0, extras, extras_total, total: 0, detalle: '', notas: [], convenio: null, tarifa: null, cliente: null };

  const cli = getCliente(tk.cliente_id);
  if (cli) {
    r.cliente = { id: cli.id, nombre: cli.nombre, tipo: cli.tipo, vigente_hasta: cli.vigente_hasta, vigente: pensionVigente(cli, ahora) };
    if (r.cliente.vigente && !opt.perdido) {
      r.detalle = 'Pensión vigente hasta ' + fechaHora(cli.vigente_hasta);
      r.notas.push('Pensionado: salida sin costo');
      r.total = extras_total;
      return r;
    }
    if (cli.tipo === 'pension') r.notas.push('¡Pensión VENCIDA! Se cobra la tarifa.');
  }
  let t = getTarifa(opt.tarifa_id || tk.tarifa_id) || getTarifa(cfg.tarifa_default_id);
  let mins = minutos;
  const conv = opt.convenio_id ? getConvenio(opt.convenio_id) : null;
  if (conv && conv.tipo === 'tarifa' && conv.tarifa_id) t = getTarifa(conv.tarifa_id) || t;
  if (conv && conv.tipo === 'horas') mins = Math.max(0, minutos - num(conv.valor) * 60);
  r.tarifa = t ? { id: t.id, nombre: t.nombre, descripcion: describeTarifa(t) } : null;

  const base = calcularTarifa(t, minutos);
  r.subtotal = base.monto;
  r.detalle = base.detalle;
  let neto = base.monto;
  if (conv) {
    if (conv.tipo === 'horas') neto = mins <= 0 ? 0 : calcularTarifa(t, mins).monto;
    else if (conv.tipo === 'porcentaje') neto = base.monto * (1 - Math.min(100, num(conv.valor)) / 100);
    else if (conv.tipo === 'monto') neto = Math.max(0, base.monto - num(conv.valor));
    else if (conv.tipo === 'fijo') neto = Math.min(base.monto, num(conv.valor));
    r.convenio = { id: conv.id, nombre: conv.nombre, tipo: conv.tipo, valor: conv.valor };
  }
  r.descuento = r2(base.monto - neto);
  if (opt.perdido) r.cargo_perdido = r2(cfg.costo_boleto_perdido);
  if (opt.cortesia) { r.descuento = r2(r.subtotal); r.cargo_perdido = 0; neto = 0; r.notas.push('Cortesía para: ' + opt.cortesia_para); }
  r.total = r2(neto + r.cargo_perdido + extras_total);
  return r;
}

/* ============================ TICKETS ESC/POS ============================ */
const CP437 = { 'á': 0xA0, 'é': 0x82, 'í': 0xA1, 'ó': 0xA2, 'ú': 0xA3, 'ñ': 0xA4, 'Ñ': 0xA5, 'ü': 0x81, 'Ü': 0x9A, '¿': 0xA8, '¡': 0xAD, 'É': 0x90, '°': 0xF8, '·': 0xFA, '×': 0x78 };
const SIN_ACENTO = { 'Á': 'A', 'Í': 'I', 'Ó': 'O', 'Ú': 'U', 'à': 'a', 'è': 'e', 'ì': 'i', 'ò': 'o', 'ù': 'u' };
function encode437(s) {
  const out = [];
  for (const ch of String(s)) {
    const c = ch.charCodeAt(0);
    if (c < 128) out.push(c);
    else if (CP437[ch] !== undefined) out.push(CP437[ch]);
    else if (SIN_ACENTO[ch]) out.push(SIN_ACENTO[ch].charCodeAt(0));
    else out.push(0x3F);
  }
  return Buffer.from(out);
}
// Para impresoras que no tienen la tabla de acentos: á→a, ñ→n, ¿→?, etc. (solo letras normales)
function quitarAcentos(s) {
  return String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/¿/g, '?').replace(/¡/g, '!').replace(/[·•]/g, '-').replace(/×/g, 'x').replace(/°/g, 'o')
    .replace(/[^\x20-\x7E]/g, '?');
}
function wrap(text, cols) {
  const lines = [];
  for (const parrafo of String(text || '').split('\n')) {
    let line = '';
    for (const w of parrafo.split(/\s+/).filter(Boolean)) {
      if (!line) line = w;
      else if ((line + ' ' + w).length <= cols) line += ' ' + w;
      else { lines.push(line); line = w; }
      while (line.length > cols) { lines.push(line.slice(0, cols)); line = line.slice(cols); }
    }
    lines.push(line);
  }
  return lines;
}
class Ticket {
  constructor(cols) { this.cols = Math.max(24, Math.min(64, Math.round(Number(cols)) || 42)); this.ops = []; this.corte = 'parcial'; }
  align(a) { this.ops.push(['align', a]); return this; }
  bold(b) { this.ops.push(['bold', !!b]); return this; }
  size(w, h) { this.ops.push(['size', w, h]); return this; }
  text(s) { this.ops.push(['text', String(s ?? '')]); return this; }
  para(s, cols) { for (const l of wrap(s, cols || this.cols)) this.text(l); return this; }
  line(ch = '-') { return this.text(ch.repeat(this.cols)); }
  kv(k, v) { k = String(k); v = String(v ?? ''); if (k.length + v.length + 1 > this.cols) k = k.slice(0, Math.max(4, this.cols - v.length - 1)); const sp = Math.max(1, this.cols - k.length - v.length); return this.text(k + ' '.repeat(sp) + v); }
  big(s) { return this.size(2, 2).text(s).size(1, 1); }
  small(on) { this.ops.push(['small', !!on]); return this; } // fuente B: letra chica, 64 caracteres por renglón
  get colsB() { return Math.round(this.cols * 4 / 3); }
  chico(s) { this.small(true); for (const l of wrap(s, this.colsB)) this.text(l); return this.small(false); }
  barcode(data) { this.ops.push(['barcode', String(data)]); return this; }
  feed(n = 1) { this.ops.push(['feed', n]); return this; }
  cut() { this.ops.push(['cut']); return this; }
  drawer() { this.ops.push(['drawer']); return this; }
  img(bpr, h, b64) { this.ops.push(['img', bpr, h, b64]); return this; }
  escpos() {
    const ESC = 0x1B, GS = 0x1D;
    // ESC @ reinicia · FS . apaga el modo chino (Xprinter y genéricas: si no, los acentos salen como letras raras)
    // ESC R 0 juego de caracteres EE.UU. · ESC t 0 tabla PC437 · ESC 3 renglones más juntos (ahorra papel)
    const parts = [Buffer.from([ESC, 0x40, 0x1C, 0x2E, ESC, 0x52, 0x00, ESC, 0x74, 0x00, ESC, 0x33, 26])];
    const enc = this.sinAcentos ? (t) => Buffer.from(quitarAcentos(t), 'latin1') : encode437;
    for (const op of this.ops) {
      switch (op[0]) {
        case 'align': parts.push(Buffer.from([ESC, 0x61, { left: 0, center: 1, right: 2 }[op[1]] ?? 0])); break;
        case 'bold': parts.push(Buffer.from([ESC, 0x45, op[1] ? 1 : 0])); break;
        case 'small': parts.push(Buffer.from(op[1] ? [ESC, 0x4D, 1, ESC, 0x33, 20] : [ESC, 0x4D, 0, ESC, 0x33, 26])); break;
        case 'size': parts.push(Buffer.from([GS, 0x21, ((op[1] - 1) << 4) | (op[2] - 1)])); break;
        case 'text': parts.push(enc(op[1]), Buffer.from([0x0A])); break;
        case 'feed': parts.push(Buffer.from([ESC, 0x64, op[1]])); break;
        case 'barcode': {
          // CODE128 juego C (solo números): barras más anchas y fáciles de leer para el escáner
          let d = String(op[1]).replace(/\D/g, '');
          if (d.length % 2) d = '0' + d;
          const pares = [];
          for (let i = 0; i < d.length; i += 2) pares.push(Number(d.slice(i, i + 2)));
          const data = Buffer.from([0x7B, 0x43, ...pares]); // "{C" + pares de dígitos
          parts.push(Buffer.from([ESC, 0x4A, 18])); // espacio antes de las barras para que no se encime el texto
          parts.push(Buffer.from([GS, 0x68, 100, GS, 0x77, 4, GS, 0x48, 2, GS, 0x66, 1, GS, 0x6B, 73, data.length]), data, Buffer.from([0x0A]));
          break;
        }
        case 'cut': // avanza el papel y CORTA el ticket al terminar de imprimir
          // GS V 65/66: la impresora avanza sola hasta la cuchilla y corta (sin desperdiciar renglones en blanco)
          parts.push(Buffer.from([ESC, 0x64, 1, GS, 0x56, this.corte === 'total' ? 0x41 : 0x42, 0x00])); break;
        case 'drawer': parts.push(Buffer.from([ESC, 0x70, 0x00, 0x19, 0xFA])); break; // pulso al cajón de dinero
        case 'img': { // 2.7.2: logo en franjas de 24 puntos (ESC * 33): lo imprimen Epson, Bixolon, Star, Xprinter y genéricas
          const [, bpr, h, b64] = op, bits = Buffer.from(b64, 'base64'), w = bpr * 8;
          const px = (x, y) => (y < h ? (bits[y * bpr + (x >> 3)] >> (7 - (x & 7))) & 1 : 0);
          parts.push(Buffer.from([ESC, 0x33, 24]));
          for (let y0 = 0; y0 < h; y0 += 24) {
            const banda = Buffer.alloc(w * 3);
            for (let x = 0; x < w; x++) for (let k = 0; k < 3; k++) {
              let b = 0; for (let j = 0; j < 8; j++) b |= px(x, y0 + k * 8 + j) << (7 - j);
              banda[x * 3 + k] = b;
            }
            parts.push(Buffer.from([ESC, 0x2A, 33, w & 255, w >> 8]), banda, Buffer.from([0x0A]));
          }
          parts.push(Buffer.from([ESC, 0x33, 26]));
          break;
        }
      }
    }
    return Buffer.concat(parts);
  }
  preview() {
    const out = []; let align = 'left', w = 1, bold = false, chica = false;
    const pad = (s) => {
      const c = chica ? this.colsB : this.cols;
      s = s.length > c ? s.slice(0, c) : s;
      if (align === 'center') { const l = Math.floor((c - s.length) / 2); return ' '.repeat(Math.max(0, l)) + s; }
      if (align === 'right') return s.padStart(c);
      return s;
    };
    for (const op of this.ops) {
      if (op[0] === 'align') align = op[1];
      else if (op[0] === 'bold') bold = op[1];
      else if (op[0] === 'size') w = op[1];
      else if (op[0] === 'small') chica = op[1];
      else if (op[0] === 'text') out.push({ t: pad(w > 1 ? op[1].split('').join(' ') : op[1]), b: bold || w > 1, big: w > 1, small: chica });
      else if (op[0] === 'feed') for (let i = 0; i < op[1]; i++) out.push({ t: '' });
      else if (op[0] === 'barcode') out.push({ t: pad('▌▌▐ ▌▐▐▌ ▌▌▐▐ ' + op[1] + ' ▌▐▐ ▌▌▐▌▐'), barcode: true });
      else if (op[0] === 'cut') out.push({ t: '✂' + '- '.repeat(Math.floor(this.cols / 2) - 1), cut: true });
      else if (op[0] === 'drawer') out.push({ t: '[ abre cajón de dinero ]', meta: true });
      else if (op[0] === 'img') out.push({ t: '', logo: true });
    }
    return out;
  }
}

function encabezado(tk, cfg) {
  // Nombre en letra grande normal (doble ancho y alto) si cabe; si es muy largo, en negritas normal
  const nom = String(cfg.empresa_nombre || '');
  if (nom.length <= Math.floor(tk.cols / 2)) tk.align('center').bold(true).size(2, 2).text(nom).size(1, 1).bold(false);
  else tk.align('center').bold(true).para(nom).bold(false);
  const datos = [cfg.empresa_direccion, cfg.empresa_telefono ? 'Tel. ' + cfg.empresa_telefono : '', cfg.empresa_rfc ? 'RFC ' + cfg.empresa_rfc : ''].filter(Boolean).join(' · ');
  if (datos) tk.chico(datos);
  return tk;
}
// Al final del ticket: logo de Maxsel chico y discreto, la leyenda y el contacto de Maxsel
const LEYENDA_MAXSEL = ['Sistema Punto de Venta MAXSEL', 'Estacionamientos · Restaurantes · Tiendas · Hoteles'];
const LOGO_MAXSEL_TICKET = {"80":[32,51,"P////8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/////4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAAAAgMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMH/8CAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAw//4/DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADCABn8MAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMIAGYAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwgAZ/DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADD//gMMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMNLGfwwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwkkZ/DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADD//ggMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMNLGCAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAw0kYADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADD//gAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMJJGAAyGMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAw0sYADM9wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADD/xgAM//AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMMzmAAz/8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwf/wADP/wA9vfeghHh88AAAAAAAAAAAAAAAAAAAAAADgAAAAc//ACW05DCMaG6AAAAAAAAAAAAAAAAAAAAAAAP/////z/8AMbBGMY5gZsAAAAAAAAAAAAAAAAAAAAAAAf////+P/wAdnEe7njhm8AAAAAAAAAAAAAAAAAAAAAAA/////w//AAWGRD+aDGaAAAAAAAAAAAAAAAAAAAAAAAAAGBgAP/+AbbZHtL9sfPAAAAAAAAAAAAAAAAAAAAAAAAAYGAA//8A9vEekoXh48AAAAAAAAAAAAAAAAAAAAAAAABgYAD//gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGBgAMAGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYGAAwAYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//ADABgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//8AMAGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH//4AwAYAAAAAAwAAAAAAAAAAAAAAAAAAAQAAAAAwD////////4P/B8HjgPn/8D8Af/A/+AfgPn/zgPn/8HgP////////g//HwePA+f/w88B/+D/4A+B8f/PA+f/weA////////+D/+fB4+D5//GAYH/8P/gD4Hx/8+D5//D8D////////4P/58Hj8Pn/4wAwf/4/+AHw+H/z8Pn/8PwP////////g+PnweP4+B4GABB8fz4AAfD4eAP4+B8B/g////////+D4efB4/z4HgY+GHwfPgAA+fB4A/z4HwH+DAGB3cDA34Ph58Hj/vgeBCEIfB8/8AD58H/j/vgfAf4N3bzrn9/fg//nweP/+B4E/8h8Hz/wAH3gf+P/+B8D/w3dvPPBwN+D/+fB4//4HgX/yHwfP/AAf+B/4//4HwPPDd2A4/zf34P/x8Hj7/geBf/IfB8/8AA/wH/j7/gfB8+N3bzp/t/fg/+HwePn+B4Eb4h8Hz4AAD/AeAPn+B8Hz43dvN3AwMGD/AfD4+P4HgYAGHw/PgAAH8B4A+P4Hw//z////////4PgB/fj4fgeAgAwf/4/+AAfgH/z4fgfD//P////////g+AD/+Pg+B4DAGB//D/4AB+Af/Pg+B8f/+////////+D4AH/w+B4HgHAwH/4P/gADwB/8+B4Hx//7////////4PgAP+D4DgeAH+Af/A/+AAPAH/z4DgfPgH3////////AeAAfgPAGB4ADAA/gB/4AAYAf+HAGB4+Af"],"58":[25,40,"P///4AAAAAAAAAAAAAAAAAAAAAAAAAAAAH////AAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAwAAIMAAAAAAAAAAAAAAAAAAAAAAAAAAAAMf/CDAAAAAAAAAAAAAAAAAAAAAAAAAAAADH/z4wAAAAAAAAAAAAAAAAAAAAAAAAAAAAxAEyMAAAAAAAAAAAAAAAAAAAAAAAAAAAAMQBPzAAAAAAAAAAAAAAAAAAAAAAAAAAAADH/xMwAAAAAAAAAAAAAAAAAAAAAAAAAAAAxVk/MAAAAAAAAAAAAAAAAAAAAAAAAAAAAMf/CDAAAAAAAAAAAAAAAAAAAAAAAAAAAADFWQgwAAAAAAAAAAAAAAAAAAAAAAAAAAAAx/kAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAMVZADIgAAAAAAAAAAAAAAAAAAAAAAAAAADFWQA3dgAAAAAAAAAAAAAAAAAAAAAAAAAAx/kAN/4AAAAAAAAAAAAAAAAAAAAAAAAAAMf/ADf+AdN7gAMOcAAAAAAAAAAAAAAAAADAAAA3/gFXNyImj3AAAAAAAAAAAAAAAAAA////9/4BljcmZglgAAAAAAAAAAAAAAAAAH///+f+ANO3PlGJcAAAAAAAAAAAAAAAAAAf//+H/wB1tjrwi0AAAAAAAAAAAAAAAAAAADBAD/8B1zOin45wAAAAAAAAAAAAAAAAAAAwQAwDAAAAAAAAAAAAAAAAAAAAAAAAAAAAMEAMAwAAAAAAAAAAAAAAAAAAAAAAAAAAAP/wDAMAAAAAAAAAAAAAAAAAAAAAAAAAAAD/+AwDAAAAAAAAAAAAAAAAAAAAAAAAAAAB//gMAwPweHMBz/gAAfgP8BwPP8wPf+DA///////D/Hhzg9/4fwP+D/AeDz/OD3/hwP//////w/54c8Pf+MGD/w/wHh4/zw9/4eD//////8P/eHPjz/mAQ/+P8A8eP8+Pf+Hg///////Dj3hz88HBAGPHzgAPHDgPzw8D8MDBtgw3w494c/vBwyojw8/gB7w/j+8PA/DbXdb598P/eHP/wcJ/I8PP8Ae8P4//Dwf4213ODDfD/nhz/8HC/6PDz/AD+D+P/w8HeNtdx+33w/x4c9/Bw3+jw88gA/g8j38PDzzbXbYMMMPwePPPwcEgI8fOAAHwOA8/Dw/8///////DgH/zx8HBgEP/j/AB8D/PHw8f/v//////w4A/88PBwMDD/w/wAeA/zw8PH/7//////8OAH+PBwcB/A/4P8ADgP88HDzwP//////+DgA+BwMHAHgP4D/AAwD/PAwc8Dw=="]};
function pieMaxsel(tk, cfg, esPago = false) {
  tk.align('center').line();
  // 2.5.2: la leyenda de Maxsel sale SIEMPRE (no se puede quitar), igual que en el sistema hotelero.
  // 2.7.2: logo chico y discreto; con "logo solo en el comprobante de pago" no sale en boletos de entrada, cortes ni reportes
  // 2.7.3: el logo y los datos de Maxsel salen SIEMPRE en todos los tickets, chicos y discretos (no hay opción para quitarlos)
  tk.img(...LOGO_MAXSEL_TICKET[tk.cols <= 32 ? '58' : '80']);
  const contacto = ['WhatsApp 664 337 5433'];
  tk.small(true); for (const l of [...LEYENDA_MAXSEL, ...contacto]) tk.text(l.slice(0, tk.colsB)); tk.small(false);
  return tk;
}
const nombreUsuario = (id) => db.prepare('SELECT nombre FROM usuarios WHERE id=?').get(id)?.nombre || '';
const nombreTarifa = (id) => getTarifa(id)?.nombre || '';
const CLIENTE_TXT = { normal: 'Cliente', mesero: 'Mesero', pension: 'Pensionado', frecuente: 'Cliente frecuente', empresa: 'Empresa' };
const vehiculoTxt = (t) => [t.marca, t.modelo, t.color].filter(Boolean).join(' / ');
function lineasExtras(tk, extras) {
  for (const e of extras || []) tk.kv(`${e.cantidad} x ${e.nombre}`.slice(0, tk.cols - 12), money(e.importe));
}

function ticketEntrada(t, cfg, reimpresion) {
  const tk = encabezado(new Ticket(cfg.impresora_columnas), cfg);
  tk.big('BOLETO ' + folio(t.id));
  if (reimpresion) tk.chico('*** REIMPRESIÓN ***');
  tk.align('left').bold(true).kv('Entrada:', fechaHora(t.entrada)).bold(false);
  const veh = [t.placas, vehiculoTxt(t).replace(/ \/ /g, ' ')].filter(Boolean).join('  ');
  if (veh) tk.text(veh.slice(0, tk.cols));
  const cli = getCliente(t.cliente_id);
  const tar = getTarifa(t.tarifa_id);
  tk.kv((CLIENTE_TXT[t.cliente] || 'Cliente') + (cli ? ': ' + cli.nombre : ''), t.cliente !== 'pension' && tar ? tar.nombre : '');
  tk.align('center').barcode(folio(t.id));
  tk.align('left');
  if (cfg.imprimir_politicas && cfg.politicas) tk.chico(String(cfg.politicas).replace(/\s*\n\s*/g, ' '));
  tk.bold(true).chico(`BOLETO PERDIDO: ${money(cfg.costo_boleto_perdido)}.` + (cfg.boleto_perdido_texto ? ' ' + cfg.boleto_perdido_texto : '')).bold(false);
  tk.chico('Atendió: ' + nombreUsuario(t.usuario_entrada));
  pieMaxsel(tk, cfg).cut();
  return tk;
}
function ticketPagado(t, pago, cfg, copia) {
  const tk = encabezado(new Ticket(cfg.impresora_columnas), cfg);
  tk.bold(true).text((t.perdido ? 'PAGO - BOLETO PERDIDO' : t.cortesia_para ? 'CORTESÍA' : 'COMPROBANTE DE PAGO') + (copia ? ' (COPIA CAJERO)' : '')).bold(false);
  tk.align('left').kv('Boleto ' + folio(t.id), [t.placas, vehiculoTxt(t).replace(/ \/ /g, ' ')].filter(Boolean).join(' ').slice(0, tk.cols - 14));
  tk.kv('Entrada:', fechaHora(t.entrada)).kv('Salida:', fechaHora(t.salida));
  const cli = getCliente(t.cliente_id);
  tk.kv('Tiempo: ' + tiempoTxt(t.minutos), (cli ? cli.nombre : CLIENTE_TXT[t.cliente] || '') + (t.tarifa_cobro_id ? ' · ' + nombreTarifa(t.tarifa_cobro_id) : ''));
  tk.kv('Estacionamiento:', money(t.subtotal));
  if (t.convenio_id) tk.kv('Convenio ' + (getConvenio(t.convenio_id)?.nombre || '') + ':', '-' + money(t.descuento));
  else if (t.cortesia_para) tk.kv('Cortesía:', '-' + money(t.descuento)).chico('Para: ' + t.cortesia_para + (t.cortesia_motivo ? ' (' + t.cortesia_motivo + ')' : ''));
  else if (t.descuento > 0) tk.kv('Descuento:', '-' + money(t.descuento));
  if (t.cargo_perdido > 0) tk.kv('Boleto perdido:', money(t.cargo_perdido));
  if (pago && pago.detalle) lineasExtras(tk, jsonArr(pago.detalle));
  tk.bold(true).size(1, 2).kv('TOTAL:', money(t.total)).size(1, 1).bold(false);
  if (pago) {
    const rec = [pago.pesos > 0 ? 'Efectivo ' + money(pago.pesos) : '', pago.usd > 0 ? `US$${r2(pago.usd)} (TC ${pago.tipo_cambio})` : '',
      pago.tarjeta > 0 ? 'Tarjeta ' + money(pago.tarjeta) : '', pago.transferencia > 0 ? 'Transf. ' + money(pago.transferencia) : ''].filter(Boolean).join(' + ');
    tk.text(('Recibido: ' + rec).slice(0, tk.cols)).bold(true).kv('Cambio:', money(pago.cambio)).bold(false);
  } else if (t.cliente === 'pension') tk.text('Salida de pensionado');
  tk.align('center').chico('Atendió: ' + nombreUsuario(t.usuario_salida) + (cfg.mensaje_pago ? ' · ' + cfg.mensaje_pago : ''));
  pieMaxsel(tk, cfg, true).cut();
  return tk;
}
function ticketVenta(pago, cfg, copia) {
  const tk = encabezado(new Ticket(cfg.impresora_columnas), cfg);
  tk.bold(true).text('VENTA DE PRODUCTOS Y SERVICIOS').bold(false);
  if (copia) tk.bold(true).text('*** COPIA CAJERO ***').bold(false);
  tk.align('left').kv('Folio venta:', 'V' + folio(pago.id)).kv('Fecha:', fechaHora(pago.fecha)).line();
  lineasExtras(tk, jsonArr(pago.detalle));
  tk.line().bold(true).size(1, 2).kv('TOTAL:', money(pago.total)).size(1, 1).bold(false);
  if (pago.pesos > 0) tk.kv('Efectivo MXN:', money(pago.pesos));
  if (pago.usd > 0) tk.kv(`Dólares US$${r2(pago.usd)} (TC ${pago.tipo_cambio})`, money(pago.usd_mxn));
  if (pago.tarjeta > 0) tk.kv('Tarjeta:', money(pago.tarjeta));
  if (pago.transferencia > 0) tk.kv('Transferencia:', money(pago.transferencia));
  tk.kv('Cambio:', money(pago.cambio)).line().text('Atendió: ' + nombreUsuario(pago.usuario_id)).align('center').feed(1).para(cfg.mensaje_pago);
  pieMaxsel(tk, cfg, true).cut();
  return tk;
}
function ticketPerdido(datos, t, cfg) {
  const tk = encabezado(new Ticket(cfg.impresora_columnas), cfg);
  tk.bold(true).size(1, 2).text('FORMATO DE BOLETO PERDIDO').size(1, 1).bold(false).align('left');
  tk.kv('Fecha:', fechaHora(Date.now()));
  if (t) tk.kv('Folio:', folio(t.id)).kv('Entrada:', fechaHora(t.entrada));
  const campo = (label, val) => { tk.feed(1); if (val) tk.text(label + ' ' + val); else tk.text(label + ' ' + '_'.repeat(Math.max(4, tk.cols - label.length - 1))); };
  tk.line();
  campo('Nombre:', datos.nombre);
  campo('Identificación:', datos.identificacion);
  campo('Teléfono:', datos.telefono);
  campo('Placas:', datos.placas || t?.placas);
  campo('Marca:', datos.marca || t?.marca);
  campo('Modelo:', datos.modelo || t?.modelo);
  campo('Color:', datos.color || t?.color);
  if (datos.monto !== undefined) { tk.feed(1).bold(true).kv('Monto a pagar:', money(datos.monto)).bold(false); }
  tk.line().para(cfg.boleto_perdido_politicas);
  tk.feed(3).align('center').text('_'.repeat(Math.min(32, tk.cols))).text('Firma del cliente');
  tk.feed(2).text('_'.repeat(Math.min(32, tk.cols))).text('Nombre y firma del cajero');
  pieMaxsel(tk, cfg).cut();
  return tk;
}
function ticketPension(c, per, pago, cfg, copia) {
  const tk = encabezado(new Ticket(cfg.impresora_columnas), cfg);
  tk.bold(true).text('RECIBO DE PENSIÓN').bold(false);
  if (copia) tk.bold(true).text('*** COPIA CAJERO ***').bold(false);
  tk.align('left').kv('Recibo:', folio(pago.id)).kv('Fecha:', fechaHora(pago.fecha)).line();
  tk.kv('Cliente:', c.nombre);
  for (const v of db.prepare('SELECT * FROM vehiculos WHERE cliente_id=? AND activo=1').all(c.id)) tk.text(`  ${v.placas || 's/placas'} ${vehiculoTxt(v)}`);
  if (per.categoria) tk.kv('Pensión:', per.categoria);
  tk.kv('Plan:', PLANES[per.plan] || per.plan).kv('Desde:', fechaHora(per.desde)).kv('Hasta:', fechaHora(per.hasta));
  tk.line().bold(true).size(1, 2).kv('TOTAL:', money(pago.total)).size(1, 1).bold(false);
  if (pago.pesos > 0) tk.kv('Efectivo MXN:', money(pago.pesos));
  if (pago.usd > 0) tk.kv(`Dólares US$${r2(pago.usd)} (TC ${pago.tipo_cambio})`, money(pago.usd_mxn));
  if (pago.tarjeta > 0) tk.kv('Tarjeta:', money(pago.tarjeta));
  if (pago.transferencia > 0) tk.kv('Transferencia:', money(pago.transferencia));
  tk.kv('Cambio:', money(pago.cambio)).line().text('Cobró: ' + nombreUsuario(pago.usuario_id));
  pieMaxsel(tk, cfg, true).cut();
  return tk;
}
function ticketCorte(res, cfg, conDiferencias) {
  const tk = encabezado(new Ticket(cfg.impresora_columnas), cfg);
  const t = res.turno;
  tk.bold(true).size(1, 2).text('CORTE DE CAJA').size(1, 1).bold(false).align('left');
  tk.kv('Turno:', folio(t.id)).kv('Cajero:', res.cajero).kv('Apertura:', fechaHora(t.apertura)).kv('Cierre:', fechaHora(t.cierre || Date.now()));
  tk.kv('Tipo de cambio:', '$' + t.tipo_cambio).line();
  tk.bold(true).text('MOVIMIENTO DE VEHÍCULOS').bold(false);
  tk.kv('Dentro al abrir turno:', res.dentro_al_abrir).kv('Entradas registradas:', res.entradas).kv('Salidas:', res.salidas)
    .kv('Dentro al cerrar turno:', res.dentro_al_cerrar).kv('Máxima ocupación:', res.pico);
  for (const [k, v] of Object.entries(res.entradas_tipo || {})) tk.kv('  Entradas ' + (CLIENTE_TXT[k] || k) + ':', v);
  tk.kv('Boletos perdidos:', res.perdidos)
    .kv('Con convenio:', res.convenios).kv('Boletos cancelados:', res.cancelados).kv('Pensiones cobradas:', res.pensiones).line();
  tk.bold(true).text('VENTAS').bold(false);
  tk.kv('Estacionamiento:', money(res.venta_estacionamiento)).kv('Pensiones:', money(res.venta_pensiones)).kv('Productos y servicios:', money(res.venta_productos));
  tk.bold(true).kv('TOTAL VENTA:', money(res.venta_total)).bold(false);
  tk.kv('Efectivo MXN (neto):', money(res.efectivo_mxn)).kv(`Dólares: US$${r2(res.usd)}`, money(res.usd_mxn)).kv('Tarjeta:', money(res.tarjeta));
  if (res.transferencia > 0) tk.kv('Transferencias:', money(res.transferencia));
  tk.line();
  tk.bold(true).text(`CORTESÍAS: ${res.cortesias} (${money(res.cortesias_monto)})`).bold(false).text('No son dinero en caja.');
  for (const c of res.lista_cortesias) tk.kv(`${folio(c.id)} ${c.cortesia_para}`.slice(0, tk.cols - 12), money(c.subtotal));
  tk.line().bold(true).text('CAJA').bold(false);
  tk.kv('Fondo inicial MXN:', money(t.fondo_pesos)); if (t.fondo_usd > 0) tk.kv('Fondo inicial USD:', 'US$' + r2(t.fondo_usd));
  if (res.retiros_mxn || res.retiros_usd) tk.kv('Retiros:', money(res.retiros_mxn) + (res.retiros_usd ? ' + US$' + r2(res.retiros_usd) : ''));
  if (res.ingresos_mxn || res.ingresos_usd) tk.kv('Ingresos:', money(res.ingresos_mxn) + (res.ingresos_usd ? ' + US$' + r2(res.ingresos_usd) : ''));
  tk.line().bold(true).text('DECLARACIÓN DEL CAJERO').bold(false);
  tk.kv('Efectivo MXN:', money(t.decl_pesos)).kv('Dólares:', 'US$' + r2(t.decl_usd)).kv('Vouchers tarjeta:', money(t.decl_tarjeta));
  if (conDiferencias) {
    tk.line().bold(true).text('ESPERADO / DIFERENCIA').bold(false);
    const d = (x) => (x > 0 ? 'SOBRA ' : x < 0 ? 'FALTA ' : '') + money(Math.abs(x));
    tk.kv('MXN esperado:', money(res.esperado_mxn)).kv('  Diferencia:', d(res.dif_mxn));
    tk.kv('USD esperado:', 'US$' + r2(res.esperado_usd)).kv('  Diferencia:', (res.dif_usd > 0 ? 'SOBRA ' : res.dif_usd < 0 ? 'FALTA ' : '') + 'US$' + Math.abs(r2(res.dif_usd)));
    tk.kv('Tarjeta esperado:', money(res.tarjeta)).kv('  Diferencia:', d(res.dif_tarjeta));
  }
  if (t.notas) tk.line().para('Notas: ' + t.notas);
  tk.feed(3).align('center').text('_'.repeat(30)).text('Firma cajero').feed(2).text('_'.repeat(30)).text('Firma supervisor');
  pieMaxsel(tk, cfg).cut();
  return tk;
}

/* ============================ IMPRESIÓN Y HARDWARE ============================ */
const esWindows = process.platform === 'win32';
function powershell(script, args, timeout = 20000) {
  return new Promise((resolve, reject) => {
    execFile('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(__dirname, 'herramientas', script), ...args],
      { timeout, windowsHide: true }, (err, stdout, stderr) => {
        const out = String(stdout || '').trim();
        if (err) return reject(new Error(String(stderr || err.message).trim()));
        if (out && !out.endsWith('OK')) return reject(new Error(out));
        resolve(out);
      });
  });
}
function enviarIP(buf, ip, port) {
  return new Promise((resolve, reject) => {
    const s = net.createConnection({ host: ip, port: Number(port) || 9100 });
    s.setTimeout(5000);
    s.on('connect', () => s.end(buf));
    s.on('close', (hadErr) => (hadErr ? null : resolve()));
    s.on('timeout', () => { s.destroy(); reject(new Error('La impresora IP no respondió (' + ip + ')')); });
    s.on('error', (e) => reject(new Error('Impresora IP: ' + e.message)));
  });
}
async function enviarImpresora(buf, cfg) {
  if (cfg.impresora_tipo === 'ip') return enviarIP(buf, cfg.impresora_ip, cfg.impresora_puerto);
  if (cfg.impresora_tipo === 'windows' || cfg.impresora_tipo === 'usb') {
    if (!esWindows) throw new Error('La impresión en impresoras de Windows solo funciona en Windows');
    if (!cfg.impresora_nombre) throw new Error('Seleccione la impresora en Configuración');
    const f = path.join(os.tmpdir(), 'maxsel_' + crypto.randomBytes(6).toString('hex') + '.bin');
    fs.writeFileSync(f, buf);
    try { await powershell('imprimir-raw.ps1', ['-Printer', cfg.impresora_nombre, '-File', f]); } finally { fs.rm(f, () => {}); }
  }
}
async function imprimir(tickets, { cajon = false } = {}) {
  const cfg = getConfig();
  tickets = [].concat(tickets).filter(Boolean);
  for (const t of tickets) { t.corte = cfg.impresora_corte; t.sinAcentos = cfg.impresora_acentos === false; }
  if (cajon && cfg.abrir_cajon_efectivo && tickets[0]) tickets[0].ops.unshift(['drawer']);
  const preview = tickets.flatMap((t) => t.preview());
  if (!cfg.impresora_tipo || cfg.impresora_tipo === 'ninguna') return { ok: true, simulado: true, preview };
  try {
    await enviarImpresora(Buffer.concat(tickets.map((t) => t.escpos())), cfg);
    return { ok: true, preview };
  } catch (e) {
    return { ok: false, error: e.message, preview };
  }
}
async function abrirPluma(origen, uid) {
  const cfg = getConfig();
  bitacora(uid, 'pluma', origen);
  try {
    if (cfg.relay_tipo === 'http') {
      const r = await fetch(cfg.relay_url, { method: cfg.relay_metodo || 'GET', signal: AbortSignal.timeout(4000) });
      if (!r.ok) throw new Error('El relevador respondió ' + r.status);
      return { ok: true };
    }
    if (cfg.relay_tipo === 'serial') {
      if (!esWindows) throw new Error('El relevador USB/serial solo funciona en Windows');
      await powershell('relevador-serial.ps1', ['-Port', cfg.relay_puerto_com, '-OnHex', cfg.relay_on_hex, '-OffHex', cfg.relay_off_hex || '', '-Ms', String(cfg.relay_pulso_ms || 1000)]);
      return { ok: true };
    }
    return { ok: true, simulado: true };
  } catch (e) {
    return { ok: false, error: 'Pluma: ' + (e.name === 'TimeoutError' ? 'el relevador no respondió' : e.message) };
  }
}

/* ============================ CÁMARA DE ENTRADA ============================ */
const md5 = (x) => crypto.createHash('md5').update(x).digest('hex');
// Pide una foto (snapshot) a una cámara IP. Soporta autenticación Basic y Digest (Hikvision, Dahua, etc.)
async function snapshotIP(cfg) {
  const url = String(cfg.camara_url || '').trim();
  if (!/^https?:\/\//i.test(url)) throw new Error('Escriba la dirección de la foto de la cámara (http://…)');
  const user = cfg.camara_usuario || '', pass = cfg.camara_password || '';
  const pedir = (headers = {}) => fetch(url, { headers, signal: AbortSignal.timeout(5000) });
  let r = await pedir(user ? { Authorization: 'Basic ' + Buffer.from(user + ':' + pass).toString('base64') } : {});
  const wa = r.headers.get('www-authenticate') || '';
  if (r.status === 401 && /^digest/i.test(wa) && user) {
    const p = {}; wa.replace(/(\w+)="?([^",]+)"?/g, (_, k, v) => { p[k] = v; });
    const u = new URL(url), uri = u.pathname + u.search, nc = '00000001', cnonce = crypto.randomBytes(8).toString('hex');
    const ha1 = md5(`${user}:${p.realm}:${pass}`), ha2 = md5(`GET:${uri}`);
    const qop = p.qop ? p.qop.split(',')[0].trim() : '';
    const resp = qop ? md5(`${ha1}:${p.nonce}:${nc}:${cnonce}:${qop}:${ha2}`) : md5(`${ha1}:${p.nonce}:${ha2}`);
    let h = `Digest username="${user}", realm="${p.realm}", nonce="${p.nonce}", uri="${uri}", response="${resp}"`;
    if (qop) h += `, qop=${qop}, nc=${nc}, cnonce="${cnonce}"`;
    if (p.opaque) h += `, opaque="${p.opaque}"`;
    if (p.algorithm) h += `, algorithm=${p.algorithm}`;
    r = await pedir({ Authorization: h });
  }
  if (r.status === 401) throw new Error('La cámara rechazó el usuario o contraseña');
  if (!r.ok) throw new Error('La cámara respondió ' + r.status);
  const buf = Buffer.from(await r.arrayBuffer());
  if (buf.length < 500 || buf[0] !== 0xff || buf[1] !== 0xd8) throw new Error('La cámara no devolvió una foto JPG (revise la dirección)');
  return buf;
}
function guardarFoto(ticketId, buf) {
  const d = new Date();
  const rel = path.join('fotos', `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`, `${ticketId}.jpg`);
  fs.mkdirSync(path.join(DATA_DIR, path.dirname(rel)), { recursive: true });
  fs.writeFileSync(path.join(DATA_DIR, rel), buf);
  db.prepare('UPDATE tickets SET foto=? WHERE id=?').run(rel.replace(/\\/g, '/'), ticketId);
  return rel;
}
async function fotoCamaraIP(ticketId) {
  try { guardarFoto(ticketId, await snapshotIP(getConfig())); return { ok: true }; }
  catch (e) { return { ok: false, error: 'Cámara: ' + (e.name === 'TimeoutError' ? 'no respondió' : e.message) }; }
}
function limpiarFotos() {
  try {
    const dias = Math.max(1, num(getConfig().camara_dias) || 90);
    const dir = path.join(DATA_DIR, 'fotos'); if (!fs.existsSync(dir)) return;
    const limite = Date.now() - dias * 864e5;
    for (const f of fs.readdirSync(dir)) {
      const m = /^(\d{4})-(\d\d)-(\d\d)$/.exec(f);
      if (m && new Date(+m[1], +m[2] - 1, +m[3]).getTime() < limite) fs.rmSync(path.join(dir, f), { recursive: true, force: true });
    }
  } catch (e) { console.error('Fotos:', e.message); }
}

/* ============================ LECTURA DE PLACAS (LPR) ============================ */
// 2.5: Dos formas de leer placas (mexicanas y americanas):
//  - "nube": la foto de la cámara IP se manda a Plate Recognizer (servicio de reconocimiento, requiere internet y token).
//  - "camara": una cámara con lectura de placas integrada (Hikvision ANPR, Dahua ITC/LPR…) manda la placa a
//    http://IP-DE-ESTA-PC:3040/api/lpr/evento?clave=… (JSON, XML o formulario; también GET ?placa=ABC123).
// Cada placa leída queda como PRE-INGRESO: la caja la ve al instante y la entrada (F2) la toma sola.
db.exec(`CREATE TABLE IF NOT EXISTS lpr_lecturas (id INTEGER PRIMARY KEY, fecha INTEGER, placa TEXT, confianza REAL, region TEXT, fuente TEXT,
  ticket_id INTEGER, descartada INTEGER DEFAULT 0, foto TEXT, candidatos TEXT);
  CREATE INDEX IF NOT EXISTS ix_lpr_fecha ON lpr_lecturas(fecha);`);
const LPR_URL = process.env.MAXSEL_LPR_URL || 'https://api.platerecognizer.com/v1/plate-reader/'; // (la variable es solo para pruebas)
const PREINGRESO_MS = 3 * 60 * 1000; // una placa leída sirve como pre-ingreso durante 3 minutos
function lprClave() {
  let k = getConfig().lpr_clave;
  if (!k) { k = crypto.randomBytes(9).toString('base64url'); db.prepare('INSERT INTO config(clave, valor) VALUES(?, ?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor').run('lpr_clave', JSON.stringify(k)); }
  return k;
}
// Placa en formato de la caja: mayúsculas y sin espacios ni guiones raros
const placaLPR = (p) => String(p || '').toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 15);
async function leerPlacaNube(buf, cfg) {
  const token = String(cfg.lpr_token || '').trim();
  if (!token) throw new Error('Falta el token de Plate Recognizer (Configuración → Lectura de placas)');
  const fd = new FormData();
  fd.append('upload', new Blob([buf], { type: 'image/jpeg' }), 'entrada.jpg');
  for (const r of String(cfg.lpr_regiones || 'mx,us-ca').split(/[\s,]+/).filter(Boolean)) fd.append('regions', r.toLowerCase());
  const r = await fetch(LPR_URL, { method: 'POST', headers: { Authorization: 'Token ' + token }, body: fd, signal: AbortSignal.timeout(12000) });
  let d = null; try { d = await r.json(); } catch { /* sin cuerpo */ }
  if (r.status === 403 || r.status === 401) throw new Error('Plate Recognizer rechazó el token (revíselo en su cuenta)');
  if (r.status === 429) throw new Error('Se acabaron las lecturas del plan de Plate Recognizer o son demasiadas por segundo');
  if (!r.ok) throw new Error('Plate Recognizer respondió ' + r.status + (d && d.detail ? ': ' + d.detail : ''));
  const res = (d && d.results) || [];
  if (!res.length) return { placa: '', confianza: 0, region: '', candidatos: [] };
  const best = res.slice().sort((a, b) => (b.score || 0) - (a.score || 0))[0];
  const placa = typeof best.plate === 'string' ? best.plate : best.plate?.props?.plate?.[0]?.value || '';
  const region = best.region?.code || best.plate?.props?.region?.[0]?.value || '';
  const cand = (best.candidates || []).map((c) => placaLPR(c.plate)).filter(Boolean).slice(0, 4);
  return { placa: placaLPR(placa), confianza: Number(best.score ?? best.dscore ?? 0), region, candidatos: cand };
}
function guardarLectura(l, fuente, foto) {
  if (!l.placa) return null;
  // La misma placa leída varias veces seguidas (la cámara manda varios eventos) cuenta una sola vez
  const rep = db.prepare('SELECT id FROM lpr_lecturas WHERE placa=? AND fecha>? AND descartada=0 AND ticket_id IS NULL ORDER BY id DESC').get(l.placa, Date.now() - 60000);
  if (rep) return rep.id;
  return Number(db.prepare('INSERT INTO lpr_lecturas(fecha, placa, confianza, region, fuente, foto, candidatos) VALUES(?,?,?,?,?,?,?)')
    .run(Date.now(), l.placa, r2(l.confianza || 0), String(l.region || '').slice(0, 10), fuente, foto || null, JSON.stringify(l.candidatos || [])).lastInsertRowid);
}
// Toma la foto de la cámara de entrada y lee la placa
async function leerPlacaAhora() {
  const cfg = getConfig();
  if (cfg.camara_tipo !== 'ip') throw new Error('Para leer placas desde la foto, configure una cámara IP en Configuración → Cámara de entrada');
  const buf = await snapshotIP(cfg);
  const l = await leerPlacaNube(buf, cfg);
  const id = l.placa ? guardarLectura(l, 'nube') : null;
  return { ...l, id, imagen: 'data:image/jpeg;base64,' + buf.toString('base64') };
}
// Después de dar entrada SIN placas: lee la placa de la foto que ya se tomó y la guarda en el boleto (en segundo plano)
function placaDespuesDeEntrada(ticketId) {
  const cfg = getConfig();
  if (cfg.lpr_modo !== 'nube' || !cfg.lpr_al_ingreso || cfg.camara_tipo !== 'ip') return;
  setTimeout(async () => {
    try {
      const t = db.prepare('SELECT placas, foto FROM tickets WHERE id=?').get(ticketId);
      if (!t || t.placas || !t.foto) return;
      const l = await leerPlacaNube(fs.readFileSync(path.join(DATA_DIR, t.foto)), cfg);
      if (!l.placa || l.confianza < (num(cfg.lpr_min_confianza) || 0.5)) return;
      const ya = db.prepare(`SELECT id FROM tickets WHERE estado='dentro' AND id<>? AND ${SQL_PLACA}=?`).get(ticketId, limpiaPlaca(l.placa));
      if (ya) return; // esa placa ya está dentro con otro boleto: mejor no adivinar
      db.prepare("UPDATE tickets SET placas=? WHERE id=? AND COALESCE(placas,'')=''").run(l.placa, ticketId);
      const id = guardarLectura(l, 'nube'); if (id) db.prepare('UPDATE lpr_lecturas SET ticket_id=? WHERE id=?').run(ticketId, id);
    } catch (e) { console.error('Placas:', e.message); }
  }, 50);
}
// Saca la placa del aviso de una cámara LPR (JSON, XML de Hikvision/Dahua, formulario o texto)
function placaDeEvento(raw, q) {
  const directa = q.get('placa') || q.get('plate') || q.get('plateNumber');
  if (directa) return directa;
  const s = String(raw || '');
  try { const j = JSON.parse(s); const busca = (o) => { if (!o || typeof o !== 'object') return null; for (const [k, v] of Object.entries(o)) { if (/^(placa|plate|platenumber|plateno|licenseplate|plate_number|platetext)$/i.test(k) && typeof v === 'string' && v.trim()) return v; const x = busca(v); if (x) return x; } return null; }; const p = busca(j); if (p) return p; } catch { /* no es JSON */ }
  const m = s.match(/<(?:\w+:)?(licensePlate|plateNumber|PlateNumber|PlateNo|plateNo|PlateText|placa)>\s*([^<\s][^<]*)<\//i)
    || s.match(/name="(?:placa|plate|plateNumber|licensePlate)"\s*\r?\n\r?\n([^\r\n]+)/i)
    || s.match(/(?:^|[&?])(?:placa|plate|plateNumber|licensePlate)=([^&\s]+)/i);
  return m ? decodeURIComponent(m[m.length - 1]) : null;
}
function lecturasPendientes() {
  const dentro = new Set(db.prepare("SELECT placas FROM tickets WHERE estado='dentro'").all().map((t) => limpiaPlaca(t.placas)));
  return db.prepare('SELECT * FROM lpr_lecturas WHERE ticket_id IS NULL AND descartada=0 AND fecha>? ORDER BY id DESC LIMIT 5').all(Date.now() - PREINGRESO_MS)
    .filter((l) => !dentro.has(limpiaPlaca(l.placa)))
    .map((l) => { const v = vehiculoPorPlaca(l.placa); const cli = v ? getCliente(v.cliente_id) : null; return { ...l, candidatos: JSON.parse(l.candidatos || '[]'), cliente: cli ? cli.nombre : null, tipo_cliente: cli ? cli.tipo : null }; });
}

/* ============================ MERCADO PAGO POINT (API de Órdenes) ============================ */
async function mpFetch(url, opts = {}) {
  const cfg = getConfig();
  if (!cfg.mp_access_token) fallo('Configure el Access Token de Mercado Pago en Configuración');
  const r = await fetch('https://api.mercadopago.com' + url, {
    ...opts,
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + cfg.mp_access_token, 'X-Idempotency-Key': crypto.randomUUID(), ...(opts.headers || {}) },
    signal: AbortSignal.timeout(15000),
  });
  const txt = await r.text();
  let data; try { data = JSON.parse(txt); } catch { data = { raw: txt }; }
  if (!r.ok) fallo('Mercado Pago: ' + (data.message || data.error || (data.errors && data.errors[0]?.message) || r.status));
  return data;
}

/* ============================ TURNOS ============================ */
const turnoAbierto = (uid) => db.prepare("SELECT * FROM turnos WHERE usuario_id=? AND estado='abierto' ORDER BY id DESC LIMIT 1").get(uid);
function resumenTurno(id) {
  const t = db.prepare('SELECT * FROM turnos WHERE id=?').get(id);
  if (!t) fallo('Turno no encontrado', 404);
  const p = db.prepare(`SELECT COUNT(*) n, IFNULL(SUM(total),0) total, IFNULL(SUM(pesos),0) pesos, IFNULL(SUM(cambio),0) cambio,
    IFNULL(SUM(usd),0) usd, IFNULL(SUM(usd_mxn),0) usd_mxn, IFNULL(SUM(tarjeta),0) tarjeta, IFNULL(SUM(transferencia),0) transferencia, IFNULL(SUM(monto_extras),0) extras,
    IFNULL(SUM(CASE WHEN concepto='publicidad' THEN total END),0) pub,
    IFNULL(SUM(CASE WHEN concepto='estacionamiento' THEN total-monto_extras END),0) est, IFNULL(SUM(CASE WHEN concepto='pension' THEN total END),0) pen,
    IFNULL(SUM(CASE WHEN concepto='pension' THEN 1 END),0) npen
    FROM pagos WHERE turno_id=? AND cancelado=0`).get(id);
  const mv = db.prepare(`SELECT
    IFNULL(SUM(CASE WHEN tipo='retiro' AND moneda='MXN' THEN monto END),0) ret_mxn, IFNULL(SUM(CASE WHEN tipo='retiro' AND moneda='USD' THEN monto END),0) ret_usd,
    IFNULL(SUM(CASE WHEN tipo='ingreso' AND moneda='MXN' THEN monto END),0) ing_mxn, IFNULL(SUM(CASE WHEN tipo='ingreso' AND moneda='USD' THEN monto END),0) ing_usd
    FROM movimientos WHERE turno_id=?`).get(id);
  const tk = db.prepare(`SELECT
    (SELECT COUNT(*) FROM tickets WHERE turno_entrada=?) entradas,
    (SELECT COUNT(*) FROM tickets WHERE turno_salida=? AND estado='pagado') salidas,
    (SELECT COUNT(*) FROM tickets WHERE turno_salida=? AND estado='pagado' AND perdido=1) perdidos,
    (SELECT COUNT(*) FROM tickets WHERE turno_salida=? AND estado='pagado' AND convenio_id IS NOT NULL) convenios,
    (SELECT COUNT(*) FROM tickets WHERE turno_salida=? AND estado='cancelado') cancelados`).get(id, id, id, id, id);
  const lista_cortesias = db.prepare(`SELECT id, placas, cortesia_para, cortesia_motivo, subtotal, salida FROM tickets
    WHERE turno_salida=? AND estado='pagado' AND cortesia_para IS NOT NULL ORDER BY id`).all(id);
  // Carros del turno: entradas/salidas por tipo y cuántos había dentro al abrir y al cerrar
  const fin = t.cierre || Date.now();
  const dentroEn = (ms) => db.prepare(`SELECT COUNT(*) n FROM tickets WHERE entrada<=? AND (salida IS NULL OR salida>?) AND (estado<>'cancelado' OR salida IS NOT NULL)`).get(ms, ms).n;
  const porTipo = (sql) => Object.fromEntries(db.prepare(sql).all(id).map((x) => [x.cliente, x.n]));
  const carros = {
    dentro_al_abrir: dentroEn(t.apertura),
    dentro_al_cerrar: dentroEn(fin),
    entradas_tipo: porTipo('SELECT cliente, COUNT(*) n FROM tickets WHERE turno_entrada=? GROUP BY cliente'),
    salidas_tipo: porTipo("SELECT cliente, COUNT(*) n FROM tickets WHERE turno_salida=? AND estado='pagado' GROUP BY cliente"),
    entradas_rapidas: db.prepare("SELECT COUNT(*) n FROM tickets WHERE turno_entrada=? AND modo_ingreso='rapido'").get(id).n,
    entradas_manuales: db.prepare("SELECT COUNT(*) n FROM tickets WHERE turno_entrada=? AND modo_ingreso='manual'").get(id).n,
    estancia_prom: Math.round(db.prepare("SELECT IFNULL(AVG(minutos),0) m FROM tickets WHERE turno_salida=? AND estado='pagado'").get(id).m),
    pico: 0,
  };
  // Máxima ocupación durante el turno (recorre entradas y salidas en orden)
  {
    const ev = db.prepare(`SELECT entrada t, 1 d FROM tickets WHERE entrada BETWEEN ? AND ?
      UNION ALL SELECT salida t, -1 d FROM tickets WHERE salida BETWEEN ? AND ? ORDER BY t`).all(t.apertura, fin, t.apertura, fin);
    let n = carros.dentro_al_abrir, max = n;
    for (const e of ev) { n += e.d; if (n > max) max = n; }
    carros.pico = max;
  }
  const efectivo = r2(p.pesos - p.cambio);
  const esperado_mxn = r2(t.fondo_pesos + efectivo + mv.ing_mxn - mv.ret_mxn);
  const esperado_usd = r2(t.fondo_usd + p.usd + mv.ing_usd - mv.ret_usd);
  return {
    turno: t, cajero: nombreUsuario(t.usuario_id), cobros: p.n, ...tk, ...carros, pensiones: p.npen,
    venta_total: r2(p.total), venta_estacionamiento: r2(p.est), venta_pensiones: r2(p.pen), venta_productos: r2(p.extras),
    efectivo_mxn: efectivo, usd: r2(p.usd), usd_mxn: r2(p.usd_mxn), tarjeta: r2(p.tarjeta), transferencia: r2(p.transferencia), venta_publicidad: r2(p.pub),
    cortesias: lista_cortesias.length, cortesias_monto: r2(lista_cortesias.reduce((s, c) => s + c.subtotal, 0)), lista_cortesias,
    retiros_mxn: r2(mv.ret_mxn), retiros_usd: r2(mv.ret_usd), ingresos_mxn: r2(mv.ing_mxn), ingresos_usd: r2(mv.ing_usd),
    esperado_mxn, esperado_usd,
    dif_mxn: t.decl_pesos == null ? null : r2(t.decl_pesos - esperado_mxn),
    dif_usd: t.decl_usd == null ? null : r2(t.decl_usd - esperado_usd),
    dif_tarjeta: t.decl_tarjeta == null ? null : r2(t.decl_tarjeta - p.tarjeta),
  };
}
function ocultarEsperado(res) {
  const r = { ...res };
  for (const k of ['esperado_mxn', 'esperado_usd', 'dif_mxn', 'dif_usd', 'dif_tarjeta']) delete r[k];
  r.oculto = true;
  return r;
}

/* ============================ PAGOS ============================ */
function validarPago(total, b, tc) {
  const pesos = r2(Math.max(0, num(b.pesos))), usd = r2(Math.max(0, num(b.usd))), tarjeta = r2(Math.max(0, num(b.tarjeta))), transferencia = r2(Math.max(0, num(b.transferencia)));
  const usd_mxn = r2(usd * tc);
  if (usd > 0 && !(tc > 0)) fallo('No hay tipo de cambio en el turno');
  if (tarjeta + transferencia > total + 0.001) fallo('Lo de tarjeta y transferencia no puede ser mayor al total');
  const pagado = r2(pesos + usd_mxn + tarjeta + transferencia);
  if (pagado + 0.001 < total) fallo(`Pago insuficiente: faltan ${money(total - pagado)}`);
  const cambio = r2(pagado - total);
  if (cambio > pesos + usd_mxn + 0.001) fallo('El cambio no puede ser mayor al efectivo recibido');
  return { pesos, usd, usd_mxn, tarjeta, transferencia, cambio, tarjeta_ref: String(b.tarjeta_ref || '').slice(0, 60), mp_order_id: String(b.mp_order_id || '').slice(0, 80) };
}
function registrarPago(turno, uid, concepto, ref, total, v, extras = []) {
  const fecha = Date.now();
  const monto_extras = r2(extras.reduce((s, e) => s + e.importe, 0));
  const r = db.prepare(`INSERT INTO pagos(turno_id, usuario_id, concepto, ticket_id, cliente_id, total, monto_extras, detalle, pesos, usd, tipo_cambio, usd_mxn,
    tarjeta, tarjeta_ref, mp_order_id, cambio, fecha, transferencia) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(turno.id, uid, concepto, ref.ticket_id || null, ref.cliente_id || null, total, monto_extras, extras.length ? JSON.stringify(extras) : '',
      v.pesos, v.usd, turno.tipo_cambio, v.usd_mxn, v.tarjeta, v.tarjeta_ref, v.mp_order_id, v.cambio, fecha, v.transferencia || 0);
  return db.prepare('SELECT * FROM pagos WHERE id=?').get(Number(r.lastInsertRowid));
}

// Imprime el comprobante; si el cajero eligió "Cobrar sin imprimir" sólo abre el cajón cuando hubo efectivo
// (con "Imprimir el ticket automáticamente al cobrar" encendido, siempre se imprime)
async function imprimirCobro(tk, pago, body) {
  const efectivo = !!pago && (pago.pesos > 0 || pago.usd > 0);
  if (body && body.no_imprimir && getConfig().imprimir_auto === false) return efectivo ? imprimir(new Ticket(getConfig().impresora_columnas), { cajon: true }) : { ok: true, omitido: true };
  return imprimir(tk, { cajon: efectivo });
}

/* ============================ CLIENTES Y PENSIONES ============================ */
const PLANES = { semana: 'Semanal', quincena: 'Quincenal', mes: 'Mensual', trimestre: 'Trimestral', semestre: 'Semestral', anual: 'Anual', personalizado: 'Por fechas' };
const TIPOS_CLIENTE = { mesero: 'Mesero', frecuente: 'Cliente frecuente', pension: 'Pensionado', empresa: 'Empresa' };
function vehiculoPorPlaca(placa) {
  const pl = limpiaPlaca(placa);
  if (!pl) return null;
  return db.prepare(`SELECT v.*, c.nombre cliente_nombre FROM vehiculos v JOIN clientes c ON c.id=v.cliente_id
    WHERE v.activo=1 AND c.activo=1 AND REPLACE(REPLACE(UPPER(v.placas),'-',''),' ','')=?`).get(pl) || null;
}
function listaClientes() {
  const ahora = Date.now();
  const veh = db.prepare('SELECT * FROM vehiculos WHERE cliente_id=? AND activo=1 ORDER BY id');
  const dentro = db.prepare("SELECT COUNT(*) n FROM tickets WHERE cliente_id=? AND estado='dentro'");
  return db.prepare('SELECT c.*, t.nombre tarifa FROM clientes c LEFT JOIN tarifas t ON t.id=c.tarifa_id ORDER BY c.activo DESC, c.nombre').all().map((c) => ({
    ...c, vehiculos: veh.all(c.id), dentro: dentro.get(c.id).n,
    estado: !c.activo ? 'inactivo' : c.tipo !== 'pension' && !c.vigente_hasta ? 'activo'
      : !c.vigente_hasta || c.vigente_hasta < ahora ? 'vencida' : c.vigente_hasta - ahora < 7 * 864e5 ? 'por vencer' : 'vigente',
    historial: db.prepare('SELECT id, plan, categoria, desde, hasta, monto, fecha FROM pension_periodos WHERE cliente_id=? ORDER BY id DESC LIMIT 12').all(c.id),
  }));
}

/* ============================ ESTADO DEL ESTACIONAMIENTO ============================ */
function estado() {
  const cfg = getConfig();
  const dentro = db.prepare(`SELECT t.id, t.placas, t.marca, t.modelo, t.color, t.cliente, t.entrada, t.foto IS NOT NULL foto, t.tarifa_id, ta.nombre tarifa, c.nombre cliente_nombre
    FROM tickets t LEFT JOIN tarifas ta ON ta.id=t.tarifa_id LEFT JOIN clientes c ON c.id=t.cliente_id
    WHERE t.estado='dentro' ORDER BY t.entrada DESC`).all();
  const capacidad = Math.max(0, num(cfg.capacidad));
  return { capacidad, ocupados: dentro.length, disponibles: Math.max(0, capacidad - dentro.length), lleno: dentro.length >= capacidad,
    meseros: dentro.filter((d) => d.cliente === 'mesero').length, pensionados: dentro.filter((d) => d.cliente === 'pension').length, dentro };
}

/* ============================ PANTALLA DEL CLIENTE (segundo monitor) ============================ */
const pantallas = new Map(); // ip -> estado
const suscriptores = new Map(); // ip -> Set(res)
function ipDe(req) {
  // 2.7: lo que entra por Tailscale Funnel trae la dirección real del teléfono en X-Forwarded-For
  if (req.__funnel) return 'internet:' + (String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'desconocida');
  let ip = String(req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  if (ip === '::1') ip = '127.0.0.1';
  return ip;
}
function publicarPantalla(ip, datos) {
  const st = { ...datos, t: Date.now() };
  pantallas.set(ip, st);
  for (const res of suscriptores.get(ip) || []) res.write('data: ' + JSON.stringify(st) + '\n\n');
}

/* ============================ REPORTES ============================ */
function reporte(desde, hasta) {
  const P = [desde, hasta];
  const resumen = db.prepare(`SELECT COUNT(*) cobros, IFNULL(SUM(total),0) total, IFNULL(SUM(pesos-cambio),0) efectivo_mxn, IFNULL(SUM(usd),0) usd,
    IFNULL(SUM(usd_mxn),0) usd_mxn, IFNULL(SUM(tarjeta),0) tarjeta, IFNULL(SUM(transferencia),0) transferencia, IFNULL(SUM(monto_extras),0) productos,
    IFNULL(SUM(CASE WHEN concepto='publicidad' THEN total END),0) publicidad,
    IFNULL(SUM(CASE WHEN concepto='estacionamiento' THEN total-monto_extras END),0) estacionamiento, IFNULL(SUM(CASE WHEN concepto='pension' THEN total END),0) pensiones,
    IFNULL(SUM(CASE WHEN mp_order_id<>'' THEN tarjeta END),0) mercado_pago
    FROM pagos WHERE cancelado=0 AND fecha BETWEEN ? AND ?`).get(...P);
  const vehiculos = db.prepare(`SELECT
    (SELECT COUNT(*) FROM tickets WHERE entrada BETWEEN ? AND ?) entradas,
    (SELECT COUNT(*) FROM tickets WHERE estado='pagado' AND salida BETWEEN ? AND ?) salidas,
    (SELECT COUNT(*) FROM tickets WHERE estado='pagado' AND perdido=1 AND salida BETWEEN ? AND ?) perdidos,
    (SELECT IFNULL(SUM(cargo_perdido),0) FROM tickets WHERE estado='pagado' AND salida BETWEEN ? AND ?) cargo_perdidos,
    (SELECT COUNT(*) FROM tickets WHERE estado='pagado' AND cortesia_para IS NOT NULL AND salida BETWEEN ? AND ?) cortesias,
    (SELECT IFNULL(SUM(subtotal),0) FROM tickets WHERE estado='pagado' AND cortesia_para IS NOT NULL AND salida BETWEEN ? AND ?) cortesias_monto,
    (SELECT IFNULL(SUM(descuento),0) FROM tickets WHERE estado='pagado' AND cortesia_para IS NULL AND salida BETWEEN ? AND ?) descuentos,
    (SELECT COUNT(*) FROM tickets WHERE estado='cancelado' AND salida BETWEEN ? AND ?) cancelados,
    (SELECT IFNULL(AVG(minutos),0) FROM tickets WHERE estado='pagado' AND salida BETWEEN ? AND ?) estancia_prom`).get(...P, ...P, ...P, ...P, ...P, ...P, ...P, ...P, ...P);
  const porCliente = db.prepare(`SELECT cliente, COUNT(*) n, IFNULL(SUM(total-extras_total),0) total, IFNULL(AVG(minutos),0) prom
    FROM tickets WHERE estado='pagado' AND salida BETWEEN ? AND ? GROUP BY cliente`).all(...P);
  const porTarifa = db.prepare(`SELECT IFNULL(ta.nombre,'(sin tarifa)') tarifa, COUNT(*) n, IFNULL(SUM(t.total-t.extras_total),0) total
    FROM tickets t LEFT JOIN tarifas ta ON ta.id=t.tarifa_cobro_id WHERE t.estado='pagado' AND t.salida BETWEEN ? AND ? GROUP BY t.tarifa_cobro_id ORDER BY total DESC`).all(...P);
  const porConvenio = db.prepare(`SELECT c.nombre convenio, COUNT(*) n, IFNULL(SUM(t.descuento),0) descuento, IFNULL(SUM(t.total-t.extras_total),0) total
    FROM tickets t JOIN convenios c ON c.id=t.convenio_id WHERE t.estado='pagado' AND t.salida BETWEEN ? AND ? GROUP BY t.convenio_id ORDER BY n DESC`).all(...P);
  const porCajero = db.prepare(`SELECT u.nombre cajero, COUNT(*) cobros, IFNULL(SUM(p.total),0) total, IFNULL(SUM(p.pesos-p.cambio),0) efectivo_mxn,
    IFNULL(SUM(p.usd),0) usd, IFNULL(SUM(p.tarjeta),0) tarjeta, IFNULL(SUM(p.transferencia),0) transferencia FROM pagos p JOIN usuarios u ON u.id=p.usuario_id
    WHERE p.cancelado=0 AND p.fecha BETWEEN ? AND ? GROUP BY p.usuario_id ORDER BY total DESC`).all(...P);
  const turnos = db.prepare(`SELECT id FROM turnos WHERE apertura BETWEEN ? AND ? OR (cierre BETWEEN ? AND ?) ORDER BY apertura`).all(...P, ...P)
    .map((t) => resumenTurno(t.id));
  const pagos = db.prepare('SELECT fecha, total, monto_extras, concepto, detalle FROM pagos WHERE cancelado=0 AND fecha BETWEEN ? AND ?').all(...P);
  const dias = {}, prod = {};
  for (const p of pagos) {
    const d = new Date(p.fecha); const k = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    dias[k] ||= { dia: k, estacionamiento: 0, pensiones: 0, productos: 0, total: 0, cobros: 0 };
    if (p.concepto === 'pension') dias[k].pensiones += p.total;
    else if (p.concepto === 'publicidad') dias[k].publicidad = (dias[k].publicidad || 0) + p.total;
    else dias[k].estacionamiento += p.total - p.monto_extras;
    dias[k].productos += p.monto_extras; dias[k].total += p.total; dias[k].cobros++;
    for (const e of jsonArr(p.detalle)) {
      prod[e.nombre] ||= { producto: e.nombre, tipo: e.tipo, cantidad: 0, total: 0 };
      prod[e.nombre].cantidad += e.cantidad; prod[e.nombre].total += e.importe;
    }
  }
  const entradasHora = Array(24).fill(0);
  for (const t of db.prepare('SELECT entrada FROM tickets WHERE entrada BETWEEN ? AND ?').all(...P)) entradasHora[new Date(t.entrada).getHours()]++;
  const tickets = db.prepare(`SELECT t.id, t.placas, t.marca, t.modelo, t.color, t.cliente, t.entrada, t.salida, t.foto IS NOT NULL foto, t.estado, t.minutos, t.subtotal, t.descuento,
    t.cargo_perdido, t.extras_total, t.total, t.perdido, t.cortesia_para, t.cortesia_motivo, t.cancel_motivo, ta.nombre tarifa, c.nombre convenio,
    cl.nombre cliente_nombre, ue.nombre usuario_entrada, us.nombre usuario_salida
    FROM tickets t LEFT JOIN tarifas ta ON ta.id=IFNULL(t.tarifa_cobro_id, t.tarifa_id) LEFT JOIN convenios c ON c.id=t.convenio_id
    LEFT JOIN clientes cl ON cl.id=t.cliente_id LEFT JOIN usuarios ue ON ue.id=t.usuario_entrada LEFT JOIN usuarios us ON us.id=t.usuario_salida
    WHERE t.entrada BETWEEN ? AND ? OR t.salida BETWEEN ? AND ? ORDER BY t.id DESC LIMIT 10000`).all(...P, ...P);
  const cortesias = tickets.filter((t) => t.estado === 'pagado' && t.cortesia_para);
  const pensionesCobradas = db.prepare(`SELECT pp.id, c.nombre, pp.plan, pp.categoria, pp.desde, pp.hasta, pp.monto, pp.fecha, u.nombre cajero
    FROM pension_periodos pp JOIN clientes c ON c.id=pp.cliente_id LEFT JOIN usuarios u ON u.id=pp.usuario_id
    WHERE pp.fecha BETWEEN ? AND ? ORDER BY pp.fecha DESC`).all(...P);
  const ahora = Date.now();
  const pensionesEstado = db.prepare(`SELECT id, nombre, telefono, vigente_hasta FROM clientes WHERE activo=1 AND (tipo='pension' OR vigente_hasta IS NOT NULL) ORDER BY vigente_hasta`).all()
    .map((p) => ({ ...p, estado: !p.vigente_hasta || p.vigente_hasta < ahora ? 'vencida' : p.vigente_hasta - ahora < 7 * 864e5 ? 'por vencer' : 'vigente' }));
  const movimientos = db.prepare(`SELECT m.*, u.nombre usuario FROM movimientos m LEFT JOIN usuarios u ON u.id=m.usuario_id
    WHERE m.fecha BETWEEN ? AND ? ORDER BY m.fecha DESC`).all(...P);
  const mods = MOD.todos();
  const gastos = !mods.gastos ? [] : db.prepare(`SELECT g.id, g.fecha, g.categoria, g.concepto, g.monto, g.origen, u.nombre usuario FROM gastos g LEFT JOIN usuarios u ON u.id=g.usuario_id
    WHERE g.cancelado=0 AND g.fecha BETWEEN ? AND ? ORDER BY g.fecha DESC`).all(...P);
  const gastosPorCategoria = Object.values(gastos.reduce((a, g) => { (a[g.categoria] ||= { categoria: g.categoria, n: 0, total: 0 }); a[g.categoria].n++; a[g.categoria].total = r2(a[g.categoria].total + g.monto); return a; }, {})).sort((a, b) => b.total - a.total);
  resumen.gastos = r2(gastos.reduce((t, g) => t + g.monto, 0));
  const publicidad = !mods.publicidad ? [] : db.prepare(`SELECT r.id, r.fecha, r.cliente, r.anuncio, r.desde, r.hasta, r.monto, e.nombre espacio, u.nombre cajero FROM rentas_pub r JOIN espacios_pub e ON e.id=r.espacio_id
    LEFT JOIN usuarios u ON u.id=r.usuario_id WHERE r.cancelado=0 AND r.fecha BETWEEN ? AND ? ORDER BY r.fecha DESC`).all(...P);
  resumen.utilidad = r2(resumen.total - resumen.gastos);
  if (!mods.gastos) { delete resumen.gastos; delete resumen.utilidad; }
  if (!mods.publicidad) delete resumen.publicidad;
  return {
    modulos: mods, gastos, gastosPorCategoria, publicidad,
    desde, hasta, resumen, vehiculos, porCliente, porTarifa, porConvenio, porCajero, turnos, cortesias,
    productos: Object.values(prod).sort((a, b) => b.total - a.total),
    porDia: Object.values(dias).sort((a, b) => a.dia.localeCompare(b.dia)), entradasHora, tickets,
    pensionesCobradas, pensionesEstado, movimientos, dentro: estado().dentro,
  };
}

/* ============================ RESPALDO DIARIO ============================ */
function respaldoDiario() {
  try {
    const dir = path.join(DATA_DIR, 'respaldos');
    fs.mkdirSync(dir, { recursive: true });
    const d = new Date();
    const f = path.join(dir, `parking_${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}.db`);
    if (!fs.existsSync(f)) db.exec(`VACUUM INTO '${f.replace(/'/g, "''")}'`);
    const viejos = fs.readdirSync(dir).filter((x) => /^parking_\d{4}-\d\d-\d\d\.db$/.test(x)).sort();
    for (const v of viejos.slice(0, Math.max(0, viejos.length - 30))) fs.rmSync(path.join(dir, v), { force: true });
  } catch (e) { console.error('Respaldo:', e.message); }
}

/* ============================ RED (acceso remoto) ============================ */
function infoRed() {
  const ips = [];
  for (const [nombre, lista] of Object.entries(os.networkInterfaces())) {
    for (const i of lista || []) {
      if (i.family !== 'IPv4' || i.internal) continue;
      const ts = /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(i.address) || /tailscale/i.test(nombre);
      ips.push({ interfaz: nombre, ip: i.address, tailscale: ts, url: `http://${i.address}:${PORT}` });
    }
  }
  return { puerto: PORT, ips, tailscale: ips.find((x) => x.tailscale) || null };
}

/* ============================ HTTP / SESIONES ============================ */
const sesiones = new Map();
const intentos = new Map(); // ip -> {n, hasta}
function usuarioDe(req) {
  const m = /(?:^|;\s*)sid=([a-f0-9]+)/.exec(req.headers.cookie || '');
  const s = m && sesiones.get(m[1]);
  if (!s || s.exp < Date.now()) return null;
  s.exp = Date.now() + 12 * 3600e3;
  const u = db.prepare('SELECT * FROM usuarios WHERE id=? AND activo=1').get(s.uid);
  if (!u) return null;
  u.perms = permisosDe(u);
  return u;
}
const puede = (u, p) => u.rol === 'admin' || u.perms.includes(p);
function requiere(u, ...ps) { if (!ps.some((p) => puede(u, p))) fallo('No tiene permiso para esta acción', 403); }
function requiereTurno(u) { const t = turnoAbierto(u.id); if (!t) fallo('Primero debe abrir turno', 409); return t; }

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.webmanifest': 'application/manifest+json' };
function enviarJSON(res, code, obj, headers = {}) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(obj));
}
function leerBody(req) {
  return new Promise((resolve, reject) => {
    let d = '';
    req.on('data', (c) => { d += c; if (d.length > 2e6) req.destroy(); });
    req.on('end', () => { try { resolve(d ? JSON.parse(d) : {}); } catch { reject(new ErrorUsuario('JSON inválido')); } });
    req.on('error', reject);
  });
}
// 2.5: cuerpo tal cual (avisos de cámaras LPR: XML, formulario o JSON)
function leerCrudo(req) {
  return new Promise((resolve, reject) => {
    const partes = []; let n = 0;
    req.on('data', (c) => { n += c.length; if (n > 4e6) req.destroy(); else partes.push(c); });
    req.on('end', () => resolve(Buffer.concat(partes).toString('latin1')));
    req.on('error', reject);
  });
}
try { sembrar230(); } catch (e) { console.error('Semillas:', e.message); }
const rutas = [];
// Módulos que se venden aparte (se activan en la licencia): qué rutas le pertenecen a cada uno.
// Este sistema no tiene asistencia (checador de empleados); su bit queda reservado en la licencia.
const RUTAS_MODULO = [
  ['gastos', /^\/api\/(gastos|gastos-fijos)(\/|$)/],
  ['publicidad', /^\/api\/publicidad(\/|$)/],
];
const licEstado = () => ({ ...LIC.estado(), modulos: MOD.todos() });
const moduloDeRuta = (r0) => (RUTAS_MODULO.find(([, re]) => re.test(r0)) || [])[0] || null;
const SIN_MODULO = (k) => `El módulo de ${MOD.NOMBRE[k] || k} no está incluido en la licencia de este negocio. Para activarlo comuníquese con Maxsel.`;
const ruta = (metodo, patron, fn, opts = {}) => rutas.push({ metodo, re: new RegExp('^' + patron.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn, ...opts });

/* ---------- Licencia ---------- */
ruta('GET', '/api/licencia/estado', () => ({ ...licEstado(), producto: PRODUCTO, version: VERSION, poliza: polizaHoy() }), { publica: true, sinLicencia: true });
ruta('POST', '/api/licencia/activar', (req, res, { body }) => {
  try { _pol = null; setTimeout(revisarPoliza, 1000); LIC.activar(body.clave); return licEstado(); } catch (e) { fallo(e.message); }
}, { publica: true, sinLicencia: true });

/* ---------- Autenticación ---------- */
ruta('POST', '/api/login', async (req, res, { body }) => {
  const ip = ipDe(req), it = intentos.get(ip);
  if (it && it.n >= 8 && it.hasta > Date.now()) fallo('Demasiados intentos. Espere 5 minutos.', 429);
  const u = db.prepare('SELECT * FROM usuarios WHERE usuario=? AND activo=1').get(String(body.usuario || '').trim().toLowerCase());
  if (!u || !checkPass(body.password || '', u.pass)) {
    const n = (it && it.hasta > Date.now() ? it.n : 0) + 1;
    intentos.set(ip, { n, hasta: Date.now() + 5 * 60e3 });
    await new Promise((r) => setTimeout(r, 600));
    fallo('Usuario o contraseña incorrectos', 401);
  }
  if (req.__funnel && !['admin', 'supervisor'].includes(u.rol)) fallo('Desde internet solo entran el administrador o el supervisor.', 403);
  intentos.delete(ip);
  const token = crypto.randomBytes(24).toString('hex');
  sesiones.set(token, { uid: u.id, exp: Date.now() + 12 * 3600e3 });
  bitacora(u.id, 'login', u.usuario + ' desde ' + ip);
  enviarJSON(res, 200, { ok: true }, { 'Set-Cookie': `sid=${token}; HttpOnly; SameSite=Lax; Path=/` });
  return null;
}, { publica: true });
ruta('POST', '/api/logout', (req) => {
  const m = /(?:^|;\s*)sid=([a-f0-9]+)/.exec(req.headers.cookie || '');
  if (m) sesiones.delete(m[1]);
  return { ok: true };
}, { publica: true });
ruta('GET', '/api/me', (req, res, { u }) => {
  const cfg = getConfig();
  const publico = { ...cfg };
  for (const k of CONFIG_SECRETA) publico[k] = cfg[k] ? '********' : '';
  if (!puede(u, 'configuracion')) for (const k of ['relay_url', 'mp_terminal_id']) delete publico[k];
  return {
    usuario: { id: u.id, nombre: u.nombre, usuario: u.usuario, rol: u.rol }, permisos: u.perms, catalogoPermisos: Object.fromEntries(Object.entries(PERMISOS).filter(([k]) => !(k in MOD.MODULOS) || MOD.activo(k))), permisosRol: PERMISOS_ROL,
    turno: turnoAbierto(u.id) || null, config: publico, planes: PLANES, tiposCliente: TIPOS_CLIENTE, mp_configurado: !!(cfg.mp_access_token && cfg.mp_terminal_id), mp_conectado: !!cfg.mp_access_token,
    tarifas: db.prepare('SELECT * FROM tarifas WHERE activo=1 ORDER BY orden, id').all(),
    convenios: db.prepare('SELECT * FROM convenios WHERE activo=1 ORDER BY nombre').all(),
    productos: db.prepare('SELECT * FROM productos WHERE activo=1 ORDER BY orden, nombre').all().filter((p) => MOD.activo('publicidad') || !/\blona/i.test(p.nombre)),
    licencia: licEstado(), version: VERSION, producto: PRODUCTO, modulos: MOD.todos(),
    avisos: {
      gastos_fijos: puede(u, 'gastos') && MOD.activo('gastos') ? listaGastosFijos().filter((g) => ['vencido', 'por vencer'].includes(g.estado)).length : 0,
      publicidad: puede(u, 'publicidad') && MOD.activo('publicidad') ? listaEspacios().filter((e) => ['vencido', 'por vencer'].includes(e.estado)).length : 0,
    },
  };
});
ruta('POST', '/api/cambiar-password', (req, res, { u, body }) => {
  if (!checkPass(body.actual || '', u.pass)) fallo('La contraseña actual no es correcta');
  if (String(body.nueva || '').length < 4) fallo('La nueva contraseña debe tener al menos 4 caracteres');
  db.prepare('UPDATE usuarios SET pass=? WHERE id=?').run(hashPass(body.nueva), u.id);
  bitacora(u.id, 'password', 'Cambió su contraseña');
  return { ok: true };
});

/* ---------- Estado ---------- */
ruta('GET', '/api/estado', () => estado());
ruta('GET', '/api/red', (req, res, { u }) => { requiere(u, 'configuracion', 'reportes'); return infoRed(); });

/* ---------- Pantalla del cliente ---------- */
ruta('GET', '/api/pantalla/info', () => {
  const cfg = getConfig(), e = estado();
  return { empresa: cfg.empresa_nombre, bienvenida: cfg.pantalla_bienvenida, gracias: cfg.pantalla_gracias, disponibles: e.disponibles, capacidad: e.capacidad, lleno: e.lleno };
}, { publica: true, sinLicencia: true });
ruta('GET', '/api/pantalla/stream', (req, res) => {
  const ip = ipDe(req);
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
  res.write('retry: 2000\n\n');
  if (pantallas.has(ip)) res.write('data: ' + JSON.stringify(pantallas.get(ip)) + '\n\n');
  if (!suscriptores.has(ip)) suscriptores.set(ip, new Set());
  suscriptores.get(ip).add(res);
  const ka = setInterval(() => res.write(': ok\n\n'), 25000);
  req.on('close', () => { clearInterval(ka); suscriptores.get(ip)?.delete(res); });
  return null;
}, { publica: true, sinLicencia: true });
ruta('POST', '/api/pantalla', (req, res, { body }) => {
  const permitido = ['espera', 'entrada', 'cobro', 'pagado', 'venta'];
  publicarPantalla(ipDe(req), { ...body, estado: permitido.includes(body.estado) ? body.estado : 'espera' });
  return { ok: true };
});

ruta('GET', '/api/buscar', (req, res, { q }) => {
  const s = String(q.get('q') || '').trim();
  if (!s) return [];
  const pl = limpiaPlaca(s);
  return db.prepare(`SELECT id, placas, marca, modelo, color, cliente, entrada FROM tickets WHERE estado='dentro'
    AND (CAST(id AS TEXT)=? OR ${SQL_PLACA} LIKE ? OR UPPER(marca||' '||modelo||' '||color) LIKE ?) ORDER BY entrada DESC LIMIT 30`)
    .all(String(Number(s) || -1), '%' + pl + '%', '%' + s.toUpperCase() + '%');
});

/* ---------- Turnos ---------- */
ruta('POST', '/api/turno/abrir', async (req, res, { u, body }) => {
  if (turnoAbierto(u.id)) fallo('Ya tiene un turno abierto');
  const tc = r2(num(body.tipo_cambio));
  if (!(tc > 0)) fallo('Indique el tipo de cambio del dólar');
  const r = db.prepare('INSERT INTO turnos(usuario_id, apertura, fondo_pesos, fondo_usd, tipo_cambio) VALUES(?,?,?,?,?)')
    .run(u.id, Date.now(), r2(Math.max(0, num(body.fondo_pesos))), r2(Math.max(0, num(body.fondo_usd))), tc);
  bitacora(u.id, 'abrir_turno', { turno: Number(r.lastInsertRowid), fondo_pesos: body.fondo_pesos, fondo_usd: body.fondo_usd, tc });
  // Abre el cajón para colocar el fondo de caja
  const cajon = await imprimir(new Ticket(getConfig().impresora_columnas), { cajon: true });
  return { ok: true, turno: turnoAbierto(u.id), cajon: { ok: cajon.ok, error: cajon.error, simulado: cajon.simulado } };
});
ruta('POST', '/api/turno/movimiento', (req, res, { u, body }) => {
  requiere(u, 'movimientos');
  const t = requiereTurno(u);
  const tipo = body.tipo === 'ingreso' ? 'ingreso' : 'retiro', moneda = body.moneda === 'USD' ? 'USD' : 'MXN', monto = r2(num(body.monto));
  if (!(monto > 0)) fallo('Monto inválido');
  if (!String(body.motivo || '').trim()) fallo('Escriba el motivo');
  db.prepare('INSERT INTO movimientos(turno_id, usuario_id, tipo, moneda, monto, motivo, fecha) VALUES(?,?,?,?,?,?,?)')
    .run(t.id, u.id, tipo, moneda, monto, String(body.motivo).slice(0, 200), Date.now());
  bitacora(u.id, tipo, `${moneda} ${monto} - ${body.motivo}`);
  return { ok: true };
});
ruta('POST', '/api/turno/cerrar', async (req, res, { u, body }) => {
  const t = requiereTurno(u);
  // 2.7.3: lo que se deje en blanco cuenta como 0 (no hay que llenar cada casilla)
  for (const k of ['decl_pesos', 'decl_usd', 'decl_tarjeta']) { if (body[k] === '' || body[k] == null) body[k] = 0; if (!(num(body[k], -1) >= 0)) fallo('Las cantidades no pueden ser negativas'); }
  db.prepare("UPDATE turnos SET decl_pesos=?, decl_usd=?, decl_tarjeta=?, notas=?, cierre=?, estado='cerrado' WHERE id=?")
    .run(r2(body.decl_pesos), r2(body.decl_usd), r2(body.decl_tarjeta), String(body.notas || '').slice(0, 500), Date.now(), t.id);
  const res2 = resumenTurno(t.id);
  bitacora(u.id, 'cerrar_turno', { turno: t.id, dif_mxn: res2.dif_mxn, dif_usd: res2.dif_usd, dif_tarjeta: res2.dif_tarjeta });
  const cfg = getConfig();
  const verDif = puede(u, 'ver_diferencias') || cfg.mostrar_diferencia_cajero;
  const imp = await imprimir(ticketCorte(res2, cfg, verDif));
  return { ok: true, corte: verDif ? res2 : ocultarEsperado(res2), impresion: imp };
});
ruta('GET', '/api/turno/:id/detalle', (req, res, { u, params }) => {
  requiere(u, 'reportes');
  const id = Number(params.id);
  const r = resumenTurno(id);
  const cols = `t.id, t.placas, t.marca, t.modelo, t.color, t.cliente, t.entrada, t.salida, t.estado, t.minutos, t.subtotal, t.descuento, t.cargo_perdido,
    t.extras_total, t.total, t.perdido, t.cortesia_para, t.cancel_motivo, t.modo_ingreso, ta.nombre tarifa, c.nombre convenio, cl.nombre cliente_nombre`;
  const from = `FROM tickets t LEFT JOIN tarifas ta ON ta.id=IFNULL(t.tarifa_cobro_id, t.tarifa_id) LEFT JOIN convenios c ON c.id=t.convenio_id LEFT JOIN clientes cl ON cl.id=t.cliente_id`;
  return {
    ...r,
    tickets_entrada: db.prepare(`SELECT ${cols} ${from} WHERE t.turno_entrada=? ORDER BY t.entrada`).all(id),
    tickets_salida: db.prepare(`SELECT ${cols} ${from} WHERE t.turno_salida=? ORDER BY t.salida`).all(id),
    otros_pagos: db.prepare(`SELECT p.id, p.concepto, p.total, p.detalle, p.fecha, cl.nombre cliente FROM pagos p LEFT JOIN clientes cl ON cl.id=p.cliente_id
      WHERE p.turno_id=? AND p.concepto<>'estacionamiento' AND p.cancelado=0 ORDER BY p.fecha`).all(id),
    movimientos: db.prepare('SELECT * FROM movimientos WHERE turno_id=? ORDER BY fecha').all(id),
  };
});
ruta('POST', '/api/turno/:id/reimprimir', async (req, res, { u, params }) => {
  requiere(u, 'reportes');
  const r = resumenTurno(Number(params.id));
  if (r.turno.estado !== 'cerrado') fallo('El turno sigue abierto');
  return imprimir(ticketCorte(r, getConfig(), true));
});

/* ---------- Entradas ---------- */
ruta('POST', '/api/entrada', async (req, res, { u, body }) => {
  const manual = body.modo === 'manual';
  requiere(u, manual ? 'ingreso_manual' : 'ingreso_rapido');
  const turno = requiereTurno(u);
  const cfg = getConfig();
  if (estado().lleno && cfg.bloquear_lleno) fallo('Estacionamiento LLENO: no hay espacios disponibles');
  let tipo = ['normal', 'mesero'].includes(body.cliente) ? body.cliente : 'normal';
  let placas = String(body.placas || '').toUpperCase().trim().slice(0, 15);
  // Mesero nuevo: se registra (nombre y su carro) y se le da ingreso en el mismo paso
  const nm = body.nuevo_mesero;
  let nuevoMesero = null;
  if (nm && manual) {
    const nombre = String(nm.nombre || '').trim().slice(0, 80);
    if (!nombre) fallo('Escriba el nombre del mesero');
    if (!placas) fallo('Escriba las placas del carro del mesero');
    const yaReg = vehiculoPorPlaca(placas);
    if (yaReg) fallo(`Las placas ${placas} ya están registradas con ${yaReg.cliente_nombre}. Búsquelo en la lista de meseros.`);
    nuevoMesero = { nombre, telefono: String(nm.telefono || '').slice(0, 30), notas: String(nm.notas || '').slice(0, 200) };
  }
  // Vehículo de un cliente registrado (por selección o por placas)
  let veh = null;
  if (body.vehiculo_id) veh = db.prepare('SELECT * FROM vehiculos WHERE id=? AND activo=1').get(Number(body.vehiculo_id));
  else if (placas) veh = vehiculoPorPlaca(placas);
  if (body.cliente === 'registrado' && !veh) fallo('Seleccione el cliente y su vehículo');
  let cli = veh ? getCliente(veh.cliente_id) : null;
  if (cli && !cli.activo) fallo(`El cliente ${cli.nombre} está dado de baja`);
  let aviso = null;
  if (cli) {
    tipo = pensionVigente(cli) ? 'pension' : cli.tipo;
    if (cli.tipo === 'pension' && !pensionVigente(cli)) {
      if (cfg.bloquear_pension_vencida && !body.forzar_vencida) fallo(`ACCESO NEGADO: la pensión de ${cli.nombre} está VENCIDA. Cobre la pensión o dé entrada como cliente normal.`, 423);
      aviso = `Pensión de ${cli.nombre} VENCIDA: se cobrará tarifa`;
    }
    placas = veh.placas || placas;
  }
  if (placas && !nuevoMesero) {
    const dup = db.prepare(`SELECT id FROM tickets WHERE estado='dentro' AND ${SQL_PLACA}=?`).get(limpiaPlaca(placas));
    if (dup && !body.forzar) fallo(`Las placas ${placas} ya están dentro con el boleto ${folio(dup.id)}. Revise antes de continuar.`, 409);
  }
  if (nuevoMesero) {
    const dup = db.prepare(`SELECT id FROM tickets WHERE estado='dentro' AND ${SQL_PLACA}=?`).get(limpiaPlaca(placas));
    if (dup && !body.forzar) fallo(`Las placas ${placas} ya están dentro con el boleto ${folio(dup.id)}. Revise antes de continuar.`, 409);
    const cid = Number(db.prepare("INSERT INTO clientes(nombre, telefono, tipo, notas, activo, creado) VALUES(?,?,'mesero',?,1,?)")
      .run(nuevoMesero.nombre, nuevoMesero.telefono, nuevoMesero.notas, Date.now()).lastInsertRowid);
    const vid = Number(db.prepare('INSERT INTO vehiculos(cliente_id, placas, marca, modelo, color) VALUES(?,?,?,?,?)')
      .run(cid, placas, String(body.marca || '').slice(0, 30), String(body.modelo || '').slice(0, 30), String(body.color || '').slice(0, 20)).lastInsertRowid);
    veh = db.prepare('SELECT * FROM vehiculos WHERE id=?').get(vid);
    cli = getCliente(cid); tipo = 'mesero';
    bitacora(u.id, 'cliente_alta', `${nuevoMesero.nombre} (Mesero, registrado en la entrada) ${placas}`);
  }
  let tarifa_id = Number(body.tarifa_id) || cli?.tarifa_id || (tipo === 'mesero' ? cfg.tarifa_mesero_id : !manual && Number(cfg.tarifa_rapida_id) ? cfg.tarifa_rapida_id : cfg.tarifa_default_id);
  if (!getTarifa(tarifa_id)) tarifa_id = db.prepare('SELECT id FROM tarifas WHERE activo=1 ORDER BY orden LIMIT 1').get()?.id;
  const r = db.prepare(`INSERT INTO tickets(placas, marca, modelo, color, modo_ingreso, cliente, tarifa_id, cliente_id, vehiculo_id, entrada, usuario_entrada, turno_entrada, notas)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
    placas, String(veh?.marca || body.marca || '').slice(0, 30), String(veh?.modelo || body.modelo || '').slice(0, 30),
    String(veh?.color || body.color || '').slice(0, 20), manual ? 'manual' : 'rapido', tipo, tarifa_id, cli?.id || null, veh?.id || null,
    Date.now(), u.id, turno.id, String(body.notas || '').slice(0, 200));
  const tk = getTicket(Number(r.lastInsertRowid));
  const [imp, foto] = await Promise.all([imprimir(ticketEntrada(tk, cfg)), cfg.camara_tipo === 'ip' ? fotoCamaraIP(tk.id) : null]);
  // 2.5: la placa vino de la cámara (pre-ingreso) o se lee de la foto en segundo plano
  if (body.lpr_id) db.prepare('UPDATE lpr_lecturas SET ticket_id=? WHERE id=? AND ticket_id IS NULL').run(tk.id, Number(body.lpr_id));
  else if (placas) db.prepare('UPDATE lpr_lecturas SET ticket_id=? WHERE ticket_id IS NULL AND descartada=0 AND fecha>? AND placa=?').run(tk.id, Date.now() - PREINGRESO_MS, placaLPR(placas));
  if (!placas && foto && foto.ok) placaDespuesDeEntrada(tk.id);
  let pluma = null;
  if (cfg.abrir_pluma_al_ingresar) pluma = await abrirPluma('entrada ' + folio(tk.id), u.id);
  return { ok: true, ticket: tk, folio: folio(tk.id), tarifa: nombreTarifa(tk.tarifa_id), impresion: imp, pluma, aviso, cliente: cli ? cli.nombre : null, foto, camara: cfg.camara_tipo };
});

/* ---------- Cobro ---------- */
function ticketActivo(id) {
  const tk = getTicket(Number(String(id).replace(/\D/g, '')));
  if (!tk) fallo('No existe el boleto ' + id, 404);
  if (tk.estado === 'pagado') fallo(`El boleto ${folio(tk.id)} ya fue pagado el ${fechaHora(tk.salida)}`, 409);
  if (tk.estado === 'cancelado') fallo(`El boleto ${folio(tk.id)} está cancelado`, 409);
  return tk;
}
function opcionesCobro(u, src) {
  let extras = src.extras;
  if (typeof extras === 'string') { try { extras = JSON.parse(extras); } catch { extras = []; } }
  const o = { convenio_id: Number(src.convenio_id) || null, tarifa_id: Number(src.tarifa_id) || null, perdido: src.perdido === true || src.perdido === '1' || src.perdido === 'true',
    cortesia_para: String(src.cortesia_para || '').trim().slice(0, 80), cortesia_motivo: String(src.cortesia_motivo || '').trim().slice(0, 200), extras: extras || [] };
  o.cortesia = !!o.cortesia_para;
  // 2.5.2: se cobra con la hora que vio el cajero en pantalla (si pasaron hasta 15 min), para que no cambie el total mientras cobra
  const sal = Number(src.salida);
  if (sal > 0 && sal <= Date.now() && Date.now() - sal <= 15 * 60e3) o.ahora = sal;
  if (o.cortesia) {
    const lista = getConfig().cortesia_lista || [];
    if (lista.length && !lista.some((x) => x.toLowerCase() === o.cortesia_para.toLowerCase())) fallo('Sólo se permiten cortesías para: ' + lista.join(', '));
  }
  if (o.convenio_id) requiere(u, 'aplicar_convenio');
  if (o.tarifa_id) requiere(u, 'cambiar_tarifa');
  if (o.perdido) requiere(u, 'boleto_perdido');
  if (o.cortesia) requiere(u, 'cortesia');
  if (o.extras.length) requiere(u, 'vender_productos');
  return o;
}
ruta('GET', '/api/ticket/:id', (req, res, { u, params, q }) => {
  requiere(u, 'cobrar', 'boleto_perdido');
  const tk = ticketActivo(params.id);
  const opt = opcionesCobro(u, Object.fromEntries(q));
  return { ticket: tk, cotizacion: cotizar(tk, opt), tarifa_entrada: nombreTarifa(tk.tarifa_id) };
});
ruta('POST', '/api/ticket/:id/cobrar', async (req, res, { u, params, body }) => {
  requiere(u, 'cobrar', 'boleto_perdido');
  const turno = requiereTurno(u);
  const cfg = getConfig();
  const opt = opcionesCobro(u, body);
  const { tk, pago, cot } = tx(() => {
    const tk0 = ticketActivo(params.id);
    const cot = cotizar(tk0, opt);
    const v = cot.total > 0 ? validarPago(cot.total, body, turno.tipo_cambio) : null;
    const pago = v ? registrarPago(turno, u.id, 'estacionamiento', { ticket_id: tk0.id, cliente_id: tk0.cliente_id }, cot.total, v, cot.extras) : null;
    db.prepare(`UPDATE tickets SET estado='pagado', salida=?, minutos=?, subtotal=?, descuento=?, cargo_perdido=?, extras_total=?, total=?, convenio_id=?,
      tarifa_cobro_id=?, cortesia_para=?, cortesia_motivo=?, perdido=?, perdido_datos=?, usuario_salida=?, turno_salida=? WHERE id=?`)
      .run(cot.salida, cot.minutos, cot.subtotal, cot.descuento, cot.cargo_perdido, cot.extras_total, cot.total, opt.convenio_id, cot.tarifa?.id || null,
        opt.cortesia ? opt.cortesia_para : null, opt.cortesia ? opt.cortesia_motivo : null, opt.perdido ? 1 : 0,
        opt.perdido ? JSON.stringify(body.perdido_datos || {}) : null, u.id, turno.id, tk0.id);
    if (opt.cortesia) bitacora(u.id, 'cortesia', `Boleto ${folio(tk0.id)} para ${opt.cortesia_para}${opt.cortesia_motivo ? ' (' + opt.cortesia_motivo + ')' : ''}: ${money(cot.subtotal)}`);
    if (opt.perdido) bitacora(u.id, 'boleto_perdido', `Boleto ${folio(tk0.id)} cobrado como perdido`);
    return { tk: getTicket(tk0.id), pago, cot };
  });
  const efectivo = pago && (pago.pesos > 0 || pago.usd > 0);
  const imp = await imprimirCobro(ticketPagado(tk, pago, cfg, false), efectivo ? pago : null, body);
  let pluma = null;
  if (cfg.abrir_pluma_al_cobrar) pluma = await abrirPluma('salida ' + folio(tk.id), u.id);
  return { ok: true, ticket: tk, pago, cotizacion: cot, impresion: imp, pluma, preguntar_copia: !!cfg.preguntar_copia_cajero };
});
ruta('POST', '/api/ticket/:id/reimprimir', async (req, res, { u, params, body }) => {
  requiere(u, 'reimprimir', 'cobrar');
  const tk = getTicket(Number(params.id));
  if (!tk) fallo('No existe el boleto', 404);
  if (body.tipo !== 'copia') requiere(u, 'reimprimir');
  const cfg = getConfig();
  if (body.tipo === 'pagado' || body.tipo === 'copia') {
    if (tk.estado !== 'pagado') fallo('Ese boleto no ha sido pagado');
    const pago = db.prepare('SELECT * FROM pagos WHERE ticket_id=? AND cancelado=0 ORDER BY id DESC LIMIT 1').get(tk.id);
    if (body.tipo !== 'copia') bitacora(u.id, 'reimprimir', 'Comprobante ' + folio(tk.id));
    return imprimir(ticketPagado(tk, pago, cfg, body.tipo === 'copia'));
  }
  bitacora(u.id, 'reimprimir', 'Boleto de entrada ' + folio(tk.id));
  return imprimir(ticketEntrada(tk, cfg, true));
});
ruta('POST', '/api/ticket/:id/cancelar', (req, res, { u, params, body }) => {
  requiere(u, 'cancelar_ticket');
  const turno = requiereTurno(u);
  const tk = ticketActivo(params.id);
  if (!String(body.motivo || '').trim()) fallo('Escriba el motivo de la cancelación');
  db.prepare("UPDATE tickets SET estado='cancelado', cancel_motivo=?, salida=?, usuario_salida=?, turno_salida=? WHERE id=?")
    .run(String(body.motivo).slice(0, 200), Date.now(), u.id, turno.id, tk.id);
  bitacora(u.id, 'cancelar_ticket', `Boleto ${folio(tk.id)}: ${body.motivo}`);
  return { ok: true };
});
ruta('POST', '/api/perdido/formato', async (req, res, { u, body }) => {
  requiere(u, 'boleto_perdido');
  const tk = body.ticket_id ? getTicket(Number(body.ticket_id)) : null;
  let monto;
  if (tk && tk.estado === 'dentro') monto = cotizar(tk, { perdido: true }).total;
  return imprimir(ticketPerdido({ ...(body.datos || {}), monto }, tk, getConfig()));
});
ruta('POST', '/api/pluma', async (req, res, { u, body }) => {
  requiere(u, 'abrir_pluma');
  return abrirPluma('manual: ' + String(body.motivo || 'sin motivo').slice(0, 100), u.id);
});

/* ---------- Venta de productos y servicios ---------- */
ruta('POST', '/api/venta', async (req, res, { u, body }) => {
  requiere(u, 'vender_productos');
  const turno = requiereTurno(u);
  const extras = armarExtras(body.items);
  if (!extras.length) fallo('Agregue al menos un producto o servicio');
  const total = r2(extras.reduce((s, e) => s + e.importe, 0));
  const pago = tx(() => registrarPago(turno, u.id, 'producto', {}, total, validarPago(total, body, turno.tipo_cambio), extras));
  bitacora(u.id, 'venta', `V${folio(pago.id)} ${money(total)}`);
  const imp = await imprimirCobro(ticketVenta(pago, getConfig()), pago, body);
  return { ok: true, pago, impresion: imp, preguntar_copia: !!getConfig().preguntar_copia_cajero };
});
ruta('GET', '/api/ventas/hoy', (req, res, { u }) => {
  requiere(u, 'vender_productos');
  const hoy = new Date(); hoy.setHours(0, 0, 0, 0);
  const ver = puede(u, 'reportes');
  return db.prepare(`SELECT p.id, p.fecha, p.total, p.detalle, p.pesos, p.usd, p.tarjeta, p.transferencia, p.mp_order_id, p.cambio, p.cancelado, u.nombre cajero FROM pagos p LEFT JOIN usuarios u ON u.id=p.usuario_id
    WHERE p.concepto='producto' AND p.fecha >= ? ${ver ? '' : 'AND p.usuario_id=?'} ORDER BY p.id DESC LIMIT 300`).all(...(ver ? [+hoy] : [+hoy, u.id]));
});
ruta('POST', '/api/venta/:id/reimprimir', async (req, res, { u, params, body }) => {
  requiere(u, 'vender_productos', 'reimprimir');
  const pago = db.prepare("SELECT * FROM pagos WHERE id=? AND concepto='producto'").get(Number(params.id)) || fallo('No existe la venta', 404);
  return imprimir(ticketVenta(pago, getConfig(), !!body.copia));
});
ruta('GET', '/api/productos', (req, res, { u }) => { requiere(u, 'productos_admin', 'vender_productos'); return db.prepare('SELECT * FROM productos ORDER BY activo DESC, orden, nombre').all(); });
ruta('POST', '/api/productos', (req, res, { u, body }) => {
  requiere(u, 'productos_admin');
  const nombre = String(body.nombre || '').trim() || fallo('Escriba el nombre');
  const v = [nombre.slice(0, 60), body.tipo === 'producto' ? 'producto' : 'servicio', r2(Math.max(0, num(body.precio))), body.activo === false ? 0 : 1, Math.round(num(body.orden)),
    body.precio_libre ? 1 : 0, body.rapido ? 1 : 0, String(body.codigo || '').trim().slice(0, 40)];
  if (!v[5] && !(v[2] > 0)) fallo('Escriba el precio o marque "Precio libre"');
  if (v[7] && db.prepare('SELECT id FROM productos WHERE codigo=? AND id<>?').get(v[7], Number(body.id) || -1)) fallo('Ese código ya lo tiene otro producto');
  if (body.id) db.prepare('UPDATE productos SET nombre=?, tipo=?, precio=?, activo=?, orden=?, precio_libre=?, rapido=?, codigo=? WHERE id=?').run(...v, Number(body.id));
  else db.prepare('INSERT INTO productos(nombre, tipo, precio, activo, orden, precio_libre, rapido, codigo) VALUES(?,?,?,?,?,?,?,?)').run(...v);
  bitacora(u.id, 'producto', `${nombre} ${money(v[2])}`);
  return { ok: true };
});
// 2.7.2: eliminar productos y servicios (los cobros ya hechos conservan el nombre y el importe)
ruta('POST', '/api/productos/:id/eliminar', (req, res, { u, params }) => {
  requiere(u, 'productos_admin');
  const p = db.prepare('SELECT * FROM productos WHERE id=?').get(Number(params.id)) || fallo('No existe el producto', 404);
  db.prepare('DELETE FROM productos WHERE id=?').run(p.id);
  bitacora(u.id, 'producto_eliminado', p.nombre);
  return { ok: true };
});

/* ---------- Mercado Pago ---------- */
ruta('POST', '/api/mp/cobrar', async (req, res, { u, body }) => {
  requiere(u, 'cobrar', 'pensiones_cobrar', 'vender_productos');
  requiereTurno(u);
  const cfg = getConfig();
  if (!cfg.mp_terminal_id) fallo('Configure el ID de la terminal Point');
  const monto = r2(num(body.monto));
  if (!(monto > 0)) fallo('Monto inválido');
  const ref = ('MX' + String(body.referencia || 'P').replace(/[^A-Za-z0-9_-]/g, '') + '-' + Date.now()).slice(0, 64);
  const o = await mpFetch('/v1/orders', { method: 'POST', body: JSON.stringify({
    type: 'point', external_reference: ref, expiration_time: 'PT5M', description: cfg.empresa_nombre.slice(0, 50),
    transactions: { payments: [{ amount: monto.toFixed(2) }] },
    config: { point: { terminal_id: cfg.mp_terminal_id, print_on_terminal: 'no_ticket' } } }) });
  bitacora(u.id, 'mp_orden', `${o.id} ${money(monto)}`);
  return { id: o.id, status: o.status };
});
ruta('GET', '/api/mp/orden/:id', async (req, res, { u, params }) => {
  requiere(u, 'cobrar', 'pensiones_cobrar', 'vender_productos');
  const o = await mpFetch('/v1/orders/' + encodeURIComponent(params.id));
  const pay = o.transactions?.payments?.[0] || {};
  return { id: o.id, status: o.status, status_detail: o.status_detail, pago_status: pay.status, monto: Number(pay.amount || 0),
    referencia: pay.reference_id || pay.id || '', aprobado: o.status === 'processed' };
});
ruta('POST', '/api/mp/orden/:id/cancelar', async (req, res, { u, params }) => {
  requiere(u, 'cobrar', 'pensiones_cobrar', 'vender_productos');
  await mpFetch('/v1/orders/' + encodeURIComponent(params.id) + '/cancel', { method: 'POST', headers: { 'x-allow-cancelable-status': 'at_terminal' } });
  return { ok: true };
});
ruta('GET', '/api/mp/terminales', async (req, res, { u }) => {
  requiere(u, 'configuracion');
  return mpTerminales();
});

/* ---------- 2.7.2: Conectar con Mercado Pago iniciando sesión (igual que Maxsel POS) ----------
   El servidor de Maxsel (Cloudflare) cambia la autorización por la llave; la caja nunca ve las claves de Maxsel.
   La llave dura 180 días y se renueva sola cuando le faltan menos de 30. */
const MP_LINK = process.env.MAXSEL_MP_LINK || 'https://maxsel-mp.ventasmaxsel.workers.dev';
let mpConexion = null; // { s, hasta }
async function mpTerminales() {
  const d = await mpFetch('/terminals/v1/list?limit=50&offset=0');
  return d.data?.terminals || d.terminals || [];
}
async function mpModoPDV(t) {
  if (!t || t.operating_mode === 'PDV') return true;
  try { await mpFetch('/terminals/v1/setup', { method: 'PATCH', body: JSON.stringify({ terminals: [{ id: t.id, operating_mode: 'PDV' }] }) }); return true; } catch { return false; }
}
function mpGuardarLlave(j) {
  setConfig({ mp_access_token: j.access_token, mp_refresh_token: j.refresh_token || getConfig().mp_refresh_token || '', mp_token_vence: Date.now() + (Number(j.expires_in) || 15552000) * 1000, mp_via: 'oauth' });
}
ruta('POST', '/api/mp/conectar', (req, res, { u }) => {
  requiere(u, 'configuracion');
  mpConexion = { s: crypto.randomBytes(24).toString('hex'), hasta: Date.now() + 12 * 60e3 };
  return { url: MP_LINK + '/start?s=' + mpConexion.s };
});
ruta('GET', '/api/mp/conectar/estado', async (req, res, { u }) => {
  requiere(u, 'configuracion');
  const c = mpConexion;
  if (!c) return { estado: 'sin' };
  if (Date.now() > c.hasta) { mpConexion = null; return { estado: 'vencido' }; }
  let j;
  try { const r = await fetch(MP_LINK + '/claim?s=' + c.s, { signal: AbortSignal.timeout(10000) }); j = await r.json(); } catch { return { estado: 'esperando', sinInternet: true }; }
  if (!j || !j.access_token) return { estado: 'esperando' };
  mpConexion = null;
  mpGuardarLlave(j);
  bitacora(u.id, 'mp_conectado', 'Cuenta de Mercado Pago conectada' + (j.user_id ? ' (' + j.user_id + ')' : ''));
  // elige sola la terminal si solo hay una y la pone en modo PDV
  let terminales = [], terminal = '', aviso = '';
  try {
    terminales = await mpTerminales();
    const cfg = getConfig();
    const t = terminales.find((x) => x.id === cfg.mp_terminal_id) || (terminales.length === 1 ? terminales[0] : null);
    if (t) { setConfig({ mp_terminal_id: t.id }); terminal = t.id; if (!(await mpModoPDV(t))) aviso = 'No se pudo poner la terminal en modo PDV: reiníciela.'; }
  } catch (e) { aviso = e.message; }
  return { estado: 'listo', terminales, terminal, aviso };
});
ruta('POST', '/api/mp/terminal', async (req, res, { u, body }) => {
  requiere(u, 'configuracion');
  const ts = await mpTerminales();
  const t = ts.find((x) => x.id === String(body.id || '')) || fallo('No se encontró esa terminal en su cuenta');
  setConfig({ mp_terminal_id: t.id });
  const pdv = await mpModoPDV(t);
  bitacora(u.id, 'mp_terminal', t.id);
  return { ok: true, pdv };
});
ruta('POST', '/api/mp/desconectar', (req, res, { u }) => {
  requiere(u, 'configuracion');
  setConfig({ mp_access_token: '', mp_refresh_token: '', mp_token_vence: 0, mp_via: '', mp_terminal_id: '' });
  bitacora(u.id, 'mp_desconectado', '');
  return { ok: true };
});
async function mpRenovar() {
  try {
    const cfg = getConfig();
    if (cfg.mp_via !== 'oauth' || !cfg.mp_refresh_token || !cfg.mp_token_vence || cfg.mp_token_vence - Date.now() > 30 * 864e5) return;
    const r = await fetch(MP_LINK + '/refresh', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refresh_token: cfg.mp_refresh_token }), signal: AbortSignal.timeout(15000) });
    const j = await r.json();
    if (j && j.access_token) mpGuardarLlave(j);
  } catch { /* sin internet: se intenta más tarde */ }
}
setTimeout(mpRenovar, 30e3).unref(); setInterval(mpRenovar, 6 * 3600e3).unref();

/* ---------- Clientes (meseros, frecuentes, pensionados) ---------- */
ruta('GET', '/api/clientes', (req, res, { u }) => { requiere(u, 'pensiones_cobrar', 'clientes_admin', 'ingreso_manual'); return listaClientes(); });
ruta('POST', '/api/clientes', (req, res, { u, body }) => {
  requiere(u, 'clientes_admin');
  const nombre = String(body.nombre || '').trim() || fallo('Escriba el nombre del cliente');
  const tipo = TIPOS_CLIENTE[body.tipo] ? body.tipo : 'mesero';
  const tarifa_id = Number(body.tarifa_id) || null;
  if (tarifa_id && !getTarifa(tarifa_id)) fallo('La tarifa no existe');
  const vehiculos = (Array.isArray(body.vehiculos) ? body.vehiculos : []).map((v) => ({
    id: Number(v.id) || null, placas: String(v.placas || '').toUpperCase().trim().slice(0, 15), marca: String(v.marca || '').slice(0, 30),
    modelo: String(v.modelo || '').slice(0, 30), color: String(v.color || '').slice(0, 20), activo: v.activo === false ? 0 : 1 })).filter((v) => v.id || v.placas || v.marca);
  return tx(() => {
    const vals = [nombre.slice(0, 80), String(body.telefono || '').slice(0, 30), tipo, tarifa_id, String(body.notas || '').slice(0, 200), body.activo === false ? 0 : 1, String(body.pension_categoria || '').slice(0, 40) || null];
    let id = Number(body.id) || null;
    if (id) db.prepare('UPDATE clientes SET nombre=?, telefono=?, tipo=?, tarifa_id=?, notas=?, activo=?, pension_categoria=? WHERE id=?').run(...vals, id);
    else id = Number(db.prepare('INSERT INTO clientes(nombre, telefono, tipo, tarifa_id, notas, activo, pension_categoria, creado) VALUES(?,?,?,?,?,?,?,?)').run(...vals, Date.now()).lastInsertRowid);
    for (const v of vehiculos) {
      if (v.placas) {
        const otro = db.prepare(`SELECT v.id, c.nombre FROM vehiculos v JOIN clientes c ON c.id=v.cliente_id WHERE v.activo=1 AND c.activo=1 AND ${SQL_PLACA.replace(/placas/g, 'v.placas')}=? AND v.id<>?`)
          .get(limpiaPlaca(v.placas), v.id || -1);
        if (otro && v.activo) fallo(`Las placas ${v.placas} ya están registradas con el cliente ${otro.nombre}`);
      }
      if (v.id) db.prepare('UPDATE vehiculos SET placas=?, marca=?, modelo=?, color=?, activo=? WHERE id=? AND cliente_id=?').run(v.placas, v.marca, v.modelo, v.color, v.activo, v.id, id);
      else if (v.activo) db.prepare('INSERT INTO vehiculos(cliente_id, placas, marca, modelo, color) VALUES(?,?,?,?,?)').run(id, v.placas, v.marca, v.modelo, v.color);
    }
    bitacora(u.id, body.id ? 'cliente_editar' : 'cliente_alta', `${nombre} (${TIPOS_CLIENTE[tipo]}, ${vehiculos.filter((v) => v.activo).length} vehículo(s))`);
    return { ok: true, id };
  });
});
ruta('POST', '/api/clientes/:id/cobrar', async (req, res, { u, params, body }) => {
  requiere(u, 'pensiones_cobrar');
  const turno = requiereTurno(u);
  const c = getCliente(params.id) || fallo('No existe el cliente', 404);
  const cfgP = getConfig();
  const plan = PLANES[body.plan] ? body.plan : fallo('Elija el plan');
  if (!cfgP.pension_planes.includes(plan)) fallo(`El plan ${PLANES[plan]} no está habilitado`);
  const cat = cfgP.pension_categorias.find((x) => x.id === body.categoria) || cfgP.pension_categorias.find((x) => x.id === c.pension_categoria) || cfgP.pension_categorias[0];
  const desde = num(body.desde), hasta = num(body.hasta), monto = r2(num(body.monto));
  if (!(desde > 0 && hasta > desde)) fallo('Revise las fechas de la pensión');
  if (!(monto > 0)) fallo('Indique el monto');
  const { pago, per } = tx(() => {
    const v = validarPago(monto, body, turno.tipo_cambio);
    const pago = registrarPago(turno, u.id, 'pension', { cliente_id: c.id }, monto, v);
    const r = db.prepare('INSERT INTO pension_periodos(cliente_id, plan, categoria, desde, hasta, monto, pago_id, fecha, usuario_id) VALUES(?,?,?,?,?,?,?,?,?)')
      .run(c.id, plan, cat.nombre, desde, hasta, monto, pago.id, Date.now(), u.id);
    const nuevoHasta = Math.max(c.vigente_hasta || 0, hasta);
    const nuevoDesde = c.vigente_hasta && c.vigente_hasta >= desde ? c.vigente_desde : desde;
    db.prepare("UPDATE clientes SET vigente_desde=?, vigente_hasta=?, activo=1, tipo='pension', pension_categoria=? WHERE id=?").run(nuevoDesde, nuevoHasta, cat.id, c.id);
    bitacora(u.id, 'pension_cobro', `${c.nombre} ${cat.nombre} ${PLANES[plan]} ${money(monto)}`);
    return { pago, per: db.prepare('SELECT * FROM pension_periodos WHERE id=?').get(Number(r.lastInsertRowid)) };
  });
  const cfg = getConfig();
  const imp = await imprimirCobro(ticketPension(c, per, pago, cfg), pago, body);
  return { ok: true, pago, impresion: imp, preguntar_copia: !!cfg.preguntar_copia_cajero, periodo_id: per.id, hasta: (getCliente(c.id) || {}).vigente_hasta || per.hasta };
});
ruta('POST', '/api/pension-periodo/:id/reimprimir', async (req, res, { u, params, body }) => {
  requiere(u, 'reimprimir', 'pensiones_cobrar');
  const per = db.prepare('SELECT * FROM pension_periodos WHERE id=?').get(Number(params.id)) || fallo('No existe', 404);
  const c = getCliente(per.cliente_id);
  const pago = db.prepare('SELECT * FROM pagos WHERE id=?').get(per.pago_id);
  return imprimir(ticketPension(c, per, pago, getConfig(), !!body.copia));
});

/* ---------- Catálogos (admin) ---------- */
ruta('GET', '/api/tarifas', (req, res, { u }) => { requiere(u, 'tarifas_admin', 'convenios_admin', 'clientes_admin'); return db.prepare('SELECT * FROM tarifas ORDER BY orden, id').all(); });
function tarifaDeBody(body) {
  const modo = ['hora', 'escalonada', 'bloque', 'fija'].includes(body.modo) ? body.modo : 'hora';
  const escalones = (Array.isArray(body.escalones) ? body.escalones : jsonArr(body.escalones)).map((x) => r2(Math.max(0, num(x)))).slice(0, 72);
  if (modo === 'escalonada' && !escalones.length) fallo('Capture el precio de al menos la primera hora');
  return { nombre: String(body.nombre || '').trim() || fallo('Escriba el nombre de la tarifa'), modo, precio_hora: r2(body.precio_hora), horas_bloque: num(body.horas_bloque, 12) || 12,
    precio_bloque: r2(body.precio_bloque), excedente: body.excedente === 'bloque' ? 'bloque' : 'hora', precio_hora_extra: r2(body.precio_hora_extra),
    tolerancia_min: Math.max(0, Math.round(num(body.tolerancia_min))), minutos_gratis: Math.max(0, Math.round(num(body.minutos_gratis))), tope: r2(body.tope),
    es_mesero: body.es_mesero ? 1 : 0, activo: body.activo === false ? 0 : 1, orden: Math.round(num(body.orden)), escalones: JSON.stringify(escalones) };
}
ruta('POST', '/api/tarifas', (req, res, { u, body }) => {
  requiere(u, 'tarifas_admin');
  const t = tarifaDeBody(body);
  const cols = Object.keys(t);
  if (body.id) db.prepare(`UPDATE tarifas SET ${cols.map((c) => c + '=?').join(', ')} WHERE id=?`).run(...Object.values(t), Number(body.id));
  else db.prepare(`INSERT INTO tarifas(${cols.join(', ')}) VALUES(${cols.map(() => '?').join(',')})`).run(...Object.values(t));
  bitacora(u.id, 'tarifa', t.nombre);
  return { ok: true };
});
ruta('POST', '/api/tarifas/simular', (req, res, { u, body }) => {
  requiere(u, 'tarifas_admin');
  const t = tarifaDeBody({ ...body, nombre: 'sim' });
  return [15, 45, 60, 75, 120, 180, 240, 300, 600, 720, 735, 780, 900, 1440, 1500, 2880].map((m) => ({ minutos: m, tiempo: tiempoTxt(m), ...calcularTarifa(t, m) }));
});
ruta('GET', '/api/convenios', (req, res, { u }) => { requiere(u, 'convenios_admin'); return db.prepare('SELECT * FROM convenios ORDER BY activo DESC, nombre').all(); });
ruta('POST', '/api/convenios', (req, res, { u, body }) => {
  requiere(u, 'convenios_admin');
  const nombre = String(body.nombre || '').trim() || fallo('Escriba el nombre del negocio');
  const tipo = ['porcentaje', 'monto', 'fijo', 'horas', 'tarifa'].includes(body.tipo) ? body.tipo : 'porcentaje';
  if (tipo === 'tarifa' && !getTarifa(Number(body.tarifa_id))) fallo('Elija la tarifa especial');
  const v = [nombre, tipo, r2(body.valor), tipo === 'tarifa' ? Number(body.tarifa_id) : null, String(body.notas || ''), body.activo === false ? 0 : 1];
  if (body.id) db.prepare('UPDATE convenios SET nombre=?, tipo=?, valor=?, tarifa_id=?, notas=?, activo=? WHERE id=?').run(...v, Number(body.id));
  else db.prepare('INSERT INTO convenios(nombre, tipo, valor, tarifa_id, notas, activo) VALUES(?,?,?,?,?,?)').run(...v);
  bitacora(u.id, 'convenio', nombre);
  return { ok: true };
});
ruta('GET', '/api/usuarios', (req, res, { u }) => {
  requiere(u, 'usuarios');
  return db.prepare('SELECT id, nombre, usuario, rol, permisos, activo FROM usuarios ORDER BY activo DESC, nombre').all()
    .map((x) => ({ ...x, permisos: permisosDe(x) }));
});
ruta('POST', '/api/usuarios', (req, res, { u, body }) => {
  requiere(u, 'usuarios');
  const nombre = String(body.nombre || '').trim() || fallo('Escriba el nombre');
  const usuario = String(body.usuario || '').trim().toLowerCase();
  if (!/^[a-z0-9._-]{3,30}$/.test(usuario)) fallo('El usuario debe tener de 3 a 30 letras o números, sin espacios');
  const rol = ['admin', 'supervisor', 'cajero'].includes(body.rol) ? body.rol : 'cajero';
  if (rol === 'admin' && u.rol !== 'admin') fallo('Solo un administrador puede crear administradores', 403);
  const permisos = JSON.stringify((body.permisos || []).filter((p) => PERMISOS[p]));
  const activo = body.activo === false ? 0 : 1;
  const otro = db.prepare('SELECT id FROM usuarios WHERE usuario=?').get(usuario);
  if (otro && otro.id !== Number(body.id)) fallo('Ese nombre de usuario ya existe');
  if (body.id) {
    const prev = db.prepare('SELECT * FROM usuarios WHERE id=?').get(Number(body.id)) || fallo('No existe', 404);
    if (prev.rol === 'admin' && u.rol !== 'admin') fallo('Solo un administrador puede modificar a otro administrador', 403);
    if (prev.rol === 'admin' && (rol !== 'admin' || !activo)) {
      if (!db.prepare("SELECT COUNT(*) n FROM usuarios WHERE rol='admin' AND activo=1 AND id<>?").get(prev.id).n) fallo('Debe quedar al menos un administrador activo');
    }
    db.prepare('UPDATE usuarios SET nombre=?, usuario=?, rol=?, permisos=?, activo=? WHERE id=?').run(nombre, usuario, rol, permisos, activo, prev.id);
    if (body.password) db.prepare('UPDATE usuarios SET pass=? WHERE id=?').run(hashPass(body.password), prev.id);
    if (!activo) for (const [k, s] of sesiones) if (s.uid === prev.id) sesiones.delete(k);
  } else {
    if (String(body.password || '').length < 4) fallo('La contraseña debe tener al menos 4 caracteres');
    db.prepare('INSERT INTO usuarios(nombre, usuario, pass, rol, permisos, activo, creado) VALUES(?,?,?,?,?,?,?)')
      .run(nombre, usuario, hashPass(body.password), rol, permisos, activo, Date.now());
  }
  bitacora(u.id, 'usuario', `${usuario} (${rol})`);
  return { ok: true };
});
ruta('POST', '/api/config', (req, res, { u, body }) => {
  requiere(u, 'configuracion');
  setConfig(body || {});
  bitacora(u.id, 'configuracion', Object.keys(body || {}).join(', '));
  return { ok: true };
});
ruta('POST', '/api/prueba/:que', async (req, res, { u, params }) => {
  requiere(u, 'configuracion');
  const cfg = getConfig();
  if (params.que === 'impresora') {
    // Imprime un boleto de ejemplo igual al real, para revisar tamaño, políticas, código de barras y corte
    const ej = { id: 123, placas: 'ABC-123', marca: 'Nissan', modelo: 'Versa', color: 'Gris', cliente: 'normal', tarifa_id: cfg.tarifa_default_id, entrada: Date.now(), usuario_entrada: u.id };
    const tk = ticketEntrada(ej, cfg);
    tk.ops.unshift(['align', 'center'], ['bold', true], ['text', '*** IMPRESIÓN DE PRUEBA ***'], ['bold', false], ['text', 'Acentos: Configuración, Peñasco, ¿Sí?'], ['feed', 1]);
    return imprimir(tk);
  }
  if (params.que === 'cajon') return imprimir(new Ticket(cfg.impresora_columnas), { cajon: true });
  // 2.5.2: prueba de ancho: renglones de 32, 42, 48 y 56 letras; el más largo que salga en UNA línea es el bueno
  if (params.que === 'ancho') {
    const tk = new Ticket(64), regla = (n) => { let x = ''; for (let i = 1; i <= n; i++) x += i % 10 === 0 ? String((i / 10) % 10) : i % 5 === 0 ? '+' : '-'; return x.slice(0, n - 3) + n; };
    tk.align('center').bold(true).text('PRUEBA DE ANCHO').bold(false).align('left').feed(1);
    for (const n of [32, 42, 48, 56]) tk.text(`Renglon de ${n} letras:`).text(regla(n)).feed(1);
    tk.text('Elija el numero mas grande que').text('salio completo en UNA sola linea.').cut();
    return imprimir(tk);
  }
  if (params.que === 'pluma') return abrirPluma('prueba', u.id);
  if (params.que === 'camara') {
    try { const buf = await snapshotIP(cfg); return { ok: true, imagen: 'data:image/jpeg;base64,' + buf.toString('base64') }; }
    catch (e) { return { ok: false, error: e.name === 'TimeoutError' ? 'La cámara no respondió (revise la IP y que esté en la misma red)' : e.message }; }
  }
  fallo('Prueba desconocida', 404);
});
/* ---------- Lectura de placas (2.5) ---------- */
ruta('POST', '/api/lpr/leer', async (req, res, { u }) => {
  requiere(u, 'ingreso_rapido', 'ingreso_manual');
  try { return { ok: true, ...(await leerPlacaAhora()) }; }
  catch (e) { return { ok: false, error: e.name === 'TimeoutError' ? 'La cámara o el servicio de placas no respondió' : e.message }; }
});
ruta('GET', '/api/lpr/pendientes', (req, res, { u }) => {
  if (!(puede(u, 'ingreso_rapido') || puede(u, 'ingreso_manual'))) return { lecturas: [] };
  return { modo: getConfig().lpr_modo, lecturas: lecturasPendientes() };
});
ruta('POST', '/api/lpr/:id/descartar', (req, res, { u, params }) => {
  requiere(u, 'ingreso_rapido', 'ingreso_manual');
  db.prepare('UPDATE lpr_lecturas SET descartada=1 WHERE id=?').run(Number(params.id));
  return { ok: true };
});
ruta('GET', '/api/lpr/info', (req, res, { u }) => {
  requiere(u, 'configuracion');
  const clave = lprClave();
  return { clave, urls: infoRed().ips.map((i) => `${i.url}/api/lpr/evento?clave=${clave}`), ultimas: db.prepare('SELECT * FROM lpr_lecturas ORDER BY id DESC LIMIT 15').all() };
});
ruta('POST', '/api/lpr/nueva-clave', (req, res, { u }) => {
  requiere(u, 'configuracion');
  db.prepare("DELETE FROM config WHERE clave='lpr_clave'").run();
  return { ok: true, clave: lprClave() };
});
// Aviso de una cámara con lectura de placas (sin sesión: se protege con la clave)
const eventoLPR = (req, res, { body, q }) => {
  const cfg = getConfig();
  if (cfg.lpr_modo !== 'camara') fallo('La lectura de placas por cámara está apagada en Configuración', 403);
  if (!q.get('clave') || q.get('clave') !== lprClave()) fallo('Clave incorrecta', 403);
  const placa = placaLPR(placaDeEvento(typeof body === 'string' ? body : body && body._crudo, q));
  if (!placa || placa.length < 3) return { ok: false, error: 'No venía la placa' };
  const id = guardarLectura({ placa, confianza: Number(q.get('confianza') || 1), region: q.get('region') || '' }, 'camara');
  return { ok: true, id, placa };
};
ruta('GET', '/api/lpr/evento', eventoLPR, { publica: true });
ruta('POST', '/api/lpr/evento', eventoLPR, { publica: true, crudo: true });
ruta('GET', '/api/impresoras', async (req, res, { u }) => {
  requiere(u, 'configuracion');
  if (!esWindows) return { impresoras: [], aviso: 'La lista de impresoras solo está disponible en Windows' };
  try {
    const out = await new Promise((resolve, reject) => execFile('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(__dirname, 'herramientas', 'listar-impresoras.ps1')],
      { timeout: 20000, windowsHide: true }, (e, so) => (e ? reject(e) : resolve(String(so || '')))));
    const lista = out.split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
    return { impresoras: [...new Set(lista)] };
  } catch (e) { return { impresoras: [], aviso: 'No se pudo leer la lista de impresoras: ' + e.message }; }
});
ruta('POST', '/api/respaldo', (req, res, { u }) => {
  requiere(u, 'configuracion');
  const dir = path.join(DATA_DIR, 'respaldos'); fs.mkdirSync(dir, { recursive: true });
  const f = path.join(dir, 'manual_' + new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-') + '.db');
  db.exec(`VACUUM INTO '${f.replace(/'/g, "''")}'`);
  bitacora(u.id, 'respaldo', f);
  return { ok: true, archivo: f };
});

/* ---------- Gastos ---------- */
ruta('GET', '/api/gastos', (req, res, { u, q }) => {
  requiere(u, 'gastos', 'reportes');
  const desde = num(q.get('desde')) || Date.now() - 31 * 864e5, hasta = num(q.get('hasta')) || Date.now() + 864e5;
  return db.prepare(`SELECT g.*, u.nombre usuario FROM gastos g LEFT JOIN usuarios u ON u.id=g.usuario_id
    WHERE g.fecha BETWEEN ? AND ? ORDER BY g.fecha DESC, g.id DESC LIMIT 5000`).all(desde, hasta);
});
function crearGasto(u, body, extra = {}) {
  const cfg = getConfig();
  const categoria = String(body.categoria || '').trim().slice(0, 40) || fallo('Elija la categoría del gasto');
  const concepto = String(body.concepto || '').trim().slice(0, 200);
  const monto = r2(num(body.monto));
  if (!(monto > 0)) fallo('Escriba el monto del gasto');
  const origen = body.origen === 'caja' ? 'caja' : 'fuera';
  let fecha = num(body.fecha) || Date.now();
  if (origen === 'caja') fecha = Date.now();
  return tx(() => {
    let turno = null, movId = null;
    if (origen === 'caja') {
      turno = requiereTurno(u);
      movId = Number(db.prepare('INSERT INTO movimientos(turno_id, usuario_id, tipo, moneda, monto, motivo, fecha) VALUES(?,?,?,?,?,?,?)')
        .run(turno.id, u.id, 'retiro', 'MXN', monto, `Gasto: ${categoria}${concepto ? ' - ' + concepto : ''}`.slice(0, 200), fecha).lastInsertRowid);
    }
    const id = Number(db.prepare('INSERT INTO gastos(fecha, categoria, concepto, monto, origen, turno_id, movimiento_id, usuario_id, creado, gasto_fijo_id) VALUES(?,?,?,?,?,?,?,?,?,?)')
      .run(fecha, categoria, concepto, monto, origen, turno?.id || null, movId, u.id, Date.now(), extra.gasto_fijo_id || null).lastInsertRowid);
    if (!cfg.gastos_categorias.includes(categoria)) setConfig({ gastos_categorias: [...cfg.gastos_categorias, categoria] });
    bitacora(u.id, 'gasto', `${categoria} ${money(monto)} ${origen === 'caja' ? '(de caja)' : ''} ${concepto}`);
    return { ok: true, id };
  });
}
ruta('POST', '/api/gastos', (req, res, { u, body }) => { requiere(u, 'gastos'); return crearGasto(u, body); });

/* ---------- Gastos fijos (renta, luz, agua, internet… que se repiten) ---------- */
const FRECUENCIAS = { semanal: 'Semanal', quincenal: 'Quincenal', mensual: 'Mensual', bimestral: 'Bimestral', anual: 'Anual' };
// Periodo actual del gasto fijo y su fecha límite de pago
function periodoFijo(g, ahora = new Date()) {
  const Y = ahora.getFullYear(), M = ahora.getMonth(), D = ahora.getDate();
  const ultimo = (y, m) => new Date(y, m + 1, 0).getDate();
  const dia = Math.max(1, Math.round(num(g.dia) || 1));
  if (g.frecuencia === 'semanal') {
    const dow = (ahora.getDay() + 6) % 7, ini = new Date(Y, M, D - dow);
    return { ini: +ini, fin: +new Date(Y, M, D - dow + 7), vence: +new Date(Y, M, D - dow + Math.min(7, dia) - 1, 23, 59), nombre: 'esta semana' };
  }
  if (g.frecuencia === 'quincenal') {
    const primera = D <= 15, ini = new Date(Y, M, primera ? 1 : 16), fin = primera ? new Date(Y, M, 16) : new Date(Y, M + 1, 1);
    const v = primera ? Math.min(dia, 15) : Math.min(15 + Math.min(dia, 15), ultimo(Y, M));
    return { ini: +ini, fin: +fin, vence: +new Date(Y, M, v, 23, 59), nombre: primera ? 'primera quincena' : 'segunda quincena' };
  }
  if (g.frecuencia === 'bimestral') {
    const ref = Math.max(1, Math.min(12, Math.round(num(g.mes_ref) || 1))) - 1, m0 = M - (((M - ref) % 2) + 2) % 2;
    const ini = new Date(Y, m0, 1), fin = new Date(Y, m0 + 2, 1);
    return { ini: +ini, fin: +fin, vence: +new Date(ini.getFullYear(), ini.getMonth(), Math.min(dia, ultimo(ini.getFullYear(), ini.getMonth())), 23, 59), nombre: 'este bimestre' };
  }
  if (g.frecuencia === 'anual') {
    const mes = Math.max(1, Math.min(12, Math.round(num(g.mes_ref) || 1))) - 1;
    return { ini: +new Date(Y, 0, 1), fin: +new Date(Y + 1, 0, 1), vence: +new Date(Y, mes, Math.min(dia, ultimo(Y, mes)), 23, 59), nombre: 'este año' };
  }
  return { ini: +new Date(Y, M, 1), fin: +new Date(Y, M + 1, 1), vence: +new Date(Y, M, Math.min(dia, ultimo(Y, M)), 23, 59), nombre: 'este mes' };
}
function listaGastosFijos() {
  const ahora = Date.now();
  return db.prepare('SELECT * FROM gastos_fijos ORDER BY activo DESC, dia, nombre').all().map((g) => {
    const p = periodoFijo(g);
    const pagado = db.prepare('SELECT id, fecha, monto FROM gastos WHERE gasto_fijo_id=? AND cancelado=0 AND fecha >= ? AND fecha < ? ORDER BY fecha DESC LIMIT 1').get(g.id, p.ini, p.fin);
    const estado = !g.activo ? 'inactivo' : pagado ? 'pagado' : ahora > p.vence ? 'vencido' : p.vence - ahora < 3 * 864e5 ? 'por vencer' : 'pendiente';
    return { ...g, frecuencia_txt: FRECUENCIAS[g.frecuencia] || g.frecuencia, periodo: p, pagado: pagado || null, estado };
  });
}
ruta('GET', '/api/gastos-fijos', (req, res, { u }) => { requiere(u, 'gastos', 'reportes'); return listaGastosFijos(); });
ruta('POST', '/api/gastos-fijos', (req, res, { u, body }) => {
  requiere(u, 'gastos');
  const nombre = String(body.nombre || '').trim().slice(0, 80) || fallo('Escriba el nombre del gasto fijo');
  const categoria = String(body.categoria || '').trim().slice(0, 40) || fallo('Elija el tipo de gasto');
  const v = [nombre, categoria, r2(Math.max(0, num(body.monto))), FRECUENCIAS[body.frecuencia] ? body.frecuencia : 'mensual', Math.max(1, Math.min(31, Math.round(num(body.dia) || 1))),
    Math.max(1, Math.min(12, Math.round(num(body.mes_ref) || 1))), body.activo === false ? 0 : 1, String(body.notas || '').slice(0, 200)];
  if (body.id) db.prepare('UPDATE gastos_fijos SET nombre=?, categoria=?, monto=?, frecuencia=?, dia=?, mes_ref=?, activo=?, notas=? WHERE id=?').run(...v, Number(body.id));
  else db.prepare('INSERT INTO gastos_fijos(nombre, categoria, monto, frecuencia, dia, mes_ref, activo, notas, creado) VALUES(?,?,?,?,?,?,?,?,?)').run(...v, Date.now());
  bitacora(u.id, 'gasto_fijo', `${nombre} ${money(v[2])} ${v[3]}`);
  return { ok: true };
});
ruta('POST', '/api/gastos-fijos/:id/pagar', (req, res, { u, params, body }) => {
  requiere(u, 'gastos');
  const g = db.prepare('SELECT * FROM gastos_fijos WHERE id=?').get(Number(params.id)) || fallo('No existe el gasto fijo', 404);
  const monto = num(body.monto) > 0 ? body.monto : g.monto;
  return crearGasto(u, { categoria: g.categoria, concepto: g.nombre + (body.concepto ? ' - ' + body.concepto : ''), monto, origen: body.origen, fecha: body.fecha }, { gasto_fijo_id: g.id });
});

/* ---------- Renta de espacios publicitarios (lonas, bardas, espectaculares) ---------- */
function listaEspacios() {
  const ahora = Date.now();
  return db.prepare('SELECT * FROM espacios_pub ORDER BY activo DESC, orden, nombre').all().map((e) => {
    const rentas = db.prepare('SELECT r.*, u.nombre usuario FROM rentas_pub r LEFT JOIN usuarios u ON u.id=r.usuario_id WHERE r.espacio_id=? AND r.cancelado=0 ORDER BY r.hasta DESC LIMIT 24').all(e.id);
    const actual = rentas.find((r) => r.desde <= ahora && r.hasta >= ahora) || null;
    const futura = rentas.find((r) => r.desde > ahora) || null;
    const ultima = rentas[0] || null;
    const vigenteHasta = ultima ? ultima.hasta : null;
    const estado = !e.activo ? 'inactivo' : actual || futura ? (vigenteHasta - ahora < 7 * 864e5 ? 'por vencer' : 'rentado') : ultima && ahora - ultima.hasta < 60 * 864e5 ? 'vencido' : 'libre';
    return { ...e, estado, actual, ultima, vigente_hasta: vigenteHasta, rentas };
  });
}
function ticketPublicidad(e, r, pago, cfg, copia) {
  const tk = encabezado(new Ticket(cfg.impresora_columnas), cfg);
  tk.bold(true).text('RECIBO RENTA DE PUBLICIDAD').bold(false);
  if (copia) tk.bold(true).text('*** COPIA CAJERO ***').bold(false);
  tk.align('left').kv('Recibo:', 'P' + folio(pago.id)).kv('Fecha:', fechaHora(pago.fecha)).line();
  tk.kv('Cliente:', r.cliente);
  if (r.telefono) tk.kv('Teléfono:', r.telefono);
  tk.kv('Espacio:', e.nombre);
  if (e.ubicacion) tk.chico(e.ubicacion + (e.medidas ? ' · ' + e.medidas : ''));
  if (r.anuncio) tk.chico('Anuncio: ' + r.anuncio);
  tk.kv('Desde:', fechaHora(r.desde).slice(0, 10)).kv('Hasta:', fechaHora(r.hasta).slice(0, 10));
  tk.line().bold(true).size(1, 2).kv('TOTAL:', money(pago.total)).size(1, 1).bold(false);
  if (pago.pesos > 0) tk.kv('Efectivo MXN:', money(pago.pesos));
  if (pago.usd > 0) tk.kv(`Dólares US$${r2(pago.usd)} (TC ${pago.tipo_cambio})`, money(pago.usd_mxn));
  if (pago.tarjeta > 0) tk.kv('Tarjeta:', money(pago.tarjeta));
  if (pago.transferencia > 0) tk.kv('Transferencia:', money(pago.transferencia));
  tk.kv('Cambio:', money(pago.cambio)).line().text('Cobró: ' + nombreUsuario(pago.usuario_id));
  pieMaxsel(tk, cfg, true).cut();
  return tk;
}
ruta('GET', '/api/publicidad', (req, res, { u }) => { requiere(u, 'publicidad', 'reportes'); return listaEspacios(); });
ruta('POST', '/api/publicidad', (req, res, { u, body }) => {
  requiere(u, 'publicidad'); if (u.rol !== 'admin' && !puede(u, 'configuracion')) requiere(u, 'productos_admin');
  const nombre = String(body.nombre || '').trim().slice(0, 60) || fallo('Escriba el nombre del espacio');
  const v = [nombre, String(body.ubicacion || '').slice(0, 120), String(body.medidas || '').slice(0, 40), r2(Math.max(0, num(body.precio_mensual))), String(body.notas || '').slice(0, 200), body.activo === false ? 0 : 1, Math.round(num(body.orden))];
  if (body.id) db.prepare('UPDATE espacios_pub SET nombre=?, ubicacion=?, medidas=?, precio_mensual=?, notas=?, activo=?, orden=? WHERE id=?').run(...v, Number(body.id));
  else db.prepare('INSERT INTO espacios_pub(nombre, ubicacion, medidas, precio_mensual, notas, activo, orden) VALUES(?,?,?,?,?,?,?)').run(...v);
  bitacora(u.id, 'espacio_publicidad', nombre);
  return { ok: true };
});
ruta('POST', '/api/publicidad/:id/cobrar', async (req, res, { u, params, body }) => {
  requiere(u, 'publicidad');
  const turno = requiereTurno(u);
  const e = db.prepare('SELECT * FROM espacios_pub WHERE id=?').get(Number(params.id)) || fallo('No existe el espacio', 404);
  const cliente = String(body.cliente || '').trim().slice(0, 80) || fallo('Escriba el nombre de quien renta');
  const desde = num(body.desde), hasta = num(body.hasta), monto = r2(num(body.monto));
  if (!(desde > 0 && hasta > desde)) fallo('Revise las fechas de la renta');
  if (!(monto > 0)) fallo('Escriba el monto de la renta');
  const choque = db.prepare('SELECT cliente, hasta FROM rentas_pub WHERE espacio_id=? AND cancelado=0 AND desde < ? AND hasta > ? AND lower(cliente) <> lower(?)').get(e.id, hasta, desde, cliente);
  if (choque && !body.forzar) fallo(`Ese espacio está rentado a ${choque.cliente} hasta el ${fechaHora(choque.hasta).slice(0, 10)}`, 409);
  const { pago, renta } = tx(() => {
    const v = validarPago(monto, body, turno.tipo_cambio);
    const pago = registrarPago(turno, u.id, 'publicidad', {}, monto, v, []);
    db.prepare("UPDATE pagos SET detalle=? WHERE id=?").run(JSON.stringify([{ nombre: 'Renta publicidad: ' + e.nombre, tipo: 'publicidad', precio: monto, cantidad: 1, importe: monto }]), pago.id);
    const id = Number(db.prepare('INSERT INTO rentas_pub(espacio_id, cliente, telefono, anuncio, desde, hasta, meses, monto, pago_id, fecha, usuario_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      .run(e.id, cliente, String(body.telefono || '').slice(0, 30), String(body.anuncio || '').slice(0, 120), desde, hasta, num(body.meses) || 1, monto, pago.id, Date.now(), u.id).lastInsertRowid);
    bitacora(u.id, 'publicidad_cobro', `${e.nombre} · ${cliente} ${money(monto)}`);
    return { pago, renta: db.prepare('SELECT * FROM rentas_pub WHERE id=?').get(id) };
  });
  const cfg = getConfig();
  const imp = await imprimirCobro(ticketPublicidad(e, renta, pago, cfg), pago, body);
  return { ok: true, pago, renta, impresion: imp, preguntar_copia: !!cfg.preguntar_copia_cajero };
});
ruta('POST', '/api/publicidad/renta/:id/reimprimir', async (req, res, { u, params, body }) => {
  requiere(u, 'publicidad', 'reimprimir');
  const r = db.prepare('SELECT * FROM rentas_pub WHERE id=?').get(Number(params.id)) || fallo('No existe', 404);
  const e = db.prepare('SELECT * FROM espacios_pub WHERE id=?').get(r.espacio_id);
  const pago = db.prepare('SELECT * FROM pagos WHERE id=?').get(r.pago_id);
  return imprimir(ticketPublicidad(e, r, pago, getConfig(), !!body.copia));
});
ruta('POST', '/api/gastos/:id/cancelar', (req, res, { u, params }) => {
  requiere(u, 'gastos');
  const g = db.prepare('SELECT * FROM gastos WHERE id=?').get(Number(params.id)) || fallo('No existe el gasto', 404);
  if (g.cancelado) fallo('El gasto ya estaba cancelado');
  if (g.origen === 'caja') {
    const t = db.prepare('SELECT * FROM turnos WHERE id=?').get(g.turno_id);
    if (!t || t.estado !== 'abierto') fallo('Ese gasto salió de un turno que ya se cerró; no se puede cancelar.');
    if (u.rol !== 'admin' && t.usuario_id !== u.id) fallo('Sólo quien abrió el turno o un administrador puede cancelarlo', 403);
    db.prepare('DELETE FROM movimientos WHERE id=?').run(g.movimiento_id);
  }
  db.prepare('UPDATE gastos SET cancelado=1 WHERE id=?').run(g.id);
  bitacora(u.id, 'gasto_cancelado', `${g.categoria} ${money(g.monto)} ${g.concepto}`);
  return { ok: true };
});

/* ---------- Fotos de la cámara ---------- */
ruta('GET', '/api/ticket/:id/foto', (req, res, { u, params }) => {
  const t = db.prepare('SELECT foto FROM tickets WHERE id=?').get(Number(params.id));
  const f = t && t.foto ? path.join(DATA_DIR, t.foto) : null;
  if (!f || !path.resolve(f).startsWith(path.resolve(DATA_DIR)) || !fs.existsSync(f)) fallo('Sin foto', 404);
  res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'private, max-age=86400' });
  res.end(fs.readFileSync(f));
  return null;
});
ruta('POST', '/api/ticket/:id/foto', (req, res, { u, params, body }) => {
  requiere(u, 'ingreso_rapido', 'ingreso_manual');
  const t = getTicket(Number(params.id)) || fallo('No existe el boleto', 404);
  const m = /^data:image\/jpeg;base64,(.+)$/.exec(String(body.imagen || ''));
  if (!m) fallo('Foto inválida');
  const buf = Buffer.from(m[1], 'base64');
  if (buf.length < 500 || buf.length > 1.5e6) fallo('Foto inválida');
  guardarFoto(t.id, buf);
  return { ok: true };
});

/* ---------- Gráficas ---------- */
function graficas(desde, hasta, desde2, hasta2) {
  const dur = hasta - desde;
  const gran = dur <= 2 * 864e5 ? 'hora' : dur <= 62 * 864e5 ? 'dia' : 'mes';
  const cubo = (f, ini) => {
    const d = new Date(f), i = new Date(ini);
    if (gran === 'hora') return Math.floor((f - ini) / 3600e3);
    if (gran === 'dia') return Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()) - new Date(i.getFullYear(), i.getMonth(), i.getDate())) / 864e5);
    return (d.getFullYear() - i.getFullYear()) * 12 + d.getMonth() - i.getMonth();
  };
  const n = cubo(hasta, desde) + 1;
  const etiqueta = (k) => {
    if (gran === 'hora') { const d = new Date(desde + k * 3600e3); return String(d.getHours()).padStart(2, '0') + ':00'; }
    if (gran === 'dia') { const d = new Date(desde); d.setDate(d.getDate() + k); return d.getDate() + '/' + (d.getMonth() + 1); }
    const d = new Date(desde); d.setDate(1); d.setMonth(d.getMonth() + k); return ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'][d.getMonth()] + ' ' + String(d.getFullYear()).slice(2);
  };
  const datos = (a, b) => {
    const pagos = db.prepare('SELECT fecha, total, monto_extras, concepto, detalle, pesos, cambio, usd_mxn, tarjeta, transferencia, mp_order_id FROM pagos WHERE cancelado=0 AND fecha BETWEEN ? AND ?').all(a, b);
    const gastos = !MOD.activo('gastos') ? [] : db.prepare('SELECT fecha, categoria, monto FROM gastos WHERE cancelado=0 AND fecha BETWEEN ? AND ?').all(a, b);
    const tickets = db.prepare('SELECT entrada, cliente FROM tickets WHERE entrada BETWEEN ? AND ?').all(a, b);
    const cortesias = db.prepare("SELECT COUNT(*) n, IFNULL(SUM(subtotal),0) m FROM tickets WHERE estado='pagado' AND cortesia_para IS NOT NULL AND salida BETWEEN ? AND ?").get(a, b);
    const serie = Array.from({ length: n }, () => ({ ingresos: 0, gastos: 0, autos: 0 }));
    const tot = { ingresos: 0, estacionamiento: 0, pensiones: 0, publicidad: 0, servicios: 0, productos: 0, gastos: 0, autos: tickets.length, cobros: pagos.length, cortesias: cortesias.n, cortesias_monto: r2(cortesias.m) };
    const pago = { 'Efectivo pesos': 0, 'Dólares': 0, 'Tarjeta': 0, 'Mercado Pago': 0, 'Transferencia': 0 };
    const servicios = {}, gcat = {}, clientes = {}, semana = Array(7).fill(0), horas = Array(24).fill(0);
    for (const p of pagos) {
      const k = cubo(p.fecha, a); if (serie[k]) serie[k].ingresos += p.total;
      tot.ingresos += p.total;
      if (p.concepto === 'pension') tot.pensiones += p.total; else if (p.concepto === 'publicidad') tot.publicidad += p.total; else tot.estacionamiento += p.total - p.monto_extras;
      for (const e of jsonArr(p.detalle)) { if (e.tipo === 'producto') tot.productos += e.importe; else tot.servicios += e.importe; const nom = String(e.nombre).replace(/ \(.*\)$/, ''); servicios[nom] = (servicios[nom] || 0) + e.importe; }
      pago['Efectivo pesos'] += Math.max(0, p.pesos - p.cambio); pago['Dólares'] += p.usd_mxn;
      if (p.mp_order_id) pago['Mercado Pago'] += p.tarjeta; else pago['Tarjeta'] += p.tarjeta;
      pago['Transferencia'] += p.transferencia || 0;
      semana[new Date(p.fecha).getDay()] += p.total;
    }
    for (const g of gastos) { const k = cubo(g.fecha, a); if (serie[k]) serie[k].gastos += g.monto; tot.gastos += g.monto; gcat[g.categoria] = (gcat[g.categoria] || 0) + g.monto; }
    for (const t of tickets) { const k = cubo(t.entrada, a); if (serie[k]) serie[k].autos++; clientes[t.cliente] = (clientes[t.cliente] || 0) + 1; horas[new Date(t.entrada).getHours()]++; }
    for (const k of Object.keys(tot)) tot[k] = r2(tot[k]);
    tot.utilidad = r2(tot.ingresos - tot.gastos);
    const lista = (o) => Object.entries(o).map(([nombre, valor]) => ({ nombre, valor: r2(valor) })).filter((x) => x.valor > 0).sort((x, y) => y.valor - x.valor);
    return { tot, serie: serie.map((x) => ({ ingresos: r2(x.ingresos), gastos: r2(x.gastos), autos: x.autos })),
      concepto: lista({ Estacionamiento: tot.estacionamiento, Pensiones: tot.pensiones, ...(MOD.activo('publicidad') ? { 'Renta de publicidad': tot.publicidad } : {}), Servicios: tot.servicios, Productos: tot.productos }),
      formaPago: lista(pago), servicios: lista(servicios), gastosCat: lista(gcat),
      clientes: lista(Object.fromEntries(Object.entries(clientes).map(([k, v]) => [{ normal: 'Normal', mesero: 'Mesero', pension: 'Pensión', frecuente: 'Frecuente', empresa: 'Empresa' }[k] || k, v]))),
      semana: semana.map(r2), horas };
  };
  const act = datos(desde, hasta), ant = datos(desde2, hasta2);
  // Últimos 12 meses contra los mismos meses del año anterior
  const meses = [];
  const hoy = new Date();
  for (let i = 11; i >= 0; i--) {
    const ini = new Date(hoy.getFullYear(), hoy.getMonth() - i, 1), fin = new Date(hoy.getFullYear(), hoy.getMonth() - i + 1, 1);
    const iniA = new Date(ini.getFullYear() - 1, ini.getMonth(), 1), finA = new Date(ini.getFullYear() - 1, ini.getMonth() + 1, 1);
    const suma = (a, b) => db.prepare('SELECT IFNULL(SUM(total),0) t FROM pagos WHERE cancelado=0 AND fecha >= ? AND fecha < ?').get(a, b).t;
    const g = !MOD.activo('gastos') ? 0 : db.prepare('SELECT IFNULL(SUM(monto),0) t FROM gastos WHERE cancelado=0 AND fecha >= ? AND fecha < ?').get(+ini, +fin).t;
    meses.push({ mes: ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'][ini.getMonth()] + ' ' + String(ini.getFullYear()).slice(2),
      ingresos: r2(suma(+ini, +fin)), anterior: r2(suma(+iniA, +finA)), gastos: r2(g) });
  }
  return { modulos: MOD.todos(), gran, etiquetas: Array.from({ length: n }, (_, k) => etiqueta(k)), actual: act, anterior: ant, meses };
}
ruta('GET', '/api/graficas', (req, res, { u, q }) => {
  requiere(u, 'reportes');
  const v = ['desde', 'hasta', 'desde2', 'hasta2'].map((k) => num(q.get(k)));
  if (!(v[0] > 0 && v[1] > v[0] && v[2] > 0 && v[3] > v[2])) fallo('Rango de fechas inválido');
  if (v[1] - v[0] > 400 * 864e5) fallo('El rango máximo para gráficas es de un año');
  return graficas(...v);
});

/* ---------- Reiniciar datos (borrar historial, productos, servicios) ---------- */
ruta('POST', '/api/reiniciar', (req, res, { u, body }) => {
  requiere(u, 'configuracion');
  const que = { ventas: !!body.ventas, productos: !!body.productos, servicios: !!body.servicios };
  if (!que.ventas && !que.productos && !que.servicios) fallo('Seleccione qué desea borrar');
  // 2.7: igual que Maxsel Tech: botón oculto y solo con la contraseña especial de Maxsel
  if (req.__funnel) fallo('Solo desde la computadora del estacionamiento.', 403);
  const fr = frenoIntentos('rei|' + ipDe(req));
  if (!String(body.password || '')) fallo('Escriba la contraseña de Maxsel');
  if (!esClaveMaxsel(body.password)) { fr.fallo(); fallo('Contraseña de Maxsel incorrecta', 403); }
  fr.ok();
  const admin = { nombre: 'Maxsel (' + u.nombre + ')' };
  if (que.ventas && db.prepare("SELECT COUNT(*) n FROM turnos WHERE estado='abierto'").get().n) fallo('Hay un turno abierto. Haga el corte (cierre el turno) antes de borrar el historial de cobros.');
  // Respaldo automático antes de borrar
  const dir = path.join(DATA_DIR, 'respaldos'); fs.mkdirSync(dir, { recursive: true });
  const f = path.join(dir, 'antes_de_reiniciar_' + new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-') + '.db');
  db.exec(`VACUUM INTO '${f.replace(/'/g, "''")}'`);
  const borrados = {};
  tx(() => {
    if (que.ventas) {
      borrados.boletos = Number(db.prepare("DELETE FROM tickets WHERE estado <> 'dentro'").run().changes);
      borrados.pagos = Number(db.prepare('DELETE FROM pagos').run().changes);
      borrados.pensiones = Number(db.prepare('DELETE FROM pension_periodos').run().changes);
      borrados.movimientos = Number(db.prepare('DELETE FROM movimientos').run().changes);
      borrados.turnos = Number(db.prepare('DELETE FROM turnos').run().changes);
      borrados.gastos = Number(db.prepare('DELETE FROM gastos').run().changes);
      borrados.rentas_publicidad = Number(db.prepare('DELETE FROM rentas_pub').run().changes);
      db.prepare('UPDATE tickets SET turno_entrada=NULL').run();
      const reiniciar = ['pagos', 'pension_periodos', 'movimientos', 'turnos', 'gastos', 'rentas_pub'];
      if (!db.prepare('SELECT COUNT(*) n FROM tickets').get().n) reiniciar.push('tickets');
      for (const t of reiniciar) db.prepare('DELETE FROM sqlite_sequence WHERE name=?').run(t);
    }
    if (que.productos) borrados.productos = Number(db.prepare("DELETE FROM productos WHERE tipo='producto'").run().changes);
    if (que.servicios) borrados.servicios = Number(db.prepare("DELETE FROM productos WHERE tipo<>'producto'").run().changes);
  });
  bitacora(u.id, 'reinicio_datos', `Autorizó ${admin.nombre}: ${Object.entries(borrados).map(([k, v]) => k + ' ' + v).join(', ')} · respaldo ${path.basename(f)}`);
  return { ok: true, borrados, respaldo: f };
});

/* ---------- Reportes ---------- */
ruta('GET', '/api/reportes', (req, res, { u, q }) => {
  requiere(u, 'reportes');
  const desde = num(q.get('desde')), hasta = num(q.get('hasta'));
  if (!(desde > 0 && hasta > desde)) fallo('Rango de fechas inválido');
  return reporte(desde, hasta);
});
ruta('POST', '/api/reportes/imprimir', async (req, res, { u, body }) => {
  requiere(u, 'reportes');
  const r = reporte(num(body.desde), num(body.hasta));
  const cfg = getConfig();
  const tk = encabezado(new Ticket(cfg.impresora_columnas), cfg);
  tk.bold(true).text('REPORTE DE VENTAS').bold(false).align('left').kv('Desde:', fechaHora(r.desde)).kv('Hasta:', fechaHora(r.hasta)).line();
  tk.kv('Estacionamiento:', money(r.resumen.estacionamiento)).kv('Pensiones:', money(r.resumen.pensiones)).kv('Productos y servicios:', money(r.resumen.productos))
    .bold(true).kv('TOTAL:', money(r.resumen.total)).bold(false);
  tk.kv('Efectivo MXN:', money(r.resumen.efectivo_mxn)).kv(`Dólares US$${r2(r.resumen.usd)}:`, money(r.resumen.usd_mxn)).kv('Tarjeta:', money(r.resumen.tarjeta));
  if (r.resumen.transferencia > 0) tk.kv('Transferencias:', money(r.resumen.transferencia));
  if (MOD.activo('publicidad') && r.resumen.publicidad > 0) tk.kv('Renta publicidad:', money(r.resumen.publicidad));
  tk.line();
  tk.kv('Entradas:', r.vehiculos.entradas).kv('Salidas:', r.vehiculos.salidas).kv('Boletos perdidos:', r.vehiculos.perdidos)
    .kv('Cortesías:', `${r.vehiculos.cortesias} (${money(r.vehiculos.cortesias_monto)})`).kv('Cancelados:', r.vehiculos.cancelados)
    .kv('Descuentos convenios:', money(r.vehiculos.descuentos)).kv('Vehículos dentro ahora:', r.dentro.length).line();
  for (const c of r.porCajero) tk.kv(c.cajero.slice(0, 24), money(c.total));
  tk.text('Impreso por: ' + u.nombre);
  pieMaxsel(tk, cfg).cut();
  return imprimir(tk);
});
ruta('GET', '/api/bitacora', (req, res, { u, q }) => {
  requiere(u, 'bitacora');
  const desde = num(q.get('desde')) || Date.now() - 7 * 864e5, hasta = num(q.get('hasta')) || Date.now();
  return db.prepare('SELECT b.*, u.nombre usuario FROM bitacora b LEFT JOIN usuarios u ON u.id=b.usuario_id WHERE b.fecha BETWEEN ? AND ? ORDER BY b.id DESC LIMIT 2000').all(desde, hasta);
});

/* ============================ SERVIDOR ============================ */
// ======================================================================
// Parking 2.6: ACTUALIZACIONES POR INTERNET (igual que Maxsel POS, Hotel y Carwash)
// Baja version.json de github.com/mlunq23/maxsel-actualizaciones (público, solo paquetes); el .zip trae los archivos del programa
// (sin node.exe, sin licencia y sin la carpeta datos). Se revisa la huella SHA-256 antes de instalar y se guarda un respaldo para regresar.
// ======================================================================
const UPD_CLAVE = 'parking', UPD_MARCA = 'public/lpr.js', DIR = __dirname;
const ahoraTxt = () => new Date().toLocaleString('es-MX');
const setCfgUpd = (k, v) => db.prepare('INSERT INTO config(clave, valor) VALUES(?, ?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor').run(k, JSON.stringify(v));
const UPD_BASE = 'https://raw.githubusercontent.com/mlunq23/maxsel-actualizaciones/main/', UPD_DIR = path.join(DATA_DIR, 'actualizacion');
const NO_TOCAR = /^(datos\/|node_modules\/|licencia\.js$|generador\/)/i;
const verCmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 4; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
function httpsBajar(url, max, redirs = 0) {
  if (process.env.MAXSEL_UPD_PRUEBA) return Promise.resolve().then(() => fs.readFileSync(path.join(process.env.MAXSEL_UPD_PRUEBA, path.basename(url.split('?')[0]))));
  return new Promise((resolve, reject) => {
    if (!/^https:\/\/raw\.githubusercontent\.com\/mlunq23\/maxsel-actualizaciones\//.test(url)) return reject(new ErrorUsuario('Dirección no permitida'));
    https.get(url, { timeout: 30000, headers: { 'Cache-Control': 'no-cache', 'User-Agent': 'MaxselParking/' + VERSION } }, (rs) => {
      if ([301, 302, 303, 307, 308].includes(rs.statusCode) && rs.headers.location && redirs < 4) { rs.resume(); return resolve(httpsBajar(new URL(rs.headers.location, url).href, max, redirs + 1)); }
      if (rs.statusCode !== 200) { rs.resume(); return reject(new ErrorUsuario('El servidor de Maxsel respondió ' + rs.statusCode)); }
      const ch = []; let n = 0;
      rs.on('data', (c) => { n += c.length; if (n > max) { rs.destroy(); reject(new ErrorUsuario('Archivo demasiado grande')); } else ch.push(c); });
      rs.on('end', () => resolve(Buffer.concat(ch))); rs.on('error', reject);
    }).on('timeout', function () { this.destroy(new ErrorUsuario('Sin respuesta (revise el internet)')); })
      .on('error', (e) => reject(e instanceof ErrorUsuario ? e : new ErrorUsuario(/ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ENETUNREACH|ECONNRESET/.test(e.code || '') ? 'Sin internet. Conecte la computadora a internet e intente de nuevo.' : e.message)));
  });
}
async function versionDisponible() {
  const j = JSON.parse((await httpsBajar(UPD_BASE + 'version.json?t=' + Date.now(), 256 * 1024)).toString('utf8'));
  const e = j[UPD_CLAVE];
  if (!e || !e.ver) { setCfgUpd('upd_disponible', ''); return { instalada: VERSION, hay: false }; }
  const hay = verCmp(e.ver, VERSION) > 0 && /^[\w.-]+\.zip$/.test(e.win || '') && /^[0-9a-f]{64}$/i.test(e.winSha || '');
  setCfgUpd('upd_disponible', hay ? String(e.ver) : '');
  return { instalada: VERSION, disponible: String(e.ver), notas: String(e.notas || ''), hay, _e: e };
}
function leerZip(buf) {
  let e = buf.length - 22; while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) throw new ErrorUsuario('El paquete de actualización está dañado');
  const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const out = [];
  for (let i = 0; i < n; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new ErrorUsuario('El paquete de actualización está dañado');
    const met = buf.readUInt16LE(p + 10), cs = buf.readUInt32LE(p + 20), nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const nom = buf.toString('utf8', p + 46, p + 46 + nl).replace(/\\/g, '/'); p += 46 + nl + xl + cl;
    if (nom.endsWith('/')) continue;
    if (buf.readUInt32LE(lo) !== 0x04034b50) throw new ErrorUsuario('El paquete de actualización está dañado');
    const s0 = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28), raw = buf.subarray(s0, s0 + cs);
    const dat = met === 0 ? raw : met === 8 ? zlib.inflateRawSync(raw) : null;
    if (!dat) throw new ErrorUsuario('Formato de paquete no soportado');
    out.push({ nom, dat });
  }
  if (!out.length) throw new ErrorUsuario('El paquete de actualización viene vacío');
  return out;
}
let actualizando = false;
async function instalarActualizacion(u) {
  if (actualizando) throw new ErrorUsuario('Ya se está instalando una actualización');
  actualizando = true;
  try {
    const v = await versionDisponible();
    if (!v.hay) throw new ErrorUsuario(`Ya tiene la versión más reciente (${VERSION}).`);
    const zip = await httpsBajar(UPD_BASE + v._e.win, 80 * 1024 * 1024);
    if (crypto.createHash('sha256').update(zip).digest('hex') !== String(v._e.winSha).toLowerCase()) throw new ErrorUsuario('El archivo descargado no es válido. Intente de nuevo.');
    const archivos = leerZip(zip).filter((f) => !NO_TOCAR.test(f.nom) && !f.nom.split('/').includes('..'));
    if (!archivos.some((f) => f.nom === 'server.js') || !archivos.some((f) => f.nom === UPD_MARCA)) throw new ErrorUsuario('El paquete de actualización no es de ' + PRODUCTO);
    const bk = path.join(UPD_DIR, 'respaldo_' + VERSION); fs.rmSync(bk, { recursive: true, force: true }); fs.mkdirSync(bk, { recursive: true });
    const raiz = path.resolve(DIR) + path.sep, escritos = [];
    try {
      for (const f of archivos) {
        const d = path.resolve(DIR, f.nom); if (!d.startsWith(raiz)) continue;
        if (fs.existsSync(d)) { fs.mkdirSync(path.dirname(path.join(bk, f.nom)), { recursive: true }); fs.copyFileSync(d, path.join(bk, f.nom)); }
        fs.mkdirSync(path.dirname(d), { recursive: true }); fs.writeFileSync(d + '.nuevo', f.dat); escritos.push(d);
      }
      // se cambian todos juntos al final; si Windows o el antivirus tienen un archivo ocupado, se reintenta
      const espera = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
      for (const d of escritos) for (let i = 0; ; i++) { try { fs.renameSync(d + '.nuevo', d); break; } catch (e) { if (i >= 20) throw e; espera(300); } }
      // se comprueba que cada archivo quedó igual al del paquete antes de reiniciar
      const h = (b) => crypto.createHash('sha256').update(b).digest('hex');
      for (const f of archivos) { const d = path.resolve(DIR, f.nom); if (d.startsWith(raiz) && h(fs.readFileSync(d)) !== h(f.dat)) throw new Error('el archivo ' + f.nom + ' no quedó bien escrito'); }
    } catch (e) {
      for (const d of escritos) { try { fs.rmSync(d + '.nuevo', { force: true }); } catch { /* nada */ } }
      for (const f of archivos) { const b = path.join(bk, f.nom); if (fs.existsSync(b)) try { fs.copyFileSync(b, path.resolve(DIR, f.nom)); } catch { /* nada */ } }
      throw new ErrorUsuario('No se pudo instalar la actualización: ' + e.message);
    }
    fs.writeFileSync(path.join(UPD_DIR, 'estado.json'), JSON.stringify({ de: VERSION, a: v.disponible, fecha: ahoraTxt(), usuario: u?.nombre || '', archivos: escritos.length }));
    console.log(`  [${ahoraTxt()}] Actualización ${VERSION} → ${v.disponible} instalada (${escritos.length} archivos). Reiniciando...`);
    setTimeout(() => process.exit(0), 1500).unref?.();
    return { ok: true, de: VERSION, a: v.disponible, archivos: escritos.length, servicio: !!process.env.MAXSEL_SERVICIO };
  } finally { actualizando = false; }
}
ruta('GET', '/api/actualizacion', async (req, res, { u }) => { requiere(u, 'configuracion'); const { _e, ...v } = await versionDisponible(); return v; });
ruta('POST', '/api/actualizacion/instalar', async (req, res, { u }) => { requiere(u, 'configuracion'); const r = await instalarActualizacion(u); bitacora(u.id, 'actualizacion', `${r.de} → ${r.a}`); return r; });
try {
  const f = path.join(UPD_DIR, 'estado.json');
  if (fs.existsSync(f)) {
    const i = JSON.parse(fs.readFileSync(f, 'utf8'));
    console.log(`  [${ahoraTxt()}] ` + (verCmp(VERSION, i.a) >= 0 ? `Se actualizó de la versión ${i.de} a la ${VERSION}` : `La actualización a la ${i.a} no quedó (sigue la ${VERSION})`));
    setCfgUpd('upd_ultima', JSON.stringify({ ...i, quedo: verCmp(VERSION, i.a) >= 0 }));
    fs.unlinkSync(f);
  }
  if (getConfig().upd_disponible && verCmp(getConfig().upd_disponible, VERSION) <= 0) setCfgUpd('upd_disponible', '');
} catch { /* nada */ }
/* ======================================================================
 * Parking 2.7 (igual que Maxsel Tech y Maxsel Abarrotes)
 *  - Recuperar contraseña olvidada (con la de un administrador o la clave de Maxsel)
 *  - Reiniciar ventas: botón oculto, solo con la contraseña especial de Maxsel
 *  - Monitoreo por internet solo con Tailscale Funnel
 * ====================================================================== */
// Clave de Maxsel: solo se guarda su huella, nunca el texto
const SUPER_HASH = '27486342e248a68acb426e94ae242e3483785c78fac2f971b602f09771629cfa';
const esClaveMaxsel = (pw) => crypto.timingSafeEqual(Buffer.from(crypto.createHash('sha256').update('maxsel-super|' + String(pw || '')).digest('hex')), Buffer.from(SUPER_HASH));
function frenoIntentos(clave) {
  const it = intentos.get(clave) || { n: 0, hasta: 0 };
  if (it.n >= 6 && it.hasta > Date.now()) fallo('Demasiados intentos. Espere 10 minutos.', 429);
  return { fallo() { const n = (it.hasta > Date.now() ? it.n : 0) + 1; intentos.set(clave, { n, hasta: Date.now() + 10 * 60e3 }); }, ok() { intentos.delete(clave); } };
}
ruta('POST', '/api/recuperar-contrasena', async (req, res, { body }) => {
  if (req.__funnel) fallo('Por seguridad, la contraseña solo se recupera desde la computadora del estacionamiento.', 403);
  const f = frenoIntentos('rec|' + ipDe(req));
  const u = db.prepare('SELECT * FROM usuarios WHERE usuario=? AND activo=1').get(String(body.usuario || '').trim().toLowerCase());
  if (!u) { f.fallo(); fallo('No existe ese usuario (o está desactivado). Revise cómo se escribe.'); }
  const nueva = String(body.nueva || '');
  if (nueva.length < 4) fallo('La contraseña nueva debe tener al menos 4 caracteres');
  const aut = String(body.autoriza || '');
  const maxsel = esClaveMaxsel(aut);
  const admin = !maxsel && db.prepare("SELECT * FROM usuarios WHERE rol='admin' AND activo=1").all().find((a) => checkPass(aut, a.pass));
  if (!maxsel && !admin) { f.fallo(); await new Promise((r) => setTimeout(r, 600)); fallo('La contraseña del administrador (o la clave de Maxsel) no es correcta', 401); }
  f.ok();
  db.prepare('UPDATE usuarios SET pass=? WHERE id=?').run(hashPass(nueva), u.id);
  for (const [t, s] of sesiones) if (s.uid === u.id) sesiones.delete(t);
  bitacora(admin ? admin.id : null, 'recuperar_contrasena', `Contraseña nueva para ${u.usuario} (autorizó: ${maxsel ? 'clave de Maxsel' : 'administrador ' + admin.usuario})`);
  return { ok: true, usuario: u.usuario };
}, { publica: true });

// Monitoreo por internet: Funnel apunta a este puerto aparte (solo en esta computadora)
const PUERTO_FUNNEL = PORT + 1;
// Desde internet: ver todo (GET) y, como en el portal, dar de alta productos y usuarios. Cobrar, cortes, configuración, etc. NO.
const FUNNEL_NO = [/^\/api\/respaldo/, /^\/api\/actualizacion/, /^\/api\/funnel/, /^\/api\/maxsel\//, /^\/api\/recuperar/, /^\/api\/licencia\/activar/, /^\/api\/pluma/, /^\/api\/lpr/];
const FUNNEL_POST = new Set(['/api/login', '/api/logout', '/api/productos', '/api/usuarios']);
const funnelPermitido = (m, p) => {
  if (FUNNEL_NO.some((r) => r.test(p))) return false;
  if (m === 'GET' || m === 'HEAD') return true;
  return m === 'POST' && FUNNEL_POST.has(p);
};
let FUNNEL = null;
// 2.7.1: el acceso por internet va con la póliza de mantenimiento (viene en la licencia, con fecha de vencimiento)
let _pol = null, _polT = 0;
function polizaHoy() { if (!_pol || Date.now() - _polT > 60000) { _pol = poliza(); _polT = Date.now(); } return _pol; }
const PAGINA_SIN_POLIZA = (m) => `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Maxsel Parking</title><body style="font-family:system-ui,sans-serif;background:#f4f1ee;margin:0"><div style="background:#cd6628;color:#fff;padding:18px 20px;font-weight:800;font-size:20px">Maxsel Parking</div><div style="max-width:440px;margin:40px auto;background:#fff;border-radius:14px;padding:24px;text-align:center;border:1px solid #e3ddd6"><h2 style="margin:0 0 8px">Portal por internet no disponible</h2><p style="color:#5a6878;line-height:1.5">${m}</p></div></body>`;
async function revisarPoliza() {
  try {
    _pol = null;
    if (polizaHoy().activa || !FUNNEL) return;
    const e = await FUNNEL.estado();
    if (e.activo) { await FUNNEL.cambiar(false); bitacora(null, 'funnel', 'Acceso por internet apagado: la póliza no está vigente'); }
  } catch { /* nada */ }
}
ruta('GET', '/api/funnel', async (req, res, { u }) => {
  if (req.__funnel || !FUNNEL) fallo('Solo desde la computadora del estacionamiento.', 403);
  if (!puede(u, 'configuracion')) fallo('Su usuario no tiene permiso de configuración', 403);
  _pol = null;
  if (!polizaHoy().activa) await revisarPoliza();
  return { ...(await FUNNEL.estado()), poliza: polizaHoy() };
});
ruta('POST', '/api/funnel', async (req, res, { body, u }) => {
  if (req.__funnel || !FUNNEL) fallo('Solo desde la computadora del estacionamiento.', 403);
  if (u.rol !== 'admin') fallo('Solo el administrador puede encender o apagar el acceso por internet', 403);
  if (body.sesion) return FUNNEL.iniciarSesion();
  _pol = null;
  if (body.activar && !polizaHoy().activa) fallo(polizaHoy().motivo, 402);
  const r = await FUNNEL.cambiar(!!body.activar);
  if (r.error) fallo(r.error);
  if (r.habilitar) return r;
  bitacora(u.id, 'funnel', 'Acceso por internet ' + (body.activar ? 'encendido' : 'apagado'));
  return { ...(await FUNNEL.estado()), poliza: polizaHoy() };
});
// Red local y la propia computadora (desde fuera solo por Funnel)
function ipPrivada(ip) {
  if (ip === '::1' || ip.startsWith('127.') || ip.startsWith('10.') || ip.startsWith('192.168.') || /^fe80:|^fd/i.test(ip)) return true;
  const m = /^172\.(\d+)\./.exec(ip); return !!(m && +m[1] >= 16 && +m[1] <= 31);
}

// Revisa sola si hay versión nueva (al minuto y medio de arrancar y cada 6 horas) para avisarle al administrador
const revisarActualizacion = () => versionDisponible().catch(() => {});
if (!process.env.MAXSEL_UPD_NO) { setTimeout(revisarActualizacion, 90 * 1000).unref(); setInterval(revisarActualizacion, 6 * 60 * 60 * 1000).unref(); }

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    // 2.7: desde fuera de la red local solo se entra por Tailscale Funnel (Configuración → Monitoreo por internet)
    if (!req.__funnel && !ipPrivada(ipDe(req))) {
      res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Desde fuera del estacionamiento entre con la dirección https://….ts.net de Configuración → Monitoreo por internet.');
    }
    if (req.__funnel && (url.pathname === '/' || url.pathname === '/index.html')) { res.writeHead(302, { Location: '/portal' }); return res.end(); }
    if (url.pathname.startsWith('/api/')) {
      const r = rutas.find((x) => x.metodo === req.method && x.re.test(url.pathname));
      if (!r) return enviarJSON(res, 404, { error: 'Ruta no encontrada' });
      if (!r.sinLicencia && !LIC.L.LICENCIA.activa) return enviarJSON(res, 402, { error: 'El sistema no tiene licencia activa. ' + (LIC.L.LICENCIA.motivo || ''), sinLicencia: true });
      const u = usuarioDe(req);
      if (!r.publica && !u) return enviarJSON(res, 401, { error: 'Sesión expirada, vuelva a entrar' });
      const mod = moduloDeRuta(url.pathname);
      if (mod && !MOD.activo(mod)) return enviarJSON(res, 403, { error: SIN_MODULO(mod), sinModulo: mod });
      const body = req.method === 'POST' ? (r.crudo ? await leerCrudo(req) : await leerBody(req)) : {};
      const out = await r.fn(req, res, { u, body, q: url.searchParams, params: url.pathname.match(r.re).groups || {} });
      if (out !== null && !res.headersSent) enviarJSON(res, 200, out);
      return;
    }
    const alias = { '/': 'index.html', '/pantalla': 'pantalla.html', '/portal': 'portal.html' };
    let f = path.normalize(path.join(PUBLIC_DIR, alias[url.pathname] || decodeURIComponent(url.pathname)));
    if (!f.startsWith(PUBLIC_DIR) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) f = path.join(PUBLIC_DIR, 'index.html');
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    fs.createReadStream(f).pipe(res);
  } catch (e) {
    if (!(e instanceof ErrorUsuario)) console.error(e);
    if (!res.headersSent) enviarJSON(res, e.code && e.code >= 400 && e.code < 600 ? e.code : 500, { error: e instanceof ErrorUsuario ? e.message : 'Error interno: ' + e.message });
  }
});
if (require.main === module) {
  FUNNEL = crearFunnel({ puertoPublico: PUERTO_FUNNEL, permitido: funnelPermitido, manejar: (req, res) => {
    const p = polizaHoy();
    if (!p.activa) { // sin póliza vigente no se entra desde internet
      if (String(req.url).startsWith('/api/')) return enviarJSON(res, 402, { error: p.motivo });
      res.writeHead(402, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }); return res.end(PAGINA_SIN_POLIZA(p.motivo));
    }
    server.emit('request', req, res);
  } });
  setTimeout(revisarPoliza, 20000).unref(); setInterval(revisarPoliza, 30 * 60 * 1000).unref();
  server.listen(PORT, '0.0.0.0', () => {
    console.log('\n  ' + PRODUCTO + ' v' + VERSION);
    console.log('  En esta computadora:  http://localhost:' + PORT);
    for (const i of infoRed().ips) if (!i.tailscale) console.log('  En la red local:      ' + i.url);
    console.log('  Código de equipo (licencia): ' + LIC.codigoEquipo());
    console.log('  Licencia: ' + (LIC.MODO_DESARROLLO ? 'MODO DESARROLLO' : LIC.L.LICENCIA.activa ? 'ACTIVA - ' + LIC.L.LICENCIA.cliente : 'NO ACTIVADA'));
    console.log('  Usuario inicial: admin / admin  (cámbielo en Usuarios)\n');
    if (process.env.NO_ABRIR !== '1' && esWindows && !process.env.MAXSEL_SERVICIO) exec('cmd /c start "" "http://localhost:' + PORT + '"');
  }).on('error', (e) => { console.error('No se pudo abrir el puerto ' + PORT + ': ' + e.message); process.exit(1); });
  respaldoDiario(); limpiarFotos();
  setInterval(() => { respaldoDiario(); limpiarFotos(); }, 3600e3).unref();
  setInterval(() => LIC.revisar(), 3600e3).unref();
}
module.exports = { calcularTarifa, cotizar, server };
