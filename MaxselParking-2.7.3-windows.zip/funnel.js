'use strict';
// Monitoreo por internet con Tailscale Funnel (igual que Maxsel Tech y Maxsel Abarrotes).
// Funnel publica https://<computadora>.<red>.ts.net SIN instalar nada en el teléfono.
// Seguridad: Funnel NO apunta al puerto normal del sistema, sino a un puerto aparte que solo
// escucha en esta computadora. Por ahí solo se puede ENTRAR y VER (solo lectura): no se puede
// cobrar, borrar, cambiar configuración, ni bajar respaldos desde internet.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

function exeTailscale() {
  if (process.platform === 'win32') {
    for (const f of [path.join(process.env.ProgramFiles || 'C:\\Program Files', 'Tailscale', 'tailscale.exe'),
      path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Tailscale', 'tailscale.exe')]) {
      try { if (fs.existsSync(f)) return f; } catch { /* sigue */ }
    }
    return '';
  }
  if (process.env.MAXSEL_TAILSCALE) return process.env.MAXSEL_TAILSCALE; // solo para pruebas
  for (const d of String(process.env.PATH || '').split(path.delimiter)) { const f = path.join(d, 'tailscale'); try { if (fs.existsSync(f)) return f; } catch { /* sigue */ } }
  return '';
}
const RE_LOGIN = /https:\/\/login\.tailscale\.com\/\S+/;
function correr(seg, args) {
  return new Promise((resolve) => {
    const exe = exeTailscale();
    if (!exe) return resolve({ out: '', error: 'Tailscale no está instalado en esta computadora.' });
    let out = '', fin = false, c;
    try { c = spawn(exe, args, { windowsHide: true }); } catch (e) { return resolve({ out: '', error: String(e.message || e) }); }
    const terminar = (r) => { if (fin) return; fin = true; clearTimeout(t); clearInterval(iv); resolve(r); };
    c.stdout.on('data', (d) => { out += d; }); c.stderr.on('data', (d) => { out += d; });
    c.on('error', (e) => terminar({ out, error: String(e.message || e) }));
    c.on('close', (code) => terminar({ out, error: code === 0 ? '' : (out.trim() || 'código ' + code) }));
    // si Tailscale pide habilitar Funnel en la cuenta, se regresa el enlace en lugar de esperar
    const iv = setInterval(() => { if (RE_LOGIN.test(out)) { try { c.kill(); } catch { /* nada */ } terminar({ out, error: '' }); } }, 300);
    const t = setTimeout(() => { try { c.kill(); } catch { /* nada */ } terminar({ out, error: 'Tailscale no respondió a tiempo.' }); }, seg * 1000);
  });
}

function crearFunnel({ puertoPublico, manejar, permitido }) {
  const srv = http.createServer((req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Referrer-Policy', 'no-referrer'); res.setHeader('X-Frame-Options', 'DENY');
    const p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
    if (!permitido(req.method, p)) {
      res.writeHead(403, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: 'Desde internet solo se puede consultar (solo lectura). Para cobrar o cambiar algo use la computadora del negocio.' }));
    }
    req.__funnel = true;
    manejar(req, res);
  });
  srv.on('error', () => { /* puerto ocupado: el monitoreo por internet no queda disponible */ });
  srv.listen(puertoPublico, '127.0.0.1');

  async function estado() {
    const exe = exeTailscale();
    const r = { instalado: !!exe, conectado: false, nombre: '', ip: '', activo: false, url: '', necesitaSesion: false };
    if (!exe) return r;
    const s = await correr(8, ['status', '--json']);
    try {
      const j = JSON.parse(s.out);
      r.conectado = j.BackendState === 'Running';
      r.necesitaSesion = j.BackendState === 'NeedsLogin' || j.BackendState === 'NoState';
      r.nombre = String((j.Self && j.Self.DNSName) || '').replace(/\.$/, '');
      r.ip = ((j.Self && j.Self.TailscaleIPs) || []).find((x) => !x.includes(':')) || '';
    } catch { /* sin datos */ }
    if (r.nombre) r.url = 'https://' + r.nombre + '/';
    if (r.conectado) {
      const f = await correr(8, ['funnel', 'status', '--json']);
      r.activo = f.out.includes('127.0.0.1:' + puertoPublico) && f.out.includes('AllowFunnel');
    }
    return r;
  }
  async function cambiar(activar) {
    const r = activar
      ? await correr(25, ['funnel', '--bg', '--https=443', 'http://127.0.0.1:' + puertoPublico])
      : await correr(15, ['funnel', '--https=443', 'off']);
    const m = r.out.match(RE_LOGIN);
    if (m) return { habilitar: m[0].replace(/[.,)]+$/, '') };
    if (r.error) {
      const l = r.error.toLowerCase();
      if (l.includes('access denied') || l.includes('operator') || l.includes('permission')) return { error: 'Tailscale no dio permiso. Reinicie la computadora y vuelva a intentar.' };
      if (l.includes('not running') || l.includes('logged out') || l.includes('needslogin')) return { error: 'Tailscale no tiene la sesión iniciada. Ábralo (icono junto al reloj) e inicie sesión.' };
      return { error: 'Tailscale respondió: ' + r.error.slice(0, 300) };
    }
    return { ok: true };
  }
  async function iniciarSesion() {
    // pide a Tailscale el enlace para iniciar sesión (se abre en el navegador de esta computadora)
    const r = await correr(20, ['login', '--timeout=15s']);
    const m = r.out.match(RE_LOGIN);
    return m ? { enlace: m[0].replace(/[.,)]+$/, '') } : (r.error ? { error: 'Abra Tailscale (icono junto al reloj) e inicie sesión.' } : { ok: true });
  }
  return { estado, cambiar, iniciarSesion };
}
module.exports = { crearFunnel, exeTailscale };
