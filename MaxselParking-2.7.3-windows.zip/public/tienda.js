/* Maxsel Parking — Venta de productos y servicios estilo punto de venta (como la tienda del hotel / Eleventa).
   Escáner o búsqueda · lista del ticket · F12 cobrar con la ventana de cobro. Sin tickets en espera ni entradas/salidas de efectivo
   (los retiros e ingresos de efectivo se hacen en "Turno y corte"). */
'use strict';
(function () {
  const CSS = `
  .pv{display:flex;flex-direction:column;gap:12px}
  .pv-top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
  .pv-top h2{margin:0}
  .pv-hoy{color:var(--muted);font-size:14px}.pv-hoy b{color:var(--ink)}
  .pv-teclas{display:flex;gap:8px;flex-wrap:wrap}
  .pk{display:inline-flex;align-items:center;gap:8px;border:1px solid var(--line);background:var(--panel);border-radius:10px;padding:8px 12px;font-weight:700;font-size:13px;cursor:pointer;color:var(--ink)}
  .pk:hover{border-color:var(--acc);color:var(--acc)}
  .pk kbd,.pv-cobrar kbd{font:600 10px/1 ui-monospace,monospace;border:1px solid currentColor;border-radius:4px;padding:2px 4px;opacity:.7}
  .pv-cuerpo{display:grid;grid-template-columns:minmax(0,1.5fr) minmax(280px,1fr);gap:14px;align-items:start}
  .pv-izq,.pv-der{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:14px}
  .pv-izq{display:flex;flex-direction:column;gap:12px;min-height:520px}
  .pv-scan{display:flex;align-items:center;gap:10px;border:2px solid var(--acc);border-radius:12px;padding:6px 12px;background:var(--panel)}
  .pv-scan input{border:0;outline:0;font-size:20px;flex:1;padding:8px 0;background:transparent}
  .pv-tabla{flex:1;overflow:auto;max-height:52vh;border:1px solid var(--line);border-radius:12px}
  .pv-tabla table{width:100%}
  .pv-tabla thead th{position:sticky;top:0;background:var(--bg);z-index:1}
  .pv-tabla tbody tr{cursor:pointer}
  .pv-tabla tbody tr.sel td{background:color-mix(in srgb,var(--acc) 12%,var(--panel))}
  .pv-tabla .x{border:0;background:transparent;font-size:20px;color:var(--bad);cursor:pointer;line-height:1}
  .pv-tabla .qty{display:inline-flex;align-items:center;gap:6px}.pv-tabla .qty button{border:1px solid var(--line);background:var(--panel);border-radius:6px;width:26px;height:26px;cursor:pointer;font-weight:800}
  .pv-vacio{text-align:center;color:var(--muted);padding:56px 10px!important}
  .pv-pie{display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:16px;border-top:2px solid var(--line);padding-top:12px;color:var(--muted);font-weight:700}
  .pv-total{text-align:right}.pv-total span{display:block;font-size:12px;text-transform:uppercase;letter-spacing:.08em}
  .pv-total b{font-size:44px;color:var(--ink);font-variant-numeric:tabular-nums;letter-spacing:-.02em}
  .pv-cobrar{border:0;background:var(--ok);color:#fff;font-size:22px;font-weight:800;border-radius:14px;padding:18px 28px;cursor:pointer;display:flex;align-items:center;gap:10px}
  .pv-cobrar:disabled{opacity:.45;cursor:not-allowed}
  .pv-prods{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;max-height:62vh;overflow:auto}
  .pv-prod{border:1px solid var(--line);background:var(--panel);border-radius:10px;padding:10px;text-align:left;cursor:pointer;display:flex;flex-direction:column;gap:2px;min-height:72px}
  .pv-prod:hover{border-color:var(--acc)}.pv-prod b{font-variant-numeric:tabular-nums}.pv-prod small{color:var(--muted)}
  .pv-prod.serv{border-style:dashed}
  @media (max-width:980px){.pv-cuerpo{grid-template-columns:1fr}}`;
  const st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);

  const T = { items: [], sel: -1, ultima: null, ventasHoy: [] };
  const prods = () => S.me.productos || [];
  const precioL = (l) => l.precio;
  const totalT = () => r2(T.items.reduce((s, l) => s + l.cantidad * precioL(l), 0));
  const artT = () => T.items.reduce((s, l) => s + l.cantidad, 0);

  window.vistaTienda = async function (main) {
    if (!can('vender_productos')) { main.innerHTML = '<p class="muted">Sin permiso para vender.</p>'; return; }
    if (sinTurno(() => ir('tienda'))) { main.innerHTML = '<div class="card"><p>Abra su turno para vender.</p></div>'; return; }
    try { T.ventasHoy = await api('/api/ventas/hoy'); } catch { T.ventasHoy = []; }
    pintar();
  };
  function pintar() {
    const main = $('#main'); if (!main || S.view !== 'tienda') return;
    if (T.sel >= T.items.length) T.sel = T.items.length - 1;
    const tot = totalT(), hoy = T.ventasHoy.filter((v) => !v.cancelado), hoyT = hoy.reduce((s, v) => s + v.total, 0);
    const K = (k, n, f) => `<button class="pk" data-k="${f}"><kbd>${k}</kbd><span>${n}</span></button>`;
    main.innerHTML = `<div class="pv">
      <div class="pv-top"><h2>🛒 Venta de productos y servicios</h2><div class="pv-hoy">${can('productos_admin') ? '<button class="btn sm" id="pvEdit" style="margin-right:.6rem">✏️ Editar productos</button>' : ''}${can('reportes') ? 'Ventas de hoy' : 'Mis ventas de hoy'} <b>${money(hoyT)}</b> · ${hoy.length} ticket(s)</div></div>
      <div class="pv-teclas">${K('F10', 'Buscar producto', 'buscar')}${K('*', 'Cantidad', 'cantidad')}${K('Supr', 'Quitar artículo', 'quitar')}${K('F11', 'Reimprimir último', 'reimprimir')}${K('F6', 'Ventas del día', 'ventas')}</div>
      <div class="pv-cuerpo">
        <div class="pv-izq"><div class="pv-scan"><span aria-hidden="true">🔎</span><input id="qP" placeholder="Escanee el código o escriba el nombre (3*código = 3 piezas)" autocomplete="off"><span class="small muted">Listo para escanear</span></div>
          <div class="pv-tabla"><table><thead><tr><th>Código</th><th>Descripción</th><th class="num">Precio</th><th class="num">Cant.</th><th class="num">Importe</th><th></th></tr></thead><tbody>
          ${T.items.map((l, i) => `<tr class="${i === T.sel ? 'sel' : ''}" data-i="${i}"><td class="mono">${esc(l.codigo || '')}</td><td><b>${esc(l.nombre)}</b>${l.nota ? `<div class="small muted">${esc(l.nota)}</div>` : ''}</td><td class="num">${money(l.precio)}</td>
            <td class="num"><span class="qty"><button data-q="${i}" data-d="-1" aria-label="Quitar uno">−</button><b>${l.cantidad}</b><button data-q="${i}" data-d="1" aria-label="Agregar uno">+</button></span></td><td class="num"><b>${money(l.cantidad * l.precio)}</b></td>
            <td><button class="x" data-x="${i}" aria-label="Quitar">×</button></td></tr>`).join('') || '<tr><td colspan="6" class="pv-vacio">Escanee un producto o tóquelo en la lista de la derecha</td></tr>'}</tbody></table></div>
          <div class="pv-pie"><div><span>${artT()} artículo(s)</span></div><div class="pv-total"><span>Total</span><b>${money(tot)}</b></div>
            <button class="pv-cobrar" id="pvC" ${T.items.length ? '' : 'disabled'}><kbd>F12</kbd> Cobrar</button></div></div>
        <div class="pv-der"><div class="pv-prods">${prods().map((p) => `<button class="pv-prod ${p.tipo !== 'producto' ? 'serv' : ''}" data-p="${p.id}"><span>${esc(p.nombre)}</span><b>${p.precio_libre ? 'precio libre' : money(p.precio)}</b><small>${p.tipo === 'producto' ? 'Producto' : 'Servicio'}${p.codigo ? ' · ' + esc(p.codigo) : ''}</small></button>`).join('') || '<p class="muted">Sin productos. Agréguelos en "Productos y servicios".</p>'}</div></div></div></div>`;
    $$('[data-k]', main).forEach((b) => (b.onclick = () => ({ buscar: () => buscar(), cantidad, quitar, reimprimir, ventas })[b.dataset.k]()));
    $$('[data-i]', main).forEach((tr) => (tr.onclick = () => { T.sel = Number(tr.dataset.i); pintar(); }));
    $$('[data-q]', main).forEach((b) => (b.onclick = (e) => { e.stopPropagation(); cant(Number(b.dataset.q), Number(b.dataset.d)); }));
    $$('[data-x]', main).forEach((b) => (b.onclick = (e) => { e.stopPropagation(); T.sel = Number(b.dataset.x); quitar(); }));
    $$('[data-p]', main).forEach((b) => (b.onclick = () => agregar(Number(b.dataset.p))));
    $('#pvC').onclick = cobrar;
    $('#pvEdit') && ($('#pvEdit').onclick = () => ir('productos'));
    const qp = $('#qP');
    qp.onkeydown = (e) => {
      if (e.key === 'Enter') { e.preventDefault(); escaneo(qp.value); qp.value = ''; return; }
      if (!qp.value && (e.key === '+' || e.key === '-')) { e.preventDefault(); if (T.sel >= 0) cant(T.sel, e.key === '+' ? 1 : -1); return; }
      if (!qp.value && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) { e.preventDefault(); if (T.items.length) { T.sel = Math.max(0, Math.min(T.items.length - 1, T.sel + (e.key === 'ArrowUp' ? -1 : 1))); pintar(); } }
    };
    if (!$('#modals').children.length) qp.focus();
    actualizarPantalla();
  }
  function actualizarPantalla(recibido, cambio) {
    if (!T.items.length) return pantalla('espera');
    pantalla('venta', { extras: T.items.map((l) => ({ nombre: l.nombre, cantidad: l.cantidad, importe: l.cantidad * l.precio })), total: totalT(), recibido, cambio });
  }
  function beep(f = 880) { try { const a = beep.a || (beep.a = new AudioContext()), o = a.createOscillator(), g = a.createGain(); g.gain.value = 0.08; o.frequency.value = f; o.connect(g); g.connect(a.destination); o.start(); o.stop(a.currentTime + 0.08); } catch { /* sin sonido */ } }
  function escaneo(t) {
    t = String(t || '').trim(); if (!t) return;
    let c = 1; const m = t.match(/^(\d+(?:\.\d+)?)\s*[*xX]\s*(.+)$/); if (m) { c = parseFloat(m[1]) || 1; t = m[2].trim(); }
    const p = prods().find((x) => x.codigo && x.codigo === t);
    if (p) return agregar(p.id, c);
    const l = prods().filter((x) => x.nombre.toLowerCase().includes(t.toLowerCase()));
    if (l.length === 1) return agregar(l[0].id, c);
    if (l.length > 1) return buscar(t);
    toast('No hay producto con el código ' + t, 'warn'); beep(220);
  }
  async function agregar(id, c = 1) {
    const p = prods().find((x) => x.id === id); if (!p) return;
    if (p.precio_libre) {
      const r = await pedirImporte(p); if (!r) return $('#qP')?.focus();
      T.items.push({ producto_id: id, nombre: p.nombre, codigo: p.codigo, precio: r.precio, nota: r.nota, cantidad: c }); T.sel = T.items.length - 1;
    } else {
      const i = T.items.findIndex((x) => x.producto_id === id && !x.nota);
      if (i >= 0) { T.items[i].cantidad = +(T.items[i].cantidad + c).toFixed(3); T.sel = i; }
      else { T.items.push({ producto_id: id, nombre: p.nombre, codigo: p.codigo, precio: p.precio, cantidad: c }); T.sel = T.items.length - 1; }
    }
    beep(); pintar();
  }
  function cant(i, d) { const l = T.items[i]; if (!l) return; l.cantidad = +(l.cantidad + d).toFixed(3); if (l.cantidad <= 0) T.items.splice(i, 1); pintar(); }
  function quitar() { if (T.sel < 0 || !T.items[T.sel]) return toast('Seleccione el artículo a quitar', 'warn'); T.items.splice(T.sel, 1); T.sel = Math.min(T.sel, T.items.length - 1); pintar(); }
  function cantidad() {
    if (T.sel < 0 || !T.items[T.sel]) return toast('Seleccione un artículo del ticket', 'warn');
    const l = T.items[T.sel];
    const m = modal(`<div class="hd"><h3>Cantidad</h3><button class="btn sm" data-close>✕</button></div><form class="bd grid"><label class="f">${esc(l.nombre)}<input name="c" type="number" min="0" step="any" value="${l.cantidad}" autofocus></label>
      <div class="ft" style="padding:0;border:0;position:static"><button type="button" class="btn" data-close>Cancelar</button><button class="btn pri">Aceptar</button></div></form>`);
    $('form', m.el).onsubmit = (e) => { e.preventDefault(); const c = parseFloat(e.target.c.value); if (!(c > 0)) T.items.splice(T.sel, 1); else l.cantidad = c; m.close(); pintar(); };
  }
  function buscar(q = '') {
    const m = modal(`<div class="hd"><h3>Buscar producto</h3><button class="btn sm" data-close>✕</button></div><div class="bd"><input id="bqP" placeholder="Nombre o código" value="${esc(q)}" autocomplete="off">
      <div class="tbl-wrap" style="max-height:420px;margin-top:10px"><table><thead><tr><th>Código</th><th>Producto</th><th class="num">Precio</th></tr></thead><tbody id="bqL"></tbody></table></div></div>`, { cls: 'wide' });
    const pint = () => {
      const t = $('#bqP', m.el).value.toLowerCase(), l = prods().filter((p) => (p.nombre + ' ' + (p.codigo || '')).toLowerCase().includes(t)).slice(0, 100);
      $('#bqL', m.el).innerHTML = l.map((p) => `<tr class="click" data-id="${p.id}" style="cursor:pointer"><td class="mono">${esc(p.codigo || '')}</td><td><b>${esc(p.nombre)}</b></td><td class="num">${p.precio_libre ? 'libre' : money(p.precio)}</td></tr>`).join('') || '<tr><td colspan="3" class="muted">No se encontró.</td></tr>';
      $$('#bqL tr[data-id]', m.el).forEach((tr) => (tr.onclick = () => { m.close(); agregar(Number(tr.dataset.id)); }));
    };
    $('#bqP', m.el).oninput = pint; pint();
    $('#bqP', m.el).onkeydown = (e) => { if (e.key === 'Enter') { const f = $('#bqL tr[data-id]', m.el); if (f) { m.close(); agregar(Number(f.dataset.id)); } } };
  }
  async function reimprimir() {
    if (!T.ultima) return toast('Aún no hay ventas en esta sesión', 'warn');
    try { manejarImpresion(await post(`/api/venta/${T.ultima}/reimprimir`, {}), 'Ticket'); } catch (e) { errToast(e); }
  }
  function ventas() {
    const v = T.ventasHoy;
    modal(`<div class="hd"><h3>${can('reportes') ? 'Ventas de hoy' : 'Mis ventas de hoy'}</h3><button class="btn sm" data-close>✕</button></div><div class="bd tbl-wrap" style="max-height:460px">
      <table><thead><tr><th>Folio</th><th>Hora</th><th>Productos</th><th>Pago</th><th>Cajero</th><th class="num">Total</th><th></th></tr></thead><tbody>
      ${v.map((x) => `<tr style="${x.cancelado ? 'opacity:.5;text-decoration:line-through' : ''}"><td class="mono">V${folio(x.id)}</td><td>${fdt(x.fecha)}</td><td class="small">${jsonArr(x.detalle).map((i) => i.cantidad + ' ' + esc(i.nombre)).join(', ')}</td><td class="small">${esc(recibidoTxt(x))}</td><td class="small">${esc(x.cajero || '')}</td><td class="num">${money(x.total)}</td>
        <td>${can('reimprimir') ? `<button class="btn sm" data-r="${x.id}">🖨️</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="7" class="muted">Aún no hay ventas hoy.</td></tr>'}</tbody></table></div>`, { cls: 'wide' });
    $$('[data-r]').forEach((b) => (b.onclick = async () => { try { manejarImpresion(await post(`/api/venta/${b.dataset.r}/reimprimir`, {}), 'Ticket'); } catch (e) { errToast(e); } }));
  }
  async function cobrar() {
    if (!T.items.length) return toast('El ticket está vacío', 'warn');
    const tot = totalT();
    const cobro = await ventanaCobro({ total: tot, titulo: 'Cobrar venta', articulos: artT(), referencia: 'VENTA', onCambio: (v) => actualizarPantalla(v.pagado, v.dif >= 0 ? v.dif : null) });
    if (!cobro) { $('#qP')?.focus(); return; }
    try {
      const r = await post('/api/venta', { items: T.items.map((l) => ({ producto_id: l.producto_id, cantidad: l.cantidad, precio: l.precio, nota: l.nota })), ...cobro.valores, no_imprimir: !cobro.imprimir });
      T.ultima = r.pago.id; T.items = []; T.sel = -1;
      pantalla('pagado', { extras: jsonArr(r.pago.detalle), total: r.pago.total, recibido: cobro.recibido, cambio: r.pago.cambio }, 12000);
      try { T.ventasHoy = await api('/api/ventas/hoy'); } catch { /* */ }
      pintar();
      trasCobro(r, cobro, 'Ticket de venta', () => post(`/api/venta/${r.pago.id}/reimprimir`, { copia: true }));
    } catch (e) { errToast(e); }
  }
  // Venta rápida de un solo servicio (botones de la pantalla de Caja: baño, lavado, lona…)
  window.ventaRapida = async function (id) {
    if (!can('vender_productos') || sinTurno(() => ventaRapida(id))) return;
    const p = prods().find((x) => x.id === id); if (!p) return;
    let item = { producto_id: id, cantidad: 1, precio: p.precio };
    if (p.precio_libre) { const r = await pedirImporte(p); if (!r) return; item = { ...item, ...r }; }
    const cobro = await ventanaCobro({ total: item.precio, titulo: 'Cobrar ' + p.nombre, detalle: item.nota || '', referencia: 'VENTA',
      onCambio: (v) => pantalla('venta', { extras: [{ nombre: p.nombre, cantidad: 1, importe: item.precio }], total: item.precio, recibido: v.pagado, cambio: v.dif >= 0 ? v.dif : null }) });
    if (!cobro) { pantalla('espera'); return; }
    try {
      const r = await post('/api/venta', { items: [item], ...cobro.valores, no_imprimir: !cobro.imprimir });
      pantalla('pagado', { extras: jsonArr(r.pago.detalle), total: r.pago.total, recibido: cobro.recibido, cambio: r.pago.cambio }, 12000);
      trasCobro(r, cobro, 'Ticket de venta', () => post(`/api/venta/${r.pago.id}/reimprimir`, { copia: true }));
    } catch (e) { errToast(e); }
  };
  document.addEventListener('keydown', (e) => {
    if (!S.me || S.view !== 'tienda' || !$('.pv') || $('#modals').children.length) return;
    const k = e.key, acc = { F12: cobrar, F10: () => buscar(), F11: reimprimir, F6: ventas }[k];
    if (acc) { e.preventDefault(); e.stopImmediatePropagation(); acc(); return; }
    const qp = $('#qP');
    if (k === 'Delete' && !qp.value) { e.preventDefault(); quitar(); return; }
    if (k === '*' && !qp.value) { e.preventDefault(); cantidad(); return; }
    if (document.activeElement !== qp && k.length === 1 && !e.ctrlKey && !e.altKey) qp.focus(); // el escáner siempre escribe en la búsqueda
  }, true);
})();
