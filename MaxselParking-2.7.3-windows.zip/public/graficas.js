/* Maxsel Parking - gráficas sin librerías (SVG). Las usa la caja (Reportes > Gráficas) y el portal. */
(function () {
  const CSS = `
  .g-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px;margin-bottom:12px}
  .g-kpi{background:#fff;border:1px solid #e3e6ea;border-radius:12px;padding:12px 14px}
  .g-kpi-l{font-size:.78rem;font-weight:700;color:#52514e;text-transform:uppercase;letter-spacing:.03em}
  .g-kpi-v{font-size:1.65rem;font-weight:800;color:#0b0b0b;margin:.15rem 0;font-variant-numeric:tabular-nums}
  .g-kpi-c{font-size:.82rem;font-weight:700}.g-kpi-c.good{color:#12814b}.g-kpi-c.bad{color:#cc2f2b}.g-kpi-c.neu{color:#52514e}
  .g-card{background:#fff;border:1px solid #e3e6ea;border-radius:12px;padding:14px;margin-bottom:12px}
  .g-card h3{margin:0 0 .6rem;font-size:1rem;color:#0b0b0b}
  .g-grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(330px,1fr));gap:12px}.g-grid2 .g-card{margin-bottom:0}
  .g-grid2+.g-card{margin-top:12px}
  .g-mut{color:#6b6a65;font-weight:400;font-size:.85em}
  .g-scroll{overflow-x:auto;-webkit-overflow-scrolling:touch}
  .g-scroll svg{display:block;width:100%;height:auto}
  .g-grid{stroke:#ecebe6;stroke-width:1}.g-base{stroke:#9d9c96;stroke-width:1}
  .g-ax{font-size:11px;fill:#6b6a65;font-family:system-ui,Segoe UI,Arial,sans-serif}
  .g-cross{stroke:#9d9c96;stroke-width:1;opacity:0}.g-dot{opacity:0}.g-col:hover .g-cross,.g-col:hover .g-dot{opacity:1}
  .g-hit:hover{fill:rgba(42,120,214,.06)}.g-slice:hover{opacity:.85}
  .g-ley{display:flex;gap:14px;flex-wrap:wrap;font-size:.82rem;color:#52514e;margin-bottom:4px}
  .g-ley i,.g-pl i,.g-tip i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:5px;vertical-align:-1px}
  .g-ley i.dash{width:14px;height:0;border-top:2px dashed;border-radius:0;vertical-align:3px}
  .g-pie{display:flex;align-items:center;gap:14px;flex-wrap:wrap}.g-pie svg{flex:none}
  .g-pleg{flex:1;min-width:170px;display:grid;gap:5px;font-size:.88rem}
  .g-pl{display:grid;grid-template-columns:auto 1fr auto auto;gap:6px;align-items:center}.g-pl b{font-variant-numeric:tabular-nums;color:#0b0b0b}
  .g-pl .g-mut{min-width:42px;text-align:right}.g-pn{color:#0b0b0b;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .g-c1{font-size:11px;fill:#6b6a65;font-family:system-ui,Segoe UI,Arial,sans-serif}.g-c2{font-size:15px;font-weight:800;fill:#0b0b0b;font-family:system-ui,Segoe UI,Arial,sans-serif}
  .g-tabla{border-collapse:collapse;font-size:.82rem;margin-top:8px;white-space:nowrap}.g-tabla td,.g-tabla th{padding:5px 8px;border-bottom:1px solid #ecebe6;text-align:right}
  .g-tabla td:first-child,.g-tabla th:first-child{text-align:left;position:sticky;left:0;background:#fff}
  .g-tip{position:fixed;z-index:9999;display:none;pointer-events:none;background:#fff;color:#0b0b0b;border:1px solid #d9d8d2;border-radius:8px;padding:7px 10px;font-size:.84rem;line-height:1.45;box-shadow:0 6px 20px rgba(0,0,0,.14);max-width:260px}
  @media print{.g-card,.g-kpi{break-inside:avoid}}`;
  const st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
  const SERIE = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#6250d6', '#e34948'];
  const GRIS = '#b9b8b1';
  const movil = () => window.innerWidth < 700;
  const e = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const dinero = (n) => '$' + Number(n || 0).toLocaleString('es-MX', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  const corto = (n) => { n = Number(n || 0); const a = Math.abs(n); return a >= 1e6 ? (n / 1e6).toFixed(1).replace('.0', '') + 'M' : a >= 1e3 ? (n / 1e3).toFixed(a >= 1e4 ? 0 : 1).replace('.0', '') + 'k' : String(Math.round(n)); };

  // Tooltip único para todas las gráficas (atributo data-tip en cada marca)
  let tip = null;
  function asegurarTip() {
    if (tip) return;
    tip = document.createElement('div');
    tip.className = 'g-tip';
    document.body.appendChild(tip);
    const mover = (ev) => {
      const t = ev.target.closest && ev.target.closest('[data-tip]');
      if (!t) { tip.style.display = 'none'; return; }
      tip.innerHTML = t.getAttribute('data-tip');
      tip.style.display = 'block';
      const w = tip.offsetWidth, h = tip.offsetHeight;
      let x = ev.clientX + 14, y = ev.clientY - h - 10;
      if (x + w > innerWidth - 8) x = ev.clientX - w - 14;
      if (y < 8) y = ev.clientY + 16;
      tip.style.left = x + 'px'; tip.style.top = y + 'px';
    };
    document.addEventListener('mousemove', mover);
    document.addEventListener('touchstart', (ev) => mover(ev.touches[0] ? Object.assign({}, ev.touches[0], { target: ev.target }) : ev), { passive: true });
    document.addEventListener('scroll', () => { tip.style.display = 'none'; }, true);
  }

  // Escala "bonita" para el eje Y
  function escala(max) {
    if (!(max > 0)) return { max: 1, pasos: [0, 1] };
    const bruto = max / 4, mag = Math.pow(10, Math.floor(Math.log10(bruto)));
    const paso = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((p) => p >= bruto);
    const tope = Math.ceil(max / paso) * paso;
    const pasos = []; for (let v = 0; v <= tope + 1e-9; v += paso) pasos.push(v);
    return { max: tope, pasos };
  }

  // Variación porcentual
  function variacion(act, ant) {
    if (!ant && !act) return { txt: 'sin cambio', cls: 'neu', flecha: '•' };
    if (!ant) return { txt: 'nuevo', cls: 'up', flecha: '▲' };
    const p = ((act - ant) / Math.abs(ant)) * 100;
    if (Math.abs(p) < 0.5) return { txt: 'igual', cls: 'neu', flecha: '•' };
    return { txt: (p > 0 ? '+' : '') + p.toFixed(Math.abs(p) < 10 ? 1 : 0) + '%', cls: p > 0 ? 'up' : 'down', flecha: p > 0 ? '▲' : '▼' };
  }

  // KPI con comparación contra el periodo anterior. menosEsMejor: para gastos
  function kpi(titulo, act, ant, { fmt = dinero, menosEsMejor = false, etiquetaAnt = 'periodo anterior' } = {}) {
    const v = variacion(act, ant);
    const bueno = v.cls === 'neu' ? 'neu' : (v.cls === 'up') !== menosEsMejor ? 'good' : 'bad';
    return `<div class="g-kpi"><div class="g-kpi-l">${e(titulo)}</div><div class="g-kpi-v">${fmt(act)}</div>
      <div class="g-kpi-c ${bueno}"><span aria-hidden="true">${v.flecha}</span> ${e(v.txt)} <span class="g-mut">vs ${e(etiquetaAnt)} (${fmt(ant)})</span></div></div>`;
  }

  // Barras agrupadas: periodo actual vs anterior (una sola escala)
  function barrasComp(etiquetas, actual, anterior, { fmt = dinero, nombres = ['Actual', 'Anterior'], alto = 240, ancho = movil() ? 360 : 1000 } = {}) {
    asegurarTip();
    const n = etiquetas.length;
    if (!n) return '<p class="g-mut">Sin datos.</p>';
    const W = Math.max(ancho, n * (anterior ? 46 : 32)), H = alto, L = 46, R = 10, T = 14, B = 30;
    const { max, pasos } = escala(Math.max(...actual, ...(anterior || [0])));
    const y = (v) => T + (H - T - B) * (1 - v / max);
    const banda = (W - L - R) / n, gap = 2;
    const bw = anterior ? Math.min(18, (banda * 0.78 - gap) / 2) : Math.min(26, banda * 0.66);
    const cada = Math.ceil(n / Math.floor((W - L - R) / 44));
    let s = pasos.map((p) => `<line x1="${L}" x2="${W - R}" y1="${y(p)}" y2="${y(p)}" class="g-grid"/><text x="${L - 6}" y="${y(p) + 4}" text-anchor="end" class="g-ax">${corto(p)}</text>`).join('');
    etiquetas.forEach((et, i) => {
      const cx = L + banda * i + banda / 2;
      const grupo = anterior ? bw * 2 + gap : bw, x0 = cx - grupo / 2;
      const barra = (x, v, color, nombre) => {
        const h = Math.max(0, y(0) - y(v)), r = Math.min(4, bw / 2, h);
        const d = h <= 0 ? '' : `M${x},${y(0)} V${y(v) + r} Q${x},${y(v)} ${x + r},${y(v)} H${x + bw - r} Q${x + bw},${y(v)} ${x + bw},${y(v) + r} V${y(0)} Z`;
        return d ? `<path d="${d}" fill="${color}"/>` : '';
      };
      const tipTxt = `<b>${e(et)}</b><br><i style="background:${SERIE[0]}"></i>${e(nombres[0])}: <b>${fmt(actual[i])}</b>` + (anterior ? `<br><i style="background:${GRIS}"></i>${e(nombres[1])}: <b>${fmt(anterior[i])}</b>` : '');
      s += `<g>${anterior ? barra(x0, anterior[i], GRIS) : ''}${barra(anterior ? x0 + bw + gap : x0, actual[i], SERIE[0])}
        <rect x="${cx - banda / 2}" y="${T}" width="${banda}" height="${H - T - B}" fill="transparent" data-tip="${e(tipTxt)}" class="g-hit"/></g>`;
      if (i % cada === 0) s += `<text x="${cx}" y="${H - 10}" text-anchor="middle" class="g-ax">${e(et)}</text>`;
    });
    s += `<line x1="${L}" x2="${W - R}" y1="${y(0)}" y2="${y(0)}" class="g-base"/>`;
    const ley = anterior ? `<div class="g-ley"><span><i style="background:${GRIS}"></i>${e(nombres[1])}</span><span><i style="background:${SERIE[0]}"></i>${e(nombres[0])}</span></div>` : '';
    return `${ley}<div class="g-scroll"><svg viewBox="0 0 ${W} ${H}" style="max-width:${W}px;min-width:${movil() ? W : Math.min(W, Math.max(300, n * 30))}px" role="img">${s}</svg></div>`;
  }

  // Línea: actual (sólida) vs anterior (gris punteada), con cruz de lectura al pasar el mouse
  function lineaComp(etiquetas, actual, anterior, { fmt = dinero, nombres = ['Actual', 'Anterior'], alto = 240, ancho = movil() ? 360 : 1000 } = {}) {
    asegurarTip();
    const n = etiquetas.length;
    if (n < 2) return barrasComp(etiquetas, actual, anterior, { fmt, nombres, alto, ancho });
    const W = Math.max(ancho, n * 22), H = alto, L = 46, R = 14, T = 14, B = 30;
    const { max, pasos } = escala(Math.max(...actual, ...(anterior || [0])));
    const x = (i) => L + ((W - L - R) * i) / (n - 1), y = (v) => T + (H - T - B) * (1 - v / max);
    const camino = (arr) => arr.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
    const cada = Math.ceil(n / Math.floor((W - L - R) / 44));
    let s = pasos.map((p) => `<line x1="${L}" x2="${W - R}" y1="${y(p)}" y2="${y(p)}" class="g-grid"/><text x="${L - 6}" y="${y(p) + 4}" text-anchor="end" class="g-ax">${corto(p)}</text>`).join('');
    s += `<line x1="${L}" x2="${W - R}" y1="${y(0)}" y2="${y(0)}" class="g-base"/>`;
    if (anterior) s += `<path d="${camino(anterior)}" fill="none" stroke="${GRIS}" stroke-width="2" stroke-dasharray="5 4" stroke-linejoin="round"/>`;
    s += `<path d="${camino(actual)}" fill="none" stroke="${SERIE[0]}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>`;
    const ult = n - 1;
    s += `<circle cx="${x(ult)}" cy="${y(actual[ult])}" r="4" fill="${SERIE[0]}" stroke="#fff" stroke-width="2"/>`;
    etiquetas.forEach((et, i) => {
      const w = (W - L - R) / (n - 1);
      const tipTxt = `<b>${e(et)}</b><br><i style="background:${SERIE[0]}"></i>${e(nombres[0])}: <b>${fmt(actual[i])}</b>` + (anterior ? `<br><i style="background:${GRIS}"></i>${e(nombres[1])}: <b>${fmt(anterior[i])}</b>` : '');
      s += `<g class="g-col"><line x1="${x(i)}" x2="${x(i)}" y1="${T}" y2="${y(0)}" class="g-cross"/><circle cx="${x(i)}" cy="${y(actual[i])}" r="4" fill="${SERIE[0]}" stroke="#fff" stroke-width="2" class="g-dot"/>
        <rect x="${x(i) - w / 2}" y="${T}" width="${w}" height="${H - T - B}" fill="transparent" data-tip="${e(tipTxt)}"/></g>`;
      if (i % cada === 0) s += `<text x="${x(i)}" y="${H - 10}" text-anchor="middle" class="g-ax">${e(et)}</text>`;
    });
    const ley = anterior ? `<div class="g-ley"><span><i style="background:${SERIE[0]}"></i>${e(nombres[0])}</span><span><i class="dash" style="border-color:${GRIS}"></i>${e(nombres[1])}</span></div>` : '';
    return `${ley}<div class="g-scroll"><svg viewBox="0 0 ${W} ${H}" style="max-width:${W}px;min-width:${movil() ? W : Math.min(W, Math.max(300, n * 30))}px" role="img">${s}</svg></div>`;
  }

  // Pastel (dona) con leyenda de valores y porcentajes. Más de 6 partes se juntan en "Otros".
  function pastel(lista, { fmt = dinero, centro = 'Total' } = {}) {
    asegurarTip();
    let datos = (lista || []).filter((d) => d.valor > 0);
    if (!datos.length) return '<p class="g-mut">Sin datos en el periodo.</p>';
    if (datos.length > 6) { const resto = datos.slice(5).reduce((t, d) => t + d.valor, 0); datos = datos.slice(0, 5).concat([{ nombre: 'Otros', valor: resto }]); }
    const total = datos.reduce((t, d) => t + d.valor, 0);
    const R = 80, r = 50, C = 90;
    let ang = -Math.PI / 2, s = '';
    datos.forEach((d, i) => {
      const a = (d.valor / total) * Math.PI * 2, color = SERIE[i % SERIE.length];
      const pct = ((d.valor / total) * 100).toFixed(1).replace('.0', '');
      const tipTxt = `<i style="background:${color}"></i><b>${e(d.nombre)}</b><br>${fmt(d.valor)} · ${pct}%`;
      if (datos.length === 1) {
        s += `<circle cx="${C}" cy="${C}" r="${(R + r) / 2}" fill="none" stroke="${color}" stroke-width="${R - r}" data-tip="${e(tipTxt)}"/>`;
      } else {
        const a0 = ang, a1 = ang + a, grande = a > Math.PI ? 1 : 0;
        const p = (rad, t) => `${(C + rad * Math.cos(t)).toFixed(2)},${(C + rad * Math.sin(t)).toFixed(2)}`;
        s += `<path d="M${p(R, a0)} A${R},${R} 0 ${grande} 1 ${p(R, a1)} L${p(r, a1)} A${r},${r} 0 ${grande} 0 ${p(r, a0)} Z" fill="${color}" stroke="#fff" stroke-width="2" stroke-linejoin="round" data-tip="${e(tipTxt)}" class="g-slice"/>`;
      }
      ang += a;
    });
    s += `<text x="${C}" y="${C - 4}" text-anchor="middle" class="g-c1">${e(centro)}</text><text x="${C}" y="${C + 16}" text-anchor="middle" class="g-c2">${e(fmt(total))}</text>`;
    const ley = datos.map((d, i) => `<div class="g-pl"><i style="background:${SERIE[i % SERIE.length]}"></i><span class="g-pn">${e(d.nombre)}</span><b>${fmt(d.valor)}</b><span class="g-mut">${((d.valor / total) * 100).toFixed(1).replace('.0', '')}%</span></div>`).join('');
    return `<div class="g-pie"><svg viewBox="0 0 ${C * 2} ${C * 2}" width="180" height="180" role="img">${s}</svg><div class="g-pleg">${ley}</div></div>`;
  }

  // Rango del periodo anterior equivalente (para comparar)
  function rangoAnterior(periodo, desde, hasta) {
    const d = new Date(desde), h = new Date(hasta);
    const mover = (f, meses) => { const x = new Date(f); const dia = x.getDate(); x.setDate(1); x.setMonth(x.getMonth() + meses); const fin = new Date(x.getFullYear(), x.getMonth() + 1, 0).getDate(); x.setDate(Math.min(dia, fin)); return x.getTime(); };
    const meses = { mes: 1, trimestre: 3, semestre: 6, anio: 12 }[periodo];
    if (meses) return [mover(d, -meses), mover(h, -meses)];
    if (periodo === 'quincena') { return d.getDate() === 1 ? [mover(d, -1) + 15 * 864e5, mover(h, -1) + 15 * 864e5] : [d.getTime() - 15 * 864e5, h.getTime() - 15 * 864e5]; }
    const dur = hasta - desde + 1;
    return [desde - dur, hasta - dur];
  }
  const nombreAnterior = { hoy: 'ayer', ayer: 'antier', semana: 'semana pasada', quincena: 'quincena anterior', mes: 'mes pasado', trimestre: 'trimestre anterior', semestre: 'semestre anterior', anio: 'año pasado', rango: 'periodo anterior' };
  const DIAS = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

  // Tablero completo de gráficas a partir de /api/graficas
  function tablero(g, periodo) {
    const A = g.actual, P = g.anterior, ant = nombreAnterior[periodo] || 'periodo anterior';
    const tituloSerie = g.gran === 'hora' ? 'por hora' : g.gran === 'dia' ? 'por día' : 'por mes';
    const ordenSemana = [1, 2, 3, 4, 5, 6, 0];
    const conteo = (n) => Number(n || 0).toLocaleString('es-MX');
    const conGastos = !(g.modulos && g.modulos.gastos === false);
    return `<div class="g-kpis">
        ${kpi('Ingresos', A.tot.ingresos, P.tot.ingresos, { etiquetaAnt: ant })}
        ${conGastos ? kpi('Gastos', A.tot.gastos, P.tot.gastos, { etiquetaAnt: ant, menosEsMejor: true }) + kpi('Utilidad', A.tot.utilidad, P.tot.utilidad, { etiquetaAnt: ant }) : kpi('Cobros', A.tot.cobros, P.tot.cobros, { etiquetaAnt: ant, fmt: conteo })}
        ${kpi('Carros que entraron', A.tot.autos, P.tot.autos, { etiquetaAnt: ant, fmt: conteo })}
      </div>
      <div class="g-card"><h3>Ingresos ${tituloSerie} <span class="g-mut">contra ${e(ant)}</span></h3>
        ${(g.gran === 'mes' ? barrasComp : lineaComp)(g.etiquetas, A.serie.map((x) => x.ingresos), P.serie.map((x) => x.ingresos), { nombres: ['Este periodo', ant.charAt(0).toUpperCase() + ant.slice(1)] })}</div>
      <div class="g-card"><h3>Carros que entraron ${tituloSerie} <span class="g-mut">contra ${e(ant)}</span></h3>
        ${barrasComp(g.etiquetas, A.serie.map((x) => x.autos), P.serie.map((x) => x.autos), { fmt: conteo, nombres: ['Este periodo', ant.charAt(0).toUpperCase() + ant.slice(1)], alto: 200 })}</div>
      <div class="g-grid2">
        <div class="g-card"><h3>¿De dónde viene el dinero?</h3>${pastel(A.concepto, { centro: 'Ingresos' })}</div>
        <div class="g-card"><h3>Forma de pago</h3>${pastel(A.formaPago, { centro: 'Cobrado' })}</div>
        ${conGastos ? `<div class="g-card"><h3>Gastos por tipo</h3>${pastel(A.gastosCat, { centro: 'Gastos' })}</div>` : ''}
        <div class="g-card"><h3>Servicios y productos</h3>${pastel(A.servicios, { centro: 'Ventas' })}</div>
        <div class="g-card"><h3>Tipo de cliente <span class="g-mut">(carros)</span></h3>${pastel(A.clientes, { centro: 'Carros', fmt: conteo })}</div>
        <div class="g-card"><h3>Ingresos por día de la semana</h3>${barrasComp(ordenSemana.map((d) => DIAS[d]), ordenSemana.map((d) => A.semana[d]), ordenSemana.map((d) => P.semana[d]), { nombres: ['Este periodo', ant.charAt(0).toUpperCase() + ant.slice(1)], alto: 230, ancho: movil() ? 360 : 420 })}</div>
      </div>
      <div class="g-card"><h3>Últimos 12 meses <span class="g-mut">contra los mismos meses del año anterior</span></h3>
        ${barrasComp(g.meses.map((m) => m.mes), g.meses.map((m) => m.ingresos), g.meses.map((m) => m.anterior), { nombres: ['Ingresos', 'Año anterior'] })}
        <div class="g-scroll"><table class="g-tabla"><thead><tr><th>Mes</th>${g.meses.map((m) => `<th>${e(m.mes)}</th>`).join('')}</tr></thead><tbody>
          <tr><td>Ingresos</td>${g.meses.map((m) => `<td>${dinero(m.ingresos)}</td>`).join('')}</tr>
          ${conGastos ? `<tr><td>Gastos</td>${g.meses.map((m) => `<td>${dinero(m.gastos)}</td>`).join('')}</tr>
          <tr><td><b>Utilidad</b></td>${g.meses.map((m) => `<td><b>${dinero(m.ingresos - m.gastos)}</b></td>`).join('')}</tr>` : ''}
          <tr><td class="g-mut">Año anterior</td>${g.meses.map((m) => `<td class="g-mut">${dinero(m.anterior)}</td>`).join('')}</tr></tbody></table></div></div>
      <div class="g-card"><h3>Hora de llegada de los carros</h3>${barrasComp(A.horas.map((_, h) => String(h).padStart(2, '0') + 'h'), A.horas, null, { fmt: conteo, alto: 180 })}</div>`;
  }

  window.Graficas = { kpi, barrasComp, lineaComp, pastel, tablero, rangoAnterior, nombreAnterior, variacion };
})();
