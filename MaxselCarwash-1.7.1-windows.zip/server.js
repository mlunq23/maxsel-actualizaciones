// Servidor de Maxsel Carwash. Se abre en el navegador: http://localhost:3070
import http from 'node:http';
import https from 'node:https';
import zlib from 'node:zlib';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';
import { execFile } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { all, get, run, tx, cfg, cfgTodo, setCfg, CONFIG_DEFAULT, hoy, ahora, aFecha, salidaPrevista, r2, hashPass, checkPass, siguienteFolio, respaldar, RESPALDOS_DIR, DATA_DIR, FOTOS_DIR, CONTRATO_BASE } from './db.js';
import { PERMISOS, PERMISOS_ROL, permisosDe, limpiarPermisos } from './permisos.js';
import { imprimirOps, abrirCajon, listarImpresoras, hayImpresora } from './impresora.js';
import { LICENCIA, revisarLicencia, estadoLicencia, activarLicencia, codigoEquipo, MODO_DESARROLLO, moduloActivo, NOMBRE_MODULO } from './licencia.js';
import { crearSincronizador, iniciarSesion, URL_PAGINA } from './nube.js';
import { crearFunnel } from './funnel.js';
import { poliza } from './poliza.js';

const DIR = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(DIR, 'public');
const PUERTO = Number(process.env.PORT || 3070);
export const PRODUCTO = 'Maxsel Carwash';
const VERSION = '1.7.1';
const METODOS = ['efectivo', 'dolares', 'tarjeta', 'transferencia'];
const METODOS_GASTO = ['efectivo', 'tarjeta', 'transferencia'];
const EN_CAJA = ['efectivo', 'dolares'];
const MODALIDADES = ['rato', 'noche', 'dia', 'semana', 'mes'];
const NOMBRE_MOD = { rato: 'rato', noche: 'noche', dia: 'día', semana: 'semana', mes: 'mes' };
const AMENIDADES = ['wifi', 'tv', 'ac', 'ventilador', 'agua', 'cocina', 'parrilla', 'refri', 'micro', 'minibar', 'jacuzzi', 'estacionamiento', 'lavadora', 'balcon', 'mascotas'];
const CLASES = ['habitacion', 'departamento', 'local'];
const CAMAS = ['individual', 'matrimonial', 'queen', 'king', 'litera', 'sofacama'];

class ErrorUsuario extends Error { constructor(m, status = 400) { super(m); this.status = status; } }

// ---------- Utilidades HTTP ----------
function enviar(res, status, obj, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(obj));
}
function leerCuerpo(req, max = 30 * 1024 * 1024) {
  return new Promise((ok, mal) => {
    const chunks = []; let n = 0;
    req.on('data', (c) => { n += c.length; if (n > max) { mal(new ErrorUsuario('Datos demasiado grandes', 413)); req.destroy(); } else chunks.push(c); });
    req.on('end', () => ok(Buffer.concat(chunks))); req.on('error', mal);
  });
}
const cookies = (req) => Object.fromEntries(String(req.headers.cookie || '').split(';').map((c) => c.trim().split('=')).filter((p) => p[0]));
const num = (v) => r2(Number(v) || 0);
const ent = (v, min = 0) => Math.max(min, Math.floor(Number(v) || 0));
const txt = (v, max = 200) => (v === undefined || v === null ? null : String(v).trim().slice(0, max) || null);
// 1.7: lo que entra por Tailscale Funnel trae la dirección real del teléfono en X-Forwarded-For
const ipDe = (req) => (req.__funnel ? 'internet:' + (String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'desconocida') : String(req.socket.remoteAddress || '').replace(/^::ffff:/, ''));

// Red local y la propia computadora (1.7: desde fuera solo por Tailscale Funnel, ver funnel.js)
function ipPrivada(ip) {
  if (ip === '::1' || ip.startsWith('127.') || ip.startsWith('10.') || ip.startsWith('192.168.') || /^fe80:|^fd/i.test(ip)) return true;
  let m = /^172\.(\d+)\./.exec(ip); if (m && +m[1] >= 16 && +m[1] <= 31) return true;
  return false;
}

const rutas = [];
const ruta = (metodo, patron, rol, fn) => rutas.push({ metodo, re: new RegExp('^' + patron.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), rol, fn });
// Permiso que pide cada ruta: null = sin sesión · 'todos' = cualquier usuario · 'sesion' = ver (todos menos mantenimiento)
// 'vermant' = ver el panel de mantenimiento · 'mant' = reportar o atender mantenimiento · cualquier otro = clave de permisos.js
function autorizado(u, rol) {
  if (rol === 'todos' || rol === 'vermant') return true;
  if (rol === 'sesion') return u.rol !== 'mantenimiento';
  if (rol === 'mant') return u.perm.has('mant_reportar') || u.perm.has('mant_atender');
  return String(rol).split('|').some((k) => u.perm.has(k));
}
const TEXTO_PERMISO = Object.fromEntries(PERMISOS.map((x) => [x.clave, x.texto]));

// ---------- Licencia ----------
ruta('GET', '/api/licencia/estado', null, () => ({ ...estadoLicencia(), producto: PRODUCTO, version: VERSION, poliza: polizaHoy() }));
ruta('POST', '/api/licencia/activar', null, ({ body }) => { try { _pol = null; setTimeout(revisarPoliza, 1000); return activarLicencia(body.clave); } catch (e) { throw new ErrorUsuario(e.message); } });
const SIN_LICENCIA_OK = new Set(['/api/licencia/estado', '/api/licencia/activar']);
// Módulos que se venden aparte (se activan en la licencia): qué rutas le pertenecen a cada uno
const RUTAS_MODULO = [
  ['gastos', /^\/api\/(gastos|gastos-fijos|cuentas-pagar|proveedores|empleados|nomina)(\/|$)/],
  ['asistencia', /^\/api\/(asistencia|huella|festivos|incidencias|relojes)(\/|$)/],
  ['membresias', /^\/api\/membresias(\/|$)/],
];
const moduloDeRuta = (r0) => RUTAS_MODULO.find(([, re]) => re.test(r0))?.[0] || null;
const SIN_MODULO = (k) => `El módulo de ${NOMBRE_MODULO[k] || k} no está incluido en la licencia de este negocio. Para activarlo comuníquese con Maxsel.`;

// ---------- Sesión ----------
const intentos = new Map(); // ip -> {n, hasta}
ruta('POST', '/api/login', null, ({ body, res, req }) => {
  const ip = ipDe(req), it = intentos.get(ip) || { n: 0, hasta: 0 };
  if (it.hasta > Date.now()) throw new ErrorUsuario('Demasiados intentos. Espere 10 minutos.', 429);
  const u = get('SELECT * FROM usuarios WHERE usuario=? AND activo=1', txt(body.usuario)?.toLowerCase());
  if (!u || !checkPass(body.password || '', u.pass_hash)) {
    it.n++; if (it.n >= 8) { it.hasta = Date.now() + 10 * 60000; it.n = 0; } intentos.set(ip, it);
    throw new ErrorUsuario('Usuario o contraseña incorrectos', 401);
  }
  if (req.__funnel && !['admin', 'gerente', 'monitor'].includes(u.rol)) throw new ErrorUsuario('Desde internet solo entran el administrador, el gerente o el usuario de monitoreo.', 403);
  intentos.delete(ip);
  const token = crypto.randomBytes(24).toString('hex');
  run('INSERT INTO sesiones(token,usuario_id,creado,ip) VALUES(?,?,?,?)', token, u.id, ahora(), ip);
  res.setHeader('Set-Cookie', `htl_s=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=2592000`);
  return { id: u.id, nombre: u.nombre, rol: u.rol };
});
ruta('POST', '/api/logout', 'todos', ({ req, res }) => {
  run('DELETE FROM sesiones WHERE token=?', cookies(req).htl_s);
  res.setHeader('Set-Cookie', 'htl_s=; Path=/; Max-Age=0');
});
ruta('GET', '/api/yo', 'todos', ({ u }) => ({ id: u.id, nombre: u.nombre, rol: u.rol, permisos: [...u.perm], turno: turnoAbierto(u.id) || null, hotel: cfg('hotel_nombre'), licencia: estadoLicencia(), producto: PRODUCTO, version: VERSION }));
ruta('POST', '/api/mi-password', 'todos', ({ body, u }) => {
  if (!checkPass(body.actual || '', u.pass_hash)) throw new ErrorUsuario('La contraseña actual no es correcta');
  if (String(body.nueva || '').length < 6) throw new ErrorUsuario('La nueva contraseña debe tener al menos 6 caracteres');
  run('UPDATE usuarios SET pass_hash=? WHERE id=?', hashPass(body.nueva), u.id);
});

// ---------- Usuarios ----------
const ROLES = ['admin', 'gerente', 'recepcion', 'monitor', 'mantenimiento'];
ruta('GET', '/api/permisos', 'todos', () => ({ lista: PERMISOS, roles: PERMISOS_ROL }));
ruta('GET', '/api/usuarios', 'usuarios', () => all('SELECT id,nombre,usuario,rol,activo,permisos FROM usuarios ORDER BY nombre')
  .map((x) => ({ ...x, personalizado: !!x.permisos && x.rol !== 'admin', permisos: permisosDe(x) })));
// Si los permisos marcados son exactamente los del tipo de usuario, no se guardan como personalizados
function permisosBody(body, rol) {
  if (rol === 'admin' || !Array.isArray(body.permisos)) return null;
  const l = limpiarPermisos(body.permisos), base = PERMISOS_ROL[rol] || [];
  if (l.length === base.length && l.every((k) => base.includes(k))) return null;
  return JSON.stringify(l);
}
ruta('POST', '/api/usuarios', 'usuarios', ({ body }) => {
  if (!txt(body.nombre) || !txt(body.usuario) || !body.password) throw new ErrorUsuario('Nombre, usuario y contraseña son obligatorios');
  if (String(body.password).length < 6) throw new ErrorUsuario('La contraseña debe tener al menos 6 caracteres');
  if (!ROLES.includes(body.rol)) throw new ErrorUsuario('Tipo de usuario inválido');
  if (get('SELECT id FROM usuarios WHERE usuario=?', txt(body.usuario).toLowerCase())) throw new ErrorUsuario('Ese nombre de usuario ya existe');
  return run('INSERT INTO usuarios(nombre,usuario,pass_hash,rol,permisos) VALUES(?,?,?,?,?)', txt(body.nombre), txt(body.usuario).toLowerCase(), hashPass(body.password), body.rol, permisosBody(body, body.rol));
});
ruta('PUT', '/api/usuarios/:id', 'usuarios', ({ body, p, u }) => {
  const id = Number(p.id), a = get('SELECT * FROM usuarios WHERE id=?', id);
  if (!a) throw new ErrorUsuario('Usuario no encontrado', 404);
  if (id === u.id && (body.activo === false || (body.rol && body.rol !== 'admin'))) throw new ErrorUsuario('No puede desactivarse ni quitarse el rol de administrador a sí mismo');
  const rol = ROLES.includes(body.rol) ? body.rol : a.rol;
  run('UPDATE usuarios SET nombre=COALESCE(?,nombre), rol=?, activo=COALESCE(?,activo), permisos=? WHERE id=?', txt(body.nombre), rol, body.activo === undefined ? null : body.activo ? 1 : 0,
    body.permisos === undefined ? a.permisos : permisosBody(body, rol), id);
  if (body.password) {
    if (String(body.password).length < 6) throw new ErrorUsuario('La contraseña debe tener al menos 6 caracteres');
    run('UPDATE usuarios SET pass_hash=? WHERE id=?', hashPass(body.password), id);
  }
  if (body.activo === false || body.password) run('DELETE FROM sesiones WHERE usuario_id=? AND usuario_id<>?', id, u.id);
});

// ---------- Configuración ----------
// La sesión de la nube nunca se manda a la pantalla (solo el correo y si está activa)
function sinSecretos(c) { for (const k of Object.keys(c)) if (k.startsWith('nube_') && k !== 'nube_activo' && k !== 'nube_email') delete c[k]; return c; }
function ipsEquipo() {
  return Object.entries(os.networkInterfaces()).flatMap(([n, l]) => (l || []).filter((i) => i.family === 'IPv4' && !i.internal).map((i) => ({ ip: i.address, nombre: n, tailscale: /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(i.address) || /tailscale/i.test(n) })));
}
ruta('GET', '/api/config', 'todos', () => ({ ...sinSecretos(cfgTodo()), _contrato_base: CONTRATO_BASE, _clasif_base: CONFIG_DEFAULT.gastos_clasificacion, _ips: ipsEquipo(), _puerto: PUERTO, _version: VERSION, _amenidades: AMENIDADES, _camas: CAMAS }));
// 1.8 El servicio de limpieza es un producto de tipo servicio en la tienda (se vende aparte o se carga a la habitación)
function servicioLimpieza() {
  const precio = num(cfg('cuota_limpieza')), ya = get("SELECT * FROM productos WHERE codigo='SERV-LIMPIEZA'");
  if (ya) run('UPDATE productos SET precio=CASE WHEN ?>0 THEN ? ELSE precio END, activo=CASE WHEN ?>0 THEN 1 ELSE activo END, servicio=1 WHERE id=?', precio, precio, precio, ya.id);
  else if (precio > 0) run("INSERT INTO productos(codigo,nombre,costo,precio,existencia,minimo,area,servicio) VALUES('SERV-LIMPIEZA','Servicio de limpieza',0,?,0,0,'Servicios',1)", precio);
}
// Carwash: no se crea el servicio de limpieza del hotel
ruta('PUT', '/api/config', 'config', ({ body }) => {
  for (const k of Object.keys(CONFIG_DEFAULT)) if (body[k] !== undefined) setCfg(k, txt(body[k], k === 'ticket_logo' ? 200000 : ['contrato_clausulas', 'gastos_clasificacion', 'multas_lista', 'unidades_negocio', 'tienda_areas', 'maxsel_contacto', 'cw_pantalla_bienvenida', 'cw_pantalla_gracias'].includes(k) ? 60000 : k === 'cw_logo_pantalla' ? 400000 : 300) ?? '');
});

// ---------- Habitaciones ----------
function limpiarHab(b, sinPrecio = false) {
  const camas = {};
  for (const c of CAMAS) { const n = ent(b.camas?.[c]); if (n) camas[c] = Math.min(n, 20); }
  const d = {
    numero: txt(b.numero, 20), nombre: txt(b.nombre, 60), clase: CLASES.includes(b.clase) ? b.clase : 'habitacion', piso: txt(b.piso, 20) || '', unidad: txt(b.unidad, 60),
    camas: JSON.stringify(camas), recamaras: Math.min(ent(b.recamaras, 1), 20), banos: Math.min(ent(b.banos, 0), 20), capacidad: Math.min(ent(b.capacidad, 1), 50),
    amenidades: JSON.stringify((Array.isArray(b.amenidades) ? b.amenidades : []).filter((a) => AMENIDADES.includes(a))),
    precio_rato: num(b.precio_rato), precio_noche: num(b.precio_noche), precio_dia: num(b.precio_dia), precio_semana: num(b.precio_semana), precio_mes: num(b.precio_mes),
  };
  if (!d.numero) throw new ErrorUsuario('Escriba el número o nombre corto de la habitación');
  if (!sinPrecio && !(d.precio_rato > 0 || d.precio_noche > 0 || d.precio_dia > 0 || d.precio_semana > 0 || d.precio_mes > 0)) throw new ErrorUsuario('Ponga al menos un precio (rato, noche, día, semana o mes)');
  return d;
}
const habJSON = (h) => h && ({ ...h, camas: JSON.parse(h.camas || '{}'), amenidades: JSON.parse(h.amenidades || '[]') });
// ---------- Habitaciones en lote (1.3): crear o importar muchas de golpe y editar varias a la vez ----------
const HAB_COLS = 'nombre=?,clase=?,piso=?,camas=?,recamaras=?,banos=?,capacidad=?,amenidades=?,precio_rato=?,precio_noche=?,precio_dia=?,precio_semana=?,precio_mes=?,unidad=?';
const habVals = (d) => [d.nombre, d.clase, d.piso, d.camas, d.recamaras, d.banos, d.capacidad, d.amenidades, d.precio_rato, d.precio_noche, d.precio_dia, d.precio_semana, d.precio_mes, d.unidad];
// Precio fijo de visita por habitación: solo gerente o administrador (permiso "autorizar")
function fijarVisita(id, b, u) {
  if (b.precio_visita === undefined || !u?.perm?.has('autorizar')) return;
  const v = b.precio_visita === '' || b.precio_visita === null ? null : num(b.precio_visita);
  run('UPDATE habitaciones SET precio_visita=? WHERE id=?', v, id);
}
ruta('POST', '/api/habitaciones/lote', 'habitaciones', ({ body, u }) => tx(() => {
  const lista = Array.isArray(body.habitaciones) ? body.habitaciones : [];
  if (!lista.length) throw new ErrorUsuario('No hay habitaciones para crear');
  if (lista.length > 2000) throw new ErrorUsuario('Máximo 2000 habitaciones por vez');
  const actualizar = body.existentes === 'actualizar', res = { creadas: 0, actualizadas: 0, saltadas: [] }, vistos = new Set();
  lista.forEach((b, i) => {
    let d; try { d = limpiarHab(b, true); } catch (e) { throw new ErrorUsuario(`Renglón ${i + 1}: ${e.message}`); }
    const k = d.numero.toLowerCase();
    if (vistos.has(k)) throw new ErrorUsuario(`La habitación ${d.numero} viene repetida en la lista`);
    vistos.add(k);
    const ya = get('SELECT id FROM habitaciones WHERE numero=? AND activo=1', d.numero);
    if (ya) {
      if (!actualizar) { res.saltadas.push(d.numero); return; }
      run(`UPDATE habitaciones SET ${HAB_COLS} WHERE id=?`, ...habVals(d), ya.id); fijarVisita(ya.id, b, u); res.actualizadas++; return;
    }
    const viejo = get('SELECT id FROM habitaciones WHERE numero=? AND activo=0', d.numero);
    let nid;
    if (viejo) { run(`UPDATE habitaciones SET ${HAB_COLS},estado='libre',nota=NULL,activo=1 WHERE id=?`, ...habVals(d), viejo.id); nid = viejo.id; }
    else nid = run(`INSERT INTO habitaciones(numero,nombre,clase,piso,camas,recamaras,banos,capacidad,amenidades,precio_rato,precio_noche,precio_dia,precio_semana,precio_mes,unidad) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, d.numero, ...habVals(d)).id;
    fijarVisita(nid, b, u);
    res.creadas++;
  });
  return res;
}));
ruta('PUT', '/api/habitaciones/lote', 'habitaciones', ({ body, u }) => tx(() => {
  const lista = Array.isArray(body.habitaciones) ? body.habitaciones : [];
  const nums = new Map();
  for (const b of lista) {
    const id = Number(b.id), d = limpiarHab(b, true);
    if (!get('SELECT id FROM habitaciones WHERE id=? AND activo=1', id)) throw new ErrorUsuario('La habitación ' + d.numero + ' ya no existe');
    if (nums.has(d.numero.toLowerCase())) throw new ErrorUsuario('El número ' + d.numero + ' está repetido');
    nums.set(d.numero.toLowerCase(), id);
  }
  for (const b of lista) {
    const id = Number(b.id), d = limpiarHab(b, true);
    const otro = get('SELECT id FROM habitaciones WHERE numero=? AND id<>? AND activo=1', d.numero, id);
    if (otro && !lista.some((x) => Number(x.id) === otro.id)) throw new ErrorUsuario('Ya existe la habitación ' + d.numero);
    run(`UPDATE habitaciones SET numero=?,${HAB_COLS} WHERE id=?`, '~' + id + '~' + d.numero, ...habVals(d), id); // número temporal por si se intercambian
    fijarVisita(id, b, u);
  }
  for (const b of lista) run("UPDATE habitaciones SET numero=substr(numero, instr(substr(numero,2),'~')+2) WHERE id=? AND numero LIKE '~%'", Number(b.id));
  return { guardadas: lista.length };
}));
ruta('GET', '/api/habitaciones', 'vermant', () => all('SELECT * FROM habitaciones WHERE activo=1').map(habJSON));
ruta('POST', '/api/habitaciones', 'habitaciones', ({ body, u }) => {
  const d = limpiarHab(body);
  if (get('SELECT id FROM habitaciones WHERE numero=? AND activo=1', d.numero)) throw new ErrorUsuario('Ya existe la habitación ' + d.numero);
  const viejo = get('SELECT id FROM habitaciones WHERE numero=? AND activo=0', d.numero);
  if (viejo) { run(`UPDATE habitaciones SET ${HAB_COLS},estado='libre',nota=NULL,activo=1 WHERE id=?`, ...habVals(d), viejo.id); fijarVisita(viejo.id, body, u); return { id: viejo.id }; }
  const r = run(`INSERT INTO habitaciones(numero,nombre,clase,piso,camas,recamaras,banos,capacidad,amenidades,precio_rato,precio_noche,precio_dia,precio_semana,precio_mes,unidad) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, d.numero, ...habVals(d));
  fijarVisita(r.id, body, u); return r;
});
ruta('PUT', '/api/habitaciones/:id', 'habitaciones', ({ body, p, u }) => {
  const id = Number(p.id), d = limpiarHab(body);
  if (get('SELECT id FROM habitaciones WHERE numero=? AND id<>? AND activo=1', d.numero, id)) throw new ErrorUsuario('Ya existe la habitación ' + d.numero);
  run(`UPDATE habitaciones SET numero=?,${HAB_COLS} WHERE id=?`, d.numero, ...habVals(d), id);
  fijarVisita(id, body, u);
});
ruta('DELETE', '/api/habitaciones/:id', 'habitaciones', ({ p }) => {
  const h = get('SELECT * FROM habitaciones WHERE id=?', Number(p.id));
  if (!h) throw new ErrorUsuario('No existe', 404);
  if (h.estado === 'ocupada') throw new ErrorUsuario('No se puede borrar una habitación ocupada');
  run('UPDATE habitaciones SET activo=0 WHERE id=?', h.id); // se conserva para el historial
});
ruta('POST', '/api/habitaciones/:id/estado', 'estados', ({ body, p, u }) => {
  const h = get('SELECT * FROM habitaciones WHERE id=? AND activo=1', Number(p.id));
  if (!h) throw new ErrorUsuario('No existe', 404);
  if (!['libre', 'limpieza', 'mant'].includes(body.estado)) throw new ErrorUsuario('Estado inválido');
  if (h.estado === 'ocupada') throw new ErrorUsuario('La habitación está ocupada. Primero registre la salida del huésped.');
  run('UPDATE habitaciones SET estado=?, nota=? WHERE id=?', body.estado, body.estado === 'mant' ? txt(body.nota) : null, h.id);
  run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), h.id, body.estado, txt(body.nota), u.id);
  // Mandar a mantenimiento crea el reporte para el personal de mantenimiento
  if (body.estado === 'mant' && !get("SELECT id FROM mantenimiento WHERE habitacion_id=? AND estado<>'terminado'", h.id))
    nuevoReporte({ habitacion_id: h.id, titulo: txt(body.nota, 120) || 'Revisión general', prioridad: 'normal' }, u.id);
});

// ---------- Estancias (registro del huésped en la habitación) ----------
const consumo = (eid) => get('SELECT COALESCE(SUM(importe),0) t FROM cargos WHERE estancia_id=?', eid).t;
const pagado = (eid) => get('SELECT COALESCE(SUM(monto),0) t FROM pagos WHERE estancia_id=?', eid).t;
function resumenEstancia(e) {
  if (!e) return null;
  const c = consumo(e.id), pg = pagado(e.id);
  const dep = get(`SELECT COALESCE(SUM(CASE WHEN tipo='recibido' THEN monto END),0) rec, COALESCE(SUM(CASE WHEN tipo='devuelto' THEN monto END),0) dev,
    COALESCE(SUM(CASE WHEN tipo='retenido' THEN monto END),0) ret FROM depositos WHERE estancia_id=?`, e.id);
  return { ...e, consumo: r2(c), pagado: r2(pg), saldo: r2(e.total_hospedaje + c - pg), vencida: e.activa && aFecha(e.salida_prevista) < new Date(),
    deposito: r2(dep.rec), deposito_devuelto: r2(dep.dev), deposito_retenido: r2(dep.ret), deposito_saldo: r2(dep.rec - dep.dev - dep.ret) };
}
const precioDe = (h, m) => h['precio_' + m] || 0;
// Registro de cada renta, extensión o cambio (para contar ratos, noches, días, semanas y meses en el corte)
function anotarRenta(eid, uid, modalidad, cantidad, precio, tipo) {
  run('INSERT INTO rentas(estancia_id,fecha,turno_id,usuario_id,modalidad,cantidad,precio,importe,tipo) VALUES(?,?,?,?,?,?,?,?,?)',
    eid, ahora(), turnoAbierto(uid)?.id ?? null, uid, modalidad, cantidad, precio, r2(precio * cantidad), tipo);
}
// ---------- Caja: turnos, dólares y cajón ----------
const turnoAbierto = (uid) => get("SELECT * FROM turnos WHERE usuario_id=? AND estado='abierto' ORDER BY id DESC LIMIT 1", uid);
function turnoCaja(uid) {
  const t = turnoAbierto(uid);
  if (!t && cfg('exigir_turno') !== '0') throw new ErrorUsuario('Primero abra su turno de caja (botón "Abrir turno" arriba).');
  return t || null;
}
const tcDe = (t) => (t?.tipo_cambio > 0 ? t.tipo_cambio : num(cfg('tipo_cambio')) || 18);
let cajonPendiente = false;
const pedirCajon = () => { cajonPendiente = true; };
// Reparte un cobro entre formas de pago: pesos en efectivo, dólares, tarjeta y transferencia.
// Lo que sobra se entrega de cambio en pesos (primero se descuenta de los pesos recibidos, luego de los dólares).
function repartir(monto, partes, tc) {
  const ef = Math.max(0, num(partes.efectivo)), usd = Math.max(0, num(partes.usd)), ta = Math.max(0, num(partes.tarjeta)), tr = Math.max(0, num(partes.transferencia));
  const eq = r2(usd * tc), total = r2(ef + eq + ta + tr);
  if (total + 0.009 < monto) throw new ErrorUsuario(`Faltan $${(monto - total).toFixed(2)}: recibió $${total.toFixed(2)}${usd ? ` (US$${usd} × ${tc} = $${eq.toFixed(2)})` : ''} y el cobro es de $${monto.toFixed(2)}`);
  if (ta + tr > monto + 0.009) throw new ErrorUsuario('Lo cobrado con tarjeta y transferencia no puede pasar del total');
  const cambio = r2(total - monto), c1 = Math.min(cambio, ef), c2 = r2(cambio - c1);
  const filas = [];
  if (ef > 0 && ef - c1 > 0.004) filas.push({ metodo: 'efectivo', monto: r2(ef - c1), usd: 0, cambio: 0 });
  if (usd > 0) filas.push({ metodo: 'dolares', monto: r2(eq - c2), usd, cambio: c2 });
  if (ta > 0) filas.push({ metodo: 'tarjeta', monto: ta, usd: 0, cambio: 0 });
  if (tr > 0) filas.push({ metodo: 'transferencia', monto: tr, usd: 0, cambio: 0 });
  return { filas, cambio, usd, total };
}
// Convierte la forma de pago que manda la pantalla en partes: un solo método, dólares o "mixto" (se llenan los montos de cada método)
function partesDe(monto, metodo, usd, partes, tc) {
  if (metodo === 'mixto') {
    const p = partes || {};
    // Si no se escribió nada en ninguna forma, se toma como pago exacto en efectivo
    if (!(num(p.efectivo) > 0 || num(p.usd) > 0 || num(p.tarjeta) > 0 || num(p.transferencia) > 0)) return { efectivo: monto };
    return p;
  }
  if (!METODOS.includes(metodo)) throw new ErrorUsuario('Elija la forma de pago');
  if (metodo === 'dolares') return { usd: num(usd) || r2(Math.ceil((monto / tc) * 100) / 100) };
  return { [metodo]: monto };
}
// ---------- 1.8 Cargos extra: multas, intereses moratorios, cuotas de limpieza y por mascota ----------
const TIPOS_CARGO = { multa: 'Multa', mora: 'Interés moratorio', limpieza: 'Cuota de limpieza', mascota: 'Cuota por mascota', otro: 'Otro cargo' };
const EXTRAS = Object.keys(TIPOS_CARGO);
const cargar = (eid, tipo, descripcion, importe, cantidad, uid) => run('INSERT INTO cargos(estancia_id,fecha,descripcion,cantidad,importe,tipo,usuario_id) VALUES(?,?,?,?,?,?,?)', eid, ahora(), descripcion, cantidad || 1, r2(importe), tipo, uid ?? null);
const pendienteExtra = (eid, tipo) => r2(get('SELECT COALESCE(SUM(importe),0) t FROM cargos WHERE estancia_id=? AND tipo=?', eid, tipo).t - get('SELECT COALESCE(SUM(monto),0) t FROM pagos WHERE estancia_id=? AND concepto=?', eid, tipo).t);
// Cobro a la caja (hospedaje, anticipos, tienda, visitas)
function pagar(monto, metodo, concepto, estanciaId, ventaId, uid, nota, usd, partes) {
  monto = num(monto); if (!(monto > 0)) return { cambio: 0 };
  const t = turnoCaja(uid), tc = tcDe(t);
  const rp = repartir(monto, partesDe(monto, metodo, usd, partes, tc), tc);
  const modalidad = concepto === 'hospedaje' && estanciaId ? get('SELECT modalidad FROM estancias WHERE id=?', estanciaId)?.modalidad : null;
  // 1.8: los abonos y la liquidación pagan primero multas, intereses y cuotas pendientes (así cada ingreso sale en su renglón del reporte)
  const cola = concepto === 'hospedaje' && estanciaId && /^(Abono|Liquidación|Anticipo al registrar)/.test(nota || '')
    ? EXTRAS.map((k) => [k, pendienteExtra(estanciaId, k)]).filter((x) => x[1] > 0.004) : [];
  for (const f of rp.filas) {
    let resto = f.monto; const partes = [];
    while (resto > 0.004 && cola.length) { const c = cola[0], a = r2(Math.min(resto, c[1])); partes.push([c[0], a]); c[1] = r2(c[1] - a); resto = r2(resto - a); if (c[1] <= 0.004) cola.shift(); }
    if (resto > 0.004 || !partes.length) partes.push([concepto, r2(resto)]);
    partes.forEach(([con, m], i) => run('INSERT INTO pagos(fecha,monto,metodo,concepto,estancia_id,venta_id,usuario_id,nota,turno_id,usd,tc,cambio,modalidad) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
      ahora(), m, f.metodo, con, estanciaId, ventaId, uid, (con !== concepto ? TIPOS_CARGO[con] + ' · ' : '') + (nota || '') || null, t?.id ?? null, f.usd && f.monto ? r2(f.usd * m / f.monto) : 0, f.usd ? tc : 0, i === 0 ? f.cambio : 0, con === 'hospedaje' ? modalidad : null));
    if (EN_CAJA.includes(f.metodo)) pedirCajon();
  }
  return { cambio: rp.cambio, usd: rp.usd, tc, total: rp.total, filas: rp.filas };
}

const p2_ = (n) => String(n).padStart(2, '0');
const fechaHoraDe = (d) => `${d.getFullYear()}-${p2_(d.getMonth() + 1)}-${p2_(d.getDate())} ${p2_(d.getHours())}:${p2_(d.getMinutes())}:${p2_(d.getSeconds())}`;
// Nueva salida al agregar n periodos con el mismo precio. Mes se cuenta desde el inicio (para no recorrer el día de pago);
// lo demás se suma a la salida actual (respeta la hora de check out elegida).
function sumarPeriodos(e, inicio, cantTotal, n) {
  if (e.modalidad === 'mes') return salidaPrevista(inicio, 'mes', cantTotal, cfg('hora_salida'), e.hora_checkout);
  if (e.modalidad === 'rato') { const d = aFecha(e.salida_prevista); d.setMinutes(d.getMinutes() + Math.round((num(cfg('horas_rato')) || 3) * 60) * n); return fechaHoraDe(d); }
  if (e.modalidad === 'dia' && cfg('dia_24h') === '1') { const d = aFecha(e.salida_prevista); d.setDate(d.getDate() + n); return fechaHoraDe(d); }
  const d = aFecha(e.salida_prevista); d.setDate(d.getDate() + (e.modalidad === 'semana' ? 7 : 1) * n); return fechaHoraDe(d);
}
// ---------- 1.7.2 Cobro automático: si llegó la hora del check out y no se registró la salida, se carga otro periodo ----------
// (otro rato, otra noche, otro día, otra semana u otro mes al mismo precio). El cargo queda en la cuenta y se cobra al salir.
function cobrosVencidos() {
  if (cfg('cobro_auto') === '0') return 0;
  const tol = Math.max(0, num(cfg('cobro_auto_tolerancia'))) * 60000, ya = new Date();
  const turno = get("SELECT id FROM turnos WHERE estado='abierto' ORDER BY id DESC LIMIT 1")?.id ?? null;
  let total = 0;
  for (const e0 of all('SELECT * FROM estancias WHERE activa=1 AND precio>0')) {
    let e = e0, vueltas = 0;
    while (aFecha(e.salida_prevista).getTime() + tol < ya.getTime() && vueltas++ < 60) {
      tx(() => {
        const inicio = e.inicio_tramo || e.entrada, cant = e.cantidad + 1, nueva = sumarPeriodos(e, inicio, cant, 1);
        run('UPDATE estancias SET cantidad=?, total_hospedaje=?, salida_prevista=?, cobros_auto=COALESCE(cobros_auto,0)+1 WHERE id=?', cant, r2(e.total_hospedaje + e.precio), nueva, e.id);
        run('INSERT INTO rentas(estancia_id,fecha,turno_id,usuario_id,modalidad,cantidad,precio,importe,tipo) VALUES(?,?,?,?,?,?,?,?,?)',
          e.id, ahora(), turno, e.usuario_id, e.modalidad, 1, e.precio, r2(e.precio), 'automatico');
        run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), e.habitacion_id, 'ocupada',
          `No se registró la salida a las ${e.salida_prevista.slice(11, 16)}: se cobró otro periodo (${NOMBRE_MOD[e.modalidad]}) de $${r2(e.precio).toFixed(2)}`, e.usuario_id);
      });
      e = get('SELECT * FROM estancias WHERE id=?', e.id); total++;
    }
  }
  return total;
}
// Interés moratorio: rentas por semana o mes (deptos., locales) que siguen sin pagarse N días después de generarse
function morasVencidas() {
  if (cfg('mora_activa') !== '1') return 0;
  // Solo rentas por semana o por mes (hotel por semana/mes, departamentos del callejón, otros deptos. y locales).
  // Nunca a ratos, noches ni días.
  const LARGAS = ['semana', 'mes'], gracia = Math.max(0, num(cfg('mora_dias'))) * 86400000, ya = Date.now();
  const tipo = cfg('mora_tipo') === 'fijo' ? 'fijo' : 'porcentaje', valor = num(cfg('mora_valor'));
  let n = 0;
  if (!(valor > 0)) return 0;
  for (const e of all("SELECT * FROM estancias WHERE activa=1 AND modalidad IN ('semana','mes')")) {
    // Cada renta vencida (también las que el sistema cobró solo porque no se cerró la renta) lleva su propio interés
    const vencidas = all('SELECT * FROM rentas WHERE estancia_id=? AND id>? ORDER BY id DESC', e.id, e.mora_renta_id || 0)
      .filter((x) => LARGAS.includes(x.modalidad || e.modalidad) && aFecha(x.fecha).getTime() + gracia <= ya);
    if (!vencidas.length) continue;
    tx(() => {
      // El adeudo se reparte de la renta más nueva a la más vieja (los pagos cubren primero lo más viejo)
      let resta = resumenEstancia(e).saldo;
      for (const ult of vencidas) {
        if (!(resta > 0.009)) break;
        const base = Math.min(resta, ult.importe || e.precio); resta -= base;
        const monto = tipo === 'fijo' ? valor : r2(base * valor / 100);
        if (!(monto > 0)) continue;
        cargar(e.id, 'mora', tipo === 'fijo' ? `Interés moratorio por pago tardío (${NOMBRE_MOD[ult.modalidad || e.modalidad] || 'renta'} del ${ult.fecha.slice(0, 10)})` : `Interés moratorio ${valor}% por pago tardío de ${NOMBRE_MOD[ult.modalidad || e.modalidad] || 'renta'} (${ult.fecha.slice(0, 10)}, adeudo $${base.toFixed(2)})`, monto, 1, null);
        run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), e.habitacion_id, 'ocupada', `Interés moratorio de $${monto.toFixed(2)} por renta del ${ult.fecha.slice(0, 10)} no pagada a tiempo`, null);
        n++;
      }
      run('UPDATE estancias SET mora_renta_id=? WHERE id=?', vencidas[0].id, e.id);
    });
  }
  return n;
}
setInterval(() => { try { cobrosVencidos(); morasVencidas(); } catch (err) { console.error('Cobro automático:', err.message); } }, 60 * 1000).unref();

ruta('GET', '/api/tablero', 'sesion', () => {
  try { cobrosVencidos(); morasVencidas(); } catch { /* nada */ }
  const habs = all('SELECT * FROM habitaciones WHERE activo=1').map(habJSON);
  const activas = all('SELECT * FROM estancias WHERE activa=1').map(resumenEstancia);
  const porHab = Object.fromEntries(activas.map((e) => [e.habitacion_id, e]));
  const dentro = all('SELECT habitacion_id, COUNT(*) n FROM visitantes WHERE salida IS NULL GROUP BY habitacion_id');
  const vis = Object.fromEntries(dentro.map((v) => [v.habitacion_id, v.n]));
  const mt = Object.fromEntries(all("SELECT habitacion_id, COUNT(*) n FROM mantenimiento WHERE estado<>'terminado' GROUP BY habitacion_id").map((x) => [x.habitacion_id, x.n]));
  return { habitaciones: habs.map((h) => ({ ...h, estancia: porHab[h.id] || null, visitantes: vis[h.id] || 0, reportes: mt[h.id] || 0 })), config: cfgTodo(), ahora: ahora() };
});

ruta('POST', '/api/estancias', 'registrar', ({ body, u }) => tx(() => {
  const h = get('SELECT * FROM habitaciones WHERE id=? AND activo=1', Number(body.habitacion_id));
  if (!h) throw new ErrorUsuario('Habitación no encontrada');
  if (h.estado !== 'libre') throw new ErrorUsuario('La habitación no está disponible');
  const huesped = txt(body.huesped, 100);
  if (!huesped) throw new ErrorUsuario('Escriba el nombre del huésped');
  const m = MODALIDADES.includes(body.modalidad) ? body.modalidad : null;
  if (!m) throw new ErrorUsuario('Elija el tipo de renta: rato, noche, día, semana o mes');
  const cant = Math.min(ent(body.cantidad, 1), 365), precio = body.precio !== undefined && body.precio !== '' ? num(body.precio) : precioDe(h, m);
  if (!(precio > 0)) throw new ErrorUsuario('Esta habitación no tiene precio por ' + NOMBRE_MOD[m]);
  const entrada = ahora(), folio = siguienteFolio('estancia');
  // Hora de check out que dice el huésped (HH:MM). Rato: se toma el día de hoy o mañana a esa hora.
  const hco = /^\d{1,2}:\d{2}$/.test(String(body.hora_checkout || '')) ? String(body.hora_checkout).padStart(5, '0') : null;
  let salida = salidaPrevista(entrada, m, cant, cfg('hora_salida'), hco);
  if (hco && m === 'rato') {
    const d = aFecha(entrada), [hh, mm] = hco.split(':').map(Number); d.setHours(hh, mm, 0, 0);
    if (d <= aFecha(entrada)) d.setDate(d.getDate() + 1);
    salida = fechaHoraDe(d);
  }
  const r = run(`INSERT INTO estancias(folio,habitacion_id,huesped,telefono,identificacion,procedencia,placas,personas,modalidad,cantidad,precio,total_hospedaje,entrada,salida_prevista,notas,usuario_id,domicilio,inicio_tramo,hospedaje_previo,turno_id)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?)`, folio, h.id, huesped, txt(body.telefono, 30), txt(body.identificacion, 60), txt(body.procedencia, 80), txt(body.placas, 20),
    Math.min(ent(body.personas, 1), 50), m, cant, precio, r2(precio * cant), entrada, salida, txt(body.notas, 300), u.id, txt(body.domicilio, 200), entrada, turnoAbierto(u.id)?.id ?? null);
  if (hco && m !== 'rato') run('UPDATE estancias SET hora_checkout=? WHERE id=?', hco, r.id);
  anotarRenta(r.id, u.id, m, cant, precio, 'entrada');
  // 1.8 Cuota por mascota
  // La limpieza ya no se cobra al registrar: es un servicio de la tienda o se carga desde la cuenta (Multa o cargo)
  const nm = Math.min(ent(body.mascotas), 10);
  if (nm > 0) { run('UPDATE estancias SET mascotas=? WHERE id=?', nm, r.id); if (num(cfg('cuota_mascota')) > 0) cargar(r.id, 'mascota', `Cuota por mascota (${nm})`, num(cfg('cuota_mascota')) * nm, nm, u.id); }
  const pago = pagar(body.pago, body.metodo, 'hospedaje', r.id, null, u.id, 'Anticipo al registrar', body.usd, body.partes);
  const dep = num(body.deposito) > 0 ? recibirDeposito(r.id, body.deposito, body.metodo_deposito || body.metodo, u.id, body.usd_deposito, body.partes_deposito) : null;
  run("UPDATE habitaciones SET estado='ocupada', nota=NULL WHERE id=?", h.id);
  return { id: r.id, pago, deposito: dep };
}));
function estanciaActiva(id) {
  const e = get('SELECT * FROM estancias WHERE id=?', Number(id));
  if (!e) throw new ErrorUsuario('Registro no encontrado', 404);
  if (!e.activa) throw new ErrorUsuario('Este huésped ya salió');
  return e;
}
ruta('GET', '/api/estancias/:id', 'sesion', ({ p }) => {
  const e = resumenEstancia(get('SELECT * FROM estancias WHERE id=?', Number(p.id)));
  if (!e) throw new ErrorUsuario('Registro no encontrado', 404);
  return {
    ...e, habitacion: habJSON(get('SELECT * FROM habitaciones WHERE id=?', e.habitacion_id)),
    cargos: all('SELECT * FROM cargos WHERE estancia_id=? ORDER BY fecha', e.id),
    pagos: all('SELECT p.*, u.nombre usuario FROM pagos p LEFT JOIN usuarios u ON u.id=p.usuario_id WHERE estancia_id=? ORDER BY fecha', e.id),
    visitantes: all('SELECT * FROM visitantes WHERE estancia_id=? ORDER BY entrada DESC', e.id),
    depositos: all('SELECT d.*, u.nombre usuario FROM depositos d LEFT JOIN usuarios u ON u.id=d.usuario_id WHERE estancia_id=? ORDER BY d.id', e.id).map(({ firma, ...d }) => ({ ...d, firmado: !!firma })),
    contratos: all('SELECT id, folio, fecha FROM contratos WHERE estancia_id=? ORDER BY id DESC', e.id),
  };
});
ruta('PUT', '/api/estancias/:id', 'registrar', ({ p, body }) => {
  const e = estanciaActiva(p.id);
  run('UPDATE estancias SET huesped=COALESCE(?,huesped), telefono=?, identificacion=?, procedencia=?, placas=?, personas=?, notas=?, domicilio=? WHERE id=?',
    txt(body.huesped, 100), txt(body.telefono, 30), txt(body.identificacion, 60), txt(body.procedencia, 80), txt(body.placas, 20), Math.min(ent(body.personas, 1), 50), txt(body.notas, 300), txt(body.domicilio, 200), e.id);
});
ruta('POST', '/api/estancias/:id/extender', 'registrar', ({ p, body, u }) => tx(() => {
  const e = estanciaActiva(p.id), n = Math.min(ent(body.cantidad, 1), 365);
  const nueva = MODALIDADES.includes(body.modalidad) ? body.modalidad : e.modalidad;
  const inicio = e.inicio_tramo || e.entrada, previo = e.hospedaje_previo || 0;
  let importe;
  if (nueva !== e.modalidad) {
    // Cambio de tipo de renta (ej. de día a semana): lo ya generado se conserva y la nueva renta empieza donde terminaba la anterior
    const h = get('SELECT * FROM habitaciones WHERE id=?', e.habitacion_id);
    const precio = body.precio !== undefined && body.precio !== '' ? num(body.precio) : precioDe(h, nueva);
    if (!(precio > 0)) throw new ErrorUsuario('Esta habitación no tiene precio por ' + NOMBRE_MOD[nueva] + '. Escríbalo en "Precio".');
    const desde = e.salida_prevista, total = r2(e.total_hospedaje + precio * n);
    run('UPDATE estancias SET modalidad=?, cantidad=?, precio=?, hospedaje_previo=?, inicio_tramo=?, total_hospedaje=?, salida_prevista=? WHERE id=?',
      nueva, n, precio, e.total_hospedaje, desde, total, salidaPrevista(desde, nueva, n, cfg('hora_salida'), e.hora_checkout), e.id);
    anotarRenta(e.id, u.id, nueva, n, precio, 'cambio');
    importe = precio * n;
  } else {
    const cant = e.cantidad + n, precio = body.precio !== undefined && body.precio !== '' ? num(body.precio) : e.precio;
    // Si cambian el precio en la extensión, lo anterior se queda al precio anterior
    if (precio !== e.precio) {
      run('UPDATE estancias SET cantidad=?, precio=?, hospedaje_previo=?, inicio_tramo=?, total_hospedaje=?, salida_prevista=? WHERE id=?',
        n, precio, e.total_hospedaje, e.salida_prevista, r2(e.total_hospedaje + precio * n), salidaPrevista(e.salida_prevista, e.modalidad, n, cfg('hora_salida'), e.hora_checkout), e.id);
    } else {
      run('UPDATE estancias SET cantidad=?, total_hospedaje=?, salida_prevista=? WHERE id=?', cant, r2(previo + e.precio * cant), sumarPeriodos(e, inicio, cant, n), e.id);
    }
    anotarRenta(e.id, u.id, e.modalidad, n, precio, 'extension');
    importe = precio * n;
  }
  const pago = body.metodo ? pagar(body.pago ?? importe, body.metodo, 'hospedaje', e.id, null, u.id, nueva !== e.modalidad ? 'Cambio a renta por ' + NOMBRE_MOD[nueva] : 'Extensión', body.usd, body.partes) : null;
  return { ok: true, pago };
}));
ruta('POST', '/api/estancias/:id/pago', 'caja', ({ p, body, u }) => {
  const e = estanciaActiva(p.id);
  if (!(num(body.monto) > 0)) throw new ErrorUsuario('Escriba un monto mayor a cero');
  return pagar(body.monto, body.metodo, 'hospedaje', e.id, null, u.id, body.nota === 'anticipo' ? 'Anticipo' : 'Abono', body.usd, body.partes);
});
ruta('POST', '/api/estancias/:id/cargo', 'registrar', ({ p, body, u }) => tx(() => {
  const e = estanciaActiva(p.id), tipo = EXTRAS.includes(body.tipo) ? body.tipo : null;
  if (!tipo) throw new ErrorUsuario('Elija qué se va a cobrar');
  const cant = Math.max(1, Math.min(ent(body.cantidad, 1), 50)), unit = num(body.monto), imp = r2(unit * cant);
  if (!(imp > 0)) throw new ErrorUsuario('Escriba el monto');
  const desc = txt(body.descripcion, 120) || TIPOS_CARGO[tipo];
  const c = cargar(e.id, tipo, desc, imp, cant, u.id);
  if (tipo === 'mascota') run('UPDATE estancias SET mascotas=COALESCE(mascotas,0)+? WHERE id=?', cant, e.id);
  run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), e.habitacion_id, 'ocupada', `${desc}: $${imp.toFixed(2)}${txt(body.nota, 150) ? ' · ' + txt(body.nota, 150) : ''}`, u.id);
  const pago = body.cobrar && body.metodo ? pagar(imp, body.metodo, tipo, e.id, null, u.id, desc, body.usd, body.partes) : null;
  return { id: c.id, pago };
}));
ruta('DELETE', '/api/cargos/:id', 'autorizar', ({ p, u }) => tx(() => {
  const c = get('SELECT * FROM cargos WHERE id=?', Number(p.id));
  if (!c || c.venta_id) throw new ErrorUsuario('Ese cargo no se puede quitar aquí (las ventas se cancelan en Tienda)');
  const e = estanciaActiva(c.estancia_id);
  if (get('SELECT COALESCE(SUM(monto),0) t FROM pagos WHERE estancia_id=? AND concepto=?', e.id, c.tipo).t > get('SELECT COALESCE(SUM(importe),0) t FROM cargos WHERE estancia_id=? AND tipo=? AND id<>?', e.id, c.tipo, c.id).t + 0.009)
    throw new ErrorUsuario('Ese cargo ya se pagó. Para devolverlo registre un egreso de caja.');
  run('DELETE FROM cargos WHERE id=?', c.id);
  run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), e.habitacion_id, 'ocupada', `Se quitó: ${c.descripcion} ($${num(c.importe).toFixed(2)})`, u.id);
}));
ruta('POST', '/api/estancias/:id/cambiar', 'registrar', ({ p, body, u }) => tx(() => {
  const e = estanciaActiva(p.id), nueva = get("SELECT * FROM habitaciones WHERE id=? AND activo=1 AND estado='libre'", Number(body.habitacion_id));
  if (!nueva) throw new ErrorUsuario('La habitación nueva no está disponible');
  run("UPDATE habitaciones SET estado='limpieza' WHERE id=?", e.habitacion_id);
  run("UPDATE habitaciones SET estado='ocupada' WHERE id=?", nueva.id);
  run('UPDATE estancias SET habitacion_id=? WHERE id=?', nueva.id, e.id);
  run('UPDATE visitantes SET habitacion_id=? WHERE estancia_id=? AND salida IS NULL', nueva.id, e.id);
  run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), e.habitacion_id, 'limpieza', 'Cambio de habitación del huésped', u.id);
}));
ruta('POST', '/api/estancias/:id/salida', 'registrar', ({ p, body, u }) => tx(() => {
  const e = resumenEstancia(estanciaActiva(p.id));
  let pago = null;
  if (e.saldo > 0) {
    if (!body.metodo) throw new ErrorUsuario('El huésped debe ' + e.saldo.toFixed(2) + '. Elija cómo paga.');
    pago = pagar(e.saldo, body.metodo, 'hospedaje', e.id, null, u.id, 'Liquidación al salir', body.usd, body.partes);
  }
  const t = ahora();
  run('UPDATE estancias SET activa=0, salida_real=? WHERE id=?', t, e.id);
  run('UPDATE visitantes SET salida=? WHERE estancia_id=? AND salida IS NULL', t, e.id);
  run("UPDATE habitaciones SET estado='limpieza' WHERE id=?", e.habitacion_id);
  run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', t, e.habitacion_id, 'limpieza', 'Salida del huésped', u.id);
  return { id: e.id, pago };
}));
ruta('GET', '/api/estancias', 'sesion', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d, b = '%' + (q.q || '') + '%';
  return all(`SELECT e.*, hb.numero FROM estancias e JOIN habitaciones hb ON hb.id=e.habitacion_id
    WHERE (substr(e.entrada,1,10) <= ? AND COALESCE(substr(e.salida_real,1,10),'9999') >= ?) AND (e.huesped LIKE ? OR e.placas LIKE ? OR hb.numero LIKE ?)
    ORDER BY e.entrada DESC LIMIT 500`, h, d, b, b, b).map(resumenEstancia);
});

// ---------- Firmas y fotos ----------
function firma(v) {
  if (!v) return null;
  if (!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(v) || v.length > 600000) throw new ErrorUsuario('La firma no es válida');
  return v;
}
function guardarFotos(lista, mantId, tipo, uid) {
  for (const f of (Array.isArray(lista) ? lista : []).slice(0, 8)) {
    const m = /^data:image\/(jpeg|png);base64,([A-Za-z0-9+/=]+)$/.exec(String(f));
    if (!m) throw new ErrorUsuario('Una de las fotos no es válida');
    const buf = Buffer.from(m[2], 'base64');
    if (buf.length > 6 * 1024 * 1024) throw new ErrorUsuario('Una foto pesa demasiado');
    const archivo = `m${mantId}_${Date.now()}_${crypto.randomBytes(4).toString('hex')}.${m[1] === 'png' ? 'png' : 'jpg'}`;
    fs.writeFileSync(path.join(FOTOS_DIR, archivo), buf);
    run('INSERT INTO mant_fotos(mant_id,tipo,archivo,fecha,usuario_id) VALUES(?,?,?,?,?)', mantId, tipo, archivo, ahora(), uid);
  }
}

// ---------- Depósitos ----------
function recibirDeposito(eid, monto, metodo, uid, usd, partes) {
  monto = num(monto);
  if (!(monto > 0)) throw new ErrorUsuario('Escriba el monto del depósito');
  const t = turnoCaja(uid), tc = tcDe(t), folio = siguienteFolio('deposito');
  const rp = repartir(monto, partesDe(monto, metodo, usd, partes, tc), tc);
  let id = null;
  for (const f of rp.filas) {
    const r = run('INSERT INTO depositos(estancia_id,fecha,tipo,monto,metodo,folio,usuario_id,turno_id,usd,tc,cambio) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
      eid, ahora(), 'recibido', f.monto, f.metodo, folio, uid, t?.id ?? null, f.usd, f.usd ? tc : 0, f.cambio);
    id = id || r.id;
    if (EN_CAJA.includes(f.metodo)) pedirCajon();
  }
  if (id) run('UPDATE depositos SET recibido=? WHERE id=?', rp.total, id);
  return { id, cambio: rp.cambio };
}
ruta('POST', '/api/estancias/:id/deposito', 'depositos', ({ p, body, u }) => {
  const e = estanciaActiva(p.id);
  return recibirDeposito(e.id, body.monto, body.metodo, u.id, body.usd, body.partes);
});
// Al desocupar: se retiene lo de los daños y se devuelve el resto
ruta('POST', '/api/estancias/:id/deposito/liquidar', 'depositos', ({ p, body, u }) => tx(() => {
  const e = resumenEstancia(get('SELECT * FROM estancias WHERE id=?', Number(p.id)));
  if (!e) throw new ErrorUsuario('Registro no encontrado', 404);
  const retener = num(body.retener), devolver = num(body.devolver);
  if (retener < 0 || devolver < 0) throw new ErrorUsuario('Montos inválidos');
  if (!(retener + devolver > 0)) throw new ErrorUsuario('Escriba cuánto se retiene o se devuelve');
  if (retener + devolver > e.deposito_saldo + 0.001) throw new ErrorUsuario('Solo quedan ' + e.deposito_saldo.toFixed(2) + ' de depósito');
  const out = {};
  if (retener > 0) {
    const motivo = txt(body.motivo, 300);
    if (!motivo) throw new ErrorUsuario('Escriba el motivo de la retención (qué daños o faltantes hubo)');
    let tk = null;
    if (body.crear_reporte) tk = nuevoReporte({ habitacion_id: e.habitacion_id, titulo: 'Daños al desocupar: ' + motivo.slice(0, 80), descripcion: motivo, prioridad: 'alta', estancia_id: e.id }, u.id);
    out.retenido = run('INSERT INTO depositos(estancia_id,fecha,tipo,monto,motivo,ticket_id,folio,usuario_id) VALUES(?,?,?,?,?,?,?,?)', e.id, ahora(), 'retenido', retener, motivo, tk, siguienteFolio('deposito'), u.id).id;
  }
  if (devolver > 0) {
    if (!METODOS.includes(body.metodo)) throw new ErrorUsuario('Elija cómo se devuelve el depósito');
    const t = turnoCaja(u.id), tc = tcDe(t), dol = body.metodo === 'dolares' ? r2(devolver / tc) : 0;
    if (EN_CAJA.includes(body.metodo)) pedirCajon();
    out.devuelto = run('INSERT INTO depositos(estancia_id,fecha,tipo,monto,metodo,recibe,firma,folio,usuario_id,turno_id,usd,tc) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
      e.id, ahora(), 'devuelto', devolver, body.metodo, txt(body.recibe, 100) || e.huesped, firma(body.firma), siguienteFolio('deposito'), u.id, t?.id ?? null, dol, dol ? tc : 0).id;
  }
  return out;
}));
ruta('GET', '/api/depositos/:id', 'sesion', ({ p }) => {
  const d = get('SELECT d.*, u.nombre usuario FROM depositos d LEFT JOIN usuarios u ON u.id=d.usuario_id WHERE d.id=?', Number(p.id));
  if (!d) throw new ErrorUsuario('No existe', 404);
  // Un depósito pagado con varios métodos se guarda en varias filas con el mismo folio: el recibo las junta
  if (d.tipo === 'recibido' && d.folio) {
    const g = all("SELECT * FROM depositos WHERE estancia_id=? AND folio=? AND tipo='recibido'", d.estancia_id, d.folio);
    if (g.length > 1) Object.assign(d, { monto: r2(g.reduce((s, x) => s + x.monto, 0)), usd: r2(g.reduce((s, x) => s + (x.usd || 0), 0)), tc: Math.max(...g.map((x) => x.tc || 0)), metodo: 'mixto' });
    const rec = Math.max(...g.map((x) => x.recibido || 0));
    d.recibido = rec > 0 ? rec : r2(d.monto + g.reduce((s, x) => s + (x.cambio || 0), 0));
    d.cambio_total = r2(d.recibido - d.monto);
  }
  const e = resumenEstancia(get('SELECT * FROM estancias WHERE id=?', d.estancia_id));
  return { ...d, estancia: e, habitacion: habJSON(get('SELECT * FROM habitaciones WHERE id=?', e.habitacion_id)), movimientos: all('SELECT id,fecha,tipo,monto,metodo,motivo FROM depositos WHERE estancia_id=? ORDER BY id', e.id) };
});

// ---------- Gastos ----------
ruta('GET', '/api/gastos', 'sesion', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d;
  return all(`SELECT g.id,g.folio,g.fecha,g.concepto,g.categoria,g.grupo,g.empleado_id,g.proveedor_id,g.factura,g.periodo,em.nombre empleado,pv.nombre proveedor,g.monto,g.metodo,g.entrega,g.recibe,g.nota,g.cancelado,hb.numero, u.nombre usuario,
    (g.firma_recibe IS NOT NULL) firmado FROM gastos g LEFT JOIN habitaciones hb ON hb.id=g.habitacion_id LEFT JOIN usuarios u ON u.id=g.usuario_id
    LEFT JOIN empleados em ON em.id=g.empleado_id LEFT JOIN proveedores pv ON pv.id=g.proveedor_id
    WHERE substr(g.fecha,1,10) BETWEEN ? AND ? ORDER BY g.fecha DESC`, d, h);
});
ruta('GET', '/api/gastos/:id', 'sesion', ({ p }) => {
  const g = get('SELECT g.*, hb.numero, u.nombre usuario, em.nombre empleado, pv.nombre proveedor FROM gastos g LEFT JOIN habitaciones hb ON hb.id=g.habitacion_id LEFT JOIN usuarios u ON u.id=g.usuario_id LEFT JOIN empleados em ON em.id=g.empleado_id LEFT JOIN proveedores pv ON pv.id=g.proveedor_id WHERE g.id=?', Number(p.id));
  if (!g) throw new ErrorUsuario('No existe', 404);
  return g;
});
// ---------- Clasificación de gastos (1.5) ----------
function clasificacion() {
  return String(cfg('gastos_clasificacion') || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((l) => {
    const i = l.indexOf(':'), grupo = (i >= 0 ? l.slice(0, i) : l).trim();
    return { grupo, conceptos: (i >= 0 ? l.slice(i + 1) : '').split(',').map((x) => x.trim()).filter(Boolean) };
  }).filter((g) => g.grupo);
}
// Categorías de versiones anteriores
const GRUPO_VIEJO = { 'mantenimiento': 'Mantenimiento', 'limpieza': 'Compras', 'servicios (luz, agua, gas)': 'Servicios', 'internet y cable': 'Servicios', 'insumos y blancos': 'Compras', 'sueldos': 'Nómina y personal', 'gastos fijos': 'Servicios' };
function grupoDe(categoria) {
  const c = String(categoria || '').trim().toLowerCase();
  if (!c) return 'Otros';
  for (const g of clasificacion()) if (g.grupo.toLowerCase() === c || g.conceptos.some((x) => x.toLowerCase() === c)) return g.grupo;
  return GRUPO_VIEJO[c] || 'Otros';
}
// Gastos guardados antes de la 1.5: se les asigna su clasificación
for (const g of all("SELECT id, categoria FROM gastos WHERE grupo IS NULL OR grupo=''")) run('UPDATE gastos SET grupo=? WHERE id=?', grupoDe(g.categoria), g.id);
function crearGasto(b, uid) {
  const concepto = txt(b.concepto, 200), monto = num(b.monto);
  if (!concepto) throw new ErrorUsuario('Escriba el concepto del gasto');
  if (!(monto > 0)) throw new ErrorUsuario('Escriba el monto del gasto');
  if (!METODOS_GASTO.includes(b.metodo)) throw new ErrorUsuario('Elija cómo se pagó');
  // Si quien lo registra tiene turno abierto, el gasto sale de su caja (salvo que se indique que se pagó por fuera)
  const t = b.fuera_de_caja ? null : turnoAbierto(uid);
  if (t && b.metodo === 'efectivo') pedirCajon();
  const categoria = txt(b.categoria, 60), grupo = txt(b.grupo, 60) || grupoDe(categoria);
  const emp = Number(b.empleado_id) ? get('SELECT id, nombre FROM empleados WHERE id=?', Number(b.empleado_id)) : null;
  const prov = Number(b.proveedor_id) ? get('SELECT id, nombre FROM proveedores WHERE id=?', Number(b.proveedor_id)) : null;
  if (!b.recibe && (emp || prov)) b.recibe = (emp || prov).nombre;
  return run(`INSERT INTO gastos(folio,fecha,concepto,categoria,monto,metodo,entrega,recibe,firma_entrega,firma_recibe,habitacion_id,ticket_id,nota,usuario_id,turno_id,fijo_id,grupo,empleado_id,proveedor_id,factura,periodo)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, siguienteFolio('gasto'), ahora(), concepto, categoria, monto, b.metodo, txt(b.entrega, 100), txt(b.recibe, 100),
    firma(b.firma_entrega), firma(b.firma_recibe), Number(b.habitacion_id) || null, Number(b.ticket_id) || null, txt(b.nota, 300), uid, t?.id ?? null, Number(b.fijo_id) || null, grupo, emp?.id ?? null, prov?.id ?? null, txt(b.factura, 80), txt(b.periodo, 80)).id;
}

// ---------- Empleados y proveedores (1.6) ----------
const PERIODOS_PAGO = ['semanal', 'catorcenal', 'quincenal', 'mensual'];
function limpiarEmp(b) {
  const d = { nombre: txt(b.nombre, 100), puesto: txt(b.puesto, 60), telefono: txt(b.telefono, 30), ingreso: /^\d{4}-\d{2}-\d{2}$/.test(b.ingreso || '') ? b.ingreso : null,
    sueldo: num(b.sueldo), periodo_pago: PERIODOS_PAGO.includes(b.periodo_pago) ? b.periodo_pago : 'semanal', nss: txt(b.nss, 20), rfc: txt(b.rfc, 15), curp: txt(b.curp, 20),
    domicilio: txt(b.domicilio, 200), emergencia: txt(b.emergencia, 120), notas: txt(b.notas, 300) };
  if (!d.nombre) throw new ErrorUsuario('Escriba el nombre del empleado');
  return d;
}
const EMP_COLS = 'nombre=?,puesto=?,telefono=?,ingreso=?,sueldo=?,periodo_pago=?,nss=?,rfc=?,curp=?,domicilio=?,emergencia=?,notas=?';
const empVals = (d) => [d.nombre, d.puesto, d.telefono, d.ingreso, d.sueldo, d.periodo_pago, d.nss, d.rfc, d.curp, d.domicilio, d.emergencia, d.notas];
function limpiarProv(b) {
  const d = { nombre: txt(b.nombre, 100), contacto: txt(b.contacto, 100), telefono: txt(b.telefono, 30), correo: txt(b.correo, 100), rfc: txt(b.rfc, 15), surte: txt(b.surte, 200),
    banco: txt(b.banco, 60), cuenta: txt(b.cuenta, 40), notas: txt(b.notas, 300) };
  if (!d.nombre) throw new ErrorUsuario('Escriba el nombre del proveedor');
  return d;
}
const PROV_COLS = 'nombre=?,contacto=?,telefono=?,correo=?,rfc=?,surte=?,banco=?,cuenta=?,notas=?';
const provVals = (d) => [d.nombre, d.contacto, d.telefono, d.correo, d.rfc, d.surte, d.banco, d.cuenta, d.notas];
// Lista para elegir en "Nuevo gasto" (sin datos privados): cualquiera que registre gastos
ruta('GET', '/api/empleados/lista', 'gastos', () => all('SELECT id, nombre, puesto, sueldo, periodo_pago FROM empleados WHERE activo=1 ORDER BY nombre'));
ruta('GET', '/api/proveedores/lista', 'gastos', () => all('SELECT id, nombre, surte FROM proveedores WHERE activo=1 ORDER BY nombre'));
// Catálogo completo con lo pagado en el periodo
const pagadoA = (col, id, d, h) => get(`SELECT COUNT(*) n, COALESCE(SUM(monto),0) t FROM gastos WHERE ${col}=? AND cancelado=0 AND substr(fecha,1,10) BETWEEN ? AND ?`, id, d, h);
ruta('GET', '/api/empleados', 'personal', ({ q }) => {
  const d = q.desde || hoy().slice(0, 8) + '01', h = q.hasta || hoy();
  return all(`SELECT * FROM empleados WHERE ${q.todos ? '1=1' : 'activo=1'} ORDER BY activo DESC, nombre`).map((e) => ({ ...e, pagado: pagadoA('empleado_id', e.id, d, h) }));
});
ruta('GET', '/api/proveedores', 'personal', ({ q }) => {
  const d = q.desde || hoy().slice(0, 8) + '01', h = q.hasta || hoy();
  return all(`SELECT * FROM proveedores WHERE ${q.todos ? '1=1' : 'activo=1'} ORDER BY activo DESC, nombre`).map((x) => ({ ...x, pagado: pagadoA('proveedor_id', x.id, d, h) }));
});
function historial(col, id) {
  const pagos = all(`SELECT id, folio, fecha, concepto, grupo, categoria, metodo, monto, factura, periodo FROM gastos WHERE ${col}=? AND cancelado=0 ORDER BY fecha DESC LIMIT 300`, id);
  const porTipo = {}; for (const g of pagos) porTipo[g.categoria || 'Otros'] = r2((porTipo[g.categoria || 'Otros'] || 0) + g.monto);
  return { pagos, porTipo, total: r2(pagos.reduce((s, g) => s + g.monto, 0)) };
}
ruta('GET', '/api/empleados/:id', 'personal', ({ p }) => { const e = get('SELECT * FROM empleados WHERE id=?', Number(p.id)); if (!e) throw new ErrorUsuario('No existe', 404); return { ...e, ...historial('empleado_id', e.id) }; });
ruta('GET', '/api/proveedores/:id', 'personal', ({ p }) => { const x = get('SELECT * FROM proveedores WHERE id=?', Number(p.id)); if (!x) throw new ErrorUsuario('No existe', 404); return { ...x, ...historial('proveedor_id', x.id) }; });
ruta('POST', '/api/empleados', 'personal', ({ body }) => ({ id: run(`INSERT INTO empleados(nombre,puesto,telefono,ingreso,sueldo,periodo_pago,nss,rfc,curp,domicilio,emergencia,notas,creado) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`, ...empVals(limpiarEmp(body)), ahora()).id }));
ruta('PUT', '/api/empleados/:id', 'personal', ({ body, p }) => { run(`UPDATE empleados SET ${EMP_COLS}, activo=? WHERE id=?`, ...empVals(limpiarEmp(body)), body.activo === false || body.activo === 0 ? 0 : 1, Number(p.id)); });
ruta('POST', '/api/proveedores', 'personal', ({ body }) => ({ id: run(`INSERT INTO proveedores(nombre,contacto,telefono,correo,rfc,surte,banco,cuenta,notas,creado) VALUES(?,?,?,?,?,?,?,?,?,?)`, ...provVals(limpiarProv(body)), ahora()).id }));
ruta('PUT', '/api/proveedores/:id', 'personal', ({ body, p }) => { run(`UPDATE proveedores SET ${PROV_COLS}, activo=? WHERE id=?`, ...provVals(limpiarProv(body)), body.activo === false || body.activo === 0 ? 0 : 1, Number(p.id)); });
// Nómina de todos de una vez: un gasto por empleado (sueldo + bonos), con un mismo periodo
ruta('POST', '/api/nomina', 'personal', ({ body, u }) => tx(() => {
  const lineas = Array.isArray(body.lineas) ? body.lineas : [], periodo = txt(body.periodo, 80), metodo = METODOS_GASTO.includes(body.metodo) ? body.metodo : 'efectivo';
  if (!periodo) throw new ErrorUsuario('Escriba el periodo que se paga (ej. Semana del 6 al 12 de octubre)');
  const grupoNom = clasificacion().find((g) => /n[oó]mina|personal/i.test(g.grupo))?.grupo || 'Nómina y personal';
  const ids = [];
  for (const l of lineas) {
    const e = get('SELECT * FROM empleados WHERE id=? AND activo=1', Number(l.empleado_id)); if (!e) continue;
    for (const [cat, monto] of [['Nómina', l.sueldo], ['Bono de puntualidad', l.puntualidad], ['Bonos para empleados', l.bono], ['Días festivos', l.festivos], ['Tiempo extra', l.extra]]) {
      if (!(num(monto) > 0)) continue;
      ids.push(crearGasto({ concepto: `${cat} · ${e.nombre} · ${periodo}`, categoria: cat, grupo: grupoNom, monto, metodo, empleado_id: e.id, periodo, recibe: e.nombre, entrega: u.nombre, fuera_de_caja: !!body.fuera_de_caja,
        nota: num(l.descuento) > 0 && cat === 'Nómina' ? 'Descuento aplicado: $' + num(l.descuento).toFixed(2) + (ent(l.retardos) || ent(l.faltas) ? ` (${ent(l.retardos)} retardo(s), ${ent(l.faltas)} falta(s))` : '') : null }, u.id));
    }
    // 1.8: renglón de nómina con sus descuentos de asistencia (para reportes y cierre de mes)
    run('INSERT INTO nomina_lineas(fecha,periodo,empleado_id,sueldo,descuento,desc_retardos,desc_faltas,retardos,faltas,puntualidad,bono,festivos,extra,total,usuario_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
      ahora(), periodo, e.id, num(l.bruto ?? l.sueldo), num(l.descuento), num(l.desc_retardos), num(l.desc_faltas), ent(l.retardos), ent(l.faltas), num(l.puntualidad), num(l.bono), num(l.festivos), num(l.extra),
      r2(num(l.sueldo) + num(l.puntualidad) + num(l.bono) + num(l.festivos) + num(l.extra)), u.id);
  }
  if (!ids.length) throw new ErrorUsuario('No hay montos para pagar');
  return { gastos: ids.length };
}));

// ---------- Control de asistencia (1.7) ----------
const TIPOS_CHECADA = { entrada: 'Entrada', descanso: 'Salida a comer', regreso: 'Regreso de comer', salida: 'Salida' };
const TIPOS_INCID = { vacaciones: 'Vacaciones', permiso_goce: 'Permiso con goce', permiso_sin_goce: 'Permiso sin goce', incapacidad: 'Incapacidad', falta_justificada: 'Falta justificada', descanso_extra: 'Descanso extra' };
const DIAS_PERIODO = { semanal: 7, catorcenal: 14, quincenal: 15, mensual: 30 };
const minDe = (hhmm) => { const [h, m] = String(hhmm || '').split(':').map(Number); return Number.isFinite(h) ? h * 60 + (m || 0) : null; };
const minDeFecha = (f) => { const t = String(f).slice(11, 16); return minDe(t); };
const fechaMas = (d, n) => { const x = aFecha(d); x.setDate(x.getDate() + n); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`; };
function horarioDe(e) { try { const h = JSON.parse(e.horario || 'null'); return h && typeof h === 'object' ? h : null; } catch { return null; } }
// Qué le toca: entrada → comida (si tiene tiempo de comida y aún falta más de 1 hora para su salida) → regreso → salida
function siguienteTipo(empId) {
  const cs = all("SELECT tipo FROM checadas WHERE empleado_id=? AND anulada=0 AND substr(fecha,1,10)=? ORDER BY fecha", empId, hoy()), u = cs[cs.length - 1];
  if (!u || u.tipo === 'salida') return 'entrada';
  if (u.tipo === 'descanso') return 'regreso';
  if (u.tipo === 'regreso') return 'salida';
  const e = get('SELECT horario FROM empleados WHERE id=?', empId), H = e ? horarioDe(e) : null, h = H ? H[new Date().getDay()] : null;
  if (h && num(h.descanso) > 0 && !cs.some((c) => c.tipo === 'descanso') && minDe(h.salida) !== null && minDeFecha(ahora()) < minDe(h.salida) - 60) return 'descanso';
  return 'salida';
}
const metodoChecador = () => (['nip', 'huella', 'ambos'].includes(cfg('asis_metodo')) ? cfg('asis_metodo') : 'ambos');
const puedeAsis = (u, ...k) => u.perm && k.some((x) => u.perm.has(x));
// Cálculo de un periodo para un empleado: estado de cada día, retardos, faltas y descuentos
function asistenciaDe(e, desde, hasta) {
  const C = { tol: num(cfg('asis_tolerancia')), modo: cfg('asis_desc_modo'), monto: num(cfg('asis_desc_monto')), doble: cfg('asis_desc_doble') === '1', nFalta: ent(cfg('asis_retardos_falta')), faltaDesc: cfg('asis_falta_desc') !== '0', festPago: num(cfg('asis_festivo_pago')) };
  const H = horarioDe(e), diario = e.sueldo ? e.sueldo / (DIAS_PERIODO[e.periodo_pago] || 7) : 0;
  const fest = Object.fromEntries(all('SELECT * FROM festivos WHERE fecha BETWEEN ? AND ?', desde, hasta).map((x) => [x.fecha, x]));
  const inc = all('SELECT * FROM incidencias WHERE empleado_id=? AND hasta>=? AND desde<=?', e.id, desde, hasta);
  const chk = all('SELECT * FROM checadas WHERE empleado_id=? AND anulada=0 AND substr(fecha,1,10) BETWEEN ? AND ? ORDER BY fecha', e.id, desde, hasta);
  const porDia = {}; for (const c of chk) (porDia[c.fecha.slice(0, 10)] ||= []).push(c);
  const hoyS = hoy(), ahoraMin = minDeFecha(ahora()), dias = [];
  const R = { trabajados: 0, retardos: 0, min_tarde: 0, faltas: 0, faltas_retardos: 0, descansos: 0, festivos: 0, festivos_trabajados: 0, incidencias: {}, min_trabajados: 0, salidas_antes: 0,
    desc_retardos: 0, desc_faltas: 0, pago_festivos: 0, sueldo_diario: r2(diario) };
  for (let d = desde; d <= hasta; d = fechaMas(d, 1)) {
    const dow = aFecha(d).getDay(), h = H ? H[dow] : undefined, f = fest[d], i = inc.find((x) => x.desde <= d && x.hasta >= d), cs = porDia[d] || [];
    const ent1 = cs.find((c) => c.tipo === 'entrada'), sal = [...cs].reverse().find((c) => c.tipo === 'salida');
    let desc = 0; for (let k = 0; k < cs.length; k++) if (cs[k].tipo === 'descanso') { const r = cs.slice(k + 1).find((c) => c.tipo === 'regreso'); if (r) desc += minDeFecha(r.fecha) - minDeFecha(cs[k].fecha); }
    const trab = ent1 && sal && sal.fecha > ent1.fecha ? Math.max(0, minDeFecha(sal.fecha) - minDeFecha(ent1.fecha) - desc) : 0;
    const dia = { fecha: d, dow, horario: h || null, entrada: ent1?.fecha || null, salida: sal?.fecha || null, descanso_min: desc, trabajado_min: trab, checadas: cs.map((c) => ({ id: c.id, fecha: c.fecha, tipo: c.tipo, metodo: c.metodo })), estado: '', tarde: 0, descuento: 0, extra: 0, nota: '' };
    if (i) { dia.estado = i.tipo; dia.nota = i.nota || ''; R.incidencias[i.tipo] = (R.incidencias[i.tipo] || 0) + 1; if (i.tipo === 'permiso_sin_goce') { dia.descuento = diario; R.desc_faltas += diario; } }
    else if (f && f.descansa) { if (ent1) { dia.estado = 'festivo_trabajado'; dia.extra = diario * C.festPago; R.pago_festivos += dia.extra; R.festivos_trabajados++; R.trabajados++; } else { dia.estado = 'festivo'; R.festivos++; } dia.nota = f.nombre || ''; }
    else if (H === null) { dia.estado = ent1 ? 'asistencia' : 'sin_horario'; if (ent1) R.trabajados++; }
    else if (!h) { dia.estado = ent1 ? 'trabajo_descanso' : 'descanso'; if (ent1) R.trabajados++; else R.descansos++; }
    else if (!ent1) {
      const paso = d < hoyS || (d === hoyS && ahoraMin > (minDe(h.salida) ?? 1440));
      dia.estado = paso ? 'falta' : 'pendiente';
      if (paso) { R.faltas++; if (C.faltaDesc) { dia.descuento = diario; R.desc_faltas += diario; } }
    } else {
      R.trabajados++;
      const tarde = minDeFecha(ent1.fecha) - minDe(h.entrada);
      if (tarde > C.tol) {
        dia.estado = 'retardo'; dia.tarde = tarde; R.retardos++; R.min_tarde += tarde;
        const jornada = Math.max(60, (minDe(h.salida) - minDe(h.entrada)) - (num(h.descanso) || 0));
        const base = C.modo === 'fijo' ? C.monto : C.modo === 'minutos' ? (diario / jornada) * tarde : 0;
        dia.descuento = base * (C.doble ? 2 : 1); R.desc_retardos += dia.descuento;
      } else dia.estado = 'asistencia';
      if (sal && minDe(h.salida) !== null && minDeFecha(sal.fecha) < minDe(h.salida) - C.tol && sal.fecha.slice(0, 10) === d) { R.salidas_antes++; dia.nota = 'Salió antes'; }
    }
    R.min_trabajados += trab;
    dias.push(dia);
  }
  if (C.nFalta > 0) { R.faltas_retardos = Math.floor(R.retardos / C.nFalta); R.desc_faltas += R.faltas_retardos * diario; }
  for (const k of ['desc_retardos', 'desc_faltas', 'pago_festivos']) R[k] = r2(R[k]);
  R.total_descuento = r2(R.desc_retardos + R.desc_faltas);
  for (const x of dias) { x.descuento = r2(x.descuento); x.extra = r2(x.extra); }
  return { dias, resumen: R };
}
const empAsis = (e) => ({ id: e.id, nombre: e.nombre, puesto: e.puesto, numero: e.numero, sueldo: e.sueldo, periodo_pago: e.periodo_pago, horario: horarioDe(e), tiene_pin: !!e.pin, tiene_huella: !!e.huella, activo: e.activo });
// Checador: número + NIP (y huella cuando se conecte el lector)
ruta('POST', '/api/asistencia/checar', 'sesion', ({ body, u }) => {
  if (!puedeAsis(u, 'checador', 'asistencia')) throw new ErrorUsuario('Este usuario no tiene permiso para usar el checador', 403);
  if (metodoChecador() === 'huella') throw new ErrorUsuario('El checador está configurado solo con huella');
  const numero = txt(body.numero, 20);
  if (!numero) throw new ErrorUsuario('Escriba su número de empleado');
  const e = get('SELECT * FROM empleados WHERE numero=? AND activo=1', numero);
  if (!e || !e.pin || !checkPass(String(body.pin || ''), e.pin)) throw new ErrorUsuario('Número o NIP incorrecto');
  return registrarChecada(e, body.tipo, 'nip', u);
});
function registrarChecada(e, tipoPedido, metodo, u) {
  const tipo = TIPOS_CHECADA[tipoPedido] ? tipoPedido : siguienteTipo(e.id);
  const ult = get('SELECT * FROM checadas WHERE empleado_id=? AND anulada=0 ORDER BY fecha DESC LIMIT 1', e.id);
  if (ult && ult.tipo === tipo && (new Date() - aFecha(ult.fecha)) < 120000) throw new ErrorUsuario(`${e.nombre}: ya registró "${TIPOS_CHECADA[tipo]}" hace un momento`);
  const fecha = ahora();
  run('INSERT INTO checadas(empleado_id,fecha,tipo,metodo,usuario_id) VALUES(?,?,?,?,?)', e.id, fecha, tipo, metodo, u.id);
  const H = horarioDe(e), h = H ? H[new Date().getDay()] : null;
  let aviso = '';
  if (tipo === 'entrada' && h && minDeFecha(fecha) - minDe(h.entrada) > num(cfg('asis_tolerancia'))) aviso = `Retardo de ${minDeFecha(fecha) - minDe(h.entrada)} minutos`;
  return { nombre: e.nombre, tipo, texto: TIPOS_CHECADA[tipo], fecha, aviso, siguiente: siguienteTipo(e.id), metodo };
}
// ---------- Lector de huellas DigitalPersona (programa auxiliar herramientas\huella.exe) ----------
const HUELLA_EXE = path.join(path.dirname(fileURLToPath(import.meta.url)), 'herramientas', 'huella.exe');
let lectorOcupado = false;
function huella(args, segundos) {
  if (process.platform !== 'win32' || !fs.existsSync(HUELLA_EXE)) return Promise.reject(new ErrorUsuario('El lector de huellas no está instalado en esta computadora. Use número y NIP.'));
  if (lectorOcupado) return Promise.reject(new ErrorUsuario('El lector está ocupado, intente en un momento'));
  lectorOcupado = true;
  return new Promise((ok, mal) => {
    execFile(HUELLA_EXE, args, { timeout: (segundos + 15) * 1000, windowsHide: true }, (err, stdout) => {
      lectorOcupado = false;
      const l = String(stdout || '').trim().split(/\r?\n/).filter(Boolean).pop();
      let r = null; try { r = JSON.parse(l); } catch { /* sin respuesta */ }
      if (!r) return mal(new ErrorUsuario(err?.killed ? 'El lector no respondió' : 'El lector no respondió (' + (err?.message || 'sin datos') + ')'));
      if (!r.ok) return mal(new ErrorUsuario(r.error || 'Error del lector'));
      ok(r);
    });
  });
}
ruta('GET', '/api/huella/estado', 'sesion', async ({ u }) => {
  if (!puedeAsis(u, 'checador', 'asistencia')) throw new ErrorUsuario('Sin permiso', 403);
  const metodo = metodoChecador();
  if (process.platform !== 'win32' || !fs.existsSync(HUELLA_EXE)) return { metodo, instalado: false, registradas: get("SELECT COUNT(*) n FROM empleados WHERE activo=1 AND huella IS NOT NULL").n };
  try { const r = await huella(['estado'], 5); return { metodo, instalado: true, lector: r.lector, registradas: get("SELECT COUNT(*) n FROM empleados WHERE activo=1 AND huella IS NOT NULL").n }; }
  catch (e) { return { metodo, instalado: true, error: e.message, registradas: get("SELECT COUNT(*) n FROM empleados WHERE activo=1 AND huella IS NOT NULL").n }; }
});
ruta('POST', '/api/huella/enrolar/:id', 'asistencia', async ({ p }) => {
  const e = get('SELECT id, nombre FROM empleados WHERE id=?', Number(p.id)); if (!e) throw new ErrorUsuario('No existe', 404);
  const r = await huella(['enrolar', '20'], 8 * 20);
  run('UPDATE empleados SET huella=? WHERE id=?', r.plantilla, e.id);
  return { ok: true, muestras: r.muestras };
});
ruta('DELETE', '/api/huella/:id', 'asistencia', ({ p }) => { run('UPDATE empleados SET huella=NULL WHERE id=?', Number(p.id)); });
ruta('POST', '/api/huella/checar', 'sesion', async ({ body, u }) => {
  if (!puedeAsis(u, 'checador', 'asistencia')) throw new ErrorUsuario('Este usuario no tiene permiso para usar el checador', 403);
  if (metodoChecador() === 'nip') throw new ErrorUsuario('El checador está configurado solo con número y NIP');
  const L = all('SELECT id, huella FROM empleados WHERE activo=1 AND huella IS NOT NULL');
  if (!L.length) throw new ErrorUsuario('Ningún empleado tiene huella registrada. Regístrelas en Asistencia → Empleados.');
  const tmp = path.join(os.tmpdir(), 'maxsel_huellas_' + process.pid + '.txt');
  fs.writeFileSync(tmp, L.map((x) => x.id + '\t' + x.huella).join('\n'), 'utf8');
  let r;
  try { r = await huella(['identificar', tmp, String(Math.min(30, Math.max(3, ent(body.segundos) || 10)))], 30); } finally { try { fs.unlinkSync(tmp); } catch { /* nada */ } }
  if (r.sinDedo) return { sinDedo: true };
  if (!r.id) return { noReconocida: true };
  const e = get('SELECT * FROM empleados WHERE id=? AND activo=1', Number(r.id));
  if (!e) return { noReconocida: true };
  return registrarChecada(e, body.tipo, 'huella', u);
});
// Quién está trabajando hoy
ruta('GET', '/api/asistencia/hoy', 'sesion', ({ u }) => {
  if (!puedeAsis(u, 'checador', 'asistencia')) throw new ErrorUsuario('Sin permiso', 403);
  const d = hoy();
  return all('SELECT * FROM empleados WHERE activo=1 ORDER BY nombre').map((e) => {
    const cs = all('SELECT fecha, tipo FROM checadas WHERE empleado_id=? AND anulada=0 AND substr(fecha,1,10)=? ORDER BY fecha', e.id, d);
    const a = puedeAsis(u, 'asistencia') ? asistenciaDe(e, d, d).dias[0] : null;
    return { id: e.id, nombre: e.nombre, puesto: e.puesto, ultima: cs[cs.length - 1] || null, checadas: cs, estado: a?.estado || null, tarde: a?.tarde || 0, horario: a?.horario || null };
  });
});
ruta('GET', '/api/asistencia/empleados', 'asistencia', () => all('SELECT * FROM empleados ORDER BY activo DESC, nombre').map(empAsis));
ruta('PUT', '/api/asistencia/empleados/:id', 'asistencia', ({ body, p }) => {
  const e = get('SELECT * FROM empleados WHERE id=?', Number(p.id)); if (!e) throw new ErrorUsuario('No existe', 404);
  const numero = txt(body.numero, 20);
  if (numero && get('SELECT id FROM empleados WHERE numero=? AND id<>?', numero, e.id)) throw new ErrorUsuario('Ese número ya lo tiene otro empleado');
  let horario = null;
  if (body.horario && typeof body.horario === 'object') {
    horario = {};
    for (let k = 0; k <= 6; k++) { const x = body.horario[k]; horario[k] = x && minDe(x.entrada) !== null && minDe(x.salida) !== null ? { entrada: x.entrada, salida: x.salida, descanso: ent(x.descanso) } : null; }
  }
  const pin = body.pin ? String(body.pin).trim() : '';
  if (pin && !/^\d{4,8}$/.test(pin)) throw new ErrorUsuario('El NIP debe ser de 4 a 8 números');
  run('UPDATE empleados SET numero=?, horario=?, pin=COALESCE(?, pin) WHERE id=?', numero, horario ? JSON.stringify(horario) : null, pin ? hashPass(pin) : null, e.id);
});
ruta('GET', '/api/asistencia/checadas', 'asistencia', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d, emp = Number(q.empleado_id) || 0;
  return all(`SELECT c.*, e.nombre, u.nombre usuario FROM checadas c JOIN empleados e ON e.id=c.empleado_id LEFT JOIN usuarios u ON u.id=c.usuario_id
    WHERE substr(c.fecha,1,10) BETWEEN ? AND ? AND (?=0 OR c.empleado_id=?) ORDER BY c.fecha DESC LIMIT 2000`, d, h, emp, emp);
});
// Registro manual (olvidó checar) o corrección
ruta('POST', '/api/asistencia/checadas', 'asistencia', ({ body, u }) => {
  const e = get('SELECT id FROM empleados WHERE id=?', Number(body.empleado_id)); if (!e) throw new ErrorUsuario('Elija al empleado');
  if (!TIPOS_CHECADA[body.tipo]) throw new ErrorUsuario('Elija el tipo');
  const f = String(body.fecha || '').replace('T', ' ');
  if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}/.test(f)) throw new ErrorUsuario('Escriba fecha y hora');
  return { id: run('INSERT INTO checadas(empleado_id,fecha,tipo,metodo,usuario_id,nota) VALUES(?,?,?,?,?,?)', e.id, f.slice(0, 16) + ':00', body.tipo, 'manual', u.id, txt(body.nota, 200) || 'Registro manual').id };
});
ruta('POST', '/api/asistencia/checadas/:id/anular', 'asistencia', ({ p }) => { run('UPDATE checadas SET anulada=1 WHERE id=?', Number(p.id)); });
ruta('GET', '/api/asistencia/reporte', 'asistencia', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d, emp = Number(q.empleado_id) || 0;
  if (d > h) throw new ErrorUsuario('La fecha inicial es mayor a la final');
  if ((aFecha(h) - aFecha(d)) / 86400000 > 370) throw new ErrorUsuario('Máximo un año por reporte');
  return all(`SELECT * FROM empleados WHERE (?=0 OR id=?) AND (activo=1 OR id IN (SELECT empleado_id FROM checadas WHERE substr(fecha,1,10) BETWEEN ? AND ?)) ORDER BY nombre`, emp, emp, d, h)
    .map((e) => ({ empleado: empAsis(e), ...asistenciaDe(e, d, h) }));
});
ruta('GET', '/api/festivos', 'sesion', ({ q }) => all('SELECT * FROM festivos WHERE substr(fecha,1,4)=? ORDER BY fecha', String(q.anio || hoy().slice(0, 4))));
ruta('POST', '/api/festivos', 'asistencia', ({ body }) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(body.fecha || '')) throw new ErrorUsuario('Elija la fecha');
  run('INSERT INTO festivos(fecha,nombre,descansa) VALUES(?,?,?) ON CONFLICT(fecha) DO UPDATE SET nombre=excluded.nombre, descansa=excluded.descansa', body.fecha, txt(body.nombre, 80) || 'Día festivo', body.descansa === false ? 0 : 1);
});
ruta('DELETE', '/api/festivos/:id', 'asistencia', ({ p }) => { run('DELETE FROM festivos WHERE id=?', Number(p.id)); });
// Días de descanso obligatorio (Ley Federal del Trabajo, art. 74)
ruta('POST', '/api/festivos/ley', 'asistencia', ({ body }) => {
  const y = ent(body.anio) || Number(hoy().slice(0, 4)), f2 = (m, d) => `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  const lunes = (m, n) => { const d = new Date(y, m - 1, 1); while (d.getDay() !== 1) d.setDate(d.getDate() + 1); d.setDate(d.getDate() + 7 * (n - 1)); return f2(m, d.getDate()); };
  const L = [[f2(1, 1), 'Año Nuevo'], [lunes(2, 1), 'Día de la Constitución'], [lunes(3, 3), 'Natalicio de Benito Juárez'], [f2(5, 1), 'Día del Trabajo'], [f2(9, 16), 'Día de la Independencia'],
    [lunes(11, 3), 'Día de la Revolución'], [f2(12, 25), 'Navidad']];
  if ((y - 2024) % 6 === 0) L.push([f2(10, 1), 'Transmisión del Poder Ejecutivo Federal']);
  for (const [f, n] of L) run('INSERT OR IGNORE INTO festivos(fecha,nombre,descansa) VALUES(?,?,1)', f, n);
  return { agregados: L.length };
});
ruta('GET', '/api/incidencias', 'asistencia', ({ q }) => all(`SELECT i.*, e.nombre FROM incidencias i JOIN empleados e ON e.id=i.empleado_id WHERE i.hasta>=? AND i.desde<=? ORDER BY i.desde DESC`, q.desde || '0000-00-00', q.hasta || '9999-12-31'));
ruta('POST', '/api/incidencias', 'asistencia', ({ body, u }) => {
  if (!get('SELECT id FROM empleados WHERE id=?', Number(body.empleado_id))) throw new ErrorUsuario('Elija al empleado');
  if (!TIPOS_INCID[body.tipo]) throw new ErrorUsuario('Elija el tipo');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(body.desde || '') || !/^\d{4}-\d{2}-\d{2}$/.test(body.hasta || '') || body.hasta < body.desde) throw new ErrorUsuario('Revise las fechas');
  return { id: run('INSERT INTO incidencias(empleado_id,tipo,desde,hasta,nota,usuario_id,creado) VALUES(?,?,?,?,?,?,?)', Number(body.empleado_id), body.tipo, body.desde, body.hasta, txt(body.nota, 200), u.id, ahora()).id };
});
ruta('DELETE', '/api/incidencias/:id', 'asistencia', ({ p }) => { run('DELETE FROM incidencias WHERE id=?', Number(p.id)); });

// ---------- Cierre de mes (1.7): todo el mes desglosado ----------
function rangoMes(mes) {
  if (!/^\d{4}-\d{2}$/.test(mes || '')) throw new ErrorUsuario('Elija el mes');
  const [y, m] = mes.split('-').map(Number), dias = new Date(y, m, 0).getDate();
  return { desde: `${mes}-01`, hasta: `${mes}-${String(dias).padStart(2, '0')}`, dias, y, m };
}
function totalesMes(d, h) {
  const S = (sql, ...a) => r2(get(`SELECT COALESCE(SUM(${sql}),0) v ` + a.shift(), ...a).v);
  const hosp = S('monto', "FROM pagos WHERE concepto='hospedaje' AND substr(fecha,1,10) BETWEEN ? AND ?", d, h), tienda = S('monto', "FROM pagos WHERE concepto='tienda' AND substr(fecha,1,10) BETWEEN ? AND ?", d, h);
  const visita = S('monto', "FROM pagos WHERE concepto='visita' AND substr(fecha,1,10) BETWEEN ? AND ?", d, h), gastos = S('monto', 'FROM gastos WHERE cancelado=0 AND substr(fecha,1,10) BETWEEN ? AND ?', d, h);
  const otros = S('monto', `FROM pagos WHERE concepto IN ('multa','mora','limpieza','mascota','otro') AND substr(fecha,1,10) BETWEEN ? AND ?`, d, h);
  return { hospedaje: hosp, tienda, visitas: visita, otros, ingresos: r2(hosp + tienda + visita + otros), gastos, utilidad: r2(hosp + tienda + visita + otros - gastos) };
}
function cierreDatos(mes) { const c = cierreBase(mes); return { ...c, extra: extrasPeriodo(c.desde, c.hasta) }; }
function cierreBase(mes) {
  const { desde: d, hasta: h, dias, y, m } = rangoMes(mes);
  const S = (sql, ...a) => r2(get(`SELECT COALESCE(SUM(${sql}),0) v ` + a.shift(), ...a).v);
  const B = 'substr(fecha,1,10) BETWEEN ? AND ?';
  const habs = all('SELECT id, numero, nombre, clase FROM habitaciones WHERE activo=1');
  const pagos = all(`SELECT p.*, u.nombre usuario FROM pagos p LEFT JOIN usuarios u ON u.id=p.usuario_id WHERE substr(p.fecha,1,10) BETWEEN ? AND ?`, d, h);
  const sum = (l, f = () => true) => r2(l.filter(f).reduce((s, x) => s + x.monto, 0));
  // Ingresos por día
  const porDia = []; const estancias = all('SELECT id, habitacion_id, entrada, COALESCE(salida_real, salida_prevista) sale, modalidad FROM estancias WHERE substr(entrada,1,10)<=? AND substr(COALESCE(salida_real, salida_prevista),1,10)>=?', h, d);
  for (let i = 1; i <= dias; i++) {
    const f = `${mes}-${String(i).padStart(2, '0')}`, l = pagos.filter((x) => x.fecha.slice(0, 10) === f);
    const ocup = new Set(estancias.filter((e) => e.entrada.slice(0, 10) <= f && e.sale.slice(0, 10) > f).map((e) => e.habitacion_id)).size;
    const usadas = new Set(estancias.filter((e) => e.entrada.slice(0, 10) <= f && e.sale.slice(0, 10) >= f).map((e) => e.habitacion_id)).size;
    porDia.push({ fecha: f, hospedaje: sum(l, (x) => x.concepto === 'hospedaje'), tienda: sum(l, (x) => x.concepto === 'tienda'), visitas: sum(l, (x) => x.concepto === 'visita'), total: sum(l),
      efectivo: sum(l, (x) => x.metodo === 'efectivo'), dolares: sum(l, (x) => x.metodo === 'dolares'), tarjeta: sum(l, (x) => x.metodo === 'tarjeta'), transferencia: sum(l, (x) => x.metodo === 'transferencia'),
      gastos: S('monto', `FROM gastos WHERE cancelado=0 AND substr(fecha,1,10)=?`, f), ocupadas: ocup, usadas, entradas: get('SELECT COUNT(*) n FROM estancias WHERE substr(entrada,1,10)=?', f).n });
  }
  const nH = habs.length, capacidad = nH * dias, nochesOcup = porDia.reduce((s, x) => s + x.ocupadas, 0);
  // Rentas por tipo
  const rentas = Object.fromEntries(MODALIDADES.map((k) => [k, { n: 0, unidades: 0, generado: 0, cobrado: 0 }]));
  for (const x of all(`SELECT modalidad, COUNT(*) n, SUM(cantidad) c, SUM(importe) i FROM rentas WHERE ${B} GROUP BY modalidad`, d, h)) if (rentas[x.modalidad]) Object.assign(rentas[x.modalidad], { n: x.n, unidades: x.c, generado: r2(x.i) });
  for (const x of pagos) if (x.concepto === 'hospedaje' && rentas[x.modalidad]) rentas[x.modalidad].cobrado = r2(rentas[x.modalidad].cobrado + x.monto);
  const hospSinTipo = sum(pagos, (x) => x.concepto === 'hospedaje' && !x.modalidad);
  // Por habitación
  const porHab = habs.map((hb) => ({ numero: hb.numero, nombre: hb.nombre, rentas: get(`SELECT COUNT(*) n FROM rentas r JOIN estancias e ON e.id=r.estancia_id WHERE e.habitacion_id=? AND substr(r.fecha,1,10) BETWEEN ? AND ?`, hb.id, d, h).n,
    cobrado: S('p.monto', `FROM pagos p JOIN estancias e ON e.id=p.estancia_id WHERE e.habitacion_id=? AND p.concepto='hospedaje' AND substr(p.fecha,1,10) BETWEEN ? AND ?`, hb.id, d, h),
    noches: porDia.reduce((s, x, i) => s + (estancias.some((e) => e.habitacion_id === hb.id && e.entrada.slice(0, 10) <= x.fecha && e.sale.slice(0, 10) > x.fecha) ? 1 : 0), 0) })).sort((a, b) => b.cobrado - a.cobrado);
  // Tienda
  const items = all(`SELECT i.descripcion, SUM(i.cantidad) cantidad, SUM(i.importe) importe, SUM(i.costo*i.cantidad) costo FROM venta_items i JOIN ventas v ON v.id=i.venta_id WHERE v.cancelada=0 AND substr(v.fecha,1,10) BETWEEN ? AND ? GROUP BY i.descripcion ORDER BY importe DESC`, d, h);
  const tienda = { ventas: get(`SELECT COUNT(*) n, COALESCE(SUM(total),0) t FROM ventas WHERE cancelada=0 AND estancia_id IS NULL AND ${B}`, d, h), cargadas: get(`SELECT COUNT(*) n, COALESCE(SUM(total),0) t FROM ventas WHERE cancelada=0 AND estancia_id IS NOT NULL AND ${B}`, d, h),
    canceladas: get(`SELECT COUNT(*) n, COALESCE(SUM(total),0) t FROM ventas WHERE cancelada=1 AND ${B}`, d, h), productos: items.map((x) => ({ ...x, importe: r2(x.importe), costo: r2(x.costo), utilidad: r2(x.importe - x.costo) })),
    venta: r2(items.reduce((s, x) => s + x.importe, 0)), costo: r2(items.reduce((s, x) => s + x.costo, 0)),
    entradas: all(`SELECT p.nombre, SUM(m.cantidad) cantidad, SUM(m.cantidad*p.costo) costo FROM movimientos m JOIN productos p ON p.id=m.producto_id WHERE m.tipo='entrada' AND substr(m.fecha,1,10) BETWEEN ? AND ? GROUP BY p.id ORDER BY costo DESC`, d, h),
    inventario: r2(get('SELECT COALESCE(SUM(existencia*costo),0) v FROM productos WHERE activo=1').v) };
  tienda.utilidad = r2(tienda.venta - tienda.costo);
  // Depósitos
  const dep = (t) => get(`SELECT COUNT(DISTINCT COALESCE(folio,id)) n, COALESCE(SUM(monto),0) t FROM depositos WHERE tipo=? AND ${B}`, t, d, h);
  const depositos = { recibidos: dep('recibido'), devueltos: dep('devuelto'), retenidos: dep('retenido'), resguardo: r2(get(`SELECT COALESCE(SUM(CASE WHEN tipo='recibido' THEN monto ELSE -monto END),0) t FROM depositos WHERE substr(fecha,1,10)<=?`, h).t) };
  // Gastos
  const gl = all(`SELECT g.*, em.nombre empleado, pv.nombre proveedor FROM gastos g LEFT JOIN empleados em ON em.id=g.empleado_id LEFT JOIN proveedores pv ON pv.id=g.proveedor_id WHERE g.cancelado=0 AND substr(g.fecha,1,10) BETWEEN ? AND ? ORDER BY g.fecha`, d, h);
  const porGrupo = {}; for (const g of gl) { const k = g.grupo || 'Otros', x = porGrupo[k] || (porGrupo[k] = { total: 0, n: 0, conceptos: {} }); x.total = r2(x.total + g.monto); x.n++; const c = x.conceptos[g.categoria || 'Otros'] || (x.conceptos[g.categoria || 'Otros'] = { n: 0, total: 0 }); c.n++; c.total = r2(c.total + g.monto); }
  const agr = (campo) => { const o = {}; for (const g of gl) if (g[campo]) { const x = o[g[campo]] || (o[g[campo]] = { n: 0, total: 0 }); x.n++; x.total = r2(x.total + g.monto); } return Object.entries(o).map(([nombre, v]) => ({ nombre, ...v })).sort((a, b) => b.total - a.total); };
  const porMetodoG = {}; for (const g of gl) porMetodoG[g.metodo] = r2((porMetodoG[g.metodo] || 0) + g.monto);
  // Nómina por empleado (gastos de la clasificación de personal)
  const nomina = {}; for (const g of gl) if (g.empleado_id) { const x = nomina[g.empleado] || (nomina[g.empleado] = { total: 0, conceptos: {} }); x.total = r2(x.total + g.monto); x.conceptos[g.categoria || 'Otros'] = r2((x.conceptos[g.categoria || 'Otros'] || 0) + g.monto); }
  // Asistencia
  const asistencia = all('SELECT * FROM empleados WHERE activo=1 OR id IN (SELECT empleado_id FROM checadas WHERE substr(fecha,1,10) BETWEEN ? AND ?) ORDER BY nombre', d, h).map((e) => ({ nombre: e.nombre, puesto: e.puesto, ...asistenciaDe(e, d, h <= hoy() ? h : hoy()).resumen }));
  // Caja
  const turnos = all(`SELECT id FROM turnos WHERE substr(apertura,1,10) BETWEEN ? AND ? ORDER BY id`, d, h).map((x) => { const r = resumenTurno(x.id); return { id: r.turno.id, usuario: r.turno.usuario, apertura: r.turno.apertura, cierre: r.turno.cierre, cobrado: r.cobrado, dif: r.dif, movimientos: r.movimientos, gastos: r.gastos.efectivo }; });
  const movCaja = { ingresos: S('monto', `FROM caja_mov WHERE tipo='ingreso' AND moneda='MXN' AND ${B}`, d, h), egresos: S('monto', `FROM caja_mov WHERE tipo='retiro' AND moneda='MXN' AND ${B}`, d, h) };
  const T = totalesMes(d, h), mesAnt = m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, '0')}`, ra = rangoMes(mesAnt), Ta = totalesMes(ra.desde, ra.hasta);
  const nochesAnt = (() => { const e2 = all('SELECT habitacion_id, entrada, COALESCE(salida_real, salida_prevista) sale FROM estancias WHERE substr(entrada,1,10)<=? AND substr(COALESCE(salida_real, salida_prevista),1,10)>=?', ra.hasta, ra.desde); let n = 0; for (let i = 1; i <= ra.dias; i++) { const f = `${mesAnt}-${String(i).padStart(2, '0')}`; n += new Set(e2.filter((e) => e.entrada.slice(0, 10) <= f && e.sale.slice(0, 10) > f).map((e) => e.habitacion_id)).size; } return n; })();
  return {
    mes, desde: d, hasta: h, dias, hotel: cfg('hotel_nombre'), generado: ahora(), totales: T,
    anterior: { mes: mesAnt, ...Ta, ocupacion: nH ? r2(nochesAnt / (nH * ra.dias) * 100) : 0 },
    ocupacion: { habitaciones: nH, capacidad, noches: nochesOcup, porcentaje: capacidad ? r2(nochesOcup / capacidad * 100) : 0, promedio_noche: nochesOcup ? r2(T.hospedaje / nochesOcup) : 0, revpar: capacidad ? r2(T.hospedaje / capacidad) : 0,
      entradas: get(`SELECT COUNT(*) n FROM estancias WHERE substr(entrada,1,10) BETWEEN ? AND ?`, d, h).n, salidas: get(`SELECT COUNT(*) n FROM estancias WHERE substr(salida_real,1,10) BETWEEN ? AND ?`, d, h).n,
      activas_al_cierre: estancias.filter((e) => e.entrada.slice(0, 10) <= h && e.sale.slice(0, 10) > h).length },
    rentas, hospedaje_sin_tipo: hospSinTipo, porDia, porHab,
    porMetodo: Object.fromEntries(METODOS.map((k) => [k, sum(pagos, (x) => x.metodo === k)])), usd: r2(pagos.reduce((s, x) => s + (x.usd || 0), 0)), usd_pesos: r2(pagos.reduce((s, x) => s + (x.usd || 0) * (x.tc || 0), 0)), cambio: r2(pagos.reduce((s, x) => s + (x.cambio || 0), 0)),
    porUsuario: Object.entries(pagos.reduce((o, x) => { o[x.usuario || '—'] = r2((o[x.usuario || '—'] || 0) + x.monto); return o; }, {})).map(([nombre, total]) => ({ nombre, total })).sort((a, b) => b.total - a.total),
    visitas: { registradas: get(`SELECT COUNT(*) n FROM visitantes WHERE substr(entrada,1,10) BETWEEN ? AND ?`, d, h).n, cobradas: get(`SELECT COUNT(*) n FROM visitantes WHERE cobro>0 AND substr(entrada,1,10) BETWEEN ? AND ?`, d, h).n, total: T.visitas },
    tienda, depositos,
    gastos: { total: T.gastos, n: gl.length, porGrupo, porMetodo: porMetodoG, porEmpleado: agr('empleado'), porProveedor: agr('proveedor'), fijos: gl.filter((g) => g.fijo_id).map((g) => ({ concepto: g.concepto, fecha: g.fecha, monto: g.monto })),
      lista: gl.map((g) => ({ folio: g.folio, fecha: g.fecha, concepto: g.concepto, grupo: g.grupo, categoria: g.categoria, monto: g.monto, metodo: g.metodo, empleado: g.empleado, proveedor: g.proveedor, factura: g.factura, recibe: g.recibe })) },
    nomina: Object.entries(nomina).map(([nombre, v]) => ({ nombre, ...v })).sort((a, b) => b.total - a.total), asistencia,
    caja: { turnos, ...movCaja, diferencia_mxn: r2(turnos.reduce((s, t) => s + (t.dif?.mxn || 0), 0)), diferencia_usd: r2(turnos.reduce((s, t) => s + (t.dif?.usd || 0), 0)) },
    mantenimiento: { reportados: get(`SELECT COUNT(*) n FROM mantenimiento WHERE substr(alta,1,10) BETWEEN ? AND ?`, d, h).n, terminados: get(`SELECT COUNT(*) n FROM mantenimiento WHERE estado='terminado' AND substr(cierre,1,10) BETWEEN ? AND ?`, d, h).n,
      abiertos: get("SELECT COUNT(*) n FROM mantenimiento WHERE estado<>'terminado'").n, costo: S('costo', 'FROM mantenimiento WHERE substr(cierre,1,10) BETWEEN ? AND ?', d, h) },
    por_cobrar: all("SELECT e.id FROM estancias e WHERE e.activa=1").map((e) => resumenEstancia(get('SELECT * FROM estancias WHERE id=?', e.id))).filter((e) => e.saldo > 0).reduce((s, e) => r2(s + e.saldo), 0),
  };
}
ruta('GET', '/api/cierre', 'reportes', ({ q }) => {
  const g = get('SELECT c.*, u.nombre usuario FROM cierres c LEFT JOIN usuarios u ON u.id=c.usuario_id WHERE mes=?', q.mes);
  if (g && !q.actual) return { ...JSON.parse(g.datos), cerrado: { fecha: g.fecha, usuario: g.usuario, notas: g.notas } };
  return { ...cierreDatos(q.mes), cerrado: null };
});
ruta('GET', '/api/cierres', 'reportes', () => all('SELECT c.mes, c.fecha, c.notas, u.nombre usuario FROM cierres c LEFT JOIN usuarios u ON u.id=c.usuario_id ORDER BY mes DESC'));
// Cerrar el mes: guarda una foto de todos los números para consultarla después tal cual
ruta('POST', '/api/cierre', 'config', ({ body, u }) => {
  const datos = cierreDatos(body.mes);
  if (datos.hasta >= hoy()) throw new ErrorUsuario('El mes todavía no termina. Puede ver el reporte, pero el cierre se hace cuando acabe el mes.');
  run('INSERT INTO cierres(mes,fecha,usuario_id,notas,datos) VALUES(?,?,?,?,?) ON CONFLICT(mes) DO UPDATE SET fecha=excluded.fecha, usuario_id=excluded.usuario_id, notas=excluded.notas, datos=excluded.datos',
    body.mes, ahora(), u.id, txt(body.notas, 500), JSON.stringify(datos));
  return { ok: true };
});

// ---------- Gastos fijos (1.4): luz, agua, internet, renta… con vencimiento y aviso ----------
const PERIODOS = { semanal: [0, 7], quincenal: [0, 15], mensual: [1, 0], bimestral: [2, 0], trimestral: [3, 0], semestral: [6, 0], anual: [12, 0], unico: [0, 0] };
function siguienteVence(vence, periodo) {
  const [m, d] = PERIODOS[periodo] || [1, 0], f = aFecha(vence || hoy());
  if (m) { const dia = f.getDate(); f.setDate(1); f.setMonth(f.getMonth() + m); f.setDate(Math.min(dia, new Date(f.getFullYear(), f.getMonth() + 1, 0).getDate())); } else f.setDate(f.getDate() + d);
  return `${f.getFullYear()}-${String(f.getMonth() + 1).padStart(2, '0')}-${String(f.getDate()).padStart(2, '0')}`;
}
function fijoJSON(g) {
  const dias = g.vence ? Math.round((aFecha(g.vence) - aFecha(hoy())) / 86400000) : null;
  const pagos = all('SELECT id, folio, fecha, monto, metodo, nota FROM gastos WHERE fijo_id=? AND cancelado=0 ORDER BY fecha DESC LIMIT 12', g.id);
  const ult = pagos.slice(0, 3), promedio = ult.length ? r2(ult.reduce((s, x) => s + x.monto, 0) / ult.length) : 0;
  const estado = !g.activo ? 'inactivo' : dias === null ? 'sin_fecha' : dias < 0 ? 'vencido' : dias <= (g.dias_aviso ?? 5) ? 'por_vencer' : 'al_corriente';
  return { ...g, dias, estado, pagos, promedio, ultimo: pagos[0] || null };
}
function limpiarFijo(b) {
  const d = { nombre: txt(b.nombre, 80), categoria: txt(b.categoria, 60), proveedor: txt(b.proveedor, 80), contrato: txt(b.contrato, 60), referencia: txt(b.referencia, 80),
    monto: num(b.monto), periodo: PERIODOS[b.periodo] ? b.periodo : 'mensual', vence: /^\d{4}-\d{2}-\d{2}$/.test(b.vence || '') ? b.vence : null,
    dias_aviso: Math.min(ent(b.dias_aviso, 0), 60), domiciliado: b.domiciliado ? 1 : 0, notas: txt(b.notas, 300) };
  if (!d.nombre) throw new ErrorUsuario('Escriba qué es (ej. Luz, Agua, Internet)');
  if (!d.vence) throw new ErrorUsuario('Ponga la fecha en que vence el próximo pago');
  return d;
}
const FIJO_COLS = 'nombre=?,categoria=?,proveedor=?,contrato=?,referencia=?,monto=?,periodo=?,vence=?,dias_aviso=?,domiciliado=?,notas=?';
const fijoVals = (d) => [d.nombre, d.categoria, d.proveedor, d.contrato, d.referencia, d.monto, d.periodo, d.vence, d.dias_aviso, d.domiciliado, d.notas];
ruta('GET', '/api/gastos-fijos', 'gastos', () => all('SELECT * FROM gastos_fijos WHERE activo=1 ORDER BY vence').map(fijoJSON));
// Avisos para el menú y la pantalla de habitaciones
ruta('GET', '/api/gastos-fijos/avisos', 'sesion', ({ u }) => {
  if (!u.perm.has('gastos') && !u.perm.has('reportes')) return [];
  return all('SELECT * FROM gastos_fijos WHERE activo=1 ORDER BY vence').map(fijoJSON).filter((g) => g.estado === 'vencido' || g.estado === 'por_vencer')
    .map(({ id, nombre, vence, dias, estado, monto, domiciliado }) => ({ id, nombre, vence, dias, estado, monto, domiciliado }));
});
ruta('POST', '/api/gastos-fijos', 'gastos', ({ body }) => {
  const d = limpiarFijo(body);
  return { id: run(`INSERT INTO gastos_fijos(nombre,categoria,proveedor,contrato,referencia,monto,periodo,vence,dias_aviso,domiciliado,notas,creado) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`, ...fijoVals(d), ahora()).id };
});
ruta('PUT', '/api/gastos-fijos/:id', 'gastos', ({ body, p }) => { run(`UPDATE gastos_fijos SET ${FIJO_COLS} WHERE id=?`, ...fijoVals(limpiarFijo(body)), Number(p.id)); });
ruta('DELETE', '/api/gastos-fijos/:id', 'gastos', ({ p }) => { run('UPDATE gastos_fijos SET activo=0 WHERE id=?', Number(p.id)); });
// Pagar: registra el gasto (con folio) y mueve el vencimiento al siguiente periodo
ruta('POST', '/api/gastos-fijos/:id/pagar', 'gastos', ({ body, p, u }) => tx(() => {
  const g = get('SELECT * FROM gastos_fijos WHERE id=? AND activo=1', Number(p.id));
  if (!g) throw new ErrorUsuario('No existe', 404);
  const periodoTxt = txt(body.periodo_txt, 60);
  const id = crearGasto({ concepto: g.nombre + (g.proveedor ? ' (' + g.proveedor + ')' : '') + (periodoTxt ? ' · ' + periodoTxt : ''), categoria: g.categoria || 'Gastos fijos', monto: body.monto,
    metodo: body.metodo, nota: [g.contrato ? 'Contrato ' + g.contrato : '', txt(body.nota, 200)].filter(Boolean).join(' · '), fijo_id: g.id, fuera_de_caja: !!body.fuera_de_caja, recibe: g.proveedor }, u.id);
  if (g.periodo === 'unico') run('UPDATE gastos_fijos SET activo=0 WHERE id=?', g.id);
  else run('UPDATE gastos_fijos SET vence=? WHERE id=?', siguienteVence(g.vence, g.periodo), g.id);
  return { id, siguiente: get('SELECT vence FROM gastos_fijos WHERE id=?', g.id).vence };
}));
ruta('POST', '/api/gastos', 'gastos', ({ body, u }) => {
  // Opcional (1.8): los gastos pagados en efectivo con dinero de la caja también piden clave de gerente
  if (cfg('autoriza_gastos') === '1' && body.metodo === 'efectivo' && !body.fuera_de_caja && turnoAbierto(u.id)) autorizacion(u, body.autoriza);
  return { id: crearGasto(body, u.id) };
});
ruta('PUT', '/api/gastos/:id/firmas', 'gastos', ({ body, p }) => {
  const g = get('SELECT * FROM gastos WHERE id=?', Number(p.id)); if (!g) throw new ErrorUsuario('No existe', 404);
  run('UPDATE gastos SET firma_entrega=COALESCE(?,firma_entrega), firma_recibe=COALESCE(?,firma_recibe), recibe=COALESCE(?,recibe) WHERE id=?', firma(body.firma_entrega), firma(body.firma_recibe), txt(body.recibe, 100), g.id);
});
ruta('POST', '/api/gastos/:id/cancelar', 'cancelar', ({ p }) => { run('UPDATE gastos SET cancelado=1 WHERE id=?', Number(p.id)); });

// ---------- Contratos de arrendamiento ----------
ruta('GET', '/api/contratos', 'sesion', ({ q }) => all(`SELECT c.id,c.folio,c.fecha,c.arrendatario,c.inicio,c.fin,c.modalidad,c.renta,c.deposito, e.activa, e.salida_prevista, e.salida_real, hb.numero, hb.clase,
  (c.firma_arrendatario IS NOT NULL) firmado FROM contratos c JOIN estancias e ON e.id=c.estancia_id JOIN habitaciones hb ON hb.id=e.habitacion_id
  WHERE (? = '' OR c.arrendatario LIKE ? OR hb.numero LIKE ?) ORDER BY e.activa DESC, c.id DESC LIMIT 300`, q.q || '', '%' + (q.q || '') + '%', '%' + (q.q || '') + '%'));
ruta('GET', '/api/contratos/:id', 'sesion', ({ p }) => {
  const c = get('SELECT * FROM contratos WHERE id=?', Number(p.id)); if (!c) throw new ErrorUsuario('No existe', 404);
  const e = resumenEstancia(get('SELECT * FROM estancias WHERE id=?', c.estancia_id));
  return { ...c, estancia: e, habitacion: habJSON(get('SELECT * FROM habitaciones WHERE id=?', e.habitacion_id)) };
});
ruta('POST', '/api/contratos', 'contratos', ({ body, u }) => {
  const e = get('SELECT * FROM estancias WHERE id=?', Number(body.estancia_id));
  if (!e) throw new ErrorUsuario('Registro de huésped no encontrado');
  if (!txt(body.texto, 60000)) throw new ErrorUsuario('El contrato está vacío');
  if (!txt(body.arrendatario, 100)) throw new ErrorUsuario('Escriba el nombre del arrendatario');
  return run(`INSERT INTO contratos(folio,estancia_id,fecha,arrendatario,identificacion,domicilio,telefono,inicio,fin,modalidad,renta,deposito,dia_pago,texto,firma_arrendador,firma_arrendatario,usuario_id)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, siguienteFolio('contrato'), e.id, ahora(), txt(body.arrendatario, 100), txt(body.identificacion, 80), txt(body.domicilio, 200), txt(body.telefono, 30),
    txt(body.inicio, 20), txt(body.fin, 20), MODALIDADES.includes(body.modalidad) ? body.modalidad : e.modalidad, num(body.renta), num(body.deposito), txt(body.dia_pago, 100),
    txt(body.texto, 60000), firma(body.firma_arrendador), firma(body.firma_arrendatario), u.id);
});
ruta('PUT', '/api/contratos/:id/firmas', 'contratos', ({ body, p }) => {
  const c = get('SELECT id FROM contratos WHERE id=?', Number(p.id)); if (!c) throw new ErrorUsuario('No existe', 404);
  run('UPDATE contratos SET firma_arrendador=COALESCE(?,firma_arrendador), firma_arrendatario=COALESCE(?,firma_arrendatario) WHERE id=?', firma(body.firma_arrendador), firma(body.firma_arrendatario), c.id);
});

// ---------- Mantenimiento (reportes con fotos) ----------
const PRIORIDADES = ['baja', 'normal', 'alta', 'urgente'];
function nuevoReporte(b, uid, fotos) {
  const titulo = txt(b.titulo, 120);
  if (!titulo) throw new ErrorUsuario('Escriba qué hay que reparar');
  const id = run('INSERT INTO mantenimiento(folio,habitacion_id,titulo,descripcion,prioridad,estado,alta,alta_usuario,estancia_id) VALUES(?,?,?,?,?,?,?,?,?)',
    siguienteFolio('mant'), Number(b.habitacion_id) || null, titulo, txt(b.descripcion, 1000), PRIORIDADES.includes(b.prioridad) ? b.prioridad : 'normal', 'pendiente', ahora(), uid, Number(b.estancia_id) || null).id;
  if (fotos) guardarFotos(fotos, id, 'reporte', uid);
  return id;
}
const SQL_MANT = `SELECT m.*, hb.numero, hb.clase, ua.nombre alta_nombre, ut.nombre atiende_nombre, uc.nombre cierre_nombre,
  (SELECT COUNT(*) FROM mant_fotos f WHERE f.mant_id=m.id AND f.tipo='reporte') fotos_reporte,
  (SELECT COUNT(*) FROM mant_fotos f WHERE f.mant_id=m.id AND f.tipo='evidencia') fotos_evidencia,
  (SELECT archivo FROM mant_fotos f WHERE f.mant_id=m.id ORDER BY (f.tipo='evidencia') DESC, f.id DESC LIMIT 1) foto
  FROM mantenimiento m LEFT JOIN habitaciones hb ON hb.id=m.habitacion_id LEFT JOIN usuarios ua ON ua.id=m.alta_usuario
  LEFT JOIN usuarios ut ON ut.id=m.atiende_usuario LEFT JOIN usuarios uc ON uc.id=m.cierre_usuario`;
ruta('GET', '/api/mant', 'vermant', ({ q }) => {
  if (q.estado === 'terminados') {
    const d = q.desde || hoy(), h = q.hasta || d;
    return all(SQL_MANT + " WHERE m.estado='terminado' AND substr(m.cierre,1,10) BETWEEN ? AND ? ORDER BY m.cierre DESC LIMIT 300", d, h);
  }
  return all(SQL_MANT + " WHERE m.estado<>'terminado' ORDER BY CASE m.prioridad WHEN 'urgente' THEN 0 WHEN 'alta' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END, m.alta");
});
ruta('GET', '/api/mant/:id', 'vermant', ({ p }) => {
  const m = get(SQL_MANT + ' WHERE m.id=?', Number(p.id)); if (!m) throw new ErrorUsuario('No existe', 404);
  return { ...m, fotos: all('SELECT f.*, u.nombre usuario FROM mant_fotos f LEFT JOIN usuarios u ON u.id=f.usuario_id WHERE mant_id=? ORDER BY f.id', m.id) };
});
ruta('POST', '/api/mant', 'mant_reportar', ({ body, u }) => tx(() => {
  const h = body.habitacion_id ? get('SELECT * FROM habitaciones WHERE id=? AND activo=1', Number(body.habitacion_id)) : null;
  const id = nuevoReporte(body, u.id, body.fotos);
  if (h && body.poner_en_mant && h.estado !== 'ocupada' && h.estado !== 'mant') {
    run("UPDATE habitaciones SET estado='mant', nota=? WHERE id=?", txt(body.titulo, 120), h.id);
    run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), h.id, 'mant', txt(body.titulo, 120), u.id);
  }
  return { id };
}));
ruta('POST', '/api/mant/:id/atender', 'mant_atender', ({ p, u }) => {
  const m = get('SELECT * FROM mantenimiento WHERE id=?', Number(p.id));
  if (!m || m.estado === 'terminado') throw new ErrorUsuario('El reporte ya está terminado');
  run("UPDATE mantenimiento SET estado='proceso', inicio=COALESCE(inicio,?), atiende_usuario=? WHERE id=?", ahora(), u.id, m.id);
});
ruta('POST', '/api/mant/:id/fotos', 'mant', ({ p, body, u }) => {
  const m = get('SELECT * FROM mantenimiento WHERE id=?', Number(p.id)); if (!m) throw new ErrorUsuario('No existe', 404);
  guardarFotos(body.fotos, m.id, body.tipo === 'evidencia' ? 'evidencia' : 'reporte', u.id);
});
ruta('POST', '/api/mant/:id/cerrar', 'mant_atender', ({ p, body, u }) => tx(() => {
  const m = get('SELECT * FROM mantenimiento WHERE id=?', Number(p.id));
  if (!m || m.estado === 'terminado') throw new ErrorUsuario('El reporte ya está terminado');
  const nota = txt(body.nota, 1000);
  if (!nota) throw new ErrorUsuario('Escriba qué se hizo para repararlo');
  guardarFotos(body.fotos, m.id, 'evidencia', u.id);
  const costo = num(body.costo);
  let gasto = null;
  if (costo > 0 && body.registrar_gasto) {
    const hb = m.habitacion_id ? get('SELECT numero FROM habitaciones WHERE id=?', m.habitacion_id) : null;
    gasto = crearGasto({ concepto: `Mantenimiento${hb ? ' hab. ' + hb.numero : ''}: ${m.titulo}`, categoria: 'Mantenimiento', monto: costo, metodo: METODOS_GASTO.includes(body.metodo) ? body.metodo : 'efectivo',
      recibe: u.nombre, habitacion_id: m.habitacion_id, ticket_id: m.id, nota }, u.id);
  }
  const t = ahora();
  run("UPDATE mantenimiento SET estado='terminado', inicio=COALESCE(inicio,?), atiende_usuario=COALESCE(atiende_usuario,?), cierre=?, cierre_usuario=?, nota_cierre=?, costo=?, gasto_id=? WHERE id=?",
    t, u.id, t, u.id, nota, costo, gasto, m.id);
  // Si la habitación estaba en mantenimiento y ya no tiene pendientes, pasa a limpieza (o lista)
  if (m.habitacion_id && !get("SELECT id FROM mantenimiento WHERE habitacion_id=? AND estado<>'terminado'", m.habitacion_id)) {
    const h = get('SELECT * FROM habitaciones WHERE id=?', m.habitacion_id);
    if (h?.estado === 'mant') {
      const nuevo = body.estado_hab === 'libre' ? 'libre' : 'limpieza';
      run('UPDATE habitaciones SET estado=?, nota=NULL WHERE id=?', nuevo, h.id);
      run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', t, h.id, nuevo, 'Reparado: ' + m.titulo, u.id);
    }
  }
}));

// ---------- Turnos de caja ----------
function resumenTurno(id) {
  const t = get('SELECT t.*, u.nombre usuario FROM turnos t LEFT JOIN usuarios u ON u.id=t.usuario_id WHERE t.id=?', id);
  if (!t) throw new ErrorUsuario('Turno no encontrado', 404);
  const S = (sql, ...a) => r2(get(`SELECT COALESCE(SUM(${sql}),0) v ` + a.shift(), ...a).v);
  const pag = (m) => S('monto', "FROM pagos WHERE turno_id=? AND metodo=?", id, m);
  const p = { efectivo: pag('efectivo'), dolares: pag('dolares'), tarjeta: pag('tarjeta'), transferencia: pag('transferencia'),
    usd: S('usd', "FROM pagos WHERE turno_id=? AND metodo='dolares'", id), cambio: S('cambio', 'FROM pagos WHERE turno_id=?', id) };
  const conceptos = Object.fromEntries(all('SELECT concepto, COUNT(*) n, SUM(monto) t FROM pagos WHERE turno_id=? GROUP BY concepto', id).map((x) => [x.concepto, { n: x.n, total: r2(x.t) }]));
  const dep = (tipo, m) => S('monto', 'FROM depositos WHERE turno_id=? AND tipo=? AND metodo=?', id, tipo, m);
  const depUsd = (tipo) => S('usd', "FROM depositos WHERE turno_id=? AND tipo=? AND metodo='dolares'", id, tipo);
  const dr = { efectivo: dep('recibido', 'efectivo'), dolares: dep('recibido', 'dolares'), usd: depUsd('recibido'), tarjeta: dep('recibido', 'tarjeta'), transferencia: dep('recibido', 'transferencia'),
    cambio: S('cambio', "FROM depositos WHERE turno_id=? AND tipo='recibido'", id) };
  const dd = { efectivo: dep('devuelto', 'efectivo'), dolares: dep('devuelto', 'dolares'), usd: depUsd('devuelto'), tarjeta: dep('devuelto', 'tarjeta'), transferencia: dep('devuelto', 'transferencia') };
  const g = { efectivo: S('monto', "FROM gastos WHERE turno_id=? AND cancelado=0 AND metodo='efectivo'", id), total: S('monto', 'FROM gastos WHERE turno_id=? AND cancelado=0', id) };
  const mv = (tipo, mon) => S('monto', 'FROM caja_mov WHERE turno_id=? AND tipo=? AND moneda=?', id, tipo, mon);
  const m = { ing_mxn: mv('ingreso', 'MXN'), ret_mxn: mv('retiro', 'MXN'), ing_usd: mv('ingreso', 'USD'), ret_usd: mv('retiro', 'USD') };
  const esperado = {
    mxn: r2(t.fondo_mxn + p.efectivo - p.cambio + dr.efectivo - dr.cambio - dd.efectivo - g.efectivo + m.ing_mxn - m.ret_mxn),
    usd: r2(t.fondo_usd + p.usd + dr.usd - dd.usd + m.ing_usd - m.ret_usd),
    tarjeta: r2(p.tarjeta + dr.tarjeta - dd.tarjeta),
    transferencia: r2(p.transferencia + dr.transferencia - dd.transferencia),
  };
  const dif = t.estado === 'cerrado' ? { mxn: r2(t.decl_mxn - esperado.mxn), usd: r2(t.decl_usd - esperado.usd), tarjeta: r2(t.decl_tarjeta - esperado.tarjeta), transferencia: r2(t.decl_transferencia - esperado.transferencia) } : null;
  // Cuántos de cada cosa (1.4)
  const rentas = Object.fromEntries(MODALIDADES.map((k) => [k, { n: 0, cantidad: 0, importe: 0, cobrado: 0 }]));
  for (const x of all('SELECT modalidad, COUNT(*) n, SUM(cantidad) c, SUM(importe) i FROM rentas WHERE turno_id=? GROUP BY modalidad', id)) if (rentas[x.modalidad]) Object.assign(rentas[x.modalidad], { n: x.n, cantidad: x.c, importe: r2(x.i) });
  for (const x of all("SELECT modalidad, SUM(monto) t FROM pagos WHERE turno_id=? AND concepto='hospedaje' GROUP BY modalidad", id)) if (rentas[x.modalidad]) rentas[x.modalidad].cobrado = r2(x.t);
  const sinMod = S('monto', "FROM pagos WHERE turno_id=? AND concepto='hospedaje' AND modalidad IS NULL", id);
  const visitas = { n: get('SELECT COUNT(*) n FROM visitantes WHERE turno_id=? AND cobro>0', id).n, t: S('monto', "FROM pagos WHERE turno_id=? AND concepto='visita'", id) };
  const tienda = { ventas: get('SELECT COUNT(*) n, COALESCE(SUM(total),0) t FROM ventas WHERE turno_id=? AND cancelada=0 AND estancia_id IS NULL', id),
    cargadas: get('SELECT COUNT(*) n, COALESCE(SUM(total),0) t FROM ventas WHERE turno_id=? AND cancelada=0 AND estancia_id IS NOT NULL', id),
    productos: all('SELECT i.descripcion, SUM(i.cantidad) cantidad, SUM(i.importe) importe FROM venta_items i JOIN ventas v ON v.id=i.venta_id WHERE v.turno_id=? AND v.cancelada=0 GROUP BY i.descripcion ORDER BY importe DESC', id) };
  const depN = (tipo) => get('SELECT COUNT(DISTINCT COALESCE(folio, id)) n, COALESCE(SUM(monto),0) t FROM depositos WHERE turno_id=? AND tipo=?', id, tipo);
  const cuentas = { rentas, hospedaje_sin_tipo: sinMod, visitas: { n: visitas.n, total: r2(visitas.t) }, tienda,
    depositos: { recibidos: depN('recibido'), devueltos: depN('devuelto'), retenidos: depN('retenido') },
    dolares: { usd: r2(p.usd + dr.usd), tc: t.tipo_cambio, pesos: r2((p.usd + dr.usd) * t.tipo_cambio), cambio: r2(p.cambio + dr.cambio) } };
  return {
    turno: t, pagos: p, conceptos, depositos: { recibidos: dr, devueltos: dd }, gastos: g, movimientos: m, esperado, dif, cuentas,
    cobrado: r2(p.efectivo + p.dolares + p.tarjeta + p.transferencia),
    lista_mov: all('SELECT m.*, a.nombre autorizo FROM caja_mov m LEFT JOIN usuarios a ON a.id=m.autorizo_id WHERE m.turno_id=? ORDER BY m.id', id),
  };
}
const ocultarEsperado = (r) => ({ ...r, esperado: null, dif: null, ciego: true });
// Detalle para el Excel (de un turno o de un periodo)
function detalle(where, ...a) {
  const W = (alias) => where.replace(/\$/g, alias);
  return {
    rentas: all(`SELECT r.fecha, hb.numero, e.huesped, e.folio, r.modalidad, r.cantidad, r.precio, r.importe, r.tipo, u.nombre usuario FROM rentas r JOIN estancias e ON e.id=r.estancia_id
      JOIN habitaciones hb ON hb.id=e.habitacion_id LEFT JOIN usuarios u ON u.id=r.usuario_id WHERE ${W('r')} ORDER BY r.fecha`, ...a),
    pagos: all(`SELECT p.fecha, p.concepto, p.modalidad, p.metodo, p.monto, p.usd, p.tc, p.cambio, p.nota, hb.numero, e.huesped, u.nombre usuario FROM pagos p LEFT JOIN estancias e ON e.id=p.estancia_id
      LEFT JOIN habitaciones hb ON hb.id=e.habitacion_id LEFT JOIN usuarios u ON u.id=p.usuario_id WHERE ${W('p')} ORDER BY p.fecha`, ...a),
    ventas: all(`SELECT v.folio, v.fecha, i.descripcion, i.cantidad, i.precio, i.importe, v.metodo, hb.numero FROM venta_items i JOIN ventas v ON v.id=i.venta_id LEFT JOIN estancias e ON e.id=v.estancia_id
      LEFT JOIN habitaciones hb ON hb.id=e.habitacion_id WHERE v.cancelada=0 AND ${W('v')} ORDER BY v.fecha`, ...a),
    depositos: all(`SELECT d.fecha, d.folio, d.tipo, d.metodo, d.monto, d.usd, d.motivo, hb.numero, e.huesped FROM depositos d JOIN estancias e ON e.id=d.estancia_id JOIN habitaciones hb ON hb.id=e.habitacion_id
      WHERE ${W('d')} ORDER BY d.fecha`, ...a),
    gastos: all(`SELECT g.folio, g.fecha, g.concepto, g.grupo, g.categoria, g.metodo, g.monto, g.recibe, g.factura, g.periodo, em.nombre empleado, pv.nombre proveedor FROM gastos g LEFT JOIN empleados em ON em.id=g.empleado_id LEFT JOIN proveedores pv ON pv.id=g.proveedor_id WHERE g.cancelado=0 AND ${W('g')} ORDER BY g.fecha`, ...a),
  };
}
// Corte detallado en PDF: solo el administrador (permiso "usuarios" solo lo tiene el administrador)
ruta('GET', '/api/turnos/:id/completo', 'usuarios', ({ p }) => {
  const t = get('SELECT * FROM turnos WHERE id=?', Number(p.id));
  if (!t) throw new ErrorUsuario('Turno no encontrado', 404);
  return { ...resumenTurno(t.id), detalle: detalle('$.turno_id=?', t.id), visitantes: all('SELECT v.nombre, v.entrada, v.cobro, hb.numero FROM visitantes v LEFT JOIN habitaciones hb ON hb.id=v.habitacion_id WHERE v.turno_id=? AND v.cobro>0 ORDER BY v.entrada', t.id),
    movimientos_caja: all('SELECT * FROM caja_mov WHERE turno_id=? ORDER BY id', t.id) };
});
ruta('GET', '/api/turnos/:id/detalle', 'sesion', ({ p, u }) => {
  const t = get('SELECT * FROM turnos WHERE id=?', Number(p.id));
  if (!t) throw new ErrorUsuario('Turno no encontrado', 404);
  if (t.usuario_id !== u.id && !u.perm.has('cortes')) throw new ErrorUsuario('Su usuario no puede ver cortes de otros usuarios', 403);
  const r = resumenTurno(t.id);
  return { ...(u.perm.has('ver_corte') || t.estado === 'cerrado' ? r : ocultarEsperado(r)), detalle: detalle('$.turno_id=?', t.id), visitantes: all('SELECT v.nombre, v.entrada, v.cobro, hb.numero FROM visitantes v LEFT JOIN habitaciones hb ON hb.id=v.habitacion_id WHERE v.turno_id=? AND v.cobro>0 ORDER BY v.entrada', t.id),
    movimientos_caja: all('SELECT * FROM caja_mov WHERE turno_id=? ORDER BY id', t.id) };
});
ruta('GET', '/api/turno', 'todos', ({ u }) => {
  const t = turnoAbierto(u.id);
  if (!t) return { turno: null, tipo_cambio: num(cfg('tipo_cambio')), exigir: cfg('exigir_turno') !== '0' };
  const r = resumenTurno(t.id);
  return u.perm.has('ver_corte') ? r : ocultarEsperado(r);
});
ruta('POST', '/api/turno/abrir', 'caja', async ({ u, body }) => {
  if (turnoAbierto(u.id)) throw new ErrorUsuario('Ya tiene un turno abierto');
  const tc = num(body.tipo_cambio);
  if (!(tc > 0)) throw new ErrorUsuario('Escriba en cuánto toma el dólar hoy');
  const r = run('INSERT INTO turnos(usuario_id,apertura,fondo_mxn,fondo_usd,tipo_cambio) VALUES(?,?,?,?,?)', u.id, ahora(), Math.max(0, num(body.fondo_mxn)), Math.max(0, num(body.fondo_usd)), tc);
  setCfg('tipo_cambio', tc);
  // Abre el cajón para colocar el fondo de caja
  const cajon = await abrirCajon();
  return { turno: get('SELECT * FROM turnos WHERE id=?', r.id), cajon };
});
ruta('POST', '/api/turno/tipo-cambio', 'tipo_cambio', ({ u, body }) => {
  const t = turnoAbierto(u.id); if (!t) throw new ErrorUsuario('No tiene turno abierto');
  const tc = num(body.tipo_cambio); if (!(tc > 0)) throw new ErrorUsuario('Tipo de cambio inválido');
  run('UPDATE turnos SET tipo_cambio=? WHERE id=?', tc, t.id); setCfg('tipo_cambio', tc);
});
// Autorización con clave de gerente o administrador (para egresos de caja)
function autorizacion(u, a) {
  if (cfg('autoriza_egresos') === '0') return null;
  if (u.perm.has('autorizar')) return u;
  const us = txt(a?.usuario, 60)?.toLowerCase(), x = us ? get('SELECT * FROM usuarios WHERE usuario=? AND activo=1', us) : null;
  if (!us || !a?.password) throw new ErrorUsuario('Este egreso necesita la clave de un gerente o del administrador', 403);
  if (!x || !checkPass(String(a.password), x.pass_hash)) throw new ErrorUsuario('Usuario o contraseña del gerente incorrectos', 403);
  if (!new Set(permisosDe(x)).has('autorizar')) throw new ErrorUsuario(x.nombre + ' no puede autorizar egresos (solo gerente o administrador)', 403);
  return x;
}
ruta('POST', '/api/turno/movimiento', 'movimientos', ({ u, body }) => {
  const t = turnoAbierto(u.id); if (!t) throw new ErrorUsuario('Primero abra su turno de caja');
  const tipo = body.tipo === 'ingreso' ? 'ingreso' : 'retiro', moneda = body.moneda === 'USD' ? 'USD' : 'MXN', monto = num(body.monto);
  if (!(monto > 0)) throw new ErrorUsuario('Escriba el monto');
  const motivo = txt(body.motivo, 200); if (!motivo) throw new ErrorUsuario('Escriba el motivo');
  const aut = tipo === 'retiro' ? autorizacion(u, body.autoriza) : null;
  pedirCajon();
  return run('INSERT INTO caja_mov(turno_id,usuario_id,fecha,tipo,moneda,monto,motivo,autorizo_id) VALUES(?,?,?,?,?,?,?,?)', t.id, u.id, ahora(), tipo, moneda, monto, motivo, aut?.id ?? null);
});
ruta('POST', '/api/turno/cerrar', 'caja', ({ u, body }) => {
  const t = turnoAbierto(u.id); if (!t) throw new ErrorUsuario('No tiene turno abierto');
  const v = ['decl_mxn', 'decl_usd', 'decl_tarjeta', 'decl_transferencia'].map((k) => body[k]);
  if (v.some((x) => x === '' || x === undefined || x === null || !(Number(x) >= 0))) throw new ErrorUsuario('Cuente y escriba: efectivo en pesos, dólares, vouchers de tarjeta y transferencias (0 si no hay)');
  run("UPDATE turnos SET decl_mxn=?, decl_usd=?, decl_tarjeta=?, decl_transferencia=?, notas=?, cierre=?, estado='cerrado' WHERE id=?", num(v[0]), num(v[1]), num(v[2]), num(v[3]), txt(body.notas, 500), ahora(), t.id);
  pedirCajon(); // abre el cajón para sacar el dinero del corte
  const r = resumenTurno(t.id);
  return u.perm.has('ver_corte') ? r : ocultarEsperado(r);
});
ruta('GET', '/api/turnos', 'cortes', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d;
  return all("SELECT t.id FROM turnos t WHERE substr(t.apertura,1,10) <= ? AND COALESCE(substr(t.cierre,1,10),'9999') >= ? ORDER BY t.id DESC LIMIT 200", h, d).map((x) => resumenTurno(x.id));
});
ruta('GET', '/api/turnos/:id', 'todos', ({ p, u }) => {
  const r = resumenTurno(Number(p.id));
  if (r.turno.usuario_id !== u.id && !u.perm.has('cortes')) throw new ErrorUsuario('Solo puede ver sus propios cortes', 403);
  return u.perm.has('ver_corte') || u.perm.has('cortes') ? r : ocultarEsperado(r);
});

// ---------- Impresora de tickets y cajón ----------
ruta('POST', '/api/imprimir', 'todos', async ({ body }) => imprimirOps(Array.isArray(body.ops) ? body.ops.slice(0, 600) : [], false));
ruta('POST', '/api/cajon', 'cajon', async () => abrirCajon());
ruta('GET', '/api/impresoras', 'config', async () => { try { return { lista: await listarImpresoras() }; } catch (e) { return { lista: [], error: e.message }; } });

// ---------- Visitantes ----------
ruta('GET', '/api/visitantes', 'sesion', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d;
  return {
    dentro: all('SELECT v.*, hb.numero, e.huesped FROM visitantes v LEFT JOIN habitaciones hb ON hb.id=v.habitacion_id LEFT JOIN estancias e ON e.id=v.estancia_id WHERE v.salida IS NULL ORDER BY v.entrada DESC'),
    historial: all(`SELECT v.*, hb.numero, e.huesped FROM visitantes v LEFT JOIN habitaciones hb ON hb.id=v.habitacion_id LEFT JOIN estancias e ON e.id=v.estancia_id
      WHERE v.salida IS NOT NULL AND substr(v.entrada,1,10) BETWEEN ? AND ? ORDER BY v.entrada DESC LIMIT 500`, d, h),
  };
});
ruta('POST', '/api/visitantes', 'visitantes', ({ body, u }) => {
  const nombre = txt(body.nombre, 100);
  if (!nombre) throw new ErrorUsuario('Escriba el nombre del visitante');
  const e = get('SELECT * FROM estancias WHERE habitacion_id=? AND activa=1', Number(body.habitacion_id));
  if (!e) throw new ErrorUsuario('Esa habitación no tiene huésped');
  // Precio fijo: el de la habitación (o el general). Solo gerente o administrador puede cobrar otra cantidad.
  const hb = get('SELECT * FROM habitaciones WHERE id=?', e.habitacion_id), fijo = hb.precio_visita !== null && hb.precio_visita !== undefined ? num(hb.precio_visita) : num(cfg('precio_visita'));
  const cobro = u.perm.has('autorizar') && body.cobro !== undefined && body.cobro !== '' ? num(body.cobro) : fijo;
  return tx(() => {
    const r = run('INSERT INTO visitantes(nombre,identificacion,habitacion_id,estancia_id,motivo,entrada,usuario_id,cobro,turno_id) VALUES(?,?,?,?,?,?,?,?,?)', nombre, txt(body.identificacion, 60), e.habitacion_id, e.id, txt(body.motivo, 100), ahora(), u.id, cobro, turnoAbierto(u.id)?.id ?? null);
    // El cobro de la visita no se suma a la cuenta del huésped: entra directo a caja
    const pg = cobro > 0 ? pagar(cobro, body.metodo, 'visita', null, null, u.id, 'Visita: ' + nombre + ' · hab. ' + get('SELECT numero FROM habitaciones WHERE id=?', e.habitacion_id).numero, body.usd, body.partes) : null;
    return { id: r.id, pago: pg };
  });
});
ruta('POST', '/api/visitantes/:id/salida', 'visitantes', ({ p }) => { run('UPDATE visitantes SET salida=? WHERE id=? AND salida IS NULL', ahora(), Number(p.id)); });

// ---------- Productos e inventario ----------
ruta('GET', '/api/productos', 'sesion', () => all("SELECT * FROM productos WHERE activo=1" + (moduloActivo('membresias') ? '' : " AND COALESCE(codigo,'') NOT LIKE 'MEM-%'") + ' ORDER BY nombre'));
// 1.5: tiempo de lavado y comisión del lavador (solo paquetes y servicios)
function prodLavado(id, b) {
  if (b.minutos === undefined && b.com_tipo === undefined) return;
  const tipo = ['monto', 'porc'].includes(b.com_tipo) ? b.com_tipo : null;
  if (tipo === 'porc' && num(b.com_valor) > 100) throw new ErrorUsuario('La comisión no puede ser más del 100%');
  run('UPDATE productos SET minutos=?, com_tipo=?, com_valor=? WHERE id=?', ent(b.minutos) || null, tipo, tipo ? num(b.com_valor) : 0, id);
}
function limpiarProd(b) {
  const paquete = txt(b.paquete, 6);
  const d = { codigo: txt(b.codigo, 40), nombre: txt(b.nombre, 80), costo: num(b.costo), precio: num(b.precio), minimo: num(b.minimo), area: txt(b.area, 60), servicio: b.servicio || paquete ? 1 : 0,
    paquete: paquete ? paquete.toUpperCase() : null, incluye: txt(b.incluye, 300), color: /^#[0-9a-f]{6}$/i.test(String(b.color || '')) ? b.color : null };
  if (!d.nombre) throw new ErrorUsuario('Escriba el nombre del producto');
  if (!(d.precio > 0)) throw new ErrorUsuario('Escriba el precio de venta');
  return d;
}
ruta('POST', '/api/productos', 'productos', ({ body, u }) => tx(() => {
  const d = limpiarProd(body), ex = num(body.existencia);
  if (d.codigo && get('SELECT id FROM productos WHERE codigo=? AND activo=1', d.codigo)) throw new ErrorUsuario('Ya existe un producto con ese código');
  if (d.paquete && get('SELECT id FROM productos WHERE paquete=? AND activo=1', d.paquete)) throw new ErrorUsuario('Ya existe el paquete ' + d.paquete);
  const r = run('INSERT INTO productos(codigo,nombre,costo,precio,existencia,minimo,area,servicio,paquete,incluye,color) VALUES(?,?,?,?,?,?,?,?,?,?,?)', d.codigo, d.nombre, d.costo, d.precio, d.servicio ? 0 : ex, d.minimo, d.area, d.servicio, d.paquete, d.incluye, d.color);
  if (ex && !d.servicio) run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', ahora(), r.id, 'entrada', ex, 'Alta del producto', u.id);
  prodLavado(r.id, body);
  return r;
}));
ruta('PUT', '/api/productos/:id', 'productos', ({ body, p, u }) => tx(() => {
  const a = get('SELECT * FROM productos WHERE id=?', Number(p.id)); if (!a) throw new ErrorUsuario('No existe', 404);
  const d = limpiarProd(body);
  if (d.codigo && get('SELECT id FROM productos WHERE codigo=? AND id<>? AND activo=1', d.codigo, a.id)) throw new ErrorUsuario('Ya existe un producto con ese código');
  if (d.paquete && get('SELECT id FROM productos WHERE paquete=? AND id<>? AND activo=1', d.paquete, a.id)) throw new ErrorUsuario('Ya existe el paquete ' + d.paquete);
  run('UPDATE productos SET codigo=?,nombre=?,costo=?,precio=?,minimo=?,area=?,servicio=?,paquete=?,incluye=?,color=? WHERE id=?', d.codigo, d.nombre, d.costo, d.precio, d.minimo, d.area, d.servicio, d.paquete, d.incluye, d.color, a.id);
  prodLavado(a.id, body);
  if (!d.servicio && body.existencia !== undefined && num(body.existencia) !== a.existencia) {
    run('UPDATE productos SET existencia=? WHERE id=?', num(body.existencia), a.id);
    run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', ahora(), a.id, 'ajuste', r2(num(body.existencia) - a.existencia), txt(body.motivo) || 'Ajuste de inventario', u.id);
  }
}));
// 1.8 Importar productos de Excel: si el código (o el nombre) ya existe se actualiza; la existencia se suma o se reemplaza
ruta('POST', '/api/productos/importar', 'productos', ({ body, u }) => tx(() => {
  const lista = Array.isArray(body.productos) ? body.productos.slice(0, 5000) : [], modo = body.existencia === 'reemplazar' ? 'reemplazar' : 'sumar';
  const res = { creados: 0, actualizados: 0, errores: [] };
  lista.forEach((b, i) => {
    let d; try { d = limpiarProd(b); } catch (e) { res.errores.push(`Renglón ${i + 2}: ${e.message}`); return; }
    const ex = b.existencia === undefined || b.existencia === '' ? null : num(b.existencia);
    const a = (d.codigo && get('SELECT * FROM productos WHERE codigo=? AND activo=1', d.codigo)) || get('SELECT * FROM productos WHERE lower(nombre)=lower(?) AND activo=1', d.nombre);
    if (a) {
      run('UPDATE productos SET codigo=COALESCE(?,codigo),nombre=?,costo=CASE WHEN ?>0 THEN ? ELSE costo END,precio=?,minimo=?,area=COALESCE(?,area) WHERE id=?', d.codigo, d.nombre, d.costo, d.costo, d.precio, d.minimo, d.area, a.id);
      if (ex !== null) {
        const nueva = modo === 'sumar' ? r2(a.existencia + ex) : ex;
        if (nueva !== a.existencia) { run('UPDATE productos SET existencia=? WHERE id=?', nueva, a.id); run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', ahora(), a.id, modo === 'sumar' ? 'entrada' : 'ajuste', r2(nueva - a.existencia), 'Importado de Excel', u.id); }
      }
      res.actualizados++;
    } else {
      const r = run('INSERT INTO productos(codigo,nombre,costo,precio,existencia,minimo,area) VALUES(?,?,?,?,?,?,?)', d.codigo, d.nombre, d.costo, d.precio, ex || 0, d.minimo, d.area);
      if (ex) run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', ahora(), r.id, 'entrada', ex, 'Importado de Excel', u.id);
      res.creados++;
    }
  });
  return res;
}));
ruta('DELETE', '/api/productos/:id', 'productos', ({ p }) => { run('UPDATE productos SET activo=0 WHERE id=?', Number(p.id)); });
ruta('POST', '/api/productos/:id/entrada', 'inventario', ({ body, p, u }) => tx(() => {
  const a = get('SELECT * FROM productos WHERE id=? AND activo=1', Number(p.id)); if (!a) throw new ErrorUsuario('No existe', 404);
  const c = num(body.cantidad); if (!(c > 0)) throw new ErrorUsuario('Escriba la cantidad que llegó');
  run('UPDATE productos SET existencia=existencia+?, costo=CASE WHEN ?>0 THEN ? ELSE costo END WHERE id=?', c, num(body.costo), num(body.costo), a.id);
  run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', ahora(), a.id, 'entrada', c, txt(body.nota) || 'Compra', u.id);
}));
ruta('GET', '/api/movimientos', 'sesion', () => all(`SELECT m.*, p.nombre producto, u.nombre usuario FROM movimientos m LEFT JOIN productos p ON p.id=m.producto_id
  LEFT JOIN usuarios u ON u.id=m.usuario_id ORDER BY m.id DESC LIMIT 100`));

// ---------- Ventas de tienda ----------
ruta('POST', '/api/ventas', 'vender', ({ body, u }) => tx(() => {
  const items = Array.isArray(body.items) ? body.items : [];
  if (!items.length) throw new ErrorUsuario('La cuenta está vacía');
  const metodo = body.metodo;
  let estancia = null;
  if (metodo === 'habitacion') {
    estancia = get('SELECT * FROM estancias WHERE habitacion_id=? AND activa=1', Number(body.habitacion_id));
    if (!estancia) throw new ErrorUsuario('Esa habitación no tiene huésped');
  } else if (!METODOS.includes(metodo) && metodo !== 'mixto') throw new ErrorUsuario('Forma de pago inválida');
  const lineas = items.map((it) => {
    const pr = get('SELECT * FROM productos WHERE id=? AND activo=1', Number(it.producto_id)), c = num(it.cantidad);
    if (!pr) throw new ErrorUsuario('Un producto ya no existe');
    if (!(c > 0)) throw new ErrorUsuario('Cantidad inválida');
    if (!pr.servicio && pr.existencia < c) throw new ErrorUsuario(`Solo quedan ${pr.existencia} de ${pr.nombre}`);
    return { pr, c, importe: r2(pr.precio * c) };
  });
  const mv = estancia ? null : memPrepararVenta(body, lineas); // 1.4: membresías (lavado incluido y renovación)
  const total = r2(lineas.reduce((s, l) => s + l.importe, 0)), recibido = metodo === 'efectivo' ? num(body.recibido) : 0;
  if (metodo === 'efectivo' && recibido && recibido < total) throw new ErrorUsuario('El efectivo recibido no alcanza');
  const t = estancia ? turnoAbierto(u.id) : turnoCaja(u.id);
  const folio = siguienteFolio('venta'), fecha = ahora();
  const v = run('INSERT INTO ventas(folio,fecha,total,metodo,estancia_id,recibido,cambio,usuario_id,turno_id) VALUES(?,?,?,?,?,?,?,?,?)', folio, fecha, total, metodo, estancia?.id, recibido, recibido ? r2(recibido - total) : 0, u.id, t?.id ?? null);
  for (const l of lineas) {
    run('INSERT INTO venta_items(venta_id,producto_id,descripcion,cantidad,precio,costo,importe,paquete) VALUES(?,?,?,?,?,?,?,?)', v.id, l.pr.id, l.desc || l.pr.nombre, l.c, l.pr.precio, l.pr.costo, l.importe, l.pr.paquete || null);
    if (!l.pr.servicio) {
      run('UPDATE productos SET existencia=existencia-? WHERE id=?', l.c, l.pr.id);
      run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', fecha, l.pr.id, 'venta', -l.c, 'Venta ' + folio, u.id);
    }
    // El servicio de limpieza cargado a la habitación cuenta como "Cuota de limpieza" en los reportes
    if (estancia) run('INSERT INTO cargos(estancia_id,fecha,descripcion,cantidad,importe,venta_id,tipo,usuario_id) VALUES(?,?,?,?,?,?,?,?)', estancia.id, fecha, l.pr.nombre, l.c, l.importe, v.id, l.pr.codigo === 'SERV-LIMPIEZA' ? 'limpieza' : 'consumo', u.id);
  }
  if (!estancia && total > 0) {
    const pg = pagar(total, metodo, 'tienda', null, v.id, u.id, null, body.usd, metodo === 'efectivo' && recibido ? { efectivo: recibido } : body.partes);
    const metFinal = pg.filas.length === 1 ? pg.filas[0].metodo : 'mixto';
    run('UPDATE ventas SET recibido=?, cambio=?, metodo=? WHERE id=?', pg.total, pg.cambio, metFinal, v.id);
  } else if (!estancia) run("UPDATE ventas SET recibido=0, cambio=0, metodo='membresia' WHERE id=?", v.id); // lavado cubierto por la membresía
  const memInfo = memDespuesVenta(mv, v.id, u.id, body.placas);
  if (txt(body.nota, 300)) run('UPDATE ventas SET nota=? WHERE id=?', txt(body.nota, 300), v.id);
  pedirCajon(); // Carwash: el cajón se abre en cada cobro (efectivo, dólares, tarjeta o transferencia)
  if (txt(body.placas, 20) || txt(body.vehiculo, 40)) run('UPDATE ventas SET placas=?, vehiculo=? WHERE id=?', txt(body.placas, 20)?.toUpperCase() ?? null, txt(body.vehiculo, 40), v.id);
  if (!estancia) lavadoDespuesVenta(v.id, lineas, body, u.id); // 1.5: lavador asignado, tiempo y comisión
  return { ...ticketVenta(v.id), pago: get('SELECT SUM(usd) usd, MAX(tc) tc, SUM(cambio) cambio FROM pagos WHERE venta_id=?', v.id) || null, formas: all('SELECT metodo, monto, usd FROM pagos WHERE venta_id=?', v.id), membresia: memInfo };
}));
function ticketVenta(id) {
  const v = get('SELECT v.*, u.nombre usuario, hb.numero FROM ventas v LEFT JOIN usuarios u ON u.id=v.usuario_id LEFT JOIN estancias e ON e.id=v.estancia_id LEFT JOIN habitaciones hb ON hb.id=e.habitacion_id WHERE v.id=?', id);
  const lav = get("SELECT e.nombre, l.fin_estimado, l.minutos FROM lavados l JOIN empleados e ON e.id=l.empleado_id WHERE l.venta_id=? AND l.estado<>'cancelado' ORDER BY l.id DESC LIMIT 1", id);
  return { ...v, lavador: lav?.nombre || null, listo: lav && lav.minutos ? lav.fin_estimado : null, items: all('SELECT vi.*, p.incluye FROM venta_items vi LEFT JOIN productos p ON p.id=vi.producto_id WHERE vi.venta_id=?', id) };
}
ruta('GET', '/api/ventas', 'sesion', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d;
  return all(`SELECT v.*, u.nombre usuario, hb.numero FROM ventas v LEFT JOIN usuarios u ON u.id=v.usuario_id LEFT JOIN estancias e ON e.id=v.estancia_id LEFT JOIN habitaciones hb ON hb.id=e.habitacion_id
    WHERE substr(v.fecha,1,10) BETWEEN ? AND ? ORDER BY v.fecha DESC`, d, h).map((v) => ({ ...v, items: all('SELECT descripcion, cantidad, importe, paquete FROM venta_items WHERE venta_id=?', v.id) }));
});
ruta('POST', '/api/ventas/:id/cancelar', 'cancelar', ({ p, u, body }) => tx(() => {
  const v = get('SELECT * FROM ventas WHERE id=?', Number(p.id));
  if (!v || v.cancelada) throw new ErrorUsuario('La venta no existe o ya está cancelada');
  // Carwash: queda guardado quién canceló, cuándo y por qué (reporte de cancelaciones)
  run('UPDATE ventas SET cancelo_id=?, cancelo_fecha=?, cancelo_motivo=? WHERE id=?', u.id, ahora(), txt(body?.motivo, 200), v.id);
  for (const it of all('SELECT vi.*, COALESCE(pr.servicio,0) servicio FROM venta_items vi LEFT JOIN productos pr ON pr.id=vi.producto_id WHERE vi.venta_id=?', v.id)) {
    if (it.servicio) continue; // los paquetes y servicios no llevan inventario
    run('UPDATE productos SET existencia=existencia+? WHERE id=?', it.cantidad, it.producto_id);
    run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', ahora(), it.producto_id, 'cancelacion', it.cantidad, 'Cancelación venta ' + v.folio, u.id);
  }
  run('DELETE FROM cargos WHERE venta_id=?', v.id);
  run('DELETE FROM pagos WHERE venta_id=?', v.id);
  memCancelarVenta(v.id); // 1.4: regresa la vigencia de la membresía y libera el lavado
  run("UPDATE lavados SET estado='cancelado' WHERE venta_id=?", v.id); // 1.5: el carro ya no cuenta para el lavador
  run('UPDATE ventas SET cancelada=1 WHERE id=?', v.id);
}));

// ======================================================================
// Carwash 1.5: LAVADORES, TIEMPO DE LAVADO Y COMISIONES
// Al cobrar se elige quién lava el carro. Cada paquete tiene su tiempo (minutos) para saber si el lavador ya está libre;
// se puede liberar a mano si terminó antes, o elegir a uno ocupado (se da por terminado su carro anterior).
// Si las comisiones están encendidas, cada carro le genera su comisión (por paquete, o un monto fijo por carro)
// y al final del día se le paga desde la caja: queda como gasto "Comisiones a lavadores".
// ======================================================================
const masMin = (f, m) => { const d = aFecha(f); d.setMinutes(d.getMinutes() + m); return fechaHoraL(d); };
const fechaHoraL = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
// Los carros cuyo tiempo ya pasó se dan por terminados solos
function lavadosVencidos() { run("UPDATE lavados SET estado='terminado', fin_real=fin_estimado WHERE estado='lavando' AND fin_estimado<=?", ahora()); }
function comisionDe(lineas) {
  if (cfg('cw_comisiones') !== '1') return 0;
  const carros = lineas.filter((l) => l.pr.paquete).reduce((s, l) => s + l.c, 0);
  if (cfg('cw_comision_modo') === 'fijo') return r2(num(cfg('cw_comision_fija')) * carros);
  return r2(lineas.reduce((s, l) => {
    if (!l.pr.servicio || !l.pr.com_tipo || !(l.pr.com_valor > 0)) return s;
    return s + (l.pr.com_tipo === 'porc' ? l.pr.precio * l.c * l.pr.com_valor / 100 : l.pr.com_valor * l.c);
  }, 0));
}
function minutosDe(lineas) {
  const def = ent(cfg('cw_minutos_lavado')) || 30;
  return lineas.reduce((s, l) => s + (l.pr.paquete ? (ent(l.pr.minutos) || def) * l.c : l.pr.servicio && l.pr.minutos ? ent(l.pr.minutos) * l.c : 0), 0);
}
const lavadorActivo = (id) => get('SELECT id, nombre FROM empleados WHERE id=? AND activo=1 AND lavador=1', Number(id) || 0);
// Se llama dentro de la venta (misma transacción)
function lavadoDespuesVenta(ventaId, lineas, body, uid) {
  const paqs = lineas.filter((l) => l.pr.paquete);
  const hayLav = cfg('cw_lavadores') !== '0' && get('SELECT COUNT(*) n FROM empleados WHERE activo=1 AND lavador=1').n > 0;
  if (!hayLav || !lineas.some((l) => l.pr.servicio && !/^MEM-/.test(l.pr.codigo || ''))) return null;
  if (!Number(body.lavador_id)) {
    if (paqs.length && cfg('cw_pedir_lavador') === '1') throw new ErrorUsuario('Elija quién va a lavar el carro');
    return null;
  }
  const e = lavadorActivo(body.lavador_id);
  if (!e) throw new ErrorUsuario('Ese lavador ya no está dado de alta');
  lavadosVencidos();
  const t = ahora();
  // Elegido aunque estaba ocupado: terminó antes, se libera su carro anterior
  run("UPDATE lavados SET estado='terminado', fin_real=? WHERE empleado_id=? AND estado='lavando'", t, e.id);
  const min = minutosDe(lineas), v = get('SELECT placas, vehiculo FROM ventas WHERE id=?', ventaId);
  const desc = lineas.filter((l) => l.pr.servicio && !/^MEM-/.test(l.pr.codigo || '')).map((l) => (l.c > 1 ? l.c + ' ' : '') + (l.pr.paquete ? 'Paquete ' + l.pr.paquete : l.pr.nombre)).join(', ');
  run(`INSERT INTO lavados(venta_id,empleado_id,paquetes,descripcion,placas,vehiculo,inicio,fin_estimado,minutos,comision,estado,usuario_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`,
    ventaId, e.id, paqs.map((l) => l.pr.paquete).join(',') || null, desc, v?.placas || null, v?.vehiculo || null, t, masMin(t, min), min, comisionDe(lineas), min > 0 ? 'lavando' : 'terminado', uid);
  return e.nombre;
}
function estadoLavadores() {
  lavadosVencidos();
  const t = hoy();
  return all('SELECT id, nombre, telefono FROM empleados WHERE activo=1 AND lavador=1 ORDER BY nombre').map((e) => {
    const l = get("SELECT l.*, v.folio FROM lavados l LEFT JOIN ventas v ON v.id=l.venta_id WHERE l.empleado_id=? AND l.estado='lavando' ORDER BY l.inicio DESC LIMIT 1", e.id);
    const dia = get("SELECT COUNT(*) n, COALESCE(SUM(comision),0) c, COALESCE(SUM(CASE WHEN pagado=0 THEN comision ELSE 0 END),0) p FROM lavados WHERE empleado_id=? AND estado<>'cancelado' AND substr(inicio,1,10)=?", e.id, t);
    const pend = get("SELECT COALESCE(SUM(comision),0) p, COUNT(*) n FROM lavados WHERE empleado_id=? AND estado<>'cancelado' AND pagado=0 AND comision>0", e.id);
    return { ...e, libre: !l, lavando: l ? { id: l.id, folio: l.folio, descripcion: l.descripcion, placas: l.placas, vehiculo: l.vehiculo, inicio: l.inicio, hasta: l.fin_estimado, minutos: l.minutos } : null,
      carros_hoy: dia.n, comision_hoy: r2(dia.c), pendiente: r2(pend.p), pendientes: pend.n };
  });
}
ruta('GET', '/api/lavadores/estado', 'sesion', () => ({ lavadores: estadoLavadores(), ahora: ahora(), comisiones: cfg('cw_comisiones') === '1' }));
ruta('GET', '/api/lavadores', 'lavadores|comisiones', () => all('SELECT id, nombre, telefono, puesto, activo, lavador FROM empleados WHERE lavador=1 ORDER BY activo DESC, nombre'));
function limpiarLav(b) {
  const d = { nombre: txt(b.nombre, 100), telefono: txt(b.telefono, 30) };
  if (!d.nombre) throw new ErrorUsuario('Escriba el nombre del lavador');
  return d;
}
ruta('POST', '/api/lavadores', 'lavadores', ({ body }) => {
  const d = limpiarLav(body);
  // Si ya existe un empleado con ese nombre, solo se marca como lavador
  const ya = get('SELECT id FROM empleados WHERE lower(nombre)=lower(?) AND activo=1', d.nombre);
  if (ya) { run('UPDATE empleados SET lavador=1, telefono=COALESCE(?,telefono) WHERE id=?', d.telefono, ya.id); return { id: ya.id }; }
  return { id: run("INSERT INTO empleados(nombre,puesto,telefono,lavador,activo,creado) VALUES(?,'Lavador',?,1,1,?)", d.nombre, d.telefono, ahora()).id };
});
// Configuración de lavadores y comisiones (la puede cambiar quien administra lavadores)
const CFG_LAV = ['cw_lavadores', 'cw_pedir_lavador', 'cw_minutos_lavado', 'cw_comisiones', 'cw_comision_modo', 'cw_comision_fija'];
ruta('PUT', '/api/lavadores/config', 'lavadores', ({ body }) => {
  for (const k of CFG_LAV) if (body[k] !== undefined) setCfg(k, txt(body[k], 20) ?? '');
  // Tiempo y comisión de cada paquete / servicio
  for (const x of Array.isArray(body.productos) ? body.productos : []) {
    const tipo = ['monto', 'porc'].includes(x.com_tipo) ? x.com_tipo : null;
    run('UPDATE productos SET minutos=?, com_tipo=?, com_valor=? WHERE id=? AND servicio=1', ent(x.minutos) || null, tipo, tipo ? num(x.com_valor) : 0, Number(x.id));
  }
});
ruta('PUT', '/api/lavadores/:id', 'lavadores', ({ body, p }) => {
  const a = get('SELECT * FROM empleados WHERE id=?', Number(p.id)); if (!a) throw new ErrorUsuario('No existe', 404);
  const d = limpiarLav({ nombre: a.nombre, telefono: a.telefono, ...body });
  run('UPDATE empleados SET nombre=?, telefono=?, activo=?, lavador=? WHERE id=?', d.nombre, d.telefono, body.activo === false || body.activo === 0 ? 0 : 1, body.lavador === false || body.lavador === 0 ? 0 : 1, a.id);
});
// Empleados que ya existen (de Gastos / Asistencia) para marcarlos como lavadores
ruta('GET', '/api/lavadores/empleados', 'lavadores', () => all('SELECT id, nombre, puesto, lavador FROM empleados WHERE activo=1 ORDER BY nombre'));
// Liberar a mano: el lavador terminó antes de tiempo
ruta('POST', '/api/lavadores/:id/liberar', 'vender', ({ p }) => {
  const n = run("UPDATE lavados SET estado='terminado', fin_real=? WHERE empleado_id=? AND estado='lavando'", ahora(), Number(p.id)).changes;
  if (!n) throw new ErrorUsuario('Ese lavador ya estaba libre');
});
// Cambiar de lavador un carro ya cobrado (se equivocaron al elegir)
ruta('POST', '/api/lavados/:id/cambiar', 'vender', ({ p, body }) => tx(() => {
  const l = get('SELECT * FROM lavados WHERE id=?', Number(p.id)); if (!l || l.estado === 'cancelado') throw new ErrorUsuario('No existe', 404);
  if (l.pagado) throw new ErrorUsuario('La comisión de ese carro ya se pagó; no se puede cambiar de lavador');
  const e = lavadorActivo(body.lavador_id); if (!e) throw new ErrorUsuario('Elija el lavador');
  if (l.estado === 'lavando') run("UPDATE lavados SET estado='terminado', fin_real=? WHERE empleado_id=? AND estado='lavando' AND id<>?", ahora(), e.id, l.id);
  run('UPDATE lavados SET empleado_id=? WHERE id=?', e.id, l.id);
}));
// Asignar lavador a una venta ya cobrada (se les olvidó elegirlo)
ruta('POST', '/api/ventas/:id/lavador', 'vender', ({ p, body, u }) => tx(() => {
  const v = get('SELECT * FROM ventas WHERE id=? AND cancelada=0', Number(p.id)); if (!v) throw new ErrorUsuario('La venta no existe o está cancelada');
  const ya = get("SELECT id FROM lavados WHERE venta_id=? AND estado<>'cancelado'", v.id);
  if (ya) return post_cambiar(ya.id, body.lavador_id);
  const lineas = all('SELECT vi.cantidad c, p.* FROM venta_items vi JOIN productos p ON p.id=vi.producto_id WHERE vi.venta_id=?', v.id).map((x) => ({ c: x.c, pr: x }));
  if (!lavadoDespuesVenta(v.id, lineas, { lavador_id: body.lavador_id }, u.id)) throw new ErrorUsuario('Esa venta no lleva lavado');
}));
function post_cambiar(id, lavId) {
  const l = get('SELECT * FROM lavados WHERE id=?', id);
  if (l.pagado) throw new ErrorUsuario('La comisión de ese carro ya se pagó; no se puede cambiar de lavador');
  const e = lavadorActivo(lavId); if (!e) throw new ErrorUsuario('Elija el lavador');
  run('UPDATE lavados SET empleado_id=? WHERE id=?', e.id, id);
}
// Comisiones: lo que se debe a cada lavador (todo lo pendiente) y lo de un rango de fechas
function comisionesPeriodo(d, h) {
  const filas = all(`SELECT e.id, e.nombre, COUNT(l.id) carros, COALESCE(SUM(l.minutos),0) minutos, COALESCE(SUM(l.comision),0) generada,
      COALESCE(SUM(CASE WHEN l.pagado=1 THEN l.comision ELSE 0 END),0) pagada, COALESCE(SUM(CASE WHEN l.pagado=0 THEN l.comision ELSE 0 END),0) pendiente,
      (SELECT COALESCE(SUM(vi.importe),0) FROM venta_items vi JOIN lavados x ON x.venta_id=vi.venta_id JOIN productos pr ON pr.id=vi.producto_id
        WHERE x.empleado_id=e.id AND x.estado<>'cancelado' AND substr(x.inicio,1,10) BETWEEN ? AND ? AND pr.servicio=1) vendido
    FROM empleados e JOIN lavados l ON l.empleado_id=e.id AND l.estado<>'cancelado' AND substr(l.inicio,1,10) BETWEEN ? AND ?
    GROUP BY e.id ORDER BY carros DESC, e.nombre`, d, h, d, h).map((x) => ({ ...x, generada: r2(x.generada), pagada: r2(x.pagada), pendiente: r2(x.pendiente), vendido: r2(x.vendido) }));
  const tot = filas.reduce((s, x) => ({ carros: s.carros + x.carros, generada: r2(s.generada + x.generada), pagada: r2(s.pagada + x.pagada), pendiente: r2(s.pendiente + x.pendiente) }), { carros: 0, generada: 0, pagada: 0, pendiente: 0 });
  return { lavadores: filas, total: tot };
}
ruta('GET', '/api/comisiones', 'comisiones|lavadores|reportes', ({ q }) => {
  lavadosVencidos();
  const d = q.desde || hoy(), h = q.hasta || d;
  const porPagar = all(`SELECT e.id, e.nombre, COUNT(l.id) carros, SUM(l.comision) monto, MIN(substr(l.inicio,1,10)) desde, MAX(substr(l.inicio,1,10)) hasta
    FROM lavados l JOIN empleados e ON e.id=l.empleado_id WHERE l.estado<>'cancelado' AND l.pagado=0 AND l.comision>0 GROUP BY e.id ORDER BY e.nombre`).map((x) => ({ ...x, monto: r2(x.monto) }));
  const detalle = all(`SELECT l.id, l.venta_id, l.empleado_id, e.nombre lavador, v.folio, l.inicio, l.fin_estimado, l.fin_real, l.minutos, l.descripcion, l.placas, l.vehiculo, l.comision, l.estado, l.pagado, l.fecha_pago, g.folio gasto_folio
    FROM lavados l JOIN empleados e ON e.id=l.empleado_id LEFT JOIN ventas v ON v.id=l.venta_id LEFT JOIN gastos g ON g.id=l.gasto_id
    WHERE l.estado<>'cancelado' AND substr(l.inicio,1,10) BETWEEN ? AND ? ORDER BY l.inicio DESC LIMIT 3000`, d, h);
  const pagos = all(`SELECT g.id, g.folio, g.fecha, g.monto, g.metodo, g.recibe, g.concepto, u.nombre usuario FROM gastos g LEFT JOIN usuarios u ON u.id=g.usuario_id
    WHERE g.cancelado=0 AND g.categoria='Comisiones a lavadores' AND substr(g.fecha,1,10) BETWEEN ? AND ? ORDER BY g.fecha DESC`, d, h);
  return { desde: d, hasta: h, activo: cfg('cw_comisiones') === '1', porPagar, ...comisionesPeriodo(d, h), detalle, pagos };
});
// Pagar comisiones: sale de la caja como gasto y quedan marcadas como pagadas
ruta('POST', '/api/comisiones/pagar', 'comisiones', ({ body, u }) => tx(() => {
  const e = get('SELECT id, nombre FROM empleados WHERE id=?', Number(body.empleado_id) || 0); if (!e) throw new ErrorUsuario('Elija el lavador');
  const hasta = /^\d{4}-\d{2}-\d{2}$/.test(body.hasta || '') ? body.hasta : hoy();
  const ids = Array.isArray(body.ids) && body.ids.length ? body.ids.map(Number).filter(Boolean) : null;
  const ls = all(`SELECT id, comision, substr(inicio,1,10) dia FROM lavados WHERE empleado_id=? AND estado<>'cancelado' AND pagado=0 AND comision>0 AND substr(inicio,1,10)<=?`, e.id, hasta)
    .filter((l) => !ids || ids.includes(l.id));
  if (!ls.length) throw new ErrorUsuario(`${e.nombre} no tiene comisiones por pagar`);
  const monto = r2(ls.reduce((s, l) => s + l.comision, 0)), dias = [...new Set(ls.map((l) => l.dia))].sort();
  const per = dias.length === 1 ? dias[0].split('-').reverse().join('/') : `${dias[0].split('-').reverse().join('/')} al ${dias.at(-1).split('-').reverse().join('/')}`;
  const gid = crearGasto({ concepto: `Comisiones de lavado · ${e.nombre} · ${ls.length} carro(s) · ${per}`, monto, metodo: body.metodo || 'efectivo', categoria: 'Comisiones a lavadores', grupo: 'Nómina y personal',
    empleado_id: e.id, recibe: e.nombre, entrega: u.nombre, firma_recibe: body.firma_recibe, periodo: per, nota: txt(body.nota, 300), fuera_de_caja: !!body.fuera_de_caja }, u.id);
  const t = ahora();
  for (const l of ls) run('UPDATE lavados SET pagado=1, gasto_id=?, fecha_pago=? WHERE id=?', gid, t, l.id);
  return { gasto_id: gid, folio: get('SELECT folio FROM gastos WHERE id=?', gid).folio, monto, carros: ls.length, lavador: e.nombre, periodo: per };
}));
function lavadoresPeriodo(d, h) {
  const c = comisionesPeriodo(d, h);
  return { activo: cfg('cw_comisiones') === '1', ...c, sinLavador: get(`SELECT COALESCE(SUM(vi.cantidad),0) n FROM venta_items vi JOIN ventas v ON v.id=vi.venta_id WHERE v.cancelada=0 AND vi.paquete IS NOT NULL
    AND substr(v.fecha,1,10) BETWEEN ? AND ? AND NOT EXISTS (SELECT 1 FROM lavados l WHERE l.venta_id=v.id AND l.estado<>'cancelado')`, d, h).n };
}

// ======================================================================
// Carwash 1.2: PANTALLA DEL CLIENTE (segundo monitor)
// La caja manda lo que se está cobrando y la pantalla que se abrió en la MISMA computadora lo muestra al instante.
// ======================================================================
const pantallas = new Map(), subsPantalla = new Map();
const IPS_PROPIAS = () => new Set(['127.0.0.1', '::1', ...ipsEquipo().map((i) => i.ip)]);
const clavePantalla = (req, q = {}) => { const ip = ipDe(req); if (q.caja) return String(q.caja); return IPS_PROPIAS().has(ip) ? 'local' : ip; };
function publicarPantalla(clave, datos) {
  const st = { ...datos, t: Date.now() };
  pantallas.set(clave, st);
  for (const r of subsPantalla.get(clave) || []) { try { r.write('data: ' + JSON.stringify(st) + '\n\n'); } catch { /* cerrada */ } }
}
const paquetesPantalla = () => all("SELECT paquete, nombre, precio, incluye, color FROM productos WHERE activo=1 AND paquete IS NOT NULL ORDER BY CAST(paquete AS INTEGER), paquete");
ruta('GET', '/api/pantalla/info', null, () => ({ negocio: cfg('hotel_nombre'), logo: cfg('cw_logo_pantalla'), bienvenida: cfg('cw_pantalla_bienvenida'), gracias: cfg('cw_pantalla_gracias'),
  menu: cfg('cw_pantalla_menu') !== '0', tc: num(cfg('tipo_cambio')), paquetes: paquetesPantalla() }));
ruta('GET', '/api/pantalla/stream', null, ({ req, res, q }) => {
  const clave = clavePantalla(req, q);
  res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
  res.write('retry: 2000\n\n');
  if (pantallas.has(clave)) res.write('data: ' + JSON.stringify(pantallas.get(clave)) + '\n\n');
  if (!subsPantalla.has(clave)) subsPantalla.set(clave, new Set());
  subsPantalla.get(clave).add(res);
  const ka = setInterval(() => { try { res.write(': ok\n\n'); } catch { /* cerrada */ } }, 25000);
  req.on('close', () => { clearInterval(ka); subsPantalla.get(clave)?.delete(res); });
});
ruta('POST', '/api/pantalla', 'sesion', ({ req, body }) => {
  const estado = ['espera', 'venta', 'cobro', 'pagado'].includes(body.estado) ? body.estado : 'espera';
  const datos = JSON.parse(JSON.stringify(body || {}).slice(0, 20000) || '{}');
  publicarPantalla(clavePantalla(req), { ...datos, estado });
});

// ======================================================================
// Carwash 1.2: MONITOREO EN LA NUBE (Firebase, como el gimnasio) — https://maxsel-pos.web.app/carwash
// ======================================================================
function resumenNube() {
  const t = hoy(), a = resumenCW(t, t), k = paquetesPeriodo(t, t);
  const P = Object.fromEntries(all(`SELECT p.metodo, SUM(p.monto) m, SUM(COALESCE(p.usd,0)) u FROM pagos p JOIN ventas v ON v.id=p.venta_id WHERE v.cancelada=0 AND substr(v.fecha,1,10)=? GROUP BY p.metodo`, t).map((x) => [x.metodo, { m: r2(x.m), u: r2(x.u) }]));
  const abiertos = all("SELECT id FROM turnos WHERE estado='abierto'").map((x) => resumenTurno(x.id));
  const mes = resumenCW(t.slice(0, 8) + '01', t);
  return { fecha: t, hora: ahora().slice(11, 16), negocio: cfg('hotel_nombre'), carros: a.carros, ventas: a.total, tickets: a.tickets, paquetes: a.paquetes, extras: a.extras, productos: a.productos,
    ticket_promedio: a.ticketPromedio, pct_extra: a.pctExtra, canceladas: a.canceladas, cancelado: a.canceladoTotal, gastos: a.gastos, utilidad: a.utilidad,
    efectivo: P.efectivo?.m || 0, usd: P.dolares?.u || 0, usd_mxn: P.dolares?.m || 0, tarjeta: P.tarjeta?.m || 0, transferencia: P.transferencia?.m || 0,
    por_paquete: k.porPaquete.map((x) => ({ paquete: x.paquete, nombre: x.nombre, n: x.n, total: x.total })),
    cajas_abiertas: abiertos.length, efectivo_en_cajas: r2(abiertos.reduce((s, r) => s + (r.esperado?.mxn || 0), 0)), usd_en_cajas: r2(abiertos.reduce((s, r) => s + (r.esperado?.usd || 0), 0)),
    por_surtir: get('SELECT COUNT(*) n FROM productos WHERE activo=1 AND COALESCE(servicio,0)=0 AND existencia<=minimo').n, mes: mes.total, mes_carros: mes.carros,
    lavadores: (() => { const L = estadoLavadores(), c = lavadoresPeriodo(t, t); return { lista: L.map((x) => ({ nombre: x.nombre, libre: x.libre, hasta: x.lavando?.hasta?.slice(11, 16) || null, placas: x.lavando?.placas || null, carros: x.carros_hoy, comision: x.comision_hoy, pendiente: x.pendiente })),
      comisiones: cfg('cw_comisiones') === '1', generada: c.total.generada, pagada: c.total.pagada, pendiente: r2(L.reduce((s, x) => s + x.pendiente, 0)), sin_lavador: c.sinLavador }; })() };
}
const USUARIO_NUBE = { id: 0, nombre: 'Monitoreo en la nube', rol: 'admin', perm: new Set(PERMISOS_ROL.admin) };
async function ejecutarParaNube(url) {
  const u = new URL(url, 'http://x');
  const r = rutas.find((x) => x.metodo === 'GET' && x.re.test(u.pathname));
  if (!r) throw new Error('Reporte no encontrado');
  return r.fn({ q: Object.fromEntries(u.searchParams), p: r.re.exec(u.pathname).groups || {}, u: USUARIO_NUBE, body: {} });
}
const nube = crearSincronizador({ cfg, setCfg, resumenHoy: resumenNube, ejecutar: ejecutarParaNube, version: VERSION, equipo: os.hostname(), log: (m) => console.log(`[${ahora()}] ${m}`) });
ruta('GET', '/api/movil/resumen', 'reportes', () => resumenNube());
ruta('GET', '/api/nube/estado', 'config', () => ({ activo: cfg('nube_activo') === '1', email: cfg('nube_email'), pagina: URL_PAGINA, ...nube.estado }));
ruta('POST', '/api/nube/conectar', 'config', async ({ body }) => {
  const email = txt(body.email)?.toLowerCase(), pass = String(body.password || '');
  if (!email || !pass) throw new ErrorUsuario('Escriba el correo y la contraseña que le dio Maxsel');
  let s;
  try { s = await iniciarSesion(email, pass); } catch (e) { throw new ErrorUsuario(e.message); }
  setCfg('nube_email', email); setCfg('nube_uid', s.uid); setCfg('nube_refresh', s.refresh); setCfg('nube_activo', '1');
  nube.reiniciar();
  await new Promise((ok) => setTimeout(ok, 2500));
  return { ok: true, ...nube.estado };
});
ruta('POST', '/api/nube/desconectar', 'config', () => { setCfg('nube_activo', '0'); setCfg('nube_refresh', ''); nube.detener(); return { ok: true }; });
ruta('POST', '/api/nube/subir', 'config', async () => { await nube.ahora(); return { ok: true, ...nube.estado }; });

// ---------- Carwash: paquetes vendidos (para revisar contra la cámara) ----------
function paquetesPeriodo(d, h, turno) {
  const filtro = turno ? 'v.turno_id=?' : 'substr(v.fecha,1,10) BETWEEN ? AND ?', args = turno ? [turno] : [d, h];
  const porPaquete = all(`SELECT vi.paquete, MAX(vi.descripcion) nombre, SUM(vi.cantidad) n, SUM(vi.importe) total FROM venta_items vi JOIN ventas v ON v.id=vi.venta_id
    WHERE v.cancelada=0 AND vi.paquete IS NOT NULL AND ${filtro} GROUP BY vi.paquete ORDER BY CAST(vi.paquete AS INTEGER), vi.paquete`, ...args).map((x) => ({ ...x, total: r2(x.total) }));
  const otros = get(`SELECT COALESCE(SUM(CASE WHEN p.servicio=1 THEN vi.importe END),0) servicios, COALESCE(SUM(CASE WHEN COALESCE(p.servicio,0)=0 THEN vi.importe END),0) productos
    FROM venta_items vi JOIN ventas v ON v.id=vi.venta_id LEFT JOIN productos p ON p.id=vi.producto_id WHERE v.cancelada=0 AND vi.paquete IS NULL AND ${filtro}`, ...args);
  const porDia = turno ? [] : all(`SELECT substr(v.fecha,1,10) dia, vi.paquete, SUM(vi.cantidad) n FROM venta_items vi JOIN ventas v ON v.id=vi.venta_id
    WHERE v.cancelada=0 AND vi.paquete IS NOT NULL AND ${filtro} GROUP BY dia, vi.paquete ORDER BY dia`, ...args);
  const lista = all(`SELECT v.id, v.folio, v.fecha, v.placas, v.vehiculo, v.total, v.metodo, u.nombre usuario, vi.paquete, vi.cantidad FROM venta_items vi JOIN ventas v ON v.id=vi.venta_id LEFT JOIN usuarios u ON u.id=v.usuario_id
    WHERE v.cancelada=0 AND vi.paquete IS NOT NULL AND ${filtro} ORDER BY v.fecha DESC LIMIT 2000`, ...args);
  const carros = r2(porPaquete.reduce((t, x) => t + x.n, 0));
  return { desde: d, hasta: h, porPaquete, carros, totalPaquetes: r2(porPaquete.reduce((t, x) => t + x.total, 0)), serviciosExtra: r2(otros.servicios), productos: r2(otros.productos), porDia, lista };
}
ruta('GET', '/api/reporte/paquetes', 'reportes', ({ q }) => { const d = q.desde || hoy(); return paquetesPeriodo(d, q.hasta || d); });
ruta('GET', '/api/turnos/:id/paquetes', 'sesion', ({ p }) => paquetesPeriodo(null, null, Number(p.id)));

// ---------- Carwash 1.1: reporte completo del periodo ----------
const diaISO = (dt) => `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
function resumenCW(d, h) {
  const B = 'v.cancelada=0 AND substr(v.fecha,1,10) BETWEEN ? AND ?';
  const t = get(`SELECT COUNT(*) n, COALESCE(SUM(total),0) total FROM ventas v WHERE ${B}`, d, h);
  const it = get(`SELECT COALESCE(SUM(CASE WHEN vi.paquete IS NOT NULL THEN vi.cantidad END),0) carros, COALESCE(SUM(CASE WHEN vi.paquete IS NOT NULL THEN vi.importe END),0) paquetes,
    COALESCE(SUM(CASE WHEN vi.paquete IS NULL AND COALESCE(p.servicio,0)=1 THEN vi.importe END),0) extras, COALESCE(SUM(CASE WHEN vi.paquete IS NULL AND COALESCE(p.servicio,0)=0 THEN vi.importe END),0) productos,
    COALESCE(SUM(vi.costo*vi.cantidad),0) costo FROM venta_items vi JOIN ventas v ON v.id=vi.venta_id LEFT JOIN productos p ON p.id=vi.producto_id WHERE ${B}`, d, h);
  // tickets con paquete que además compraron algo extra (venta adicional)
  const conPaq = get(`SELECT COUNT(*) n, COALESCE(SUM(CASE WHEN EXISTS(SELECT 1 FROM venta_items x WHERE x.venta_id=v.id AND x.paquete IS NULL) THEN 1 ELSE 0 END),0) conExtra
    FROM ventas v WHERE ${B} AND EXISTS(SELECT 1 FROM venta_items y WHERE y.venta_id=v.id AND y.paquete IS NOT NULL)`, d, h);
  const canc = get(`SELECT COUNT(*) n, COALESCE(SUM(total),0) t FROM ventas v WHERE v.cancelada=1 AND substr(v.fecha,1,10) BETWEEN ? AND ?`, d, h);
  const gastos = r2(get('SELECT COALESCE(SUM(monto),0) t FROM gastos WHERE cancelado=0 AND substr(fecha,1,10) BETWEEN ? AND ?', d, h).t);
  const dias = Math.max(1, Math.round((aFecha(h) - aFecha(d)) / 86400000) + 1);
  return { tickets: t.n, total: r2(t.total), carros: r2(it.carros), paquetes: r2(it.paquetes), extras: r2(it.extras), productos: r2(it.productos), costo: r2(it.costo),
    utilidadBruta: r2(t.total - it.costo), gastos, utilidad: r2(t.total - it.costo - gastos), ticketPromedio: t.n ? r2(t.total / t.n) : 0,
    carroPromedio: it.carros ? r2((it.paquetes + it.extras) / it.carros) : 0, ticketsPaquete: conPaq.n, conExtra: conPaq.conExtra, pctExtra: conPaq.n ? Math.round(conPaq.conExtra / conPaq.n * 100) : 0,
    canceladas: canc.n, canceladoTotal: r2(canc.t), dias, carrosDia: r2(it.carros / dias), ventaDia: r2(t.total / dias) };
}
ruta('GET', '/api/reporte/carwash', 'reportes', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d;
  const B = 'v.cancelada=0 AND substr(v.fecha,1,10) BETWEEN ? AND ?';
  // Periodo anterior del mismo largo (para comparar)
  const ini = aFecha(d), fin = aFecha(h), largo = Math.round((fin - ini) / 86400000) + 1;
  const aH = new Date(ini); aH.setDate(aH.getDate() - 1); const aD = new Date(aH); aD.setDate(aD.getDate() - (largo - 1));
  const porHora = Array.from({ length: 24 }, (_, i) => ({ hora: i, carros: 0, tickets: 0, total: 0 }));
  for (const x of all(`SELECT CAST(substr(v.fecha,12,2) AS INTEGER) hr, COUNT(*) tickets, SUM(v.total) total, SUM((SELECT COALESCE(SUM(cantidad),0) FROM venta_items WHERE venta_id=v.id AND paquete IS NOT NULL)) carros FROM ventas v WHERE ${B} GROUP BY hr`, d, h))
    if (porHora[x.hr]) Object.assign(porHora[x.hr], { tickets: x.tickets, total: r2(x.total), carros: x.carros });
  const porSemana = Array.from({ length: 7 }, (_, i) => ({ dia: i, carros: 0, total: 0, fechas: 0 })); // 0 = domingo
  for (const x of all(`SELECT CAST(strftime('%w', substr(v.fecha,1,10)) AS INTEGER) dw, COUNT(DISTINCT substr(v.fecha,1,10)) fechas, SUM(v.total) total, SUM((SELECT COALESCE(SUM(cantidad),0) FROM venta_items WHERE venta_id=v.id AND paquete IS NOT NULL)) carros FROM ventas v WHERE ${B} GROUP BY dw`, d, h))
    Object.assign(porSemana[x.dw], { carros: x.carros, total: r2(x.total), fechas: x.fechas });
  const porDia = all(`SELECT substr(v.fecha,1,10) dia, COUNT(*) tickets, SUM(v.total) total, SUM((SELECT COALESCE(SUM(cantidad),0) FROM venta_items WHERE venta_id=v.id AND paquete IS NOT NULL)) carros FROM ventas v WHERE ${B} GROUP BY dia ORDER BY dia`, d, h).map((x) => ({ ...x, total: r2(x.total) }));
  const porVehiculo = all(`SELECT COALESCE(NULLIF(v.vehiculo,''),'Sin especificar') vehiculo, SUM(vi.cantidad) carros, SUM(vi.importe) total FROM venta_items vi JOIN ventas v ON v.id=vi.venta_id WHERE ${B} AND vi.paquete IS NOT NULL GROUP BY 1 ORDER BY carros DESC`, d, h).map((x) => ({ ...x, total: r2(x.total) }));
  const vehPaq = all(`SELECT COALESCE(NULLIF(v.vehiculo,''),'Sin especificar') vehiculo, vi.paquete, SUM(vi.cantidad) n FROM venta_items vi JOIN ventas v ON v.id=vi.venta_id WHERE ${B} AND vi.paquete IS NOT NULL GROUP BY 1, 2`, d, h);
  const porCajero = all(`SELECT COALESCE(u.nombre,'—') cajero, COUNT(*) tickets, SUM(v.total) total, SUM((SELECT COALESCE(SUM(cantidad),0) FROM venta_items WHERE venta_id=v.id AND paquete IS NOT NULL)) carros,
    (SELECT COUNT(*) FROM ventas c WHERE c.usuario_id=v.usuario_id AND c.cancelada=1 AND substr(c.fecha,1,10) BETWEEN ? AND ?) canceladas FROM ventas v LEFT JOIN usuarios u ON u.id=v.usuario_id WHERE ${B} GROUP BY v.usuario_id ORDER BY total DESC`, d, h, d, h).map((x) => ({ ...x, total: r2(x.total) }));
  const articulos = all(`SELECT vi.descripcion, MAX(vi.paquete) paquete, MAX(COALESCE(p.servicio,0)) servicio, SUM(vi.cantidad) cantidad, SUM(vi.importe) importe, SUM(vi.costo*vi.cantidad) costo FROM venta_items vi JOIN ventas v ON v.id=vi.venta_id LEFT JOIN productos p ON p.id=vi.producto_id
    WHERE ${B} GROUP BY vi.producto_id, vi.descripcion ORDER BY importe DESC`, d, h).map((x) => ({ ...x, importe: r2(x.importe), costo: r2(x.costo), utilidad: r2(x.importe - x.costo), tipo: x.paquete ? 'paquete' : x.servicio ? 'servicio' : 'producto' }));
  const pagosP = all(`SELECT p.metodo, SUM(p.monto) monto, SUM(COALESCE(p.usd,0)) usd, SUM(COALESCE(p.cambio,0)) cambio, COUNT(DISTINCT p.venta_id) tickets FROM pagos p JOIN ventas v ON v.id=p.venta_id WHERE ${B} GROUP BY p.metodo`, d, h).map((x) => ({ ...x, monto: r2(x.monto), usd: r2(x.usd), cambio: r2(x.cambio) }));
  const canceladas = all(`SELECT v.id, v.folio, v.fecha, v.total, v.placas, v.cancelo_fecha, v.cancelo_motivo, u.nombre vendio, c.nombre cancelo,
    (SELECT GROUP_CONCAT('P'||paquete, ' ') FROM venta_items WHERE venta_id=v.id AND paquete IS NOT NULL) paquetes,
    (SELECT GROUP_CONCAT((CASE WHEN cantidad=CAST(cantidad AS INTEGER) THEN CAST(cantidad AS INTEGER) ELSE cantidad END)||' '||descripcion, ', ') FROM venta_items WHERE venta_id=v.id) detalle
    FROM ventas v LEFT JOIN usuarios u ON u.id=v.usuario_id LEFT JOIN usuarios c ON c.id=v.cancelo_id WHERE v.cancelada=1 AND substr(v.fecha,1,10) BETWEEN ? AND ? ORDER BY v.fecha DESC`, d, h);
  const clientes = all(`SELECT v.placas, COUNT(*) visitas, SUM(v.total) total, MAX(v.fecha) ultimo, MAX(v.vehiculo) vehiculo,
    (SELECT vi.paquete FROM venta_items vi JOIN ventas w ON w.id=vi.venta_id WHERE w.placas=v.placas AND w.cancelada=0 AND vi.paquete IS NOT NULL GROUP BY vi.paquete ORDER BY SUM(vi.cantidad) DESC LIMIT 1) paquete
    FROM ventas v WHERE ${B} AND COALESCE(v.placas,'')<>'' GROUP BY v.placas ORDER BY visitas DESC, total DESC LIMIT 100`, d, h).map((x) => ({ ...x, total: r2(x.total) }));
  const conPlacas = get(`SELECT COUNT(DISTINCT v.placas) n FROM ventas v WHERE ${B} AND COALESCE(v.placas,'')<>''`, d, h).n;
  const regresaron = get(`SELECT COUNT(*) n FROM (SELECT v.placas FROM ventas v WHERE ${B} AND COALESCE(v.placas,'')<>'' GROUP BY v.placas HAVING COUNT(*)>1)`, d, h).n;
  const existencias = all('SELECT nombre, area, existencia, minimo, costo, precio FROM productos WHERE activo=1 AND COALESCE(servicio,0)=0 ORDER BY (existencia<=minimo) DESC, nombre').map((x) => ({ ...x, valor: r2(x.existencia * x.costo) }));
  const gastosP = all(`SELECT COALESCE(grupo,'Otros') grupo, COUNT(*) n, SUM(monto) t FROM gastos WHERE cancelado=0 AND substr(fecha,1,10) BETWEEN ? AND ? GROUP BY 1 ORDER BY t DESC`, d, h).map((x) => ({ ...x, t: r2(x.t) }));
  return { desde: d, hasta: h, anterior: { desde: diaISO(aD), hasta: diaISO(aH), ...resumenCW(diaISO(aD), diaISO(aH)) }, resumen: resumenCW(d, h), paquetes: paquetesPeriodo(d, h),
    porHora, porSemana, porDia, porVehiculo, vehPaq, porCajero, articulos, pagos: pagosP, canceladas, clientes, conPlacas, regresaron, existencias, gastos: gastosP, lavadores: lavadoresPeriodo(d, h) };
});
// Historial de un vehículo por placas
ruta('GET', '/api/placas/:placas', 'reportes', ({ p }) => all(`SELECT v.id, v.folio, v.fecha, v.total, v.vehiculo, v.cancelada, u.nombre usuario,
  (SELECT GROUP_CONCAT((CASE WHEN cantidad=CAST(cantidad AS INTEGER) THEN CAST(cantidad AS INTEGER) ELSE cantidad END)||' '||descripcion, ', ') FROM venta_items WHERE venta_id=v.id) detalle FROM ventas v LEFT JOIN usuarios u ON u.id=v.usuario_id WHERE v.placas=? ORDER BY v.fecha DESC LIMIT 200`, decodeURIComponent(p.placas).toUpperCase()));

// ======================================================================
// Carwash 1.4: MEMBRESÍAS DE LAVADO
// El socio paga su plan (ej. mensual) y lava sin pagar cada vez: ilimitado o con límite por día / por periodo.
// Se reconoce por sus placas en el punto de venta. La membresía se vende como un artículo normal (entra a la caja,
// al corte y a los reportes) y cada lavado del socio queda registrado con $0 en el ticket.
// ======================================================================
run(`CREATE TABLE IF NOT EXISTS mem_planes (id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, precio REAL NOT NULL, dias INTEGER DEFAULT 30,
  paquetes TEXT, por_dia INTEGER DEFAULT 1, por_periodo INTEGER DEFAULT 0, descripcion TEXT, producto_id INTEGER, activo INTEGER DEFAULT 1)`);
run(`CREATE TABLE IF NOT EXISTS mem_socios (id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, telefono TEXT, placas TEXT, vehiculo TEXT, plan_id INTEGER,
  inicio TEXT, vence TEXT, notas TEXT, creado TEXT, usuario_id INTEGER, activo INTEGER DEFAULT 1)`);
run(`CREATE TABLE IF NOT EXISTS mem_pagos (id INTEGER PRIMARY KEY, socio_id INTEGER NOT NULL, venta_id INTEGER, fecha TEXT, plan_id INTEGER, periodos INTEGER DEFAULT 1,
  monto REAL, desde TEXT, hasta TEXT, vence_antes TEXT, usuario_id INTEGER, cancelado INTEGER DEFAULT 0)`);
run(`CREATE TABLE IF NOT EXISTS mem_usos (id INTEGER PRIMARY KEY, socio_id INTEGER NOT NULL, venta_id INTEGER, fecha TEXT, paquete TEXT, placas TEXT, valor REAL,
  usuario_id INTEGER, cancelado INTEGER DEFAULT 0)`);
run('CREATE INDEX IF NOT EXISTS ix_mem_usos ON mem_usos(socio_id, fecha)');
run('CREATE INDEX IF NOT EXISTS ix_mem_pagos ON mem_pagos(venta_id)');
if (!all('PRAGMA table_info(ventas)').some((c) => c.name === 'socio_id')) run('ALTER TABLE ventas ADD COLUMN socio_id INTEGER');
const normPl = (s) => String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
const listaPlacas = (s) => String(s || '').split(/[,;/]+/).map((x) => x.trim().toUpperCase()).filter(Boolean);
const sumarDiasF = (f, n) => { const d = aFecha(f); d.setDate(d.getDate() + n); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const planMem = (id) => get('SELECT * FROM mem_planes WHERE id=?', Number(id) || 0);
const paqsPlan = (p) => String(p?.paquetes || '').split(',').map((x) => x.trim().toUpperCase()).filter(Boolean);
const cubrePlan = (p, paq) => { const l = paqsPlan(p); return !l.length || l.includes(String(paq || '').toUpperCase()); };
function estadoSocio(s, renovando = false) {
  const plan = planMem(s.plan_id), t = hoy();
  const vigente = renovando || !!(s.vence && s.vence >= t);
  const diasRest = s.vence ? Math.round((aFecha(s.vence) - aFecha(t)) / 86400000) : null;
  const usosHoy = get("SELECT COUNT(*) n FROM mem_usos WHERE socio_id=? AND cancelado=0 AND substr(fecha,1,10)=?", s.id, t).n;
  const desde = s.vence && plan ? sumarDiasF(s.vence, -(plan.dias || 30) + 1) : (s.inicio || t);
  const usosPeriodo = get("SELECT COUNT(*) n FROM mem_usos WHERE socio_id=? AND cancelado=0 AND substr(fecha,1,10)>=?", s.id, desde).n;
  let motivo = '';
  if (!plan) motivo = 'El socio no tiene plan';
  else if (!vigente) motivo = s.vence ? `La membresía venció el ${s.vence.split('-').reverse().join('/')}` : 'La membresía todavía no está pagada';
  else if (!renovando && plan.por_dia > 0 && usosHoy >= plan.por_dia) motivo = `Ya usó ${usosHoy} lavado(s) hoy (su plan permite ${plan.por_dia} por día)`;
  else if (!renovando && plan.por_periodo > 0 && usosPeriodo >= plan.por_periodo) motivo = `Ya usó los ${plan.por_periodo} lavados de su plan en este periodo`;
  const estado = !s.vence ? 'sin_pago' : !vigente ? 'vencida' : diasRest <= 5 ? 'por_vencer' : 'vigente';
  return { plan, vigente, estado, dias_restantes: diasRest, usos_hoy: usosHoy, usos_periodo: usosPeriodo, puede_usar: !motivo, motivo, paquetes: plan ? paqsPlan(plan) : [] };
}
const socioJSON = (s) => s && ({ ...s, ...estadoSocio(s) });
// Cada plan es también un artículo de servicio (área "Membresías", código MEM-n) para venderlo en el punto de venta
function productoDePlan(p) {
  const nombre = 'Membresía ' + p.nombre;
  const ex = p.producto_id && get('SELECT id FROM productos WHERE id=?', p.producto_id);
  if (ex) run("UPDATE productos SET codigo=?, nombre=?, precio=?, area='Membresías', servicio=1, paquete=NULL, incluye=?, activo=? WHERE id=?", 'MEM-' + p.id, nombre, p.precio, p.descripcion, p.activo ? 1 : 0, ex.id);
  else {
    const r = run("INSERT INTO productos(codigo,nombre,costo,precio,existencia,minimo,area,servicio,incluye,activo) VALUES(?,?,0,?,0,0,'Membresías',1,?,?)", 'MEM-' + p.id, nombre, p.precio, p.descripcion, p.activo ? 1 : 0);
    run('UPDATE mem_planes SET producto_id=? WHERE id=?', r.id, p.id);
  }
}
function limpiarPlan(b) {
  const d = { nombre: txt(b.nombre, 60), precio: num(b.precio), dias: ent(b.dias, 1) || 30, por_dia: ent(b.por_dia), por_periodo: ent(b.por_periodo),
    paquetes: String(b.paquetes || '').split(',').map((x) => x.trim().toUpperCase()).filter(Boolean).join(',') || null, descripcion: txt(b.descripcion, 300) };
  if (!d.nombre) throw new ErrorUsuario('Escriba el nombre del plan (ej. Mensual ilimitado)');
  if (!(d.precio > 0)) throw new ErrorUsuario('Escriba el precio del plan');
  if (d.dias > 3660) throw new ErrorUsuario('La duración del plan es demasiado larga');
  return d;
}
ruta('GET', '/api/membresias/planes', 'sesion', () => all('SELECT * FROM mem_planes WHERE activo=1 ORDER BY precio').map((p) => ({ ...p, socios: get("SELECT COUNT(*) n FROM mem_socios WHERE activo=1 AND plan_id=? AND vence>=?", p.id, hoy()).n })));
ruta('POST', '/api/membresias/planes', 'productos', ({ body }) => tx(() => {
  const d = limpiarPlan(body);
  const r = run('INSERT INTO mem_planes(nombre,precio,dias,paquetes,por_dia,por_periodo,descripcion) VALUES(?,?,?,?,?,?,?)', d.nombre, d.precio, d.dias, d.paquetes, d.por_dia, d.por_periodo, d.descripcion);
  productoDePlan(planMem(r.id)); return planMem(r.id);
}));
ruta('PUT', '/api/membresias/planes/:id', 'productos', ({ body, p }) => tx(() => {
  const a = planMem(p.id); if (!a) throw new ErrorUsuario('El plan no existe', 404);
  const d = limpiarPlan(body);
  run('UPDATE mem_planes SET nombre=?,precio=?,dias=?,paquetes=?,por_dia=?,por_periodo=?,descripcion=? WHERE id=?', d.nombre, d.precio, d.dias, d.paquetes, d.por_dia, d.por_periodo, d.descripcion, a.id);
  productoDePlan(planMem(a.id)); return planMem(a.id);
}));
ruta('DELETE', '/api/membresias/planes/:id', 'productos', ({ p }) => tx(() => {
  const a = planMem(p.id); if (!a) return;
  run('UPDATE mem_planes SET activo=0 WHERE id=?', a.id); productoDePlan(planMem(a.id));
}));
function limpiarSocio(b) {
  const d = { nombre: txt(b.nombre, 80), telefono: txt(b.telefono, 30), placas: listaPlacas(b.placas).join(', ') || null, vehiculo: txt(b.vehiculo, 60), plan_id: Number(b.plan_id) || null, notas: txt(b.notas, 300) };
  if (!d.nombre) throw new ErrorUsuario('Escriba el nombre del socio');
  if (!d.placas) throw new ErrorUsuario('Escriba las placas del carro (con ellas se reconoce al socio en la caja)');
  if (d.plan_id && !planMem(d.plan_id)?.activo) throw new ErrorUsuario('Elija un plan válido');
  return d;
}
function placasOcupadas(placas, id) {
  const mias = listaPlacas(placas).map(normPl);
  for (const s of all('SELECT id, nombre, placas FROM mem_socios WHERE activo=1 AND id<>?', id || 0))
    if (listaPlacas(s.placas).some((x) => mias.includes(normPl(x)))) throw new ErrorUsuario(`Esas placas ya están registradas con el socio ${s.nombre}`);
}
ruta('GET', '/api/membresias/socios', 'sesion', ({ q }) => {
  const b = String(q.q || '').trim().toLowerCase(), bp = normPl(q.q);
  const l = all('SELECT s.*, p.nombre plan_nombre FROM mem_socios s LEFT JOIN mem_planes p ON p.id=s.plan_id WHERE s.activo=1 ORDER BY s.nombre').map(socioJSON)
    .filter((s) => !b || s.nombre.toLowerCase().includes(b) || String(s.telefono || '').includes(b) || (bp && listaPlacas(s.placas).some((x) => normPl(x).includes(bp))));
  return q.estado ? l.filter((s) => s.estado === q.estado) : l;
});
ruta('GET', '/api/membresias/socios/:id', 'sesion', ({ p }) => {
  const s = get('SELECT s.*, p.nombre plan_nombre FROM mem_socios s LEFT JOIN mem_planes p ON p.id=s.plan_id WHERE s.id=?', Number(p.id));
  if (!s) throw new ErrorUsuario('El socio no existe', 404);
  return { ...socioJSON(s), pagos: all('SELECT mp.*, v.folio, pl.nombre plan FROM mem_pagos mp LEFT JOIN ventas v ON v.id=mp.venta_id LEFT JOIN mem_planes pl ON pl.id=mp.plan_id WHERE mp.socio_id=? ORDER BY mp.id DESC LIMIT 100', s.id),
    usos: all('SELECT mu.*, v.folio, u.nombre usuario FROM mem_usos mu LEFT JOIN ventas v ON v.id=mu.venta_id LEFT JOIN usuarios u ON u.id=mu.usuario_id WHERE mu.socio_id=? ORDER BY mu.id DESC LIMIT 200', s.id) };
});
// El punto de venta busca al socio por las placas que escribe el cajero
ruta('GET', '/api/membresias/placas/:placas', 'sesion', ({ p }) => {
  const pl = normPl(decodeURIComponent(p.placas)); if (pl.length < 3) return { socio: null };
  const s = all('SELECT s.*, p.nombre plan_nombre FROM mem_socios s LEFT JOIN mem_planes p ON p.id=s.plan_id WHERE s.activo=1').find((x) => listaPlacas(x.placas).some((y) => normPl(y) === pl));
  return { socio: socioJSON(s) || null };
});
ruta('POST', '/api/membresias/socios', 'vender', ({ body, u }) => tx(() => {
  const d = limpiarSocio(body); placasOcupadas(d.placas);
  const r = run('INSERT INTO mem_socios(nombre,telefono,placas,vehiculo,plan_id,notas,creado,usuario_id) VALUES(?,?,?,?,?,?,?,?)', d.nombre, d.telefono, d.placas, d.vehiculo, d.plan_id, d.notas, ahora(), u.id);
  return socioJSON(get('SELECT s.*, p.nombre plan_nombre FROM mem_socios s LEFT JOIN mem_planes p ON p.id=s.plan_id WHERE s.id=?', r.id));
}));
ruta('PUT', '/api/membresias/socios/:id', 'vender', ({ body, p, u }) => tx(() => {
  const a = get('SELECT * FROM mem_socios WHERE id=? AND activo=1', Number(p.id)); if (!a) throw new ErrorUsuario('El socio no existe', 404);
  const d = limpiarSocio({ ...a, ...body }); placasOcupadas(d.placas, a.id);
  run('UPDATE mem_socios SET nombre=?,telefono=?,placas=?,vehiculo=?,plan_id=?,notas=? WHERE id=?', d.nombre, d.telefono, d.placas, d.vehiculo, d.plan_id, d.notas, a.id);
  // Corregir la fecha de vencimiento a mano (solo gerente o administrador)
  if (body.vence !== undefined && body.vence !== a.vence) {
    if (!u.perm.has('productos')) throw new ErrorUsuario('Solo el gerente o el administrador pueden cambiar la fecha de vencimiento');
    if (body.vence && !/^\d{4}-\d{2}-\d{2}$/.test(body.vence)) throw new ErrorUsuario('Fecha de vencimiento inválida');
    run('UPDATE mem_socios SET vence=?, inicio=COALESCE(inicio,?) WHERE id=?', body.vence || null, hoy(), a.id);
    run('INSERT INTO bitacora(fecha,habitacion_id,estado,nota,usuario_id) VALUES(?,?,?,?,?)', ahora(), null, 'membresia', `Cambió el vencimiento de ${a.nombre}: ${a.vence || 'sin fecha'} → ${body.vence || 'sin fecha'}`, u.id);
  }
}));
ruta('DELETE', '/api/membresias/socios/:id', 'productos', ({ p }) => { run('UPDATE mem_socios SET activo=0 WHERE id=?', Number(p.id)); });
ruta('GET', '/api/membresias/resumen', 'reportes', ({ q }) => {
  const d = q.desde || hoy().slice(0, 8) + '01', h = q.hasta || hoy();
  const socios = all('SELECT * FROM mem_socios WHERE activo=1').map(socioJSON);
  const cuenta = (e) => socios.filter((s) => s.estado === e).length;
  const ing = get("SELECT COUNT(*) n, COALESCE(SUM(monto),0) t FROM mem_pagos WHERE cancelado=0 AND substr(fecha,1,10) BETWEEN ? AND ?", d, h);
  const uso = get("SELECT COUNT(*) n, COALESCE(SUM(valor),0) t FROM mem_usos WHERE cancelado=0 AND substr(fecha,1,10) BETWEEN ? AND ?", d, h);
  const porPlan = all(`SELECT pl.nombre, COUNT(mp.id) n, COALESCE(SUM(mp.monto),0) t FROM mem_pagos mp JOIN mem_planes pl ON pl.id=mp.plan_id
    WHERE mp.cancelado=0 AND substr(mp.fecha,1,10) BETWEEN ? AND ? GROUP BY pl.id ORDER BY t DESC`, d, h).map((x) => ({ ...x, t: r2(x.t) }));
  const top = all(`SELECT s.nombre, s.placas, COUNT(*) n, SUM(mu.valor) valor FROM mem_usos mu JOIN mem_socios s ON s.id=mu.socio_id WHERE mu.cancelado=0 AND substr(mu.fecha,1,10) BETWEEN ? AND ?
    GROUP BY s.id ORDER BY n DESC LIMIT 20`, d, h).map((x) => ({ ...x, valor: r2(x.valor) }));
  return { desde: d, hasta: h, activos: cuenta('vigente') + cuenta('por_vencer'), por_vencer: cuenta('por_vencer'), vencidos: cuenta('vencida'), sin_pago: cuenta('sin_pago'),
    pagos: ing.n, ingresos: r2(ing.t), lavados: uso.n, valor_lavados: r2(uso.t), por_plan: porPlan, top };
});
// ---- Lo que hace /api/ventas con las membresías ----
// Antes de guardar la venta: valida al socio, aplica el lavado incluido (esa línea queda en $0) y revisa los planes vendidos.
function memPrepararVenta(body, lineas) {
  const mems = lineas.filter((l) => String(l.pr.codigo || '').startsWith('MEM-'));
  const sid = Number(body.socio_id) || 0;
  if ((sid || mems.length || body.usar_membresia) && !moduloActivo('membresias')) throw new ErrorUsuario(SIN_MODULO('membresias'), 403);
  if (!sid) { if (mems.length) throw new ErrorUsuario('Para vender una membresía elija primero al socio (o dé de alta uno nuevo)'); return null; }
  const s = get('SELECT * FROM mem_socios WHERE id=? AND activo=1', sid); if (!s) throw new ErrorUsuario('El socio no existe');
  const planes = mems.map((l) => ({ l, plan: get('SELECT * FROM mem_planes WHERE producto_id=?', l.pr.id) }));
  if (planes.some((x) => !x.plan)) throw new ErrorUsuario('Esa membresía ya no existe');
  let cubierta = null;
  if (body.usar_membresia) {
    const sx = planes.length ? { ...s, plan_id: planes[0].plan.id } : s;
    const est = estadoSocio(sx, planes.length > 0);
    if (!est.puede_usar) throw new ErrorUsuario(est.motivo);
    cubierta = lineas.find((l) => l.pr.paquete && cubrePlan(est.plan, l.pr.paquete));
    if (!cubierta) throw new ErrorUsuario(`El plan de ${s.nombre} no incluye ese paquete`);
    cubierta.importe = r2(cubierta.importe - cubierta.pr.precio); cubierta.desc = cubierta.pr.nombre + ' · MEMBRESÍA';
  }
  return { s, planes, cubierta };
}
// Después de guardar la venta: alarga la vigencia del socio y anota el lavado usado
function memDespuesVenta(mv, ventaId, uid, placas) {
  if (!mv) return null;
  const fecha = ahora(); let s = mv.s;
  for (const { l, plan } of mv.planes) {
    const desde = s.vence && s.vence >= hoy() ? sumarDiasF(s.vence, 1) : hoy(), hasta = sumarDiasF(desde, (plan.dias || 30) * l.c - 1);
    run('INSERT INTO mem_pagos(socio_id,venta_id,fecha,plan_id,periodos,monto,desde,hasta,vence_antes,usuario_id) VALUES(?,?,?,?,?,?,?,?,?,?)', s.id, ventaId, fecha, plan.id, l.c, l.importe, desde, hasta, s.vence, uid);
    run('UPDATE mem_socios SET vence=?, plan_id=?, inicio=COALESCE(inicio,?) WHERE id=?', hasta, plan.id, desde, s.id);
    s = get('SELECT * FROM mem_socios WHERE id=?', s.id);
  }
  if (mv.cubierta) run('INSERT INTO mem_usos(socio_id,venta_id,fecha,paquete,placas,valor,usuario_id) VALUES(?,?,?,?,?,?,?)', s.id, ventaId, fecha, mv.cubierta.pr.paquete, txt(placas, 20)?.toUpperCase() ?? null, mv.cubierta.pr.precio, uid);
  run('UPDATE ventas SET socio_id=? WHERE id=?', s.id, ventaId);
  return { socio: s.nombre, vence: s.vence, plan: planMem(s.plan_id)?.nombre || '', uso: !!mv.cubierta, renovo: mv.planes.length > 0 };
}
// Al cancelar la venta: regresa la vigencia y libera el lavado
function memCancelarVenta(ventaId) {
  for (const pg of all('SELECT * FROM mem_pagos WHERE venta_id=? AND cancelado=0 ORDER BY id DESC', ventaId)) {
    const s = get('SELECT * FROM mem_socios WHERE id=?', pg.socio_id);
    if (s && s.vence === pg.hasta) run('UPDATE mem_socios SET vence=? WHERE id=?', pg.vence_antes, s.id);
    run('UPDATE mem_pagos SET cancelado=1 WHERE id=?', pg.id);
  }
  run('UPDATE mem_usos SET cancelado=1 WHERE venta_id=?', ventaId);
}

// ---------- Reportes ----------
ruta('GET', '/api/reporte/detalle', 'reportes', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d;
  return { ...detalle('substr($.fecha,1,10) BETWEEN ? AND ?', d, h),
    visitantes: all('SELECT v.nombre, v.identificacion, v.entrada, v.salida, v.cobro, hb.numero FROM visitantes v LEFT JOIN habitaciones hb ON hb.id=v.habitacion_id WHERE substr(v.entrada,1,10) BETWEEN ? AND ? ORDER BY v.entrada', d, h),
    turnos: all("SELECT t.id FROM turnos t WHERE substr(t.apertura,1,10) BETWEEN ? AND ? ORDER BY t.id", d, h).map((x) => resumenTurno(x.id)) };
});
ruta('GET', '/api/reporte', 'reportes', ({ q }) => {
  const d = q.desde || hoy(), h = q.hasta || d;
  const habs = all('SELECT * FROM habitaciones WHERE activo=1').map(habJSON);
  const activas = all('SELECT e.*, hb.numero FROM estancias e JOIN habitaciones hb ON hb.id=e.habitacion_id WHERE e.activa=1 ORDER BY hb.numero').map(resumenEstancia);
  const pagos = all('SELECT p.*, u.nombre usuario FROM pagos p LEFT JOIN usuarios u ON u.id=p.usuario_id WHERE substr(p.fecha,1,10) BETWEEN ? AND ?', d, h);
  const suma = (f) => r2(pagos.filter(f).reduce((s, x) => s + x.monto, 0));
  const porMetodo = Object.fromEntries(METODOS.map((m) => [m, suma((x) => x.metodo === m)]));
  const porUsuario = {}; for (const x of pagos) porUsuario[x.usuario || '—'] = r2((porUsuario[x.usuario || '—'] || 0) + x.monto);
  const porModalidad = Object.fromEntries(MODALIDADES.map((m) => [m, activas.filter((e) => e.modalidad === m).length]));
  const rentas = Object.fromEntries(MODALIDADES.map((k) => [k, { n: 0, cantidad: 0, importe: 0, cobrado: 0 }]));
  for (const x of all('SELECT modalidad, COUNT(*) n, SUM(cantidad) c, SUM(importe) i FROM rentas WHERE substr(fecha,1,10) BETWEEN ? AND ? GROUP BY modalidad', d, h)) if (rentas[x.modalidad]) Object.assign(rentas[x.modalidad], { n: x.n, cantidad: x.c, importe: r2(x.i) });
  for (const x of pagos) if (x.concepto === 'hospedaje' && rentas[x.modalidad]) rentas[x.modalidad].cobrado = r2(rentas[x.modalidad].cobrado + x.monto);
  return {
    desde: d, hasta: h, rentas, visitasCobradas: { n: get('SELECT COUNT(*) n FROM visitantes WHERE cobro>0 AND substr(entrada,1,10) BETWEEN ? AND ?', d, h).n, total: suma((x) => x.concepto === 'visita') },
    habitaciones: habs.map((x) => ({ id: x.id, numero: x.numero, nombre: x.nombre, clase: x.clase, estado: x.estado, nota: x.nota })),
    huespedes: activas, porModalidad,
    cobrado: { hospedaje: suma((x) => x.concepto === 'hospedaje'), tienda: suma((x) => x.concepto === 'tienda'), visita: suma((x) => x.concepto === 'visita'), total: suma(() => true), porMetodo, porUsuario,
      usd: r2(pagos.reduce((t, x) => t + (x.usd || 0), 0)), cambio: r2(pagos.reduce((t, x) => t + (x.cambio || 0), 0)) },
    turnosAbiertos: all("SELECT t.id, t.apertura, u.nombre FROM turnos t JOIN usuarios u ON u.id=t.usuario_id WHERE t.estado='abierto'"),
    entradas: get('SELECT COUNT(*) n FROM estancias WHERE substr(entrada,1,10) BETWEEN ? AND ?', d, h).n,
    salidas: get('SELECT COUNT(*) n FROM estancias WHERE substr(salida_real,1,10) BETWEEN ? AND ?', d, h).n,
    visitantes: get('SELECT COUNT(*) n FROM visitantes WHERE substr(entrada,1,10) BETWEEN ? AND ?', d, h).n,
    ventasTienda: get('SELECT COUNT(*) n, COALESCE(SUM(total),0) t FROM ventas WHERE cancelada=0 AND substr(fecha,1,10) BETWEEN ? AND ?', d, h),
    cargosHabitacion: r2(get('SELECT COALESCE(SUM(c.importe),0) t FROM cargos c WHERE substr(c.fecha,1,10) BETWEEN ? AND ?', d, h).t),
    porSurtir: all('SELECT nombre, existencia, minimo FROM productos WHERE activo=1 AND COALESCE(servicio,0)=0 AND existencia<=minimo ORDER BY nombre'),
    gastos: (() => {
      const l = all('SELECT categoria, grupo, metodo, monto FROM gastos WHERE cancelado=0 AND substr(fecha,1,10) BETWEEN ? AND ?', d, h);
      const porEmpleado = all('SELECT em.nombre, COUNT(*) n, SUM(g.monto) t FROM gastos g JOIN empleados em ON em.id=g.empleado_id WHERE g.cancelado=0 AND substr(g.fecha,1,10) BETWEEN ? AND ? GROUP BY em.id ORDER BY t DESC', d, h);
      const porProveedor = all('SELECT pv.nombre, COUNT(*) n, SUM(g.monto) t FROM gastos g JOIN proveedores pv ON pv.id=g.proveedor_id WHERE g.cancelado=0 AND substr(g.fecha,1,10) BETWEEN ? AND ? GROUP BY pv.id ORDER BY t DESC', d, h);
      const porCategoria = {}, porMetodo = {}, porGrupo = {};
      for (const g of l) {
        porCategoria[g.categoria || 'Otros'] = r2((porCategoria[g.categoria || 'Otros'] || 0) + g.monto); porMetodo[g.metodo] = r2((porMetodo[g.metodo] || 0) + g.monto);
        const k = g.grupo || 'Otros', x = porGrupo[k] || (porGrupo[k] = { total: 0, n: 0, conceptos: {} });
        x.total = r2(x.total + g.monto); x.n++; x.conceptos[g.categoria || 'Otros'] = r2((x.conceptos[g.categoria || 'Otros'] || 0) + g.monto);
      }
      return { total: r2(l.reduce((s, g) => s + g.monto, 0)), n: l.length, porCategoria, porMetodo, porGrupo, porEmpleado, porProveedor };
    })(),
    depositos: (() => {
      const sumT = (t) => r2(get('SELECT COALESCE(SUM(monto),0) t FROM depositos WHERE tipo=? AND substr(fecha,1,10) BETWEEN ? AND ?', t, d, h).t);
      const porMetodo = (t) => Object.fromEntries(all('SELECT metodo, SUM(monto) t FROM depositos WHERE tipo=? AND substr(fecha,1,10) BETWEEN ? AND ? GROUP BY metodo', t, d, h).map((x) => [x.metodo, r2(x.t)]));
      const enGuarda = r2(get(`SELECT COALESCE(SUM(CASE WHEN tipo='recibido' THEN monto ELSE -monto END),0) t FROM depositos`).t);
      return { cambio: r2(get("SELECT COALESCE(SUM(cambio),0) t FROM depositos WHERE tipo='recibido' AND substr(fecha,1,10) BETWEEN ? AND ?", d, h).t), recibidos: sumT('recibido'), devueltos: sumT('devuelto'), retenidos: sumT('retenido'), recibidosMetodo: porMetodo('recibido'), devueltosMetodo: porMetodo('devuelto'), enGuarda,
        pendientes: all(`SELECT e.id, e.huesped, e.salida_real, hb.numero, SUM(CASE WHEN d.tipo='recibido' THEN d.monto ELSE -d.monto END) saldo FROM depositos d JOIN estancias e ON e.id=d.estancia_id
          JOIN habitaciones hb ON hb.id=e.habitacion_id WHERE e.activa=0 GROUP BY e.id HAVING saldo > 0.009 ORDER BY e.salida_real`) };
    })(),
    mantenimiento: { abiertos: get("SELECT COUNT(*) n FROM mantenimiento WHERE estado<>'terminado'").n, terminados: get("SELECT COUNT(*) n FROM mantenimiento WHERE estado='terminado' AND substr(cierre,1,10) BETWEEN ? AND ?", d, h).n },
    bitacora: all(`SELECT b.*, hb.numero, u.nombre usuario FROM bitacora b LEFT JOIN habitaciones hb ON hb.id=b.habitacion_id LEFT JOIN usuarios u ON u.id=b.usuario_id
      WHERE substr(b.fecha,1,10) BETWEEN ? AND ? ORDER BY b.id DESC LIMIT 200`, d, h),
  };
});


// ======================================================================
// 1.8 Cuentas por pagar a proveedores
// ======================================================================
function cxpJSON(c) {
  const saldo = r2(c.monto - c.pagado), dias = c.vence ? Math.round((aFecha(c.vence) - aFecha(hoy())) / 86400000) : null;
  const estado = c.cancelada ? 'cancelada' : saldo <= 0.009 ? 'pagada' : dias !== null && dias < 0 ? 'vencida' : 'pendiente';
  return { ...c, saldo, dias, estado, por_vencer: estado === 'pendiente' && dias !== null && dias <= (ent(cfg('cxp_dias_aviso')) || 3) };
}
const SQL_CXP = 'SELECT c.*, pv.nombre proveedor FROM cuentas_pagar c LEFT JOIN proveedores pv ON pv.id=c.proveedor_id';
ruta('GET', '/api/cuentas-pagar', 'cuentas_pagar', ({ q }) => {
  const L = all(`${SQL_CXP} WHERE c.cancelada=0 ORDER BY c.vence IS NULL, c.vence, c.id`).map(cxpJSON);
  const f = q.estado || 'abiertas';
  return f === 'todas' ? L : f === 'abiertas' ? L.filter((c) => c.estado !== 'pagada') : L.filter((c) => c.estado === f);
});
ruta('GET', '/api/cuentas-pagar/avisos', 'sesion', ({ u }) => (u.perm.has('cuentas_pagar') ? all(`${SQL_CXP} WHERE c.cancelada=0 AND c.monto-c.pagado>0.009`).map(cxpJSON).filter((c) => c.estado === 'vencida' || c.por_vencer) : []));
ruta('GET', '/api/cuentas-pagar/:id', 'cuentas_pagar', ({ p }) => {
  const c = get(`${SQL_CXP} WHERE c.id=?`, Number(p.id)); if (!c) throw new ErrorUsuario('No existe', 404);
  return { ...cxpJSON(c), pagos: all('SELECT cp.*, g.folio, g.metodo, u.nombre usuario FROM cuentas_pagos cp LEFT JOIN gastos g ON g.id=cp.gasto_id LEFT JOIN usuarios u ON u.id=cp.usuario_id WHERE cp.cuenta_id=? ORDER BY cp.id', c.id) };
});
function limpiarCxp(b) {
  const d = { proveedor_id: Number(b.proveedor_id) || null, concepto: txt(b.concepto, 200), factura: txt(b.factura, 80), categoria: txt(b.categoria, 60) || 'Pago a proveedores', monto: num(b.monto),
    fecha: /^\d{4}-\d{2}-\d{2}$/.test(b.fecha || '') ? b.fecha : hoy(), vence: /^\d{4}-\d{2}-\d{2}$/.test(b.vence || '') ? b.vence : null, notas: txt(b.notas, 300) };
  if (!d.concepto) throw new ErrorUsuario('Escriba qué se debe (concepto)');
  if (!(d.monto > 0)) throw new ErrorUsuario('Escriba el monto que se debe');
  d.grupo = grupoDe(d.categoria);
  return d;
}
ruta('POST', '/api/cuentas-pagar', 'cuentas_pagar', ({ body, u }) => {
  const d = limpiarCxp(body);
  return run('INSERT INTO cuentas_pagar(proveedor_id,concepto,factura,categoria,grupo,monto,fecha,vence,notas,usuario_id,creado) VALUES(?,?,?,?,?,?,?,?,?,?,?)', d.proveedor_id, d.concepto, d.factura, d.categoria, d.grupo, d.monto, d.fecha, d.vence, d.notas, u.id, ahora());
});
ruta('PUT', '/api/cuentas-pagar/:id', 'cuentas_pagar', ({ body, p }) => {
  const c = get('SELECT * FROM cuentas_pagar WHERE id=?', Number(p.id)); if (!c) throw new ErrorUsuario('No existe', 404);
  const d = limpiarCxp(body); if (d.monto < c.pagado - 0.009) throw new ErrorUsuario('Ya se pagaron $' + c.pagado.toFixed(2) + ': el monto no puede ser menor');
  run('UPDATE cuentas_pagar SET proveedor_id=?,concepto=?,factura=?,categoria=?,grupo=?,monto=?,fecha=?,vence=?,notas=? WHERE id=?', d.proveedor_id, d.concepto, d.factura, d.categoria, d.grupo, d.monto, d.fecha, d.vence, d.notas, c.id);
});
ruta('DELETE', '/api/cuentas-pagar/:id', 'cuentas_pagar', ({ p }) => {
  const c = get('SELECT * FROM cuentas_pagar WHERE id=?', Number(p.id)); if (!c) throw new ErrorUsuario('No existe', 404);
  if (c.pagado > 0) throw new ErrorUsuario('Ya tiene pagos: no se puede cancelar');
  run('UPDATE cuentas_pagar SET cancelada=1 WHERE id=?', c.id);
});
ruta('POST', '/api/cuentas-pagar/:id/pagar', 'cuentas_pagar', ({ body, p, u }) => tx(() => {
  const c = cxpJSON(get(`${SQL_CXP} WHERE c.id=?`, Number(p.id)) || {});
  if (!c.id || c.cancelada) throw new ErrorUsuario('No existe', 404);
  const monto = num(body.monto); if (!(monto > 0)) throw new ErrorUsuario('Escriba cuánto se paga');
  if (monto > c.saldo + 0.009) throw new ErrorUsuario('Solo se deben $' + c.saldo.toFixed(2));
  const gid = crearGasto({ concepto: `Pago a ${c.proveedor || 'proveedor'} · ${c.concepto}${c.factura ? ' · Fact. ' + c.factura : ''}${monto < c.saldo - 0.009 ? ' (abono)' : ''}`, categoria: c.categoria, grupo: c.grupo, monto, metodo: body.metodo,
    proveedor_id: c.proveedor_id, factura: c.factura, nota: txt(body.nota, 200), fuera_de_caja: !!body.fuera_de_caja, recibe: c.proveedor }, u.id);
  run('INSERT INTO cuentas_pagos(cuenta_id,gasto_id,fecha,monto,usuario_id) VALUES(?,?,?,?,?)', c.id, gid, ahora(), monto, u.id);
  run('UPDATE cuentas_pagar SET pagado=pagado+? WHERE id=?', monto, c.id);
  return { gasto_id: gid, saldo: r2(c.saldo - monto) };
}));

// ======================================================================
// 1.8 Nómina: descuentos de asistencia listos para pagar
// ======================================================================
ruta('GET', '/api/nomina/asistencia', 'personal', ({ q }) => {
  const d = /^\d{4}-\d{2}-\d{2}$/.test(q.desde || '') ? q.desde : fechaMas(hoy(), -6), h = /^\d{4}-\d{2}-\d{2}$/.test(q.hasta || '') ? q.hasta : hoy();
  return all('SELECT * FROM empleados WHERE activo=1 ORDER BY nombre').map((e) => ({ empleado_id: e.id, nombre: e.nombre, con_horario: !!horarioDe(e), resumen: asistenciaDe(e, d, h <= hoy() ? h : hoy()).resumen }));
});

// ======================================================================
// 1.8 Reloj checador por red ZKTeco (protocolo ADMS / "push"): el reloj manda las checadas solo
//   En el reloj: Menú → Comunicación → Servidor en la nube (ADMS): dirección = IP de esta computadora, puerto 3070
//   El número de usuario en el reloj (PIN) debe ser el mismo "Número para checar" del empleado
// ======================================================================
const TIPO_ZK = { 0: 'entrada', 1: 'salida', 2: 'descanso', 3: 'regreso', 4: 'entrada', 5: 'salida' };
function tipoEnFecha(empId, fecha) {
  const cs = all("SELECT tipo FROM checadas WHERE empleado_id=? AND anulada=0 AND substr(fecha,1,10)=? AND fecha<? ORDER BY fecha", empId, fecha.slice(0, 10), fecha), u = cs[cs.length - 1];
  if (!u || u.tipo === 'salida') return 'entrada';
  if (u.tipo === 'descanso') return 'regreso';
  if (u.tipo === 'regreso') return 'salida';
  const e = get('SELECT horario FROM empleados WHERE id=?', empId), H = e ? horarioDe(e) : null, h = H ? H[aFecha(fecha).getDay()] : null;
  if (h && num(h.descanso) > 0 && !cs.some((c) => c.tipo === 'descanso') && minDe(h.salida) !== null && minDeFecha(fecha) < minDe(h.salida) - 60) return 'descanso';
  return 'salida';
}
function checadaReloj(sn, linea) {
  const [pin, fecha, estado] = linea.split('\t').map((x) => String(x || '').trim());
  if (!pin || !/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/.test(fecha || '')) return false;
  const e = get('SELECT * FROM empleados WHERE numero=? AND activo=1', pin); if (!e) return false;
  const f = fecha.length === 16 ? fecha + ':00' : fecha;
  if (get('SELECT id FROM checadas WHERE empleado_id=? AND fecha=?', e.id, f)) return false;
  const tipo = cfg('reloj_estado') === 'reloj' && TIPO_ZK[estado] ? TIPO_ZK[estado] : tipoEnFecha(e.id, f);
  run('INSERT INTO checadas(empleado_id,fecha,tipo,metodo,usuario_id,nota) VALUES(?,?,?,?,?,?)', e.id, f, tipo, 'reloj', null, 'Reloj ' + sn);
  return true;
}
function iclock(req, res, url, r0, cuerpo) {
  const sn = txt(url.searchParams.get('SN'), 40), texto = (t, st = 200) => { res.writeHead(st, { 'Content-Type': 'text/plain' }); res.end(t); };
  if (!sn) return texto('ERROR', 400);
  const ya = get('SELECT * FROM relojes WHERE sn=?', sn);
  if (!ya) run('INSERT INTO relojes(sn,nombre,ip,ultimo,activo) VALUES(?,?,?,?,0)', sn, 'Reloj ' + sn, ipDe(req), ahora());
  else run('UPDATE relojes SET ip=?, ultimo=? WHERE sn=?', ipDe(req), ahora(), sn);
  const activo = ya?.activo === 1;
  if (r0 === '/iclock/cdata' && req.method === 'GET') {
    const tz = -new Date().getTimezoneOffset() / 60;
    return texto(`GET OPTION FROM: ${sn}\nATTLOGStamp=${ya?.stamp || 'None'}\nOPERLOGStamp=9999\nATTPHOTOStamp=None\nErrorDelay=60\nDelay=30\nTransTimes=00:00;14:05\nTransInterval=1\nTransFlag=TransData AttLog\nTimeZone=${tz}\nRealtime=1\nEncrypt=None\n`);
  }
  if (r0 === '/iclock/cdata' && req.method === 'POST') {
    // Mientras el administrador no active el reloj no se reciben checadas (el reloj las vuelve a mandar después)
    if (!activo) return texto('ERROR: reloj no autorizado', 403);
    const tabla = url.searchParams.get('table');
    if (tabla !== 'ATTLOG') return texto('OK');
    let n = 0; const lineas = cuerpo.toString('utf8').split(/\r?\n/).filter(Boolean);
    tx(() => { for (const l of lineas) if (checadaReloj(sn, l)) n++; });
    if (url.searchParams.get('Stamp')) run('UPDATE relojes SET stamp=? WHERE sn=?', url.searchParams.get('Stamp'), sn);
    return texto('OK: ' + lineas.length);
  }
  return texto('OK');
}
ruta('GET', '/api/relojes', 'asistencia', () => all('SELECT sn, nombre, ip, ultimo, activo FROM relojes ORDER BY ultimo DESC'));
ruta('PUT', '/api/relojes/:sn', 'asistencia', ({ p, body }) => { run('UPDATE relojes SET nombre=COALESCE(?,nombre), activo=? WHERE sn=?', txt(body.nombre, 60), body.activo ? 1 : 0, p.sn); });
ruta('DELETE', '/api/relojes/:sn', 'asistencia', ({ p }) => { run('DELETE FROM relojes WHERE sn=?', p.sn); });

// ======================================================================
// 1.8 Unidades de negocio, otros ingresos, gráfica de pastel y venta promedio diaria
// ======================================================================
const unidadesCfg = () => String(cfg('unidades_negocio') || 'Hotel').split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
const unidadDe = (h) => h.unidad || (h.clase === 'local' ? (unidadesCfg().find((x) => /local/i.test(x)) || 'Locales comerciales') : (unidadesCfg()[0] || 'Hotel'));
function extrasPeriodo(d, h) {
  const B = (a) => `substr(${a}.fecha,1,10) BETWEEN ? AND ?`;
  const habs = all('SELECT * FROM habitaciones WHERE activo=1 OR id IN (SELECT habitacion_id FROM estancias WHERE substr(entrada,1,10)<=?)', h);
  const uh = Object.fromEntries(habs.map((x) => [x.id, unidadDe(x)]));
  const nombres = [...new Set([...unidadesCfg(), ...Object.values(uh)])];
  const U = Object.fromEntries(nombres.map((n) => [n, { nombre: n, habitaciones: 0, ocupadas: 0, rentas: 0, generado: 0, cobrado: 0, cortas: 0, largas: 0, extras: 0 }]));
  for (const x of habs) if (x.activo) { U[uh[x.id]].habitaciones++; if (x.estado === 'ocupada') U[uh[x.id]].ocupadas++; }
  for (const r of all(`SELECT r.modalidad, r.importe, e.habitacion_id FROM rentas r JOIN estancias e ON e.id=r.estancia_id WHERE ${B('r')}`, d, h)) {
    const x = U[uh[r.habitacion_id] || nombres[0]]; x.rentas++; x.generado = r2(x.generado + r.importe); if (['semana', 'mes'].includes(r.modalidad)) x.largas = r2(x.largas + r.importe); else x.cortas = r2(x.cortas + r.importe);
  }
  const pagos = all(`SELECT p.concepto, p.monto, p.fecha, e.habitacion_id FROM pagos p LEFT JOIN estancias e ON e.id=p.estancia_id WHERE ${B('p')}`, d, h);
  for (const p of pagos) if (p.habitacion_id && uh[p.habitacion_id] && p.concepto === 'hospedaje') U[uh[p.habitacion_id]].cobrado = r2(U[uh[p.habitacion_id]].cobrado + p.monto);
  // Multas, intereses y cuotas
  const cargos = all(`SELECT c.*, hb.numero, hb.id hid, e.huesped, us.nombre usuario FROM cargos c JOIN estancias e ON e.id=c.estancia_id JOIN habitaciones hb ON hb.id=e.habitacion_id LEFT JOIN usuarios us ON us.id=c.usuario_id
    WHERE c.tipo IN ('multa','mora','limpieza','mascota','otro') AND ${B('c')} ORDER BY c.fecha`, d, h);
  const tipos = Object.fromEntries(EXTRAS.map((k) => [k, { nombre: TIPOS_CARGO[k], n: 0, generado: 0, cobrado: 0, conceptos: {} }]));
  for (const c of cargos) {
    const x = tipos[c.tipo]; x.n++; x.generado = r2(x.generado + c.importe);
    const k = c.tipo === 'mora' ? 'Interés moratorio' : c.descripcion, y = x.conceptos[k] || (x.conceptos[k] = { n: 0, total: 0 }); y.n++; y.total = r2(y.total + c.importe);
    if (uh[c.hid]) U[uh[c.hid]].extras = r2(U[uh[c.hid]].extras + c.importe);
  }
  for (const p of pagos) if (tipos[p.concepto]) tipos[p.concepto].cobrado = r2(tipos[p.concepto].cobrado + p.monto);
  // Tienda por área y visitas
  const tienda = all(`SELECT COALESCE(pr.area,'Sin área') area, SUM(i.cantidad) cantidad, SUM(i.importe) importe, SUM(i.costo*i.cantidad) costo FROM venta_items i JOIN ventas v ON v.id=i.venta_id LEFT JOIN productos pr ON pr.id=i.producto_id
    WHERE v.cancelada=0 AND ${B('v')} GROUP BY 1 ORDER BY importe DESC`, d, h).map((x) => ({ ...x, importe: r2(x.importe), costo: r2(x.costo), utilidad: r2(x.importe - x.costo) }));
  const ventaTienda = r2(tienda.reduce((s, x) => s + x.importe, 0));
  const visitas = all(`SELECT hb.numero, COUNT(*) n, SUM(v.cobro) total FROM visitantes v JOIN habitaciones hb ON hb.id=v.habitacion_id WHERE v.cobro>0 AND substr(v.entrada,1,10) BETWEEN ? AND ? GROUP BY hb.id ORDER BY total DESC`, d, h);
  const visitasTot = r2(pagos.filter((p) => p.concepto === 'visita').reduce((s, p) => s + p.monto, 0));
  // Gráfica de pastel: lo que generó cada unidad de negocio y cada tipo de ingreso
  const pastel = [...Object.values(U).filter((x) => x.generado > 0).map((x) => ({ nombre: x.nombre + ' (rentas)', valor: x.generado })),
    { nombre: 'Tienda', valor: ventaTienda }, { nombre: 'Visitas', valor: visitasTot },
    ...EXTRAS.map((k) => ({ nombre: { multa: 'Multas', mora: 'Intereses moratorios', limpieza: 'Cuotas de limpieza', mascota: 'Cuotas por mascota', otro: 'Otros cargos' }[k], valor: tipos[k].generado }))].filter((x) => x.valor > 0);
  const totPastel = r2(pastel.reduce((s, x) => s + x.valor, 0));
  pastel.forEach((x) => { x.pct = totPastel ? r2(x.valor / totPastel * 100) : 0; });
  pastel.sort((a, b) => b.valor - a.valor);
  // Venta promedio diaria (días transcurridos del periodo)
  const fin = h < hoy() ? h : hoy(), nd = Math.max(1, Math.round((aFecha(fin) - aFecha(d)) / 86400000) + 1);
  const porDia = {}; for (const p of pagos) porDia[p.fecha.slice(0, 10)] = r2((porDia[p.fecha.slice(0, 10)] || 0) + p.monto);
  const cob = r2(pagos.reduce((s, p) => s + p.monto, 0)), dl = Object.entries(porDia).sort((a, b) => b[1] - a[1]);
  const S = (f) => r2(pagos.filter(f).reduce((s, p) => s + p.monto, 0));
  const promedio = { dias: nd, total: cob, diario: r2(cob / nd), hospedaje: r2(S((p) => p.concepto === 'hospedaje') / nd), tienda: r2(S((p) => p.concepto === 'tienda') / nd), visitas: r2(visitasTot / nd),
    otros: r2(S((p) => tipos[p.concepto]) / nd), generado_diario: r2(totPastel / nd), mejor: dl[0] ? { fecha: dl[0][0], total: dl[0][1] } : null, peor: dl.length ? { fecha: dl[dl.length - 1][0], total: dl[dl.length - 1][1] } : null,
    unidades: Object.values(U).map((x) => ({ nombre: x.nombre, diario: r2(x.cobrado / nd) })) };
  // Cuentas por pagar
  const cx = all(`${SQL_CXP} WHERE c.cancelada=0`).map(cxpJSON);
  const cuentas = { pendiente: r2(cx.filter((c) => c.estado === 'pendiente').reduce((s, c) => s + c.saldo, 0)), vencido: r2(cx.filter((c) => c.estado === 'vencida').reduce((s, c) => s + c.saldo, 0)),
    n_pendientes: cx.filter((c) => c.estado === 'pendiente').length, n_vencidas: cx.filter((c) => c.estado === 'vencida').length,
    pagado: r2(get(`SELECT COALESCE(SUM(monto),0) t FROM cuentas_pagos WHERE substr(fecha,1,10) BETWEEN ? AND ?`, d, h).t),
    nuevas: r2(get(`SELECT COALESCE(SUM(monto),0) t FROM cuentas_pagar WHERE cancelada=0 AND fecha BETWEEN ? AND ?`, d, h).t),
    lista: cx.filter((c) => c.estado !== 'pagada' || (c.fecha >= d && c.fecha <= h)).map((c) => ({ proveedor: c.proveedor, concepto: c.concepto, factura: c.factura, fecha: c.fecha, vence: c.vence, monto: c.monto, pagado: c.pagado, saldo: c.saldo, estado: c.estado, dias: c.dias })) };
  // Nómina: descuentos aplicados por retardos y faltas
  const nomina = all(`SELECT em.nombre, COUNT(*) pagos, SUM(n.sueldo) sueldo, SUM(n.descuento) descuento, SUM(n.desc_retardos) desc_retardos, SUM(n.desc_faltas) desc_faltas, SUM(n.retardos) retardos, SUM(n.faltas) faltas, SUM(n.total) total
    FROM nomina_lineas n JOIN empleados em ON em.id=n.empleado_id WHERE ${B('n')} GROUP BY em.id ORDER BY em.nombre`, d, h).map((x) => ({ ...x, sueldo: r2(x.sueldo), descuento: r2(x.descuento), desc_retardos: r2(x.desc_retardos), desc_faltas: r2(x.desc_faltas), total: r2(x.total) }));
  // Egresos de caja y quién los autorizó
  const egresos = all(`SELECT m.fecha, m.moneda, m.monto, m.motivo, u.nombre usuario, a.nombre autorizo FROM caja_mov m LEFT JOIN usuarios u ON u.id=m.usuario_id LEFT JOIN usuarios a ON a.id=m.autorizo_id WHERE m.tipo='retiro' AND ${B('m')} ORDER BY m.fecha`, d, h);
  const g = (re) => r2(get(`SELECT COALESCE(SUM(monto),0) t FROM gastos WHERE cancelado=0 AND substr(fecha,1,10) BETWEEN ? AND ? AND (${re})`, d, h).t);
  return {
    unidades: Object.values(U), tipos, cargos: cargos.map((c) => ({ fecha: c.fecha, numero: c.numero, huesped: c.huesped, tipo: c.tipo, descripcion: c.descripcion, cantidad: c.cantidad, importe: c.importe, usuario: c.usuario })),
    tienda_areas: tienda, venta_tienda: ventaTienda, visitas_hab: visitas, visitas_total: visitasTot, pastel, total_generado: totPastel, promedio, cuentas, nomina, egresos,
    conteos: all("SELECT i.folio, i.fecha, i.area, i.productos, i.faltantes, i.sobrantes, i.valor_faltante, i.valor_sobrante, u.nombre usuario FROM inventarios i LEFT JOIN usuarios u ON u.id=i.usuario_id WHERE substr(i.fecha,1,10) BETWEEN ? AND ? ORDER BY i.fecha", d, h),
    marketing: g("grupo LIKE '%arketing%' OR categoria LIKE '%ublicidad%' OR categoria LIKE '%arketing%'"), lavanderia: g("categoria LIKE '%avander%' OR concepto LIKE '%avander%'"),
  };
}
ruta('GET', '/api/reporte/extra', 'reportes', ({ q }) => { const d = q.desde || hoy(); return extrasPeriodo(d, q.hasta || d); });


// ======================================================================
// 1.8 Tienda: departamentos (áreas) y conteo de inventario físico
// ======================================================================
const areasCfg = () => String(cfg('tienda_areas') || '').split(',').map((x) => x.trim()).filter(Boolean);
const guardarAreas = (l) => setCfg('tienda_areas', [...new Set(l.map((x) => String(x).trim()).filter(Boolean))].join(', '));
ruta('GET', '/api/tienda/areas', 'sesion', () => {
  const usados = Object.fromEntries(all("SELECT COALESCE(NULLIF(area,''),'') a, COUNT(*) n FROM productos WHERE activo=1 GROUP BY 1").map((x) => [x.a, x.n]));
  const l = [...new Set([...areasCfg(), ...Object.keys(usados).filter(Boolean)])].sort((a, b) => a.localeCompare(b, 'es'));
  return { areas: l.map((n) => ({ nombre: n, productos: usados[n] || 0 })), sin_area: usados[''] || 0 };
});
ruta('POST', '/api/tienda/areas', 'productos', ({ body }) => {
  const n = txt(body.nombre, 60); if (!n) throw new ErrorUsuario('Escriba el nombre del departamento');
  if (areasCfg().some((x) => x.toLowerCase() === n.toLowerCase())) throw new ErrorUsuario('Ese departamento ya existe');
  guardarAreas([...areasCfg(), n]);
});
ruta('PUT', '/api/tienda/areas', 'productos', ({ body }) => tx(() => {
  const de = txt(body.de, 60), a = txt(body.a, 60); if (!de || !a) throw new ErrorUsuario('Escriba el nombre nuevo');
  run('UPDATE productos SET area=? WHERE area=?', a, de);
  guardarAreas([...areasCfg().filter((x) => x !== de), a]);
}));
ruta('DELETE', '/api/tienda/areas', 'productos', ({ q }) => tx(() => {
  const n = txt(q.nombre, 60); if (!n) throw new ErrorUsuario('Falta el departamento');
  const r = run('UPDATE productos SET area=NULL WHERE area=?', n);
  guardarAreas(areasCfg().filter((x) => x !== n));
  return { productos: r.changes };
}));
// Conteo físico: compara lo contado contra el sistema, guarda faltantes y sobrantes y (si se pide) ajusta las existencias
ruta('POST', '/api/inventarios', 'inventario', ({ body, u }) => tx(() => {
  const L = (Array.isArray(body.lineas) ? body.lineas : []).filter((l) => l.contado !== '' && l.contado !== null && l.contado !== undefined && Number.isFinite(Number(l.contado)));
  if (!L.length) throw new ErrorUsuario('Capture al menos un producto contado');
  // Solo quien puede editar productos (gerente / administrador) ajusta las existencias; los demás solo registran el conteo
  const aplicar = body.aplicar !== false && u.perm.has('productos'), folio = siguienteFolio('inventario'), fecha = ahora();
  const r = run('INSERT INTO inventarios(folio,fecha,usuario_id,area,notas,aplicado) VALUES(?,?,?,?,?,?)', folio, fecha, u.id, txt(body.area, 60), txt(body.notas, 300), aplicar ? 1 : 0);
  let F = 0, S = 0, VF = 0, VS = 0;
  for (const l of L) {
    const p = get('SELECT * FROM productos WHERE id=? AND activo=1', Number(l.producto_id)); if (!p || p.servicio) continue;
    const c = r2(num(l.contado)), d = r2(c - p.existencia);
    run('INSERT INTO inventario_lineas(inventario_id,producto_id,codigo,nombre,area,sistema,contado,diferencia,costo,precio) VALUES(?,?,?,?,?,?,?,?,?,?)', r.id, p.id, p.codigo, p.nombre, p.area, p.existencia, c, d, p.costo, p.precio);
    if (d < 0) { F += -d; VF += -d * p.costo; } else if (d > 0) { S += d; VS += d * p.costo; }
    if (aplicar && d !== 0) {
      run('UPDATE productos SET existencia=? WHERE id=?', c, p.id);
      run('INSERT INTO movimientos(fecha,producto_id,tipo,cantidad,referencia,usuario_id) VALUES(?,?,?,?,?,?)', fecha, p.id, 'ajuste', d, `Conteo físico ${folio}${d < 0 ? ' (faltante)' : ' (sobrante)'}`, u.id);
    }
  }
  run('UPDATE inventarios SET productos=?, faltantes=?, sobrantes=?, valor_faltante=?, valor_sobrante=? WHERE id=?', L.length, r2(F), r2(S), r2(VF), r2(VS), r.id);
  return { id: r.id, folio };
}));
ruta('GET', '/api/inventarios', 'inventario', () => all('SELECT i.*, u.nombre usuario FROM inventarios i LEFT JOIN usuarios u ON u.id=i.usuario_id ORDER BY i.id DESC LIMIT 200'));
ruta('GET', '/api/inventarios/:id', 'inventario', ({ p }) => {
  const i = get('SELECT i.*, u.nombre usuario FROM inventarios i LEFT JOIN usuarios u ON u.id=i.usuario_id WHERE i.id=?', Number(p.id)); if (!i) throw new ErrorUsuario('No existe', 404);
  return { ...i, lineas: all('SELECT * FROM inventario_lineas WHERE inventario_id=? ORDER BY area, nombre', i.id) };
});

// ---------- Respaldos ----------
ruta('GET', '/api/respaldos', 'config', () => fs.readdirSync(RESPALDOS_DIR).filter((f) => f.endsWith('.db')).sort().reverse().slice(0, 40)
  .map((f) => ({ archivo: f, tam: fs.statSync(path.join(RESPALDOS_DIR, f)).size })));
ruta('POST', '/api/respaldos', 'config', () => ({ archivo: respaldar('manual'), carpeta: RESPALDOS_DIR }));

// ---------- Archivos estáticos ----------
const TIPOS = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json' };
function estatico(res, archivo) {
  const r = path.join(PUBLIC, archivo);
  if (!r.startsWith(PUBLIC) || !fs.existsSync(r) || fs.statSync(r).isDirectory()) return false;
  res.writeHead(200, { 'Content-Type': TIPOS[path.extname(r)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Frame-Options': 'DENY' });
  fs.createReadStream(r).pipe(res);
  return true;
}
function usuarioDe(req, res) {
  const tk = cookies(req).htl_s;
  if (!tk) return null;
  const u = get('SELECT u.*, s.creado sesion_creada FROM sesiones s JOIN usuarios u ON u.id=s.usuario_id WHERE s.token=? AND u.activo=1', tk) || null;
  // Sesión que se renueva sola (la pantalla del checador queda abierta semanas)
  if (u && res && u.sesion_creada < fechaMas(hoy(), -1)) {
    run('UPDATE sesiones SET creado=? WHERE token=?', ahora(), tk);
    res.setHeader('Set-Cookie', `htl_s=${tk}; HttpOnly; SameSite=Strict; Path=/; Max-Age=2592000`);
  }
  return u;
}

// ======================================================================
// Carwash 1.6: ACTUALIZACIONES POR INTERNET (igual que Maxsel POS y Maxsel Hotel)
// Baja version.json de github.com/mlunq23/maxsel-actualizaciones (público, solo paquetes); el .zip trae los archivos del programa
// (sin node.exe, sin licencia y sin la carpeta datos). Se revisa la huella SHA-256 antes de instalar y se guarda un respaldo para regresar.
// ======================================================================
const UPD_CLAVE = 'carwash', UPD_MARCA = 'public/app-lavadores.js';
const UPD_BASE = 'https://raw.githubusercontent.com/mlunq23/maxsel-actualizaciones/main/', UPD_DIR = path.join(DATA_DIR, 'actualizacion');
const NO_TOCAR = /^(datos\/|node_modules\/|licencia\.js$|generador\/)/i;
const verCmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 4; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
function httpsBajar(url, max, redirs = 0) {
  if (process.env.MAXSEL_UPD_PRUEBA) return Promise.resolve().then(() => fs.readFileSync(path.join(process.env.MAXSEL_UPD_PRUEBA, path.basename(url.split('?')[0]))));
  return new Promise((resolve, reject) => {
    if (!/^https:\/\/raw\.githubusercontent\.com\/mlunq23\/maxsel-actualizaciones\//.test(url)) return reject(new ErrorUsuario('Dirección no permitida'));
    https.get(url, { timeout: 30000, headers: { 'Cache-Control': 'no-cache', 'User-Agent': 'MaxselCarwash/' + VERSION } }, (rs) => {
      if ([301, 302, 303, 307, 308].includes(rs.statusCode) && rs.headers.location && redirs < 4) { rs.resume(); return resolve(httpsBajar(new URL(rs.headers.location, url).href, max, redirs + 1)); }
      if (rs.statusCode !== 200) { rs.resume(); return reject(new ErrorUsuario('El servidor de Maxsel respondió ' + rs.statusCode)); }
      const ch = []; let n = 0;
      rs.on('data', (c) => { n += c.length; if (n > max) { rs.destroy(); reject(new ErrorUsuario('Archivo demasiado grande')); } else ch.push(c); });
      rs.on('end', () => resolve(Buffer.concat(ch))); rs.on('error', reject);
    }).on('timeout', function () { this.destroy(new ErrorUsuario('Sin respuesta (revise el internet)')); })
      .on('error', (e) => reject(e instanceof ErrorUsuario ? e : new ErrorUsuario(/ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ENETUNREACH|ECONNRESET/.test(e.code || '') ? 'Sin internet. Conecte la computadora a internet e intente de nuevo.' : e.message)));
  });
}
async function versionDisponible() {
  const j = JSON.parse((await httpsBajar(UPD_BASE + 'version.json?t=' + Date.now(), 256 * 1024)).toString('utf8'));
  const e = j[UPD_CLAVE];
  if (!e || !e.ver) { setCfg('upd_disponible', ''); return { instalada: VERSION, hay: false }; }
  const hay = verCmp(e.ver, VERSION) > 0 && /^[\w.-]+\.zip$/.test(e.win || '') && /^[0-9a-f]{64}$/i.test(e.winSha || '');
  setCfg('upd_disponible', hay ? String(e.ver) : '');
  return { instalada: VERSION, disponible: String(e.ver), notas: String(e.notas || ''), hay, _e: e };
}
function leerZip(buf) {
  let e = buf.length - 22; while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) throw new ErrorUsuario('El paquete de actualización está dañado');
  const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const out = [];
  for (let i = 0; i < n; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new ErrorUsuario('El paquete de actualización está dañado');
    const met = buf.readUInt16LE(p + 10), cs = buf.readUInt32LE(p + 20), nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const nom = buf.toString('utf8', p + 46, p + 46 + nl).replace(/\\/g, '/'); p += 46 + nl + xl + cl;
    if (nom.endsWith('/')) continue;
    if (buf.readUInt32LE(lo) !== 0x04034b50) throw new ErrorUsuario('El paquete de actualización está dañado');
    const s0 = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28), raw = buf.subarray(s0, s0 + cs);
    const dat = met === 0 ? raw : met === 8 ? zlib.inflateRawSync(raw) : null;
    if (!dat) throw new ErrorUsuario('Formato de paquete no soportado');
    out.push({ nom, dat });
  }
  if (!out.length) throw new ErrorUsuario('El paquete de actualización viene vacío');
  return out;
}
let actualizando = false;
async function instalarActualizacion(u) {
  if (actualizando) throw new ErrorUsuario('Ya se está instalando una actualización');
  actualizando = true;
  try {
    const v = await versionDisponible();
    if (!v.hay) throw new ErrorUsuario(`Ya tiene la versión más reciente (${VERSION}).`);
    const zip = await httpsBajar(UPD_BASE + v._e.win, 80 * 1024 * 1024);
    if (crypto.createHash('sha256').update(zip).digest('hex') !== String(v._e.winSha).toLowerCase()) throw new ErrorUsuario('El archivo descargado no es válido. Intente de nuevo.');
    const archivos = leerZip(zip).filter((f) => !NO_TOCAR.test(f.nom) && !f.nom.split('/').includes('..'));
    if (!archivos.some((f) => f.nom === 'server.js') || !archivos.some((f) => f.nom === UPD_MARCA)) throw new ErrorUsuario('El paquete de actualización no es de ' + PRODUCTO);
    const bk = path.join(UPD_DIR, 'respaldo_' + VERSION); fs.rmSync(bk, { recursive: true, force: true }); fs.mkdirSync(bk, { recursive: true });
    const raiz = path.resolve(DIR) + path.sep, escritos = [];
    try {
      for (const f of archivos) {
        const d = path.resolve(DIR, f.nom); if (!d.startsWith(raiz)) continue;
        if (fs.existsSync(d)) { fs.mkdirSync(path.dirname(path.join(bk, f.nom)), { recursive: true }); fs.copyFileSync(d, path.join(bk, f.nom)); }
        fs.mkdirSync(path.dirname(d), { recursive: true }); fs.writeFileSync(d + '.nuevo', f.dat); escritos.push(d);
      }
      // se cambian todos juntos al final; si Windows o el antivirus tienen un archivo ocupado, se reintenta
      const espera = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
      for (const d of escritos) for (let i = 0; ; i++) { try { fs.renameSync(d + '.nuevo', d); break; } catch (e) { if (i >= 20) throw e; espera(300); } }
      // se comprueba que cada archivo quedó igual al del paquete antes de reiniciar
      const h = (b) => crypto.createHash('sha256').update(b).digest('hex');
      for (const f of archivos) { const d = path.resolve(DIR, f.nom); if (d.startsWith(raiz) && h(fs.readFileSync(d)) !== h(f.dat)) throw new Error('el archivo ' + f.nom + ' no quedó bien escrito'); }
    } catch (e) {
      for (const d of escritos) { try { fs.rmSync(d + '.nuevo', { force: true }); } catch { /* nada */ } }
      for (const f of archivos) { const b = path.join(bk, f.nom); if (fs.existsSync(b)) try { fs.copyFileSync(b, path.resolve(DIR, f.nom)); } catch { /* nada */ } }
      throw new ErrorUsuario('No se pudo instalar la actualización: ' + e.message);
    }
    fs.writeFileSync(path.join(UPD_DIR, 'estado.json'), JSON.stringify({ de: VERSION, a: v.disponible, fecha: ahora(), usuario: u?.nombre || '', archivos: escritos.length }));
    console.log(`  [${ahora()}] Actualización ${VERSION} → ${v.disponible} instalada (${escritos.length} archivos). Reiniciando...`);
    setTimeout(() => process.exit(0), 1500).unref?.();
    return { ok: true, de: VERSION, a: v.disponible, archivos: escritos.length, servicio: !!process.env.MAXSEL_SERVICIO };
  } finally { actualizando = false; }
}
ruta('GET', '/api/actualizacion', 'config', async () => { const { _e, ...v } = await versionDisponible(); return v; });
ruta('POST', '/api/actualizacion/instalar', 'config', ({ u }) => instalarActualizacion(u));
try {
  const f = path.join(UPD_DIR, 'estado.json');
  if (fs.existsSync(f)) {
    const i = JSON.parse(fs.readFileSync(f, 'utf8'));
    console.log(`  [${ahora()}] ` + (verCmp(VERSION, i.a) >= 0 ? `Se actualizó de la versión ${i.de} a la ${VERSION}` : `La actualización a la ${i.a} no quedó (sigue la ${VERSION})`));
    setCfg('upd_ultima', JSON.stringify({ ...i, quedo: verCmp(VERSION, i.a) >= 0 }));
    fs.unlinkSync(f);
  }
  if (cfg('upd_disponible') && verCmp(cfg('upd_disponible'), VERSION) <= 0) setCfg('upd_disponible', '');
} catch { /* nada */ }
// ======================================================================
// Carwash 1.7 (igual que Maxsel Tech y Maxsel Abarrotes)
//  - Recuperar contraseña olvidada (con la de un administrador o la clave de Maxsel)
//  - Reiniciar ventas: botón oculto, solo con la contraseña especial de Maxsel
//  - Monitoreo por internet solo con Tailscale Funnel (solo lectura)
// ======================================================================
// Clave de Maxsel: solo se guarda su huella, nunca el texto
const SUPER_HASH = '27486342e248a68acb426e94ae242e3483785c78fac2f971b602f09771629cfa';
const esClaveMaxsel = (pw) => crypto.timingSafeEqual(Buffer.from(crypto.createHash('sha256').update('maxsel-super|' + String(pw || '')).digest('hex')), Buffer.from(SUPER_HASH));
function frenoIntentos(clave) {
  const it = intentos.get(clave) || { n: 0, hasta: 0 };
  if (it.hasta > Date.now()) throw new ErrorUsuario('Demasiados intentos. Espere 10 minutos.', 429);
  return { fallo() { it.n++; if (it.n >= 6) { it.hasta = Date.now() + 10 * 60000; it.n = 0; } intentos.set(clave, it); }, ok() { intentos.delete(clave); } };
}
ruta('POST', '/api/recuperar-contrasena', null, ({ body, req }) => {
  if (req.__funnel) throw new ErrorUsuario('Por seguridad, la contraseña solo se recupera desde la computadora del negocio.', 403);
  const f = frenoIntentos('rec|' + ipDe(req));
  const u = get('SELECT * FROM usuarios WHERE usuario=? AND activo=1', txt(body.usuario)?.toLowerCase());
  if (!u) { f.fallo(); throw new ErrorUsuario('No existe ese usuario (o está desactivado). Revise cómo se escribe.'); }
  const nueva = String(body.nueva || '');
  if (nueva.length < 6) throw new ErrorUsuario('La contraseña nueva debe tener al menos 6 caracteres');
  const aut = String(body.autoriza || '');
  const maxsel = esClaveMaxsel(aut);
  const admin = !maxsel && all("SELECT * FROM usuarios WHERE rol='admin' AND activo=1").find((a) => checkPass(aut, a.pass_hash));
  if (!maxsel && !admin) { f.fallo(); throw new ErrorUsuario('La contraseña del administrador (o la clave de Maxsel) no es correcta', 401); }
  f.ok();
  run('UPDATE usuarios SET pass_hash=? WHERE id=?', hashPass(nueva), u.id);
  run('DELETE FROM sesiones WHERE usuario_id=?', u.id);
  console.log(`  [${ahora()}] Se cambió la contraseña olvidada de "${u.usuario}" (autorizó: ${maxsel ? 'clave de Maxsel' : 'administrador ' + admin.usuario})`);
  return { ok: true, usuario: u.usuario };
});

const TABLAS_REINICIO = ['estancias', 'cargos', 'pagos', 'visitantes', 'ventas', 'venta_items', 'movimientos', 'bitacora', 'gastos', 'depositos', 'contratos', 'mantenimiento', 'mant_fotos',
  'turnos', 'caja_mov', 'checadas', 'incidencias', 'cierres', 'rentas', 'inventarios', 'inventario_lineas', 'cuentas_pagar', 'cuentas_pagos', 'nomina_lineas', 'lavados', 'mem_usos'];
const TABLAS_SOCIOS = ['mem_socios', 'mem_pagos', 'mem_usos'];
ruta('POST', '/api/maxsel/reiniciar', 'config', ({ body, u, req }) => {
  if (req.__funnel) throw new ErrorUsuario('Solo desde la computadora del negocio.', 403);
  const f = frenoIntentos('rei|' + ipDe(req));
  if (!esClaveMaxsel(body.pass)) { f.fallo(); throw new ErrorUsuario('Contraseña de Maxsel incorrecta', 401); }
  f.ok();
  const respaldo = respaldar('antes_de_reiniciar');
  const tablas = new Set(all("SELECT name FROM sqlite_master WHERE type='table'").map((r) => r.name));
  const borrar = [...new Set([...TABLAS_REINICIO, ...(body.socios ? TABLAS_SOCIOS : [])])].filter((t) => tablas.has(t));
  tx(() => {
    for (const t of borrar) run(`DELETE FROM "${t}"`);
    if (tablas.has('sqlite_sequence')) run(`DELETE FROM sqlite_sequence WHERE name IN (${borrar.map((t) => `'${t}'`).join(',')})`);
    if (body.existencias) run('UPDATE productos SET existencia=0 WHERE COALESCE(servicio,0)=0');
    for (const r of all("SELECT clave FROM config WHERE clave LIKE 'folio\\_%' ESCAPE '\\'")) setCfg(r.clave, '0');
  });
  try { fs.appendFileSync(path.join(DATA_DIR, 'reinicios.log'), `${ahora()}  ${u.nombre} reinició las ventas${body.socios ? ' + socios' : ''}${body.existencias ? ' + existencias' : ''}. Respaldo: ${respaldo}\r\n`); } catch { /* nada */ }
  console.log(`  [${ahora()}] Ventas reiniciadas por ${u.nombre} (respaldo ${respaldo})`);
  return { ok: true, respaldo };
});

// Monitoreo por internet: Funnel apunta a este puerto aparte (solo en esta computadora)
const PUERTO_FUNNEL = PUERTO + 1;
const FUNNEL_NO = [/^\/api\/respaldos/, /^\/api\/actualizacion/, /^\/api\/exportar/, /^\/api\/importar/, /^\/api\/funnel/, /^\/api\/maxsel\//, /^\/api\/recuperar/, /^\/checador/, /^\/iclock\//, /^\/api\/licencia\/activar/];
const funnelPermitido = (m, p) => {
  if (FUNNEL_NO.some((r) => r.test(p))) return false;
  if (m === 'GET' || m === 'HEAD') return true;
  return m === 'POST' && (p === '/api/login' || p === '/api/logout');
};
let FUNNEL = null;
// 1.7.1: el acceso por internet va con la póliza de mantenimiento (viene en la licencia, con fecha de vencimiento)
let _pol = null, _polT = 0;
const polizaHoy = () => { if (!_pol || Date.now() - _polT > 60000) { _pol = poliza(); _polT = Date.now(); } return _pol; };
const PAGINA_SIN_POLIZA = (m) => `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Maxsel Carwash</title><body style="font-family:system-ui,sans-serif;background:#f4f1ee;margin:0"><div style="background:#cd6628;color:#fff;padding:18px 20px;font-weight:800;font-size:20px">Maxsel Carwash</div><div style="max-width:440px;margin:40px auto;background:#fff;border-radius:14px;padding:24px;text-align:center;border:1px solid #e3ddd6"><h2 style="margin:0 0 8px">Monitoreo por internet no disponible</h2><p style="color:#5a6878;line-height:1.5">${m}</p></div></body>`;
async function revisarPoliza() {
  try {
    _pol = null;
    if (polizaHoy().activa || !FUNNEL) return;
    const e = await FUNNEL.estado();
    if (e.activo) { await FUNNEL.cambiar(false); console.log(`  [${ahora()}] Acceso por internet APAGADO: la póliza no está vigente`); }
  } catch { /* nada */ }
}
ruta('GET', '/api/funnel', 'config', async ({ req }) => {
  if (req.__funnel || !FUNNEL) throw new ErrorUsuario('Solo desde la computadora del negocio.', 403);
  _pol = null;
  if (!polizaHoy().activa) await revisarPoliza();
  return { ...(await FUNNEL.estado()), poliza: polizaHoy() };
});
ruta('POST', '/api/funnel', 'config', async ({ body, req, u }) => {
  if (req.__funnel || !FUNNEL) throw new ErrorUsuario('Solo desde la computadora del negocio.', 403);
  if (u.rol !== 'admin') throw new ErrorUsuario('Solo el administrador puede encender o apagar el acceso por internet', 403);
  if (body.sesion) return FUNNEL.iniciarSesion();
  _pol = null;
  if (body.activar && !polizaHoy().activa) throw new ErrorUsuario(polizaHoy().motivo, 402);
  const r = await FUNNEL.cambiar(!!body.activar);
  if (r.error) throw new ErrorUsuario(r.error);
  if (r.habilitar) return r;
  console.log(`  [${ahora()}] Acceso por internet (Funnel) ${body.activar ? 'ENCENDIDO' : 'apagado'} por ${u.nombre}`);
  return { ...(await FUNNEL.estado()), poliza: polizaHoy() };
});

// Revisa sola si hay versión nueva (al minuto y medio de arrancar y cada 6 horas) para avisarle al administrador
const revisarActualizacion = () => versionDisponible().catch(() => {});
if (!process.env.MAXSEL_UPD_NO) { setTimeout(revisarActualizacion, 90 * 1000).unref(); setInterval(revisarActualizacion, 6 * 60 * 60 * 1000).unref(); }

const servidor = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const r0 = decodeURIComponent(url.pathname);
  try {
    // 1.7: desde fuera de la red local solo se entra por Tailscale Funnel (Configuración → Monitoreo por internet)
    if (!req.__funnel && !ipPrivada(ipDe(req))) {
      res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Desde fuera del negocio entre con la dirección https://….ts.net de Configuración → Monitoreo por internet.');
    }
    if (r0.startsWith('/iclock/') && !moduloActivo('asistencia')) { res.writeHead(403); return res.end('OK'); }
    if (r0 === '/checador' && !moduloActivo('asistencia')) { res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end(SIN_MODULO('asistencia')); }
    if (r0.startsWith('/iclock/')) { const b = req.method === 'POST' ? await leerCuerpo(req, 5 * 1024 * 1024) : Buffer.alloc(0); return iclock(req, res, url, r0, b); }
    if (r0.startsWith('/api/')) {
      if (!LICENCIA.activa && !SIN_LICENCIA_OK.has(r0)) return enviar(res, 402, { error: 'El sistema no tiene licencia activa. ' + (LICENCIA.motivo || ''), sinLicencia: true });
      const mod = moduloDeRuta(r0);
      if (mod && !moduloActivo(mod)) return enviar(res, 403, { error: SIN_MODULO(mod), modulo: mod });
      const r = rutas.find((x) => x.metodo === req.method && x.re.test(r0));
      if (!r) return enviar(res, 404, { error: 'Ruta no encontrada' });
      const u = usuarioDe(req, res);
      if (r.rol && !u) return enviar(res, 401, { error: 'Inicie sesión' });
      if (u) u.perm = new Set(permisosDe(u));
      if (r.rol && !autorizado(u, r.rol)) return enviar(res, 403, { error: TEXTO_PERMISO[r.rol] ? `Su usuario no tiene permiso para: ${TEXTO_PERMISO[r.rol].toLowerCase()}. Pídaselo al administrador.` : 'Su usuario no tiene permiso para esto.' });
      let body = {};
      if (['POST', 'PUT', 'DELETE'].includes(req.method)) {
        const b = await leerCuerpo(req);
        if (b.length) { try { body = JSON.parse(b.toString()); } catch { throw new ErrorUsuario('Datos inválidos'); } }
      }
      cajonPendiente = false;
      const out = await r.fn({ req, res, body, u, p: r.re.exec(r0).groups || {}, q: Object.fromEntries(url.searchParams) });
      // Cobro o salida de efectivo: manda el pulso para abrir el cajón de dinero
      if (cajonPendiente) { cajonPendiente = false; abrirCajon().catch(() => {}); }
      if (res.headersSent || res.writableEnded) return; // la pantalla del cliente deja la conexión abierta
      return enviar(res, 200, out === undefined ? { ok: true } : out);
    }
    if (r0.startsWith('/fotos/')) {
      if (!usuarioDe(req)) { res.writeHead(401); return res.end(); }
      const f = path.join(FOTOS_DIR, path.basename(r0));
      if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
      res.writeHead(200, { 'Content-Type': f.endsWith('.png') ? 'image/png' : 'image/jpeg', 'Cache-Control': 'private, max-age=86400' });
      return fs.createReadStream(f).pipe(res);
    }
    if (r0 === '/checador' && estatico(res, 'checador.html')) return;
    if (r0 === '/pantalla' && estatico(res, 'pantalla.html')) return;
    if (r0 !== '/' && estatico(res, r0.slice(1))) return;
    estatico(res, 'index.html') || (res.writeHead(404), res.end());
  } catch (e) {
    if (res.headersSent) return;
    if (e instanceof ErrorUsuario) return enviar(res, e.status, { error: e.message });
    console.error(e);
    enviar(res, 500, { error: 'Error interno: ' + e.message });
  }
});

revisarLicencia();
setInterval(revisarLicencia, 60 * 60 * 1000).unref();
const respaldoDiario = () => { try { const f = respaldar('diario'); if (f) console.log('  Respaldo diario: ' + f); } catch (e) { console.error('No se pudo respaldar:', e.message); } };
setTimeout(respaldoDiario, 15000).unref();
setInterval(respaldoDiario, 60 * 60 * 1000).unref();
setInterval(() => { try { run("DELETE FROM sesiones WHERE creado < datetime('now','localtime','-30 days')"); } catch { /* nada */ } }, 6 * 3600 * 1000).unref();

FUNNEL = crearFunnel({ puertoPublico: PUERTO_FUNNEL, permitido: funnelPermitido, manejar: (req, res) => {
  const p = polizaHoy();
  if (!p.activa) { // sin póliza vigente no se entra desde internet
    if (String(req.url).startsWith('/api/')) return enviar(res, 402, { error: p.motivo });
    res.writeHead(402, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }); return res.end(PAGINA_SIN_POLIZA(p.motivo));
  }
  servidor.emit('request', req, res);
} });
setTimeout(revisarPoliza, 20000).unref(); setInterval(revisarPoliza, 30 * 60 * 1000).unref();
servidor.listen(PUERTO, '0.0.0.0', () => {
  nube.iniciar();
  console.log('\n  ==============================================');
  console.log(`   ${PRODUCTO} v${VERSION}`);
  console.log(`   [${new Date().toLocaleString('es-MX')}] Sistema iniciado`);
  console.log('   Código de equipo (para la licencia): ' + codigoEquipo());
  console.log('   Licencia: ' + (MODO_DESARROLLO ? 'MODO DESARROLLO' : LICENCIA.activa ? 'ACTIVA - ' + LICENCIA.cliente + (LICENCIA.expira ? ' (vence ' + LICENCIA.expira + ')' : ' (permanente)') : 'NO ACTIVADA'));
  console.log(`   Abra en el navegador:  http://localhost:${PUERTO}`);
  for (const i of ipsEquipo()) console.log(`   ${i.tailscale ? 'Monitoreo (Tailscale)' : 'Otras computadoras '}:  http://${i.ip}:${PUERTO}`);
  if (!process.env.MAXSEL_SERVICIO) console.log('   No cierre esta ventana mientras use el sistema');
  console.log('  ==============================================\n');
});
servidor.on('error', (e) => {
  if (e.code === 'EADDRINUSE') console.error(`\n  El puerto ${PUERTO} ya está en uso: el sistema probablemente ya está funcionando.\n`);
  else console.error(e);
  process.exit(1);
});
