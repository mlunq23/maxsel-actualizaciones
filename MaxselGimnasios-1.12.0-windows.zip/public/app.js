// ===================== Utilidades =====================
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const dinero = (n) => (Number(n) < -0.004 ? '-$' : '$') + Math.abs(Number(n || 0)).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const usd = (n) => 'US$' + Number(n || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
const fecha = (s) => { if (!s) return '—'; const [y, m, d] = s.slice(0, 10).split('-'); return `${Number(d)} ${MESES[m - 1]} ${y}`; };
const hora = (s) => (s && s.length > 10 ? s.slice(11, 16) : '');
const fechaHora = (s) => (s ? `${fecha(s)} ${hora(s)}` : '—');
const hoyStr = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const ymdLocal = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const sumarDiasStr = (s, n) => { const [y, m, d] = s.split('-').map(Number); const f = new Date(y, m - 1, d + n); return `${f.getFullYear()}-${String(f.getMonth() + 1).padStart(2, '0')}-${String(f.getDate()).padStart(2, '0')}`; };
const ESTADOS = { activo: 'Activo', por_vencer: 'Por vencer', vencido: 'Vencido', sin: 'Sin membresía', bloqueado: 'Bloqueado', pendiente: 'Pendiente' };
const etqEstado = (e) => `<span class="etq ${e}">${ESTADOS[e] || e}</span>`;
const iniciales = (n) => esc(String(n || '?').split(/\s+/).slice(0, 2).map((p) => p[0]).join('').toUpperCase());
const fotoMini = (c) => (c.foto_url ? `<img class="foto-mini" src="${c.foto_url}" alt="">` : `<span class="foto-mini">${iniciales(c.nombre)}</span>`);
// Permisos del usuario (los define el administrador en Usuarios)
// Módulos que se venden aparte (Gastos y Asistencia de empleados). Se encienden desde la licencia.
const PERM_MODULO = { gastos: 'gastos', cuentas_pagar: 'gastos', empleados: 'gastos', checador: 'asistencia', asistencia: 'asistencia' };
const NOMBRE_MOD = { gastos: 'Gastos', asistencia: 'Asistencia de empleados' };
const modOn = (k) => !(k && estado.yo?.licencia?.modulos && estado.yo.licencia.modulos[k] === false);
const puede = (perm) => !perm || perm === 'sesion' || (perm.includes('|') ? perm.split('|').some((p) => puede(p)) : (modOn(PERM_MODULO[perm]) && !!estado.yo?.permisos?.includes(perm)));

async function api(url, datos, metodo) {
  const opts = { method: metodo || (datos !== undefined ? 'POST' : 'GET'), headers: {} };
  if (datos !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(datos); }
  const r = await fetch(url, opts);
  let j = null; try { j = await r.json(); } catch { /* sin cuerpo */ }
  if (r.status === 401 && url !== '/api/login') { mostrarLogin(); throw new Error('Tu sesión terminó, vuelve a entrar'); }
  if (r.status === 402) { mostrarActivacion(); throw new Error(j?.error || 'El sistema no tiene licencia activa'); }
  if (!r.ok) throw new Error(j?.error || 'Error ' + r.status);
  return j;
}
function toast(msg, tipo = '') {
  const t = document.createElement('div');
  t.className = 'toast ' + tipo; t.textContent = msg;
  $('#toasts').append(t); setTimeout(() => t.remove(), tipo === 'error' ? 6000 : 3500);
}
// Ejecuta una acción mostrando el error si falla
async function intentar(fn, btn) {
  if (btn) btn.disabled = true;
  try { return await fn(); } catch (e) { toast(e.message, 'error'); } finally { if (btn) btn.disabled = false; }
}
const ventanaDeCaptura = (el) => !!el.querySelector('input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=file]),select,textarea');
function avisarVentana(caja) { if (!caja) return; caja.classList.remove('avisa'); void caja.offsetWidth; caja.classList.add('avisa'); }
function modal(html, { ancho = false, alCerrar, escSiempre = false } = {}) {
  const f = document.createElement('div');
  f.className = 'fondo-modal';
  f.innerHTML = `<div class="modal ${ancho ? 'ancho' : ''}">${html}</div>`;
  f.cerrar = () => { if (!f.isConnected) return; f.remove(); document.removeEventListener('keydown', escGlobal, true); alCerrar?.(); };
  // Esc funciona aunque el cursor no esté dentro de la ventana (solo la ventana de hasta arriba)
  const escGlobal = (e) => { if (e.key === 'Escape' && $('#modales').lastElementChild === f && !f.contains(document.activeElement)) { e.preventDefault(); f.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); } };
  document.addEventListener('keydown', escGlobal, true);
  // 1.7.1: tocar fuera de una ventana de captura ya NO la cierra (no se pierde lo capturado).
  // Esc solo la cierra si no se ha escrito nada; si ya hay datos, se cierra con Cancelar.
  f.addEventListener('input', () => { f.sucio = true; });
  f.addEventListener('mousedown', (e) => {
    if (e.target !== f) return;
    if (!ventanaDeCaptura(f)) return f.cerrar();
    e.preventDefault(); avisarVentana(f.firstElementChild);
  });
  f.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    e.stopPropagation();
    if (f.sucio && !escSiempre) { avisarVentana(f.firstElementChild); toast('Para cerrar sin guardar use el botón Cancelar'); return; }
    f.cerrar();
  });
  $$('[data-cerrar]', f).forEach((b) => b.addEventListener('click', () => f.cerrar()));
  $('#modales').append(f);
  setTimeout(() => $('[autofocus]', f)?.focus(), 30);
  return f;
}
const confirmar = (msg, txt = 'Sí, continuar') => new Promise((ok) => {
  const m = modal(`<h2>¿Seguro?</h2><p>${msg}</p><div class="modal-pie"><button class="btn" data-cerrar>Cancelar</button><button class="btn peligro" id="si">${txt}</button></div>`, { alCerrar: () => ok(false) });
  $('#si', m).onclick = () => { m.remove(); ok(true); };
});
const valores = (form) => {
  const o = {};
  for (const el of form.elements) {
    if (!el.name) continue;
    if (el.type === 'checkbox') o[el.name] = el.checked;
    else if (el.type === 'radio') { if (el.checked) o[el.name] = el.value; }
    else o[el.name] = el.value;
  }
  return o;
};
function telWa(c) {
  let t = String(c.whatsapp || c.telefono || '').replace(/\D/g, '');
  const lada = String(estado.config?.lada || '52');
  if (t.length === 10) t = lada + t;
  return t;
}
function mensajeWa(plantilla, c) {
  return String(plantilla || '').replaceAll('{nombre}', String(c.nombre || '').split(' ')[0])
    .replaceAll('{nombre_completo}', c.nombre || '').replaceAll('{fecha}', fecha(c.fin || c.vence))
    .replaceAll('{gimnasio}', estado.config?.gym_nombre || '');
}
const URL_NUBE = 'maxsel-pos.web.app/gym';
const linkWa = (c, msg) => `https://wa.me/${telWa(c)}?text=${encodeURIComponent(msg)}`;

// ===================== Estado =====================
const estado = { yo: null, config: null, turno: null, carrito: [], clienteVenta: null };

// ===================== Sesión =====================
function mostrarLogin() {
  $('#app').classList.add('oculto'); $('#activar').classList.add('oculto'); $('#login').classList.remove('oculto');
  $$('.fondo-modal').forEach((m) => m.remove());
  setTimeout(() => $('#formLogin [name=usuario]').focus(), 30);
}
// ===================== Licencia =====================
async function mostrarActivacion(est) {
  est = est || await (await fetch('/api/licencia/estado')).json();
  ['#app', '#login'].forEach((s) => $(s).classList.add('oculto'));
  $$('.fondo-modal').forEach((m) => m.remove());
  $('#activar').classList.remove('oculto');
  $('#licEquipo').textContent = est.codigoEquipo;
  $('#licHuella').textContent = est.huella ? 'Huella del instalador: ' + est.huella : '';
  const motivo = est.motivo && est.motivo !== 'Sin licencia' ? est.motivo : '';
  $('#licMotivo').textContent = motivo; $('#licMotivo').classList.toggle('oculto', !motivo);
  setTimeout(() => $('#licClave').focus(), 30);
}
$('#licCopiar').onclick = async () => {
  const t = $('#licEquipo').textContent;
  try { await navigator.clipboard.writeText(t); toast('Código copiado', 'ok'); }
  catch { const r = document.createRange(); r.selectNodeContents($('#licEquipo')); getSelection().removeAllRanges(); getSelection().addRange(r); document.execCommand('copy'); toast('Código copiado', 'ok'); }
};
$('#licActivar').onclick = async () => {
  $('#licError').textContent = '';
  try {
    const r = await api('/api/licencia/activar', { clave: $('#licClave').value });
    $('#activar').classList.add('oculto');
    toast('¡Sistema activado! Licencia ' + (r.expira ? 'vigente hasta ' + fecha(r.expira) : 'permanente'), 'ok');
    $('#licClave').value = '';
    iniciar();
  } catch (e) { $('#licError').textContent = e.message; }
};

$('#formLogin').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('#loginError').textContent = '';
  try { await api('/api/login', valores(e.target)); e.target.reset(); await iniciar(); }
  catch (err) { $('#loginError').textContent = err.message; }
});
$('#btnSalir').onclick = async () => { await api('/api/logout', {}); location.hash = ''; mostrarLogin(); };
// ===================== Recuperar contraseña (igual que Maxsel Abarrotes) =====================
$('#lgOlvide').addEventListener('click', async (e) => {
  e.preventDefault();
  let lista = [];
  try { lista = await api('/api/login/usuarios'); } catch (x) { toast(x.message, 'error'); return; }
  const ROL = { admin: 'Administrador', gerente: 'Gerente', cajero: 'Cajero' };
  const escrito = String($('#formLogin [name=usuario]').value || '').trim().toLowerCase();
  const m = modal(`<h2>Recuperar contraseña</h2>
    <div class="aviso" style="margin-bottom:12px">Un <b>administrador</b> puede ponerle contraseña nueva a cualquier usuario. Si ningún administrador la recuerda, comunícate con <b>Maxsel</b> (WhatsApp 664 337 5433) para que lo haga con su clave de soporte.</div>
    <form class="form" id="fRec">
      <label class="todo">Usuario que olvidó su contraseña<select name="usuario_id">${lista.map((u) => `<option value="${u.id}" ${u.usuario === escrito ? 'selected' : ''}>${esc(u.nombre)} (${esc(u.usuario)} · ${ROL[u.rol] || esc(u.rol)})</option>`).join('')}</select></label>
      <label class="todo">Contraseña de un administrador (o clave de soporte de Maxsel)<input type="password" name="autorizacion" autocomplete="off" required autofocus></label>
      <label>Contraseña nueva<input type="password" name="nueva" autocomplete="new-password" required minlength="4"></label>
      <label>Repite la contraseña nueva<input type="password" name="nueva2" autocomplete="new-password" required minlength="4"></label>
      <p class="error todo" id="recErr" style="margin:0"></p>
      <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Cambiar contraseña</button></div>
    </form>`, { escSiempre: true });
  $('#fRec', m).addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const d = valores(ev.target); $('#recErr', m).textContent = '';
    if (String(d.nueva).length < 4) { $('#recErr', m).textContent = 'La contraseña nueva debe tener al menos 4 caracteres'; return; }
    if (d.nueva !== d.nueva2) { $('#recErr', m).textContent = 'Las contraseñas nuevas no coinciden'; return; }
    try {
      const r = await api('/api/recuperar', { usuario_id: Number(d.usuario_id), autorizacion: d.autorizacion, nueva: d.nueva });
      m.cerrar();
      $('#formLogin [name=usuario]').value = r.usuario; $('#formLogin [name=password]').value = ''; $('#formLogin [name=password]').focus();
      toast('Listo. Entra con la contraseña nueva de ' + r.nombre, 'ok');
    } catch (x) { $('#recErr', m).textContent = x.message; ev.target.autorizacion.value = ''; ev.target.autorizacion.focus(); }
  });
});
$('#btnPantalla').onclick = () => window.open('/pantalla', 'pantalla_acceso', 'width=1280,height=800');
$('#btnMiPass').onclick = () => {
  const m = modal(`<h2>Cambiar mi contraseña</h2><form class="form" id="f">
    <label class="todo">Contraseña actual<input type="password" name="actual" required autofocus></label>
    <label class="todo">Nueva contraseña<input type="password" name="nueva" required minlength="4"></label>
    <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`);
  $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => { await api('/api/mi-password', valores(e.target)); m.cerrar(); toast('Contraseña actualizada', 'ok'); }); };
};

const MENU = [
  ['inicio', '📊', 'Inicio', 'inicio'], ['pos', '🛒', 'Punto de venta', 'pos'], ['clientes', '👥', 'Clientes', 'clientes'],
  ['accesos', '🚪', 'Accesos', 'accesos'], ['adeudos', '📒', 'Cuentas por cobrar', 'adeudos'], ['avisos', '💬', 'Avisos WhatsApp', 'avisos'],
  ['productos', '📦', 'Productos', 'productos'], ['planes', '🏷️', 'Membresías y promos', 'planes'], ['cortes', '🧾', 'Cortes de caja', 'cortes'], ['gastos', '💸', 'Gastos', 'gastos'], ['cxp', '📑', 'Cuentas por pagar', 'cuentas_pagar'], ['empleados', '👷', 'Empleados', 'empleados'], ['asistencia', '🕒', 'Asistencia', 'checador|asistencia'],
  ['reportes', '📈', 'Reportes', 'reportes'], ['usuarios', '🔑', 'Usuarios y permisos', 'usuarios'], ['config', '⚙️', 'Configuración', 'config'],
];
async function iniciar() {
  let lic;
  try { lic = await (await fetch('/api/licencia/estado')).json(); } catch { lic = null; }
  if (lic && !lic.activa) return mostrarActivacion(lic);
  if (lic && !lic.desarrollo) $('#loginGym').textContent = lic.cliente;
  if (lic) $('#loginLic').textContent = `v${lic.version} · ` + (lic.desarrollo ? 'Modo desarrollo' : `Licencia: ${lic.cliente}` + (lic.expira ? ` (vence ${fecha(lic.expira)})` : ''));
  try { estado.yo = await api('/api/yo'); } catch { return mostrarLogin(); }
  estado.config = await api('/api/config');
  estado.turno = estado.yo.turno;
  $('#login').classList.add('oculto'); $('#activar').classList.add('oculto'); $('#app').classList.remove('oculto');
  $('#gymNombre').textContent = estado.config.gym_nombre;
  document.title = estado.config.gym_nombre + ' · Maxsel Gimnasios';
  const l = estado.yo.licencia;
  if (l && l.diasRestantes !== null && l.diasRestantes <= 10) toast(`Tu licencia vence en ${l.diasRestantes} día(s). Comunícate con Maxsel para renovarla.`, 'error');
  $('#usuarioNombre').textContent = estado.yo.nombre; $('#usuarioRol').textContent = estado.yo.rol;
  $('#bEntradaManual').classList.toggle('oculto', !puede('puerta'));
  $('#nav').innerHTML = MENU.filter((m) => puede(m[3])).map((m) => `<a href="#/${m[0]}" data-r="${m[0]}"><span>${m[1]}</span>${m[2]}</a>`).join('');
  avisosCxp();
  const primera = MENU.find((m) => puede(m[3]));
  if (!location.hash || location.hash === '#/') location.hash = '#/' + (puede('inicio') ? 'inicio' : puede('pos') ? 'pos' : primera ? primera[0] : 'pos');
  else enrutar();
}

// ===================== Rutas =====================
const VISTAS = {};
let limpiarVista = null;
function enrutar() {
  if (!estado.yo) return;
  limpiarVista?.(); limpiarVista = null;
  const [r, id] = location.hash.replace(/^#\//, '').split('/');
  $$('#nav a').forEach((a) => a.classList.toggle('activo', a.dataset.r === r || (r === 'cliente' && a.dataset.r === 'clientes') || (r === 'corte' && a.dataset.r === 'cortes')));
  const v = $('#vista');
  const permRuta = { cliente: 'clientes', corte: 'cortes' }[r] || MENU.find((m) => m[0] === r)?.[3];
  if (permRuta && !modOn(PERM_MODULO[permRuta.split('|')[0]])) { v.innerHTML = `<div class="aviso rojo">El módulo de ${NOMBRE_MOD[PERM_MODULO[permRuta.split('|')[0]]]} no está incluido en la licencia de este negocio. Para activarlo comuníquese con Maxsel.</div>`; return; }
  if (permRuta && !puede(permRuta)) { v.innerHTML = '<div class="aviso rojo">No tienes permiso para entrar aquí. Pídeselo al administrador.</div>'; return; }
  v.innerHTML = '<p class="muted">Cargando…</p>';
  (VISTAS[r] || VISTAS.pos)(v, id).catch((e) => { v.innerHTML = `<div class="aviso rojo">${esc(e.message)}</div>`; });
}
window.addEventListener('hashchange', enrutar);

// ===================== Selector de cliente =====================
function selectorCliente(cont, { alElegir, placeholder = 'Buscar cliente por nombre o teléfono…', elegido = null, permitirQuitar = true } = {}) {
  let actual = elegido;
  const pintar = () => {
    if (actual) {
      cont.innerHTML = `<div class="elegido">${fotoMini(actual)}<b>${esc(actual.nombre)}</b>${actual.estado ? etqEstado(actual.estado) : ''}
        ${actual.saldo > 0 ? `<span class="etq vencido">Debe ${dinero(actual.saldo)}</span>` : ''}${permitirQuitar ? '<button type="button" class="btn chico" data-q>Cambiar</button>' : ''}</div>`;
      $('[data-q]', cont)?.addEventListener('click', () => { actual = null; pintar(); alElegir?.(null); $('input', cont)?.focus(); });
      return;
    }
    cont.innerHTML = `<div class="selector"><input placeholder="${placeholder}" autocomplete="off"><div class="resultados oculto"></div></div>`;
    const inp = $('input', cont), res = $('.resultados', cont);
    let lista = [], sel = 0, timer;
    const mostrar = () => {
      res.classList.toggle('oculto', !lista.length);
      res.innerHTML = lista.map((c, i) => `<div class="res ${i === sel ? 'sel' : ''}" data-i="${i}"><span>${fotoMini(c)} ${esc(c.nombre)} <small class="muted">${esc(c.telefono || '')}</small></span>${etqEstado(c.estado)}</div>`).join('');
      $$('.res', res).forEach((d) => d.addEventListener('mousedown', (e) => { e.preventDefault(); elegir(lista[d.dataset.i]); }));
    };
    const elegir = (c) => { actual = c; pintar(); alElegir?.(c); };
    inp.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(async () => {
        const q = inp.value.trim();
        if (!q) { lista = []; return mostrar(); }
        lista = await api('/api/clientes?limite=12&q=' + encodeURIComponent(q)); sel = 0; mostrar();
      }, 180);
    });
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { sel = Math.min(sel + 1, lista.length - 1); mostrar(); e.preventDefault(); }
      if (e.key === 'ArrowUp') { sel = Math.max(sel - 1, 0); mostrar(); e.preventDefault(); }
      if (e.key === 'Enter' && lista[sel]) { e.preventDefault(); elegir(lista[sel]); }
    });
    inp.addEventListener('blur', () => setTimeout(() => res.classList.add('oculto'), 150));
  };
  pintar();
  return { valor: () => actual, poner: (c) => { actual = c; pintar(); } };
}

// ===================== Inicio =====================
VISTAS.inicio = async (v) => {
  const [d, lec] = await Promise.all([api('/api/inicio'), api('/api/lector/estado')]);
  v.innerHTML = `<div class="encabezado"><h1>Hola, ${esc(estado.yo.nombre.split(' ')[0])}</h1>
    <span class="estado-lector">${estadoLectorHtml(lec)}</span></div>
    ${d.sin_sincronizar ? `<div class="aviso">${d.sin_sincronizar} cliente(s) no se han podido enviar al lector facial. Revisa <a href="#/config">Configuración</a> o entra a la ficha del cliente y presiona "Enviar al lector".</div>` : ''}
    <div class="rejilla cols-4">
      <div class="kpi"><small>Socios con membresía activa</small><b>${d.activos}</b></div>
      <div class="kpi"><small>Vencen en los próximos 7 días</small><b>${d.vencen_semana}</b> <a href="#/avisos">avisar</a></div>
      <div class="kpi"><small>Personas que entraron hoy</small><b>${d.visitas_hoy}</b></div>
      <div class="kpi"><small>Ventas de hoy</small><b>${dinero(d.ventas_hoy)}</b></div>
    </div>
    <div class="rejilla cols-2" style="margin-top:16px">
      <div class="panel"><h2>Cuentas por cobrar</h2><p style="font-size:26px;font-weight:800;margin:0">${dinero(d.por_cobrar)}</p><a href="#/adeudos">Ver quién debe →</a></div>
      <div class="panel"><h2>Productos con poca existencia</h2>${d.stock_bajo.length ? `<table>${d.stock_bajo.map((p) => `<tr><td>${esc(p.nombre)}</td><td class="num ${p.existencia <= 0 ? 'rojo' : ''}">${p.existencia}</td></tr>`).join('')}</table>` : '<p class="muted">Todo en orden.</p>'}</div>
    </div>`;
};
function estadoLectorHtml(l) {
  if (l.modo !== 'real') return '<span class="punto"></span> Lector: modo simulador';
  if (l.conectado) return `<span class="punto ok"></span> Lector conectado (${esc(l.ip)})`;
  return `<span class="punto mal"></span> Lector sin conexión${l.error ? ': ' + esc(l.error) : ''}`;
}

// ===================== Punto de venta =====================
VISTAS.pos = async (v) => {
  estado.turno = await api('/api/turno');
  if (!estado.turno) return pintarAbrirTurno(v);
  const t = estado.turno;
  v.innerHTML = `
    <div class="barra-turno">
      <div class="info"><b>Turno #${t.id}</b><span class="muted">Abierto ${fechaHora(t.abierto)}</span><span>Dólar: <b>${dinero(t.tipo_cambio)}</b></span></div>
      <button class="btn" id="bVentas">Ventas del turno</button>
      ${puede('movimientos') ? '<button class="btn" id="bMov">💸 Retiros y gastos</button>' : ''}
      <button class="btn peligro" id="bCerrar">Cerrar turno</button>
    </div>
    <div class="pos">
      <section>
        <input class="codigo" id="codigo" placeholder="Escanea el código de barras o escribe el nombre del producto" autocomplete="off" autofocus>
        <div class="acciones-rapidas" style="margin-top:12px">
          <button class="btn grande azul" id="bMemb">🏷️ Cobrar membresía</button>
          ${puede('abonos') ? '<button class="btn grande" id="bAbono">💵 Abono a cuenta</button>' : ''}
        </div>
        <div class="fila" id="posDeps" style="gap:6px;flex-wrap:wrap;margin-top:12px"></div>
        <div class="productos-grid" id="prods"></div>
      </section>
      <aside class="panel carrito">
        <div><label>Cliente (obligatorio para venta a crédito)</label><div id="selCliente" style="margin-top:4px"></div></div>
        <div class="carrito-lista" id="lista"></div>
        <div class="total"><span>Total</span><span id="total">$0.00</span></div>
        <button class="btn primario grande bloque" id="bCobrar">Cobrar <kbd>F12</kbd></button>
        <button class="btn bloque" id="bVaciar">Vaciar</button>
      </aside>
    </div>`;
  const sel = selectorCliente($('#selCliente'), { alElegir: (c) => { estado.clienteVenta = c; }, elegido: estado.clienteVenta, placeholder: 'Buscar cliente (opcional)…' });
  const cod = $('#codigo');
  let productos = await api('/api/productos'), depSel = '';
  const pintarDeps = () => {
    const ds = [...new Set(productos.map((p) => p.area).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es'));
    $('#posDeps').innerHTML = ds.length ? `<button class="btn chico ${!depSel ? 'primario' : ''}" data-d="">Todos</button>${ds.map((d) => `<button class="btn chico ${depSel === d ? 'primario' : ''}" data-d="${esc(d)}">${esc(d)}</button>`).join('')}` : '';
    $$('[data-d]', $('#posDeps')).forEach((b) => b.onclick = () => { depSel = b.dataset.d; cod.value = ''; pintarDeps(); pintarProds(productos); cod.focus(); });
  };
  const pintarProds = (lista) => {
    if (depSel && !cod.value.trim()) lista = lista.filter((p) => p.area === depSel);
    $('#prods').innerHTML = lista.slice(0, 60).map((p) => `<button class="prod" data-id="${p.id}"><b>${esc(p.nombre)}</b><span class="precio">${dinero(p.precio)}</span><br><small>${p.existencia} en existencia</small></button>`).join('') || '<p class="muted">Sin resultados</p>';
    $$('.prod', $('#prods')).forEach((b) => b.onclick = () => { agregarProducto(productos.find((p) => p.id == b.dataset.id)); cod.focus(); });
  };
  pintarDeps(); pintarProds(productos);
  cod.addEventListener('input', () => {
    const q = cod.value.trim().toLowerCase();
    pintarProds(q ? productos.filter((p) => p.nombre.toLowerCase().includes(q) || (p.codigo || '').includes(q)) : productos);
  });
  cod.addEventListener('keydown', async (e) => {
    if (e.key !== 'Enter') return;
    const q = cod.value.trim(); if (!q) return;
    const exacto = productos.find((p) => p.codigo === q);
    if (exacto) { agregarProducto(exacto); cod.value = ''; pintarProds(productos); return; }
    const coinc = productos.filter((p) => p.nombre.toLowerCase().includes(q.toLowerCase()));
    if (coinc.length === 1) { agregarProducto(coinc[0]); cod.value = ''; pintarProds(productos); return; }
    if (!coinc.length) toast('No existe un producto con ese código', 'error');
  });
  const pintarCarrito = () => {
    const l = $('#lista');
    if (!estado.carrito.length) { l.innerHTML = '<p class="vacio">Carrito vacío</p>'; }
    else l.innerHTML = estado.carrito.map((it, i) => `<div class="item"><div><b>${esc(it.nombre)}</b><br><small class="muted">${it.tipo === 'membresia' ? esc(`${fecha(it.inicio)} al ${fecha(it.fin)}`) : dinero(it.precio) + ' c/u'}</small></div>
      <b class="num">${dinero(it.precio * it.cantidad)}</b>
      <div class="cant">${it.tipo === 'producto' ? `<button data-m="${i}">−</button><span style="min-width:28px;text-align:center">${it.cantidad}</span><button data-p="${i}">+</button>` : ''}</div>
      <div class="derecha"><button class="btn chico" data-x="${i}">Quitar</button></div></div>`).join('');
    $$('[data-m]', l).forEach((b) => b.onclick = () => { const it = estado.carrito[b.dataset.m]; it.cantidad--; if (it.cantidad <= 0) estado.carrito.splice(b.dataset.m, 1); pintarCarrito(); });
    $$('[data-p]', l).forEach((b) => b.onclick = () => { estado.carrito[b.dataset.p].cantidad++; pintarCarrito(); });
    $$('[data-x]', l).forEach((b) => b.onclick = () => { estado.carrito.splice(b.dataset.x, 1); pintarCarrito(); });
    $('#total').textContent = dinero(totalCarrito());
  };
  const agregarProducto = (p) => {
    if (!p) return;
    const ex = estado.carrito.find((i) => i.tipo === 'producto' && i.producto_id === p.id);
    if (ex) ex.cantidad++; else estado.carrito.push({ tipo: 'producto', producto_id: p.id, nombre: p.nombre, precio: p.precio, cantidad: 1 });
    if (p.existencia <= 0) toast(`Ojo: "${p.nombre}" no tiene existencia registrada`);
    pintarCarrito();
  };
  pintarCarrito();
  $('#bVaciar').onclick = () => { estado.carrito = []; estado.clienteVenta = null; sel.poner(null); pintarCarrito(); };
  const abrirMemb = (cliente) => modalMembresia({ cliente, alAgregar: (it, c) => {
    estado.carrito.push(it);
    if (!estado.clienteVenta) { estado.clienteVenta = c; sel.poner(c); }
    pintarCarrito();
  } });
  $('#bMemb').onclick = () => abrirMemb(null);
  $('#bAbono') && ($('#bAbono').onclick = () => modalAbono());
  $('#bCobrar').onclick = () => modalCobro(() => { estado.carrito = []; estado.clienteVenta = null; sel.poner(null); pintarCarrito(); api('/api/productos').then((p) => { productos = p; pintarProds(p); }); });
  $('#bCerrar').onclick = () => modalCerrarTurno();
  $('#bMov') && ($('#bMov').onclick = () => modalMovimiento());
  $('#bVentas').onclick = () => modalVentasTurno();
  const tecla = (e) => { if ((e.key === 'F12' || e.key === 'F2') && !window.ventanaCobroAbierta?.()) { e.preventDefault(); if (!$('.fondo-modal')) $('#bCobrar').click(); } };
  document.addEventListener('keydown', tecla);
  limpiarVista = () => document.removeEventListener('keydown', tecla);
  // Si venimos de la ficha de un cliente con "Vender membresía"
  if (estado.membresiaPara) { const c = estado.membresiaPara; estado.membresiaPara = null; abrirMemb(c); }
};
const totalCarrito = () => r2(estado.carrito.reduce((s, i) => s + i.precio * i.cantidad, 0));
// Ticket automático al cobrar (Configuración → Gimnasio y tickets). Lo usa la ventana de cobro (cobro.js).
window.imprimirAuto = () => estado.config?.imprimir_auto !== '0';

// Antes de cobrar se revisa con el servidor que la caja esté abierta. Si está cerrada, se abre sola la
// ventana "Abrir turno"; al abrirlo regresa el turno y el cobro sigue donde se quedó. Si se cancela regresa null.
async function asegurarTurno() {
  if (!puede('pos')) {
    if (estado.turno) return estado.turno;
    toast('Primero abre tu turno de caja en el Punto de venta', 'error'); return null;
  }
  try { estado.turno = await api('/api/turno'); } catch (e) { toast(e.message, 'error'); return null; }
  if (estado.turno) return estado.turno;
  toast('Tu caja está cerrada: abre tu turno para poder cobrar');
  return new Promise((listo) => {
    let hecho = false;
    const fin = (t) => { if (hecho) return; hecho = true; listo(t); };
    const m = modal(`<h2>Abrir turno de caja</h2>
      <p class="muted">Para cobrar primero abre tu turno: captura el dinero con el que empiezas y el precio del dólar de hoy. Al abrirlo sigue el cobro.</p>
      <form class="form" id="fTurnoAuto">
        <label class="todo">Fondo inicial en efectivo (pesos)<input name="fondo" type="number" step="0.01" min="0" value="0" required autofocus></label>
        <label class="todo">¿A cuánto vas a tomar el dólar hoy?<input name="tipo_cambio" type="number" step="0.01" min="1" value="${esc(estado.config.tipo_cambio)}" required></label>
        <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Abrir turno y cobrar</button></div>
      </form>`, { alCerrar: () => { if (!hecho) toast('No se cobró: el turno no se abrió', 'error'); fin(estado.turno || null); } });
    $('#fTurnoAuto', m).onsubmit = (e) => {
      e.preventDefault();
      intentar(async () => {
        const t = await api('/api/turno/abrir', valores(e.target));
        estado.turno = t; toast('Turno abierto', 'ok');
        // si se está en el Punto de venta, se actualiza la barra del turno
        const info = $('.barra-turno .info');
        if (info) info.innerHTML = `<b>Turno #${t.id}</b><span class="muted">Abierto ${fechaHora(t.abierto)}</span><span>Dólar: <b>${dinero(t.tipo_cambio)}</b></span>`;
        fin(t); m.cerrar();
      }, $('button.primario', e.target));
    };
  });
}

function pintarAbrirTurno(v) {
  v.innerHTML = `<div class="panel" style="max-width:460px;margin:40px auto">
    <h1>Abrir turno de caja</h1>
    <p class="muted">Antes de vender, captura el dinero con el que empiezas y el precio del dólar de hoy.</p>
    <form class="form" id="f">
      <label class="todo">Fondo inicial en efectivo (pesos)<input name="fondo" type="number" step="0.01" min="0" value="0" required autofocus></label>
      <label class="todo">¿A cuánto vas a tomar el dólar hoy?<input name="tipo_cambio" type="number" step="0.01" min="1" value="${esc(estado.config.tipo_cambio)}" required></label>
      <button class="btn primario grande todo">Abrir turno</button>
    </form></div>`;
  $('#f').onsubmit = (e) => { e.preventDefault(); intentar(async () => { estado.turno = await api('/api/turno/abrir', valores(e.target)); toast('Turno abierto', 'ok'); enrutar(); }, $('button', e.target)); };
}

function modalMembresia({ alAgregar, cliente }) {
  const m = modal(`<h2>Cobrar membresía</h2>
    <div class="form">
      <div class="todo"><label>Cliente</label><div id="mc" style="margin-top:4px"></div><small><a href="#/clientes/nuevo" id="nuevoC">+ Dar de alta cliente nuevo</a></small></div>
      <label>Plan<select id="mp"></select></label>
      <label>Promoción<select id="mpr"><option value="">Sin promoción</option></select></label>
      <div class="todo oculto" id="mparBox"><label>Pareja (2ª persona)</label><div id="mpar" style="margin-top:4px"></div></div>
      <div class="todo" id="cot"></div>
    </div>
    <div class="modal-pie"><button class="btn" data-cerrar>Cancelar</button><button class="btn primario" id="ok" disabled>Agregar al carrito</button></div>`);
  let planes, promos, cot = null;
  const recalcular = async () => {
    cot = null; $('#ok', m).disabled = true;
    const promo = promos?.find((p) => p.id == $('#mpr', m).value);
    $('#mparBox', m).classList.toggle('oculto', promo?.tipo !== 'pareja');
    const c = selC.valor();
    if (promo?.tipo === 'pareja' && c?.pareja_id && !selP.valor()) selP.poner({ id: c.pareja_id, nombre: c.pareja_nombre });
    if (!c || !$('#mp', m).value) { $('#cot', m).innerHTML = ''; return; }
    try {
      cot = await api('/api/membresias/cotizar', { cliente_id: c.id, plan_id: Number($('#mp', m).value), promo_id: promo?.id || null, pareja_id: selP.valor()?.id || null });
      $('#cot', m).innerHTML = `<div class="aviso verde"><b>${esc(cot.descripcion)}</b><br>
        Vigencia: <b>${fecha(cot.inicio)}</b> al <b>${fecha(cot.fin)}</b>${cot.pareja_fechas ? ` (pareja: ${fecha(cot.pareja_fechas.inicio)} al ${fecha(cot.pareja_fechas.fin)})` : ''}<br>
        ${cot.descuento > 0 ? `Precio normal ${dinero(cot.subtotal)} − descuento ${dinero(cot.descuento)} = ` : ''}<b style="font-size:20px">${dinero(cot.total)}</b></div>`;
      $('#ok', m).disabled = false;
    } catch (e) { $('#cot', m).innerHTML = `<div class="aviso rojo">${esc(e.message)}</div>`; }
  };
  const selC = selectorCliente($('#mc', m), { alElegir: recalcular, elegido: cliente || null });
  const selP = selectorCliente($('#mpar', m), { alElegir: recalcular, placeholder: 'Buscar a la pareja…' });
  $('#nuevoC', m).onclick = () => m.cerrar();
  (async () => {
    [planes, promos] = await Promise.all([api('/api/planes'), api('/api/promociones')]);
    $('#mp', m).innerHTML = planes.filter((p) => p.activo).map((p) => `<option value="${p.id}">${esc(p.nombre)} — ${dinero(p.precio)}</option>`).join('');
    $('#mpr', m).innerHTML += promos.filter((p) => p.activo).map((p) => `<option value="${p.id}">${esc(p.nombre)}</option>`).join('');
    const mens = planes.find((p) => p.activo && p.meses === 1 && !p.dias); if (mens) $('#mp', m).value = mens.id;
    recalcular();
  })();
  $('#mp', m).onchange = recalcular; $('#mpr', m).onchange = recalcular;
  $('#ok', m).onclick = () => {
    if (!cot) return;
    alAgregar({ tipo: 'membresia', nombre: cot.descripcion, precio: cot.total, cantidad: 1, inicio: cot.inicio, fin: cot.fin,
      cliente_id: cot.cliente_id, plan_id: cot.plan_id, promo_id: cot.promo_id, pareja_id: cot.pareja_id }, selC.valor());
    m.cerrar();
  };
}

// Cobro estilo punto de venta (Eleventa): ventana grande con formas de pago, billetes rápidos y cambio.
async function modalCobro(alTerminar) {
  if (!estado.carrito.length) return toast('El carrito está vacío', 'error');
  if (window.ventanaCobroAbierta?.() || $('.fondo-modal')) return;
  const turno = await asegurarTurno();
  if (!turno) { $('#codigo')?.focus(); return; }
  if (!estado.carrito.length || window.ventanaCobroAbierta?.() || $('.fondo-modal')) return;
  const total = totalCarrito(), tc = turno.tipo_cambio;
  const memb = estado.carrito.find((i) => i.tipo === 'membresia');
  const cliente = estado.clienteVenta || (memb ? { id: memb.cliente_id, nombre: '' } : null);
  const piezas = estado.carrito.reduce((a, i) => a + (i.tipo === 'producto' ? i.cantidad : 1), 0);
  const cobro = await ventanaCobro({
    total, tc, titulo: 'Cobrar venta', articulos: piezas,
    detalle: cliente?.nombre ? 'Cliente: ' + cliente.nombre : '',
    credito: cliente && puede('credito') ? (cliente.nombre || 'el cliente') : '',
  });
  if (!cobro) { $('#codigo')?.focus(); return; }
  try {
    const venta = await api('/api/ventas', { cliente_id: cliente?.id || null, items: estado.carrito, pagos: cobro.valores });
    alTerminar();
    if (cobro.imprimir) imprimirTicket(venta);
    if (venta.cambio > 0 || venta.pago_credito > 0) {
      const f = modal(`<div style="text-align:center"><div style="font-size:54px">✅</div><h2>Venta realizada</h2>
        ${venta.cambio > 0 ? `<p style="font-size:32px;margin:6px 0">Cambio: <b>${dinero(venta.cambio)}</b></p>` : ''}
        ${venta.pago_credito > 0 ? `<p>Se cargaron <b>${dinero(venta.pago_credito)}</b> a la cuenta de ${esc(venta.cliente)}</p>` : ''}</div>
        <div class="modal-pie">${cobro.imprimir ? '' : '<button class="btn" id="imp">🖨️ Imprimir ticket</button>'}<button class="btn primario" data-cerrar autofocus>Nueva venta (Enter)</button></div>`,
      { alCerrar: () => $('#codigo')?.focus() });
      $('#imp', f) && ($('#imp', f).onclick = () => imprimirTicket(venta));
    } else { toast('Venta realizada', 'ok'); $('#codigo')?.focus(); }
  } catch (e) { toast(e.message, 'error'); }
}

function modalAbono(clienteInicial) {
  const m = modal(`<h2>Abono a cuenta de cliente</h2><div id="ac"></div><div id="ad" style="margin-top:12px"></div>
    <div class="modal-pie"><button class="btn" data-cerrar>Cancelar</button><button class="btn primario" id="ok" disabled>💵 Cobrar abono</button></div>`);
  let cliente = null, saldo = 0;
  const montoActual = () => { const x = $('#monto', m); return x ? r2(x.value) : 0; };
  const validar = () => {
    const mo = montoActual(), rc = $('#rc', m); if (!rc) return false;
    let ok = false;
    if (!(mo > 0)) rc.innerHTML = '<span>Escriba cuánto va a abonar</span><span></span>', rc.className = 'resumen-cobro falta';
    else if (mo > saldo + 0.009) rc.innerHTML = `<span>El cliente solo debe</span><span>${dinero(saldo)}</span>`, rc.className = 'resumen-cobro falta';
    else { const resta = r2(saldo - mo); rc.innerHTML = `<span>Abono ${dinero(mo)}</span><span>${resta > 0.009 ? 'Seguirá debiendo ' + dinero(resta) : 'Cuenta liquidada ✅'}</span>`; rc.className = 'resumen-cobro ok'; ok = true; }
    $('#ok', m).disabled = !ok; return ok;
  };
  const pintar = async (c) => {
    cliente = c; $('#ad', m).innerHTML = ''; $('#ok', m).disabled = true;
    if (!c) return;
    const d = await api('/api/clientes/' + c.id);
    saldo = d.saldo || 0;
    if (!saldo) { $('#ad', m).innerHTML = '<div class="aviso verde">Este cliente no debe nada.</div>'; return; }
    $('#ad', m).innerHTML = `<table><tr><th>Fecha</th><th>Productos</th><th class="num">Pendiente</th></tr>
      ${d.deudas.map((x) => `<tr><td>${fechaHora(x.fecha)}</td><td>${esc(x.productos)}</td><td class="num">${dinero(x.pendiente)}</td></tr>`).join('')}
      <tr><th colspan="2">Debe en total</th><th class="num">${dinero(saldo)}</th></tr></table>
      <p class="muted" style="margin:12px 0 6px">Puede abonar <b>cualquier cantidad</b>. Lo que no cubra se queda como saldo pendiente.</p>
      <div class="cobro">
        <div class="linea"><label for="monto">💰 Cantidad a abonar</label><input id="monto" type="number" step="0.01" min="0" max="${saldo}" inputmode="decimal" value="${saldo.toFixed(2)}" autofocus></div>
        <div class="fila"><button type="button" class="btn chico" data-q="1">Todo (${dinero(saldo)})</button><button type="button" class="btn chico" data-q="0.5">La mitad</button></div>
        <div class="resumen-cobro" id="rc"></div>
      </div>`;
    $('#monto', m).addEventListener('input', validar);
    $('#monto', m).addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === 'F12') { e.preventDefault(); if (validar()) $('#ok', m).click(); } });
    $$('[data-q]', m).forEach((b) => b.onclick = () => { $('#monto', m).value = r2(saldo * Number(b.dataset.q)).toFixed(2); validar(); $('#monto', m).focus(); });
    validar(); setTimeout(() => $('#monto', m)?.select(), 50);
  };
  selectorCliente($('#ac', m), { alElegir: pintar, elegido: clienteInicial || null });
  if (clienteInicial) pintar(clienteInicial);
  $('#ok', m).onclick = async () => {
    if (!cliente || !validar()) return;
    const monto = montoActual();
    // Si la caja está cerrada se abre sola la ventana "Abrir turno" y después sigue el cobro del abono
    const turno = await asegurarTurno();
    if (!turno) { $('#monto', m)?.focus(); return; }
    const tc = turno.tipo_cambio;
    const cobro = await ventanaCobro({ total: monto, tc, titulo: 'Abono a cuenta', detalle: `${cliente.nombre || ''} · seguirá debiendo ${dinero(r2(saldo - monto))}` });
    if (!cobro) { $('#monto', m)?.focus(); return; }
    await intentar(async () => {
      const r = await api('/api/abonos', { cliente_id: cliente.id, monto, ...cobro.valores });
      m.cerrar();
      toast(`Abono registrado. ${r.cambio > 0 ? 'Cambio: ' + dinero(r.cambio) + '. ' : ''}Saldo restante: ${dinero(r.saldo_nuevo)}`, 'ok');
      if (cobro.imprimir) imprimirTicketAbono(r);
      if (location.hash.startsWith('#/adeudos') || location.hash.startsWith('#/cliente')) enrutar();
    }, $('#ok', m));
  };
}

const TIPOS_MOV = {
  retiro: { icono: '🏦', nombre: 'Retiro de efectivo', ayuda: 'El dueño o el gerente se lleva dinero de la caja (para depositar, guardar en caja fuerte, etc.).', concepto: 'Ej. depósito al banco, se lo llevó el dueño', signo: '−' },
  gasto: { icono: '🧾', nombre: 'Gasto / pago', ayuda: 'Se paga algo con dinero de la caja: proveedor, garrafones, limpieza, reparaciones…', concepto: 'Ej. 4 garrafones de agua, pago a proveedor de proteína', signo: '−' },
  entrada: { icono: '➕', nombre: 'Entrada de efectivo', ayuda: 'Se mete dinero a la caja (más cambio, fondo extra…).', concepto: 'Ej. cambio en monedas', signo: '+' },
};
async function modalMovimiento() {
  const info = await api('/api/turno/movimientos');
  let tipo = 'retiro';
  const m = modal(`<h2>💸 Retiros, gastos y entradas de efectivo</h2>
    <div class="tabs-mov">${Object.entries(TIPOS_MOV).map(([k, t]) => `<button type="button" class="btn ${k === tipo ? 'primario' : ''}" data-t="${k}">${t.icono} ${t.nombre}</button>`).join('')}</div>
    <p class="muted" id="ayudaMov" style="margin:10px 0 4px"></p>
    <form class="form" id="f">
      <label>Monto en pesos<input name="monto" type="number" step="0.01" min="0.01" inputmode="decimal" required autofocus></label>
      <label id="lCat">Categoría<select name="categoria">${info.categorias.map((c) => `<option>${esc(c)}</option>`).join('')}</select></label>
      <label class="todo">Concepto (para qué es el dinero)<input name="concepto" required maxlength="120"></label>
      <label class="todo">¿Quién recibe el dinero? <small class="muted">(opcional)</small><input name="recibe" maxlength="60" placeholder="Ej. Juan (proveedor), el dueño"></label>
      <label class="chk todo"><input type="checkbox" name="imprimir" checked> Imprimir comprobante para firma</label>
      <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cerrar</button><button class="btn primario" id="okMov">Registrar</button></div>
    </form>
    <h3 style="margin-top:18px">Movimientos de este turno</h3><div id="listaMov"></div>`);
  const pintarTipo = () => {
    const t = TIPOS_MOV[tipo];
    $$('[data-t]', m).forEach((b) => b.classList.toggle('primario', b.dataset.t === tipo));
    $('#ayudaMov', m).textContent = t.ayuda;
    $('#lCat', m).classList.toggle('oculto', tipo !== 'gasto');
    $('[name=concepto]', m).placeholder = t.concepto;
    $('#okMov', m).textContent = 'Registrar ' + t.nombre.toLowerCase();
  };
  const pintarLista = (lista) => {
    const tot = (k) => lista.filter((x) => x.tipo === k).reduce((a, x) => a + x.monto, 0);
    $('#listaMov', m).innerHTML = lista.length ? `<table><tr><th>Hora</th><th>Tipo</th><th>Concepto</th><th class="num">Monto</th><th></th></tr>
      ${lista.map((x) => `<tr><td>${hora(x.fecha)}</td><td>${TIPOS_MOV[x.tipo]?.nombre || x.tipo}${x.categoria ? `<br><small class="muted">${esc(x.categoria)}</small>` : ''}</td>
        <td>${esc(x.concepto || '')}${x.recibe ? `<br><small class="muted">Recibió: ${esc(x.recibe)}</small>` : ''}</td>
        <td class="num ${x.tipo === 'entrada' ? 'verde' : 'rojo'}">${TIPOS_MOV[x.tipo]?.signo || ''}${dinero(x.monto)}</td><td><button type="button" class="btn chico" data-imp="${x.id}">🖨️</button></td></tr>`).join('')}
      <tr><th colspan="3">Retiros ${dinero(tot('retiro'))} · Gastos ${dinero(tot('gasto'))} · Entradas ${dinero(tot('entrada'))}</th><th></th><th></th></tr></table>`
      : '<p class="muted">Todavía no hay movimientos en este turno.</p>';
    $$('[data-imp]', m).forEach((b) => b.onclick = () => imprimirMovimiento(lista.find((x) => x.id == b.dataset.imp)));
  };
  $$('[data-t]', m).forEach((b) => b.onclick = () => { tipo = b.dataset.t; pintarTipo(); $('[name=monto]', m).focus(); });
  pintarTipo(); pintarLista(info.lista);
  $('#f', m).onsubmit = (e) => {
    e.preventDefault();
    intentar(async () => {
      const d = valores(e.target);
      const mov = await api('/api/turno/movimiento', { tipo, monto: d.monto, concepto: d.concepto, categoria: d.categoria, recibe: d.recibe });
      toast(`${TIPOS_MOV[tipo].nombre} registrado: ${dinero(mov.monto)}`, 'ok');
      if ($('[name=imprimir]', m).checked) imprimirMovimiento(mov);
      e.target.reset(); $('[name=imprimir]', m).checked = true; pintarTipo();
      pintarLista((await api('/api/turno/movimientos')).lista);
    }, $('#okMov', m));
  };
}
function imprimirMovimiento(x) {
  const t = TIPOS_MOV[x.tipo] || { nombre: x.tipo };
  imprimir(`${cabeceraTicket()}<b>${t.nombre.toUpperCase()}</b><br>${fechaHora(x.fecha)}<br>Turno #${x.turno_id} · Cajero: ${esc(x.cajero || '')}<hr>
    <table>${x.categoria ? `<tr><td>Categoría</td><td class="r">${esc(x.categoria)}</td></tr>` : ''}<tr><td colspan="2">Concepto: ${esc(x.concepto || '')}</td></tr>
    ${x.recibe ? `<tr><td colspan="2">Recibió: ${esc(x.recibe)}</td></tr>` : ''}<tr><td><b>Monto</b></td><td class="r"><b>${dinero(x.monto)}</b></td></tr></table>
    <br><br><br><div class="c">______________________________<br>Firma de quien ${x.tipo === 'entrada' ? 'entrega' : 'recibe'}</div><br><br><div class="c">______________________________<br>Firma del cajero</div>`);
}

async function modalVentasTurno() {
  const ventas = await api('/api/ventas');
  const m = modal(`<h2>Ventas de mi turno</h2><div class="tabla-scroll"><table><tr><th>#</th><th>Hora</th><th>Detalle</th><th>Cliente</th><th class="num">Total</th><th></th></tr>
    ${ventas.map((v) => `<tr><td>${v.id}</td><td>${hora(v.fecha)}</td><td>${esc(v.detalle)}${v.cancelada ? ' <span class="etq vencido">Cancelada</span>' : ''}</td><td>${esc(v.cliente || '')}</td><td class="num">${dinero(v.total)}</td>
    <td class="fila"><button class="btn chico" data-t="${v.id}">Ticket</button>${puede('cancelar') && !v.cancelada ? `<button class="btn chico" data-c="${v.id}">Cancelar</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="6" class="vacio">Sin ventas todavía</td></tr>'}
    </table></div><div class="modal-pie"><button class="btn" data-cerrar>Cerrar</button></div>`, { ancho: true });
  $$('[data-t]', m).forEach((b) => b.onclick = async () => imprimirTicket(await api('/api/ventas/' + b.dataset.t)));
  $$('[data-c]', m).forEach((b) => b.onclick = async () => {
    if (!await confirmar('Se cancelará la venta, se regresará la existencia de los productos y se anulará cualquier membresía incluida.', 'Cancelar venta')) return;
    intentar(async () => { await api(`/api/ventas/${b.dataset.c}/cancelar`, {}); m.cerrar(); toast('Venta cancelada', 'ok'); modalVentasTurno(); });
  });
}

function modalCerrarTurno() {
  const m = modal(`<h2>Cerrar turno</h2>
    <p class="muted">Cuenta el dinero de la caja y escribe cuánto hay. El sistema no te muestra cuánto deberías tener.</p>
    <form class="form" id="f">
      <label class="todo">Efectivo en pesos (todo lo que hay en caja, incluyendo el fondo)<input name="efectivo" type="number" step="0.01" min="0" required autofocus></label>
      <label class="todo">Dólares (cantidad en dólares)<input name="usd" type="number" step="0.01" min="0" required></label>
      <label class="todo">Total de vouchers de tarjeta<input name="tarjeta" type="number" step="0.01" min="0" required></label>
      <label class="todo">Notas (opcional)<textarea name="notas" rows="2"></textarea></label>
      <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn peligro">Cerrar turno</button></div>
    </form>`);
  $('#f', m).onsubmit = (e) => {
    e.preventDefault();
    intentar(async () => {
      const r = await api('/api/turno/cerrar', valores(e.target));
      m.cerrar(); estado.turno = null;
      if (r.corte && puede('cortes')) { location.hash = '#/corte/' + r.id; }
      else if (r.corte) {
        const d = r.corte.diferencia;
        modal(`<div style="text-align:center"><div style="font-size:54px">${Math.abs(d.total_mxn) < 0.5 ? '✅' : '⚠️'}</div><h2>Turno cerrado</h2>
          <p style="font-size:18px">${Math.abs(d.total_mxn) < 0.5 ? 'El corte cuadra' : d.total_mxn < 0 ? 'Faltante: <b>' + dinero(-d.total_mxn) + '</b>' : 'Sobrante: <b>' + dinero(d.total_mxn) + '</b>'}</p>
          <table><tr><th></th><th class="num">Debería haber</th><th class="num">Contaste</th></tr>
          <tr><td>Efectivo</td><td class="num">${dinero(r.corte.esperado.efectivo)}</td><td class="num">${dinero(r.corte.turno.decl_efectivo)}</td></tr>
          <tr><td>Dólares</td><td class="num">${usd(r.corte.esperado.usd)}</td><td class="num">${usd(r.corte.turno.decl_usd)}</td></tr>
          <tr><td>Tarjeta</td><td class="num">${dinero(r.corte.esperado.tarjeta)}</td><td class="num">${dinero(r.corte.turno.decl_tarjeta)}</td></tr>${r.corte.resumen.transferencia > 0 ? `<tr><td>Transferencias <small class="muted">(van al banco, no se cuentan)</small></td><td class="num">${dinero(r.corte.resumen.transferencia)}</td><td></td></tr>` : ''}</table></div>
          <div class="modal-pie"><button class="btn primario" data-cerrar>Listo</button></div>`);
        enrutar();
      }
      else { modal('<div style="text-align:center"><div style="font-size:54px">👋</div><h2>Turno cerrado</h2><p>Entrega el dinero y los vouchers a tu gerente.</p></div><div class="modal-pie"><button class="btn primario" data-cerrar>Listo</button></div>'); enrutar(); }
    }, $('button.peligro', e.target));
  };
}

// ===================== Tickets =====================
function imprimir(html) {
  const f = $('#ticketFrame');
  const d = f.contentDocument;
  d.open();
  d.write(`<html><head><style>@page{margin:2mm;size:80mm auto}body{font:12px/1.35 monospace;width:72mm;margin:0}h3{text-align:center;margin:0 0 4px;font-size:15px}.c{text-align:center}.r{text-align:right}table{width:100%;border-collapse:collapse}td{vertical-align:top;padding:1px 0}hr{border:0;border-top:1px dashed #000}</style></head><body>${html}</body></html>`);
  d.close();
  // si el ticket trae imagen (logo), se espera a que cargue antes de imprimir
  const imgs = [...d.images].filter((i) => !i.complete);
  const listo = Promise.race([Promise.all(imgs.map((i) => new Promise((ok) => { i.onload = i.onerror = ok; }))), new Promise((ok) => setTimeout(ok, 1500))]);
  listo.then(() => setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); }, 150));
}
function cabeceraTicket(simple = false) {
  const c = estado.config;
  const logo = c.ticket_logo === '1' && c.gym_logo ? `<div class="c"><img src="/logo-gym?${esc(String(c.gym_logo).split('?')[1] || '')}" style="max-width:50mm;max-height:22mm;margin-bottom:3px"></div>` : '';
  if (simple) return `${logo}<h3>${esc(c.gym_nombre)}</h3><hr>`;
  return `${logo}<h3>${esc(c.gym_nombre)}</h3><div class="c">${esc(c.gym_direccion)}${c.gym_telefono ? '<br>Tel. ' + esc(c.gym_telefono) : ''}</div><hr>`;
}
// Al final de cada ticket: logo de Maxsel chico y discreto, la leyenda y el contacto de Maxsel
const LOGO_TICKET_MAXSEL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAAA8CAYAAADc3IdaAAAkJUlEQVR42u2deZwU1bn3v9VV3T0bwzoRTECixqAhEdEoiUGNxi0GUJJRkxDDVQy4RMy9LtdIfKPRxC2bvnmJCUGNevNeJCo3IDGCxjExiCKLIqLGBUEWHRiYGZie7qpz/6jn9JwuqnoD1Eg9n099urv61NnPc37Pcp6ygATgAacDl1qWdThQw/tLrlLqn8CdwM8BF7AARUwxxbTX09WAsm1bCVN43y/btpVlWQr4E1AnjNWKhyqmmPZesoAzgAcsy/KUUiqdTtsNDQ0opbCsPccflPLBklmGLtN1Xdra2hSQA5KCsv4dsAVtxRRTTHspw/pHIpE4SinlTZgwwb7mmmsYMGAAiUQCy7JQSuWZS0UZW1ZRhuc4DkopXNctYFj63n333ceVV17pZTIZlFJblVIHAptj0TCmmPZmjmVZWwHV1NSkurq61HtF7e3tJcv7+te/rgDPcRwFfF6qbMejFlNMeyc5tm07uVyO0aNHk0wm6e7uJplMopQikUgAsGnTpoozbmhooK6uDs/z8kjLdV2y2SyO4zBx4kSefvppXnzxRdLpNJZlYds2lmWRy+VIJBKMHTuWP/zhD/m6xsMVU0x7OcMyRbREIkEikciLgOvXr2fq1Kk8+uijAHieV5YomEgk6NevH9OmTWPixIl4nkcikcBxHBzHLzKRSLB27Vp69eoVmodt2/m0WmKMhyummGKG5XMDQ0/leR62bfODH/yA+++/v6qMt2zZwnnnncdRRx3FwQcfjOd5LFiwgHXr1pFKpXjzzTdJJpPMmDGDmpoabNvmtNNOo7GxMV+XanRnMcUU017AsEzGlUwmaW9v56677uKqq67imGOOIZfLYdvlq4+6u7s544wzeOaZZzj44IPZsmUL48aNo6urqyDd+eefn//+0EMPMW7cuLKQXEwxxbR3MiwrSrRzXZcjjzySU045parMNfPTIqBSiuOPP56f/OQndHd3Y1lW/n/HcfjMZz4DEMUYYx+smGKKGVa0bsiyLLZv3053dze5XC6oUwpNr2nHjh0FYp1Wvr/66qv84he/yOu1LMvC8zyGDBnCJz/5SWzbjhIFY/kwpphihlUcIXmeRyqVIpVKVZSxZliaiVmWRb9+/VizZg1r1qwJfeaII46gubk5FgljiimmyhiW67r06tWLiy66iLvuuovu7m4AUqkU2Ww2LzKm02my2SzpdJrGxkYaGhqwLCvPlDSj69OnDy+//DIvvvgitm3jeR65XI5kMsncuXO54YYbSiK4mGKKKWZYkeKd67occMABXHnllSxfvpzbbruNmTNnsmLFCq655hpuvPFGhg0bxoQJE9i4cSNPP/00Q4YMAWDjxo2MGDGCbDabR1yXXHIJGzZsIJFI5H2ustksL7zwAtlsdieFfEwxxRRTIcdynE5ANTc3K6WU6u7uVkop1dHRoQB1yy23KKWUamtrU5MmTcp7oY8dOzb/ffz48SqVSu3kqQ6o++67Tyml1LZt29SIESNUQ0ODamxszB9yrq+vV4MGDVIHHHCAWrRokVJKqUwmo5RSatasWaan+2ipcuzpHlNMMcIqpFwuR0NDA9deey0dHR088sgjLFq0CMdxsG2buXPncsEFF6CU4oEHHqC2tpZp06blRcI33nijQCSsr69n6dKleU/3s88+mzlz5rB+/Xrq6upQShU4lcYUU0wxlc2wNOPIZDKsXr2a2tpa6uvraWtr4+2338bzPFatWsWgQYOor6+nq6uLTCbDwQcfTDqdzh/nMa2E2pPesiw2b95MJpPJi4c67Z6MEBFTTDF9SEXC9vZ2Bahbb71VKaXU9u3b1ZQpU/Li3rnnnpv/3tzcrCzLKioSZrNZpZRSuVxOeZ6npk+frq6//nqVzWaV67rK87z8czptLBLGFFNMZSEspRSpVIpZs2bxpS99iQceeIA5c+Ywfvx4lFI8+uijPPLII1iWRUtLCzU1NTz11FM0NDQA5K2EQcufRlNTpkypts6WcZn+Dwl8vVjUfYh9uWKK6cPJsFzXpb6+nsWLF9Pc3My6devYvn07559/Ph0dHbS2tvKNb3yDXr16sXHjRhzH4Vvf+laeIeVyOZ+7RIh4rusW6K3KZFTgB/XTzEczI2UwKX3fC2FeMcUU078wRWq3bdtm69atXHzxxaxatYr58+dz2mmn8cYbb7Bo0SJOPfVUnn/+ed544w1OPvlkXNdl6dKlrF69mtWrV7NixYoCxhWWf4V+V5ph/Rh4CjhQmJFuw8+BfwAHyX1bmNetcn/fQD4xxRTTh4Vh6WijXV1dedTU3t6O53kMHDiQTCZD3759cV2Xd999l2QymVeol4o2WiVppDQG+BzwGDAcP2TyncClwCjgceAIuT8D+A+5P6JUm2OKKaZ/UZEwl8vRp08fZsyYweLFi1m1ahXZbJaDDjoIpRSvvfYaw4YNA3x9Vb9+/eju7s4fq3Fdd08xrk5hRoOBh4EVwGlyTwmSmgM8B3wFyAqTylZYjmWgNC1aauRmGeUlKNSf5Yx7O0nChL9Mw4xTr4psLl4Z98x6ExCXzecSgTI94xk7pI5eLF7H9IFhWMEDx7Zts2XLFi699FLOOussEokEDQ0NXHHFFXzqU5/inHPOoa2tjVQqxbRp03j88cfp3bt33odKv8gik8lUXbmIQ9AJWVA5YVqDDUaCwbT2Ne5X88Yd/RIMijAXK2IhF1vc1bxEI0oXp/V0qox6l1M/zQDjF33E9MFmWDpKgj6SU19fz5gxY5gzZw7PPfccmUwGy7J46aWXWLlyJS0tLf4MTyRYvnw52WyWT3/603ndVDabpa6ujuHDhxeEW66EWZUIM5MwkIEd+N+87wWeK4c5KPx3M35HxM81wB3Aa8CJwKeB3wFbgYOB84CPAn+TdJ8ETgG6DSaQwn9l2SdElNWcPAn8N9AfWCXPKIMJ6focCSw2ftsi6v490D4LOBc4DmgDZgratAyGNlxQaUbuvwIsBHZImhOBkUYdU8BfgGURqC6mmN5bhtXR0VEQT92yLGbMmMH48eN5+eWX82Fg+vTpg+u6vP766/lMPvKRj+A4Dm1tbViWRUdHB/X19Tz44IMcfvjhZDKZ/IHnckh7w2/fvj1M36ZCxJ8ocY4yRK2wZy3gv/BfgZYVpjIB2A/4llx/AHoBTwqzyQJnA/2AdfjK/iC9A3xN9HAmPQOcIG28WsYlZ3yeA4zHf9ltUsoaDvwROAzYYKDOnwNTDRH1AuDjwFuSXxbfp+3GQB1WAt8QEfs84KwQVBYzrJjed3o3kUh4NTU1qqWlRX1QqKOjQ40YMUJZluUlEgkPX5GOoAxl6JBKXTrdSYZ+hiJ6IoQxKdGRpYRxfVMYwHRZ9PXAZEk3EUgLo/gU0Bc4FPiepL1YfveWPNvwrZn7CUKrBX4oeY00kJcFDBQkN1vup+XzNkl/tcFoa0THt0K+fw44X56xjA3qHKnX+cDhwE2S10vSB3fI/0dJHT8hjLgSpBpTTHsEYT2llBrT1dXljhkzxp46dSqO4+SthEDFinONplzXrVgU1Ed45s+fz7Jly7xEIoHneW8DL1aIlKpSm8mC3Cqo5XPAvwG/NfRFCem3JPBPee7bIjb+0mB8y4FBknaV/NbiVVIYXgroMkQxgLuBo4Htks9vgUZhRIjI+DFhOgAXAv8P2CJM5kVhepcAv8F36QhDkY6IgkvkqgcuAg6Rsh1hpA2C3Da/B/0fU0wl6XBZMEoWQ66Cy0QxUWncMtMFr6xlWfrZKQaDfbpKhHWKoKtSR3s0h/2CLH4FbDIYxG/l3hD5faUwCiU6rE/QYxgYL/fH0GN5ezhQv3Vy/zrj3r2S99XGvfuMOt4i9+6Uz6lG3Q8RvZYSHdT3jP8cg8Eq4FSpV1L6xwXGAjcH6pgRxhUjrJjed4S1RHQvv7Usq6mSF02ELPLdlQ7P8/B8pde1wK/ltmZm1VCHLMhSDdT6mb+Jnuhc4HpBPv+QfEy6SZjJZcI4/r8gpC4DjZiWN0cYwJWy+FvpUaIr0Wd9E9gmuqSVwP6CxgA+gm8M+Kugv88KU/q1gbCOFsZzC/Az4HXgIWFMuUBbXbkOkvHZbIzT1YLsOuhRwMcU0/vKsGx8v6UlSqkJuVzuKNlNS0F/C99K1SCL5C0K/X+0+FArCygBLJKFmCiRvyv6lP+WZyx894XD8BXclZBGBCdKvovKSG8L4nga3/m0DZglOp3tkk9W6jJamMGlgrrOwHepeM1gCkFDwXZDfDSZh4fv6HoHvrJ8K76C/3EDHU0SEXGYMNBBol9qFmR2qoiq/wNsFMb7JamjOS6usYkcA/ynMNll+Mp3V5BWLkRsjimm95Wq9f5+gR6lcxQNMkTOT1XJVMH3bNfuCtkKL1N8PUqr2sLUb/KpRbm1IsK9K78PAX4l3wfguwwoEcEWyPcXgTrJp1nujTPK+KvcewV4GXhTxHIt/u0vG4HCV4prJvEAvvJ8m6Cy2cB84H5hNKtE56YkzcOStxIEDT0K++/I/XdEJNV98x35/z75/TqwWvL5ZmA8YorpfUFYenfX3s+lTNbaDyhloJe0oSPJGUzQMxYv8r3cchKGGAjQx6hnNYtGuwn0K4HsLOARfKvducCx+Ar1K4QZrRWU5omo2CAIxgEeFbFQ+2NsxPeBetcoY4mgTq3T6pa8XhNx0JH8vybIN41/dnIx/vGi1/DPU84y8rxE6uqKfmoavh/WJuAqSWsZffk2PdZWW9p7N/CEpHte6qJdPDTjjxFWTO8rWVU+oxnWUkEdk/EtUmEM6+Oy0GvwXROWUL4vj+nF/TS+8+R6fP+jcpFjVvQzp0h+JwljsSnt0Z0U8as1pD4m9ZKytpZIVwni9Ur0h3lsyA15vq+Isu5uKDemmD5QCKvSxWRReN7MNi4Vks4UufTLW6tdGK8D363wmRNFt1MJk7aF2bUav10KPcY1AmkPoEIvgsmY5Zv5qMBvL8BQE4F0QSZl/q+fC9Y7aqOyjN9uiT6K0VVM/1IMK2FMatNipy1wbkC8QnZ5PdG3Gc9Ui0IcgwmWysORevSqohw3sHDdkEUbZDZeGYtclbgfLC+YrwpJ65VR76iyVMyYYvowMiyNig7DP6YyAN9yB76f1DEiQnmB9L3oMcnfgq/AXYBvtaqGaakAElAl6pzbBTSndnO694pihhPTXs2wtFhxCvAgvj7KpM/LVYq+Ip8X4Su1r6U8XdJ7SVGhYQhBOV4RRmlHoDZV5jiYaS2jTuX0VdRZStcYz2odQMv1g7N2gYHujjGoND9CUKtXRT+X+2yxEERqN9TZJjqaSNQajwopFNXOSgFGWP9ZhIc2L9pxVpErYVzay7zLQC66QuW4FOTwrWIuviPiYAr1YWFl6++67EUR/4dd+jzeGUYdTqZ6S+PuWAi7o8wPIulxjHIXcdhzXvJ7Mu8PA31oglY6ZXA1U4k+QH4nA51Q7sI1J3QK/2DvW0U4sIrQ/ZT7Uols4BOD0UYFwxuJ78qQjVgE+jjNMnwDgIlA9W7xMeCrAfE4hx8Boo1CBXsK3xWhztgAkvihaF41EOy5+P5ed9ITNkdFtGEYvpEhazD2NnzHUg/fp6p/haJyQjaqu+XTCsyNYBytGqlnZ+B+MUSt8/mCtNkL2VgUvpHjTXwfsVcN1BfMu9wxDeafxHe4fYboIIlKNtxmCl0+kjJOiykedPFwUaNkjfzS+L51L+L71I2qsM6Py7zUUsyh+CcgnqPQgh/WltPwrem6LUn8Q/QL8R2hv1oFskri+xrOC8wX/b0OP0zTPrKWJpeD4H8qg/ME0FLk+hu+f5EZnXJXr+ek3CdLlN2Cr7DXTpEtZV5P4jtqrjTKXInvFjEoILrohTGtzLp34DtvjgxhxidEPHNQANWC7zaxIyTtmcYYXWzcv6oIhNdtuCAkv030RG14s8rxyuK7S5j9ZiKqU4Hf4zvFdgpjWwfMxT9G1BDS/rD6/7TM+mzH9/a/FD8SRrA+Or+rq2jrtUXEdY3g+9JztMq8llJofQ1DO09H9O8B8v/NVdT5CqMc7Wj9rmwAUW3R/bUwJL975L9jdmGNLygyLhMDaU8tR1Wl9tLry4GO1J30HzJxtNhb6uD3DkE/GjXqAc4FxOIO/BdnBBdsL3xHTp0+I5+nG2M0yaiTwndYDVv4ug3nGen1gfbV9Dj7Lpf/yz3srtuwkR6Lq6nXGIXvX6fwzyL+D348sBsFVb4h/22gJ85WogjD/ZGUuaOImiF4+P0V0bGGjem/lzmmOUmTxT+qVGzxmPPFM/LWjsDHEu7WY+EfVXON/u+S3zcZaa+pos6mu88ceg7lbzP6xolgWHOM+afzmy7/fY7KgiLkjHn8UAjD0tFClkm7d8jnglIibELgtVvGtSccCr0yy3YDYqBb4eUFREK3CPTU+i3TtywRWByWoZOrEVg7RiZgUJ9jUzpKRDBdUCejBzghZV6NHw/Li9jJrZA22CU2q6j6qpC2m+LXuYJymvDPIH4U/+D1ZbLovwEMxT9zuQr/cPgv6Dm1YBUZA/NKRNTfkz45UMSpifTEzq9kTBXhLiNRpFUAdwmKSQV0qhcT7TJykZE2Ic9m8COBWLupznoeZWWTmYN/eiIXwYSD5QX7PKw8u0T9wtQ2jqFLPtRQHwAcb6gC7KjFaZd57QnFXSXlWyWYQbl1T1RhJbMiFo9j6Ez+r4h37EEFsGXoIr4rjFJVoVjtK/mkjDZRZNIn5XMAhe+HbJY6zMKPbPEH2S1tI1898f4GfBHfOjxVEJhLZZE+zDzNF384xsb0W/zzol6JvK0QpujI4nHw44OVkkxsEQnvoseZ1zZ0QvsbbdQ+jPsJQ1cB3ecfRR+X3IU61xXRC+pQ3OcUYVpRlAwp0y5Rv7R89g4BKRqZBnXTlqDhokr3ntkZCC2jY7wH7+lQx5ZlRQbo8zwvHwBQ5+u6PfpQ/ayZX7HQNjpdsTJ1ueDHmjfrUCXpTlwnDMmTgfgK/jEhc9INwT80fRfVm4ArMZbkBN3U4fvFeWUsfj2Yt+CHqdG6yN6y6ycDitHf459ddAzxVyuBB0tbFxpiXjoCvVrCHHW4IEd0hU/Kzl9MEa/btVzQWb0s+qOFIRAYBwc/TPQXiHbktaRdM9k5coje3RcEFlhU3SxRbF9sIAUX/7zodwRlmicgJkkbcgHU/LMS5SREgX13iLFM1/kxwn0TzRcL3y31/I0xrqUMbmtETNd5dYvRYGwA5W8RMdI0gqwKGaOj8c+6mkhKM/qx+FF4X4qaF52V6n8sy6pKb5RIJD4IuivXgKRh+o7LDQWoTrs4hGE8ZoiFWen8GQGlu2cwhR1FdFgbA+KNwnfF0HS+Uaegklbh+8aZIsmkkDa8Sk+0hiD1Fh1bsM5HFFEa/17aNDCgvytFOt2zottKGRNej8ENRv11G38XyKdOjAtdgTrr9h5vpL3MyE/371920+ah58/dRhmeYU3uZYx1vSz+4FjPDSBa6AmZbdZ5TgX1mWvMT9NnTffPJYHx+FNgPiv8SLZRdHbIHHulDJSMoMlg3cz5PD1E77Uzwjr22GNJpVJ5ZLV69WqGDBlCbW1t/t6GDRt4/vnnAejfvz+HHXZYHjFpJASwdOlSWltbcRyH448/nq6uLlpaWvLIp66ujlGjRtHa2sry5ctJJBKMHj2aZDJZgOp0uZs3b2bJkiXU1NQwatQokslkKBpcsmQJSilGjhzJihUreOeddwrCPe8CoqkxTLWd0ulfDCCSXry3pJHW6aLcPFMYj13Gc+bO2y9CjO1twH8tumTFDP1NQTL6BRjdYqXqxo/1ZZr0U5J2llhtEeTxqDD3+WWIKGlD3MiKhXC67Or/RaHzoSV98lgZCzvqv3KdUjX9XPR1CUM83FfGRDPbrwoydQNqiV9WMN6l6lwOwvakzBqxRpZ6DZ6JvPWc6xVRhwYK3V6U0V4PP1jCGANxmahXt+Gb+BFJ1hJ0DXEcpxNQ11133U4vgmhvb9/pXmdnp9pvv/2U4zhq2bJlkS+RWLp0qWpoaFC2baubb75ZKaXU2LFj89z0zjvvVEopNXr0aAWoyZMnF30pxcyZMxWgZs6cWTTdySefrE444QSllFLNzc0KUI7j7G6EhaCaIML63XuMsLzA/b/Kwp5QAmFZgR1viIG0zTofF9FHX5f/D5O86gXmr8P33YFC37xB9IR+PtRgYq0GKnVKIKx7AnWwDH2PiXZ1/7UY7bw8BP1sFnH2Mbn090fFSFCJLtIOQSm635818nkqpJ6LAn0VhrA8w0VhQUid/0yPm45TAmEF59m1ZSAsJ8ISHZxj/zTEYiuij34dMZeDKOuG0I1FM6z58+cr13XVAQccoAYOHKgOPPBApZRSd9xxhxo4cKAaOHCgmjhxolJKqTPOOEP5oEapKVOmqMGDB6uhQ4eqoUOHqsGDB6t58+YppZTq3bt3XhScPXu2Ukqp4cOHq6uuukoppdSkSZPyFZ09e7bK5XLqzDPPVLW1taqhoUHV1taq2tpa1djYqNLptALU448/rhYsWKBqamoK0ujfiURCnX766SqXy6nTTz99VxmWHuDXRD91ouyS90cwjO+8xwwrrA5zDREot4cY1i2SXit5DxKks1UWfJD2EebUSmHE1z/j+yxRhkh4T8TisQStBRfPy6JHCo5pOWqD4RUaMnT/nGjMMVP8OgI/lpk5//Q4nxnRxz+ssM4HlsGwopjWVcac3hMMS8/3IeJi4QXq8W6gfp4g995BK3i+Itu3byeRSLB27VoymQzpdBqlFH379mXDhg0AtLa2opQim+1xHF+/fj1vvfVWwei1tbX5ZqRcj+717LPP5oknnuDJJ5+koaGBa665hhkzZpBOp8lkMmSzWWzbZtiwYbS2tmLbdv75jRs3snLlSgB27NjBPvvsw+c//3kcx8kr8pVSOI7Ds88+i+u62LZd8dt+ikDojxMeg8syFIcb8aOCwntzNnKHTA4NvbUi9jT8gIJQ+CLZ3UlN+J7zGcNiqEXio0U3FVzQjZLGfEPQNnqcaauV2ZUwyyjLVjFFdi5EGZ+tYvy0JXAhvkPoURSeCZxsjINnLOLV9AQBKGecourcVWadO0Rk8wxruSfiV5cxVrndPF+0YWGKzJGcwaDfwXdFmS0boBan95H7vzTE0J4B1Za3dDpNNpslnU5jWRbJZDL/n9YvaUbQ1dXF7bffzjnnnJNP43keo0aNorOzE8dx8s9lMhl++tOf8sc//pG2tjZuuummvD4L4N5772XcuHFce+21oS2+8MILmT59Ojt27GDkyJEsXLgwNN3JJ59Me3t7vk22beffah20Xla4KLyQRWjGq/oePZFF92S0BD3ZXhX9w0x6omQkDEvmnmaWtUYfJOV3TpjVzQHLWF+xMiXZ2fG0ezdsKmFRZLtLLOJEhKEgVaWVVy+0n+G7D5jra2IAoWgG9yupp1Mmk6i2zlqHdLdsElcFrJSKnQMa7C7S/dJbrNpBi+7DosNcIBZC84jbd8WamdeJOabSWl96Uevvmqnoe/mV43l0dnay7777Fijda2pqCt7ynM1mGTRoED/60Y/YtGkTffv25fbbb2fy5Mn5t0zPmzeP3r175xXkjuOQy+UYO3Ys999/PyeddBLTp0+nT58+LFy4kK997Wskk8kCFKffPv3lL38ZpRTt7e24rlvgTrELFBa/Sk+S7+P7IOm3Mu9q3uVQg+iE2gT9pQympdizh4Ffwg9ZPVCsXp2CFI7DPwJ0V4hF78ei3/qr0eZh9Lyso1ImkTAm9inG4tB9uSmA5oKoZL2IpMGAjB7VvYNRK/sfEnH0E4SH9Nb31ouYa5WBjnTd1orIbTpoajeDrWXOr+/L3PmuwbT25FzRiG2ioCY3gO5+Jb+nC8PSzrQu/jGlZrFIO0Au35FhIpRlWXmUpH+bCKuuro7LLruMefPmFTw3a9YsmpubC3yiWlpa6N+/PyNGjOCYY47hnnvuYevWrVxxxRXYts3HPvYxDjnkkLyvlW3buK7LoYcemkd6Gq01NjbS3d1Nd3d3ATPSTE6jw+OOO46ampq8eGlZFs8++yxvv/12Pv8Kdokw8eIZ/CMUfy5D/HKMgTInXNLQtVQqhjSIrmKcMK06yvPH2lWmrRXaX5TJtB7fF+vvxs5ptlE7Yd5voK/BYjH6TZkKbtMp0TOu8/CPQnnG4lD0HBUKLlidbiU9R6rCyqo0XLQWy7tF9/OLiOf1ge47ZLMpB13pOi8rUucEpd9GpZnTJbLJ/KfBQPYE09LMuE4YpAqoUeaJUULrM5+ix9Nd12eqbMxugUi4Y8cOOjs78whKKUVnZyerV6/Ol57L5ejs7Myjms7OTvbff39s284ztlwul0demhHeeuutDB48mJNOOok1a9Zw77338tnPfpaLLrqIlpYW5s6dy/XXX8+ECRN2XpWuy9atW3nwwQcBWLJkCRdccAEvvPBCnnkqpXBdF8dx+Pa3v80rr7zCtm3buPzyywsYLsBZZ53FrFmzqK+vZ9u2bZS5s20SBKVpHf5xlL8bu5zptf0uhV7PehFPEAZncsoJot8x3yxNhF4mSFkp48/4zqwPSV7lvH+RKpmkPou4SsTgu42FMt7Qs5ho5x18Z8AtBgq9VPKbHUAeUZShMMrtR0Q39H8CE1wvvgd2AdVWckQnrH/uxn/v5MBAuzQq3ybWUasKpliMqZVCqlrRnRKxMCP9t6eYlt5AvipoyVwTCMJ+jB5XlX0NRqf7ZqQYyPKuL52A6t27t2pqaso7hVqWpZqamlRjY2PewpBOp1VTU5NKpVIKUE1NTap///47WSwaGxtVU1NTPp+hQ4eqfv365S2G2oG0qalJDRw4UOny+/Xrt9PVv3//gjISiYQaMGCA2nfffdVHP/rR/KV/19bWKiD/XDC/VCq1u9waCJkglqFTeNmwFJmI4FaxGo3EP8ScCfyvrSamb9T5hDvppQ0FM7I7tQasQ7vTSmh+18dLphptLkeMg55TArdFjMENIe1dhe/r9CtBlRuJNon/jUInTNNxVLftden/H0t5+voR/iHkL1ZoKQwasq4PsfKVdIykuFvDKyXqfLQxtnOLWP1Mg8SVRrqgxXlXrYQa9T1DtItFlNXbTP+YORYVe7pXe1XrIU+FXvIlyqmGYT1nDLL+jDqPGAxp0l3GwKhAWv2m63SZDMsUWQ/Hj/6wJ9wagkzrHkn31YB1zjYmq3muEBEDN+PHfOoV2NnDGFaxsTQXmZ7cXfSE/EmFMKxy59F1IYu1Et3aEPzAAkETfpcgiyhmWK1bQzC8TDGG5QTmzHcpdMfYHQxLpzslsO6Cc98L9FHwf12nzwFWXuY1dVNBnVXwXrH/w+6boltUOlM/FnaZSvxi6bQ4W+z/KhSqprNfLsAIokzct4tyOqiIdwPyvc4jJ2k34jvzVRrvXitQl+D7A73Jngs/rcWcyfim/NkiWtQZE9gzEKbus7OlftvxPdHbKxgLFeh70yqqzeQZKeO5MnSKYWOqQ7Xk6Hm3ZLV9s0bUCJbRBxb+8ZqXqM7lpFSdd1SRlyNzdVKIeLk79J2Xh4yxdsXIyCatr4xhEQwaMy7WVkIbcJVSOy2QMPO/eS/KPSB4v5x0lbgalJM2Io1l6BnsIh3thuwIlQyUJXqKM/FfUjooYNUxIyyYRx7axSqyPjChy62TnoAr8c/SzRXdUTnhgYJhfIoxTH1/u+jOfi6I4ELRzSyQBeuKHucL+FFVh+NHxfw2fqTZKMW22V4rROQ2dX16HJeLMrklYDYvJ7/gHLF2UZ+j++eXYh0zj6ncVkEeu1JnLzCmVok58zuxNGprt1uGni9qTup1diQ9seH0S4NTUtZ18t0N0XndjB8KJ2uM5VjEZ28ze2cAvy9EiIRh0SlXsfP7BMvV1+wnyvByIjN+JqJOF4akfztExAuKbIMM/cHaIiLhfhF1OqGEItcs9xj8wH1RIsxi/CM9lCEO3VLmGLbiH2L+N6NtYZEtv1/F/PhhlSJhcAxmG3k+VoZeTJf34yrqfJmRz4KQ/39XpE363mn0RPedUUQknBKS/waxeOsN5eEIVchBJfruyIj2PeTgR948jL3j1VDaSrNBrHymiKZ3h4cFObhGx2+i/DjyQdHgTRF/viTo6Wj8IHeWiH+L8Q8F/8mY6ME6PYEfJ8isUxvh70rEQBfrZQL+WCahG4EEWgVyB8PLvFxCRDBf7KrDUg/EPy84VHbQt/D9r14LsQBFWboeEoYcFS+rVdr2kjBiQvrOzG8+PVEtE2WMmy1t2RXxSPfNjYaYM72MTU+X9yexrlZSZ/Ow9234bgPmm5JWFGmTRlrzRCc5CT/8TzC9/t4SMie3GhuWIwj/LxQG/Htb5lWxNj0rKHxAYDzV/wL78JTsCJLxYAAAAABJRU5ErkJggg==';
const LEYENDA_MAXSEL = ['Sistema Punto de Venta MAXSEL', 'Gimnasios · Restaurantes · Tiendas · Hoteles'];
function pieMaxsel() {
  const c = estado.config, contacto = String(c.maxsel_contacto || '').split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
  const logo = c.ticket_logo_maxsel === '0' ? '' : '<img src="${LOGO_TICKET_MAXSEL}" alt="Maxsel" style="width:26mm;height:auto;display:block;margin:0 auto 2px">';
  return `<div class="c" style="font-size:9px;margin-top:6px;border-top:1px dashed #000;padding-top:4px">${logo}${[...LEYENDA_MAXSEL, ...contacto].map(esc).join('<br>')}</div>`;
}
const formaPagoTicket = (v) => {
  const f = [];
  if (v.pago_efectivo > 0) f.push('efectivo'); if (v.pago_usd > 0) f.push(`${usd(v.pago_usd)} dólares`); if (v.pago_tarjeta > 0) f.push('tarjeta'); if (v.pago_transferencia > 0) f.push('transferencia'); if (v.pago_credito > 0) f.push(`crédito ${dinero(v.pago_credito)}`);
  return f.join(' + ') || 'efectivo';
};
function imprimirTicket(v) {
  if (estado.config.ticket_formato === 'simple') return imprimirTicketSimple(v);
  const filas = v.items.map((i) => `<tr><td colspan="2">${esc(i.descripcion)}</td></tr><tr><td>${i.cantidad} x ${dinero(i.precio)}</td><td class="r">${dinero(i.importe)}</td></tr>`).join('');
  const pagos = [
    v.pago_efectivo > 0 && ['Efectivo', dinero(v.pago_efectivo)], v.pago_usd > 0 && [`Dólares (TC ${dinero(v.tipo_cambio)})`, usd(v.pago_usd)],
    v.pago_tarjeta > 0 && ['Tarjeta', dinero(v.pago_tarjeta)], v.pago_transferencia > 0 && ['Transferencia', dinero(v.pago_transferencia)], v.pago_credito > 0 && ['A crédito', dinero(v.pago_credito)], v.cambio > 0 && ['Cambio', dinero(v.cambio)],
  ].filter(Boolean).map((p) => `<tr><td>${p[0]}</td><td class="r">${p[1]}</td></tr>`).join('') + (v.referencia ? `<tr><td colspan="2"><small>Ref: ${esc(v.referencia)}</small></td></tr>` : '');
  imprimir(`${cabeceraTicket()}Ticket #${v.id}<br>${fechaHora(v.fecha)}<br>Cajero: ${esc(v.cajero)}${v.cliente ? '<br>Cliente: ' + esc(v.cliente) : ''}${v.cancelada ? '<br><b>*** CANCELADA ***</b>' : ''}<hr>
    <table>${filas}</table><hr><table><tr><td><b>TOTAL</b></td><td class="r"><b>${dinero(v.total)}</b></td></tr>${pagos}</table><hr><div class="c">${esc(estado.config.ticket_pie)}</div>${pieMaxsel()}`);
}
// Ticket corto: una línea por artículo, total, forma de pago y cambio
function imprimirTicketSimple(v) {
  const filas = v.items.map((i) => `<tr><td>${i.cantidad !== 1 ? i.cantidad + ' ' : ''}${esc(i.descripcion.replace(/\s*\(\d{4}-\d{2}-\d{2} al \d{4}-\d{2}-\d{2}\)/, ''))}</td><td class="r">${dinero(i.importe)}</td></tr>`).join('');
  const memb = v.items.find((i) => i.tipo === 'membresia' && /\d{4}-\d{2}-\d{2} al (\d{4}-\d{2}-\d{2})/.test(i.descripcion));
  const vence = memb ? `<div class="c">Membresía vigente hasta el ${fecha(/al (\d{4}-\d{2}-\d{2})/.exec(memb.descripcion)[1])}</div>` : '';
  imprimir(`${cabeceraTicket(true)}<div class="c">${fechaHora(v.fecha)} · #${v.id}${v.cancelada ? ' · <b>CANCELADA</b>' : ''}</div><hr>
    <table>${filas}</table><hr><table><tr><td><b>TOTAL</b></td><td class="r"><b>${dinero(v.total)}</b></td></tr>
    <tr><td>Pago</td><td class="r">${formaPagoTicket(v)}</td></tr>${v.cambio > 0 ? `<tr><td>Cambio</td><td class="r">${dinero(v.cambio)}</td></tr>` : ''}</table>${vence}<hr><div class="c">${esc(estado.config.ticket_pie)}</div>${pieMaxsel()}`);
}
function imprimirTicketAbono(a) {
  imprimir(`${cabeceraTicket()}<b>ABONO A CUENTA</b><br>${fechaHora(a.fecha)}<br>Cliente: ${esc(a.cliente)}<hr><table><tr><td>Abono</td><td class="r">${dinero(a.monto)}</td></tr>
    ${a.efectivo > 0 ? `<tr><td>Efectivo</td><td class="r">${dinero(a.efectivo)}</td></tr>` : ''}${a.usd > 0 ? `<tr><td>Dólares</td><td class="r">${usd(a.usd)}</td></tr>` : ''}${a.tarjeta > 0 ? `<tr><td>Tarjeta</td><td class="r">${dinero(a.tarjeta)}</td></tr>` : ''}${a.transferencia > 0 ? `<tr><td>Transferencia</td><td class="r">${dinero(a.transferencia)}</td></tr>` : ''}
    ${a.cambio > 0 ? `<tr><td>Cambio</td><td class="r">${dinero(a.cambio)}</td></tr>` : ''}<tr><td><b>Saldo pendiente</b></td><td class="r"><b>${dinero(a.saldo_nuevo)}</b></td></tr></table><hr><div class="c">${esc(estado.config.ticket_pie)}</div>${pieMaxsel()}`);
}

// ===================== Clientes =====================
VISTAS.clientes = async (v, sub) => {
  if (sub === 'nuevo') return formCliente(v, null);
  let filtro = '';
  v.innerHTML = `<div class="encabezado"><h1>Clientes</h1><span id="cupo" class="muted"></span><a class="btn primario" href="#/clientes/nuevo">+ Nuevo cliente</a></div>
    <div class="panel"><div class="fila" style="margin-bottom:12px"><input id="q" placeholder="Buscar por nombre, teléfono o número de socio" style="max-width:380px" autofocus>
    <div class="filtros" id="fil">${[['', 'Todos'], ['activo', 'Activos'], ['por_vencer', 'Por vencer'], ['vencido', 'Vencidos'], ['sin', 'Sin membresía']].map((f) => `<button class="btn chico ${f[0] === '' ? 'sel' : ''}" data-f="${f[0]}">${f[1]}</button>`).join('')}</div></div>
    <div class="tabla-scroll" id="tabla"></div></div>`;
  api('/api/licencia/estado').then((l) => {
    if (!l.maxClientes) return;
    const lleno = l.clientes >= l.maxClientes, casi = l.clientes >= l.maxClientes * 0.9;
    $('#cupo').innerHTML = `<span class="${casi ? 'rojo' : ''}">${l.clientes.toLocaleString('es-MX')} de ${l.maxClientes.toLocaleString('es-MX')} clientes de la licencia${lleno ? ' · <b>LLENO</b>' : casi ? ' · casi lleno' : ''}</span>`;
  }).catch(() => {});
  const cargar = async () => {
    const lista = await api(`/api/clientes?q=${encodeURIComponent($('#q').value)}&estado=${filtro}`);
    $('#tabla').innerHTML = `<table><tr><th></th><th>#</th><th>Nombre</th><th>Teléfono</th><th>Membresía</th><th>Vence</th><th>Rostro</th><th class="num">Debe</th></tr>
      ${lista.map((c) => `<tr class="click" data-id="${c.id}"><td>${fotoMini(c)}</td><td class="muted">${c.id}</td><td><b>${esc(c.nombre)}</b>${c.estudiante ? ' <span class="etq azul">🎓 Estudiante</span>' : ''}${c.vecino ? ' <span class="etq azul">🏠 Vecino</span>' : ''}${c.pareja_id ? ` <span class="etq sin" title="Pareja: ${esc(c.pareja_nombre)}">💑 Pareja</span>` : ''}${c.importado ? ' <span class="etq sin">Del lector</span>' : ''}</td>
      <td>${esc(c.whatsapp || c.telefono || '')}</td><td>${etqEstado(c.estado)}</td><td>${fecha(c.vence)}</td>
      <td>${c.foto ? (c.sincronizado && c.cara_sync ? '✅' : '<span title="No enviado al lector">⚠️</span>') : '<span class="muted">—</span>'}</td>
      <td class="num ${c.saldo > 0 ? 'rojo' : ''}">${c.saldo > 0 ? dinero(c.saldo) : ''}</td></tr>`).join('') || '<tr><td colspan="8" class="vacio">No hay clientes</td></tr>'}</table>`;
    $$('tr[data-id]', v).forEach((tr) => tr.onclick = () => location.hash = '#/cliente/' + tr.dataset.id);
  };
  let t; $('#q').oninput = () => { clearTimeout(t); t = setTimeout(cargar, 200); };
  $$('[data-f]', v).forEach((b) => b.onclick = () => { filtro = b.dataset.f; $$('[data-f]', v).forEach((x) => x.classList.toggle('sel', x === b)); cargar(); });
  cargar();
};

const CAMPOS_BASE = ['nombre', 'direccion', 'colonia', 'cp', 'telefono', 'whatsapp', 'correo', 'escuela', 'notas', 'acepta_publicidad', 'estudiante', 'vecino'];
const datosBase = (c) => Object.fromEntries(CAMPOS_BASE.map((k) => [k, ['acepta_publicidad', 'estudiante', 'vecino'].includes(k) ? !!c[k] : c[k] ?? '']));
const EVIDENCIA = {
  estudiante: { check: 'Es estudiante', titulo: 'Credencial de estudiante', ayuda: 'Toma foto de su credencial escolar vigente (que se lean nombre, escuela y vigencia).' },
  vecino: { check: 'Vive en la zona (vecino)', titulo: 'INE o comprobante de domicilio', ayuda: 'Toma foto de su INE o de un comprobante de domicilio (luz, agua, teléfono) donde se lea la dirección.' },
};
function htmlFormCliente(c = {}, { autofocus = true } = {}) {
  const f = (n, l, t = 'text', extra = '') => `<label>${l}<input name="${n}" type="${t}" value="${esc(c[n] || '')}" ${extra}></label>`;
  const evi = (tipo) => `<div class="evidencia todo ${c[tipo] ? '' : 'oculto'}" data-evi="${tipo}">
      <img class="evi-img ${c[`doc_${tipo}_url`] ? '' : 'oculto'}" src="${c[`doc_${tipo}_url`] || ''}" alt="${EVIDENCIA[tipo].titulo}">
      <div><b>📎 ${EVIDENCIA[tipo].titulo} <span class="rojo">*</span></b><br><small class="muted">${EVIDENCIA[tipo].ayuda}</small>
        <div class="evi-estado"><small>${c[`doc_${tipo}_url`] ? '✅ Evidencia guardada' + (c.doc_fecha ? ' el ' + fechaHora(c.doc_fecha) : '') : '<span class="rojo">Falta la foto</span>'}</small></div>
        <div class="fila" style="margin-top:6px"><button type="button" class="btn chico primario" data-cam="${tipo}">📷 Tomar foto</button>
        <label class="btn chico" style="color:var(--texto)">📁 Subir foto<input type="file" accept="image/*" data-arch="${tipo}" hidden></label></div></div></div>`;
  return `${f('nombre', 'Nombre completo *', 'text', 'required' + (autofocus ? ' autofocus' : ''))}
    ${f('telefono', 'Teléfono', 'tel')}${f('whatsapp', 'WhatsApp (si es diferente)', 'tel')}${f('correo', 'Correo electrónico', 'email')}
    <label class="todo">Dirección<input name="direccion" value="${esc(c.direccion || '')}"></label>
    ${f('colonia', 'Colonia')}${f('cp', 'Código postal')}
    <label class="chk"><input type="checkbox" name="estudiante" ${c.estudiante ? 'checked' : ''}> 🎓 ${EVIDENCIA.estudiante.check}</label>${f('escuela', 'Escuela')}
    ${evi('estudiante')}
    <label class="chk todo"><input type="checkbox" name="vecino" ${c.vecino ? 'checked' : ''}> 🏠 ${EVIDENCIA.vecino.check}</label>
    ${evi('vecino')}
    <label class="chk todo"><input type="checkbox" name="acepta_publicidad" ${c.acepta_publicidad !== 0 ? 'checked' : ''}> Acepta recibir avisos y promociones por WhatsApp</label>
    <label class="todo">Notas<textarea name="notas" rows="2">${esc(c.notas || '')}</textarea></label>`;
}
// Activa los botones de evidencia de un formulario; las fotos nuevas quedan en form._docs
function montarEvidencias(form, actual = {}) {
  form._docs = {};
  for (const tipo of ['estudiante', 'vecino']) {
    const chk = form.querySelector(`[name=${tipo}]`), box = form.querySelector(`[data-evi=${tipo}]`);
    chk.addEventListener('change', () => box.classList.toggle('oculto', !chk.checked));
    const poner = (url) => {
      form._docs[tipo] = url;
      const img = box.querySelector('.evi-img'); img.src = url; img.classList.remove('oculto');
      box.querySelector('.evi-estado').innerHTML = '<small class="verde">✅ Foto lista (se guarda al presionar Guardar)</small>';
    };
    box.querySelector(`[data-cam=${tipo}]`).onclick = () => modalCamara(poner, { documento: true, titulo: EVIDENCIA[tipo].titulo, texto: EVIDENCIA[tipo].ayuda });
    box.querySelector(`[data-arch=${tipo}]`).onchange = async (e) => { const f = e.target.files[0]; if (f) intentar(async () => poner(await jpgDesdeArchivo(f, true))); };
    box.querySelector('.evi-img').onclick = (e) => verImagen(e.target.src, EVIDENCIA[tipo].titulo);
  }
  form._datos = () => {
    const d = valores(form);
    for (const tipo of ['estudiante', 'vecino']) {
      if (d[tipo] && !form._docs[tipo] && !actual[`doc_${tipo}`]) throw new Error(`Falta la foto de: ${EVIDENCIA[tipo].titulo}` + (d.nombre ? ` (${d.nombre})` : ''));
      if (form._docs[tipo]) d[`doc_${tipo}`] = form._docs[tipo];
    }
    return d;
  };
}
function verImagen(src, titulo) {
  modal(`<h2>${esc(titulo)}</h2><img src="${src}" style="width:100%;border-radius:8px" alt=""><div class="modal-pie"><button class="btn primario" data-cerrar>Cerrar</button></div>`, { ancho: true });
}
async function formCliente(v) {
  v.innerHTML = `<div class="encabezado"><h1>Nuevo cliente</h1></div>
    <form id="f" style="max-width:820px" class="rejilla">
      <div class="panel"><div class="fila" style="gap:18px">
        <label class="chk" style="font-size:16px"><input type="checkbox" id="esPareja"> 💑 Inscripción en pareja (registrar a las dos personas)</label></div></div>
      <div class="panel"><h2 id="t1">Datos del cliente</h2><div class="form" id="p1">${htmlFormCliente()}</div></div>
      <div class="panel oculto" id="panel2"><div class="encabezado" style="margin-bottom:10px"><h2 style="margin:0;margin-right:auto">Segunda persona (pareja)</h2>
        <button type="button" class="btn chico" id="copiarDir">Copiar dirección de la primera persona</button></div>
        <div class="form" id="p2">${htmlFormCliente({}, { autofocus: false })}</div></div>
      <div class="fila"><button class="btn primario grande">Guardar y registrar rostro →</button><a class="btn" href="#/clientes">Cancelar</a></div>
    </form>`;
  // cada persona es un "sub-formulario" con sus propias evidencias
  const p1 = $('#p1'), p2 = $('#p2');
  [p1, p2].forEach((p) => { p.elements = p.querySelectorAll('input,textarea,select'); montarEvidencias(p); });
  p2.querySelector('[name=nombre]').required = false;
  $('#esPareja').onchange = (e) => {
    $('#panel2').classList.toggle('oculto', !e.target.checked);
    $('#t1').textContent = e.target.checked ? 'Primera persona' : 'Datos del cliente';
    p2.querySelector('[name=nombre]').required = e.target.checked;
    if (e.target.checked) p2.querySelector('[name=nombre]').focus();
  };
  $('#copiarDir').onclick = () => ['direccion', 'colonia', 'cp'].forEach((k) => { p2.querySelector(`[name=${k}]`).value = p1.querySelector(`[name=${k}]`).value; });
  api('/api/licencia/estado').then((l) => { if (l.maxClientes && l.clientes >= l.maxClientes) v.insertAdjacentHTML('afterbegin', `<div class="aviso rojo" style="margin-bottom:12px">⚠️ Ya tiene <b>${l.clientes.toLocaleString('es-MX')}</b> clientes, el máximo que permite su licencia. Para registrar más, pida a Maxsel una licencia más grande (Configuración → Licencia) o elimine clientes que ya no vienen.</div>`); }).catch(() => {});
  $('#f').onsubmit = (e) => {
    e.preventDefault();
    intentar(async () => {
      const d = p1._datos();
      if ($('#esPareja').checked) d.pareja = p2._datos();
      const r = await api('/api/clientes', d);
      toast(r.pareja_id ? 'Se registraron las dos personas. Ahora registra el rostro de cada una.' : 'Cliente guardado', 'ok');
      location.hash = `#/cliente/${r.id}`;
    }, $('#f button.primario.grande'));
  };
}

VISTAS.cliente = async (v, id) => {
  const c = await api('/api/clientes/' + id);
  const real = estado.config.hik_modo === 'real';
  const syncTxt = !c.foto ? '<div class="aviso">Falta registrar el rostro para que pueda entrar con el lector.</div>'
    : c.sincronizado && c.cara_sync ? `<div class="aviso verde">✅ ${real ? 'Registrado en el lector facial' : 'Listo (modo simulador)'}</div>`
    : `<div class="aviso rojo">⚠️ No se ha enviado al lector${c.sync_error ? ': ' + esc(c.sync_error) : ''}</div>`;
  const edita = puede('clientes_editar');
  v.innerHTML = `<div class="encabezado"><a class="btn" href="#/clientes">←</a><h1>${esc(c.nombre)} <small class="muted">#${c.id}</small></h1>
    ${c.estudiante ? '<span class="etq azul">🎓 Estudiante</span>' : ''}${c.vecino ? '<span class="etq azul">🏠 Vecino</span>' : ''}${etqEstado(c.estado)}</div>
  ${c.importado ? '<div class="aviso azul">Este cliente se importó del lector facial y conserva el acceso que ya tenía ahí. Cuando le cobres una membresía o guardes cambios, su acceso pasa a controlarse con las membresías del sistema.</div>' : ''}
  <div class="ficha">
    <div class="rejilla">
      <div class="panel">
        ${c.foto_url ? `<img class="foto-grande" src="${c.foto_url}" alt="Rostro">` : `<div class="foto-grande">${iniciales(c.nombre)}</div>`}
        <div class="rejilla" style="margin-top:12px;gap:8px">
          <button class="btn primario" id="bCam">📷 Tomar foto con cámara</button>
          ${real ? '<button class="btn azul" id="bLector">🙂 Capturar en el lector facial</button>' : ''}
          <label class="btn" style="color:var(--texto)">📁 Subir foto<input type="file" accept="image/*" id="bArchivo" hidden></label>
        </div>
        <div style="margin-top:12px">${syncTxt}</div>
        ${c.foto || c.sync_error ? '<button class="btn bloque" id="bSync">🔄 Enviar al lector otra vez</button>' : ''}
      </div>
      <div class="panel rejilla" style="gap:8px">
        <div><small class="muted">Membresía</small><br><b>${esc(c.plan || 'Sin membresía')}</b>${c.vence ? `<br>Vence: <b>${fecha(c.vence)}</b>${c.dias_restantes >= 0 ? ` (${c.dias_restantes} días)` : ''}` : ''}</div>
        ${puede('pos') ? '<button class="btn primario grande" id="bVender">🏷️ Vender / renovar membresía</button>' : ''}
        ${c.saldo > 0 && puede('abonos') ? `<button class="btn" id="bAbonar">💵 Abonar (debe ${dinero(c.saldo)})</button>` : ''}
        ${!real ? '<button class="btn" id="bSim">🧪 Simular que llega al lector</button>' : ''}
        ${puede('puerta') ? '<button class="btn" id="bPuerta">🙋 Dar entrada manual</button>' : ''}
        ${telWa(c) ? `<a class="btn wa" target="_blank" rel="noopener" href="${linkWa(c, '')}">💬 WhatsApp</a>` : ''}
        ${puede('clientes_bloquear') ? `<button class="btn" id="bBloq">${c.bloqueado ? '✅ Desbloquear acceso' : '⛔ Bloquear acceso'}</button>` : ''}
        ${puede('clientes_borrar') ? '<button class="btn" id="bBorrar" style="color:var(--rojo)">Eliminar cliente</button>' : ''}
      </div>
      <div class="panel"><h2>💑 Pareja</h2>
        ${c.pareja_id ? `<p style="margin:0 0 8px"><a href="#/cliente/${c.pareja_id}"><b>${esc(c.pareja_nombre)}</b></a></p>` : '<p class="muted" style="margin:0 0 8px">Sin pareja vinculada</p>'}
        ${edita ? `<div id="selPareja"></div>${c.pareja_id ? '<button class="btn chico" id="bQuitarPareja" style="margin-top:8px">Quitar pareja</button>' : ''}` : ''}
      </div>
    </div>
    <div class="rejilla">
      <div class="panel"><h2>Datos del cliente</h2><form class="form" id="f">${htmlFormCliente(c, { autofocus: false })}${edita ? '<div class="todo"><button class="btn primario">Guardar cambios</button></div>' : ''}</form></div>
      ${c.deudas.length ? `<div class="panel"><h2>Productos que debe</h2><table><tr><th>Fecha</th><th>Hora</th><th>Productos</th><th class="num">Pendiente</th></tr>
        ${c.deudas.map((d) => `<tr><td>${fecha(d.fecha)}</td><td>${hora(d.fecha)}</td><td>${esc(d.productos)}</td><td class="num rojo">${dinero(d.pendiente)}</td></tr>`).join('')}
        <tr><th colspan="3">Total</th><th class="num">${dinero(c.saldo)}</th></tr></table></div>` : ''}
      <div class="panel"><h2>Membresías</h2><div class="tabla-scroll"><table><tr><th>Plan</th><th>Promoción</th><th>Del</th><th>Al</th><th class="num">Precio</th></tr>
        ${c.membresias.map((m) => `<tr style="${m.cancelada ? 'text-decoration:line-through;opacity:.5' : ''}"><td>${esc(m.plan)}</td><td>${esc(m.promo || '—')}${m.pareja ? `<br><small class="muted">con ${esc(m.pareja)}</small>` : ''}</td><td>${fecha(m.inicio)}</td><td>${fecha(m.fin)}</td><td class="num">${dinero(m.precio)}</td></tr>`).join('') || '<tr><td colspan="5" class="vacio">Sin membresías</td></tr>'}</table></div></div>
      <div class="panel"><h2>Últimas visitas</h2><table><tr><th>Fecha</th><th>Hora</th><th>Resultado</th><th>Detalle</th></tr>
        ${c.visitas.map((x) => `<tr><td>${fecha(x.fecha)}</td><td>${hora(x.fecha)}</td><td><span class="etq ${x.resultado}">${x.resultado === 'permitido' ? 'Entró' : 'Negado'}</span></td><td class="muted">${esc(x.motivo || x.origen)}</td></tr>`).join('') || '<tr><td colspan="4" class="vacio">Sin visitas</td></tr>'}</table></div>
    </div>
  </div>`;
  const form = $('#f');
  montarEvidencias(form, c);
  if (!edita) $$('input,textarea,button', form).forEach((el) => { if (!el.classList.contains('evi-img')) el.disabled = true; });
  form.onsubmit = (e) => { e.preventDefault(); intentar(async () => { const r = await api('/api/clientes/' + id, form._datos(), 'PUT'); toast(r?.ok === false ? 'Guardado, pero no se pudo enviar al lector: ' + r.error : 'Cambios guardados', r?.ok === false ? 'error' : 'ok'); enrutar(); }, $('button.primario', form)); };
  if ($('#selPareja')) selectorCliente($('#selPareja'), { placeholder: c.pareja_id ? 'Cambiar pareja…' : 'Buscar y vincular a su pareja…', alElegir: (p) => {
    if (!p) return;
    intentar(async () => { await api('/api/clientes/' + id, { ...datosBase(c), pareja_id: p.id }, 'PUT'); toast(`Pareja vinculada: ${p.nombre}`, 'ok'); enrutar(); });
  } });
  $('#bQuitarPareja') && ($('#bQuitarPareja').onclick = (e) => intentar(async () => { await api('/api/clientes/' + id, { ...datosBase(c), pareja_id: null }, 'PUT'); enrutar(); }, e.target));
  const subirFoto = async (dataUrl) => {
    const r = await api(`/api/clientes/${id}/foto`, { imagen: dataUrl });
    toast(r.ok ? 'Rostro registrado ✅' : 'Foto guardada, pero el lector respondió: ' + r.error, r.ok ? 'ok' : 'error');
    enrutar();
  };
  $('#bCam').onclick = () => modalCamara((url) => intentar(() => subirFoto(url)));
  $('#bArchivo').onchange = async (e) => { const f = e.target.files[0]; if (f) intentar(async () => subirFoto(await jpgDesdeArchivo(f))); };
  $('#bLector') && ($('#bLector').onclick = (e) => {
    const m = modal('<div style="text-align:center"><div style="font-size:54px">🙂</div><h2>Párate frente al lector</h2><p>Pide al cliente que mire de frente a la pantalla del lector facial hasta que tome la foto.</p></div>');
    intentar(async () => {
      const r = await api(`/api/clientes/${id}/capturar`, {});
      m.cerrar();
      // la foto del lector se ajusta al tamaño que acepta (JPG < 190 KB) antes de guardarla
      const img = await new Promise((ok, mal) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => mal(new Error('La foto del lector no se pudo leer')); i.src = r.imagen; });
      await subirFoto(jpgDesdeCanvas(img, img.naturalWidth, img.naturalHeight));
    }, e.target).finally(() => m.cerrar());
  });
  $('#bSync') && ($('#bSync').onclick = (e) => intentar(async () => { const r = await api(`/api/clientes/${id}/sincronizar`, {}); toast(r.ok ? 'Enviado al lector ✅' : r.error, r.ok ? 'ok' : 'error'); enrutar(); }, e.target));
  $('#bVender') && ($('#bVender').onclick = () => { estado.membresiaPara = c; location.hash = '#/pos'; });
  $('#bAbonar') && ($('#bAbonar').onclick = async () => { estado.turno = await api('/api/turno'); modalAbono(c); });
  $('#bSim') && ($('#bSim').onclick = (e) => intentar(async () => { const r = await api(`/api/clientes/${id}/simular-entrada`, {}); toast(r.resultado === 'permitido' ? 'Acceso permitido (simulado). Mira la pantalla de acceso.' : 'Acceso NEGADO: ' + r.motivo, r.resultado === 'permitido' ? 'ok' : 'error'); }, e.target));
  $('#bPuerta') && ($('#bPuerta').onclick = () => modalEntradaManual(c.id));
  $('#bBloq') && ($('#bBloq').onclick = (e) => intentar(async () => { await api('/api/clientes/' + id, { ...datosBase(c), bloqueado: !c.bloqueado }, 'PUT'); enrutar(); }, e.target));
  $('#bBorrar') && ($('#bBorrar').onclick = async () => {
    if (!await confirmar(`Se eliminará a ${esc(c.nombre)} del sistema y del lector facial.`, 'Eliminar')) return;
    intentar(async () => { await api('/api/clientes/' + id, {}, 'DELETE'); toast('Cliente eliminado', 'ok'); location.hash = '#/clientes'; });
  });
};

// ---------- Fotos ----------
// Rostro: JPG de máx. 640 px y menos de 190 KB (requisito del lector). Documento: hasta 1400 px y ~900 KB.
function jpgDesdeCanvas(origen, w, h, documento = false) {
  const max = documento ? 1400 : 640, limite = (documento ? 900 : 190) * 1024;
  const esc2 = Math.min(1, max / Math.max(w, h));
  const c = document.createElement('canvas');
  c.width = Math.round(w * esc2); c.height = Math.round(h * esc2);
  c.getContext('2d').drawImage(origen, 0, 0, c.width, c.height);
  let q = documento ? 0.85 : 0.9, url = c.toDataURL('image/jpeg', q);
  while (url.length * 0.75 > limite && q > 0.3) { q -= 0.1; url = c.toDataURL('image/jpeg', q); }
  return url;
}
// Logo: conserva PNG (transparencia); reduce a máx. "max" px por lado
function redimensionar(f, max = 900, q = 0.92) {
  return new Promise((ok, mal) => {
    const img = new Image();
    img.onload = () => {
      const esc2 = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
      const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * esc2); c.height = Math.round(img.naturalHeight * esc2);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(img.src);
      ok(f.type === 'image/png' ? c.toDataURL('image/png') : c.toDataURL('image/jpeg', q));
    };
    img.onerror = () => mal(new Error('No se pudo leer la imagen'));
    img.src = URL.createObjectURL(f);
  });
}
function jpgDesdeArchivo(f, documento = false) {
  return new Promise((ok, mal) => {
    const img = new Image();
    img.onload = () => { ok(jpgDesdeCanvas(img, img.naturalWidth, img.naturalHeight, documento)); URL.revokeObjectURL(img.src); };
    img.onerror = () => mal(new Error('No se pudo leer la imagen'));
    img.src = URL.createObjectURL(f);
  });
}
async function modalCamara(alTomar, { documento = false, titulo = 'Foto del rostro', texto } = {}) {
  if (!navigator.mediaDevices?.getUserMedia) return toast('Este navegador no permite usar la cámara aquí. Abre el sistema en la computadora que tiene la cámara (http://localhost:3030), o sube una foto.', 'error');
  let stream;
  texto = texto || 'De frente, con buena luz, sin gorra ni lentes oscuros. Que la cara quede dentro del óvalo.';
  const m = modal(`<h2>${esc(titulo)}</h2><p class="muted">${esc(texto)}${documento ? ' Acerca la credencial a la cámara hasta que llene el recuadro y se lea bien.' : ''}</p>
    <div class="${documento ? 'guia-doc' : 'guia-cara'}"><video class="camara ${documento ? 'sin-espejo' : ''}" autoplay playsinline muted></video></div>
    <div class="modal-pie"><select id="cams" style="max-width:240px"></select><button class="btn" data-cerrar>Cancelar</button><button class="btn primario grande" id="tomar">📸 Tomar foto</button></div>`,
  { alCerrar: () => stream?.getTracks().forEach((t) => t.stop()) });
  const video = $('video', m);
  const abrir = async (deviceId) => {
    stream?.getTracks().forEach((t) => t.stop());
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: deviceId ? { deviceId: { exact: deviceId } } : { width: { ideal: 1920 }, height: { ideal: 1080 } } });
      video.srcObject = stream;
    } catch (e) { toast('No se pudo abrir la cámara: ' + e.message, 'error'); m.cerrar(); }
  };
  await abrir();
  const cams = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === 'videoinput');
  $('#cams', m).innerHTML = cams.map((c, i) => `<option value="${c.deviceId}">${esc(c.label || 'Cámara ' + (i + 1))}</option>`).join('');
  $('#cams', m).onchange = (e) => abrir(e.target.value);
  $('#tomar', m).onclick = () => {
    const vw = video.videoWidth, vh = video.videoHeight;
    let url;
    if (documento) url = jpgDesdeCanvas(video, vw, vh, true);
    else {
      // recorte vertical 3:4 al centro, como pide el lector
      const w = Math.min(vw, vh * 0.75), h = w / 0.75;
      const c = document.createElement('canvas'); c.width = w; c.height = h;
      c.getContext('2d').drawImage(video, (vw - w) / 2, (vh - h) / 2, w, h, 0, 0, w, h);
      url = jpgDesdeCanvas(c, w, h);
    }
    m.cerrar(); alTomar(url);
  };
}

// ===================== Entrada manual (F9) =====================
// Para cuando el lector no reconoce la cara o no funciona: se busca al cliente y se le da acceso.
function modalEntradaManual(clienteId = null) {
  if (!puede('puerta')) return;
  if ($('.fondo-modal [data-entrada-manual]')) return;
  const m = modal(`<div data-entrada-manual><h2>🙋 Entrada manual</h2>
    <p class="muted" style="margin-top:-6px">Si el lector no reconoce la cara o no funciona: busque al cliente y presione <b>Dar acceso</b>.</p>
    <input id="emQ" placeholder="Nombre, teléfono o número de socio" autocomplete="off" style="font-size:20px" ${clienteId ? '' : 'autofocus'}>
    <div id="emLista" class="em-lista"></div>
    <label class="em-chk"><input type="checkbox" id="emAbrir" checked> Abrir la puerta del lector</label>
    <div class="modal-pie"><button class="btn" data-cerrar>Cerrar (Esc)</button></div></div>`, { ancho: true, escSiempre: true });
  const q = $('#emQ', m), lista = $('#emLista', m);
  let filas = [], t = null, sel = 0;
  const pintar = () => {
    if (!q.value.trim() && !filas.length) { lista.innerHTML = '<p class="muted em-vacio">Escriba para buscar…</p>'; return; }
    lista.innerHTML = filas.map((c, i) => `<div class="em-fila ${i === sel ? 'sel' : ''} ${c.puede_entrar ? 'ok' : 'no'}" data-i="${i}">
      ${c.foto ? `<img src="${c.foto}" alt="">` : '<div class="em-sinfoto">👤</div>'}
      <div class="em-info"><b>${esc(c.nombre)}</b> <small class="muted">#${c.id}${c.telefono ? ' · ' + esc(c.telefono) : ''}</small><br>
        <span class="etq ${c.estado}">${ESTADOS[c.estado] || c.estado}</span> <small>${esc(c.mensaje)}</small>
        ${c.saldo > 0 ? `<br><small class="rojo">Debe ${dinero(c.saldo)}</small>` : ''}${c.ultima_visita ? `<br><small class="muted">Última entrada: ${fechaHora(c.ultima_visita)}</small>` : ''}</div>
      <div class="em-acc">${c.puede_entrar ? `<button class="btn primario grande" data-acc="${i}">✅ Dar acceso</button>`
        : `${puede('pos') ? `<button class="btn" data-vender="${c.id}">🏷️ Renovar</button>` : ''}${puede('puerta_forzar') ? `<button class="btn" data-forzar="${i}" style="color:var(--rojo)">Dejar pasar…</button>` : '<small class="muted">Pase a recepción</small>'}`}</div>
    </div>`).join('') || '<p class="muted em-vacio">No se encontró ningún cliente</p>';
    $$('[data-acc]', lista).forEach((b) => b.onclick = () => dar(filas[b.dataset.acc], '', b));
    $$('[data-forzar]', lista).forEach((b) => b.onclick = () => forzar(filas[b.dataset.forzar]));
    $$('[data-vender]', lista).forEach((b) => b.onclick = () => { m.cerrar(); location.hash = '#/cliente/' + b.dataset.vender; });
  };
  const buscar = async (texto) => { filas = await api('/api/acceso/buscar?q=' + encodeURIComponent(texto)); sel = 0; pintar(); };
  const dar = (c, motivo, btn) => intentar(async () => {
    const r = await api('/api/acceso/manual', { cliente_id: c.id, motivo, abrir: $('#emAbrir', m).checked });
    m.cerrar();
    toast(`✅ ${r.nombre}: entrada registrada${r.puerta === 'abierta' ? ' y puerta abierta' : r.puerta === 'simulada' ? ' (modo prueba, sin lector)' : ''}`, 'ok');
    if (location.hash.startsWith('#/accesos')) enrutar();
  }, btn);
  const forzar = (c) => {
    const f = modal(`<h2>Dejar pasar sin membresía vigente</h2><p><b>${esc(c.nombre)}</b><br><span class="etq ${c.estado}">${ESTADOS[c.estado] || c.estado}</span> ${esc(c.mensaje)}</p>
      <form id="ff"><label>Motivo (queda registrado con su nombre)<input name="motivo" required maxlength="200" placeholder="Ej. pagará mañana, autorizado por el dueño…" autofocus></label>
      <div class="modal-pie"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn peligro">Dejar pasar</button></div></form>`);
    $('#ff', f).onsubmit = (e) => { e.preventDefault(); f.cerrar(); dar(c, valores(e.target).motivo, null); };
  };
  q.addEventListener('input', () => { clearTimeout(t); const v = q.value.trim(); if (!v) { filas = []; pintar(); return; } t = setTimeout(() => buscar(v), 180); });
  q.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (!filas.length) return; sel = (sel + (e.key === 'ArrowDown' ? 1 : -1) + filas.length) % filas.length; pintar(); }
    if (e.key === 'Enter') { e.preventDefault(); const c = filas[sel]; if (!c) return; if (c.puede_entrar) dar(c, '', null); else if (puede('puerta_forzar')) forzar(c); else toast(c.mensaje, 'error'); }
  });
  pintar();
  if (clienteId) { q.value = String(clienteId); buscar(String(clienteId)); setTimeout(() => q.select(), 40); }
}
document.addEventListener('keydown', (e) => {
  if (e.key !== 'F9' || $('#app').classList.contains('oculto') || window.ventanaCobroAbierta?.()) return;
  e.preventDefault(); e.stopPropagation(); modalEntradaManual();
}, true);
$('#bEntradaManual').addEventListener('click', () => modalEntradaManual());

// ===================== Accesos =====================
VISTAS.accesos = async (v) => {
  const real = estado.config.hik_modo === 'real';
  v.innerHTML = `<div class="encabezado"><h1>Accesos</h1><input type="date" id="dia" value="${hoyStr()}" style="width:auto">
    ${puede('puerta') ? '<button class="btn primario" id="bManual">🙋 Entrada manual (F9)</button><button class="btn" id="bAbrir">🚪 Abrir puerta sin cliente</button>' : ''}${!real ? '<button class="btn" id="bDesc">🧪 Simular rostro desconocido</button>' : ''}</div>
    <div id="lec"></div><div class="panel"><div class="tabla-scroll" id="tabla"></div></div>`;
  const cargar = async () => {
    const [lista, lec] = await Promise.all([api('/api/visitas?fecha=' + $('#dia').value), api('/api/lector/estado')]);
    $('#lec').innerHTML = `<p>${estadoLectorHtml(lec)}</p>`;
    $('#tabla').innerHTML = `<table><tr><th>Hora</th><th>Cliente</th><th>Resultado</th><th>Origen</th><th>Detalle</th></tr>
      ${lista.map((x) => `<tr ${x.cliente_id ? `class="click" data-id="${x.cliente_id}"` : ''}><td>${hora(x.fecha)}</td><td><b>${esc(x.nombre || '—')}</b></td><td><span class="etq ${x.resultado}">${x.resultado === 'permitido' ? 'Entró' : 'Negado'}</span></td><td>${esc(x.origen)}</td><td class="muted">${esc(x.motivo || '')}</td></tr>`).join('') || '<tr><td colspan="5" class="vacio">Sin accesos este día</td></tr>'}</table>`;
    $$('tr[data-id]', v).forEach((tr) => tr.onclick = () => location.hash = '#/cliente/' + tr.dataset.id);
  };
  $('#dia').onchange = cargar;
  $('#bManual') && ($('#bManual').onclick = () => modalEntradaManual());
  $('#bAbrir') && ($('#bAbrir').onclick = () => {
    const m = modal(`<h2>Abrir puerta</h2><form id="f"><label>Motivo (opcional)<input name="motivo" placeholder="Ej. proveedor, cliente olvidó..." autofocus></label>
      <div class="modal-pie"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Abrir</button></div></form>`);
    $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => { await api('/api/puerta/abrir', valores(e.target)); m.cerrar(); toast('Puerta abierta', 'ok'); cargar(); }); };
  });
  $('#bDesc') && ($('#bDesc').onclick = () => api('/api/simular-desconocido', {}));
  const es = new EventSource('/api/pantalla/stream');
  // se recarga como máximo cada 3 segundos, aunque entren muchas personas seguidas
  let pendiente = null, cargando = false;
  const recargar = () => {
    if (pendiente || $('#dia').value !== hoyStr()) return;
    pendiente = setTimeout(async () => { pendiente = null; if (cargando) return recargar(); cargando = true; try { await cargar(); } finally { cargando = false; } }, 3000);
  };
  es.onmessage = (ev) => { try { const d = JSON.parse(ev.data); if (d.tipo === 'acceso' || d.tipo === 'desconocido') recargar(); } catch { /* ignorar */ } };
  limpiarVista = () => { es.close(); clearTimeout(pendiente); };
  cargar();
};

// ===================== Cuentas por cobrar =====================
VISTAS.adeudos = async (v) => {
  const lista = await api('/api/adeudos');
  const total = lista.reduce((s, c) => s + c.saldo, 0);
  v.innerHTML = `<div class="encabezado"><h1>Cuentas por cobrar</h1><b style="font-size:20px">Total: ${dinero(total)}</b></div>
    <div class="panel"><table><tr><th>Cliente</th><th>Teléfono</th><th>Debe desde</th><th class="num">Ventas</th><th class="num">Saldo</th><th></th></tr>
    ${lista.map((c) => `<tr><td><a href="#/cliente/${c.id}"><b>${esc(c.nombre)}</b></a></td><td>${esc(c.whatsapp || c.telefono || '')}</td><td>${fechaHora(c.desde)}</td><td class="num">${c.ventas}</td>
      <td class="num rojo"><b>${dinero(c.saldo)}</b></td><td class="fila"><button class="btn chico primario" data-a="${c.id}">Abonar</button>
      ${telWa(c) ? `<a class="btn chico wa" target="_blank" rel="noopener" href="${linkWa(c, `Hola ${c.nombre.split(' ')[0]}, te recordamos que tienes un saldo pendiente de ${dinero(c.saldo)} en ${estado.config.gym_nombre}. ¡Gracias!`)}">WhatsApp</a>` : ''}</td></tr>`).join('') || '<tr><td colspan="6" class="vacio">Nadie debe nada 🎉</td></tr>'}</table></div>`;
  $$('[data-a]', v).forEach((b) => b.onclick = async () => { estado.turno = await api('/api/turno'); const c = lista.find((x) => x.id == b.dataset.a); modalAbono({ ...c, estado: null }); });
};

// ===================== Avisos WhatsApp =====================
// ===================== Avisos por WhatsApp =====================
const TIPOS_AVISO = {
  vence: { icono: '⏰', titulo: 'Por vencer', desc: 'Su membresía vence pronto', clave: 'wa_vence' },
  vencido: { icono: '❌', titulo: 'Ya vencidos', desc: 'Vencieron en los últimos 30 días', clave: 'wa_vencida' },
  publicidad: { icono: '📣', titulo: 'Publicidad', desc: 'Promociones a quien aceptó recibirlas', clave: 'wa_publicidad' },
};
const preferenciaWa = () => { try { return localStorage.getItem('maxsel_wa') || 'web'; } catch { return 'web'; } };
function linkWaModo(c, msg) {
  const tel = telWa(c), t = encodeURIComponent(msg);
  return preferenciaWa() === 'app' ? `whatsapp://send?phone=${tel}&text=${t}` : `https://wa.me/${tel}?text=${t}`;
}
// Copia la imagen de publicidad para pegarla (Ctrl+V) en el chat de WhatsApp
async function copiarImagenPublicidad(blobPng) {
  if (!blobPng || !navigator.clipboard?.write || typeof ClipboardItem === 'undefined') return false;
  try { await navigator.clipboard.write([new ClipboardItem({ 'image/png': blobPng })]); return true; } catch { return false; }
}
async function imagenPublicidadPng() {
  const src = estado.config.wa_imagen; if (!src) return null;
  const img = await new Promise((ok, mal) => { const i = new Image(); i.onload = () => ok(i); i.onerror = mal; i.src = '/publicidad-img?' + (String(src).split('?')[1] || ''); });
  const c = document.createElement('canvas'); c.width = img.naturalWidth; c.height = img.naturalHeight; c.getContext('2d').drawImage(img, 0, 0);
  return new Promise((ok) => c.toBlob(ok, 'image/png'));
}

VISTAS.avisos = async (v) => {
  let tipo = estado.tipoAviso || 'vence';
  const listas = {}, sel = new Set();
  v.innerHTML = `<div class="encabezado"><h1>Avisos por WhatsApp</h1>
      <label class="fila" style="margin-left:auto">Abrir con <select id="modoWa" style="width:auto"><option value="web">WhatsApp Web (navegador)</option><option value="app">App de WhatsApp de la computadora</option></select></label></div>
    <div class="rejilla cols-3" id="tarjetas"></div>
    <div class="rejilla cols-2" style="margin-top:16px;align-items:start">
      <div class="panel" id="panelMsg"></div>
      <div class="panel" id="panelLista"></div>
    </div>`;
  $('#modoWa').value = preferenciaWa();
  $('#modoWa').onchange = () => { try { localStorage.setItem('maxsel_wa', $('#modoWa').value); } catch { /* sin almacenamiento */ } pintarLista(); };

  const pedir = (t) => api(`/api/avisos?tipo=${t}&dias=${t === 'vencido' ? 30 : $('#dias')?.value || 5}`);
  const pintarTarjetas = () => {
    $('#tarjetas').innerHTML = Object.entries(TIPOS_AVISO).map(([k, t]) => `<button class="tarjeta-aviso ${k === tipo ? 'sel' : ''}" data-t="${k}">
      <span class="ico">${t.icono}</span><span><b>${t.titulo}</b><small>${t.desc}</small></span><strong>${listas[k] ? listas[k].length : '…'}</strong></button>`).join('');
    $$('[data-t]', v).forEach((b) => b.onclick = () => { tipo = b.dataset.t; estado.tipoAviso = tipo; sel.clear(); pintarTarjetas(); pintarMensaje(); pintarLista(); });
  };

  const pintarMensaje = () => {
    const t = TIPOS_AVISO[tipo], img = estado.config.wa_imagen;
    $('#panelMsg').innerHTML = `<h2>✏️ Mensaje: ${t.titulo}</h2>
      <textarea id="msg" rows="5" maxlength="1500">${esc(estado.config[t.clave] || '')}</textarea>
      <div class="fila" style="margin:8px 0;flex-wrap:wrap;gap:6px"><small class="muted">Insertar:</small>
        ${[['{nombre}', 'Nombre'], ['{fecha}', 'Fecha de vencimiento'], ['{gimnasio}', 'Gimnasio']].map(([c, n]) => `<button type="button" class="btn chico" data-ins="${c}">${n}</button>`).join('')}
        <button type="button" class="btn chico primario" id="guardarMsg" style="margin-left:auto">💾 Guardar mensaje</button></div>
      <div class="vista-wa"><small class="muted">Así lo recibe el cliente:</small><div class="burbuja" id="vistaMsg"></div></div>
      ${tipo === 'publicidad' ? `<h3 style="margin-top:16px">🖼️ Imagen de la promoción</h3>
        <div class="fila" style="align-items:flex-start;gap:14px">
          <div id="imgPub" class="img-pub">${img ? `<img src="/publicidad-img?${esc(String(img).split('?')[1] || '')}" alt="">` : '<span class="muted">Sin imagen</span>'}</div>
          <div style="display:grid;gap:8px"><label class="btn" style="cursor:pointer">📁 ${img ? 'Cambiar imagen' : 'Agregar imagen'}<input type="file" id="archImg" accept="image/*" style="display:none"></label>
            ${img ? '<button type="button" class="btn" id="quitarImg">Quitar imagen</button>' : ''}</div></div>
        <p class="muted" style="margin:10px 0 0"><small>WhatsApp no deja adjuntar imágenes automáticamente desde un enlace. Al enviar, el sistema <b>copia la imagen</b>: en el chat que se abre solo presiona <kbd>Ctrl</kbd> + <kbd>V</kbd> para pegarla y luego Enviar.</small></p>
        <div class="aviso azul" style="margin-top:12px"><b>¿Muchos clientes a la vez?</b> Usa una <b>lista de difusión</b> de WhatsApp: descarga los contactos, impórtalos en el celular del gimnasio y crea la lista. Así mandas la imagen y el texto a todos con un solo envío.
          <div style="margin-top:8px"><button type="button" class="btn chico" id="bVcf">📇 Descargar contactos (${(listas.publicidad || []).length})</button> <a href="#" id="bAyudaDif" style="margin-left:8px">¿Cómo se hace?</a></div></div>` : ''}`;
    const actualizarVista = () => { $('#vistaMsg').textContent = mensajeWa($('#msg').value, { nombre: 'Ana López', fin: sumarDiasStr(hoyStr(), tipo === 'vencido' ? -3 : 4) }); };
    $('#msg').addEventListener('input', actualizarVista); actualizarVista();
    $$('[data-ins]', v).forEach((b) => b.onclick = () => { const ta = $('#msg'), p = ta.selectionStart; ta.value = ta.value.slice(0, p) + b.dataset.ins + ta.value.slice(ta.selectionEnd); ta.focus(); ta.selectionStart = ta.selectionEnd = p + b.dataset.ins.length; actualizarVista(); });
    $('#guardarMsg').onclick = (e) => intentar(async () => { await api('/api/avisos/mensajes', { [t.clave]: $('#msg').value }, 'PUT'); estado.config[t.clave] = $('#msg').value; toast('Mensaje guardado', 'ok'); pintarLista(); }, e.currentTarget);
    $('#archImg') && ($('#archImg').onchange = () => { const f = $('#archImg').files[0]; if (!f) return; intentar(async () => { const r = await api('/api/avisos/imagen', { imagen: await redimensionar(f, 1280, 0.88) }); estado.config.wa_imagen = r.imagen; toast('Imagen guardada', 'ok'); pintarMensaje(); }); });
    $('#quitarImg') && ($('#quitarImg').onclick = () => intentar(async () => { await api('/api/avisos/imagen', {}, 'DELETE'); estado.config.wa_imagen = ''; pintarMensaje(); }));
    $('#bVcf') && ($('#bVcf').onclick = () => descargarContactos(listas.publicidad || []));
    $('#bAyudaDif') && ($('#bAyudaDif').onclick = (e) => { e.preventDefault(); ayudaDifusion(); });
  };

  const pintarLista = () => {
    const lista = listas[tipo] || [], msgBase = estado.config[TIPOS_AVISO[tipo].clave];
    const yaHoy = (c) => c.ultimo_aviso && c.ultimo_aviso.slice(0, 10) === hoyStr();
    $('#panelLista').innerHTML = `<div class="fila" style="justify-content:space-between;align-items:center;margin-bottom:10px">
        <h2 style="margin:0">👥 ${lista.length} ${lista.length === 1 ? 'cliente' : 'clientes'}</h2>
        ${tipo === 'vence' ? '<label class="fila">Vencen en los próximos <input id="dias" type="number" value="' + ($('#dias')?.value || 5) + '" min="1" max="60" style="width:64px"> días</label>' : ''}</div>
      ${lista.length ? `<div class="fila" style="gap:8px;margin-bottom:8px;flex-wrap:wrap">
        <label class="chk"><input type="checkbox" id="todos"> Seleccionar todos</label>
        <button class="btn" id="selPend">Solo los que no tienen aviso hoy</button>
        <button class="btn primario" id="bEnviarSel" style="margin-left:auto" disabled>📤 Enviar a seleccionados</button></div>` : ''}
      <div class="tabla-scroll" style="max-height:60vh"><table><tr><th></th><th>Cliente</th><th>${tipo === 'publicidad' ? 'Membresía hasta' : tipo === 'vencido' ? 'Venció' : 'Vence'}</th><th>Último aviso</th><th></th></tr>
      ${lista.map((c) => `<tr style="${yaHoy(c) ? 'opacity:.55' : ''}"><td><input type="checkbox" data-sel="${c.id}" ${sel.has(c.id) ? 'checked' : ''}></td>
        <td><a href="#/cliente/${c.id}">${esc(c.nombre)}</a><br><small class="muted">${esc(c.whatsapp || c.telefono)}</small></td><td>${c.fin ? fecha(c.fin) : '—'}</td>
        <td class="muted" data-u="${c.id}">${c.ultimo_aviso ? fechaHora(c.ultimo_aviso) : 'Nunca'}</td>
        <td><a class="btn chico wa" target="whatsapp" rel="noopener" data-id="${c.id}" href="${linkWaModo(c, mensajeWa(msgBase, c))}">💬 Enviar</a></td></tr>`).join('') || '<tr><td colspan="5" class="vacio">No hay clientes en esta lista 🎉</td></tr>'}</table></div>`;
    const contar = () => { const b = $('#bEnviarSel'); if (!b) return; b.disabled = !sel.size; b.textContent = `📤 Enviar a seleccionados (${sel.size})`; if ($('#todos')) $('#todos').checked = sel.size === lista.length && lista.length > 0; };
    $$('[data-sel]', v).forEach((ch) => ch.onchange = () => { const id = Number(ch.dataset.sel); ch.checked ? sel.add(id) : sel.delete(id); contar(); });
    $('#todos') && ($('#todos').onchange = () => { sel.clear(); if ($('#todos').checked) lista.forEach((c) => sel.add(c.id)); pintarLista(); });
    $('#selPend') && ($('#selPend').onclick = () => { sel.clear(); lista.filter((c) => !yaHoy(c)).forEach((c) => sel.add(c.id)); pintarLista(); });
    $('#bEnviarSel') && ($('#bEnviarSel').onclick = () => enviarEnCola(lista.filter((c) => sel.has(c.id)), tipo, async () => { listas[tipo] = await pedir(tipo); sel.clear(); pintarTarjetas(); pintarLista(); }));
    $('#dias') && ($('#dias').onchange = async () => { listas.vence = await pedir('vence'); pintarTarjetas(); pintarLista(); });
    $$('a[data-id]', v).forEach((a) => a.addEventListener('click', async () => {
      if (tipo === 'publicidad' && estado.config.wa_imagen) { const ok = await copiarImagenPublicidad(await imagenPublicidadPng()); if (ok) toast('Imagen copiada: en el chat presiona Ctrl+V para pegarla', 'ok'); }
      api('/api/avisos', { cliente_id: Number(a.dataset.id), tipo }).catch(() => {});
      $(`[data-u="${a.dataset.id}"]`, v).textContent = 'Ahora'; a.closest('tr').style.opacity = 0.55;
    }));
    contar();
  };

  pintarTarjetas();
  const [a, b, c] = await Promise.all(['vence', 'vencido', 'publicidad'].map(pedir));
  Object.assign(listas, { vence: a, vencido: b, publicidad: c });
  pintarTarjetas(); pintarMensaje(); pintarLista();
};

// Envío uno tras otro: cada clic abre el chat del siguiente cliente con el mensaje listo
async function enviarEnCola(lista, tipo, alTerminar) {
  if (!lista.length) return;
  let i = 0, enviados = 0;
  const plantilla = estado.config[TIPOS_AVISO[tipo].clave];
  const conImagen = tipo === 'publicidad' && !!estado.config.wa_imagen;
  const png = conImagen ? await imagenPublicidadPng().catch(() => null) : null;
  const m = modal(`<h2>📤 Enviando avisos por WhatsApp</h2>
    <div class="barra-prog"><i id="prog"></i></div><p class="muted" id="cuenta" style="margin:6px 0 14px"></p>
    <div id="actual"></div>
    <div class="aviso" style="margin-top:12px"><small>WhatsApp no permite que un programa mande mensajes solo, por seguridad. Aquí cada clic abre el chat del siguiente cliente con el mensaje ya escrito${conImagen ? ' y la imagen copiada' : ''}: ${conImagen ? 'pega la imagen con <kbd>Ctrl</kbd>+<kbd>V</kbd>, ' : ''}presiona <b>Enviar</b> en WhatsApp y regresa aquí.</small></div>
    <div class="modal-pie"><button class="btn" id="terminar">Terminar</button></div>`, { ancho: true, alCerrar: () => { if (enviados) toast(`Se abrieron ${enviados} chats de WhatsApp`, 'ok'); alTerminar?.(); } });
  const pintar = () => {
    $('#prog', m).style.width = `${(i / lista.length) * 100}%`;
    $('#cuenta', m).textContent = i < lista.length ? `Cliente ${i + 1} de ${lista.length} · ${enviados} enviados` : `Terminado: ${enviados} de ${lista.length}`;
    if (i >= lista.length) { $('#actual', m).innerHTML = '<div style="text-align:center;font-size:48px">✅</div><p style="text-align:center">Listo, ya se abrieron todos los chats.</p>'; $('#terminar', m).textContent = 'Cerrar'; $('#terminar', m).classList.add('primario'); return; }
    const c = lista[i], msg = mensajeWa(plantilla, c);
    $('#actual', m).innerHTML = `<div class="fila" style="gap:16px;align-items:flex-start">
        ${conImagen ? `<img src="/publicidad-img?${esc(String(estado.config.wa_imagen).split('?')[1] || '')}" style="width:120px;border-radius:10px;border:1px solid var(--borde)">` : ''}
        <div style="flex:1;min-width:0"><b style="font-size:20px">${esc(c.nombre)}</b> <span class="muted">${esc(c.whatsapp || c.telefono)}</span>
          <div class="burbuja" style="margin-top:8px">${esc(msg)}</div></div></div>
      <div class="fila" style="margin-top:14px;gap:8px"><a class="btn grande wa" id="abrir" target="whatsapp" rel="noopener" href="${linkWaModo(c, msg)}">💬 Abrir WhatsApp de ${esc(c.nombre.split(' ')[0])}</a><button class="btn" id="saltar">Saltar →</button></div>`;
    $('#abrir', m).addEventListener('click', async () => {
      if (png) await copiarImagenPublicidad(png);
      api('/api/avisos', { cliente_id: c.id, tipo }).catch(() => {});
      enviados++; i++; setTimeout(pintar, 300);
    });
    $('#saltar', m).onclick = () => { i++; pintar(); };
  };
  $('#terminar', m).onclick = () => m.cerrar();
  pintar();
}

function descargarContactos(lista) {
  if (!lista.length) return toast('No hay clientes que acepten publicidad', 'error');
  const gym = estado.config.gym_nombre || 'Gym';
  const vcf = lista.map((c) => ['BEGIN:VCARD', 'VERSION:3.0', `N:${c.nombre};;;;`, `FN:${c.nombre}`, `ORG:${gym}`, `TEL;TYPE=CELL:+${telWa(c)}`, 'END:VCARD'].join('\r\n')).join('\r\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([vcf], { type: 'text/vcard' })); a.download = `Contactos ${gym}.vcf`;
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  toast(`Se descargaron ${lista.length} contactos`, 'ok');
}
function ayudaDifusion() {
  modal(`<h2>📣 Mandar la promoción a todos con una lista de difusión</h2>
    <ol class="pasos">
      <li>Presiona <b>"Descargar contactos"</b>. Se baja un archivo <b>.vcf</b> con todos los clientes que aceptan publicidad.</li>
      <li>Mándate ese archivo al celular del gimnasio (por WhatsApp a ti mismo o por correo) y ábrelo: el celular pregunta si quieres <b>importar los contactos</b>. Acepta.</li>
      <li>En WhatsApp del celular: <b>⋮ (menú) → Nueva difusión</b> (en iPhone: Chats → Listas de difusión → Nueva lista). Elige a los clientes (hasta 256 por lista).</li>
      <li>Abre la lista, adjunta la <b>imagen</b> de la promoción, pega el <b>texto</b> y envía. Le llega a cada cliente por separado, como mensaje normal.</li></ol>
    <p class="muted"><small>Importante: solo reciben la difusión los clientes que también tengan guardado el número del gimnasio. Por eso conviene pedirles que lo guarden al inscribirse.</small></p>
    <div class="modal-pie"><button class="btn primario" data-cerrar>Entendido</button></div>`, { ancho: true });
}

// ===================== Productos =====================
let prodTab = 'prod', prodDepto = '';
VISTAS.productos = async (v) => {
  const edita = puede('productos_editar');
  v.innerHTML = `<div class="encabezado"><h1>Productos</h1>${edita ? '<button class="btn" id="bImportar">📥 Importar desde Excel</button>' : ''}<button class="btn" id="bExcelInv">⬇ Inventario en Excel</button><button class="btn" id="bPdfInv">📄 Inventario en PDF</button>${edita ? '<button class="btn primario" id="bNuevo">+ Nuevo producto</button>' : ''}</div>
    <div class="pestanas" style="display:flex;gap:6px;margin-bottom:12px"><button class="btn ${prodTab === 'prod' ? 'primario' : ''}" data-tab="prod">📦 Productos</button><button class="btn ${prodTab === 'deptos' ? 'primario' : ''}" data-tab="deptos">🗂️ Departamentos</button></div>
    <div id="pcont"></div>`;
  $$('[data-tab]', v).forEach((b) => b.onclick = () => { prodTab = b.dataset.tab; VISTAS.productos(v); });
  let deps = await api('/api/departamentos');
  const nombresDep = () => deps.lista.map((d) => d.nombre);
  const recargar = async () => { deps = await api('/api/departamentos'); prodTab === 'prod' ? pintarProd() : pintarDeps(); };
  $('#bNuevo') && ($('#bNuevo').onclick = () => modalProducto({ activo: 1, area: prodDepto && prodDepto !== '__sin' ? prodDepto : '' }, recargar, nombresDep()));
  $('#bImportar') && ($('#bImportar').onclick = () => modalImportarProductos(recargar));
  $('#bExcelInv').onclick = (e) => intentar(() => exportarReporte('inventario', hoyStr(), hoyStr()), e.currentTarget);
  $('#bPdfInv').onclick = () => modalInventarioPdf(nombresDep());
  function pintarProd() {
    const chips = deps.lista.length ? `<div class="fila" style="gap:6px;flex-wrap:wrap;margin-bottom:12px"><button class="btn chico ${!prodDepto ? 'primario' : ''}" data-dep="">Todos</button>${deps.lista.map((d) => `<button class="btn chico ${prodDepto === d.nombre ? 'primario' : ''}" data-dep="${esc(d.nombre)}">${esc(d.nombre)} <small>${d.productos}</small></button>`).join('')}${deps.sin.productos ? `<button class="btn chico ${prodDepto === '__sin' ? 'primario' : ''}" data-dep="__sin">Sin departamento <small>${deps.sin.productos}</small></button>` : ''}</div>` : '';
    $('#pcont').innerHTML = `<div class="panel">${chips}<input id="q" placeholder="Buscar por nombre o código de barras" style="max-width:380px;margin-bottom:12px" autofocus><label class="chk" style="display:inline-flex;margin-left:12px"><input type="checkbox" id="todos"> Mostrar desactivados</label><div class="tabla-scroll" id="tabla"></div></div>`;
    $$('[data-dep]', v).forEach((b) => b.onclick = () => { prodDepto = b.dataset.dep; pintarProd(); });
    const cargar = async () => {
      let lista = await api(`/api/productos?q=${encodeURIComponent($('#q').value)}${$('#todos').checked ? '&todos=1' : ''}`);
      if (prodDepto) lista = lista.filter((p) => (prodDepto === '__sin' ? !p.area : p.area === prodDepto));
      $('#tabla').innerHTML = `<table><tr><th>Código</th><th>Producto</th><th>Departamento</th><th class="num">Costo</th><th class="num">Precio venta</th><th class="num">Ganancia</th><th class="num">Existencia</th><th></th></tr>
        ${lista.map((p) => `<tr style="${p.activo ? '' : 'opacity:.5'}"><td class="muted">${esc(p.codigo || '—')}</td><td><b>${esc(p.nombre)}</b></td><td>${p.area ? esc(p.area) : '<span class="muted">—</span>'}</td><td class="num">${dinero(p.costo)}</td><td class="num">${dinero(p.precio)}</td>
          <td class="num">${p.costo ? Math.round(((p.precio - p.costo) / p.precio) * 100) + '%' : '—'}</td><td class="num ${p.existencia <= p.minimo ? 'rojo' : ''}"><b>${p.existencia}</b></td>
          <td class="fila">${edita ? `<button class="btn chico" data-e="${p.id}">Editar</button><button class="btn chico" data-n="${p.id}">+ Entrada</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="8" class="vacio">Sin productos</td></tr>'}</table>`;
      $$('[data-e]', v).forEach((b) => b.onclick = () => modalProducto(lista.find((p) => p.id == b.dataset.e), recargar, nombresDep()));
      $$('[data-n]', v).forEach((b) => b.onclick = () => modalEntrada(lista.find((p) => p.id == b.dataset.n), cargar));
    };
    let t; $('#q').oninput = () => { clearTimeout(t); t = setTimeout(cargar, 200); };
    $('#todos').onchange = cargar;
    cargar();
  }
  function pintarDeps() {
    $('#pcont').innerHTML = `<div class="panel"><div class="fila" style="justify-content:space-between"><p class="muted" style="margin:0">Los departamentos agrupan los productos en el punto de venta (botones de arriba), en el inventario y en los reportes por unidad de negocio. Al eliminar un departamento sus productos NO se borran: quedan "Sin departamento".</p>${edita ? '<button class="btn primario" id="bNDep">+ Nuevo departamento</button>' : ''}</div>
      <div class="tabla-scroll" style="margin-top:12px"><table><tr><th>Departamento</th><th class="num">Productos</th><th class="num">Valor al costo</th><th class="num">Valor a la venta</th><th></th></tr>
      ${deps.lista.map((d, i) => `<tr><td><b>${esc(d.nombre)}</b></td><td class="num">${d.productos}</td><td class="num">${dinero(d.costo)}</td><td class="num">${dinero(d.venta)}</td><td class="fila"><button class="btn chico" data-ver="${i}">Ver productos</button>${edita ? `<button class="btn chico" data-ren="${i}">Renombrar</button><button class="btn chico" data-del="${i}">Eliminar</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="5" class="vacio">No hay departamentos. Crea el primero (Bebidas, Suplementos, Ropa, Accesorios…).</td></tr>'}
      ${deps.sin.productos ? `<tr><td class="muted">Sin departamento</td><td class="num">${deps.sin.productos}</td><td class="num">${dinero(deps.sin.costo)}</td><td class="num">${dinero(deps.sin.venta)}</td><td><button class="btn chico" data-ver="sin">Ver productos</button></td></tr>` : ''}</table></div></div>`;
    $$('[data-ver]', v).forEach((b) => b.onclick = () => { prodDepto = b.dataset.ver === 'sin' ? '__sin' : deps.lista[b.dataset.ver].nombre; prodTab = 'prod'; VISTAS.productos(v); });
    const pedirNombre = (titulo, actual, fn) => {
      const m = modal(`<h2>${titulo}</h2><form class="form" id="f"><label class="todo">Nombre<input name="n" value="${esc(actual || '')}" placeholder="Ej. Bebidas, Suplementos, Ropa" required autofocus></label>
        <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`);
      $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => { await fn($('[name=n]', m).value); m.cerrar(); toast('Departamento guardado', 'ok'); recargar(); }); };
    };
    $('#bNDep') && ($('#bNDep').onclick = () => pedirNombre('Nuevo departamento', '', (n) => api('/api/departamentos', { nombre: n })));
    $$('[data-ren]', v).forEach((b) => b.onclick = () => { const d = deps.lista[b.dataset.ren]; pedirNombre('Renombrar departamento', d.nombre, (n) => api('/api/departamentos', { de: d.nombre, a: n }, 'PUT')); });
    $$('[data-del]', v).forEach((b) => b.onclick = async () => {
      const d = deps.lista[b.dataset.del];
      if (await confirmar(`Se eliminará el departamento "${esc(d.nombre)}". Sus ${d.productos} producto(s) quedarán sin departamento.`, 'Sí, eliminar')) intentar(async () => { await api('/api/departamentos?nombre=' + encodeURIComponent(d.nombre), {}, 'DELETE'); toast('Departamento eliminado', 'ok'); recargar(); });
    });
  }
  prodTab === 'prod' ? pintarProd() : pintarDeps();
};
function modalInventarioPdf(deps) {
  const m = modal(`<h2>📄 Inventario en PDF</h2><form class="form" id="f">
    <label class="todo">Departamento<select name="dep"><option value="">Todos los departamentos</option>${deps.map((d) => `<option>${esc(d)}</option>`).join('')}<option value="Sin departamento">Sin departamento</option></select></label>
    <label class="chk todo"><input type="checkbox" name="conteo"> Hoja de conteo (con espacios para anotar lo que se contó)</label>
    <p class="muted todo" style="margin:0">El inventario muestra existencias, costo, precio, valor y qué productos hay que surtir, separado por departamento.</p>
    <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Descargar PDF</button></div></form>`);
  $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => {
    await generarReportePdf('inventario', hoyStr(), hoyStr(), { gym: estado.config.gym_nombre, api, departamento: $('[name=dep]', m).value, conteo: $('[name=conteo]', m).checked });
    m.cerrar(); toast('PDF descargado', 'ok');
  }, $('.primario', m)); };
}

// ---------- Importar productos desde Excel (igual que en Maxsel Comedores) ----------
function plantillaProductos() {
  descargarExcel('plantilla_productos', [{ nombre: 'Productos', titulo: 'Plantilla de productos',
    subtitulo: 'Llene desde la fila 5. Las existencias y el mínimo son piezas. Después súbala en Productos → Importar desde Excel.',
    columnas: [{ t: 'Código de barras', ancho: 18 }, { t: 'Nombre del producto', ancho: 36 }, { t: 'Precio costo', ancho: 13, tipo: 'dinero' },
      { t: 'Precio venta', ancho: 13, tipo: 'dinero' }, { t: 'Existencias', ancho: 12, tipo: 'entero' }, { t: 'Mínimo', ancho: 10, tipo: 'entero' }, { t: 'Departamento', ancho: 18 }],
    filas: [['7501055300075', 'Agua natural 1 L', 8, 20, 24, 6, 'Bebidas'], ['7500000000017', 'Barra de proteína', 22, 45, 20, 5, 'Suplementos'], ['7500000000031', 'Proteína Whey 2 lb', 520, 799, 6, 2, 'Suplementos']] }]);
}
function modalImportarProductos(listo) {
  let filasProd = [];
  const m = modal(`<h2>📥 Importar productos desde Excel</h2>
    <p>Columnas: <b>Código de barras · Nombre del producto · Precio costo · Precio venta · Existencias · Mínimo · Departamento</b> (el departamento es opcional).<br>
    Si el código ya existe, el producto se actualiza (nombre, precios y existencia); si no, se da de alta.</p>
    <div class="fila"><button class="btn" id="ipPlantilla">⬇ Descargar plantilla</button>
      <label class="btn primario">📂 Elegir archivo (.xlsx o .csv)<input type="file" id="ipArchivo" accept=".xlsx,.csv" hidden></label></div>
    <div id="ipVista" style="margin-top:12px"></div><div id="ipRes"></div>
    <div class="modal-pie"><button class="btn" data-cerrar>Cerrar</button><button class="btn primario" id="ipBtn" disabled>Subir productos</button></div>`, { ancho: true });
  $('#ipPlantilla', m).onclick = plantillaProductos;
  $('#ipArchivo', m).onchange = async (e) => {
    const f = e.target.files[0]; filasProd = []; $('#ipRes', m).innerHTML = ''; $('#ipBtn', m).disabled = true;
    if (!f) return;
    try {
      const filas = await leerArchivoTabla(f);
      const esNum = (x) => x !== undefined && x !== null && String(x).trim() !== '' && !isNaN(Number(String(x).replace(/[$,\s]/g, '')));
      filasProd = filas.map((r, i) => ({ fila: i + 1, codigo: String(r[0] ?? '').trim(), nombre: String(r[1] ?? '').trim(), costo: r[2], precio: r[3], existencia: r[4], minimo: r[5], area: String(r[6] ?? '').trim() }))
        .filter((r) => r.nombre && esNum(r.precio)); // se saltan títulos y encabezados
      $('#ipVista', m).innerHTML = filasProd.length ? `<div class="aviso verde">Se encontraron <b>${filasProd.length}</b> productos en <b>${esc(f.name)}</b>. Vista previa:</div>
        <div class="tabla-scroll" style="max-height:260px"><table><tr><th>Código</th><th>Producto</th><th class="num">Costo</th><th class="num">Venta</th><th class="num">Existencias</th><th class="num">Mínimo</th><th>Departamento</th></tr>
        ${filasProd.slice(0, 15).map((r) => `<tr><td>${esc(r.codigo)}</td><td>${esc(r.nombre)}</td><td class="num">${esc(r.costo ?? '')}</td><td class="num">${esc(r.precio)}</td><td class="num">${esc(r.existencia ?? '')}</td><td class="num">${esc(r.minimo ?? '')}</td><td>${esc(r.area)}</td></tr>`).join('')}</table></div>
        ${filasProd.length > 15 ? `<small class="muted">… y ${filasProd.length - 15} más</small>` : ''}`
        : '<div class="aviso rojo">No se encontraron productos. Revisa que el archivo tenga las columnas de la plantilla.</div>';
      $('#ipBtn', m).disabled = !filasProd.length;
    } catch (err) { $('#ipVista', m).innerHTML = `<div class="aviso rojo">${esc(err.message)}</div>`; }
  };
  $('#ipBtn', m).onclick = (e) => intentar(async () => {
    const r = await api('/api/productos/importar', { filas: filasProd });
    $('#ipRes', m).innerHTML = `<div class="aviso verde">✅ Listo: <b>${r.nuevos}</b> productos nuevos y <b>${r.actualizados}</b> actualizados.` +
      (r.errores.length ? `<br>No se subieron ${r.errores.length}: ${r.errores.slice(0, 8).map(esc).join(' · ')}` : '') + '</div>';
    $('#ipVista', m).innerHTML = ''; filasProd = []; $('#ipBtn', m).disabled = true;
    listo();
  }, e.target);
}
function modalProducto(p, listo, deps = []) {
  p = p || { activo: 1 };
  const lista = [...new Set([...deps, p.area].filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es'));
  const m = modal(`<h2>${p.id ? 'Editar' : 'Nuevo'} producto</h2><form class="form" id="f">
    <label class="todo">Código de barras (escanéalo aquí)<input name="codigo" value="${esc(p.codigo || '')}" autofocus></label>
    <label class="todo">Nombre del producto *<input name="nombre" value="${esc(p.nombre || '')}" required></label>
    <label class="todo">Departamento<select name="area_sel"><option value="">Sin departamento</option>${lista.map((d) => `<option ${d === p.area ? 'selected' : ''}>${esc(d)}</option>`).join('')}<option value="__nuevo">+ Nuevo departamento…</option></select>
      <input name="area_nueva" placeholder="Nombre del departamento nuevo (ej. Suplementos)" class="oculto" style="margin-top:6px"></label>
    <label>Precio de costo<input name="costo" type="number" step="0.01" min="0" value="${p.costo ?? ''}"></label>
    <label>Precio de venta *<input name="precio" type="number" step="0.01" min="0.01" value="${p.precio ?? ''}" required></label>
    <label>Existencia<input name="existencia" type="number" step="1" value="${p.existencia ?? 0}"></label>
    <label>Avisar cuando queden<input name="minimo" type="number" step="1" min="0" value="${p.minimo ?? 0}"></label>
    ${p.id ? `<label class="chk todo"><input type="checkbox" name="activo" ${p.activo ? 'checked' : ''}> Producto activo (se puede vender)</label>` : ''}
    <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`);
  // que el lector de código de barras no envíe el formulario al presionar Enter
  $('[name=codigo]', m).addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('[name=nombre]', m).focus(); } });
  $('[name=area_sel]', m).onchange = (e) => { $('[name=area_nueva]', m).classList.toggle('oculto', e.target.value !== '__nuevo'); if (e.target.value === '__nuevo') $('[name=area_nueva]', m).focus(); };
  $('#f', m).onsubmit = (e) => {
    e.preventDefault();
    const d = valores(e.target); if (!p.id) d.activo = true;
    d.area = d.area_sel === '__nuevo' ? d.area_nueva : d.area_sel; delete d.area_sel; delete d.area_nueva;
    intentar(async () => { await api('/api/productos' + (p.id ? '/' + p.id : ''), d, p.id ? 'PUT' : 'POST'); m.cerrar(); toast('Producto guardado', 'ok'); listo(); });
  };
}
function modalEntrada(p, listo) {
  const m = modal(`<h2>Entrada de mercancía</h2><p><b>${esc(p.nombre)}</b> — existencia actual: ${p.existencia}</p><form class="form" id="f">
    <label>Cantidad que llegó<input name="cantidad" type="number" step="1" min="1" required autofocus></label>
    <label>Nuevo costo (opcional)<input name="costo" type="number" step="0.01" min="0" placeholder="${p.costo}"></label>
    <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Agregar</button></div></form>`);
  $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => { await api(`/api/productos/${p.id}/entrada`, valores(e.target)); m.cerrar(); toast('Existencia actualizada', 'ok'); listo(); }); };
}

// ===================== Planes y promociones =====================
const TIPOS_PROMO = { estudiante: 'Estudiantes', pareja: 'Pareja (2 personas)', vecino: 'Vecinos de la zona', general: 'General' };
const DESC_PROMO = { porcentaje: '% de descuento', monto: '$ de descuento', precio_fijo: 'Precio fijo (total)' };
const duracion = (p) => (p.meses ? `${p.meses} mes${p.meses > 1 ? 'es' : ''}` : '') + (p.meses && p.dias ? ' + ' : '') + (p.dias ? `${p.dias} día${p.dias > 1 ? 's' : ''}` : '');
VISTAS.planes = async (v) => {
  const [planes, promos] = await Promise.all([api('/api/planes'), api('/api/promociones')]);
  v.innerHTML = `<div class="encabezado"><h1>Membresías y promociones</h1></div>
    <div class="rejilla cols-2">
      <div class="panel"><div class="encabezado"><h2 style="margin:0;margin-right:auto">Planes</h2><button class="btn primario chico" id="nPlan">+ Plan</button></div>
        <table><tr><th>Plan</th><th>Duración</th><th class="num">Precio</th><th></th></tr>${planes.map((p) => `<tr style="${p.activo ? '' : 'opacity:.5'}"><td><b>${esc(p.nombre)}</b></td><td>${duracion(p)}</td><td class="num">${dinero(p.precio)}</td><td><button class="btn chico" data-p="${p.id}">Editar</button></td></tr>`).join('')}</table></div>
      <div class="panel"><div class="encabezado"><h2 style="margin:0;margin-right:auto">Promociones</h2><button class="btn primario chico" id="nPromo">+ Promoción</button></div>
        <table><tr><th>Promoción</th><th>Para</th><th>Descuento</th><th></th></tr>${promos.map((p) => `<tr style="${p.activo ? '' : 'opacity:.5'}"><td><b>${esc(p.nombre)}</b>${p.plan ? `<br><small class="muted">Solo plan ${esc(p.plan)}</small>` : ''}</td><td>${TIPOS_PROMO[p.tipo]}${p.zonas ? `<br><small class="muted">${esc(p.zonas)}</small>` : ''}</td>
          <td>${p.descuento_tipo === 'porcentaje' ? p.valor + '%' : p.descuento_tipo === 'monto' ? '−' + dinero(p.valor) : 'Total ' + dinero(p.valor)}</td><td><button class="btn chico" data-r="${p.id}">Editar</button></td></tr>`).join('')}</table></div>
    </div>
    <div class="aviso azul" style="margin-top:16px"><b>Cómo funcionan:</b> <b>Estudiantes</b> → el cliente debe estar marcado como estudiante y tener la foto de su credencial escolar. <b>Pareja</b> → se cobra el plan por 2 personas con el descuento y las dos reciben su membresía (si se registraron en pareja, la segunda persona se pone sola). <b>Vecinos</b> → el cliente debe estar marcado como vecino, tener la foto de su INE o comprobante de domicilio, y si pones zonas, su colonia o código postal debe estar en la lista (sepáralas con comas, ej. <i>Otay, 22430, Altamira</i>).</div>`;
  const editarPlan = (p) => {
    p = p || { activo: 1, dias: 0, meses: 1 };
    const m = modal(`<h2>${p.id ? 'Editar' : 'Nuevo'} plan</h2><form class="form" id="f">
      <label class="todo">Nombre<input name="nombre" value="${esc(p.nombre || '')}" required autofocus></label>
      <label>Meses<input name="meses" type="number" min="0" value="${p.meses}"></label><label>Días<input name="dias" type="number" min="0" value="${p.dias}"></label>
      <p class="todo muted" style="margin:0">Diario = 1 día · Semanal = 7 días · Quincenal = 15 días · Mensual = 1 mes · Trimestral = 3 meses · Semestral = 6 meses · Anual = 12 meses</p>
      <label class="todo">Precio<input name="precio" type="number" step="0.01" min="0" value="${p.precio ?? ''}" required></label>
      <label class="chk todo"><input type="checkbox" name="activo" ${p.activo ? 'checked' : ''}> Activo</label>
      <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`);
    $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => { await api('/api/planes' + (p.id ? '/' + p.id : ''), valores(e.target), p.id ? 'PUT' : 'POST'); m.cerrar(); enrutar(); }); };
  };
  const editarPromo = (p) => {
    p = p || { activo: 1, tipo: 'general', descuento_tipo: 'porcentaje' };
    const opt = (o, sel) => Object.entries(o).map(([k, t]) => `<option value="${k}" ${k === sel ? 'selected' : ''}>${t}</option>`).join('');
    const m = modal(`<h2>${p.id ? 'Editar' : 'Nueva'} promoción</h2><form class="form" id="f">
      <label class="todo">Nombre<input name="nombre" value="${esc(p.nombre || '')}" required autofocus></label>
      <label>Para<select name="tipo">${opt(TIPOS_PROMO, p.tipo)}</select></label>
      <label>Solo para el plan<select name="plan_id"><option value="">Todos los planes</option>${planes.map((x) => `<option value="${x.id}" ${x.id === p.plan_id ? 'selected' : ''}>${esc(x.nombre)}</option>`).join('')}</select></label>
      <label>Tipo de descuento<select name="descuento_tipo">${opt(DESC_PROMO, p.descuento_tipo)}</select></label>
      <label>Valor<input name="valor" type="number" step="0.01" min="0" value="${p.valor ?? ''}" required></label>
      <label class="todo" id="zonasBox">Zonas (colonias o códigos postales, separados por coma)<input name="zonas" value="${esc(p.zonas || '')}"></label>
      <label class="chk todo"><input type="checkbox" name="activo" ${p.activo ? 'checked' : ''}> Activa</label>
      <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`);
    const zon = () => $('#zonasBox', m).classList.toggle('oculto', $('[name=tipo]', m).value !== 'vecino');
    $('[name=tipo]', m).onchange = zon; zon();
    $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => { await api('/api/promociones' + (p.id ? '/' + p.id : ''), valores(e.target), p.id ? 'PUT' : 'POST'); m.cerrar(); enrutar(); }); };
  };
  $('#nPlan').onclick = () => editarPlan(); $('#nPromo').onclick = () => editarPromo();
  $$('[data-p]', v).forEach((b) => b.onclick = () => editarPlan(planes.find((p) => p.id == b.dataset.p)));
  $$('[data-r]', v).forEach((b) => b.onclick = () => editarPromo(promos.find((p) => p.id == b.dataset.r)));
};

// ===================== Cortes =====================
VISTAS.cortes = async (v) => {
  v.innerHTML = `<div class="encabezado"><h1>Cortes de caja</h1><label class="fila">Del <input type="date" id="d" value="${sumarDiasStr(hoyStr(), -30)}" style="width:auto"></label><label class="fila">al <input type="date" id="h" value="${hoyStr()}" style="width:auto"></label></div><div class="panel" id="tabla"></div>`;
  const cargar = async () => {
    const lista = await api(`/api/cortes?desde=${$('#d').value}&hasta=${$('#h').value}`);
    $('#tabla').innerHTML = `<table><tr><th>Turno</th><th>Cajero</th><th>Abierto</th><th>Cerrado</th><th class="num">Ventas</th><th class="num">Diferencia</th><th></th></tr>
      ${lista.map((t) => `<tr class="click" data-id="${t.id}"><td>#${t.id}</td><td>${esc(t.cajero)}</td><td>${fechaHora(t.abierto)}</td><td>${t.cerrado ? fechaHora(t.cerrado) : '<span class="etq azul">Abierto</span>'}</td>
        <td class="num">${dinero(t.ventas_total)}</td><td class="num ${t.dif_mxn < -0.5 ? 'rojo' : t.dif_mxn > 0.5 ? 'verde' : ''}"><b>${t.dif_mxn === null ? '—' : (t.dif_mxn > 0 ? '+' : '') + dinero(t.dif_mxn)}</b></td><td>Ver →</td></tr>`).join('') || '<tr><td colspan="7" class="vacio">Sin turnos</td></tr>'}</table>`;
    $$('tr[data-id]', v).forEach((tr) => tr.onclick = () => location.hash = '#/corte/' + tr.dataset.id);
  };
  $('#d').onchange = cargar; $('#h').onchange = cargar; cargar();
};
VISTAS.corte = async (v, id) => {
  const c = await api('/api/cortes/' + id);
  const t = c.turno, r = c.resumen;
  const fila = (n, esp, decl, dif, fmt = dinero) => `<tr><td>${n}</td><td class="num">${fmt(esp)}</td><td class="num">${decl === null || decl === undefined ? '—' : fmt(decl)}</td><td class="num ${dif < -0.009 ? 'rojo' : dif > 0.009 ? 'verde' : ''}"><b>${dif === null || dif === undefined ? '—' : (dif > 0 ? '+' : '') + fmt(dif)}</b></td></tr>`;
  v.innerHTML = `<div class="encabezado"><a class="btn" href="#/cortes">←</a><h1>Corte del turno #${t.id}</h1><span class="etq ${t.estado === 'cerrado' ? 'sin' : 'azul'}">${t.estado === 'cerrado' ? 'Cerrado' : 'Abierto'}</span></div>
    <p>Cajero: <b>${esc(t.cajero)}</b> · Abierto ${fechaHora(t.abierto)} · ${t.cerrado ? 'Cerrado ' + fechaHora(t.cerrado) : 'Aún abierto'} · Dólar a <b>${dinero(t.tipo_cambio)}</b></p>
    ${c.diferencia ? `<div class="aviso ${Math.abs(c.diferencia.total_mxn) < 0.5 ? 'verde' : c.diferencia.total_mxn < 0 ? 'rojo' : ''}" style="font-size:18px">${Math.abs(c.diferencia.total_mxn) < 0.5 ? '✅ El corte cuadra' : c.diferencia.total_mxn < 0 ? `Faltante total: <b>${dinero(-c.diferencia.total_mxn)}</b>` : `Sobrante total: <b>${dinero(c.diferencia.total_mxn)}</b>`} <small>(dólares convertidos a pesos)</small></div>` : ''}
    <div class="rejilla cols-2">
      <div class="panel"><h2>Esperado vs. declarado</h2><table><tr><th></th><th class="num">Debería haber</th><th class="num">Contó el cajero</th><th class="num">Diferencia</th></tr>
        ${fila('Efectivo (pesos)', c.esperado.efectivo, t.decl_efectivo, c.diferencia?.efectivo)}
        ${fila('Dólares', c.esperado.usd, t.decl_usd, c.diferencia?.usd, usd)}
        ${fila('Tarjeta', c.esperado.tarjeta, t.decl_tarjeta, c.diferencia?.tarjeta)}</table>
        ${r.transferencia > 0 ? `<p class="muted" style="margin:8px 0 0">Transferencias: <b>${dinero(r.transferencia)}</b> (van directo al banco, no se cuentan en la caja).</p>` : ''}
        ${t.notas ? `<p><b>Notas:</b> ${esc(t.notas)}</p>` : ''}</div>
      <div class="panel"><h2>Resumen</h2><table>
        <tr><td>Fondo inicial</td><td class="num">${dinero(r.fondo)}</td></tr><tr><td>Ventas (${r.ventas_n})</td><td class="num">${dinero(r.ventas_total)}</td></tr>
        <tr><td>Vendido a crédito</td><td class="num">${dinero(r.credito)}</td></tr><tr><td>Abonos cobrados (${r.abonos_n})</td><td class="num">${dinero(r.abonos_total)}</td></tr>
        <tr><td>Entradas de efectivo</td><td class="num">${dinero(r.entradas)}</td></tr><tr><td>Retiros de efectivo</td><td class="num">${r.retiros ? '−' + dinero(r.retiros) : dinero(0)}</td></tr><tr><td>Gastos pagados de la caja</td><td class="num">${r.gastos ? '−' + dinero(r.gastos) : dinero(0)}</td></tr></table></div>
    </div>
    <div class="panel" style="margin-top:16px"><h2>Ventas</h2><div class="tabla-scroll"><table><tr><th>#</th><th>Hora</th><th>Detalle</th><th>Cliente</th><th class="num">Efectivo</th><th class="num">USD</th><th class="num">Tarjeta</th><th class="num">Transf.</th><th class="num">Crédito</th><th class="num">Total</th></tr>
      ${c.ventas.map((x) => `<tr style="${x.cancelada ? 'text-decoration:line-through;opacity:.5' : ''}"><td>${x.id}</td><td>${hora(x.fecha)}</td><td>${esc(x.detalle)}</td><td>${esc(x.cliente || '')}</td><td class="num">${dinero(x.pago_efectivo - x.cambio)}</td><td class="num">${x.pago_usd ? usd(x.pago_usd) : ''}</td><td class="num">${x.pago_tarjeta ? dinero(x.pago_tarjeta) : ''}</td><td class="num">${x.pago_transferencia ? dinero(x.pago_transferencia) : ''}</td><td class="num">${x.pago_credito ? dinero(x.pago_credito) : ''}</td><td class="num"><b>${dinero(x.total)}</b></td></tr>`).join('') || '<tr><td colspan="9" class="vacio">Sin ventas</td></tr>'}</table></div></div>
    ${c.abonos.length || c.movimientos.length ? `<div class="rejilla cols-2" style="margin-top:16px">
      <div class="panel"><h2>Abonos</h2><table>${c.abonos.map((a) => `<tr><td>${hora(a.fecha)}</td><td>${esc(a.cliente)}</td><td class="num">${dinero(a.monto)}</td></tr>`).join('') || '<tr><td class="vacio">—</td></tr>'}</table></div>
      <div class="panel"><h2>Retiros, gastos y entradas</h2><table>${c.movimientos.map((x) => `<tr><td>${hora(x.fecha)}</td><td>${TIPOS_MOV[x.tipo]?.nombre || x.tipo}${x.categoria ? ' (' + esc(x.categoria) + ')' : ''}: ${esc(x.concepto)}${x.recibe ? ` <small class="muted">· recibió ${esc(x.recibe)}</small>` : ''}</td><td class="num ${x.tipo === 'entrada' ? '' : 'rojo'}">${x.tipo === 'entrada' ? '' : '−'}${dinero(x.monto)}</td></tr>`).join('') || '<tr><td class="vacio">—</td></tr>'}</table></div></div>` : ''}`;
};

// ===================== Gastos (fijos y varios) =====================
const ICONO_CAT = { Agua: '💧', Luz: '💡', Internet: '🌐', Teléfono: '📞', Renta: '🏠', 'Sueldos y nómina': '👷', Mantenimiento: '🔧', Limpieza: '🧹', Publicidad: '📣', 'Impuestos y permisos': '🏛️', Proveedores: '📦', Equipo: '🏋️', 'Gastos varios': '🧾' };
const MESES_L = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const mesLargo = (m) => { const [y, mm] = m.split('-').map(Number); return `${MESES_L[mm - 1]} ${y}`; };
VISTAS.gastos = async (v) => {
  let mes = estado.mesGastos || hoyStr().slice(0, 7);
  v.innerHTML = `<div class="encabezado"><h1>Gastos</h1>
      <div class="fila"><button class="btn" id="mAnt">‹</button><input type="month" id="mes" value="${mes}" max="${hoyStr().slice(0, 7)}" style="width:auto"><button class="btn" id="mSig">›</button></div>
      <button class="btn" id="bExcelG">⬇ Excel del mes</button><button class="btn primario" id="bNuevoG">+ Registrar gasto</button></div>
    <div id="cont"><p class="muted">Cargando…</p></div>`;
  const cargar = async () => {
    mes = $('#mes').value || mes; estado.mesGastos = mes;
    const d = await api('/api/gastos?mes=' + mes);
    const esteMes = mes === hoyStr().slice(0, 7), diaHoy = Number(hoyStr().slice(8));
    const estadoFijo = (f) => {
      if (f.pagos.length) return `<span class="etq activo">Pagado ${f.pagos.length > 1 ? `(${f.pagos.length} pagos)` : 'el ' + fecha(f.pagos[0].fecha)}</span>`;
      if (f.dia && esteMes && diaHoy > f.dia) return `<span class="etq vencido">Atrasado · venció el día ${f.dia}</span>`;
      if (f.dia && esteMes && f.dia - diaHoy <= 5) return `<span class="etq por_vencer">Vence el día ${f.dia}</span>`;
      return `<span class="etq sin">Pendiente${f.dia ? ' · día ' + f.dia : ''}</span>`;
    };
    $('#cont').innerHTML = `<div class="rejilla cols-4">
        <div class="kpi"><small>Gastos de ${mesLargo(mes)}</small><b>${dinero(d.total)}</b></div>
        <div class="kpi"><small>Gastos fijos pagados</small><b>${dinero(d.total_fijos)}</b><small>de ${dinero(d.esperado_fijos)} esperados</small></div>
        <div class="kpi"><small>Fijos pendientes</small><b class="${d.vencidos ? 'rojo' : ''}">${d.pendientes}</b>${d.vencidos ? `<small class="rojo">${d.vencidos} atrasado${d.vencidos === 1 ? '' : 's'}</small>` : ''}</div>
        <div class="kpi"><small>Pagado con dinero de la caja</small><b>${dinero(d.de_caja)}</b></div></div>
      <div class="panel" style="margin-top:16px"><div class="fila" style="justify-content:space-between;align-items:center"><h2 style="margin:0">📌 Gastos fijos de cada mes</h2><button class="btn chico" id="bNuevoFijo">+ Agregar gasto fijo</button></div>
        <p class="muted">Agua, luz, internet, renta, sueldos… Se registran una vez y cada mes solo marcas si ya se pagaron.</p>
        <table><tr><th>Gasto</th><th>Categoría</th><th class="num">Monto aprox.</th><th>Estado en ${mesLargo(mes)}</th><th class="num">Pagado</th><th></th></tr>
          ${d.fijos.map((f) => `<tr><td><b>${esc(f.nombre)}</b>${f.notas ? `<br><small class="muted">${esc(f.notas)}</small>` : ''}</td><td>${ICONO_CAT[f.categoria] || ''} ${esc(f.categoria)}</td><td class="num">${f.monto ? dinero(f.monto) : '—'}</td>
            <td>${estadoFijo(f)}</td><td class="num">${f.pagado ? dinero(f.pagado) : ''}</td>
            <td class="fila" style="justify-content:flex-end"><button class="btn chico ${f.pagos.length ? '' : 'primario'}" data-pagar="${f.id}">${f.pagos.length ? '+ Otro pago' : '💵 Pagar'}</button><button class="btn chico" data-ef="${f.id}">✏️</button></td></tr>`).join('') || '<tr><td colspan="6" class="vacio">Todavía no hay gastos fijos. Presiona "Agregar gasto fijo".</td></tr>'}
          ${d.fijos.length ? `<tr><th colspan="2">TOTAL</th><th class="num">${dinero(d.esperado_fijos)}</th><th></th><th class="num">${dinero(d.total_fijos)}</th><th></th></tr>` : ''}</table></div>
      <div class="rejilla cols-2" style="margin-top:16px">
        <div class="panel"><h2>🧾 Todos los gastos de ${mesLargo(mes)}</h2>
          <div class="tabla-scroll"><table><tr><th>Fecha</th><th>Gasto</th><th>Categoría</th><th>Pagado con</th><th class="num">Monto</th><th></th></tr>
          ${d.pagos.map((x) => `<tr><td>${fecha(x.fecha)}</td><td>${esc(x.nombre)}${x.gasto_fijo_id ? ' <span class="etq azul">fijo</span>' : ''}${x.notas ? `<br><small class="muted">${esc(x.notas)}</small>` : ''}</td><td>${esc(x.categoria || '')}</td>
            <td>${x.pagado_con === 'caja' ? '💵 Caja' : '🏦 Fuera de caja'}<br><small class="muted">${esc(x.usuario || '')}</small></td><td class="num"><b>${dinero(x.monto)}</b></td><td><button class="btn chico" data-borrar="${x.id}" title="Borrar">🗑️</button></td></tr>`).join('') || '<tr><td colspan="6" class="vacio">Sin gastos registrados este mes</td></tr>'}
          ${d.pagos.length ? `<tr><th colspan="4">TOTAL</th><th class="num">${dinero(d.total)}</th><th></th></tr>` : ''}</table></div></div>
        <div>
          <div class="panel"><h2>Por categoría</h2><table>${d.por_categoria.map((c) => `<tr><td>${ICONO_CAT[c.categoria] || ''} ${esc(c.categoria)}</td><td class="num">${dinero(c.total)}</td></tr>`).join('') || '<tr><td class="vacio">—</td></tr>'}</table></div>
          <div class="panel" style="margin-top:16px"><h2>Meses anteriores</h2><table>${d.meses.map((m) => `<tr class="click" data-mes="${m.periodo}"><td>${mesLargo(m.periodo)}</td><td class="num">${dinero(m.total)}</td></tr>`).join('') || '<tr><td class="vacio">—</td></tr>'}</table></div>
        </div></div>`;
    $$('[data-mes]', v).forEach((tr) => tr.onclick = () => { $('#mes').value = tr.dataset.mes; cargar(); });
    $$('[data-pagar]', v).forEach((b) => b.onclick = () => modalGasto(d, d.fijos.find((f) => f.id == b.dataset.pagar), cargar));
    $$('[data-ef]', v).forEach((b) => b.onclick = () => modalGastoFijo(d, d.fijos.find((f) => f.id == b.dataset.ef), cargar));
    $$('[data-borrar]', v).forEach((b) => b.onclick = async () => { if (await confirmar('Se borrará este gasto. Si salió de la caja, también se quita el movimiento de la caja.', 'Sí, borrar')) intentar(async () => { await api('/api/gastos/' + b.dataset.borrar, {}, 'DELETE'); toast('Gasto borrado', 'ok'); cargar(); }); });
    $('#bNuevoFijo').onclick = () => modalGastoFijo(d, null, cargar);
    $('#bNuevoG').onclick = () => modalGasto(d, null, cargar);
    $('#bExcelG').onclick = (e) => intentar(() => {
      if (!d.pagos.length) throw new Error('No hay gastos en ese mes');
      const fx2 = (s2) => s2.slice(0, 10).split('-').reverse().join('/');
      descargarExcel(`Gastos ${mes}`, [
        { nombre: 'Gastos', titulo: `Gastos de ${mesLargo(mes)} · ${estado.config.gym_nombre}`, subtitulo: `Total: ${dinero(d.total)} · Fijos: ${dinero(d.total_fijos)} · Pagado de la caja: ${dinero(d.de_caja)}`,
          columnas: [{ t: 'Fecha', ancho: 11 }, { t: 'Gasto', ancho: 30 }, { t: 'Categoría', ancho: 20 }, { t: 'Tipo', ancho: 8 }, { t: 'Pagado con', ancho: 14 }, { t: 'Monto', ancho: 13, tipo: 'dinero' }, { t: 'Registró', ancho: 16 }, { t: 'Notas', ancho: 30 }],
          filas: d.pagos.map((x) => [fx2(x.fecha), x.nombre, x.categoria || '', x.gasto_fijo_id ? 'Fijo' : 'Vario', x.pagado_con === 'caja' ? 'Caja' : 'Fuera de caja', x.monto, x.usuario || '', x.notas || '']), totales: ['', 'TOTAL', '', '', '', d.total, '', ''] },
        { nombre: 'Gastos fijos', titulo: `Gastos fijos · ${mesLargo(mes)}`, columnas: [{ t: 'Gasto', ancho: 30 }, { t: 'Categoría', ancho: 20 }, { t: 'Monto aprox.', ancho: 13, tipo: 'dinero' }, { t: 'Día de pago', ancho: 10, tipo: 'entero' }, { t: 'Estado', ancho: 12 }, { t: 'Pagado', ancho: 13, tipo: 'dinero' }],
          filas: d.fijos.map((f) => [f.nombre, f.categoria, f.monto, f.dia || '', f.pagos.length ? 'Pagado' : 'Pendiente', f.pagado || '']), totales: ['TOTAL', '', d.esperado_fijos, '', '', d.total_fijos] },
        { nombre: 'Por categoría', titulo: `Gastos por categoría · ${mesLargo(mes)}`, columnas: [{ t: 'Categoría', ancho: 30 }, { t: 'Total', ancho: 14, tipo: 'dinero' }], filas: d.por_categoria.map((c) => [c.categoria, c.total]) },
      ]);
      toast('Excel descargado', 'ok');
    }, e.currentTarget);
  };
  const moverMes = (n) => { const [y, m] = $('#mes').value.split('-').map(Number); const d2 = new Date(y, m - 1 + n, 1); const val = `${d2.getFullYear()}-${String(d2.getMonth() + 1).padStart(2, '0')}`; if (val > hoyStr().slice(0, 7)) return; $('#mes').value = val; cargar(); };
  $('#mAnt').onclick = () => moverMes(-1); $('#mSig').onclick = () => moverMes(1);
  $('#mes').onchange = cargar; cargar();
};
const opcionesCat = (cats, sel) => cats.map((c) => `<option value="${esc(c)}" ${c === sel ? 'selected' : ''}>${ICONO_CAT[c] || ''} ${esc(c)}</option>`).join('');
function modalGastoFijo(d, f, alGuardar) {
  const m = modal(`<h2>${f ? 'Editar gasto fijo' : 'Nuevo gasto fijo'}</h2><p class="muted">Un gasto que se paga cada mes. Ejemplos: Luz CFE, Agua CESPT, Internet Telnor, Renta del local, Sueldo de Juan.</p>
    <form class="form" id="f">
      <label class="todo">Nombre del gasto<input name="nombre" value="${esc(f?.nombre || '')}" placeholder="Ej. Luz CFE" required autofocus maxlength="80"></label>
      <label>Categoría<select name="categoria">${opcionesCat(d.categorias, f?.categoria || 'Luz')}</select></label>
      <label>Monto aproximado al mes<input name="monto" type="number" step="0.01" min="0" value="${f?.monto || ''}" placeholder="0.00"></label>
      <label>Día del mes en que se paga <small class="muted">(opcional)</small><input name="dia" type="number" min="1" max="31" value="${f?.dia || ''}" placeholder="Ej. 10"></label>
      <label>Notas<input name="notas" value="${esc(f?.notas || '')}" placeholder="Ej. número de servicio, a quién se le paga"></label>
      <div class="modal-pie todo">${f ? '<button type="button" class="btn peligro" id="bBorrarFijo">Quitar</button>' : ''}<button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`);
  $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => { await api('/api/gastos/fijos' + (f ? '/' + f.id : ''), valores(e.target), f ? 'PUT' : 'POST'); m.cerrar(); toast('Gasto fijo guardado', 'ok'); alGuardar(); }); };
  $('#bBorrarFijo', m) && ($('#bBorrarFijo', m).onclick = async () => { if (await confirmar(`Se quitará "${esc(f.nombre)}" de los gastos fijos (los pagos ya registrados se conservan).`, 'Sí, quitar')) intentar(async () => { await api('/api/gastos/fijos/' + f.id, {}, 'DELETE'); m.cerrar(); toast('Gasto fijo quitado', 'ok'); alGuardar(); }); });
}
function modalGasto(d, fijo, alGuardar) {
  const puedeCaja = puede('movimientos');
  const m = modal(`<h2>${fijo ? '💵 Pagar: ' + esc(fijo.nombre) : 'Registrar gasto'}</h2>
    <form class="form" id="f">
      ${fijo ? `<input type="hidden" name="gasto_fijo_id" value="${fijo.id}">` : `<label class="todo">¿Qué gasto es?<input name="nombre" list="gastosLista" placeholder="Ej. Garrafones de agua, reparación de caminadora" required autofocus maxlength="80"><datalist id="gastosLista">${d.fijos.map((f) => `<option value="${esc(f.nombre)}">`).join('')}</datalist></label>`}
      <label>Monto pagado<input name="monto" type="number" step="0.01" min="0.01" value="${fijo?.monto || ''}" required ${fijo ? 'autofocus' : ''}></label>
      <label>Fecha de pago<input name="fecha" type="date" value="${hoyStr()}" max="${hoyStr()}"></label>
      <label>Categoría<select name="categoria">${opcionesCat(d.categorias, fijo?.categoria || 'Gastos varios')}</select></label>
      <label>Corresponde al mes<input name="periodo" type="month" value="${d.mes}" max="${hoyStr().slice(0, 7)}"></label>
      <label class="todo">¿De dónde salió el dinero?<select name="pagado_con">
        <option value="fuera">🏦 Fuera de la caja (banco, transferencia, dinero del dueño)</option>
        <option value="caja" ${puedeCaja ? '' : 'disabled'}>💵 De la caja del turno abierto (se descuenta del corte)</option></select></label>
      <label class="todo">Notas<input name="notas" placeholder="Ej. folio, a quién se le pagó"></label>
      <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Registrar gasto</button></div></form>`);
  $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => { const g = await api('/api/gastos', valores(e.target)); m.cerrar(); toast(`Gasto registrado: ${dinero(g.monto)}`, 'ok'); alGuardar(); }); };
}

// ===================== Reportes =====================
// ===================== Cuentas por pagar a proveedores (igual que en Maxsel Hotel) =====================
const EST_CXP = { pendiente: ['Se debe', 'cx-debe'], vencida: ['Vencida', 'cx-vencida'], pagada: ['Pagada', 'cx-pagada'] };
let cxpTab = 'cuentas', cxpF = 'abiertas';
// Número rojo en el menú: cuentas vencidas o por vencer
async function avisosCxp() {
  if (!puede('cuentas_pagar')) return;
  try {
    const l = await api('/api/cuentas-pagar/avisos'), a = $('#nav [data-r="cxp"]'); if (!a) return;
    a.querySelector('.badge')?.remove();
    if (l.length) a.insertAdjacentHTML('beforeend', `<b class="badge" title="Cuentas vencidas o por vencer">${l.length}</b>`);
  } catch { /* sin aviso */ }
}
const diasCxp = (c) => (c.estado === 'pagada' ? 'Pagada' : c.dias === null ? 'Sin fecha límite' : c.dias < 0 ? `venció hace ${-c.dias} día${c.dias === -1 ? '' : 's'}` : c.dias === 0 ? 'vence HOY' : c.dias === 1 ? 'vence mañana' : `vence en ${c.dias} días`);
VISTAS.cxp = async (v) => {
  v.innerHTML = `<div class="encabezado"><h1>Cuentas por pagar</h1><button class="btn" id="bXls">📊 Excel</button><button class="btn" id="bProvN">+ Proveedor</button><button class="btn primario" id="bNueva">+ Nueva cuenta por pagar</button></div>
    <div class="fila" style="gap:6px;margin-bottom:12px"><button class="btn ${cxpTab === 'cuentas' ? 'primario' : ''}" data-tab="cuentas">📑 Cuentas</button><button class="btn ${cxpTab === 'prov' ? 'primario' : ''}" data-tab="prov">🚚 Proveedores</button></div><div id="cxc"></div>`;
  $$('[data-tab]', v).forEach((b) => b.onclick = () => { cxpTab = b.dataset.tab; VISTAS.cxp(v); });
  const recargar = () => { avisosCxp(); VISTAS.cxp(v); };
  $('#bNueva').onclick = () => modalCxp(null, recargar);
  $('#bProvN').onclick = () => modalProveedor(null, recargar);
  $('#bXls').onclick = (e) => intentar(() => exportarReporte('cuentas', hoyStr().slice(0, 8) + '01', hoyStr()), e.currentTarget);
  if (cxpTab === 'prov') {
    const P = await api('/api/proveedores?todos=1');
    $('#cxc').innerHTML = `<div class="panel"><div class="tabla-scroll"><table><tr><th>Proveedor</th><th>Qué surte</th><th>Contacto</th><th>Banco / cuenta</th><th class="num">Le debemos</th><th class="num">Pagado en total</th><th></th></tr>
      ${P.map((p) => `<tr style="${p.activo ? '' : 'opacity:.5'}"><td><b>${esc(p.nombre)}</b>${p.rfc ? `<br><small class="muted">RFC ${esc(p.rfc)}</small>` : ''}</td><td>${esc(p.surte || '')}</td><td>${esc(p.contacto || '')}${p.telefono ? `<br><small class="muted">${esc(p.telefono)}</small>` : ''}</td>
        <td><small>${esc([p.banco, p.cuenta].filter(Boolean).join(' · '))}</small></td><td class="num ${p.debe > 0 ? 'rojo' : ''}"><b>${dinero(p.debe)}</b>${p.abiertas ? `<br><small class="muted">${p.abiertas} cuenta(s)</small>` : ''}</td><td class="num">${dinero(p.pagado_total)}</td>
        <td><button class="btn chico" data-ep="${p.id}">✏️</button></td></tr>`).join('') || '<tr><td colspan="7" class="vacio">Todavía no hay proveedores. Presiona "+ Proveedor".</td></tr>'}</table></div></div>`;
    $$('[data-ep]', v).forEach((b) => b.onclick = () => modalProveedor(P.find((x) => x.id == b.dataset.ep), recargar));
    return;
  }
  const [L, todas] = await Promise.all([api('/api/cuentas-pagar?estado=' + cxpF), api('/api/cuentas-pagar?estado=abiertas')]);
  const deb = todas.filter((c) => c.estado === 'pendiente'), ven = todas.filter((c) => c.estado === 'vencida'), S = (l) => l.reduce((a, c) => a + c.saldo, 0);
  const F = [['abiertas', 'Por pagar'], ['vencida', 'Vencidas'], ['pagada', 'Pagadas'], ['todas', 'Todas']];
  $('#cxc').innerHTML = `<div class="rejilla cols-3">
      <div class="kpi cx-debe"><small>Se debe (a tiempo)</small><b>${dinero(S(deb))}</b><small>${deb.length} cuenta(s)${deb.filter((c) => c.por_vencer).length ? ` · ${deb.filter((c) => c.por_vencer).length} por vencer` : ''}</small></div>
      <div class="kpi cx-vencida"><small>Vencido</small><b class="${ven.length ? 'rojo' : ''}">${dinero(S(ven))}</b><small>${ven.length} cuenta(s) pasadas de la fecha</small></div>
      <div class="kpi"><small>Total por pagar</small><b>${dinero(S(deb) + S(ven))}</b><small>${todas.length} cuenta(s) abiertas</small></div></div>
    <div class="panel" style="margin-top:16px"><div class="fila" style="justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:10px">
      <div class="fila" style="gap:6px">${F.map(([k, n]) => `<button class="btn chico ${cxpF === k ? 'primario' : ''}" data-f="${k}">${n}</button>`).join('')}</div>
      <div class="leyenda-cx"><span><i style="background:var(--cx-debe)"></i>Se debe</span><span><i style="background:var(--cx-pagada)"></i>Pagada</span><span><i style="background:var(--cx-vencida)"></i>Pasó la fecha límite</span></div></div>
      <div class="tabla-scroll"><table><tr><th>Proveedor</th><th>Concepto</th><th>Factura</th><th>Fecha</th><th>Vence</th><th class="num">Monto</th><th class="num">Pagado</th><th class="num">Debe</th><th>Estado</th><th></th></tr>
      ${L.map((c) => `<tr class="cxr ${EST_CXP[c.estado]?.[1] || ''}" data-ver="${c.id}"><td><b>${esc(c.proveedor || '—')}</b></td><td>${esc(c.concepto)}</td><td class="muted">${esc(c.factura || '')}</td><td>${fecha(c.fecha)}</td>
        <td>${c.vence ? fecha(c.vence) : '—'}<br><small class="${c.estado === 'vencida' ? 'rojo' : 'muted'}">${diasCxp(c)}</small></td><td class="num">${dinero(c.monto)}</td><td class="num">${dinero(c.pagado)}</td><td class="num"><b>${dinero(c.saldo)}</b></td>
        <td><span class="etq ${EST_CXP[c.estado]?.[1] || ''}">${EST_CXP[c.estado]?.[0] || c.estado}</span>${c.por_vencer ? ' <span class="etq por_vencer">Por vencer</span>' : ''}</td>
        <td>${c.estado !== 'pagada' ? `<button class="btn chico primario" data-pagar="${c.id}">Pagar</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="10" class="vacio">No hay cuentas en esta vista. Registra aquí las facturas o notas que te quedan a deber tus proveedores.</td></tr>'}</table></div></div>`;
  $$('[data-f]', v).forEach((b) => b.onclick = () => { cxpF = b.dataset.f; VISTAS.cxp(v); });
  $$('[data-ver]', v).forEach((tr) => tr.onclick = (e) => { if (!e.target.closest('[data-pagar]')) verCxp(Number(tr.dataset.ver), recargar); });
  $$('[data-pagar]', v).forEach((b) => b.onclick = () => pagarCxp(Number(b.dataset.pagar), recargar));
};
function modalProveedor(p, listo) {
  p = p || { activo: 1 };
  const campo = (n, t, extra = '') => `<label${extra}>${t}<input name="${n}" value="${esc(p[n] || '')}"></label>`;
  const m = modal(`<h2>${p.id ? 'Editar' : 'Nuevo'} proveedor</h2><form class="form" id="f">
    ${campo('nombre', 'Nombre o razón social *', ' class="todo"')}${campo('surte', 'Qué surte (proteína, agua, limpieza…)')}${campo('contacto', 'Contacto')}${campo('telefono', 'Teléfono')}${campo('correo', 'Correo')}
    ${campo('rfc', 'RFC')}${campo('banco', 'Banco')}${campo('cuenta', 'Cuenta / CLABE')}${campo('notas', 'Notas', ' class="todo"')}
    ${p.id ? `<label class="chk todo"><input type="checkbox" name="activo" ${p.activo ? 'checked' : ''}> Proveedor activo</label>` : ''}
    <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`);
  $('#f', m).onsubmit = (e) => { e.preventDefault(); const d = valores(e.target); if (!p.id) d.activo = true;
    intentar(async () => { await api('/api/proveedores' + (p.id ? '/' + p.id : ''), d, p.id ? 'PUT' : 'POST'); m.cerrar(); toast('Proveedor guardado', 'ok'); listo(); }, $('.primario', m)); };
}
async function modalCxp(c, listo) {
  const [P, g] = await Promise.all([api('/api/proveedores'), api('/api/gastos')]);
  const venc = new Date(); venc.setDate(venc.getDate() + 15);
  c = c || { proveedor_id: '', concepto: '', factura: '', categoria: 'Proveedores', monto: '', fecha: hoyStr(), vence: ymdLocal(venc), notas: '' };
  const m = modal(`<h2>${c.id ? 'Editar' : 'Nueva'} cuenta por pagar</h2><form class="form" id="f">
    <label class="todo">Proveedor<select name="proveedor_id"><option value="">— Elija —</option>${P.map((p) => `<option value="${p.id}" ${String(p.id) === String(c.proveedor_id) ? 'selected' : ''}>${esc(p.nombre)}</option>`).join('')}</select></label>
    <label class="todo">Concepto (qué se debe) *<input name="concepto" value="${esc(c.concepto)}" placeholder="Proteína, agua, refacción de caminadora…" required></label>
    <label>Factura / nota<input name="factura" value="${esc(c.factura || '')}"></label>
    <label>Clasificación<select name="categoria">${g.categorias.map((x) => `<option ${x === c.categoria ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select></label>
    <label>Monto que se debe *<input name="monto" type="number" step="0.01" min="0.01" value="${c.monto || ''}" required></label>
    <label>Fecha de la factura<input name="fecha" type="date" value="${esc(c.fecha || hoyStr())}"></label>
    <label class="todo">Fecha límite de pago<input name="vence" type="date" value="${esc(c.vence || '')}"></label>
    <label class="todo">Notas<input name="notas" value="${esc(c.notas || '')}" placeholder="Crédito a 15 días, cuenta para depósito…"></label>
    ${P.length ? '' : '<div class="aviso todo">Primero da de alta al proveedor con "+ Proveedor" (o déjalo vacío).</div>'}
    <div class="modal-pie todo">${c.id && !c.pagado ? '<button type="button" class="btn peligro" id="bCancelar">Cancelar cuenta</button>' : ''}<button type="button" class="btn" data-cerrar>Cerrar</button><button class="btn primario">Guardar</button></div></form>`);
  $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => { await api('/api/cuentas-pagar' + (c.id ? '/' + c.id : ''), valores(e.target), c.id ? 'PUT' : 'POST'); m.cerrar(); toast('Cuenta guardada', 'ok'); listo(); }, $('.primario', m)); };
  $('#bCancelar', m) && ($('#bCancelar', m).onclick = async () => { if (await confirmar('La cuenta se cancelará (no tiene pagos).', 'Sí, cancelar')) intentar(async () => { await api('/api/cuentas-pagar/' + c.id, {}, 'DELETE'); m.cerrar(); toast('Cuenta cancelada', 'ok'); listo(); }); });
}
async function verCxp(id, listo) {
  const c = await api('/api/cuentas-pagar/' + id);
  const m = modal(`<h2>Cuenta por pagar · ${esc(c.proveedor || 'Sin proveedor')}</h2>
    <p><span class="etq ${EST_CXP[c.estado]?.[1] || ''}">${EST_CXP[c.estado]?.[0] || c.estado}</span> <span class="muted">${diasCxp(c)}</span></p>
    <table><tr><td>Concepto</td><td><b>${esc(c.concepto)}</b></td></tr><tr><td>Factura</td><td>${esc(c.factura || '—')}</td></tr><tr><td>Clasificación</td><td>${esc(c.categoria || '')}</td></tr>
      <tr><td>Fecha</td><td>${fecha(c.fecha)}</td></tr><tr><td>Fecha límite</td><td>${c.vence ? fecha(c.vence) : '—'}</td></tr>${c.notas ? `<tr><td>Notas</td><td>${esc(c.notas)}</td></tr>` : ''}
      <tr><td>Monto</td><td class="num">${dinero(c.monto)}</td></tr><tr><td>Pagado</td><td class="num">${dinero(c.pagado)}</td></tr><tr><td><b>Debe</b></td><td class="num"><b class="${c.saldo > 0 ? 'rojo' : 'verde'}" style="font-size:20px">${dinero(c.saldo)}</b></td></tr></table>
    <h3 style="margin-top:14px">Pagos</h3>${c.pagos.length ? `<table>${c.pagos.map((p) => `<tr><td>${fechaHora(p.fecha)}</td><td>${p.pagado_con === 'caja' ? 'De la caja' : 'Por fuera de la caja'}${p.notas ? ' · ' + esc(p.notas) : ''}</td><td>${esc(p.usuario || '')}</td><td class="num">${dinero(p.monto)}</td></tr>`).join('')}</table>` : '<p class="muted">Sin pagos.</p>'}
    <div class="modal-pie"><button class="btn" data-cerrar>Cerrar</button><button class="btn" id="bEd">Editar</button>${c.saldo > 0 ? '<button class="btn primario" id="bPg">Pagar</button>' : ''}</div>`);
  $('#bEd', m).onclick = () => { m.cerrar(); modalCxp(c, listo); };
  $('#bPg', m) && ($('#bPg', m).onclick = () => { m.cerrar(); pagarCxp(id, listo); });
}
async function pagarCxp(id, listo) {
  const c = await api('/api/cuentas-pagar/' + id);
  const m = modal(`<h2>Pagar a ${esc(c.proveedor || 'proveedor')}</h2>
    <table><tr><td>Concepto</td><td><b>${esc(c.concepto)}${c.factura ? ' · ' + esc(c.factura) : ''}</b></td></tr><tr><td>Debe</td><td><b>${dinero(c.saldo)}</b></td></tr><tr><td>Fecha límite</td><td>${c.vence ? fecha(c.vence) + ' (' + diasCxp(c) + ')' : '—'}</td></tr></table>
    <form class="form" id="f" style="margin-top:12px">
      <label>Monto que paga<input name="monto" type="number" step="0.01" min="0.01" max="${c.saldo}" value="${c.saldo.toFixed(2)}" required autofocus></label>
      <label>Fecha<input name="fecha" type="date" value="${hoyStr()}"></label>
      <label class="todo">¿Con qué se pagó?<select name="pagado_con"><option value="fuera">Por fuera de la caja (transferencia, el dueño)</option>${puede('movimientos') ? '<option value="caja">Con dinero de la caja (se descuenta del corte)</option>' : ''}</select></label>
      <label class="todo">Nota<input name="notas" placeholder="Folio de transferencia, quién pagó…"></label>
      <p class="muted todo" style="margin:0">Se registra en Gastos a nombre del proveedor. Si paga menos del total queda como abono.</p>
      <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Registrar pago</button></div></form>`);
  $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => {
    const r = await api(`/api/cuentas-pagar/${id}/pagar`, valores(e.target)); m.cerrar();
    toast(r.saldo > 0 ? 'Abono registrado. Todavía se deben ' + dinero(r.saldo) : 'Cuenta pagada', 'ok'); listo();
  }, $('.primario', m)); };
}

// ===================== Empleados: sueldos, nómina, vacaciones y descansos =====================
const DIAS_SEM = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo', 'Rota (varía)'];
let empMes = hoyStr().slice(0, 7);
VISTAS.empleados = async (v) => {
  const d = await api('/api/empleados?mes=' + empMes);
  const T = d.tipos, P = d.periodos;
  const sumDias = (t) => d.dias.filter((x) => x.tipo === t).reduce((a, x) => a + x.en_periodo, 0);
  v.innerHTML = `<div class="encabezado"><h1>Empleados</h1><label class="fila">Mes <input type="month" id="mes" value="${d.mes}" style="width:auto"></label>
      <button class="btn" id="bXls">📊 Excel</button><button class="btn" id="bPdf">📄 PDF</button><button class="btn primario" id="bNuevo">+ Nuevo empleado</button></div>
    <div class="rejilla cols-4">
      <div class="kpi"><small>Empleados activos</small><b>${d.activos}</b></div>
      <div class="kpi"><small>Nómina mensual estimada</small><b>${dinero(d.nomina_mensual)}</b></div>
      <div class="kpi"><small>Sueldos pagados en el mes</small><b>${dinero(d.total)}</b></div>
      <div class="kpi"><small>Vacaciones · descansos · faltas</small><b>${sumDias('vacaciones')} · ${sumDias('descanso')} · ${sumDias('falta')}</b></div></div>
    <div class="panel" style="margin-top:16px"><div class="tabla-scroll"><table><tr><th>Empleado</th><th class="num">Sueldo</th><th>Descansa</th><th class="num">Pagado en el mes</th><th class="num">Vacaciones del año</th><th class="num">En el mes</th><th></th></tr>
      ${d.empleados.map((e) => `<tr style="${e.activo ? '' : 'opacity:.5'}"><td><b>${esc(e.nombre)}</b>${e.activo ? '' : ' <span class="etq sin">Baja</span>'}<br><small class="muted">${esc(e.puesto || '')}${e.telefono ? ' · ' + esc(e.telefono) : ''}</small></td>
        <td class="num">${dinero(e.sueldo)}<br><small class="muted">${P[e.periodo] || ''}</small></td><td>${esc(e.descanso || '—')}</td>
        <td class="num"><b>${dinero(e.pagado)}</b>${e.pagos_n ? `<br><small class="muted">${e.pagos_n} pago(s)</small>` : ''}</td>
        <td class="num">${e.vac_usadas} de ${e.vac_dias}<br><small class="${e.vac_restan < 0 ? 'rojo' : 'muted'}">Le quedan ${e.vac_restan}</small></td>
        <td class="num"><small>${[['vacaciones', 'vac.'], ['descansos', 'desc.'], ['faltas', 'faltas'], ['permisos', 'perm.'], ['incapacidades', 'incap.']].filter(([k]) => e[k]).map(([k, n]) => `${e[k]} ${n}`).join(' · ') || '—'}</small></td>
        <td class="fila" style="justify-content:flex-end">${e.activo ? `<button class="btn chico primario" data-pagar="${e.id}">💵 Pagar</button><button class="btn chico" data-dia="${e.id}">📅 Día</button>` : ''}<button class="btn chico" data-ed="${e.id}">✏️</button></td></tr>`).join('') || '<tr><td colspan="7" class="vacio">Todavía no hay empleados. Presiona "Nuevo empleado".</td></tr>'}</table></div></div>
    <div class="rejilla cols-2" style="margin-top:16px">
      <div class="panel"><h2>Vacaciones, descansos y faltas</h2><table>${d.dias.map((x) => `<tr><td><b>${esc(x.empleado)}</b><br><small class="muted">${T[x.tipo]}${x.goce ? '' : ' · sin goce de sueldo'}${x.notas ? ' · ' + esc(x.notas) : ''}</small></td><td>${fecha(x.desde)}${x.hasta !== x.desde ? ' al ' + fecha(x.hasta) : ''}</td><td class="num">${x.dias} día(s)</td><td><button class="btn chico" data-qd="${x.id}" title="Quitar">✕</button></td></tr>`).join('') || '<tr><td class="vacio">Nada registrado este mes.</td></tr>'}</table></div>
      <div class="panel"><h2>Pagos de nómina</h2><table>${d.pagos.map((g) => `<tr><td>${fecha(g.fecha)}</td><td>${esc(g.nombre)}<br><small class="muted">${g.pagado_con === 'caja' ? 'Con dinero de la caja' : 'Por fuera de la caja'}</small></td><td class="num"><b>${dinero(g.monto)}</b></td></tr>`).join('') || '<tr><td class="vacio">Sin pagos este mes.</td></tr>'}
        ${d.pagos.length ? `<tr><th colspan="2">TOTAL</th><th class="num">${dinero(d.total)}</th></tr>` : ''}</table><p class="muted" style="margin:8px 0 0;font-size:13px">Cada pago se guarda también en Gastos (categoría Sueldos y nómina) y entra al cierre de mes.</p></div></div>`;
  const recargar = () => VISTAS.empleados(v);
  const rango = () => { const [y, m] = empMes.split('-').map(Number); return [`${empMes}-01`, `${empMes}-${String(new Date(y, m, 0).getDate()).padStart(2, '0')}`]; };
  $('#mes').onchange = (e) => { empMes = e.target.value || hoyStr().slice(0, 7); recargar(); };
  $('#bXls').onclick = (e) => intentar(() => exportarReporte('empleados', ...rango()), e.currentTarget);
  $('#bPdf').onclick = (e) => intentar(async () => { await generarReportePdf('empleados', ...rango(), { gym: estado.config.gym_nombre, api }); toast('PDF descargado', 'ok'); }, e.currentTarget);
  $('#bNuevo').onclick = () => modalEmpleado(null, d, recargar);
  $$('[data-ed]', v).forEach((b) => b.onclick = () => modalEmpleado(d.empleados.find((e) => e.id == b.dataset.ed), d, recargar));
  $$('[data-pagar]', v).forEach((b) => b.onclick = () => modalPagoEmpleado(d.empleados.find((e) => e.id == b.dataset.pagar), d, recargar));
  $$('[data-dia]', v).forEach((b) => b.onclick = () => modalDiaEmpleado(d.empleados.find((e) => e.id == b.dataset.dia), d, recargar));
  $$('[data-qd]', v).forEach((b) => b.onclick = async () => { if (await confirmar('Se quitará este registro.', 'Sí, quitar')) intentar(async () => { await api('/api/empleados/dias/' + b.dataset.qd, {}, 'DELETE'); recargar(); }); });
};
function modalEmpleado(e, d, listo) {
  e = e || { periodo: 'quincenal', vac_dias: 12, activo: 1 };
  const m = modal(`<h2>${e.id ? 'Editar' : 'Nuevo'} empleado</h2><form class="form" id="f">
    <label class="todo">Nombre completo *<input name="nombre" value="${esc(e.nombre || '')}" required autofocus></label>
    <label>Puesto<input name="puesto" value="${esc(e.puesto || '')}" placeholder="Ej. Recepción, Instructor, Limpieza"></label>
    <label>Teléfono<input name="telefono" value="${esc(e.telefono || '')}"></label>
    <label>Sueldo por periodo<input name="sueldo" type="number" step="0.01" min="0" value="${e.sueldo ?? ''}" placeholder="0.00"></label>
    <label>Se le paga<select name="periodo">${Object.entries(d.periodos).map(([k, n]) => `<option value="${k}" ${e.periodo === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
    <label>Día de descanso<select name="descanso"><option value="">—</option>${DIAS_SEM.map((x) => `<option ${e.descanso === x ? 'selected' : ''}>${x}</option>`).join('')}</select></label>
    <label>Fecha de ingreso<input name="ingreso" type="date" value="${esc(e.ingreso || '')}"></label>
    <label>Días de vacaciones al año<input name="vac_dias" type="number" step="0.5" min="0" value="${e.vac_dias ?? 12}"></label>
    <label class="todo">Notas<input name="notas" value="${esc(e.notas || '')}"></label>
    ${e.id ? `<label class="chk todo"><input type="checkbox" name="activo" ${e.activo ? 'checked' : ''}> Trabaja actualmente (quítalo si se dio de baja)</label>` : ''}
    <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`);
  $('#f', m).onsubmit = (ev) => { ev.preventDefault(); const x = valores(ev.target); if (!e.id) x.activo = true;
    intentar(async () => { await api('/api/empleados' + (e.id ? '/' + e.id : ''), x, e.id ? 'PUT' : 'POST'); m.cerrar(); toast('Empleado guardado', 'ok'); listo(); }, $('.primario', m)); };
}
function modalPagoEmpleado(e, d, listo) {
  const per = { semanal: 'Sueldo semanal', quincenal: 'Sueldo quincenal', mensual: 'Sueldo mensual' }[e.periodo] || 'Sueldo';
  const m = modal(`<h2>💵 Pagar a ${esc(e.nombre)}</h2><form class="form" id="f">
    <label class="todo">Concepto<input name="concepto" value="${per}" placeholder="Ej. 1a quincena de octubre, aguinaldo, horas extra"></label>
    <label>Monto<input name="monto" type="number" step="0.01" min="0.01" value="${e.sueldo || ''}" required autofocus></label>
    <label>Fecha<input name="fecha" type="date" value="${hoyStr()}"></label>
    <label class="todo">¿Con qué se pagó?<select name="pagado_con"><option value="fuera">Por fuera de la caja (banco, transferencia, el dueño)</option>${puede('movimientos') ? '<option value="caja">Con dinero de la caja (se descuenta del corte)</option>' : ''}</select></label>
    <label class="todo">Notas<input name="notas" placeholder="Opcional"></label>
    <p class="muted todo" style="margin:0">Se guarda en Gastos como "Sueldos y nómina" y sale en el cierre de mes.</p>
    <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Registrar pago</button></div></form>`);
  $('#f', m).onsubmit = (ev) => { ev.preventDefault(); intentar(async () => { await api(`/api/empleados/${e.id}/pago`, valores(ev.target)); m.cerrar(); toast('Pago registrado', 'ok'); listo(); }, $('.primario', m)); };
  if (typeof asistenciaParaPago === 'function') asistenciaParaPago(e, m);
}
function modalDiaEmpleado(e, d, listo) {
  const m = modal(`<h2>📅 ${esc(e.nombre)}</h2><form class="form" id="f">
    <label class="todo">¿Qué se registra?<select name="tipo">${Object.entries(d.tipos).map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select></label>
    <label>Desde<input name="desde" type="date" value="${hoyStr()}" required></label>
    <label>Hasta<input name="hasta" type="date" value="${hoyStr()}"></label>
    <label class="chk todo"><input type="checkbox" name="goce" checked> Con goce de sueldo (se le paga ese día)</label>
    <label class="todo">Notas<input name="notas" placeholder="Opcional (ej. cubre Juan)"></label>
    <p class="muted todo" style="margin:0" id="vacInfo">Vacaciones del año: usó ${e.vac_usadas} de ${e.vac_dias}, le quedan <b>${e.vac_restan}</b>.</p>
    <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`);
  $('[name=tipo]', m).onchange = (ev) => { $('[name=goce]', m).checked = ev.target.value !== 'falta'; };
  $('#f', m).onsubmit = (ev) => { ev.preventDefault(); const x = valores(ev.target); x.goce = $('[name=goce]', m).checked;
    intentar(async () => { await api(`/api/empleados/${e.id}/dias`, x); m.cerrar(); toast('Guardado', 'ok'); listo(); }, $('.primario', m)); };
}

VISTAS.reportes = async (v) => {
  v.innerHTML = `<div class="encabezado"><h1>Reportes</h1><label class="fila">Del <input type="date" id="d" value="${hoyStr().slice(0, 8)}01" style="width:auto"></label><label class="fila">al <input type="date" id="h" value="${hoyStr()}" style="width:auto"></label></div>
    <div class="panel" style="margin-bottom:16px"><h2>📅 Cierre de mes</h2><p class="muted" style="margin-top:0">Resumen completo del mes para el dueño o el contador: ventas, formas de pago, unidades de negocio (gráfica de pastel y comparación con meses anteriores), departamentos, membresías, productos, gastos fijos y varios, empleados y nómina, retiros, cortes, socios e inventario. Se puede descargar en Excel o en PDF.</p>
      <div class="fila" style="align-items:center"><label class="fila">Mes <input type="month" id="mesCierre" value="${hoyStr().slice(0, 7)}" max="${hoyStr().slice(0, 7)}" style="width:auto"></label>
        <button class="btn grande primario" id="bCierreXls">📊 Cierre en Excel</button><button class="btn grande" id="bCierrePdf">📄 Cierre en PDF</button>
        <small class="muted">También puedes usar las fechas de arriba: <a href="#" id="bCierreRango">cierre del periodo elegido</a></small></div></div>
    <div class="panel" style="margin-bottom:16px"><h2>⬇ Exportar a Excel</h2><p class="muted" style="margin-top:0">Cada reporte se descarga en su propio archivo de Excel con las fechas elegidas arriba.</p>
      <div class="rejilla cols-3">${REPORTES_EXCEL.filter((r) => r.tipo !== 'cierre' && modOn(r.modulo)).map((r) => `<div class="fila" style="gap:6px;flex-wrap:nowrap"><button class="btn grande ${r.tipo === 'ventas' ? 'primario' : ''}" data-x="${r.tipo}" title="${esc(r.desc + (r.sinFechas ? ' (al día de hoy)' : ''))}" style="justify-content:flex-start;text-align:left;white-space:normal;flex:1">${r.icono} ${esc(r.nombre)}</button>${r.pdf ? `<button class="btn grande" data-pdf="${r.tipo}" title="Descargar en PDF">PDF</button>` : ''}</div>`).join('')}
      </div></div>
    <div class="panel" style="margin-bottom:16px"><h2>🥧 Unidades de negocio</h2><p class="muted" style="margin-top:0">Cuánto aporta cada unidad (membresías y cada departamento de la tienda) al total vendido en las fechas elegidas, y cómo ha cambiado en los últimos meses.</p>
      <div class="rejilla cols-2"><div id="uniPastel"></div><div><h3>Últimos 6 meses</h3><div id="uniMeses"></div></div></div><div id="uniDep" style="margin-top:12px"></div></div>
    <div id="cont"></div>`;
  $$('[data-x]', v).forEach((b) => b.onclick = (e) => intentar(() => exportarReporte(b.dataset.x, $('#d').value, $('#h').value), e.currentTarget));
  $$('[data-pdf]', v).forEach((b) => b.onclick = (e) => intentar(async () => { await generarReportePdf(b.dataset.pdf, $('#d').value, $('#h').value, { gym: estado.config.gym_nombre, api }); toast('PDF descargado', 'ok'); }, e.currentTarget));
  const rangoMes = () => { const m = $('#mesCierre').value; if (!m) throw new Error('Elige el mes'); const [y, mm] = m.split('-').map(Number); const fin = new Date(y, mm, 0).getDate(); return [`${m}-01`, `${m}-${String(fin).padStart(2, '0')}`]; };
  $('#bCierreXls').onclick = (e) => intentar(async () => { const [a, b] = rangoMes(); await exportarReporte('cierre', a, b); }, e.currentTarget);
  $('#bCierrePdf').onclick = (e) => intentar(async () => { const [a, b] = rangoMes(); await generarReportePdf('cierre', a, b, { gym: estado.config.gym_nombre, api }); toast('PDF descargado', 'ok'); }, e.currentTarget);
  $('#bCierreRango').onclick = (e) => { e.preventDefault(); intentar(async () => { await generarReportePdf('cierre', $('#d').value, $('#h').value, { gym: estado.config.gym_nombre, api }); await exportarReporte('cierre', $('#d').value, $('#h').value); }); };
  const cargar = async () => {
    const r = await api(`/api/reportes?desde=${$('#d').value}&hasta=${$('#h').value}`);
    api(`/api/reportes/excel?tipo=unidades&desde=${$('#d').value}&hasta=${$('#h').value}`).then((u) => {
      const ult6 = { unidades: u.meses.unidades, meses: u.meses.meses.slice(-6) };
      $('#uniPastel').innerHTML = graficaPastel(u.unidades, u.meses.unidades);
      $('#uniMeses').innerHTML = graficaComparativo(ult6);
      $('#uniDep').innerHTML = u.departamentos.length ? `<h3>Ventas por departamento de la tienda</h3><div class="tabla-scroll"><table><tr><th>Departamento</th><th class="num">Piezas</th><th class="num">Vendido</th><th class="num">Ganancia</th></tr>${u.departamentos.map((x) => `<tr><td>${esc(x.departamento)}</td><td class="num">${x.cantidad}</td><td class="num">${dinero(x.importe)}</td><td class="num">${dinero(x.utilidad)}</td></tr>`).join('')}</table></div>` : '';
    }).catch(() => {});
    const util = r.productos.reduce((s, p) => s + p.utilidad, 0);
    $('#cont').innerHTML = `<div class="rejilla cols-4">
        <div class="kpi"><small>Ventas totales (${r.ventas.n})</small><b>${dinero(r.ventas.total)}</b></div>
        <div class="kpi"><small>Abonos cobrados</small><b>${dinero(r.abonos.total)}</b></div>
        <div class="kpi"><small>Ganancia en productos</small><b>${dinero(util)}</b></div>
        <div class="kpi"><small>Clientes nuevos</small><b>${r.nuevos}</b></div></div>
      <div class="rejilla cols-2" style="margin-top:16px">
        <div class="panel"><h2>Forma de pago</h2><table><tr><td>Efectivo (neto)</td><td class="num">${dinero(r.ventas.efectivo)}</td></tr><tr><td>Dólares</td><td class="num">${usd(r.ventas.usd)} <small class="muted">≈ ${dinero(r.ventas.usd_mxn)}</small></td></tr>
          <tr><td>Tarjeta</td><td class="num">${dinero(r.ventas.tarjeta)}</td></tr><tr><td>Transferencia</td><td class="num">${dinero(r.ventas.transferencia)}</td></tr><tr><td>A crédito</td><td class="num">${dinero(r.ventas.credito)}</td></tr></table></div>
        <div class="panel"><h2>Membresías vendidas</h2><table><tr><th>Plan</th><th>Promoción</th><th class="num">Cant.</th><th class="num">Importe</th></tr>${r.membresias.map((m) => `<tr><td>${esc(m.plan)}</td><td>${esc(m.promo)}</td><td class="num">${m.n}</td><td class="num">${dinero(m.total)}</td></tr>`).join('') || '<tr><td colspan="4" class="vacio">—</td></tr>'}</table></div>
        <div class="panel"><h2>Productos vendidos</h2><table><tr><th>Producto</th><th class="num">Cant.</th><th class="num">Importe</th><th class="num">Ganancia</th></tr>${r.productos.map((p) => `<tr><td>${esc(p.descripcion)}</td><td class="num">${p.cantidad}</td><td class="num">${dinero(p.importe)}</td><td class="num">${dinero(p.utilidad)}</td></tr>`).join('') || '<tr><td colspan="4" class="vacio">—</td></tr>'}</table></div>
        <div class="panel"><h2>Retiros, gastos y entradas</h2><table><tr><th>Tipo</th><th>Categoría</th><th class="num">Cant.</th><th class="num">Total</th></tr>${r.movimientos.map((x) => `<tr><td>${TIPOS_MOV[x.tipo]?.nombre || x.tipo}</td><td>${esc(x.categoria || '')}</td><td class="num">${x.n}</td><td class="num ${x.tipo === 'entrada' ? '' : 'rojo'}">${dinero(x.total)}</td></tr>`).join('') || '<tr><td colspan="4" class="vacio">—</td></tr>'}</table></div>
        <div class="panel"><h2>Asistencia por día</h2><table><tr><th>Día</th><th class="num">Personas</th><th class="num">Accesos negados</th></tr>${r.visitas.map((x) => `<tr><td>${fecha(x.dia)}</td><td class="num">${x.personas}</td><td class="num">${x.negados || ''}</td></tr>`).join('') || '<tr><td colspan="3" class="vacio">—</td></tr>'}</table></div>
      </div>`;
  };
  $('#d').onchange = cargar; $('#h').onchange = cargar; cargar();
};

// ---------- Reportes en Excel (uno por archivo; el código está en reportes.js) ----------
async function exportarReporte(tipo, d, h) {
  await generarReporteExcel(tipo, d, h, { gym: estado.config.gym_nombre, api });
  toast('Excel descargado', 'ok');
}

// ===================== Usuarios =====================
VISTAS.usuarios = async (v) => {
  const [lista, P] = await Promise.all([api('/api/usuarios'), api('/api/permisos')]);
  const ROL = { cajero: 'Cajero', gerente: 'Gerente', admin: 'Administrador' };
  v.innerHTML = `<div class="encabezado"><h1>Usuarios y permisos</h1><button class="btn primario" id="n">+ Nuevo usuario</button></div>
    <div class="panel"><table><tr><th>Nombre</th><th>Usuario</th><th>Rol</th><th>Permisos</th><th>Estado</th><th></th></tr>${lista.map((u) => `<tr style="${u.activo ? '' : 'opacity:.5'}"><td><b>${esc(u.nombre)}</b></td><td>${esc(u.usuario)}</td><td>${ROL[u.rol]}</td>
      <td>${u.rol === 'admin' ? '<span class="etq activo">Todos</span>' : `${u.permisos.length} de ${P.lista.length - 2}${u.personalizado ? ' <span class="etq por_vencer">Personalizados</span>' : ' <span class="etq sin">Los del rol</span>'}`}</td>
      <td>${u.activo ? 'Activo' : 'Desactivado'}</td><td><button class="btn chico" data-id="${u.id}">Editar</button></td></tr>`).join('')}</table>
    <p class="muted" style="margin-top:12px">El <b>rol</b> pone los permisos sugeridos (Cajero o Gerente) y tú puedes activar o quitar cada uno. El <b>Administrador</b> siempre tiene todos los permisos.</p></div>`;
  const grupos = [...new Set(P.lista.map((x) => x.grupo))];
  const editar = (u) => {
    u = u || { rol: 'cajero', activo: 1, permisos: P.roles.cajero };
    const m = modal(`<h2>${u.id ? 'Editar' : 'Nuevo'} usuario</h2><form id="f">
      <div class="form">
        <label class="todo">Nombre<input name="nombre" value="${esc(u.nombre || '')}" required autofocus></label>
        <label>Usuario (para entrar)<input name="usuario" value="${esc(u.usuario || '')}" ${u.id ? 'disabled' : 'required'}></label>
        <label>Rol<select name="rol">${Object.entries(ROL).map(([r, t]) => `<option value="${r}" ${r === u.rol ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
        <label class="todo">${u.id ? 'Nueva contraseña (déjala vacía para no cambiarla)' : 'Contraseña'}<input name="password" type="password" ${u.id ? '' : 'required'}></label>
        ${u.id ? `<label class="chk todo"><input type="checkbox" name="activo" ${u.activo ? 'checked' : ''}> Usuario activo (puede entrar al sistema)</label>` : ''}
      </div>
      <div class="encabezado" style="margin:18px 0 10px"><h2 style="margin:0;margin-right:auto">¿Qué puede hacer?</h2>
        <button type="button" class="btn chico" id="pRol">Usar los del rol</button><button type="button" class="btn chico" id="pTodos">Marcar todo</button><button type="button" class="btn chico" id="pNada">Quitar todo</button></div>
      <div id="avisoAdmin" class="aviso verde oculto">El Administrador tiene todos los permisos.</div>
      <div class="permisos" id="perms">${grupos.map((g) => `<fieldset><legend>${g}</legend>${P.lista.filter((x) => x.grupo === g).map((x) => {
        const soloAdmin = x.clave === 'usuarios' || x.clave === 'config';
        return `<label class="chk"><input type="checkbox" data-p="${x.clave}" ${soloAdmin ? 'disabled' : ''}> <span>${esc(x.texto)}${soloAdmin ? ' <small class="muted">(solo Administrador)</small>' : ''}</span></label>`;
      }).join('')}</fieldset>`).join('')}</div>
      <div class="modal-pie"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`, { ancho: true });
    const marcar = (l) => $$('[data-p]', m).forEach((c) => { if (!c.disabled) c.checked = l.includes(c.dataset.p); });
    const rolSel = $('[name=rol]', m);
    const pintarRol = () => {
      const admin = rolSel.value === 'admin';
      $('#avisoAdmin', m).classList.toggle('oculto', !admin);
      $('#perms', m).style.opacity = admin ? 0.45 : 1;
      $$('[data-p]', m).forEach((c) => { if (!['usuarios', 'config'].includes(c.dataset.p)) c.disabled = admin; if (admin) c.checked = true; });
    };
    marcar(u.permisos || []); pintarRol();
    rolSel.onchange = () => { marcar(P.roles[rolSel.value] || []); pintarRol(); };
    $('#pRol', m).onclick = () => marcar(P.roles[rolSel.value] || []);
    $('#pTodos', m).onclick = () => marcar(P.lista.map((x) => x.clave));
    $('#pNada', m).onclick = () => marcar([]);
    $('#f', m).onsubmit = (e) => {
      e.preventDefault();
      const d = valores(e.target);
      d.permisos = $$('[data-p]', m).filter((c) => c.checked && !['usuarios', 'config'].includes(c.dataset.p)).map((c) => c.dataset.p);
      intentar(async () => { await api('/api/usuarios' + (u.id ? '/' + u.id : ''), d, u.id ? 'PUT' : 'POST'); m.cerrar(); toast('Usuario guardado', 'ok'); enrutar(); });
    };
  };
  $('#n').onclick = () => editar();
  $$('[data-id]', v).forEach((b) => b.onclick = () => editar(lista.find((u) => u.id == b.dataset.id)));
};

// ===================== Configuración =====================
VISTAS.config = async (v) => {
  const c = await api('/api/config');
  const campo = (k, l, t = 'text', extra = '') => `<label>${l}<input name="${k}" type="${t}" value="${esc(c[k])}" ${extra}></label>`;
  v.innerHTML = `<div class="encabezado"><h1>Configuración</h1></div><form id="f" class="rejilla">
    <div class="panel"><h2>Gimnasio y tickets</h2><div class="form">${campo('gym_nombre', 'Nombre del gimnasio')}${campo('gym_telefono', 'Teléfono')}
      <label class="todo">Dirección<input name="gym_direccion" value="${esc(c.gym_direccion)}"></label>${campo('ticket_pie', 'Mensaje al pie del ticket')}${campo('lada', 'Lada del país para WhatsApp (México = 52)')}
      <label>Formato del ticket<select name="ticket_formato"><option value="completo" ${c.ticket_formato !== 'simple' ? 'selected' : ''}>Completo: dirección, cajero, cliente y desglose de pagos</option><option value="simple" ${c.ticket_formato === 'simple' ? 'selected' : ''}>Simplificado: solo lo vendido, total y forma de pago (más corto)</option></select></label>
      <label>Imprimir el ticket automáticamente al cobrar<select name="imprimir_auto"><option value="1" ${c.imprimir_auto !== '0' ? 'selected' : ''}>Sí: todo cobro imprime su ticket (recomendado)</option><option value="0" ${c.imprimir_auto === '0' ? 'selected' : ''}>No: el cajero elige "Cobrar sin imprimir" (F2)</option></select></label>
      <label>Logo del gimnasio en el ticket<select name="ticket_logo"><option value="0" ${c.ticket_logo !== '1' ? 'selected' : ''}>No</option><option value="1" ${c.ticket_logo === '1' ? 'selected' : ''}>Sí (si la impresora lo soporta)</option></select></label>
      <label>Logo de Maxsel (chico) al final del ticket<select name="ticket_logo_maxsel"><option value="1" ${c.ticket_logo_maxsel !== '0' ? 'selected' : ''}>Sí</option><option value="0" ${c.ticket_logo_maxsel === '0' ? 'selected' : ''}>No</option></select></label>
      <label class="todo">Contacto de Maxsel al final del ticket (un renglón por línea, ej. WhatsApp, Facebook)<textarea name="maxsel_contacto" rows="2" placeholder="WhatsApp 664 000 0000&#10;facebook.com/maxsel">${esc(c.maxsel_contacto || '')}</textarea></label>
      </div>
      <h3 style="margin-top:16px">🖼️ Logo del gimnasio</h3>
      <p class="muted" style="margin-top:0">Se muestra en la pantalla del cliente, en el panel del celular y, si lo activas, en el ticket. Usa JPG o PNG (ideal: fondo blanco o transparente).</p>
      <div class="fila" style="align-items:center;gap:16px"><div id="logoPrev" style="height:90px;min-width:120px;border:1px dashed var(--borde);border-radius:10px;display:grid;place-items:center;background:#fff;padding:6px"></div>
        <div class="fila"><label class="btn" style="cursor:pointer">📁 Subir logo<input type="file" id="logoArch" accept="image/*" style="display:none"></label><button type="button" class="btn" id="logoQuitar">Quitar logo</button></div></div></div>
    <div class="panel"><h2>🖥️ Pantalla del cliente (segundo monitor)</h2>
      <p class="muted" style="margin-top:0">Es la pantalla que ve el cliente al llegar: le dice si su acceso fue <b>aceptado o negado</b>, hasta cuándo es su membresía, <b>sus últimas visitas</b> y <b>si debe algo</b> en la tienda (qué producto, qué día y a qué hora).</p>
      <div class="rejilla cols-2">
        <div><h3>Cómo instalarla</h3><ol class="pasos">
          <li>Conecta el segundo monitor (o una TV) a la computadora de recepción y colócalo junto a la entrada, a la vista del cliente.</li>
          <li>En Windows presiona <kbd>Windows</kbd> + <kbd>P</kbd> y elige <b>Extender</b>.</li>
          <li>Inicia sesión en el sistema en esta computadora (la pantalla usa esa misma sesión).</li>
          <li>Abre el icono <b>"Maxsel Gimnasios - Pantalla de acceso"</b> del escritorio (o el botón de abajo).</li>
          <li>Pasa la ventana al segundo monitor con <kbd>Windows</kbd> + <kbd>Shift</kbd> + <kbd>→</kbd> y presiona <kbd>F11</kbd> para pantalla completa.</li>
          <li>Haz clic una vez dentro de la pantalla para que se activen los sonidos.</li>
          <li>Presiona <b>Probar: acceso aceptado</b> para revisar que se vea bien.</li></ol>
          <div class="fila" style="margin-top:12px"><button type="button" class="btn" id="bAbrirPant">🖥️ Abrir pantalla del cliente</button>
            <button type="button" class="btn" id="bProbOk">✅ Probar: acceso aceptado</button><button type="button" class="btn" id="bProbNo">⛔ Probar: acceso negado</button></div>
          <p class="muted"><small>Para que aparezca sola al prender la computadora, copia el icono "Maxsel Gimnasios - Pantalla de acceso" a la carpeta de Inicio (<kbd>Windows</kbd> + <kbd>R</kbd>, escribe <b>shell:startup</b>).</small></p></div>
        <div><h3>Qué muestra</h3><div class="form" style="grid-template-columns:1fr">
          ${campo('pantalla_bienvenida', 'Mensaje en espera (cuando nadie está entrando)')}
          ${campo('pantalla_ok', 'Título cuando SÍ puede entrar')}
          ${campo('pantalla_no', 'Título cuando NO puede entrar')}
          ${campo('pantalla_segundos', 'Segundos que se queda el mensaje antes de volver a la espera', 'number', 'min="3" max="60"')}
          <label>Tamaño del logo del gimnasio en espera<select name="pantalla_logo_tam">${[['chico', 'Chico'], ['mediano', 'Mediano'], ['grande', 'Grande']].map(([v, t]) => `<option value="${v}" ${(c.pantalla_logo_tam || 'mediano') === v ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
          <label>Últimas visitas a mostrar<select name="pantalla_visitas">${[0, 3, 5, 8, 10].map((n) => `<option value="${n}" ${String(n) === String(c.pantalla_visitas) ? 'selected' : ''}>${n === 0 ? 'No mostrar' : n + ' visitas'}</option>`).join('')}</select></label>
          <label>Mostrar la cuenta pendiente en la tienda<select name="pantalla_deudas"><option value="1" ${c.pantalla_deudas !== '0' ? 'selected' : ''}>Sí: producto, día, hora y total</option><option value="0" ${c.pantalla_deudas === '0' ? 'selected' : ''}>No mostrar</option></select></label>
          <label>Texto cuando tiene cuenta pendiente<input name="pantalla_deuda_txt" list="txtDeuda" value="${esc(c.pantalla_deuda_txt)}"><datalist id="txtDeuda">${['Saldo pendiente', 'Cuenta pendiente', 'Tienes un saldo pendiente', 'Pendiente en tienda', 'Recuerda tu saldo', 'Saldo por liquidar'].map((t) => `<option value="${t}">`).join('')}</datalist></label>
          ${campo('pantalla_sin_deuda', 'Texto cuando no tiene cuenta pendiente')}
          <label>Sonido de aviso<select name="pantalla_sonido"><option value="1" ${c.pantalla_sonido !== '0' ? 'selected' : ''}>Sí</option><option value="0" ${c.pantalla_sonido === '0' ? 'selected' : ''}>No</option></select></label>
        </div><p class="muted"><small>Los cambios se aplican en la pantalla al presionar "Guardar configuración".</small></p></div>
      </div></div>
    <div class="panel"><h2>☁️ Monitoreo en la nube (desde cualquier lugar)</h2>
      <p class="muted" style="margin-top:0">El dueño ve desde su celular o cualquier computadora, en <b>${esc(URL_NUBE)}</b>, las <b>entradas y ventas del día</b>, sin instalar nada. La nube es <b>solo de consulta</b>: aquí no se puede cambiar nada. Solo se suben los totales del día (cada 5 minutos si hubo movimiento). Los reportes detallados y los Excel se generan aquí <b>únicamente cuando el dueño presiona "Actualizar"</b> en la página. Si esta computadora está apagada, la página muestra lo último que se subió.</p>
      <div id="nubeCaja" class="muted">Cargando…</div></div>
    <div class="panel oculto"><h2>📱 Ver ventas desde el celular con Tailscale (en tiempo real)</h2>
      <p class="muted" style="margin-top:0">El dueño ve desde <b>cualquier celular</b>, <b>en vivo</b> y <b>sin instalar nada en el celular</b>, lo que se vende, cómo pagaron, las cajas abiertas, los cortes, los accesos y lo que falta en la tienda. Se usa <b>Tailscale Funnel</b> (gratis): solo se publica el panel del celular, con contraseña y conexión segura (https). Es <b>solo lectura</b>: desde fuera no se puede cobrar ni cambiar nada.</p>
      <div id="movilAcceso" class="muted">Revisando Tailscale…</div></div>
    <div class="panel"><h2>Lector facial Hikvision DS-K1T671M</h2>
      <p id="estLec" class="muted"></p>
      <div class="form">
        <label class="chk"><input type="radio" name="hik_modo" value="simulador" ${c.hik_modo !== 'real' ? 'checked' : ''}> Modo simulador (para practicar sin lector)</label>
        <label class="chk"><input type="radio" name="hik_modo" value="real" ${c.hik_modo === 'real' ? 'checked' : ''}> Lector real conectado a la red</label>
        ${campo('hik_ip', 'IP del lector (ej. 192.168.1.64)')}${campo('hik_puerto', 'Puerto HTTP (normalmente 80; NO el 8000)', 'number')}
        ${campo('hik_usuario', 'Usuario del lector')}${campo('hik_password', 'Contraseña del lector', 'password', 'autocomplete="new-password"')}
        ${campo('hik_puerta', 'Número de puerta (normalmente 1)', 'number', 'min="1"')}
      </div>
      <div class="fila" style="margin-top:14px">
        <button type="button" class="btn primario" id="bGuardarLector">💾 Guardar datos del lector</button>
        <button type="button" class="btn" id="bProbar">🔌 Probar conexión</button>
        <button type="button" class="btn" id="bEventos">📡 Configurar envío de eventos</button>
        <button type="button" class="btn" id="bHora">🕒 Poner la hora de la PC en el lector</button>
        <button type="button" class="btn" id="bTodos">🔄 Enviar todos los clientes al lector</button>
        <button type="button" class="btn primario" id="bImportarLector">📥 Importar usuarios del lector</button>
        <button type="button" class="btn" id="bFotosPc">🖼️ Buscar fotos en esta computadora</button>
        <button type="button" class="btn" id="bDiag">🩺 Diagnóstico del lector</button>
      </div>
      <p class="muted" style="margin-top:10px">Los datos del lector se guardan solos al usar cualquiera de estos botones. El puerto web del lector casi siempre es <b>80</b> (el 8000 es del programa iVMS y no sirve aquí).</p></div>
    <div class="panel"><h2>Mensajes de WhatsApp</h2><p class="muted">Puedes usar {nombre}, {nombre_completo}, {fecha} y {gimnasio}.</p><div class="rejilla">
      <label>Membresía por vencer<textarea name="wa_vence" rows="2">${esc(c.wa_vence)}</textarea></label>
      <label>Membresía vencida<textarea name="wa_vencida" rows="2">${esc(c.wa_vencida)}</textarea></label>
      <label>Publicidad / promociones<textarea name="wa_publicidad" rows="2">${esc(c.wa_publicidad)}</textarea></label></div></div>
    <div class="panel"><h2>Licencia</h2><div id="licInfo" class="muted">Cargando…</div>
      <div class="fila" style="margin-top:12px"><button type="button" class="btn" id="bReiniciar">🔄 Reiniciar el sistema</button><small class="muted">Úsalo después de actualizar archivos; tarda unos segundos.</small></div></div>
    <div><button class="btn primario grande">Guardar configuración</button></div></form>
    <p class="ver-pie" id="verPie">Maxsel Gimnasios · versión ${esc(estado.yo?.version || '')} · Maxsel Sistemas de Punto de Venta</p>`;
  // Oculto (igual que Maxsel Tech): toca 7 veces seguidas la versión al final de Configuración.
  let toques = [];
  $('#verPie').addEventListener('click', () => { const t = Date.now(); toques = toques.filter((x) => t - x < 4000); toques.push(t); if (toques.length >= 7) { toques = []; modalReiniciarMaxsel(); } });
  api('/api/licencia/estado').then((l) => {
    $('#licInfo').innerHTML = `<p style="margin:0 0 6px"><b>${esc(l.producto)}</b> v${esc(l.version)}</p>
      <p style="margin:0 0 6px">Licenciado a: <b>${esc(l.cliente)}</b> · ${l.expira ? `Vence el <b>${fecha(l.expira)}</b> (${l.diasRestantes} días)` : '<b>Permanente</b>'}</p>
      <p style="margin:0 0 6px">Clientes: <b>${(l.clientes ?? 0).toLocaleString('es-MX')}</b> registrados${l.maxClientes ? ` de <b>${l.maxClientes.toLocaleString('es-MX')}</b> que permite la licencia${l.clientes >= l.maxClientes ? ' <span class="etq vencido">Lleno</span>' : l.clientes >= l.maxClientes * 0.9 ? ' <span class="etq por_vencer">Casi lleno</span>' : ''}` : ' · <b>sin límite</b>'}</p>
      <p style="margin:0">Código de equipo: <b style="font-family:Consolas,monospace;letter-spacing:2px">${esc(l.codigoEquipo)}</b>${l.huella ? ` · Huella: ${esc(l.huella)}` : ''}</p>
      <p style="margin:8px 0 0">Para renovar o ampliar a más clientes, comunícate con Maxsel y pega aquí la nueva licencia:</p><div class="fila" style="margin-top:6px"><input id="licNueva" placeholder="GY1-..." style="max-width:520px;font-family:Consolas,monospace"><button type="button" class="btn" id="licRenovar">Activar nueva licencia</button></div>`;
    $('#licRenovar') && ($('#licRenovar').onclick = (e) => intentar(async () => { await api('/api/licencia/activar', { clave: $('#licNueva').value }); toast('Licencia actualizada', 'ok'); enrutar(); }, e.target));
  });
  let avisoFunnel = '';
  const pintarMovil = async () => {
    const caja = $('#movilAcceso'); if (!caja) return;
    let d; try { d = await api('/api/movil/acceso'); } catch (e) { caja.textContent = e.message; return; }
    if (!$('#movilAcceso')) return;
    // Solo si el gimnasio ya trae Tailscale: si no, este panel no se muestra y el dueño usa la nube (Firebase) de arriba.
    caja.closest('.panel').classList.toggle('oculto', !d.instalado);
    if (!d.instalado) return;
    const paso = (t, txt, botones) => `<div class="panel" style="margin:0 0 10px;box-shadow:none;border:1px solid var(--borde)"><b>${t}</b><p class="muted" style="margin:6px 0 10px">${txt}</p><div class="fila">${botones}</div></div>`;
    let h = '';
    if (!d.conectado) {
      h = paso('Inicia sesión en Tailscale', 'Tailscale está instalado pero no ha iniciado sesión. Abre Tailscale (icono junto al reloj de Windows) y entra con la cuenta del dueño.',
        `${d.login ? `<a class="btn primario" href="${esc(d.login)}" target="_blank" rel="noopener">Iniciar sesión</a>` : ''}<button type="button" class="btn" data-rev>Volver a revisar</button>`);
    } else if (d.funnel.activo) {
      h = `<div class="aviso verde" style="margin-bottom:10px">✅ <b>Activo</b> · Tailscale conectado (${esc(d.nombre)})</div>
        <div style="display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap"><div class="funnel-qr">${d.qr}</div>
        <div style="flex:1;min-width:240px"><label>Dirección (ábrela en cualquier celular, con datos o cualquier Wi-Fi)<div class="fila" style="margin-top:4px"><input id="funnelUrl" readonly value="${esc(d.funnel.url)}" style="flex:1;font-family:Consolas,monospace"><button type="button" class="btn" id="funnelCp">Copiar</button></div></label>
        <p class="muted" style="margin:8px 0">Escanea el código con la cámara del celular y entra con un usuario que tenga el permiso <b>"Ver ventas y reportes en tiempo real desde el celular"</b> (el administrador y los gerentes lo tienen). Para tenerlo como app: Android <b>⋮ → Agregar a pantalla principal</b>; iPhone <b>Compartir → Agregar a inicio</b>.</p>
        <div class="fila"><a class="btn" href="/movil" target="_blank">👀 Ver cómo se ve</a><button type="button" class="btn" data-rev>🔄 Revisar</button><button type="button" class="btn" id="funnelOff">Desactivar</button></div></div></div>`;
    } else {
      h = `<div class="aviso verde" style="margin-bottom:10px">✅ Tailscale conectado (${esc(d.nombre)})</div>
        ${paso('Activa el acceso desde el celular', `Presiona <b>Activar</b> y la dirección <b style="font-family:Consolas,monospace">${esc(d.funnel.url)}</b> abrirá en cualquier celular, sin instalar nada en él.`,
        `<button type="button" class="btn primario" id="funnelOn">📱 Activar acceso desde el celular</button>`)}`;
    }
    if (avisoFunnel) h = `<div class="aviso" style="margin-bottom:10px">${avisoFunnel}</div>` + h;
    h += `<p class="muted" style="margin:6px 0 0"><small>Seguridad: por internet solo se ve el panel del celular (solo lectura). Cobrar, clientes, configuración, el lector y la base de datos no se pueden abrir desde fuera. Después de 6 contraseñas mal escritas se bloquea 15 minutos. Esta computadora debe estar encendida y con internet.</small></p>`;
    caja.innerHTML = h;
    $$('[data-rev]', caja).forEach((b) => { b.onclick = () => { caja.innerHTML = 'Revisando Tailscale…'; avisoFunnel = ''; pintarMovil(); }; });
    $('#funnelCp') && ($('#funnelCp').onclick = async () => { try { await navigator.clipboard.writeText(d.funnel.url); toast('Copiado', 'ok'); } catch { $('#funnelUrl').select(); } });
    const cambiar = async (on) => {
      caja.innerHTML = 'Configurando Tailscale… (puede tardar unos segundos)';
      try {
        const r = await api('/api/movil/funnel', { activar: on });
        if (r.habilitar) avisoFunnel = `<b>Falta un paso, solo la primera vez:</b> Tailscale pide permitir esto en tu cuenta. <a href="${esc(r.habilitar)}" target="_blank" rel="noopener">Abre este enlace</a>, entra con tu cuenta de Tailscale, dale <b>Enable</b> y regresa aquí a presionar <b>Activar</b> otra vez.`;
        else { avisoFunnel = ''; toast(on ? 'Acceso desde el celular activado' : 'Acceso desde el celular desactivado', 'ok'); }
      } catch (e) { avisoFunnel = esc(e.message); }
      pintarMovil();
    };
    $('#funnelOn') && ($('#funnelOn').onclick = () => cambiar(true));
    $('#funnelOff') && ($('#funnelOff').onclick = async () => { if (await confirmar('El celular dejará de poder ver las ventas por internet.', 'Sí, desactivar')) cambiar(false); });
  };
  pintarMovil();
  const pintarNube = async () => {
    const caja = $('#nubeCaja'); if (!caja) return;
    let e; try { e = await api('/api/nube/estado'); } catch (x) { caja.textContent = x.message; return; }
    const hace = (iso) => { if (!iso) return 'nunca'; const m = Math.round((Date.now() - Date.parse(iso)) / 60000); return m < 1 ? 'hace un momento' : m < 60 ? `hace ${m} min` : `hace ${Math.round(m / 60)} h`; };
    if (e.activo) {
      caja.innerHTML = `<div class="aviso ${e.error ? '' : 'verde'}" style="margin-bottom:10px">${e.error ? '⚠️ ' + esc(e.error) : `✅ Conectado a la nube${e.nombre ? ' como <b>' + esc(e.nombre) + '</b>' : ''}`}</div>
        <table><tr><td>Cuenta</td><td><b>${esc(e.email)}</b></td></tr><tr><td>Última subida de totales</td><td>${hace(e.ultimaSubida)}</td></tr><tr><td>Último contacto con la nube</td><td>${hace(e.ultimoContacto)}</td></tr><tr><td>Botón "Actualizar" del dueño</td><td>${e.timbre ? '✅ Responde al instante' : 'Se revisa cada 10 minutos'}</td></tr>
        ${e.licencia?.until ? `<tr><td>Monitoreo pagado hasta</td><td>${fecha(e.licencia.until)}</td></tr>` : ''}<tr><td>Reportes enviados al dueño</td><td>${e.solicitudesAtendidas || 0} desde que se encendió</td></tr></table>
        <p class="muted" style="margin:10px 0 0">Para gastar poco internet y nube, los totales se suben cada ${e.cadaHoras || 4} horas y al cerrar el día. Cuando el dueño presiona <b>Actualizar</b> en su celular, esta computadora le manda lo del momento.</p>
        <div class="fila" style="margin-top:12px"><a class="btn" href="${esc(e.pagina)}" target="_blank" rel="noopener">🌐 Abrir la página del dueño</a><button type="button" class="btn" id="nubeSubir">⬆ Subir totales ahora</button><button type="button" class="btn" id="nubeSalir">Desconectar</button></div>`;
      $('#nubeSubir').onclick = (ev) => intentar(async () => { await api('/api/nube/subir', {}); toast('Totales enviados a la nube', 'ok'); pintarNube(); }, ev.currentTarget);
      $('#nubeSalir').onclick = async () => { if (await confirmar('Esta computadora dejará de enviar los totales a la nube.', 'Sí, desconectar')) intentar(async () => { await api('/api/nube/desconectar', {}); pintarNube(); }); };
    } else {
      caja.innerHTML = `<p style="margin-top:0">Para activarlo, Maxsel te da un <b>correo y contraseña</b> del monitoreo. Escríbelos aquí una sola vez:</p>
        <div class="form"><label>Correo del monitoreo<input id="nubeEmail" type="email" autocomplete="off" value="${esc(e.email || '')}"></label><label>Contraseña<input id="nubePass" type="password" autocomplete="new-password"></label></div>
        <div class="fila" style="margin-top:10px"><button type="button" class="btn primario" id="nubeConectar">☁️ Conectar a la nube</button><small class="muted">Necesita internet solo para enviar los totales; sin internet el gimnasio sigue funcionando igual.</small></div>`;
      $('#nubeConectar').onclick = (ev) => intentar(async () => {
        const r = await api('/api/nube/conectar', { email: $('#nubeEmail').value, password: $('#nubePass').value });
        toast(r.error ? r.error : 'Conectado a la nube', r.error ? 'error' : 'ok'); pintarNube();
      }, ev.currentTarget);
    }
  };
  pintarNube();
  const pintarLogo = () => { const l = estado.config.gym_logo; $('#logoPrev').innerHTML = l ? `<img src="/logo-gym?${esc(String(l).split('?')[1] || '')}" style="max-height:78px;max-width:220px">` : '<span class="muted">Sin logo</span>'; $('#logoQuitar').classList.toggle('oculto', !l); };
  pintarLogo();
  $('#logoArch').onchange = () => {
    const f = $('#logoArch').files[0]; if (!f) return;
    intentar(async () => {
      const dataUrl = await redimensionar(f, 900, 0.92);
      await api('/api/config/logo', { imagen: dataUrl });
      estado.config = await api('/api/config'); pintarLogo(); $('#logoArch').value = ''; toast('Logo guardado. Ya se ve en la pantalla del cliente.', 'ok');
    });
  };
  $('#logoQuitar').onclick = () => intentar(async () => { await api('/api/config/logo', null, 'DELETE'); estado.config = await api('/api/config'); pintarLogo(); toast('Logo quitado', 'ok'); });
  const lec = await api('/api/lector/estado'); $('#estLec').innerHTML = estadoLectorHtml(lec);
  $('#f').onsubmit = (e) => { e.preventDefault(); intentar(async () => { await api('/api/config', valores(e.target), 'PUT'); estado.config = await api('/api/config'); $('#gymNombre').textContent = estado.config.gym_nombre; toast('Configuración guardada', 'ok'); }, $('button.primario', e.target)); };
  // 1.12: los datos del lector se guardan con su propio botón y antes de cualquier botón del lector
  const guardarLector = async () => {
    const f = $('#f'), d = {};
    for (const k of ['hik_ip', 'hik_puerto', 'hik_usuario', 'hik_password', 'hik_puerta']) { const el = f.querySelector(`[name=${k}]`); if (el) d[k] = el.value; }
    d.hik_modo = f.querySelector('[name=hik_modo]:checked')?.value || 'simulador';
    const p8000 = String(d.hik_puerto).trim() === '8000';
    await api('/api/config', d, 'PUT');
    estado.config = await api('/api/config');
    if (p8000) { f.querySelector('[name=hik_puerto]').value = '80'; toast('El puerto 8000 es del programa iVMS; se cambió al 80, que es el puerto web del lector', 'ok'); }
    return d;
  };
  $('#bGuardarLector').onclick = (e) => intentar(async () => {
    const d = await guardarLector();
    $('#estLec').innerHTML = d.hik_modo === 'real' ? '<span class="punto"></span> Guardado: lector real. Presiona "Probar conexión".' : '<span class="punto"></span> Guardado: modo simulador.';
    toast('Datos del lector guardados', 'ok');
  }, e.target);
  $$('[name=hik_modo]').forEach((r) => r.addEventListener('change', () => intentar(async () => {
    const d = await guardarLector();
    $('#estLec').innerHTML = d.hik_modo === 'real' ? '<span class="punto"></span> Modo "Lector real" guardado. Escribe IP, usuario y contraseña y presiona "Probar conexión".' : '<span class="punto"></span> Modo simulador guardado.';
  })));
  for (const id of ['bProbar', 'bHora', 'bTodos', 'bDiag', 'bImportarLector']) {
    $('#' + id).addEventListener('click', async (ev) => { // se guarda ANTES de la acción del botón (fase de captura)
      if (ev._guardado) return;
      const boton = ev.currentTarget;
      ev.stopImmediatePropagation(); ev.preventDefault();
      try { await guardarLector(); } catch (err) { toast(err.message, 'error'); return; }
      const nuevo = new MouseEvent('click', { bubbles: true }); nuevo._guardado = true; boton.dispatchEvent(nuevo);
    }, true);
  }
  $('#bFotosPc').onclick = () => {
    const m = modal(`<h2>🖼️ Buscar fotos en esta computadora</h2>
      <p>Para los clientes que <b>no tienen foto</b> (por ejemplo, los importados del lector cuando el lector no la entregó), se buscan sus fotos en esta computadora:
      en la información de <b>iVMS-4200, Hik-Connect o HikCentral</b> (archivos y bases de datos) y en carpetas de fotos. Se relacionan por el <b>número</b> que tienen en el lector o por su <b>nombre completo</b>. No se cambia nada en esos programas.</p>
      <label>Carpeta con fotos (opcional, si las tienes guardadas en otro lugar)<input id="fpCarpeta" placeholder="Ej. C:\\Users\\Recepcion\\Pictures\\Socios"></label>
      <p class="muted"><small>Si usas una carpeta, nombra cada foto con el número del cliente en el lector (ej. <b>12.jpg</b>) o con su nombre completo (ej. <b>Juan Perez Lopez.jpg</b>).</small></p>
      <div id="fpRes"></div>
      <div class="modal-pie"><button class="btn" data-cerrar>Cerrar</button><button class="btn primario" id="fpOk">Buscar fotos</button></div>`);
    let timer;
    const pintar = (st) => {
      if (st.activa) {
        $('#fpRes', m).innerHTML = `<div style="margin-top:10px"><b>${esc(st.fase)}</b> <span class="muted">${st.revisados.toLocaleString('es-MX')} archivos revisados · ${st.encontradas} fotos encontradas · ${st.segundos} s</span>
          <p class="muted"><small>Puedes cerrar esta ventana: la búsqueda sigue en segundo plano y el sistema sigue funcionando normal.</small></p></div>`; return;
      }
      if (st.error) { $('#fpRes', m).innerHTML = `<div class="aviso rojo">${esc(st.error)}</div>`; return; }
      const r = st.resultado;
      if (!r) { $('#fpRes', m).innerHTML = `<p class="muted">Clientes sin foto: <b>${st.sin_foto}</b></p>`; return; }
      $('#fpRes', m).innerHTML = `<div class="aviso ${r.encontradas ? 'verde' : ''}">${r.encontradas ? '✅' : 'ℹ️'} Se encontraron <b>${r.encontradas}</b> fotos de ${r.sin_foto} clientes sin foto (en ${r.segundos} s; se revisaron ${r.bases} bases de datos y ${r.imagenes.toLocaleString('es-MX')} imágenes).
        ${r.lugares?.length ? `<br><small>Encontradas en: ${r.lugares.map(esc).join(' · ')}</small>` : ''}
        ${!r.encontradas ? '<br>No se encontraron. Si sabes en qué carpeta están las fotos, escríbela arriba y vuelve a buscar.' : ''}<br>Quedan sin foto: <b>${st.sin_foto}</b>.</div>`;
    };
    const seguir = async () => { try { const st = await api('/api/lector/fotos-pc'); pintar(st); if (st.activa) timer = setTimeout(seguir, 1000); } catch (err) { $('#fpRes', m).innerHTML = `<div class="aviso rojo">${esc(err.message)}</div>`; } };
    m.addEventListener('remove', () => clearTimeout(timer));
    $('#fpOk', m).onclick = (e) => intentar(async () => { await api('/api/lector/fotos-pc', { carpeta: $('#fpCarpeta', m).value }); seguir(); }, e.target);
    seguir();
  };
  $('#bProbar').onclick = (e) => intentar(async () => {
    $('#estLec').innerHTML = '<span class="punto"></span> Probando conexión… (si el puerto está mal, se buscan los puertos comunes y puede tardar unos segundos)';
    try {
      const i = await api('/api/lector/probar', {});
      if (i.puerto_corregido) {
        $('[name=hik_puerto]').value = i.puerto_corregido;
        estado.config.hik_puerto = String(i.puerto_corregido);
        modal(`<h2>✅ Lector encontrado</h2><p>El lector no respondía en el puerto <b>${i.puerto_anterior}</b> (ese puerto es del programa iVMS/SDK de Hikvision).
          Se encontró en el puerto <b>${i.puerto_corregido}</b> y ya quedó guardado.</p><p><b>${esc(i.modelo)}</b> · serie ${esc(i.serie)} · firmware ${esc(i.firmware)}</p>
          <div class="modal-pie"><button class="btn primario" data-cerrar>Listo</button></div>`);
      } else toast(`Conectado: ${i.modelo} · serie ${i.serie} · firmware ${i.firmware}`, 'ok');
      $('#estLec').innerHTML = `<span class="punto ok"></span> Conectado: ${esc(i.modelo)} (firmware ${esc(i.firmware)})`;
    } catch (err) {
      $('#estLec').innerHTML = `<span class="punto mal"></span> ${esc(err.message)}`;
      throw err;
    }
  }, e.target);
  $('#bHora').onclick = (e) => intentar(async () => { await api('/api/lector/hora', {}); toast('Hora actualizada en el lector', 'ok'); }, e.target);
  $('#bTodos').onclick = (e) => intentar(async () => {
    toast('Enviando clientes, esto puede tardar…');
    const r = await api('/api/lector/sincronizar-todos', {});
    toast(`Enviados ${r.ok} de ${r.total} (los importados del lector se omiten)${r.errores.length ? '. Con error: ' + r.errores.map((x) => `#${x.id} ${x.error}`).join('; ') : ''}`, r.errores.length ? 'error' : 'ok');
  }, e.target);
  $('#bReiniciar').onclick = async (e) => {
    if (!await confirmar('El sistema se reiniciará y estará fuera unos 10 segundos. Los datos no se pierden.', 'Reiniciar')) return;
    intentar(async () => {
      await api('/api/sistema/reiniciar', {});
      toast('Reiniciando… la página se recargará sola');
      setTimeout(function esperar() { fetch('/api/licencia/estado').then((r) => (r.ok ? location.reload() : setTimeout(esperar, 1500))).catch(() => setTimeout(esperar, 1500)); }, 3000);
    }, e.target);
  };
  $('#bAbrirPant').onclick = () => window.open('/pantalla', 'pantalla_acceso', 'width=1280,height=800');
  $('#bProbOk').onclick = (e) => intentar(async () => { await api('/api/pantalla/prueba', { resultado: 'permitido' }); toast('Se envió una prueba a la pantalla del cliente', 'ok'); }, e.target);
  $('#bProbNo').onclick = (e) => intentar(async () => { await api('/api/pantalla/prueba', { resultado: 'denegado' }); toast('Se envió una prueba a la pantalla del cliente', 'ok'); }, e.target);
  $('#bDiag').onclick = (e) => intentar(async () => {
    const r = await api('/api/lector/diagnostico', {});
    const m = modal(`<h2>🩺 Diagnóstico del lector</h2><p class="muted">Copia este texto y mándaselo a soporte de Maxsel.</p>
      <textarea id="diagTxt" rows="16" style="font-family:Consolas,monospace;font-size:12px" readonly>${esc(r.texto)}</textarea>
      <div class="modal-pie"><button class="btn" id="diagCopiar">📋 Copiar</button><button class="btn primario" data-cerrar>Cerrar</button></div>`, { ancho: true });
    $('#diagCopiar', m).onclick = async () => { const t = $('#diagTxt', m); t.select(); try { await navigator.clipboard.writeText(t.value); } catch { document.execCommand('copy'); } toast('Copiado', 'ok'); };
  }, e.target);
  $('#bImportarLector').onclick = () => {
    const m = modal(`<h2>📥 Importar usuarios del lector</h2>
      <p>Trae al sistema a las personas que <b>ya están registradas</b> en el lector facial (por ejemplo, si el gimnasio ya lo usaba antes). Se crean como clientes con su nombre, su foto y el mismo número que tienen en el lector.</p>
      <label class="chk"><input type="checkbox" id="imFotos" checked> Traer también la foto de su rostro</label>
      <label class="chk"><input type="checkbox" id="imVig" checked> Respetar la fecha de vencimiento que tienen en el lector (se crea como membresía "Importado del lector")</label>
      <div class="aviso azul" style="margin-top:12px">No se borra ni se cambia nada en el lector: cada persona conserva su acceso actual. Cuando le cobres una membresía o edites sus datos, su acceso pasa a controlarse con las membresías del sistema. Las personas que ya existen en el sistema se saltan; si alguna quedó sin foto, se vuelve a intentar traer su foto.</div>
      <div id="imRes"></div>
      <div class="modal-pie"><button class="btn" data-cerrar>Cerrar</button><button class="btn primario" id="imOk">Importar ahora</button></div>`);
    const pintar = (st) => {
      const pct = st.total ? Math.round((st.hechos / st.total) * 100) : 0;
      if (st.activa) {
        $('#imRes', m).innerHTML = `<div style="margin-top:12px"><b>${esc(st.fase)}</b> <span class="muted">${st.hechos} de ${st.total} · ${st.segundos} s</span>
          <div style="height:12px;background:var(--gris-c);border-radius:6px;overflow:hidden;margin-top:6px"><div style="height:100%;width:${pct}%;background:var(--marca)"></div></div>
          <p class="muted"><small>Puedes cerrar esta ventana: la importación sigue en segundo plano.</small></p></div>`;
        return;
      }
      if (st.error) { $('#imRes', m).innerHTML = `<div class="aviso rojo">${esc(st.error)}</div>`; return; }
      const r = st.resultado; if (!r) return;
      $('#imRes', m).innerHTML = `<div class="aviso verde">✅ Terminado en ${r.segundos} segundos. En el lector hay <b>${r.encontrados}</b> personas: <b>${r.nuevos}</b> nuevas y <b>${r.ya_existian}</b> que ya estaban.<br>
        Fotos traídas: <b>${r.con_foto}</b>${r.fotos_pc ? ` (${r.fotos_pc} encontradas en esta computadora)` : ''}${r.sin_foto_en_lector ? ` · ${r.sin_foto_en_lector} no tienen foto en el lector` : ''}${r.errores_foto ? ` · <span class="rojo">${r.errores_foto} no se pudieron descargar</span>` : ''}. Con vigencia: ${r.con_vigencia}.${r.fuera_de_licencia ? `<br><b class="rojo">${r.fuera_de_licencia} personas NO se importaron porque se llegó al máximo de clientes de la licencia. Pida a Maxsel una licencia más grande.</b>` : ''}
        ${r.errores.length ? `<br><small>${r.errores.slice(0, 6).map(esc).join('<br>')}</small>` : ''}</div>`;
    };
    let timer;
    const seguir = async () => {
      try { const st = await api('/api/lector/importar'); pintar(st); if (st.activa) timer = setTimeout(seguir, 1000); }
      catch (err) { $('#imRes', m).innerHTML = `<div class="aviso rojo">${esc(err.message)}</div>`; }
    };
    m.addEventListener('remove', () => clearTimeout(timer));
    $('#imOk', m).onclick = (e) => intentar(async () => {
      await api('/api/lector/importar', { fotos: $('#imFotos', m).checked, vigencia: $('#imVig', m).checked });
      e.target.disabled = true;
      seguir();
    }, e.target);
    seguir(); // si ya había una importación corriendo, se muestra su avance
  };
  $('#bEventos').onclick = () => {
    const m = modal(`<h2>Envío de eventos al instante</h2><p>El lector avisará a esta computadora cada vez que alguien ponga su cara, para mostrarlo en la pantalla de acceso de inmediato. (Aunque no lo configures, el sistema revisa el lector cada 2 segundos.)</p>
      <label>IP de esta computadora en la red<select id="ip">${c._ips.map((i) => `<option ${i === c.servidor_ip ? 'selected' : ''}>${i}</option>`).join('')}</select></label>
      <p class="muted">Puerto: ${c._puerto}. Si Windows pregunta por el Firewall, permite el acceso en redes privadas.</p>
      <div class="modal-pie"><button class="btn" data-cerrar>Cancelar</button><button class="btn primario" id="ok">Configurar</button></div>`);
    $('#ok', m).onclick = (e) => intentar(async () => { await api('/api/lector/configurar-eventos', { ip: $('#ip', m).value }); m.cerrar(); toast('Listo, el lector enviará los eventos a esta computadora', 'ok'); }, e.target);
  };
};

iniciar();


// ===================== Reiniciar el sistema · solo Maxsel (botón oculto, igual que Maxsel Tech) =====================
function modalReiniciarMaxsel() {
  const m = modal(`<h2>🔒 Reiniciar el sistema · solo Maxsel</h2>
    <div class="aviso-rojo" style="margin-bottom:10px">Borra las <b>ventas, turnos y cortes</b> (por ejemplo, las ventas de prueba de la instalación), con sus membresías, abonos, movimientos de caja y el registro de entradas. Lo vendido regresa al inventario. Usuarios, configuración, planes y licencia no se borran.</div>
    <label class="rsop"><input type="checkbox" checked disabled><span>Ventas, turnos y cortes de caja</span></label>
    <label class="rsop"><input type="checkbox" id="rsCli"><span>También los clientes (las caras del lector facial se quedan en el lector)</span></label>
    <label class="rsop"><input type="checkbox" id="rsInv"><span>También el inventario (productos)</span></label>
    <label style="display:block;margin-top:10px">Contraseña de Maxsel<input id="rsPass" type="password" autocomplete="off" placeholder="Solo la conoce Maxsel" autofocus></label>
    <div class="modal-pie"><button class="btn" data-cerrar>Cancelar</button><button class="btn peligro" id="rsOk">Borrar y reiniciar</button></div>`, { escSiempre: true });
  let t = null;
  $('#rsOk', m).onclick = async () => {
    const bt = $('#rsOk', m), pw = $('#rsPass', m).value;
    if (!pw) { toast('Escribe la contraseña de Maxsel', 'error'); return; }
    if (!bt.dataset.ok) { bt.dataset.ok = '1'; bt.textContent = 'Sí, borrar (no se puede deshacer)'; clearTimeout(t); t = setTimeout(() => { delete bt.dataset.ok; bt.textContent = 'Borrar y reiniciar'; }, 6000); return; }
    delete bt.dataset.ok; bt.textContent = 'Borrar y reiniciar'; bt.disabled = true;
    try {
      const r = await api('/api/sistema/reiniciar', { clave: pw, clientes: $('#rsCli', m).checked, inventario: $('#rsInv', m).checked });
      m.cerrar();
      toast('Sistema reiniciado: ventas, turnos y cortes borrados' + (r.clientes ? ', clientes' : '') + (r.inventario ? ', inventario' : '') + '.', 'ok');
      estado.turno = null; estado.carrito = []; location.hash = ''; iniciar();
    } catch (e) { bt.disabled = false; toast(e.message, 'error'); $('#rsPass', m).value = ''; $('#rsPass', m).focus(); }
  };
  $('#rsPass', m).addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#rsOk', m).click(); });
}
