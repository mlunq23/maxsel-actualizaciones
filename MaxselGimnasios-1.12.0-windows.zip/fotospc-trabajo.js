// Buscar las fotos de los clientes importados del lector en ESTA computadora (1.12).
// Cuando el lector no entrega la foto (o el gimnasio registraba a la gente con iVMS-4200 / Hik-Connect / HikCentral),
// las fotos suelen estar guardadas en la PC: como archivos .jpg o DENTRO de una base de datos SQLite de esos programas.
// Se revisan esos lugares, se buscan fotos JPG y se relacionan con cada cliente por su NÚMERO en el lector o por su NOMBRE.
// Solo se LEE: no se cambia ni se borra nada de esos programas.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { parentPort, workerData } from 'node:worker_threads';

// Corre en un hilo aparte (worker) para que el punto de venta y el acceso NO se congelen mientras busca.
const busquedaPc = { fase: '', revisados: 0 };
let ultimoAviso = 0;
const avisar = () => { if (Date.now() - ultimoAviso > 700) { ultimoAviso = Date.now(); parentPort.postMessage({ tipo: 'avance', fase: busquedaPc.fase, revisados: busquedaPc.revisados }); } };

const EXT_IMG = new Set(['.jpg', '.jpeg', '.jpe', '.jfif']);
const EXT_DB = new Set(['.db', '.db3', '.sqlite', '.sqlite3', '.dat', '.s3db', '.sdb', '']);
const PALABRAS = /ivms|hik|hikvision|hikcentral|hik-?connect|facedb|face|rostro|persona|person|accesscontrol|acs|guarding|attendance|asistencia/i;
const NO_ENTRAR = /^(windows|\$recycle\.bin|system volume information|node_modules|winsxs|microsoft|google|mozilla|nvidia|intel|amd|package cache|installer|msocache|maxselgimnasios)$/i;
const esJpg = (b) => b && b.length > 2000 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff;
const norm = (s) => String(s ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
const sinCeros = (s) => String(s).replace(/^0+(?=\d)/, '');

function raices(extra) {
  const r = [];
  if (extra) r.push({ dir: extra, todo: true });
  if (process.platform === 'win32') {
    const pf = [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], process.env.ProgramData, 'C:\\', 'D:\\'].filter(Boolean);
    for (const p of pf) r.push({ dir: p, todo: false });
    // perfiles de usuario (AppData y Documentos), porque el servicio corre como SYSTEM
    try {
      for (const u of fs.readdirSync('C:\\Users')) {
        if (/^(public|default|default user|all users)$/i.test(u)) continue;
        for (const s of ['AppData\\Roaming', 'AppData\\Local', 'AppData\\LocalLow', 'Documents', 'Pictures', 'Desktop']) r.push({ dir: path.join('C:\\Users', u, s), todo: false });
      }
    } catch { /* nada */ }
  } else {
    r.push({ dir: os.homedir(), todo: false });
  }
  return r;
}

// Recorre carpetas. En las raíces generales solo entra a carpetas cuyo nombre suene a Hikvision/iVMS;
// dentro de esas (o en la carpeta que elija el usuario) revisa todo.
function recorrer(raiz, todo, cb, prof = 0) {
  if (prof > 9 || busquedaPc.revisados > 400000) return;
  let ents;
  try { ents = fs.readdirSync(raiz, { withFileTypes: true }); } catch { return; }
  for (const e of ents) {
    const p = path.join(raiz, e.name);
    if (e.isDirectory()) {
      if (NO_ENTRAR.test(e.name) && !todo) continue;
      const dentro = todo || PALABRAS.test(e.name);
      if (dentro) recorrer(p, true, cb, prof + 1);
      else if (prof < 2) recorrer(p, false, cb, prof + 1); // solo 2 niveles buscando la carpeta del programa
    } else if (todo && e.isFile()) {
      busquedaPc.revisados++; avisar();
      cb(p, e.name);
    }
  }
}

function esSqlite(f) {
  try {
    const fd = fs.openSync(f, 'r'); const b = Buffer.alloc(16); fs.readSync(fd, b, 0, 16, 0); fs.closeSync(fd);
    return b.toString('latin1') === 'SQLite format 3\u0000';
  } catch { return false; }
}

// Fotos dentro de una base SQLite: filas con un JPG (o la ruta de un JPG) y algún dato que identifique a la persona
function fotosDeSqlite(archivo, agregar) {
  const tmp = path.join(os.tmpdir(), `maxsel-gym-buscar-${process.pid}-${Date.now()}.db`);
  let db;
  try {
    fs.copyFileSync(archivo, tmp); // copia: así no se bloquea el programa original
    db = new DatabaseSync(tmp, { readOnly: true });
    const tablas = db.prepare(`SELECT name FROM sqlite_master WHERE type='table'`).all().map((t) => t.name);
    for (const t of tablas) {
      let filas = 0;
      try {
        for (const fila of db.prepare(`SELECT * FROM "${t.replace(/"/g, '""')}"`).iterate()) {
          if (++filas > 50000) break;
          const claves = { nombres: [], numeros: [] }; let jpg = null;
          for (const v of Object.values(fila)) {
            if (v instanceof Uint8Array) { if (!jpg && esJpg(v)) jpg = Buffer.from(v); }
            else if (typeof v === 'string') {
              if (!jpg && /\.(jpe?g|jfif)$/i.test(v) && v.length < 400) {
                const ruta = path.isAbsolute(v) ? v : path.join(path.dirname(archivo), v);
                try { const b = fs.readFileSync(ruta); if (esJpg(b)) jpg = b; } catch { /* nada */ }
              } else if (v.length && v.length < 120) {
                if (/^\s*\d{1,20}\s*$/.test(v)) claves.numeros.push(v.trim()); else claves.nombres.push(v);
              }
            } // los números enteros de la base suelen ser el id interno de la fila: no se usan
          }
          if (jpg && (claves.nombres.length || claves.numeros.length)) agregar(claves, () => jpg, `${path.basename(archivo)} › ${t}`);
        }
      } catch { /* tabla que no se puede leer */ }
    }
  } catch { /* no es una base válida */ } finally {
    try { db?.close(); } catch { /* nada */ }
    fs.rmSync(tmp, { force: true });
  }
}

function buscarFotosEnPc({ carpeta, faltan }) {
  const inicio = Date.now();
  const res = { sin_foto: faltan.length, encontradas: 0, bases: 0, imagenes: 0, lugares: [], segundos: 0 };
  if (!faltan.length) return res;
  if (carpeta && !fs.existsSync(carpeta)) throw new Error('No existe la carpeta: ' + carpeta);
  // índices para relacionar: número del lector (con y sin ceros) y nombre completo normalizado
  const porNum = new Map(), porNom = new Map();
  for (const c of faltan) {
    if (c.hik_empleado) { porNum.set(String(c.hik_empleado), c); porNum.set(sinCeros(c.hik_empleado), c); }
    const n = norm(c.nombre);
    if (n.length >= 5 && !/^persona \d+$/.test(n)) porNom.set(n, porNom.has(n) ? null : c); // nombres repetidos no se usan
  }
  const hechos = new Set(), lugares = new Set();
  // claves = { nombres:[], numeros:[] }. Primero por NOMBRE completo; si no, por número (solo si apunta a UNA sola persona).
  const agregar = (claves, sacarJpg, lugar) => {
    let c = null;
    for (const k of claves.nombres || []) { const x = porNom.get(norm(k)); if (x && !hechos.has(x.id)) { c = x; break; } }
    if (!c) {
      const cand = new Set();
      for (const k of claves.numeros || []) { const s = String(k).trim(); const x = porNum.get(s) || porNum.get(sinCeros(s)); if (x) cand.add(x); }
      if (cand.size === 1) c = [...cand][0];
      // si en la misma fila el nombre es de OTRA persona, no se usa el número
      if (c && (claves.nombres || []).some((k) => { const x = porNom.get(norm(k)); return x && x.id !== c.id; })) c = null;
    }
    if (!c || hechos.has(c.id)) return;
    const jpg = sacarJpg(); if (!esJpg(jpg)) return;
    parentPort.postMessage({ tipo: 'foto', id: c.id, jpg });
    hechos.add(c.id); res.encontradas++; lugares.add(lugar.split(' › ')[0]);
  };
  for (const { dir, todo } of raices(carpeta)) {
    if (hechos.size >= faltan.length) break;
    recorrer(dir, todo, (archivo, nombre) => {
      if (hechos.size >= faltan.length) return;
      const ext = path.extname(nombre).toLowerCase();
      let tam = 0; try { tam = fs.statSync(archivo).size; } catch { return; }
      if (EXT_IMG.has(ext) && tam > 2000 && tam < 3e6) {
        res.imagenes++;
        // la foto se relaciona por su nombre de archivo o por el nombre de su carpeta (ej. "\00000012\cara.jpg" o "Juan Perez.jpg")
        const base = path.basename(nombre, path.extname(nombre));
        const carpetaFoto = path.basename(path.dirname(archivo));
        const claves = { nombres: [base, carpetaFoto], numeros: [base, carpetaFoto].filter((x) => /^\d+$/.test(x)) };
        agregar(claves, () => { try { return fs.readFileSync(archivo); } catch { return null; } }, path.dirname(archivo));
      } else if (EXT_DB.has(ext) && tam > 4096 && tam < 2e9 && esSqlite(archivo)) {
        res.bases++;
        busquedaPc.fase = 'Revisando la base de datos ' + nombre + '…';
        fotosDeSqlite(archivo, agregar);
        busquedaPc.fase = 'Buscando las fotos en esta computadora…';
      }
    });
  }
  res.lugares = [...lugares].slice(0, 8);
  res.segundos = Math.round((Date.now() - inicio) / 1000);
  return res;
}

try { parentPort.postMessage({ tipo: 'fin', res: buscarFotosEnPc(workerData) }); }
catch (e) { parentPort.postMessage({ tipo: 'error', error: e.message }); }
