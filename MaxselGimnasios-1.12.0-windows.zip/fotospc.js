// Buscar las fotos de los clientes importados del lector en ESTA computadora (1.12).
// Cuando el lector no entrega la foto (o el gimnasio registraba a la gente con iVMS-4200 / Hik-Connect / HikCentral),
// las fotos suelen estar en la PC: como archivos .jpg o DENTRO de la base de datos de esos programas.
// La búsqueda corre en un hilo aparte (fotospc-trabajo.js) para que el punto de venta y el acceso no se congelen.
// Solo se LEE: no se cambia ni se borra nada de esos programas.
import fs from 'node:fs';
import path from 'node:path';
import { Worker } from 'node:worker_threads';
import { all, run, FOTOS_DIR } from './db.js';

export const busquedaPc = { activa: false, fase: '', revisados: 0, encontradas: 0, resultado: null, error: null, inicio: null };

// Devuelve una promesa con el resultado; el avance se puede consultar en busquedaPc
export function buscarFotosEnPc({ carpeta } = {}) {
  if (busquedaPc.activa) return Promise.reject(new Error('Ya hay una búsqueda de fotos en proceso'));
  const faltan = all(`SELECT id, nombre, hik_empleado FROM clientes WHERE (foto IS NULL OR foto='')`);
  Object.assign(busquedaPc, { activa: true, fase: 'Buscando las fotos en esta computadora…', revisados: 0, encontradas: 0, resultado: null, error: null, inicio: Date.now() });
  if (!faltan.length) {
    Object.assign(busquedaPc, { activa: false, fase: 'Terminado', resultado: { sin_foto: 0, encontradas: 0, bases: 0, imagenes: 0, lugares: [], segundos: 0 } });
    return Promise.resolve(busquedaPc.resultado);
  }
  return new Promise((resolve) => {
    const w = new Worker(new URL('./fotospc-trabajo.js', import.meta.url), { workerData: { carpeta: carpeta || '', faltan } });
    const terminar = (res, error) => {
      Object.assign(busquedaPc, { activa: false, fase: 'Terminado', resultado: res || null, error: error || null });
      if (res) console.log('[fotos pc] ' + JSON.stringify(res));
      resolve(res || null);
    };
    w.on('message', (m) => {
      if (m.tipo === 'avance') Object.assign(busquedaPc, { fase: m.fase, revisados: m.revisados });
      else if (m.tipo === 'foto') {
        try {
          const archivo = `${m.id}-${Date.now()}.jpg`;
          fs.writeFileSync(path.join(FOTOS_DIR, archivo), Buffer.from(m.jpg));
          run(`UPDATE clientes SET foto=?, cara_sync=1 WHERE id=? AND (foto IS NULL OR foto='')`, archivo, m.id);
          busquedaPc.encontradas++;
        } catch (e) { console.error('[fotos pc] ' + e.message); }
      } else if (m.tipo === 'fin') terminar(m.res);
      else if (m.tipo === 'error') terminar(null, m.error);
    });
    w.on('error', (e) => terminar(null, e.message));
    w.on('exit', (code) => { if (busquedaPc.activa) terminar(null, 'La búsqueda se detuvo (código ' + code + ')'); });
  });
}
