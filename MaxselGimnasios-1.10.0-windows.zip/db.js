// Base de datos del gimnasio (SQLite integrado en Node.js, no requiere instalar nada)
import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

import { fileURLToPath } from 'node:url';
// Los datos van en la carpeta "datos" junto al programa (o donde indique GYM_DATA)
export const DATA_DIR = path.resolve(process.env.GYM_DATA || path.join(path.dirname(fileURLToPath(import.meta.url)), 'datos'));
export const FOTOS_DIR = path.join(DATA_DIR, 'fotos');
export const DOCS_DIR = path.join(DATA_DIR, 'evidencias');
fs.mkdirSync(FOTOS_DIR, { recursive: true });
fs.mkdirSync(DOCS_DIR, { recursive: true });

export const db = new DatabaseSync(path.join(DATA_DIR, 'gimnasio.db'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');

db.exec(`
CREATE TABLE IF NOT EXISTS config (clave TEXT PRIMARY KEY, valor TEXT);

CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, usuario TEXT UNIQUE NOT NULL,
  pass_hash TEXT NOT NULL, rol TEXT NOT NULL CHECK (rol IN ('admin','gerente','cajero')),
  activo INTEGER DEFAULT 1);

CREATE TABLE IF NOT EXISTS sesiones (token TEXT PRIMARY KEY, usuario_id INTEGER, creado TEXT);

CREATE TABLE IF NOT EXISTS clientes (
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, direccion TEXT, colonia TEXT, cp TEXT,
  telefono TEXT, whatsapp TEXT, correo TEXT, acepta_publicidad INTEGER DEFAULT 1,
  estudiante INTEGER DEFAULT 0, escuela TEXT, notas TEXT,
  foto TEXT, cara_sync INTEGER DEFAULT 0, sincronizado INTEGER DEFAULT 0, sync_error TEXT,
  bloqueado INTEGER DEFAULT 0, creado TEXT);

CREATE TABLE IF NOT EXISTS planes (
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, dias INTEGER DEFAULT 0, meses INTEGER DEFAULT 0,
  precio REAL NOT NULL, activo INTEGER DEFAULT 1, orden INTEGER DEFAULT 0);

CREATE TABLE IF NOT EXISTS promociones (
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('estudiante','pareja','vecino','general')),
  descuento_tipo TEXT NOT NULL CHECK (descuento_tipo IN ('porcentaje','monto','precio_fijo')),
  valor REAL NOT NULL, plan_id INTEGER, zonas TEXT, activo INTEGER DEFAULT 1);

CREATE TABLE IF NOT EXISTS membresias (
  id INTEGER PRIMARY KEY, cliente_id INTEGER NOT NULL, plan_id INTEGER NOT NULL, promo_id INTEGER,
  inicio TEXT NOT NULL, fin TEXT NOT NULL, precio REAL NOT NULL, venta_id INTEGER,
  pareja_cliente_id INTEGER, cancelada INTEGER DEFAULT 0, creado TEXT);

CREATE TABLE IF NOT EXISTS productos (
  id INTEGER PRIMARY KEY, codigo TEXT UNIQUE, nombre TEXT NOT NULL, costo REAL DEFAULT 0,
  precio REAL NOT NULL, existencia REAL DEFAULT 0, minimo REAL DEFAULT 0, activo INTEGER DEFAULT 1);

CREATE TABLE IF NOT EXISTS turnos (
  id INTEGER PRIMARY KEY, usuario_id INTEGER NOT NULL, abierto TEXT NOT NULL, cerrado TEXT,
  fondo_mxn REAL DEFAULT 0, tipo_cambio REAL NOT NULL,
  decl_efectivo REAL, decl_usd REAL, decl_tarjeta REAL,
  esp_efectivo REAL, esp_usd REAL, esp_tarjeta REAL, notas TEXT,
  estado TEXT DEFAULT 'abierto');

CREATE TABLE IF NOT EXISTS ventas (
  id INTEGER PRIMARY KEY, turno_id INTEGER, usuario_id INTEGER, cliente_id INTEGER, fecha TEXT,
  total REAL, pago_efectivo REAL DEFAULT 0, pago_usd REAL DEFAULT 0, tipo_cambio REAL,
  pago_tarjeta REAL DEFAULT 0, pago_credito REAL DEFAULT 0, cambio REAL DEFAULT 0,
  credito_pendiente REAL DEFAULT 0, cancelada INTEGER DEFAULT 0);

CREATE TABLE IF NOT EXISTS venta_items (
  id INTEGER PRIMARY KEY, venta_id INTEGER NOT NULL, tipo TEXT NOT NULL, producto_id INTEGER,
  descripcion TEXT, cantidad REAL, precio REAL, costo REAL DEFAULT 0, importe REAL);

CREATE TABLE IF NOT EXISTS abonos (
  id INTEGER PRIMARY KEY, cliente_id INTEGER, turno_id INTEGER, usuario_id INTEGER, fecha TEXT,
  monto REAL, efectivo REAL DEFAULT 0, usd REAL DEFAULT 0, tarjeta REAL DEFAULT 0, cambio REAL DEFAULT 0);

CREATE TABLE IF NOT EXISTS movimientos (
  id INTEGER PRIMARY KEY, turno_id INTEGER, usuario_id INTEGER, tipo TEXT, monto REAL, concepto TEXT, fecha TEXT);

CREATE TABLE IF NOT EXISTS visitas (
  id INTEGER PRIMARY KEY, cliente_id INTEGER, fecha TEXT, resultado TEXT, motivo TEXT,
  origen TEXT, serial TEXT UNIQUE);

CREATE TABLE IF NOT EXISTS avisos (id INTEGER PRIMARY KEY, cliente_id INTEGER, tipo TEXT, fecha TEXT);

CREATE INDEX IF NOT EXISTS ix_memb_cliente ON membresias(cliente_id);
CREATE INDEX IF NOT EXISTS ix_visitas_cliente ON visitas(cliente_id, fecha);
CREATE INDEX IF NOT EXISTS ix_ventas_turno ON ventas(turno_id);
CREATE INDEX IF NOT EXISTS ix_ventas_cliente ON ventas(cliente_id);
CREATE TABLE IF NOT EXISTS gastos_fijos (
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, categoria TEXT, monto REAL DEFAULT 0, dia INTEGER, activo INTEGER DEFAULT 1, notas TEXT, creado TEXT);

CREATE TABLE IF NOT EXISTS gastos (
  id INTEGER PRIMARY KEY, fecha TEXT, periodo TEXT, nombre TEXT NOT NULL, categoria TEXT, monto REAL, gasto_fijo_id INTEGER,
  pagado_con TEXT, movimiento_id INTEGER, usuario_id INTEGER, notas TEXT, creado TEXT);
CREATE INDEX IF NOT EXISTS ix_gastos_periodo ON gastos(periodo);
CREATE INDEX IF NOT EXISTS ix_items_venta ON venta_items(venta_id);
-- Departamentos de la tienda (Bebidas, Suplementos, Ropa…)
CREATE TABLE IF NOT EXISTS departamentos (id INTEGER PRIMARY KEY, nombre TEXT UNIQUE NOT NULL, creado TEXT);
-- Empleados: sueldo, periodo de pago, día de descanso y vacaciones
CREATE TABLE IF NOT EXISTS empleados (
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, puesto TEXT, telefono TEXT, sueldo REAL DEFAULT 0, periodo TEXT DEFAULT 'quincenal',
  descanso TEXT, ingreso TEXT, vac_dias REAL DEFAULT 12, activo INTEGER DEFAULT 1, notas TEXT, creado TEXT);
-- Vacaciones, descansos, faltas, permisos e incapacidades
CREATE TABLE IF NOT EXISTS empleado_dias (
  id INTEGER PRIMARY KEY, empleado_id INTEGER NOT NULL, tipo TEXT NOT NULL, desde TEXT NOT NULL, hasta TEXT NOT NULL, dias REAL DEFAULT 1,
  goce INTEGER DEFAULT 1, notas TEXT, usuario_id INTEGER, creado TEXT);
CREATE INDEX IF NOT EXISTS ix_empdias ON empleado_dias(empleado_id, desde);
-- Proveedores y cuentas por pagar (facturas o notas que se les quedan a deber)
CREATE TABLE IF NOT EXISTS proveedores (
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, contacto TEXT, telefono TEXT, correo TEXT, rfc TEXT, surte TEXT, banco TEXT, cuenta TEXT, notas TEXT,
  activo INTEGER DEFAULT 1, creado TEXT);
CREATE TABLE IF NOT EXISTS cuentas_pagar (
  id INTEGER PRIMARY KEY, proveedor_id INTEGER, concepto TEXT NOT NULL, factura TEXT, categoria TEXT, monto REAL NOT NULL, pagado REAL DEFAULT 0,
  fecha TEXT, vence TEXT, notas TEXT, cancelada INTEGER DEFAULT 0, usuario_id INTEGER, creado TEXT);
CREATE TABLE IF NOT EXISTS cuentas_pagos (id INTEGER PRIMARY KEY, cuenta_id INTEGER NOT NULL, gasto_id INTEGER, fecha TEXT, monto REAL, usuario_id INTEGER);
CREATE INDEX IF NOT EXISTS ix_cxp_prov ON cuentas_pagar(proveedor_id);
`);

// ---------- Actualizaciones de la base de datos (versiones nuevas) ----------
function agregarColumna(tabla, col, def) {
  const cols = db.prepare(`PRAGMA table_info(${tabla})`).all().map((c) => c.name);
  if (!cols.includes(col)) db.exec(`ALTER TABLE ${tabla} ADD COLUMN ${col} ${def}`);
}
agregarColumna('usuarios', 'permisos', 'TEXT');            // JSON con los permisos; vacío = los del rol
agregarColumna('ventas', 'pago_transferencia', 'REAL DEFAULT 0');   // transferencia bancaria (ventana de cobro)
agregarColumna('ventas', 'referencia', 'TEXT');                     // autorización de tarjeta / folio de transferencia
agregarColumna('abonos', 'transferencia', 'REAL DEFAULT 0');
agregarColumna('abonos', 'referencia', 'TEXT');
agregarColumna('clientes', 'pareja_id', 'INTEGER');
agregarColumna('clientes', 'vecino', 'INTEGER DEFAULT 0');
agregarColumna('clientes', 'doc_estudiante', 'TEXT');      // foto de la credencial de estudiante
agregarColumna('clientes', 'doc_vecino', 'TEXT');          // foto del comprobante de domicilio / INE
agregarColumna('clientes', 'doc_fecha', 'TEXT');
agregarColumna('clientes', 'hik_empleado', 'TEXT');        // número de la persona dentro del lector
agregarColumna('clientes', 'importado', 'INTEGER DEFAULT 0');
agregarColumna('movimientos', 'categoria', 'TEXT');         // para gastos: proveedor, servicios, sueldos…
agregarColumna('movimientos', 'recibe', 'TEXT');            // quién recibió el dinero
agregarColumna('productos', 'area', 'TEXT');                // departamento de la tienda
agregarColumna('gastos', 'empleado_id', 'INTEGER');          // pago de sueldo a un empleado
agregarColumna('gastos', 'proveedor_id', 'INTEGER');         // pago a un proveedor (cuentas por pagar)
// 1.9 Gastos como en Maxsel Hotel: recibo con folio y firmas; gastos fijos con compañía, contrato y vencimiento
agregarColumna('gastos', 'folio', 'TEXT');
agregarColumna('gastos', 'metodo', "TEXT DEFAULT 'efectivo'");
agregarColumna('gastos', 'entrega', 'TEXT');
agregarColumna('gastos', 'recibe', 'TEXT');
agregarColumna('gastos', 'firma_entrega', 'TEXT');
agregarColumna('gastos', 'firma_recibe', 'TEXT');
agregarColumna('gastos_fijos', 'proveedor', 'TEXT');
agregarColumna('gastos_fijos', 'contrato', 'TEXT');
agregarColumna('gastos_fijos', 'referencia', 'TEXT');
agregarColumna('gastos_fijos', 'periodo_pago', "TEXT DEFAULT 'mensual'");
agregarColumna('gastos_fijos', 'vence', 'TEXT');
agregarColumna('gastos_fijos', 'dias_aviso', 'INTEGER DEFAULT 5');
agregarColumna('gastos_fijos', 'domiciliado', 'INTEGER DEFAULT 0');
// 1.9 Asistencia de empleados (checador): número, NIP, huella y horario de cada empleado
agregarColumna('empleados', 'numero', 'TEXT');
agregarColumna('empleados', 'pin', 'TEXT');
agregarColumna('empleados', 'huella', 'TEXT');
agregarColumna('empleados', 'horario', 'TEXT');
db.exec(`
CREATE TABLE IF NOT EXISTS checadas (
  id INTEGER PRIMARY KEY, empleado_id INTEGER NOT NULL, fecha TEXT NOT NULL, tipo TEXT NOT NULL, metodo TEXT, usuario_id INTEGER, nota TEXT, anulada INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS ix_checadas ON checadas(empleado_id, fecha);
CREATE TABLE IF NOT EXISTS festivos (id INTEGER PRIMARY KEY, fecha TEXT UNIQUE NOT NULL, nombre TEXT, descansa INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS relojes (sn TEXT PRIMARY KEY, nombre TEXT, ip TEXT, ultimo TEXT, stamp TEXT, activo INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS folios (clave TEXT PRIMARY KEY, n INTEGER DEFAULT 0);
`);
// Gastos fijos de antes (solo "día del mes"): se calcula su próximo vencimiento
for (const f of db.prepare("SELECT id, dia FROM gastos_fijos WHERE vence IS NULL").all()) {
  const d = new Date(), dia = Math.min(Math.max(Number(f.dia) || 1, 1), 28);
  let v = new Date(d.getFullYear(), d.getMonth(), dia);
  const pagado = db.prepare("SELECT 1 FROM gastos WHERE gasto_fijo_id=? AND periodo=?").get(f.id, `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  if (pagado) v = new Date(d.getFullYear(), d.getMonth() + 1, dia);
  db.prepare("UPDATE gastos_fijos SET vence=? WHERE id=?").run(`${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getDate()).padStart(2, '0')}`, f.id);
}
db.exec(`INSERT OR IGNORE INTO departamentos(nombre, creado) SELECT DISTINCT area, datetime('now','localtime') FROM productos WHERE area IS NOT NULL AND area<>''`);
db.exec(`UPDATE clientes SET hik_empleado=CAST(id AS TEXT) WHERE hik_empleado IS NULL OR hik_empleado='';
  CREATE UNIQUE INDEX IF NOT EXISTS ux_clientes_hik ON clientes(hik_empleado);`);


// ---------- Ayudantes de consultas ----------
const cache = new Map();
function st(sql) {
  let s = cache.get(sql);
  if (!s) { s = db.prepare(sql); cache.set(sql, s); }
  return s;
}
const norm = (p) => (p === undefined ? null : typeof p === 'boolean' ? (p ? 1 : 0) : p);
export const all = (sql, ...p) => st(sql).all(...p.map(norm));
export const get = (sql, ...p) => st(sql).get(...p.map(norm));
export const run = (sql, ...p) => {
  const r = st(sql).run(...p.map(norm));
  return { changes: Number(r.changes), id: Number(r.lastInsertRowid) };
};
let enTx = false;
export function tx(fn) {
  if (enTx) return fn();
  db.exec('BEGIN'); enTx = true;
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { db.exec('ROLLBACK'); throw e; }
  finally { enTx = false; }
}

// ---------- Fechas (hora local de la computadora) ----------
const p2 = (n) => String(n).padStart(2, '0');
export const fechaStr = (d) => `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
export const hoy = () => fechaStr(new Date());
export const ahora = () => { const d = new Date(); return `${fechaStr(d)} ${p2(d.getHours())}:${p2(d.getMinutes())}:${p2(d.getSeconds())}`; };
export function isoLocal(d = new Date()) {
  const off = -d.getTimezoneOffset(), s = off >= 0 ? '+' : '-', a = Math.abs(off);
  return `${fechaStr(d)}T${p2(d.getHours())}:${p2(d.getMinutes())}:${p2(d.getSeconds())}${s}${p2(Math.floor(a / 60))}:${p2(a % 60)}`;
}
const parse = (s) => { const [y, m, d] = s.slice(0, 10).split('-').map(Number); return new Date(y, m - 1, d); };
export const sumarDias = (s, n) => { const d = parse(s); d.setDate(d.getDate() + n); return fechaStr(d); };
export function sumarMeses(s, n) {
  const d = parse(s), dia = d.getDate();
  d.setDate(1); d.setMonth(d.getMonth() + n);
  const ultimo = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  d.setDate(Math.min(dia, ultimo));
  return fechaStr(d);
}
export const diasEntre = (a, b) => Math.round((parse(b) - parse(a)) / 86400000);
export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

// ---------- Contraseñas ----------
export function hashPass(pass) {
  const salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.scryptSync(String(pass), salt, 32).toString('hex');
}
export function checkPass(pass, hash) {
  const [salt, h] = String(hash).split(':');
  const calc = crypto.scryptSync(String(pass), salt, 32);
  return crypto.timingSafeEqual(calc, Buffer.from(h, 'hex'));
}

// ---------- Configuración ----------
export const CONFIG_DEFAULT = {
  cxp_dias_aviso: '3',            // avisar las cuentas por pagar que vencen en estos días
  asis_metodo: 'ambos',           // checador con: nip | huella | ambos
  asis_tolerancia: '10',          // minutos de tolerancia
  asis_desc_modo: 'fijo',         // fijo | minutos | ninguno
  asis_desc_monto: '50',          // pesos por retardo (modo fijo)
  asis_desc_doble: '0',           // 1 = cada retardo se descuenta doble
  asis_retardos_falta: '3',       // cada N retardos cuentan como 1 falta (0 = no)
  asis_falta_desc: '1',           // descontar el día por falta
  asis_festivo_pago: '2',         // trabajar en día festivo: pago extra de N días (ley: doble adicional)
  reloj_estado: 'auto',           // reloj ZKTeco: 'auto' (el sistema decide entrada/salida) o 'reloj' (usa la tecla del reloj)
  gym_nombre: 'Mi Gimnasio',
  gym_direccion: '',
  gym_telefono: '',
  ticket_pie: '¡Gracias por tu preferencia!',
  ticket_formato: 'completo',       // 'completo' o 'simple' (menos líneas, más rápido)
  ticket_logo: '0',                 // imprimir el logo del gimnasio en el ticket
  ticket_logo_maxsel: '1',          // logo chico de Maxsel al final del ticket
  imprimir_auto: '1',               // imprimir el ticket automáticamente al cobrar (sin preguntar)
  maxsel_contacto: '',              // contacto de Maxsel al final del ticket (un renglón por línea)
  gym_logo: '',                     // nombre del archivo del logo del gimnasio (en datos/)
  pantalla_logo_tam: 'mediano',     // tamaño del logo en la pantalla del cliente: chico, mediano, grande
  tipo_cambio: '17.50',
  lada: '52',
  hik_modo: 'simulador',          // 'simulador' o 'real'
  hik_ip: '',
  hik_puerto: '80',
  hik_usuario: 'admin',
  hik_password: '',
  hik_puerta: '1',
  servidor_ip: '',
  pantalla_segundos: '8',
  pantalla_visitas: '5',          // cuántas visitas anteriores mostrar (0 = no mostrar)
  pantalla_deudas: '1',           // mostrar lo que debe en la tienda
  pantalla_sonido: '1',
  pantalla_bienvenida: '¡Bienvenido! Acerca tu rostro al lector para entrar',
  pantalla_ok: '¡REGISTRO EXITOSO!',
  pantalla_no: 'ACCESO DENEGADO',
  pantalla_deuda_txt: 'Saldo pendiente',    // texto amable cuando tiene cuenta en tienda
  pantalla_sin_deuda: 'Cuenta al corriente',
  wa_vence: 'Hola {nombre} 👋, te recordamos que tu membresía en {gimnasio} vence el {fecha}. ¡Renueva y sigue entrenando! 💪',
  wa_vencida: 'Hola {nombre}, tu membresía en {gimnasio} venció el {fecha}. Te esperamos de regreso, pregunta por nuestras promociones 💪',
  wa_publicidad: 'Hola {nombre}, en {gimnasio} tenemos promociones especiales este mes. ¡Pregunta en recepción! 💪',
  wa_imagen: '',                    // imagen de publicidad (archivo en datos/)
};
export function cfg(clave) {
  const r = get('SELECT valor FROM config WHERE clave=?', clave);
  return r ? r.valor : CONFIG_DEFAULT[clave] ?? '';
}
export function cfgTodo() {
  const o = { ...CONFIG_DEFAULT };
  for (const r of all('SELECT clave, valor FROM config')) o[r.clave] = r.valor;
  return o;
}
export function setCfg(clave, valor) {
  run('INSERT INTO config(clave,valor) VALUES(?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor', clave, String(valor ?? ''));
}

// ---------- Datos iniciales ----------
if (!get('SELECT id FROM usuarios LIMIT 1')) {
  tx(() => {
    run('INSERT INTO usuarios(nombre,usuario,pass_hash,rol) VALUES(?,?,?,?)', 'Administrador', 'admin', hashPass('admin123'), 'admin');
    const planes = [
      ['Visita diaria', 1, 0, 80], ['Semanal', 7, 0, 250], ['Quincenal', 15, 0, 400],
      ['Mensual', 0, 1, 600], ['Trimestral', 0, 3, 1600], ['Semestral', 0, 6, 3000], ['Anual', 0, 12, 5500],
    ];
    planes.forEach((p, i) => run('INSERT INTO planes(nombre,dias,meses,precio,orden) VALUES(?,?,?,?,?)', ...p, i));
    run('INSERT INTO promociones(nombre,tipo,descuento_tipo,valor) VALUES(?,?,?,?)', 'Estudiante 15%', 'estudiante', 'porcentaje', 15);
    run('INSERT INTO promociones(nombre,tipo,descuento_tipo,valor) VALUES(?,?,?,?)', 'Pareja 20% (2 personas)', 'pareja', 'porcentaje', 20);
    run('INSERT INTO promociones(nombre,tipo,descuento_tipo,valor,zonas) VALUES(?,?,?,?,?)', 'Vecino de la zona 10%', 'vecino', 'porcentaje', 10, '');
    const prods = [
      ['7501055300075', 'Agua natural 1 L', 8, 20, 24], ['7501000112345', 'Bebida isotónica 600 ml', 14, 30, 24],
      ['7500000000017', 'Barra de proteína', 22, 45, 20], ['7500000000024', 'Toalla deportiva', 60, 150, 5],
    ];
    prods.forEach((p) => run('INSERT INTO productos(codigo,nombre,costo,precio,existencia) VALUES(?,?,?,?,?)', ...p));
  });
}
