// Maxsel Gimnasios 1.10 — Actualizar el sistema por internet (Configuración → Actualizaciones), igual que Maxsel POS y Maxsel Hotel
'use strict';
{
  const _cfg = VISTAS.config;
  VISTAS.config = async (v) => {
    await _cfg(v);
    if (estado.yo?.rol !== 'admin' && !puede('config')) return;
    const lic = $('#licInfo')?.closest('.panel'); if (!lic || $('#updPanel')) return;
    const c = estado.config;
    lic.insertAdjacentHTML('beforebegin', `<div class="panel" id="updPanel"><div class="fila" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
      <h2 style="margin:0">⟳ Actualizaciones</h2><button type="button" class="btn primario" id="updBuscar">Buscar actualización</button></div>
      <div id="updInfo" class="muted" style="margin-top:8px">${c.upd_disponible ? `Hay una versión nueva: <b>${esc(c.upd_disponible)}</b>. Presione "Buscar actualización".` : 'Necesita internet. La información del gimnasio (clientes, membresías, ventas, licencia y respaldos) no se toca al actualizar.'}</div>
      ${c.upd_ultima ? `<small class="muted">Última actualización: ${esc(c.upd_ultima)}</small>` : ''}</div>`);
    $('#updBuscar').onclick = () => updBuscar();
  };
}
async function updBuscar() {
  const box = $('#updInfo'); box.innerHTML = 'Buscando…';
  try {
    const r = await api('/api/actualizacion');
    estado.config.upd_disponible = r.hay ? r.disponible : ''; avisoUpd();
    box.innerHTML = r.hay
      ? `<div class="aviso-caja" style="display:block"><b>Hay una versión nueva: ${esc(r.disponible)}</b> (tiene la ${esc(r.instalada)}).${r.notas ? `<br>${esc(r.notas)}` : ''}
         <div style="margin-top:10px"><button type="button" class="btn primario" id="updInstalar">Instalar ahora</button></div>
         <small>Tarda menos de un minuto. El sistema se reinicia solo y los demás usuarios deben volver a entrar.</small></div>`
      : `Ya tiene la versión más reciente (<b>${esc(r.instalada)}</b>).`;
    $('#updInstalar') && ($('#updInstalar').onclick = (e) => updInstalar(e.currentTarget));
  } catch (e) { box.innerHTML = `<b class="rojo">${esc(e.message)}</b>`; }
}
async function updInstalar(b) {
  if (!await confirmar('Se descargará e instalará la versión nueva. El sistema se reinicia (unos 10 segundos). No se pierde ninguna información.', 'Instalar ahora')) return;
  b.disabled = true; b.textContent = 'Descargando e instalando…';
  try {
    const r = await api('/api/actualizacion/instalar', {});
    modal(`<h2>✅ Sistema actualizado</h2><p>Se instaló la versión <b>${esc(r.a)}</b> (antes ${esc(r.de)}).</p>
      <p>${r.servicio ? 'El sistema se está reiniciando; la página se vuelve a abrir sola en unos segundos.' : 'Cierre el sistema y vuelva a abrirlo.'}</p>
      <div class="modal-pie"><button class="btn primario" id="updRecargar">Volver a entrar</button></div>`);
    $('#updRecargar').onclick = () => location.reload();
    if (r.servicio) setTimeout(function esperar() { fetch('/api/licencia/estado').then((x) => (x.ok ? location.reload() : setTimeout(esperar, 1500))).catch(() => setTimeout(esperar, 1500)); }, 5000);
  } catch (e) { b.disabled = false; b.textContent = 'Instalar ahora'; toast(e.message, 'error'); }
}
// Aviso al administrador: número en "Configuración" cuando hay versión nueva
function avisoUpd() {
  const a = $('#nav [data-r="config"]'); if (!a) return;
  a.querySelector('.badge')?.remove();
  if (estado.config?.upd_disponible && (estado.yo?.rol === 'admin' || puede('config'))) a.insertAdjacentHTML('beforeend', '<b class="badge" title="Hay una versión nueva del sistema">1</b>');
}
setTimeout(() => { if (estado.yo) avisoUpd(); }, 3000);
