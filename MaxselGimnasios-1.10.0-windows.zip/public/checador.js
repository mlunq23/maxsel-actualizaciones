// Maxsel Gimnasios — pantalla del checador de asistencia de empleados (siempre abierta, esperando huella o NIP)
'use strict';
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const TIPOS = { entrada: 'Entrada', descanso: 'Salir a comer', regreso: 'Regreso de comer', salida: 'Salida' };
const TXT = { entrada: 'Entrada', descanso: 'Salida a comer', regreso: 'Regreso de comer', salida: 'Salida' };
let YO = null, CFG = {}, EST = {}, TIPO = '', tipoT = null, campo = 'n', N = '', P = '', leyendo = false, ocupado = false;

async function api(m, u, b) {
  const r = await fetch(u, { method: m, headers: b ? { 'content-type': 'application/json' } : {}, body: b ? JSON.stringify(b) : undefined });
  const d = await r.json().catch(() => ({}));
  if (r.status === 401) { pantallaLogin(); throw new Error('Inicie sesión'); }
  if (!r.ok) throw new Error(d.error || 'Error ' + r.status);
  return d;
}
const icoDedo = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M12 11c0 3.5-1 6.5-3 9"/><path d="M8.5 6.5A5 5 0 0 1 17 10c0 2-.2 4-.8 6"/><path d="M5.6 9.2A7 7 0 0 1 19 10c0 1.2 0 2.4-.2 3.6"/><path d="M15 12.5c-.2 2.8-.9 5.4-2.2 7.5"/><path d="M9 11a3 3 0 0 1 6 0"/><path d="M6.3 14.5c-.2 1.8-.7 3.4-1.4 4.8"/></svg>';

function pantallaLogin(msg) {
  leyendo = false;
  $('#app').innerHTML = `<form class="login" onsubmit="event.preventDefault();entrar()"><img src="/logo.png" alt="Maxsel" style="height:70px;align-self:center">
    <h2 style="text-align:center;margin:6px 0">Pantalla del checador</h2><div style="color:var(--muted);text-align:center">Entre con un usuario que tenga permiso de "Usar el checador". Queda abierta, no hace falta volver a entrar.</div>
    <input id="lu" placeholder="Usuario" autocomplete="username"><input id="lp" type="password" placeholder="Contraseña" autocomplete="current-password"><button>Entrar</button><div class="msg" id="lm">${esc(msg || '')}</div></form>`;
  $('#lu').focus();
}
async function entrar() {
  try {
    const r = await fetch('/api/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ usuario: $('#lu').value, password: $('#lp').value }) });
    const d = await r.json(); if (!r.ok) throw new Error(d.error || 'No se pudo entrar');
    inicio();
  } catch (e) { $('#lm').textContent = e.message; }
}
async function inicio() {
  try { YO = await api('GET', '/api/yo'); } catch { return; }
  if (!YO.permisos.includes('checador') && !YO.permisos.includes('asistencia')) return pantallaLogin('Este usuario no tiene permiso de usar el checador.');
  CFG = await api('GET', '/api/config');
  pintar(); await estadoLector(); tick(); setInterval(tick, 1000); ultimas(); setInterval(ultimas, 30000);
}
const usaNip = () => (EST.metodo || CFG.asis_metodo || 'ambos') !== 'huella';
const usaHuella = () => (EST.metodo || CFG.asis_metodo || 'ambos') !== 'nip';
function pintar() {
  $('#app').innerHTML = `<div class="raiz"><div class="top"><div style="display:flex;align-items:center;gap:14px"><img src="/logo.png" alt=""><div><div class="negocio">${esc(CFG.gym_nombre || 'Maxsel Gimnasios')}</div><div style="color:var(--muted)">Checador de asistencia</div></div></div><div class="estado" id="est"></div></div>
    <div class="medio"><div class="card reloj"><div class="hora" id="hora"></div><div class="fecha" id="fecha"></div><div class="dedo" id="dedo"></div></div>
      <div class="card"><div class="tipos">${Object.entries(TIPOS).map(([k, n]) => `<button data-t="${k}" onclick="elegir('${k}')">${n}</button>`).join('')}<button class="auto on" data-t="" onclick="elegir('')">Automático (el sistema sabe qué le toca)</button></div>
        ${usaNip() ? `<div class="nip"><div class="campos"><div class="campo on" id="cN" onclick="campo='n';marcar()"><small>Número</small><span id="vN"></span></div><div class="campo" id="cP" onclick="campo='p';marcar()"><small>NIP</small><span id="vP"></span></div></div>
          <div class="teclas">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map((d) => `<button onclick="tecla('${d}')">${d}</button>`).join('')}<button class="bor" onclick="tecla('<')">⌫</button><button onclick="tecla('0')">0</button><button class="ok" onclick="tecla('ok')">OK</button></div></div>` : ''}</div></div>
    <div class="ult" id="ult"></div></div><div class="pc"><button onclick="document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen()">Pantalla completa</button></div>`;
  marcar();
}
function tick() {
  const d = new Date(), h = $('#hora'); if (!h) return;
  const [t, ...ap] = d.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).split(' ');
  h.innerHTML = esc(t) + (ap.length ? `<small>${esc(ap.join(' '))}</small>` : '');
  const f = d.toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }); $('#fecha').textContent = f.charAt(0).toUpperCase() + f.slice(1);
}
function elegir(t) {
  TIPO = t; document.querySelectorAll('.tipos button').forEach((b) => b.classList.toggle('on', b.dataset.t === t));
  clearTimeout(tipoT); if (t) tipoT = setTimeout(() => elegir(''), 15000); // vuelve a automático si no checan
}
function marcar() { const a = $('#cN'), b = $('#cP'); if (!a) return; a.classList.toggle('on', campo === 'n'); b.classList.toggle('on', campo === 'p'); $('#vN').textContent = N; $('#vP').textContent = '•'.repeat(P.length); }
function tecla(k) {
  if (k === '<') { if (campo === 'p' && P) P = P.slice(0, -1); else if (campo === 'p') campo = 'n'; else N = N.slice(0, -1); }
  else if (k === 'ok') { if (campo === 'n' && N) campo = 'p'; else if (campo === 'p' && P) return checarNip(); }
  else if (campo === 'n') { if (N.length < 8) N += k; } else if (P.length < 8) P += k;
  marcar();
}
document.addEventListener('keydown', (e) => { if (!$('#vN')) return; if (/^\d$/.test(e.key)) tecla(e.key); else if (e.key === 'Backspace') tecla('<'); else if (e.key === 'Enter') tecla('ok'); });
async function checarNip() {
  try { mostrar(await api('POST', '/api/asistencia/checar', { numero: N, pin: P, tipo: TIPO || undefined })); }
  catch (e) { mostrarError(e.message); }
  N = ''; P = ''; campo = 'n'; marcar();
}
function mostrar(r) {
  const c = $('#res'); c.innerHTML = `<div class="caja ${r.aviso ? 'tarde' : ''}"><div class="n">${esc(r.nombre)}</div><div class="t">${esc(TXT[r.tipo] || r.texto)} · ${String(r.fecha).slice(11, 16)}</div>${r.aviso ? `<div class="a">${esc(r.aviso)}</div>` : ''}</div>`;
  c.style.display = 'flex'; clearTimeout(mostrar.t); mostrar.t = setTimeout(() => (c.style.display = 'none'), r.aviso ? 5000 : 3500);
  elegir(''); ultimas();
  try { const a = mostrar.ac || (mostrar.ac = new AudioContext()), o = a.createOscillator(), g = a.createGain(); g.gain.value = 0.2; o.frequency.value = 880; o.connect(g); g.connect(a.destination); o.start(); o.stop(a.currentTime + 0.15); } catch { /* sin sonido */ }
}
function mostrarError(m) { const c = $('#res'); c.innerHTML = `<div class="caja mal"><div class="t">${esc(m)}</div></div>`; c.style.display = 'flex'; clearTimeout(mostrar.t); mostrar.t = setTimeout(() => (c.style.display = 'none'), 3000); }
async function ultimas() {
  const el = $('#ult'); if (!el) return;
  try {
    const L = await api('GET', '/api/asistencia/hoy'), ch = [];
    for (const e of L) for (const c of e.checadas) ch.push({ n: e.nombre, ...c });
    ch.sort((a, b) => (a.fecha < b.fecha ? 1 : -1));
    el.innerHTML = ch.slice(0, 8).map((c) => `<div class="it"><b>${esc(c.n)}</b><span>${TXT[c.tipo]} · ${c.fecha.slice(11, 16)}</span></div>`).join('') || '<span style="color:var(--muted)">Nadie ha checado hoy.</span>';
  } catch { /* nada */ }
}
async function estadoLector() {
  try { EST = await api('GET', '/api/huella/estado'); } catch { EST = {}; }
  const est = $('#est'), dedo = $('#dedo');
  if (!usaHuella()) { est.innerHTML = 'Checado con <b>número y NIP</b>'; dedo.innerHTML = ''; return; }
  if (!EST.instalado || EST.error) {
    est.innerHTML = `<b style="color:var(--warn)">Lector de huellas: ${esc(EST.error || 'no instalado en esta computadora')}</b>${usaNip() ? '<br>Use su número y NIP' : ''}`;
    dedo.innerHTML = ''; setTimeout(estadoLector, 20000); return;
  }
  est.innerHTML = `Lector: <b>${esc(EST.lector || 'DigitalPersona')}</b> · ${EST.registradas} huella(s)`;
  dedo.className = 'dedo activo'; dedo.innerHTML = icoDedo + '<span>Ponga su dedo en el lector</span>';
  if (!leyendo) cicloHuella();
}
async function cicloHuella() {
  leyendo = true;
  while (leyendo) {
    try {
      const r = await api('POST', '/api/huella/checar', { segundos: 10, tipo: TIPO || undefined });
      if (r.sinDedo) continue;
      if (r.noReconocida) { mostrarError('Huella no reconocida. Intente de nuevo' + (usaNip() ? ' o use su número y NIP.' : '.')); await new Promise((ok) => setTimeout(ok, 1500)); continue; }
      mostrar(r); await new Promise((ok) => setTimeout(ok, 1500));
    } catch (e) {
      if (/Inicie sesión/.test(e.message)) { leyendo = false; return; }
      if (/ya registró/.test(e.message)) mostrarError(e.message); else { const est = $('#est'); if (est) est.innerHTML = `<b style="color:var(--warn)">${esc(e.message)}</b>`; }
      await new Promise((ok) => setTimeout(ok, 4000));
      if (/no está instalado|no se encontró|ninguno|solo con número/i.test(e.message)) { leyendo = false; setTimeout(estadoLector, 20000); return; }
    }
  }
}
inicio();
