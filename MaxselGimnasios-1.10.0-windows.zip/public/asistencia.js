// Maxsel Gimnasios 1.9 — Asistencia de empleados (checador con número y NIP, huella DigitalPersona o reloj ZKTeco)
// Igual que en Maxsel Hotel. Es un módulo aparte que se activa desde la licencia.
'use strict';
const EST_ASIS = {
  asistencia: ['Asistió', 'activo'], retardo: ['Retardo', 'por_vencer'], falta: ['Falta', 'vencido'], falta_registrada: ['Falta', 'vencido'], descanso: ['Descanso', 'sin'], festivo: ['Festivo', 'sin'],
  festivo_trabajado: ['Trabajó festivo', 'activo'], trabajo_descanso: ['Trabajó en descanso', 'activo'], pendiente: ['Pendiente', 'sin'], sin_horario: ['Sin horario', 'sin'],
  vacaciones: ['Vacaciones', 'azul'], permiso_goce: ['Permiso con goce', 'azul'], permiso_sin_goce: ['Permiso sin goce', 'por_vencer'], incapacidad: ['Incapacidad', 'sin'], descanso_extra: ['Descanso extra', 'sin'],
};
const TIPO_CHK = { entrada: 'Entrada', descanso: 'Salida a comer', regreso: 'Regreso de comer', salida: 'Salida' };
const TIPO_INC = { vacaciones: 'Vacaciones', descanso: 'Descanso extra', falta: 'Falta', permiso: 'Permiso', incapacidad: 'Incapacidad' };
const NOM_INC = { vacaciones: 'Vacaciones', permiso_goce: 'Permiso con goce', permiso_sin_goce: 'Permiso sin goce', incapacidad: 'Incapacidad', descanso_extra: 'Descanso extra' };
const METODO_CHK = { nip: 'Número y NIP', huella: 'Huella', manual: 'Manual', reloj: 'Reloj checador' };
const DIAS_SEMANA = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
const etqAsis = (e) => `<span class="etq ${EST_ASIS[e]?.[1] || 'sin'}">${EST_ASIS[e]?.[0] || esc(e)}</span>`;
const hm = (f) => (f ? String(f).slice(11, 16) : '');
const hrs = (min) => `${Math.floor(min / 60)}:${String(Math.round(min % 60)).padStart(2, '0')}`;
const lunesDe = () => { const x = new Date(); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`; };
const ASIS = { tab: 'checador', desde: null, hasta: null, emp: '', anio: new Date().getFullYear(), emps: [], huellaOn: false };

// Hoja carta para imprimir o guardar como PDF
function imprimirCarta(titulo, html) {
  const f = $('#ticketFrame'), d = f.contentDocument;
  d.open();
  d.write(`<html><head><title>${esc(titulo)}</title><style>@page{size:letter;margin:12mm}body{font:12px/1.35 Arial,sans-serif;color:#111;margin:0}h1{font-size:18px;margin:0 0 2px}h3{font-size:14px;margin:16px 0 6px}
    table{width:100%;border-collapse:collapse;margin:4px 0}th,td{border:1px solid #bbb;padding:3px 5px;text-align:left;vertical-align:top}th{background:#eee}.n{text-align:right}.sub{color:#555}.enc{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:2px solid #111;padding-bottom:6px;margin-bottom:8px}
    .firma{margin-top:28px;display:flex;gap:40px}.firma div{flex:1;text-align:center;border-top:1px solid #111;padding-top:4px}tr{page-break-inside:avoid}</style></head><body>${html}</body></html>`);
  d.close();
  setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); }, 300);
}

VISTAS.asistencia = async (v) => {
  const admin = puede('asistencia');
  if (!admin) ASIS.tab = 'checador';
  ASIS.desde = ASIS.desde || lunesDe(); ASIS.hasta = ASIS.hasta || hoyStr();
  const T = [['checador', '🕒 Checador'], ...(admin ? [['hoy', 'Hoy'], ['reporte', 'Reporte'], ['registros', 'Registros'], ['horarios', 'Horarios, NIP y huella'], ['festivos', 'Días festivos'], ['incid', 'Vacaciones y permisos'], ['reglas', 'Reglas y checador']] : [])];
  if (ASIS.tab !== 'checador') ASIS.huellaOn = false;
  v.innerHTML = `<div class="encabezado"><h1>Asistencia de empleados</h1><span class="muted">Entradas, salidas, comidas, retardos, faltas, festivos y vacaciones</span></div>
    <div class="filtros" style="margin-bottom:14px">${T.map(([k, n]) => `<button class="btn chico ${ASIS.tab === k ? 'sel' : ''}" data-tab="${k}">${n}</button>`).join('')}</div><div id="asisc"><p class="muted">Cargando…</p></div>`;
  $$('[data-tab]', v).forEach((b) => b.onclick = () => { ASIS.tab = b.dataset.tab; VISTAS.asistencia(v); });
  if (admin && ASIS.tab !== 'checador') ASIS.emps = await api('/api/asistencia/empleados');
  const fn = { checador: aChecador, hoy: aHoy, reporte: aReporte, registros: aRegistros, horarios: aHorarios, festivos: aFestivos, incid: aIncid, reglas: aReglas }[ASIS.tab];
  await fn(v);
  limpiarVista = () => { ASIS.huellaOn = false; clearInterval(aChecador.t); };
};
const selEmpAsis = (name, actual, todos) => `<select name="${name}" id="${name}"><option value="">${todos ? 'Todos los empleados' : '— Elija —'}</option>${ASIS.emps.filter((e) => e.activo || String(e.id) === String(actual)).map((e) => `<option value="${e.id}" ${String(e.id) === String(actual) ? 'selected' : ''}>${esc(e.nombre)}</option>`).join('')}</select>`;
const recargarAsis = () => VISTAS.asistencia($('#vista'));

// ---------- Checador ----------
async function aChecador() {
  let est = { instalado: false }; try { est = await api('/api/huella/estado'); } catch { /* sin permiso */ }
  const met = est.metodo || estado.config.asis_metodo || 'ambos', conNip = met !== 'huella', conHuella = met !== 'nip';
  $('#asisc').innerHTML = `<div class="aviso-caja"><span>Para dejar el checador siempre abierto use la <b>pantalla del checador</b> (también tiene icono en el escritorio: "Checador Maxsel Gimnasios").</span><button class="btn primario" id="bPant">🖥️ Abrir pantalla del checador</button></div>
    <div class="rejilla cols-2" style="margin-top:14px">
      <div class="panel chk-reloj"><div id="chkHora" class="chk-hora"></div><div id="chkFecha" class="muted"></div><div id="chkRes" class="chk-res">${conNip ? 'Ponga su número y NIP' + (conHuella && est.instalado && !est.error ? ', o su dedo en el lector' : '') : 'Ponga su dedo en el lector'}.</div></div>
      <div class="panel">${conNip ? `<form class="form" id="fChk" autocomplete="off"><label>Número de empleado<input name="numero" id="chkN" inputmode="numeric" style="font-size:22px"></label><label>NIP<input name="pin" id="chkP" type="password" inputmode="numeric" style="font-size:22px"></label>
        <div class="todo fila" style="flex-wrap:wrap;gap:6px"><button class="btn primario">Checar</button>${Object.entries(TIPO_CHK).map(([k, n]) => `<button type="button" class="btn" data-t="${k}">${n}</button>`).join('')}</div>
        <p class="muted todo" style="margin:0">"Checar" elige solo: entrada → salida a comer → regreso → salida.</p></form>` : '<p class="muted">El checador está configurado solo con huella (vea Reglas).</p>'}
        <h3 style="margin:16px 0 6px">Lector de huellas</h3>${!conHuella ? '<p class="muted" style="margin:0">El checador está configurado solo con número y NIP.</p>' : !est.instalado ? '<p class="muted" style="margin:0">El lector de huellas no está instalado en esta computadora. Se checa con número y NIP.</p>'
          : est.error ? `<p class="rojo">${esc(est.error)}</p>` : `<p style="margin:0">Lector: <b>${esc(est.lector || 'DigitalPersona')}</b> · ${est.registradas} huella(s) registradas</p>
          <button class="btn ${ASIS.huellaOn ? 'peligro' : 'primario'}" id="bHuella" style="margin-top:10px">${ASIS.huellaOn ? 'Detener lector' : 'Activar checado con huella'}</button>`}</div></div>
    <div class="panel" style="margin-top:14px"><h2>Hoy</h2><div id="chkHoy"></div></div>`;
  $('#bPant').onclick = () => window.open('/checador', 'checador', 'width=1280,height=800');
  const reloj = () => { const h = $('#chkHora'); if (!h) return clearInterval(aChecador.t); const d = new Date(); h.textContent = d.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit', second: '2-digit' }); $('#chkFecha').textContent = d.toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }); };
  clearInterval(aChecador.t); reloj(); aChecador.t = setInterval(reloj, 1000);
  const checar = async (tipo) => {
    try {
      const r = await api('/api/asistencia/checar', { numero: $('#chkN').value, pin: $('#chkP').value, tipo });
      $('#chkN').value = ''; $('#chkP').value = ''; $('#chkN').focus(); mostrarChecada(r);
    } catch (e) { $('#chkRes').innerHTML = `<b class="rojo">${esc(e.message)}</b>`; $('#chkP').value = ''; }
  };
  if (conNip) {
    $('#fChk').onsubmit = (e) => { e.preventDefault(); if (!$('#chkP').value) return $('#chkP').focus(); checar(); };
    $$('[data-t]', $('#fChk')).forEach((b) => b.onclick = () => checar(b.dataset.t));
    $('#chkN').addEventListener('keydown', (e) => { if (e.key === 'Enter' && $('#chkN').value) { e.preventDefault(); $('#chkP').focus(); } });
    $('#chkN').focus();
  }
  $('#bHuella') && ($('#bHuella').onclick = () => { ASIS.huellaOn = !ASIS.huellaOn; aChecador(); if (ASIS.huellaOn) cicloHuella(); });
  chkHoy();
}
async function chkHoy() {
  const el = $('#chkHoy'); if (!el) return;
  const L = await api('/api/asistencia/hoy').catch(() => []);
  el.innerHTML = `<table>${L.map((e) => `<tr><td><b>${esc(e.nombre)}</b><br><small class="muted">${esc(e.puesto || '')}</small></td><td>${e.ultima ? `${TIPO_CHK[e.ultima.tipo]} ${hm(e.ultima.fecha)}` : '<span class="muted">Sin checar</span>'}</td><td>${e.estado ? etqAsis(e.estado) : ''}</td></tr>`).join('') || '<tr><td class="vacio">Todavía no hay empleados.</td></tr>'}</table>`;
}
function mostrarChecada(r) {
  const el = $('#chkRes'); if (!el) return;
  el.innerHTML = `<div class="chk-ok ${r.aviso ? 'tarde' : ''}"><b>${esc(r.nombre)}</b><span>${esc(r.texto)} · ${hm(r.fecha)}${r.metodo === 'huella' ? ' · huella' : ''}</span>${r.aviso ? `<span class="rojo">${esc(r.aviso)}</span>` : ''}</div>`;
  clearTimeout(mostrarChecada.t); mostrarChecada.t = setTimeout(() => { const x = $('#chkRes'); if (x) x.textContent = 'Listo para el siguiente.'; }, 6000);
  chkHoy();
}
async function cicloHuella() {
  while (ASIS.huellaOn && $('#chkRes')) {
    try {
      const r = await api('/api/huella/checar', { segundos: 10 });
      if (r.sinDedo) continue;
      if (r.noReconocida) { $('#chkRes').innerHTML = '<b class="rojo">Huella no reconocida. Intente otra vez o use su número y NIP.</b>'; continue; }
      mostrarChecada(r); await new Promise((ok) => setTimeout(ok, 1500));
    } catch (e) {
      const x = $('#chkRes'); if (x) x.innerHTML = `<b class="rojo">${esc(e.message)}</b>`;
      await new Promise((ok) => setTimeout(ok, 3000)); if (/no está instalado|ningún|solo con número/i.test(e.message)) ASIS.huellaOn = false;
    }
  }
}

// ---------- Hoy ----------
async function aHoy() {
  const L = await api('/api/asistencia/hoy'), c = (k) => L.filter((e) => e.estado === k).length;
  const dentro = L.filter((e) => e.ultima && (e.ultima.tipo === 'entrada' || e.ultima.tipo === 'regreso')).length, desc = L.filter((e) => e.ultima?.tipo === 'descanso').length;
  $('#asisc').innerHTML = `<div class="rejilla cols-4"><div class="kpi"><small>Trabajando ahora</small><b>${dentro}</b><small>${desc} comiendo</small></div><div class="kpi"><small>Retardos hoy</small><b class="ambar">${c('retardo')}</b></div>
      <div class="kpi"><small>Faltas hoy</small><b class="rojo">${c('falta') + c('falta_registrada')}</b><small>${c('pendiente')} aún no llegan</small></div><div class="kpi"><small>Descanso / vacaciones</small><b>${c('descanso') + c('vacaciones') + c('festivo') + c('descanso_extra')}</b></div></div>
    <div class="panel" style="margin-top:14px"><div class="tabla-scroll"><table><tr><th>Empleado</th><th>Horario hoy</th><th>Checadas</th><th>Estado</th></tr>
    ${L.map((e) => `<tr><td><b>${esc(e.nombre)}</b><br><small class="muted">${esc(e.puesto || '')}</small></td><td>${e.horario ? `${e.horario.entrada} a ${e.horario.salida}` : '<span class="muted">Descansa / sin horario</span>'}</td><td>${e.checadas.map((x) => `${TIPO_CHK[x.tipo]} ${hm(x.fecha)}`).join('<br>') || '—'}</td><td>${e.estado ? etqAsis(e.estado) : ''}${e.tarde ? ` <small class="muted">${e.tarde} min</small>` : ''}</td></tr>`).join('') || '<tr><td colspan="4" class="vacio">Agregue empleados en la pestaña "Horarios, NIP y huella".</td></tr>'}</table></div></div>`;
}

// ---------- Reporte ----------
const filtroFechas = (extra = '') => `<div class="panel fila" style="flex-wrap:wrap;gap:8px;align-items:flex-end;margin-bottom:14px"><label>Desde<input type="date" id="arD" value="${ASIS.desde}"></label><label>Hasta<input type="date" id="arH" value="${ASIS.hasta}"></label><label>Empleado${selEmpAsis('arE', ASIS.emp, true)}</label>
  <button class="btn" id="arVer">Ver</button><button class="btn" id="arSem">Esta semana</button><button class="btn" id="arMes">Este mes</button><span style="flex:1"></span>${extra}</div>`;
function enlazarFiltro(fn) {
  $('#arVer').onclick = () => { ASIS.desde = $('#arD').value; ASIS.hasta = $('#arH').value; ASIS.emp = $('#arE').value; fn(); };
  $('#arSem').onclick = () => { ASIS.desde = lunesDe(); ASIS.hasta = hoyStr(); fn(); };
  $('#arMes').onclick = () => { ASIS.desde = hoyStr().slice(0, 8) + '01'; ASIS.hasta = hoyStr(); fn(); };
}
async function aReporte() {
  $('#asisc').innerHTML = filtroFechas('<button class="btn" id="arPdf">📄 PDF</button><button class="btn primario" id="arXls">📊 Excel</button>') + '<div id="arR"><p class="muted">Calculando…</p></div>';
  enlazarFiltro(aReporte);
  const R = await api(`/api/asistencia/reporte?desde=${ASIS.desde}&hasta=${ASIS.hasta}&empleado_id=${ASIS.emp}`); aReporte.R = R;
  const tot = (k) => R.reduce((s, r) => s + (r.resumen[k] || 0), 0);
  $('#arR').innerHTML = `<div class="rejilla cols-4"><div class="kpi"><small>Retardos</small><b class="ambar">${tot('retardos')}</b><small>${tot('min_tarde')} minutos en total</small></div><div class="kpi"><small>Faltas</small><b class="rojo">${tot('faltas')}</b><small>+ ${tot('faltas_retardos')} por acumular retardos</small></div>
      <div class="kpi"><small>Descuentos</small><b class="rojo">${dinero(tot('total_descuento'))}</b><small>retardos ${dinero(tot('desc_retardos'))} · faltas ${dinero(tot('desc_faltas'))}</small></div><div class="kpi"><small>Pago extra festivos</small><b>${dinero(tot('pago_festivos'))}</b><small>${tot('festivos_trabajados')} festivo(s) trabajados</small></div></div>
    <div class="panel" style="margin-top:14px"><div class="tabla-scroll"><table><tr><th>Empleado</th><th class="num">Días trab.</th><th class="num">Horas</th><th class="num">Retardos</th><th class="num">Min. tarde</th><th class="num">Faltas</th><th class="num">Por retardos</th><th class="num">Descansos</th><th class="num">Festivos trab.</th><th>Vacaciones / permisos</th><th class="num">Descuento</th><th class="num">Extra festivos</th></tr>
    ${R.map((r, i) => { const x = r.resumen; return `<tr class="click" data-i="${i}"><td><b>${esc(r.empleado.nombre)}</b><br><small class="muted">${esc(r.empleado.puesto || '')}${r.empleado.horario ? '' : ' · sin horario'}</small></td><td class="num">${x.trabajados}</td><td class="num">${hrs(x.min_trabajados)}</td><td class="num">${x.retardos}</td><td class="num">${x.min_tarde}</td><td class="num">${x.faltas}</td><td class="num">${x.faltas_retardos}</td><td class="num">${x.descansos}</td><td class="num">${x.festivos_trabajados}</td>
      <td>${Object.entries(x.incidencias).map(([k, n]) => `${NOM_INC[k] || k} ${n}`).join(', ') || '—'}</td><td class="num ${x.total_descuento ? 'rojo' : ''}">${dinero(x.total_descuento)}</td><td class="num">${dinero(x.pago_festivos)}</td></tr>`; }).join('') || '<tr><td colspan="12" class="vacio">Sin empleados.</td></tr>'}</table></div>
    <p class="muted" style="margin:8px 0 0">Toque un empleado para ver día por día. Los descuentos salen de las Reglas y se usan al "Pagar" en Empleados.</p></div>`;
  $$('tr[data-i]', $('#arR')).forEach((tr) => tr.onclick = () => detAsis(R[tr.dataset.i]));
  $('#arXls').onclick = (e) => intentar(() => excelAsis(R), e.currentTarget);
  $('#arPdf').onclick = () => pdfAsis(R);
}
function detAsis(r) {
  const x = r.resumen;
  modal(`<h2>${esc(r.empleado.nombre)}</h2><p class="muted" style="margin-top:-6px">Del ${fecha(ASIS.desde)} al ${fecha(ASIS.hasta)}</p>
    <div class="rejilla cols-4"><div class="kpi"><small>Sueldo diario</small><b>${dinero(x.sueldo_diario)}</b></div><div class="kpi"><small>Por retardos</small><b>${dinero(x.desc_retardos)}</b></div><div class="kpi"><small>Por faltas</small><b>${dinero(x.desc_faltas)}</b></div><div class="kpi"><small>Total a descontar</small><b class="rojo">${dinero(x.total_descuento)}</b><small>extra festivos ${dinero(x.pago_festivos)}</small></div></div>
    <div class="tabla-scroll" style="max-height:52vh;margin-top:10px"><table><tr><th>Fecha</th><th>Horario</th><th>Entrada</th><th>Comida</th><th>Salida</th><th class="num">Trabajó</th><th>Estado</th><th class="num">Desc. / extra</th></tr>
    ${r.dias.map((d) => `<tr><td>${DIAS_SEMANA[d.dow].slice(0, 3)} ${fecha(d.fecha)}</td><td>${d.horario ? d.horario.entrada + '–' + d.horario.salida : '—'}</td><td>${hm(d.entrada)}</td><td>${d.descanso_min ? d.descanso_min + ' min' : ''}</td><td>${hm(d.salida)}</td><td class="num">${d.trabajado_min ? hrs(d.trabajado_min) : ''}</td>
      <td>${etqAsis(d.estado)}${d.tarde ? ` <small class="muted">${d.tarde} min</small>` : ''}${d.nota ? `<br><small class="muted">${esc(d.nota)}</small>` : ''}</td><td class="num">${d.descuento ? dinero(d.descuento) : d.extra ? '+' + dinero(d.extra) : ''}</td></tr>`).join('')}</table></div>
    <div class="modal-pie"><button class="btn" data-cerrar>Cerrar</button></div>`, { ancho: true });
}
function excelAsis(R) {
  if (!R?.length) throw new Error('No hay datos');
  const fx = (s) => (s ? s.slice(0, 10).split('-').reverse().join('/') : '');
  const g = estado.config.gym_nombre;
  descargarExcel(`Asistencia ${ASIS.desde} al ${ASIS.hasta}`, [
    { nombre: 'Resumen', titulo: `${g} · Asistencia del ${fx(ASIS.desde)} al ${fx(ASIS.hasta)}`,
      columnas: [{ t: 'Empleado', ancho: 26 }, { t: 'Puesto', ancho: 16 }, { t: 'Días trabajados', ancho: 10, tipo: 'entero' }, { t: 'Horas', ancho: 9 }, { t: 'Retardos', ancho: 9, tipo: 'entero' }, { t: 'Minutos tarde', ancho: 10, tipo: 'entero' }, { t: 'Faltas', ancho: 8, tipo: 'entero' }, { t: 'Faltas por retardos', ancho: 10, tipo: 'entero' },
        { t: 'Descansos', ancho: 9, tipo: 'entero' }, { t: 'Festivos trabajados', ancho: 10, tipo: 'entero' }, { t: 'Vacaciones / permisos', ancho: 24 }, { t: 'Sueldo diario', ancho: 12, tipo: 'dinero' }, { t: 'Desc. retardos', ancho: 12, tipo: 'dinero' }, { t: 'Desc. faltas', ancho: 12, tipo: 'dinero' }, { t: 'Total descuento', ancho: 13, tipo: 'dinero' }, { t: 'Extra festivos', ancho: 12, tipo: 'dinero' }],
      filas: R.map((r) => { const x = r.resumen; return [r.empleado.nombre, r.empleado.puesto || '', x.trabajados, hrs(x.min_trabajados), x.retardos, x.min_tarde, x.faltas, x.faltas_retardos, x.descansos, x.festivos_trabajados, Object.entries(x.incidencias).map(([k, n]) => `${NOM_INC[k] || k} ${n}`).join(', '), x.sueldo_diario, x.desc_retardos, x.desc_faltas, x.total_descuento, x.pago_festivos]; }) },
    { nombre: 'Día por día', titulo: 'Día por día', columnas: [{ t: 'Empleado', ancho: 24 }, { t: 'Fecha', ancho: 11 }, { t: 'Día', ancho: 10 }, { t: 'Horario', ancho: 12 }, { t: 'Entrada', ancho: 8 }, { t: 'Comida (min)', ancho: 9, tipo: 'entero' }, { t: 'Salida', ancho: 8 }, { t: 'Horas', ancho: 8 }, { t: 'Estado', ancho: 16 }, { t: 'Min. tarde', ancho: 9, tipo: 'entero' }, { t: 'Descuento', ancho: 11, tipo: 'dinero' }, { t: 'Extra', ancho: 10, tipo: 'dinero' }, { t: 'Nota', ancho: 24 }],
      filas: R.flatMap((r) => r.dias.map((d) => [r.empleado.nombre, fx(d.fecha), DIAS_SEMANA[d.dow], d.horario ? d.horario.entrada + '-' + d.horario.salida : '', hm(d.entrada), d.descanso_min || '', hm(d.salida), d.trabajado_min ? hrs(d.trabajado_min) : '', EST_ASIS[d.estado]?.[0] || d.estado, d.tarde || '', d.descuento || '', d.extra || '', d.nota || ''])) },
    { nombre: 'Checadas', titulo: 'Checadas', columnas: [{ t: 'Empleado', ancho: 24 }, { t: 'Fecha', ancho: 11 }, { t: 'Hora', ancho: 8 }, { t: 'Tipo', ancho: 16 }, { t: 'Cómo', ancho: 14 }],
      filas: R.flatMap((r) => r.dias.flatMap((d) => d.checadas.map((c) => [r.empleado.nombre, fx(c.fecha), hm(c.fecha), TIPO_CHK[c.tipo], METODO_CHK[c.metodo] || c.metodo || '']))) },
  ]);
  toast('Excel descargado', 'ok');
}
function pdfAsis(R) {
  if (!R?.length) return toast('No hay datos', 'error');
  imprimirCarta('Reporte de asistencia', `<div class="enc"><div><h1>${esc(estado.config.gym_nombre)}</h1><div class="sub">REPORTE DE ASISTENCIA</div></div><div>Del ${fecha(ASIS.desde)} al ${fecha(ASIS.hasta)}</div></div>
    <h3>Resumen</h3><table><tr><th>Empleado</th><th class="n">Días</th><th class="n">Horas</th><th class="n">Retardos</th><th class="n">Min.</th><th class="n">Faltas</th><th class="n">x Ret.</th><th class="n">Fest. trab.</th><th>Vac./perm.</th><th class="n">Descuento</th><th class="n">Extra</th></tr>
    ${R.map((r) => { const x = r.resumen; return `<tr><td>${esc(r.empleado.nombre)}</td><td class="n">${x.trabajados}</td><td class="n">${hrs(x.min_trabajados)}</td><td class="n">${x.retardos}</td><td class="n">${x.min_tarde}</td><td class="n">${x.faltas}</td><td class="n">${x.faltas_retardos}</td><td class="n">${x.festivos_trabajados}</td><td>${Object.entries(x.incidencias).map(([k, n]) => `${NOM_INC[k] || k} ${n}`).join(', ')}</td><td class="n">${dinero(x.total_descuento)}</td><td class="n">${dinero(x.pago_festivos)}</td></tr>`; }).join('')}</table>
    ${R.map((r) => `<h3>${esc(r.empleado.nombre)}${r.empleado.puesto ? ' · ' + esc(r.empleado.puesto) : ''}</h3><table><tr><th>Fecha</th><th>Horario</th><th>Entrada</th><th>Comida</th><th>Salida</th><th class="n">Horas</th><th>Estado</th><th class="n">Desc./extra</th></tr>
      ${r.dias.map((d) => `<tr><td>${DIAS_SEMANA[d.dow].slice(0, 3)} ${fecha(d.fecha)}</td><td>${d.horario ? d.horario.entrada + '–' + d.horario.salida : '—'}</td><td>${hm(d.entrada)}</td><td>${d.descanso_min ? d.descanso_min + "'" : ''}</td><td>${hm(d.salida)}</td><td class="n">${d.trabajado_min ? hrs(d.trabajado_min) : ''}</td><td>${EST_ASIS[d.estado]?.[0] || d.estado}${d.tarde ? ' (' + d.tarde + ' min)' : ''}</td><td class="n">${d.descuento ? '-' + dinero(d.descuento) : d.extra ? '+' + dinero(d.extra) : ''}</td></tr>`).join('')}</table>
      <div class="firma"><div>Total a descontar ${dinero(r.resumen.total_descuento)} · extra festivos ${dinero(r.resumen.pago_festivos)}</div><div>Firma de conformidad de ${esc(r.empleado.nombre)}</div></div>`).join('')}
    <p class="sub">Impreso ${new Date().toLocaleString('es-MX')}</p>`);
}

// ---------- Registros (checadas) ----------
async function aRegistros() {
  const L = await api(`/api/asistencia/checadas?desde=${ASIS.desde}&hasta=${ASIS.hasta}&empleado_id=${ASIS.emp}`);
  $('#asisc').innerHTML = filtroFechas('<button class="btn primario" id="bMan">+ Agregar registro (olvidó checar)</button>') + `<div class="panel"><div class="tabla-scroll"><table><tr><th>Fecha y hora</th><th>Empleado</th><th>Tipo</th><th>Cómo</th><th>Nota</th><th></th></tr>
    ${L.map((c) => `<tr style="${c.anulada ? 'opacity:.45;text-decoration:line-through' : ''}"><td>${fechaHora(c.fecha)}</td><td>${esc(c.nombre)}</td><td>${TIPO_CHK[c.tipo]}</td><td>${METODO_CHK[c.metodo] || ''}${c.metodo === 'manual' && c.usuario ? ' · ' + esc(c.usuario) : ''}</td><td class="muted">${esc(c.nota || '')}</td><td>${c.anulada ? '' : `<button class="btn chico" data-an="${c.id}" style="color:var(--rojo)">Anular</button>`}</td></tr>`).join('') || '<tr><td colspan="6" class="vacio">Sin registros en esas fechas.</td></tr>'}</table></div></div>`;
  enlazarFiltro(aRegistros);
  $$('[data-an]').forEach((b) => b.onclick = async () => { if (await confirmar('Se anulará esta checada (queda tachada).', 'Sí, anular')) intentar(async () => { await api(`/api/asistencia/checadas/${b.dataset.an}/anular`, {}); toast('Registro anulado', 'ok'); aRegistros(); }); });
  $('#bMan').onclick = () => {
    const m = modal(`<h2>Agregar registro manual</h2><form class="form" id="f"><label>Empleado${selEmpAsis('empleado_id', ASIS.emp)}</label><label>Tipo<select name="tipo">${Object.entries(TIPO_CHK).map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select></label>
      <label>Fecha y hora<input name="fecha" type="datetime-local" value="${hoyStr()}T08:00" required></label><label>Motivo<input name="nota" placeholder="Ej. olvidó checar, se descompuso el lector"></label>
      <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`);
    $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => { await api('/api/asistencia/checadas', valores(e.target)); m.cerrar(); toast('Registro agregado', 'ok'); aRegistros(); }); };
  };
}

// ---------- Horarios, NIP y huella ----------
function resumenHorario(h) {
  const g = {}; for (let k = 1; k <= 7; k++) { const d = k % 7, x = h[d]; const key = x ? `${x.entrada}–${x.salida}` : 'Descansa'; (g[key] ||= []).push(DIAS_SEMANA[d].slice(0, 3)); }
  return Object.entries(g).map(([k, ds]) => `${ds.join(', ')}: ${k}`).join(' · ');
}
async function aHorarios() {
  let est = { instalado: false }; try { est = await api('/api/huella/estado'); } catch { /* nada */ }
  aHorarios.est = est;
  let relojes = []; try { relojes = await api('/api/relojes'); } catch { /* nada */ }
  $('#asisc').innerHTML = `<div class="panel"><div class="fila" style="justify-content:space-between;align-items:center"><h2 style="margin:0">Empleados que checan</h2><button class="btn chico" id="bNuevoEmp">+ Nuevo empleado</button></div>
    <div class="tabla-scroll"><table><tr><th>Empleado</th><th>Número</th><th>NIP</th><th>Huella</th><th>Horario</th><th></th></tr>
    ${ASIS.emps.filter((e) => e.activo).map((e) => `<tr class="click" data-h="${e.id}"><td><b>${esc(e.nombre)}</b><br><small class="muted">${esc(e.puesto || '')}</small></td><td><b>${esc(e.numero || '—')}</b></td><td>${e.tiene_pin ? '<span class="etq activo">Sí</span>' : '<span class="etq por_vencer">Falta</span>'}</td><td>${e.tiene_huella ? '<span class="etq activo">Registrada</span>' : '<span class="muted">—</span>'}</td>
      <td><small class="muted">${e.horario ? resumenHorario(e.horario) : 'Sin horario (no cuenta retardos ni faltas)'}</small></td><td><button class="btn chico">✏️ Editar</button></td></tr>`).join('') || '<tr><td colspan="6" class="vacio">Todavía no hay empleados. Presione "Nuevo empleado".</td></tr>'}</table></div>
    <p class="muted" style="margin:8px 0 0">${est.instalado ? (est.error ? 'Lector de huellas: ' + esc(est.error) : 'Lector de huellas listo: ' + esc(est.lector || '')) : 'El lector de huellas no está instalado en esta computadora (se puede checar con número y NIP).'}</p></div>
    <div class="panel" style="margin-top:14px"><h2>Reloj checador por red (ZKTeco)</h2>
      <p class="muted">En el reloj: Menú → Comunicación → Servidor en la nube (ADMS): dirección <b>${esc((estado.config._ips || [])[0] || 'IP de esta computadora')}</b>, puerto <b>${esc(estado.config._puerto || 3030)}</b>. El número de usuario del reloj debe ser el mismo "Número" del empleado. Cuando el reloj aparezca aquí, actívelo.</p>
      <table>${relojes.map((r) => `<tr><td><b>${esc(r.nombre)}</b><br><small class="muted">Serie ${esc(r.sn)} · IP ${esc(r.ip || '')} · último contacto ${fechaHora(r.ultimo)}</small></td><td>${r.activo ? '<span class="etq activo">Activo</span>' : '<span class="etq por_vencer">Esperando activación</span>'}</td>
        <td class="fila" style="justify-content:flex-end"><button class="btn chico ${r.activo ? '' : 'primario'}" data-rel="${esc(r.sn)}" data-act="${r.activo ? 0 : 1}">${r.activo ? 'Desactivar' : 'Activar'}</button><button class="btn chico" data-relq="${esc(r.sn)}">✕</button></td></tr>`).join('') || '<tr><td class="vacio">Ningún reloj se ha conectado todavía.</td></tr>'}</table></div>`;
  $$('[data-h]').forEach((tr) => tr.onclick = () => modalHorario(ASIS.emps.find((e) => e.id == tr.dataset.h)));
  $$('[data-rel]').forEach((b) => b.onclick = () => intentar(async () => { await api('/api/relojes/' + encodeURIComponent(b.dataset.rel), { activo: b.dataset.act === '1' }, 'PUT'); aHorarios(); }));
  $$('[data-relq]').forEach((b) => b.onclick = async () => { if (await confirmar('Se quitará este reloj de la lista.', 'Sí, quitar')) intentar(async () => { await api('/api/relojes/' + encodeURIComponent(b.dataset.relq), {}, 'DELETE'); aHorarios(); }); });
  $('#bNuevoEmp').onclick = () => {
    const m = modal(`<h2>Nuevo empleado</h2><form class="form" id="f"><label class="todo">Nombre completo<input name="nombre" required autofocus></label><label>Puesto<input name="puesto" placeholder="Ej. Recepción, Instructor"></label>
      <label>Sueldo por periodo<input name="sueldo" type="number" step="0.01" min="0" placeholder="Para calcular descuentos"></label><label>Se le paga<select name="periodo"><option value="semanal">Semanal</option><option value="quincenal" selected>Quincenal</option><option value="mensual">Mensual</option></select></label>
      <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`);
    $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => { const r = await api('/api/asistencia/empleados', valores(e.target)); m.cerrar(); ASIS.emps = await api('/api/asistencia/empleados'); modalHorario(ASIS.emps.find((x) => x.id === r.id)); }); };
  };
}
function modalHorario(e) {
  if (!e) return;
  const h = e.horario || {}, est = aHorarios.est || {};
  const fila = (d) => { const x = h[d]; return `<tr><td><label class="em-chk"><input type="checkbox" id="hT${d}" ${x || (!e.horario && d !== 0) ? 'checked' : ''}> ${DIAS_SEMANA[d]}</label></td><td><input type="time" id="hE${d}" value="${x?.entrada || '08:00'}"></td><td><input type="time" id="hS${d}" value="${x?.salida || '16:00'}"></td><td><input type="number" min="0" id="hD${d}" value="${x?.descanso ?? 60}" style="width:80px"></td></tr>`; };
  const m = modal(`<h2>Checador y horario · ${esc(e.nombre)}</h2>
    <div class="form"><label>Número para checar<input id="hN" value="${esc(e.numero || '')}" inputmode="numeric" autofocus></label><label>NIP nuevo (4 a 8 números)<input id="hP" type="password" inputmode="numeric" placeholder="${e.tiene_pin ? 'Déjelo vacío para no cambiarlo' : 'Ej. 1234'}"></label></div>
    <p style="margin:10px 0 4px"><b>Horario de trabajo</b> <small class="muted">(desmarque los días que descansa)</small></p>
    <table><tr><th>Día</th><th>Entrada</th><th>Salida</th><th>Comida (min)</th></tr>${[1, 2, 3, 4, 5, 6, 0].map(fila).join('')}</table>
    <div class="fila" style="gap:8px;margin-top:6px;flex-wrap:wrap"><button type="button" class="btn chico" id="hCopiar">Copiar el horario del lunes a todos</button>
      <label class="em-chk"><input type="checkbox" id="hSin" ${e.horario ? '' : 'checked'}> Sin horario (no calcula retardos ni faltas)</label></div>
    <div class="panel" style="margin-top:12px"><b>Huella digital</b>${est.instalado && !est.error ? `<p style="margin:4px 0">${e.tiene_huella ? 'Ya tiene huella registrada.' : 'Aún no tiene huella.'}</p><div class="fila" style="gap:8px"><button type="button" class="btn primario" id="hEnr">${e.tiene_huella ? 'Volver a registrar huella' : 'Registrar huella'}</button>${e.tiene_huella ? '<button type="button" class="btn" id="hBor" style="color:var(--rojo)">Borrar huella</button>' : ''}</div><div id="enrRes" class="muted" style="margin-top:6px"></div>`
      : `<p class="muted" style="margin:4px 0">${est.error ? esc(est.error) : 'El lector de huellas no está instalado en esta computadora.'}</p>`}</div>
    <div class="modal-pie"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario" id="hOk">Guardar</button></div>`, { ancho: true });
  $('#hCopiar', m).onclick = () => { for (const d of [2, 3, 4, 5, 6, 0]) { $('#hE' + d, m).value = $('#hE1', m).value; $('#hS' + d, m).value = $('#hS1', m).value; $('#hD' + d, m).value = $('#hD1', m).value; } };
  $('#hOk', m).onclick = (ev) => intentar(async () => {
    let horario = null;
    if (!$('#hSin', m).checked) { horario = {}; for (let d = 0; d <= 6; d++) horario[d] = $('#hT' + d, m).checked ? { entrada: $('#hE' + d, m).value, salida: $('#hS' + d, m).value, descanso: Number($('#hD' + d, m).value) || 0 } : null; }
    await api('/api/asistencia/empleados/' + e.id, { numero: $('#hN', m).value, pin: $('#hP', m).value, horario }, 'PUT');
    m.cerrar(); toast('Guardado', 'ok'); recargarAsis();
  }, ev.currentTarget);
  $('#hEnr', m) && ($('#hEnr', m).onclick = async () => {
    $('#enrRes', m).innerHTML = 'Ponga el <b>mismo dedo</b> en el lector varias veces (4 normalmente). Levántelo entre cada vez.';
    try { const r = await api('/api/huella/enrolar/' + e.id, {}); toast(`Huella registrada (${r.muestras} lecturas)`, 'ok'); m.cerrar(); recargarAsis(); } catch (er) { $('#enrRes', m).innerHTML = `<b class="rojo">${esc(er.message)}</b>`; }
  });
  $('#hBor', m) && ($('#hBor', m).onclick = () => intentar(async () => { await api('/api/huella/' + e.id, {}, 'DELETE'); m.cerrar(); toast('Huella borrada', 'ok'); recargarAsis(); }));
}

// ---------- Días festivos ----------
async function aFestivos() {
  const L = await api('/api/festivos?anio=' + ASIS.anio);
  $('#asisc').innerHTML = `<div class="panel"><div class="fila" style="justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px"><div class="fila" style="gap:6px;align-items:center"><button class="btn chico" id="aAnt">‹</button><b style="font-size:18px">${ASIS.anio}</b><button class="btn chico" id="aSig">›</button></div>
    <div class="fila" style="gap:8px"><button class="btn" id="fLey">Agregar los de ley (LFT)</button><button class="btn primario" id="fNuevo">+ Agregar día festivo</button></div></div>
    <table><tr><th>Fecha</th><th>Día</th><th>Festivo</th><th>Descansan</th><th></th></tr>
    ${L.map((f) => `<tr><td>${fecha(f.fecha)}</td><td>${DIAS_SEMANA[new Date(f.fecha + 'T12:00:00').getDay()]}</td><td>${esc(f.nombre || '')}</td><td>${f.descansa ? 'Sí' : 'No (día normal)'}</td><td><button class="btn chico" data-fq="${f.id}">✕</button></td></tr>`).join('') || '<tr><td colspan="5" class="vacio">Sin días festivos. Use "Agregar los de ley".</td></tr>'}</table>
    <p class="muted" style="margin:8px 0 0">El que trabaja en día festivo recibe el pago extra que ponga en Reglas (la ley marca salario doble adicional). El que no trabaja no tiene falta.</p></div>`;
  $('#aAnt').onclick = () => { ASIS.anio--; aFestivos(); }; $('#aSig').onclick = () => { ASIS.anio++; aFestivos(); };
  $('#fLey').onclick = (e) => intentar(async () => { await api('/api/festivos/ley', { anio: ASIS.anio }); toast('Días de ley agregados', 'ok'); aFestivos(); }, e.currentTarget);
  $$('[data-fq]').forEach((b) => b.onclick = () => intentar(async () => { await api('/api/festivos/' + b.dataset.fq, {}, 'DELETE'); aFestivos(); }));
  $('#fNuevo').onclick = () => {
    const m = modal(`<h2>Agregar día festivo</h2><form class="form" id="f"><label>Fecha<input type="date" name="fecha" value="${ASIS.anio}-12-12" required></label><label>Nombre<input name="nombre" placeholder="Ej. Día de la Virgen"></label>
      <label class="em-chk todo"><input type="checkbox" name="descansa" checked> Es día de descanso</label><div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`);
    $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => { await api('/api/festivos', { ...valores(e.target), descansa: e.target.descansa.checked }); m.cerrar(); aFestivos(); }); };
  };
}

// ---------- Vacaciones, permisos e incapacidades (son los mismos "días" de Empleados) ----------
async function aIncid() {
  const L = await api(`/api/asistencia/incidencias?desde=${ASIS.anio}-01-01&hasta=${ASIS.anio}-12-31`);
  $('#asisc').innerHTML = `<div class="panel"><div class="fila" style="justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px"><div class="fila" style="gap:6px;align-items:center"><button class="btn chico" id="aAnt">‹</button><b style="font-size:18px">${ASIS.anio}</b><button class="btn chico" id="aSig">›</button></div><button class="btn primario" id="iNuevo">+ Agregar vacaciones o permiso</button></div>
    <table><tr><th>Empleado</th><th>Tipo</th><th>Del</th><th>Al</th><th class="num">Días</th><th>Nota</th><th></th></tr>
    ${L.map((i) => `<tr><td>${esc(i.nombre)}</td><td>${TIPO_INC[i.tipo] || i.tipo}${i.tipo === 'permiso' ? (i.goce ? ' con goce' : ' sin goce') : ''}</td><td>${fecha(i.desde)}</td><td>${fecha(i.hasta)}</td><td class="num">${i.dias}</td><td class="muted">${esc(i.notas || '')}</td><td><button class="btn chico" data-iq="${i.id}">✕</button></td></tr>`).join('') || '<tr><td colspan="7" class="vacio">Sin registros.</td></tr>'}</table>
    <p class="muted" style="margin:8px 0 0">Vacaciones, permisos con goce, incapacidades y descansos extra no se descuentan. El permiso sin goce y la falta sí descuentan el día.</p></div>`;
  $('#aAnt').onclick = () => { ASIS.anio--; aIncid(); }; $('#aSig').onclick = () => { ASIS.anio++; aIncid(); };
  $$('[data-iq]').forEach((b) => b.onclick = async () => { if (await confirmar('Se quitará este registro.', 'Sí, quitar')) intentar(async () => { await api('/api/asistencia/incidencias/' + b.dataset.iq, {}, 'DELETE'); aIncid(); }); });
  $('#iNuevo').onclick = () => {
    const m = modal(`<h2>Vacaciones, permiso o incapacidad</h2><form class="form" id="f"><label>Empleado${selEmpAsis('empleado_id', '')}</label><label>Tipo<select name="tipo">${Object.entries(TIPO_INC).map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select></label>
      <label>Del<input type="date" name="desde" value="${hoyStr()}" required></label><label>Al<input type="date" name="hasta" value="${hoyStr()}" required></label>
      <label class="em-chk todo"><input type="checkbox" name="goce" checked> Con goce de sueldo (si es permiso)</label><label class="todo">Nota<input name="notas" placeholder="Ej. vacaciones 2026, folio de incapacidad IMSS"></label>
      <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`);
    $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => { await api('/api/asistencia/incidencias', { ...valores(e.target), goce: e.target.goce.checked }); m.cerrar(); toast('Guardado', 'ok'); aIncid(); }); };
  };
}

// ---------- Reglas de retardos y descuentos ----------
function aReglas() {
  const C = estado.config;
  $('#asisc').innerHTML = `<div class="panel" style="max-width:780px"><h2>Cómo checan los empleados</h2>
    <div class="fila" style="gap:14px;flex-wrap:wrap">${[['ambos', 'Huella o NIP (las dos)'], ['huella', 'Solo huella'], ['nip', 'Solo número y NIP']].map(([k, n]) => `<label class="em-chk"><input type="radio" name="rgMet" value="${k}" ${(C.asis_metodo || 'ambos') === k ? 'checked' : ''}> ${n}</label>`).join('')}</div>
    <p class="muted">Con "Solo huella" no se puede checar con NIP (solo el administrador agrega registros manuales).</p>
    <label class="em-chk"><input type="checkbox" id="rgZk" ${C.reloj_estado === 'reloj' ? 'checked' : ''}> Reloj ZKTeco: usar la tecla que el empleado presiona en el reloj (entrada/salida). Si no, el sistema decide solo.</label></div>
    <div class="panel" style="max-width:780px;margin-top:14px"><h2>Retardos y descuentos</h2><div class="form">
      <label>Tolerancia (minutos)<input id="rgT" type="number" min="0" value="${esc(C.asis_tolerancia ?? '10')}"></label>
      <label>Descuento por retardo<select id="rgM"><option value="fijo">Monto fijo por retardo</option><option value="minutos">Proporcional a los minutos tarde</option><option value="ninguno">No descontar retardos</option></select></label>
      <label>Monto por retardo (si es fijo)<input id="rgA" type="number" min="0" step="0.01" value="${esc(C.asis_desc_monto ?? '50')}"></label>
      <label>Cada cuántos retardos = 1 falta (0 = no)<input id="rgN" type="number" min="0" value="${esc(C.asis_retardos_falta ?? '3')}"></label>
      <label>Trabajar en festivo: pago extra de<select id="rgF"><option value="0">Nada extra</option><option value="1">1 día extra (doble)</option><option value="2">2 días extra (triple, como marca la ley)</option></select></label></div>
    <label class="em-chk" style="margin-top:10px"><input type="checkbox" id="rgD" ${C.asis_desc_doble === '1' ? 'checked' : ''}> Descuento DOBLE por retardo (cada retardo se descuenta dos veces)</label>
    <label class="em-chk" style="margin-top:6px"><input type="checkbox" id="rgFa" ${C.asis_falta_desc !== '0' ? 'checked' : ''}> Descontar el día completo por cada falta</label>
    <p class="muted" style="margin-top:12px">Ejemplo: llega 20 minutos tarde con tolerancia de 10 → retardo. El sueldo diario se calcula con el sueldo y cada cuánto se le paga (semanal ÷ 7, quincenal ÷ 15, mensual ÷ 30).</p>
    <button class="btn primario" id="rgOk">Guardar reglas</button></div>`;
  $('#rgM').value = C.asis_desc_modo || 'fijo'; $('#rgF').value = C.asis_festivo_pago || '2';
  $('#rgOk').onclick = (e) => intentar(async () => {
    const b = { asis_metodo: document.querySelector('input[name=rgMet]:checked')?.value || 'ambos', asis_tolerancia: String(Number($('#rgT').value) || 0), asis_desc_modo: $('#rgM').value, asis_desc_monto: String(Number($('#rgA').value) || 0),
      asis_retardos_falta: String(Number($('#rgN').value) || 0), asis_festivo_pago: $('#rgF').value, asis_desc_doble: $('#rgD').checked ? '1' : '0', asis_falta_desc: $('#rgFa').checked ? '1' : '0', reloj_estado: $('#rgZk').checked ? 'reloj' : 'auto' };
    await api('/api/asistencia/reglas', b, 'PUT'); Object.assign(estado.config, b); toast('Reglas guardadas', 'ok');
  }, e.currentTarget);
}

// ---------- Pagar sueldo: trae los descuentos por retardos/faltas y el extra de festivos del checador ----------
async function asistenciaParaPago(e, m) {
  if (!puede('asistencia') && !(modOn('asistencia') && puede('empleados'))) return;
  if (!modOn('asistencia')) return;
  const dias = { semanal: 7, quincenal: 15, mensual: 30 }[e.periodo] || 15;
  const hasta = hoyStr(), d0 = new Date(); d0.setDate(d0.getDate() - dias + 1);
  const desde = `${d0.getFullYear()}-${String(d0.getMonth() + 1).padStart(2, '0')}-${String(d0.getDate()).padStart(2, '0')}`;
  const caja = document.createElement('div'); caja.className = 'todo panel asis-pago';
  $('#f', m).insertBefore(caja, $('#f', m).querySelector('.modal-pie'));
  const calc = async () => {
    try {
      const r = await api(`/api/asistencia/nomina/${e.id}?desde=${$('#apD', m).value}&hasta=${$('#apH', m).value}`), x = r.resumen, fal = x.faltas + x.faltas_retardos;
      caja.querySelector('#apRes').innerHTML = !r.con_horario ? 'Este empleado no tiene horario en Asistencia: no hay descuentos.' : `${x.retardos} retardo(s) ${dinero(x.desc_retardos)} · ${fal} falta(s) ${dinero(x.desc_faltas)} · festivos trabajados +${dinero(x.pago_festivos)}`;
      caja.dataset.desc = x.total_descuento; caja.dataset.extra = x.pago_festivos;
      caja.querySelector('#apApl').disabled = !(x.total_descuento || x.pago_festivos);
    } catch (er) { caja.querySelector('#apRes').textContent = er.message; }
  };
  caja.innerHTML = `<b>🕒 Asistencia del periodo</b><div class="fila" style="gap:8px;align-items:flex-end;flex-wrap:wrap;margin-top:6px"><label>Del<input type="date" id="apD" value="${desde}"></label><label>al<input type="date" id="apH" value="${hasta}"></label>
    <button type="button" class="btn chico" id="apApl" disabled>Aplicar al monto</button></div><div id="apRes" class="muted" style="margin-top:6px">Calculando…</div>`;
  $('#apD', m).onchange = calc; $('#apH', m).onchange = calc;
  $('#apApl', m).onclick = () => {
    const inp = $('[name=monto]', m), base = Number(e.sueldo) || Number(inp.value) || 0, nuevo = Math.max(0, base - Number(caja.dataset.desc || 0) + Number(caja.dataset.extra || 0));
    inp.value = nuevo.toFixed(2);
    const n = $('[name=notas]', m); n.value = [n.value, `Asistencia ${$('#apD', m).value} al ${$('#apH', m).value}: -${dinero(caja.dataset.desc || 0)} descuentos, +${dinero(caja.dataset.extra || 0)} festivos`].filter(Boolean).join(' · ');
    toast('Descuentos aplicados al monto', 'ok');
  };
  calc();
}
