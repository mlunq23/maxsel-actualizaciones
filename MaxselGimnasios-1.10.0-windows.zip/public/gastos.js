// Maxsel Gimnasios 1.9 — Gastos como en Maxsel Hotel:
//   gastos fijos con compañía, contrato, referencia, cada cuánto se pagan y vencimiento (verde / naranja / rojo),
//   aviso en el menú, historial con promedio y alerta si el recibo viene alto,
//   recibo de gasto con folio y firmas de quien entrega y quien recibe (ticket 80 mm u hoja carta con copia).
'use strict';
const EST_FIJO = { vencido: 'Vencido', por_vencer: 'Por vencer', al_corriente: 'Al corriente', sin_fecha: 'Sin fecha' };
const METODOS_G = { efectivo: '💵 Efectivo', transferencia: '🏦 Transferencia', tarjeta: '💳 Tarjeta', cheque: '🧾 Cheque' };
const SUGERIDOS_FIJO = ['Luz (CFE)', 'Agua', 'Gas', 'Internet', 'Cable / TV', 'Teléfono', 'Renta del local', 'Publicidad (marketing)', 'Redes sociales / anuncios', 'Música / licencias', 'Recolección de basura', 'Predial', 'Seguro', 'Licencia de funcionamiento', 'Mantenimiento de aparatos'];
const diasTxtFijo = (g) => (g.dias === null || g.dias === undefined ? '' : g.dias < 0 ? `venció hace ${-g.dias} día${g.dias === -1 ? '' : 's'}` : g.dias === 0 ? 'vence HOY' : g.dias === 1 ? 'vence mañana' : `vence en ${g.dias} días`);

function numeroALetras(n) {
  const U = ['', 'UN', 'DOS', 'TRES', 'CUATRO', 'CINCO', 'SEIS', 'SIETE', 'OCHO', 'NUEVE', 'DIEZ', 'ONCE', 'DOCE', 'TRECE', 'CATORCE', 'QUINCE', 'DIECISÉIS', 'DIECISIETE', 'DIECIOCHO', 'DIECINUEVE', 'VEINTE', 'VEINTIÚN', 'VEINTIDÓS', 'VEINTITRÉS', 'VEINTICUATRO', 'VEINTICINCO', 'VEINTISÉIS', 'VEINTISIETE', 'VEINTIOCHO', 'VEINTINUEVE'];
  const D = ['', '', '', 'TREINTA', 'CUARENTA', 'CINCUENTA', 'SESENTA', 'SETENTA', 'OCHENTA', 'NOVENTA'];
  const C = ['', 'CIENTO', 'DOSCIENTOS', 'TRESCIENTOS', 'CUATROCIENTOS', 'QUINIENTOS', 'SEISCIENTOS', 'SETECIENTOS', 'OCHOCIENTOS', 'NOVECIENTOS'];
  const cien = (x) => { if (x === 100) return 'CIEN'; const c = Math.floor(x / 100), r = x % 100; let t = C[c]; if (r) t += (t ? ' ' : '') + (r < 30 ? U[r] : D[Math.floor(r / 10)] + (r % 10 ? ' Y ' + U[r % 10] : '')); return t; };
  const mil = (x) => { const m = Math.floor(x / 1000), r = x % 1000; return (m ? (m === 1 ? 'MIL' : cien(m) + ' MIL') : '') + (r ? (m ? ' ' : '') + cien(r) : ''); };
  n = Math.round((Number(n) || 0) * 100) / 100; const ent = Math.floor(n), cts = Math.round((n - ent) * 100);
  const mill = Math.floor(ent / 1e6), rest = ent % 1e6;
  let t = (mill ? (mill === 1 ? 'UN MILLÓN' : mil(mill) + ' MILLONES') + (rest ? ' ' : ' DE') : '') + (rest ? mil(rest) : '');
  if (!ent) t = 'CERO';
  return `${t} ${ent === 1 ? 'PESO' : 'PESOS'} ${String(cts).padStart(2, '0')}/100 M.N.`;
}

// ---------- Firma en pantalla (con el dedo o el mouse) ----------
const padHTML = (id, etiqueta) => `<div class="padf"><div class="fila" style="justify-content:space-between;align-items:center"><b style="font-size:13px">${etiqueta}</b><button type="button" class="btn chico" data-padborrar="${id}">Borrar</button></div><canvas id="${id}" width="600" height="190"></canvas><small class="muted">Firme con el dedo o el mouse</small></div>`;
function padIniciar(raiz) {
  $$('canvas', raiz).forEach((c) => {
    const x = c.getContext('2d'); x.lineWidth = 2.6; x.lineCap = 'round'; x.lineJoin = 'round'; x.strokeStyle = '#111';
    let dib = false; const pos = (e) => { const r = c.getBoundingClientRect(); return [(e.clientX - r.left) * c.width / r.width, (e.clientY - r.top) * c.height / r.height]; };
    c.onpointerdown = (e) => { dib = true; c.setPointerCapture(e.pointerId); x.beginPath(); x.moveTo(...pos(e)); };
    c.onpointermove = (e) => { if (!dib) return; x.lineTo(...pos(e)); x.stroke(); c.dataset.firmado = '1'; };
    c.onpointerup = c.onpointercancel = () => { dib = false; };
  });
  $$('[data-padborrar]', raiz).forEach((b) => b.onclick = () => { const c = document.getElementById(b.dataset.padborrar); c.getContext('2d').clearRect(0, 0, c.width, c.height); delete c.dataset.firmado; });
}
const padValor = (id) => { const c = document.getElementById(id); return c && c.dataset.firmado ? c.toDataURL('image/png') : null; };

// ---------- Aviso en el menú: gastos fijos vencidos o por vencer ----------
async function avisosGastosFijos() {
  if (!puede('gastos')) return [];
  try {
    const l = await api('/api/gastos/fijos/avisos'), a = $('#nav [data-r="gastos"]'); if (!a) return l;
    a.querySelector('.badge')?.remove();
    if (l.length) a.insertAdjacentHTML('beforeend', `<b class="badge" title="Gastos fijos vencidos o por vencer">${l.length}</b>`);
    return l;
  } catch { return []; }
}
setTimeout(() => { if (estado.yo) avisosGastosFijos(); }, 2500);
setInterval(() => { if (estado.yo) avisosGastosFijos(); }, 30 * 60 * 1000);

// ---------- Pantalla de Gastos ----------
VISTAS.gastos = async (v) => {
  let mes = estado.mesGastos || hoyStr().slice(0, 7);
  v.innerHTML = `<div class="encabezado"><h1>Gastos</h1>
      <div class="fila"><button class="btn" id="mAnt">‹</button><input type="month" id="mes" value="${mes}" max="${hoyStr().slice(0, 7)}" style="width:auto"><button class="btn" id="mSig">›</button></div>
      <button class="btn" id="bExcelG">⬇ Excel del mes</button><button class="btn primario" id="bNuevoG">+ Registrar gasto</button></div>
    <div id="cont"><p class="muted">Cargando…</p></div>`;
  const cargar = async () => {
    mes = $('#mes').value || mes; estado.mesGastos = mes;
    const d = await api('/api/gastos?mes=' + mes);
    VISTAS.gastos.d = d;
    $('#cont').innerHTML = `<div class="rejilla cols-4">
        <div class="kpi"><small>Gastos de ${mesLargo(mes)}</small><b>${dinero(d.total)}</b></div>
        <div class="kpi"><small>Gastos fijos pagados</small><b>${dinero(d.total_fijos)}</b><small>de ${dinero(d.esperado_fijos)} esperados</small></div>
        <div class="kpi"><small>Fijos vencidos · por vencer</small><b><span class="${d.vencidos ? 'rojo' : ''}">${d.vencidos}</span> · <span class="${d.por_vencer ? 'ambar' : ''}">${d.por_vencer}</span></b></div>
        <div class="kpi"><small>Pagado con dinero de la caja</small><b>${dinero(d.de_caja)}</b></div></div>
      <div class="panel" style="margin-top:16px"><div class="fila" style="justify-content:space-between;align-items:center;margin-bottom:10px"><h2 style="margin:0">📌 Gastos fijos · luz, agua, internet, renta…</h2><button class="btn chico primario" id="bNuevoFijo">+ Agregar gasto fijo</button></div>
        ${d.fijos.length ? `<div class="fijos">${d.fijos.map((g) => `<div class="fijo f-${g.estado}"><div class="fila" style="justify-content:space-between;align-items:flex-start"><div><b>${ICONO_CAT[g.categoria] || ''} ${esc(g.nombre)}</b>${g.proveedor ? `<br><small class="muted">${esc(g.proveedor)}</small>` : ''}</div><span class="etq fv-${g.estado}">${EST_FIJO[g.estado]}</span></div>
          <div class="grande">${g.monto ? dinero(g.monto) : '—'}</div><div class="${g.estado === 'vencido' ? 'malo' : g.estado === 'por_vencer' ? 'pronto' : 'muted'}">${g.vence ? fecha(g.vence) + ' · ' + diasTxtFijo(g) : 'Sin fecha de vencimiento'}</div>
          <small class="muted">${esc(d.periodos[g.periodo_pago] || '')}${g.contrato ? ' · Contrato ' + esc(g.contrato) : ''}${g.domiciliado ? ' · Domiciliado' : ''}${g.pagado ? ` · Pagado en ${mesLargo(mes)}: ${dinero(g.pagado)}` : ''}</small>
          <div class="fila" style="margin-top:8px;gap:6px;flex-wrap:wrap"><button class="btn chico primario" data-pagar="${g.id}">💵 Pagar</button><button class="btn chico" data-hist="${g.id}">Historial</button><button class="btn chico" data-ef="${g.id}">✏️ Editar</button></div></div>`).join('')}</div>`
          : '<p class="vacio">Agregue la luz, el agua, internet, la renta… El sistema le avisa con color cuando estén por vencer o vencidos.</p>'}</div>
      <div class="rejilla cols-2" style="margin-top:16px">
        <div class="panel"><h2>🧾 Todos los gastos de ${mesLargo(mes)}</h2>
          <div class="tabla-scroll"><table><tr><th>Fecha</th><th>Folio</th><th>Gasto</th><th>Pago</th><th class="num">Monto</th><th></th></tr>
          ${d.pagos.map((x) => `<tr class="click" data-ver="${x.id}"><td>${fecha(x.fecha)}</td><td><small style="white-space:nowrap">${esc(x.folio || '')}</small></td><td>${esc(x.nombre)}${x.gasto_fijo_id ? ' <span class="etq azul">fijo</span>' : ''}<br><small class="muted">${esc(x.categoria || '')}${x.recibe ? ' · recibió ' + esc(x.recibe) : ''}</small>${x.firmado ? '' : ' <span class="etq sin">sin firmas</span>'}</td>
            <td>${METODOS_G[x.metodo] || '💵 Efectivo'}<br><small class="muted">${x.pagado_con === 'caja' ? 'De la caja' : 'Fuera de caja'} · ${esc(x.usuario || '')}</small></td><td class="num"><b>${dinero(x.monto)}</b></td><td><button class="btn chico" data-borrar="${x.id}" title="Borrar">🗑️</button></td></tr>`).join('') || '<tr><td colspan="6" class="vacio">Sin gastos registrados este mes</td></tr>'}
          ${d.pagos.length ? `<tr><th colspan="4">TOTAL</th><th class="num">${dinero(d.total)}</th><th></th></tr>` : ''}</table></div></div>
        <div>
          <div class="panel"><h2>Por categoría</h2><table>${d.por_categoria.map((c) => `<tr><td>${ICONO_CAT[c.categoria] || ''} ${esc(c.categoria)}</td><td class="num">${dinero(c.total)}</td></tr>`).join('') || '<tr><td class="vacio">—</td></tr>'}</table></div>
          <div class="panel" style="margin-top:16px"><h2>Meses anteriores</h2><table>${d.meses.map((m) => `<tr class="click" data-mes="${m.periodo}"><td>${mesLargo(m.periodo)}</td><td class="num">${dinero(m.total)}</td></tr>`).join('') || '<tr><td class="vacio">—</td></tr>'}</table></div>
        </div></div>`;
    const fijo = (id) => d.fijos.find((f) => f.id == id);
    $$('[data-mes]', v).forEach((tr) => tr.onclick = () => { $('#mes').value = tr.dataset.mes; cargar(); });
    $$('[data-pagar]', v).forEach((b) => b.onclick = () => modalPagarFijo(fijo(b.dataset.pagar), cargar));
    $$('[data-hist]', v).forEach((b) => b.onclick = () => modalHistorialFijo(fijo(b.dataset.hist), cargar));
    $$('[data-ef]', v).forEach((b) => b.onclick = () => modalGastoFijo(d, fijo(b.dataset.ef), cargar));
    $$('tr[data-ver]', v).forEach((tr) => tr.onclick = (e) => { if (!e.target.closest('[data-borrar]')) verGasto(tr.dataset.ver, cargar); });
    $$('[data-borrar]', v).forEach((b) => b.onclick = async () => { if (await confirmar('Se borrará este gasto. Si salió de la caja, también se quita el movimiento de la caja.', 'Sí, borrar')) intentar(async () => { await api('/api/gastos/' + b.dataset.borrar, {}, 'DELETE'); toast('Gasto borrado', 'ok'); cargar(); }); });
    $('#bNuevoFijo').onclick = () => modalGastoFijo(d, null, cargar);
    $('#bNuevoG').onclick = () => modalGasto(d, null, cargar);
    $('#bExcelG').onclick = (e) => intentar(() => {
      if (!d.pagos.length) throw new Error('No hay gastos en ese mes');
      const fx2 = (s2) => (s2 ? s2.slice(0, 10).split('-').reverse().join('/') : '');
      descargarExcel(`Gastos ${mes}`, [
        { nombre: 'Gastos', titulo: `Gastos de ${mesLargo(mes)} · ${estado.config.gym_nombre}`, subtitulo: `Total: ${dinero(d.total)} · Fijos: ${dinero(d.total_fijos)} · Pagado de la caja: ${dinero(d.de_caja)}`,
          columnas: [{ t: 'Fecha', ancho: 11 }, { t: 'Folio', ancho: 11 }, { t: 'Gasto', ancho: 30 }, { t: 'Categoría', ancho: 20 }, { t: 'Tipo', ancho: 8 }, { t: 'Método', ancho: 13 }, { t: 'Pagado con', ancho: 14 }, { t: 'Recibió', ancho: 18 }, { t: 'Monto', ancho: 13, tipo: 'dinero' }, { t: 'Registró', ancho: 16 }, { t: 'Notas', ancho: 30 }],
          filas: d.pagos.map((x) => [fx2(x.fecha), x.folio || '', x.nombre, x.categoria || '', x.gasto_fijo_id ? 'Fijo' : 'Vario', (METODOS_G[x.metodo] || 'Efectivo').replace(/^\S+ /, ''), x.pagado_con === 'caja' ? 'Caja' : 'Fuera de caja', x.recibe || '', x.monto, x.usuario || '', x.notas || '']), totales: ['', '', 'TOTAL', '', '', '', '', '', d.total, '', ''] },
        { nombre: 'Gastos fijos', titulo: `Gastos fijos · ${mesLargo(mes)}`, columnas: [{ t: 'Gasto', ancho: 26 }, { t: 'Compañía', ancho: 18 }, { t: 'Contrato', ancho: 14 }, { t: 'Referencia', ancho: 14 }, { t: 'Categoría', ancho: 18 }, { t: 'Se paga', ancho: 14 }, { t: 'Monto aprox.', ancho: 13, tipo: 'dinero' }, { t: 'Próximo vencimiento', ancho: 13 }, { t: 'Estado', ancho: 12 }, { t: 'Pagado en el mes', ancho: 13, tipo: 'dinero' }, { t: 'Promedio', ancho: 12, tipo: 'dinero' }],
          filas: d.fijos.map((f) => [f.nombre, f.proveedor || '', f.contrato || '', f.referencia || '', f.categoria, d.periodos[f.periodo_pago] || '', f.monto, fx2(f.vence), EST_FIJO[f.estado], f.pagado || '', f.promedio || '']), totales: ['TOTAL', '', '', '', '', '', d.esperado_fijos, '', '', d.total_fijos, ''] },
        { nombre: 'Por categoría', titulo: `Gastos por categoría · ${mesLargo(mes)}`, columnas: [{ t: 'Categoría', ancho: 30 }, { t: 'Total', ancho: 14, tipo: 'dinero' }], filas: d.por_categoria.map((c) => [c.categoria, c.total]) },
      ]);
      toast('Excel descargado', 'ok');
    }, e.currentTarget);
    avisosGastosFijos();
  };
  const moverMes = (n) => { const [y, m] = $('#mes').value.split('-').map(Number); const d2 = new Date(y, m - 1 + n, 1); const val = `${d2.getFullYear()}-${String(d2.getMonth() + 1).padStart(2, '0')}`; if (val > hoyStr().slice(0, 7)) return; $('#mes').value = val; cargar(); };
  $('#mAnt').onclick = () => moverMes(-1); $('#mSig').onclick = () => moverMes(1);
  $('#mes').onchange = cargar; cargar();
};

// ---------- Alta / edición de gasto fijo ----------
modalGastoFijo = function (d, f, alGuardar) {
  const g = f || { periodo_pago: 'mensual', vence: hoyStr(), dias_aviso: 5, categoria: 'Luz' };
  const P = d.periodos || {};
  const m = modal(`<h2>${f ? 'Editar gasto fijo' : 'Nuevo gasto fijo'}</h2><p class="muted" style="margin-top:-6px">Luz, agua, internet, renta… El sistema le avisa con color cuando esté por vencer o vencido.</p>
    <form class="form" id="f">
      <label class="todo">¿Qué es?<input name="nombre" list="fSug" value="${esc(g.nombre || '')}" placeholder="Luz, Agua, Internet, Renta del local…" required autofocus maxlength="80"><datalist id="fSug">${SUGERIDOS_FIJO.map((x) => `<option value="${esc(x)}">`).join('')}</datalist></label>
      <label>Compañía / a quién se paga<input name="proveedor" value="${esc(g.proveedor || '')}" placeholder="CFE, CESPT, Telmex, el dueño del local…"></label>
      <label>Número de contrato / servicio<input name="contrato" value="${esc(g.contrato || '')}" placeholder="Viene en el recibo"></label>
      <label>Referencia de pago (opcional)<input name="referencia" value="${esc(g.referencia || '')}" placeholder="Para pagar en banco o tienda"></label>
      <label>Monto aproximado<input name="monto" type="number" step="0.01" min="0" value="${g.monto || ''}" placeholder="0.00"></label>
      <label>Categoría<select name="categoria">${opcionesCat(d.categorias, g.categoria)}</select></label>
      <label>Se paga<select name="periodo_pago">${Object.entries(P).map(([k, n]) => `<option value="${k}" ${k === g.periodo_pago ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <label>Próximo vencimiento<input name="vence" type="date" value="${esc(g.vence || hoyStr())}" required></label>
      <label>Avisar días antes<input name="dias_aviso" type="number" min="0" max="60" value="${g.dias_aviso ?? 5}"></label>
      <label class="em-chk todo"><input type="checkbox" name="domiciliado" ${g.domiciliado ? 'checked' : ''}> Está domiciliado (se cobra solo a la tarjeta o cuenta)</label>
      <label class="todo">Notas<input name="notas" value="${esc(g.notas || '')}" placeholder="Ej. se paga en OXXO, a nombre de…"></label>
      <div class="modal-pie todo">${f ? '<button type="button" class="btn peligro" id="bBorrarFijo">Quitar</button>' : ''}<button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar</button></div></form>`);
  $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(async () => { await api('/api/gastos/fijos' + (f ? '/' + f.id : ''), { ...valores(e.target), domiciliado: e.target.domiciliado.checked }, f ? 'PUT' : 'POST'); m.cerrar(); toast('Gasto fijo guardado', 'ok'); alGuardar(); }); };
  $('#bBorrarFijo', m) && ($('#bBorrarFijo', m).onclick = async () => { if (await confirmar(`Se quitará "${esc(f.nombre)}" de los gastos fijos (los pagos ya registrados se conservan).`, 'Sí, quitar')) intentar(async () => { await api('/api/gastos/fijos/' + f.id, {}, 'DELETE'); m.cerrar(); toast('Gasto fijo quitado', 'ok'); alGuardar(); }); });
};

// Campos comunes de un pago: método, de dónde salió el dinero, quién recibe y firmas
const camposPago = (recibe = '', metodo = 'efectivo', domiciliado = false) => `
  <label>Método de pago<select name="metodo">${Object.entries(METODOS_G).map(([k, n]) => `<option value="${k}" ${k === metodo ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
  <label>¿De dónde salió el dinero?<select name="pagado_con"><option value="fuera">🏦 Fuera de la caja (banco, dueño)</option><option value="caja" ${puede('movimientos') && !domiciliado ? '' : 'disabled'}>💵 De la caja del turno (se descuenta del corte)</option></select></label>
  <label>Entrega el dinero<input name="entrega" value="${esc(estado.yo.nombre)}"></label>
  <label>Recibe el dinero<input name="recibe" value="${esc(recibe)}" placeholder="Proveedor, empleado, técnico…"></label>
  <div class="todo rejilla cols-2" style="gap:12px">${padHTML('fEnt', 'Firma de quien entrega')}${padHTML('fRec', 'Firma de quien recibe')}</div>`;
function enlazarPago(m) {
  padIniciar(m);
  const met = $('[name=metodo]', m), pc = $('[name=pagado_con]', m);
  const sync = () => { const caja = pc.querySelector('[value=caja]'); if (met.value !== 'efectivo') { pc.value = 'fuera'; caja.disabled = true; } else caja.disabled = !puede('movimientos'); };
  met.onchange = sync; sync();
}
async function guardarEImprimir(url, datos, m, alGuardar, texto) {
  const g = await api(url, { ...datos, firma_entrega: padValor('fEnt'), firma_recibe: padValor('fRec') });
  m.cerrar(); toast(texto(g), 'ok'); alGuardar?.(); avisosGastosFijos();
  if (g.id) imprimirGasto(g.id);
  return g;
}

// ---------- Registrar gasto ----------
modalGasto = function (d, fijo, alGuardar) {
  if (fijo) return modalPagarFijo(fijo, alGuardar);
  const m = modal(`<h2>Registrar gasto</h2>
    <form class="form" id="f">
      <label class="todo">¿Qué gasto es?<input name="nombre" list="gastosLista" placeholder="Ej. Garrafones de agua, reparación de caminadora" required autofocus maxlength="80"><datalist id="gastosLista">${d.fijos.map((f) => `<option value="${esc(f.nombre)}">`).join('')}</datalist></label>
      <label>Monto pagado<input name="monto" type="number" step="0.01" min="0.01" required></label>
      <label>Fecha de pago<input name="fecha" type="date" value="${hoyStr()}" max="${hoyStr()}"></label>
      <label>Categoría<select name="categoria">${opcionesCat(d.categorias, 'Gastos varios')}</select></label>
      <label>Corresponde al mes<input name="periodo" type="month" value="${d.mes}" max="${hoyStr().slice(0, 7)}"></label>
      ${camposPago()}
      <label class="todo">Notas<input name="notas" placeholder="Ej. folio de la nota, factura"></label>
      <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Guardar e imprimir recibo</button></div></form>`, { ancho: true });
  enlazarPago(m);
  $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(() => guardarEImprimir('/api/gastos', valores(e.target), m, alGuardar, (g) => `Gasto registrado: ${dinero(g.monto)}`), $('.primario', m)); };
};

// ---------- Pagar un gasto fijo ----------
function modalPagarFijo(g, alGuardar) {
  const mesTxt = g.vence ? new Date(g.vence + 'T12:00:00').toLocaleDateString('es-MX', { month: 'long', year: 'numeric' }) : '';
  const m = modal(`<h2>💵 Pagar · ${esc(g.nombre)}</h2>
    <table style="margin-bottom:10px">${g.vence ? `<tr><td>Vence</td><td><b>${fecha(g.vence)}</b> (${diasTxtFijo(g)})</td></tr>` : ''}${g.contrato ? `<tr><td>Contrato</td><td><b>${esc(g.contrato)}</b></td></tr>` : ''}${g.referencia ? `<tr><td>Referencia</td><td><b>${esc(g.referencia)}</b></td></tr>` : ''}${g.promedio ? `<tr><td>Promedio de los últimos pagos</td><td><b>${dinero(g.promedio)}</b></td></tr>` : ''}</table>
    <form class="form" id="f">
      <label>Monto pagado<input name="monto" type="number" step="0.01" min="0.01" value="${g.monto || ''}" required autofocus></label>
      <label>Periodo<input name="periodo_txt" value="${esc(mesTxt)}"></label>
      <div class="todo" id="pAl"></div>
      ${camposPago(g.proveedor || '', 'efectivo', !!g.domiciliado)}
      <label class="todo">Nota<input name="notas" placeholder="Folio del recibo, quién pagó…"></label>
      <p class="muted todo" style="margin:0">Al guardar se registra en Gastos y el vencimiento pasa al siguiente periodo${g.periodo_pago === 'unico' ? ' (es de una sola vez: se quita de la lista)' : ''}.</p>
      <div class="modal-pie todo"><button type="button" class="btn" data-cerrar>Cancelar</button><button class="btn primario">Registrar pago e imprimir</button></div></form>`, { ancho: true });
  enlazarPago(m);
  const alto = () => { const v = Number($('[name=monto]', m).value) || 0; $('#pAl', m).innerHTML = g.promedio && v > g.promedio * 1.2 ? `<div class="aviso" style="margin:0">Ojo: este pago es ${Math.round((v / g.promedio - 1) * 100)}% más alto que el promedio (${dinero(g.promedio)}). Revise si hay alguna fuga o consumo raro.</div>` : ''; };
  $('[name=monto]', m).oninput = alto; alto();
  $('#f', m).onsubmit = (e) => { e.preventDefault(); intentar(() => guardarEImprimir(`/api/gastos/fijos/${g.id}/pagar`, valores(e.target), m, alGuardar, (r) => (r.siguiente ? `Pago registrado. Próximo vencimiento: ${fecha(r.siguiente)}` : 'Pago registrado')), $('.primario', m)); };
}
function modalHistorialFijo(g, alGuardar) {
  const h = g.historial || g.pagos || [];
  const m = modal(`<h2>Historial · ${esc(g.nombre)}</h2>${g.promedio ? `<p>Promedio de los últimos pagos: <b>${dinero(g.promedio)}</b></p>` : ''}
    <div class="tabla-scroll" style="max-height:50vh"><table><tr><th>Fecha</th><th>Folio</th><th>Método</th><th>Nota</th><th class="num">Monto</th></tr>
    ${h.map((p) => `<tr class="click" data-ver="${p.id}"><td>${fechaHora(p.fecha)}</td><td><small>${esc(p.folio || '')}</small></td><td>${METODOS_G[p.metodo] || ''}</td><td class="muted">${esc(p.notas || '')}</td><td class="num">${dinero(p.monto)}</td></tr>`).join('') || '<tr><td colspan="5" class="vacio">Aún no hay pagos.</td></tr>'}</table></div>
    <div class="modal-pie"><button class="btn" data-cerrar>Cerrar</button><button class="btn primario" id="hPagar">💵 Pagar</button></div>`, { ancho: true });
  $$('[data-ver]', m).forEach((tr) => tr.onclick = () => verGasto(tr.dataset.ver));
  $('#hPagar', m).onclick = () => { m.cerrar(); modalPagarFijo(g, alGuardar); };
}

// ---------- Ver un gasto: firmas que faltan y volver a imprimir ----------
async function verGasto(id, alGuardar) {
  const g = await api('/api/gastos/' + id);
  const m = modal(`<h2>Recibo de gasto ${esc(g.folio || '#' + g.id)}</h2>
    <table><tr><td>Fecha</td><td><b>${fechaHora(g.fecha)}</b></td></tr><tr><td>Concepto</td><td><b>${esc(g.nombre)}</b></td></tr><tr><td>Categoría</td><td>${esc(g.categoria || '')}</td></tr>
      <tr><td>Monto</td><td><b>${dinero(g.monto)}</b><br><small class="muted">${numeroALetras(g.monto)}</small></td></tr><tr><td>Método</td><td>${METODOS_G[g.metodo] || ''} · ${g.pagado_con === 'caja' ? 'de la caja' : 'fuera de la caja'}</td></tr>
      <tr><td>Entregó</td><td>${esc(g.entrega || g.usuario || '')}</td></tr><tr><td>Recibió</td><td>${esc(g.recibe || '—')}</td></tr>${g.notas ? `<tr><td>Notas</td><td>${esc(g.notas)}</td></tr>` : ''}</table>
    <div class="rejilla cols-2" style="gap:12px;margin-top:12px">${g.firma_entrega ? `<div><b style="font-size:13px">Firma de quien entrega</b><img class="firma-img" src="${g.firma_entrega}" alt="firma"></div>` : padHTML('fEnt', 'Firma de quien entrega')}
      ${g.firma_recibe ? `<div><b style="font-size:13px">Firma de quien recibe</b><img class="firma-img" src="${g.firma_recibe}" alt="firma"></div>` : padHTML('fRec', 'Firma de quien recibe')}</div>
    <div class="modal-pie">${!g.firma_entrega || !g.firma_recibe ? '<button class="btn" id="vFir">✍️ Guardar firmas</button>' : ''}<button class="btn" id="vCarta">📄 Hoja carta (PDF)</button><button class="btn primario" id="vTicket">🖨️ Ticket 80 mm</button><button class="btn" data-cerrar>Cerrar</button></div>`, { ancho: true });
  padIniciar(m);
  $('#vFir', m) && ($('#vFir', m).onclick = (e) => intentar(async () => {
    if (!padValor('fEnt') && !padValor('fRec')) throw new Error('Primero firme en el recuadro');
    await api(`/api/gastos/${id}/firmas`, { firma_entrega: padValor('fEnt'), firma_recibe: padValor('fRec') }, 'PUT'); toast('Firmas guardadas', 'ok'); m.cerrar(); verGasto(id, alGuardar); alGuardar?.();
  }, e.currentTarget));
  $('#vCarta', m).onclick = () => imprimirGasto(id, 'carta');
  $('#vTicket', m).onclick = () => imprimirGasto(id);
}
// Recibo: ticket de 80 mm (original y copia) o media hoja carta con copia
async function imprimirGasto(id, formato) {
  const g = await api('/api/gastos/' + id), c = estado.config;
  const firma = (img, rol, quien) => `<div class="fr">${img ? `<img src="${img}" alt="">` : '<div class="lin"></div>'}<div>${rol}: ${esc(quien || '')}</div></div>`;
  if (formato === 'carta') {
    const cuerpo = (copia) => `<div class="doc"><div class="enc"><div><h1>${esc(c.gym_nombre)}</h1><div class="sub">${esc(c.gym_direccion || '')} ${esc(c.gym_telefono || '')}</div></div><div style="text-align:right"><b>RECIBO DE GASTO</b><br>${esc(g.folio || '')}<br><small>${copia}</small></div></div>
      <table><tr><th>Fecha</th><td>${fechaHora(g.fecha)}</td><th>Método</th><td>${(METODOS_G[g.metodo] || '').replace(/^\S+ /, '')} · ${g.pagado_con === 'caja' ? 'de la caja' : 'fuera de la caja'}</td></tr>
      <tr><th>Concepto</th><td colspan="3">${esc(g.nombre)}</td></tr><tr><th>Categoría</th><td colspan="3">${esc(g.categoria || '')}</td></tr>${g.notas ? `<tr><th>Notas</th><td colspan="3">${esc(g.notas)}</td></tr>` : ''}</table>
      <div class="monto">${dinero(g.monto)}<small>${numeroALetras(g.monto)}</small></div>
      <div class="firmas">${firma(g.firma_entrega, 'Entrega', g.entrega || g.usuario)}${firma(g.firma_recibe, 'Recibe', g.recibe)}</div></div>`;
    imprimirCarta('Recibo de gasto ' + (g.folio || ''), `<style>.doc{height:125mm;box-sizing:border-box;padding:4mm 0;border-bottom:1px dashed #999;margin-bottom:6mm}.monto{font-size:26px;font-weight:700;margin:10px 0;text-align:center}.monto small{display:block;font-size:11px;font-weight:400}
      .firmas{display:flex;gap:30px;margin-top:10px}.fr{flex:1;text-align:center}.fr img{height:22mm;max-width:100%;object-fit:contain;display:block;margin:0 auto}.fr .lin{height:22mm;border-bottom:1px solid #111}th{width:18%}</style>${cuerpo('ORIGINAL')}${cuerpo('COPIA')}`);
    return;
  }
  const t = (copia) => `${cabeceraTicket()}<b>RECIBO DE GASTO</b> · ${copia}<br>Folio: ${esc(g.folio || '#' + g.id)}<br>${fechaHora(g.fecha)}<hr>
    <table><tr><td colspan="2">${esc(g.nombre)}</td></tr><tr><td>Categoría</td><td class="r">${esc(g.categoria || '')}</td></tr><tr><td>Método</td><td class="r">${(METODOS_G[g.metodo] || '').replace(/^\S+ /, '')}</td></tr>
    <tr><td>Pagado</td><td class="r">${g.pagado_con === 'caja' ? 'De la caja' : 'Fuera de caja'}</td></tr><tr><td><b>MONTO</b></td><td class="r"><b>${dinero(g.monto)}</b></td></tr></table><div class="c" style="font-size:10px">${numeroALetras(g.monto)}</div>
    ${g.notas ? `<div>Nota: ${esc(g.notas)}</div>` : ''}<br>
    <div class="c">${g.firma_entrega ? `<img src="${g.firma_entrega}" style="height:45px;max-width:100%">` : '<br><br>'}<br>______________________________<br>Entrega: ${esc(g.entrega || g.usuario || '')}</div><br>
    <div class="c">${g.firma_recibe ? `<img src="${g.firma_recibe}" style="height:45px;max-width:100%">` : '<br><br>'}<br>______________________________<br>Recibe: ${esc(g.recibe || '')}</div>`;
  imprimir(`${t('ORIGINAL')}<div style="page-break-after:always"></div>${t('COPIA')}`);
}
