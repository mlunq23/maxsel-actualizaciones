// Crea archivos PDF sencillos (tamaño carta) sin internet ni librerías: títulos, cuadros de cifras y tablas.
// descargarPdf(nombreArchivo, { titulo, subtitulo, pie, secciones: [{ titulo, texto, kpis: [[etiqueta, valor]], tabla: { columnas: [{ t, ancho, tipo }], filas, totales } }] })
(function () {
  const ANCHO = 612, ALTO = 792, MX = 40, MY = 40;
  // Anchos de Helvetica (por 1000) para los caracteres ASCII 32..126
  const W = [278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584];
  const WB = [278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,333,333,584,584,584,611,975,722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,667,778,722,667,611,722,667,944,667,667,611,333,278,333,584,556,333,556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,611,611,389,556,333,611,556,778,556,556,500,389,280,389,584];
  const base = (ch) => { const n = ch.normalize('NFD').replace(/[̀-ͯ]/g, ''); return n.length === 1 ? n : 'o'; };
  function ancho(txt, tam, negrita) {
    const t = negrita ? WB : W; let s = 0;
    for (const ch of String(txt)) { let c = ch.charCodeAt(0); if (c < 32 || c > 126) c = base(ch).charCodeAt(0); s += (t[c - 32] || 556); }
    return (s * tam) / 1000;
  }
  // Texto a WinAnsi (acentos y ñ se conservan)
  const MAPA = { '€': 0x80, '…': 0x85, '–': 0x96, '—': 0x97, '‘': 0x91, '’': 0x92, '“': 0x93, '”': 0x94, '•': 0x95, '✔': 0x80 };
  function codificar(txt) {
    let out = '';
    for (const ch of String(txt ?? '')) {
      let c = ch.charCodeAt(0);
      if (MAPA[ch] !== undefined) c = MAPA[ch]; else if (c > 255) c = base(ch).charCodeAt(0);
      if (c === 40 || c === 41 || c === 92) out += '\\' + String.fromCharCode(c);
      else if (c < 32 || c > 126) out += '\\' + c.toString(8).padStart(3, '0');
      else out += String.fromCharCode(c);
    }
    return out;
  }
  function recortar(txt, maxAncho, tam, negrita) {
    txt = String(txt ?? '');
    if (ancho(txt, tam, negrita) <= maxAncho) return txt;
    while (txt.length && ancho(txt + '…', tam, negrita) > maxAncho) txt = txt.slice(0, -1);
    return txt + '…';
  }
  const COLORES = [[0.80, 0.40, 0.16], [0.15, 0.39, 0.92], [0.09, 0.64, 0.29], [0.85, 0.47, 0.02], [0.55, 0.36, 0.96], [0.86, 0.15, 0.15], [0.05, 0.58, 0.53], [0.93, 0.28, 0.60], [0.39, 0.45, 0.33], [0.40, 0.40, 0.40]];
  const dinero = (n) => (Number(n) < -0.004 ? '-$' : '$') + Math.abs(Number(n || 0)).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const fmt = (v, tipo) => {
    if (v === null || v === undefined || v === '') return '';
    if (tipo === 'dinero' && typeof v === 'number') return dinero(v);
    if (tipo === 'entero' && typeof v === 'number') return String(Math.round(v));
    if (tipo === 'decimal' && typeof v === 'number') return String(Math.round(v * 100) / 100);
    return String(v);
  };

  function crearPdf(doc) {
    const paginas = []; let ops = [], y = 0;
    const nueva = () => { ops = []; paginas.push(ops); y = ALTO - MY; };
    const txt = (x, yy, s, tam, negrita, color) => ops.push(`BT ${color || '0 g'} /F${negrita ? 2 : 1} ${tam} Tf ${x.toFixed(2)} ${yy.toFixed(2)} Td (${codificar(s)}) Tj ET`);
    const rect = (x, yy, w, h, gris) => ops.push(`${gris} g ${x.toFixed(2)} ${yy.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re f 0 g`);
    const linea = (x1, y1, x2, y2, gris = 0.75) => ops.push(`${gris} G 0.5 w ${x1.toFixed(2)} ${y1.toFixed(2)} m ${x2.toFixed(2)} ${y2.toFixed(2)} l S 0 G`);
    const espacio = (h) => { if (y - h < MY + 18) nueva(); };
    nueva();
    // Encabezado del documento
    rect(MX, y - 46, ANCHO - 2 * MX, 46, 0.93);
    txt(MX + 12, y - 20, doc.titulo || '', 17, true);
    if (doc.subtitulo) txt(MX + 12, y - 36, doc.subtitulo, 10, false, '0.3 g');
    y -= 58;
    for (const sec of doc.secciones || []) {
      if (sec.titulo) { espacio(40); y -= 10; txt(MX, y, sec.titulo, 12, true, '0.1 g'); y -= 6; linea(MX, y, ANCHO - MX, y, 0.6); y -= 14; }
      if (sec.texto) {
        // texto con salto de línea automático
        const lineas = []; let actual = '';
        for (const pal of String(sec.texto).split(' ')) { const prueba = actual ? actual + ' ' + pal : pal; if (ancho(prueba, 9.5) > ANCHO - 2 * MX) { lineas.push(actual); actual = pal; } else actual = prueba; }
        if (actual) lineas.push(actual);
        for (const l of lineas) { espacio(14); txt(MX, y, l, 9.5, false, '0.25 g'); y -= 14; }
        y -= 2;
      }
      if (sec.pastel) {
        // Gráfica de pastel con su leyenda (porcentaje y monto de cada parte)
        const datos = sec.pastel.filter((x) => Number(x[1]) > 0), tot = datos.reduce((a, x) => a + Number(x[1]), 0);
        if (!tot) { espacio(16); txt(MX, y, 'Sin datos en este periodo', 9.5, false, '0.4 g'); y -= 16; }
        else {
          const R = 72, alto = Math.max(2 * R + 16, datos.length * 17 + 12);
          espacio(alto);
          const cx = MX + R + 8, cy = y - R - 6;
          let ang = Math.PI / 2;
          datos.forEach(([et, v], i) => {
            const a = (Number(v) / tot) * 2 * Math.PI, [cr, cg, cb] = COLORES[i % COLORES.length];
            const pts = [`${cx.toFixed(2)} ${cy.toFixed(2)} m`], pasos = Math.max(2, Math.ceil(a / 0.06));
            for (let k = 0; k <= pasos; k++) { const t = ang - (a * k) / pasos; pts.push(`${(cx + R * Math.cos(t)).toFixed(2)} ${(cy + R * Math.sin(t)).toFixed(2)} l`); }
            ops.push(`${cr} ${cg} ${cb} rg ${pts.join(' ')} h f 1 1 1 RG 1 w ${pts.join(' ')} h S 0 g 0 G`);
            ang -= a;
            const ly = y - 14 - i * 17, lx = MX + 2 * R + 40;
            ops.push(`${cr} ${cg} ${cb} rg ${lx.toFixed(2)} ${(ly - 2).toFixed(2)} 10 10 re f 0 g`);
            const pc = `${(Math.round((Number(v) / tot) * 1000) / 10).toFixed(1)}%  ·  ${dinero(v)}`;
            txt(lx + 16, ly, recortar(et, ANCHO - MX - lx - 16 - ancho(pc, 9.5, true) - 12, 9.5), 9.5, false);
            txt(ANCHO - MX - ancho(pc, 9.5, true), ly, pc, 9.5, true);
          });
          y -= alto + 4;
        }
      }
      if (sec.kpis && sec.kpis.length) {
        const porFila = 4, w = (ANCHO - 2 * MX - (porFila - 1) * 8) / porFila, h = 40;
        for (let i = 0; i < sec.kpis.length; i += porFila) {
          espacio(h + 8);
          sec.kpis.slice(i, i + porFila).forEach(([et, val], j) => {
            const x = MX + j * (w + 8);
            rect(x, y - h, w, h, 0.96);
            txt(x + 8, y - 14, recortar(et, w - 16, 8), 8, false, '0.35 g');
            txt(x + 8, y - 31, recortar(val, w - 16, 13, true), 13, true);
          });
          y -= h + 8;
        }
      }
      if (sec.tabla) {
        const t = sec.tabla, cols = t.columnas, total = cols.reduce((a, c) => a + (c.ancho || 10), 0), util = ANCHO - 2 * MX;
        const anchos = cols.map((c) => ((c.ancho || 10) / total) * util), tam = cols.length > 9 ? 7.5 : 8.5, alto = cols.length > 9 ? 14 : 15;
        const fila = (vals, negrita, fondo) => {
          espacio(alto + 2);
          if (fondo !== undefined) rect(MX, y - alto + 3, util, alto, fondo);
          let x = MX;
          vals.forEach((v, i) => {
            const c = cols[i] || {}, s = fmt(v, c.tipo), num = ['dinero', 'entero', 'decimal'].includes(c.tipo);
            const r = recortar(s, anchos[i] - 6, tam, negrita);
            txt(num ? x + anchos[i] - 3 - ancho(r, tam, negrita) : x + 3, y - alto + 7, r, tam, negrita);
            x += anchos[i];
          });
          linea(MX, y - alto + 3, MX + util, y - alto + 3, 0.85);
          y -= alto;
        };
        const encabezado = () => fila(cols.map((c) => c.t), true, 0.88);
        encabezado();
        if (!t.filas.length) fila(['Sin datos'], false);
        for (const f of t.filas) { if (y - alto < MY + 18) { nueva(); encabezado(); } fila(f, false); }
        if (t.totales) fila(t.totales, true, 0.94);
        y -= 8;
      }
    }
    // Pie en cada página
    const n = paginas.length;
    paginas.forEach((p, i) => {
      const saved = ops; ops = p;
      linea(MX, MY - 6, ANCHO - MX, MY - 6, 0.8);
      txt(MX, MY - 18, doc.pie || 'Maxsel Punto de Venta para Gimnasios', 8, false, '0.45 g');
      const pg = `Página ${i + 1} de ${n}`; txt(ANCHO - MX - ancho(pg, 8), MY - 18, pg, 8, false, '0.45 g');
      ops = saved;
    });
    // Armar el archivo
    const objetos = [];
    const add = (s) => { objetos.push(s); return objetos.length; };
    const fuentes = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    const fuentesB = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    const padresIdx = objetos.length + 1; add('PENDIENTE');
    const ids = paginas.map((p) => {
      const cont = p.join('\n'), len = cont.length;
      const c = add(`<< /Length ${len} >>\nstream\n${cont}\nendstream`);
      return add(`<< /Type /Page /Parent ${padresIdx} 0 R /MediaBox [0 0 ${ANCHO} ${ALTO}] /Resources << /Font << /F1 ${fuentes} 0 R /F2 ${fuentesB} 0 R >> >> /Contents ${c} 0 R >>`);
    });
    objetos[padresIdx - 1] = `<< /Type /Pages /Kids [${ids.map((i) => i + ' 0 R').join(' ')}] /Count ${ids.length} >>`;
    const cat = add(`<< /Type /Catalog /Pages ${padresIdx} 0 R >>`);
    const info = add(`<< /Producer (Maxsel Punto de Venta) /Title (${codificar(doc.titulo || '')}) >>`);
    let out = '%PDF-1.4\n%\xe2\xe3\xcf\xd3\n'; const offs = [];
    const bytes = (s) => s.length; // todo el contenido es de un byte por carácter
    let pos = bytes(out);
    objetos.forEach((o, i) => { offs.push(pos); const s = `${i + 1} 0 obj\n${o}\nendobj\n`; out += s; pos += bytes(s); });
    const xref = pos;
    out += `xref\n0 ${objetos.length + 1}\n0000000000 65535 f \n` + offs.map((o) => String(o).padStart(10, '0') + ' 00000 n \n').join('');
    out += `trailer\n<< /Size ${objetos.length + 1} /Root ${cat} 0 R /Info ${info} 0 R >>\nstartxref\n${xref}\n%%EOF`;
    // Los caracteres > 127 van como un byte cada uno (latin1), no como UTF-8
    const bin = new Uint8Array(out.length);
    for (let i = 0; i < out.length; i++) bin[i] = out.charCodeAt(i) & 0xff;
    return new Blob([bin], { type: 'application/pdf' });
  }
  window.descargarPdf = function (nombreArchivo, doc) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(crearPdf(doc));
    a.download = nombreArchivo.endsWith('.pdf') ? nombreArchivo : nombreArchivo + '.pdf';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  };
})();
