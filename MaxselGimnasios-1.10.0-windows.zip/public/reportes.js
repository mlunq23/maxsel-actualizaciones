// Reportes en Excel de Maxsel Gimnasios. Lo usan la computadora (Reportes) y el panel del celular.
// Requiere xlsx-escribir.js (descargarExcel).
(function () {
  const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
  const dinero = (n) => (Number(n) < -0.004 ? '-$' : '$') + Math.abs(Number(n || 0)).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const usd = (n) => 'US$' + Number(n || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const fecha = (s) => { if (!s) return '—'; const [y, m, d] = s.slice(0, 10).split('-'); return `${Number(d)} ${MESES[m - 1]} ${y}`; };
  const hora = (s) => (s && s.length > 10 ? s.slice(11, 16) : '');
  const fx = (s) => (s ? s.slice(0, 10).split('-').reverse().join('/') : '');
  const sumar = (l, k) => r2(l.reduce((a, x) => a + (Number(typeof k === 'function' ? k(x) : x[k]) || 0), 0));
  const ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const hoyR = () => ymd(new Date());
  const sumarDiasR = (s, n) => { const d = new Date(s + 'T12:00:00'); d.setDate(d.getDate() + n); return ymd(d); };

  // Lista de reportes disponibles (para pintar los botones)
  window.REPORTES_EXCEL = [
    { tipo: 'cierre', icono: '📅', nombre: 'Cierre de mes', desc: 'Resumen completo del periodo: ventas, pagos, gastos, cortes y socios', pdf: true },
    { tipo: 'ventas', icono: '💰', nombre: 'Ventas totales', desc: 'Resumen por día, cada ticket, abonos y cortes' },
    { tipo: 'productos', icono: '🛒', nombre: 'Productos vendidos', desc: 'Cada venta y resumen por producto con ganancia' },
    { tipo: 'membresias', icono: '🏷️', nombre: 'Membresías vendidas', desc: 'Cada membresía y resumen por plan y promoción' },
    { tipo: 'gastos', icono: '💸', nombre: 'Retiros y gastos', desc: 'Dinero que salió de la caja y en qué se usó' },
    { tipo: 'cortes', icono: '🧾', nombre: 'Cortes de caja', desc: 'Cada turno: ventas, retiros y sobrante o faltante' },
    { tipo: 'asistencias', icono: '🚪', nombre: 'Asistencias', desc: 'Por día, por cliente, por hora y registro completo' },
    { tipo: 'socios', icono: '👥', nombre: 'Socios y vencimientos', desc: 'Activos, por vencer y vencidos para recuperar', sinFechas: true },
    { tipo: 'adeudos', icono: '📒', nombre: 'Cuentas por cobrar', desc: 'Quién debe, cuánto y desde cuándo', sinFechas: true },
    { tipo: 'inventario', icono: '📦', nombre: 'Inventario', desc: 'Existencias por departamento, agotados y valor de la mercancía', sinFechas: true, pdf: true },
    { tipo: 'unidades', icono: '🥧', nombre: 'Unidades de negocio', desc: 'Cuánto aporta cada unidad (membresías y cada departamento) y comparación con meses anteriores', pdf: true },
    { tipo: 'cuentas', icono: '📑', nombre: 'Cuentas por pagar', desc: 'Lo que se les debe a proveedores: a tiempo, vencido y pagos hechos', pdf: true, modulo: 'gastos' },
    { tipo: 'empleados', icono: '👷', nombre: 'Empleados y nómina', desc: 'Sueldos pagados, vacaciones, descansos, faltas y permisos', pdf: true, modulo: 'gastos' },
  ];
  const NOM_MES = (k) => { const [y, m] = k.split('-').map(Number); return `${MESES_L[m - 1].slice(0, 3)} ${y}`; };
  const TIPO_DIA = { vacaciones: 'Vacaciones', descanso: 'Descanso', falta: 'Falta', permiso: 'Permiso', incapacidad: 'Incapacidad' };
  const PER_PAGO = { semanal: 'Semanal', quincenal: 'Quincenal', mensual: 'Mensual' };
  // Tablas de unidades de negocio, comparación por mes, departamentos y nómina (las usan el cierre y los reportes sueltos)
  // Quita los meses del principio que no tienen ventas (gimnasio recién instalado)
  const recortarMeses = (um) => { if (!um || !um.meses) return um; const i = um.meses.findIndex((m) => m.total > 0); return { ...um, meses: i < 0 ? um.meses.slice(-1) : um.meses.slice(i) }; };
  window.recortarMeses = recortarMeses;
  function partesExtra(c) {
    const u = c.unidades || [], um = recortarMeses(c.unidades_meses || c.meses || { meses: [], unidades: [] }), dep = c.departamentos || [], nom = c.nomina || c;
    const uTot = sumar(u, 'total');
    const out = {
      pastel: u.map((x) => [x.unidad, x.total]),
      colsUni: [{ t: 'Unidad de negocio', ancho: 30 }, { t: 'Vendido', ancho: 14, tipo: 'dinero' }, { t: '% del total', ancho: 11, tipo: 'decimal' }, { t: 'Ganancia', ancho: 14, tipo: 'dinero' }],
      filasUni: u.map((x) => [x.unidad, x.total, x.pct, x.utilidad]), totUni: ['TOTAL', uTot, uTot ? 100 : 0, sumar(u, 'utilidad')],
      colsMes: [{ t: 'Mes', ancho: 10 }, { t: 'Total', ancho: 12, tipo: 'dinero' }, ...um.unidades.map((n) => ({ t: n, ancho: 12, tipo: 'dinero' }))],
      filasMes: um.meses.map((m) => [NOM_MES(m.mes), m.total, ...um.unidades.map((n) => m.unidades[n] || 0)]),
      colsMesPct: [{ t: 'Mes', ancho: 10 }, ...um.unidades.map((n) => ({ t: n + ' %', ancho: 12, tipo: 'decimal' }))],
      filasMesPct: um.meses.map((m) => [NOM_MES(m.mes), ...um.unidades.map((n) => (m.total ? Math.round(((m.unidades[n] || 0) / m.total) * 1000) / 10 : 0))]),
      colsDep: [{ t: 'Departamento', ancho: 26 }, { t: 'Productos', ancho: 10, tipo: 'entero' }, { t: 'Piezas', ancho: 9, tipo: 'decimal' }, { t: 'Vendido', ancho: 13, tipo: 'dinero' }, { t: 'Costo', ancho: 13, tipo: 'dinero' }, { t: 'Ganancia', ancho: 13, tipo: 'dinero' }],
      filasDep: dep.map((x) => [x.departamento, x.productos, x.cantidad, r2(x.importe), r2(x.costo), r2(x.utilidad)]),
      totDep: ['TOTAL', sumar(dep, 'productos'), sumar(dep, 'cantidad'), sumar(dep, 'importe'), sumar(dep, 'costo'), sumar(dep, 'utilidad')],
    };
    const emps = (nom.empleados || []).filter((e) => e.activo || e.pagado || e.vacaciones || e.faltas);
    out.nomKpis = [['Empleados activos', String(nom.activos || 0)], ['Nómina mensual estimada', dinero(nom.nomina_mensual || 0)], ['Sueldos pagados en el periodo', dinero(nom.total || 0)], ['Pagos de nómina', String((nom.pagos || []).length)]];
    out.colsEmp = [{ t: 'Empleado', ancho: 22 }, { t: 'Puesto', ancho: 14 }, { t: 'Sueldo', ancho: 11, tipo: 'dinero' }, { t: 'Pago', ancho: 10 }, { t: 'Descansa', ancho: 10 }, { t: 'Pagado', ancho: 12, tipo: 'dinero' },
      { t: 'Vacac.', ancho: 7, tipo: 'decimal' }, { t: 'Desc.', ancho: 7, tipo: 'decimal' }, { t: 'Faltas', ancho: 7, tipo: 'decimal' }, { t: 'Perm.', ancho: 7, tipo: 'decimal' }, { t: 'Incap.', ancho: 7, tipo: 'decimal' }, { t: 'Vac. restan', ancho: 9, tipo: 'decimal' }];
    out.filasEmp = emps.map((e) => [e.nombre + (e.activo ? '' : ' (baja)'), e.puesto || '', e.sueldo, PER_PAGO[e.periodo] || '', e.descanso || '', e.pagado, e.vacaciones, e.descansos, e.faltas, e.permisos, e.incapacidades, e.vac_restan]);
    out.totEmp = ['TOTAL', '', sumar(emps, 'sueldo'), '', '', sumar(emps, 'pagado'), sumar(emps, 'vacaciones'), sumar(emps, 'descansos'), sumar(emps, 'faltas'), sumar(emps, 'permisos'), sumar(emps, 'incapacidades'), ''];
    out.colsDias = [{ t: 'Empleado', ancho: 22 }, { t: 'Tipo', ancho: 12 }, { t: 'Desde', ancho: 11 }, { t: 'Hasta', ancho: 11 }, { t: 'Días', ancho: 7, tipo: 'decimal' }, { t: 'Con goce', ancho: 8 }, { t: 'Notas', ancho: 26 }];
    out.filasDias = (nom.dias || []).map((x) => [x.empleado, TIPO_DIA[x.tipo] || x.tipo, fx(x.desde), fx(x.hasta), x.en_periodo ?? x.dias, x.goce === 0 ? 'No' : 'Sí', x.notas || '']);
    const cx = c.cuentas || { lista: [], pagos: [] }, EST = { pendiente: 'Se debe', vencida: 'VENCIDA', pagada: 'Pagada' };
    out.cxKpis = [['Se debe (a tiempo)', `${dinero(cx.pendiente || 0)} (${cx.n_pendiente || 0})`], ['Vencido', `${dinero(cx.vencido || 0)} (${cx.n_vencido || 0})`], ['Cuentas nuevas del periodo', dinero(cx.nuevas || 0)], ['Pagado a proveedores', dinero(cx.pagado || 0)]];
    out.colsCx = [{ t: 'Proveedor', ancho: 20 }, { t: 'Concepto', ancho: 24 }, { t: 'Factura', ancho: 10 }, { t: 'Fecha', ancho: 10 }, { t: 'Vence', ancho: 10 }, { t: 'Monto', ancho: 11, tipo: 'dinero' }, { t: 'Pagado', ancho: 11, tipo: 'dinero' }, { t: 'Debe', ancho: 11, tipo: 'dinero' }, { t: 'Estado', ancho: 10 }];
    out.filasCx = (cx.lista || []).map((x) => [x.proveedor || '', x.concepto, x.factura || '', fx(x.fecha), x.vence ? fx(x.vence) : '', x.monto, x.pagado, x.saldo, (EST[x.estado] || x.estado) + (x.por_vencer ? ' (por vencer)' : '')]);
    out.totCx = ['', 'TOTAL', '', '', '', sumar(cx.lista || [], 'monto'), sumar(cx.lista || [], 'pagado'), sumar(cx.lista || [], 'saldo'), ''];
    out.colsCxPag = [{ t: 'Fecha', ancho: 11 }, { t: 'Proveedor', ancho: 22 }, { t: 'Concepto', ancho: 28 }, { t: 'Pagado con', ancho: 13 }, { t: 'Monto', ancho: 12, tipo: 'dinero' }];
    out.filasCxPag = (cx.pagos || []).map((x) => [fx(x.fecha), x.proveedor || '', x.concepto + (x.factura ? ' · ' + x.factura : ''), x.pagado_con === 'caja' ? 'Caja' : 'Fuera de caja', x.monto]);
    out.colsPagos = [{ t: 'Fecha', ancho: 11 }, { t: 'Concepto', ancho: 36 }, { t: 'Pagado con', ancho: 13 }, { t: 'Monto', ancho: 13, tipo: 'dinero' }];
    out.filasPagos = (nom.pagos || []).map((g) => [fx(g.fecha), g.nombre, g.pagado_con === 'caja' ? 'Caja' : 'Fuera de caja', r2(g.monto)]);
    out.totPagos = ['', 'TOTAL', '', sumar(nom.pagos || [], 'monto')];
    return out;
  }
  window.partesExtraReporte = partesExtra;
  // ---------- Gráficas en pantalla (computadora, celular y página del dueño) ----------
  const COLS_G = ['#cd6628', '#2563eb', '#16a34a', '#d97706', '#8b5cf6', '#dc2626', '#0d9488', '#ec4899', '#64734f', '#6b7280'];
  const escG = (t) => String(t ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const colorDe = (lista) => { const m = {}; lista.forEach((n, i) => { m[n] = COLS_G[i % COLS_G.length]; }); return m; };
  // Pastel (dona) con leyenda: datos = [{ unidad, total, pct }]
  window.graficaPastel = function (datos, nombres) {
    const l = (datos || []).filter((x) => x.total > 0), tot = l.reduce((a, x) => a + x.total, 0);
    if (!tot) return '<p style="color:#6b7065;margin:6px 0">Sin ventas en este periodo.</p>';
    const col = colorDe(nombres || l.map((x) => x.unidad));
    let ang = -Math.PI / 2; const R = 80, r0 = 46, c = 90;
    const arcos = l.map((x) => {
      const a = (x.total / tot) * 2 * Math.PI, a2 = ang + a, g = a > Math.PI ? 1 : 0;
      const P = (rr, t) => `${(c + rr * Math.cos(t)).toFixed(2)} ${(c + rr * Math.sin(t)).toFixed(2)}`;
      const d = l.length === 1 ? `M ${c - R} ${c} A ${R} ${R} 0 1 1 ${c + R} ${c} A ${R} ${R} 0 1 1 ${c - R} ${c} Z M ${c - r0} ${c} A ${r0} ${r0} 0 1 0 ${c + r0} ${c} A ${r0} ${r0} 0 1 0 ${c - r0} ${c} Z`
        : `M ${P(R, ang)} A ${R} ${R} 0 ${g} 1 ${P(R, a2)} L ${P(r0, a2)} A ${r0} ${r0} 0 ${g} 0 ${P(r0, ang)} Z`;
      ang = a2;
      return `<path d="${d}" fill="${col[x.unidad]}" fill-rule="evenodd" stroke="#fff" stroke-width="1.5"><title>${escG(x.unidad)}: ${(Math.round((x.total / tot) * 1000) / 10)}%</title></path>`;
    }).join('');
    const din = (n) => '$' + Number(n || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return `<div style="display:flex;gap:18px;align-items:center;flex-wrap:wrap">
      <svg viewBox="0 0 180 180" width="180" height="180" style="flex:none" role="img" aria-label="Gráfica de pastel">${arcos}<text x="90" y="86" text-anchor="middle" font-size="11" fill="#6b7065">Total</text><text x="90" y="104" text-anchor="middle" font-size="14" font-weight="700" fill="#1c1f1a">${din(tot).replace('.00', '')}</text></svg>
      <div style="flex:1;min-width:200px;display:grid;gap:6px">${l.map((x) => `<div style="display:flex;align-items:center;gap:8px;font-size:14px"><i style="width:12px;height:12px;border-radius:3px;background:${col[x.unidad]};flex:none"></i><span style="flex:1">${escG(x.unidad)}</span><b>${(Math.round((x.total / tot) * 1000) / 10).toFixed(1)}%</b><span style="color:#6b7065;min-width:92px;text-align:right">${din(x.total)}</span></div>`).join('')}</div></div>`;
  };
  // Barras apiladas por mes (cada barra = 100% del mes): compara el peso de cada unidad entre meses
  window.graficaComparativo = function (um) {
    um = recortarMeses(um);
    if (!um || !um.meses || !um.meses.some((m) => m.total)) return '<p style="color:#6b7065;margin:6px 0">Sin ventas en los meses anteriores.</p>';
    const col = colorDe(um.unidades), maxT = Math.max(...um.meses.map((m) => m.total));
    return `<div style="display:grid;gap:8px">${um.meses.map((m) => `<div style="display:grid;grid-template-columns:62px 1fr 92px;gap:8px;align-items:center;font-size:13px">
        <span style="color:#6b7065">${NOM_MES(m.mes)}</span>
        <div style="height:22px;border-radius:6px;overflow:hidden;display:flex;background:#eef0ea;width:${m.total ? Math.max(8, (m.total / maxT) * 100) : 100}%">${m.total ? um.unidades.map((n) => { const v = m.unidades[n] || 0; return v ? `<i title="${escG(n)}: ${(Math.round((v / m.total) * 1000) / 10)}%" style="width:${(v / m.total) * 100}%;background:${col[n]};display:flex;align-items:center;justify-content:center;color:#fff;font-style:normal;font-size:11px;font-weight:700;overflow:hidden">${v / m.total >= 0.12 ? Math.round((v / m.total) * 100) + '%' : ''}</i>` : ''; }).join('') : ''}</div>
        <b style="text-align:right">${'$' + Math.round(m.total).toLocaleString('es-MX')}</b></div>`).join('')}
      <div style="display:flex;flex-wrap:wrap;gap:6px 14px;font-size:12px;color:#6b7065;margin-top:4px">${um.unidades.map((n) => `<span style="display:inline-flex;align-items:center;gap:5px"><i style="width:10px;height:10px;border-radius:2px;background:${col[n]}"></i>${escG(n)}</span>`).join('')}</div></div>`;
  };


  const MESES_L = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  const DIAS_C = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
  const diaSem = (s) => DIAS_C[new Date(s + 'T12:00:00').getDay()];
  const pct = (a, b) => (!b ? (a ? 'nuevo' : '—') : (a >= b ? '+' : '-') + Math.abs(Math.round(((a - b) / b) * 100)) + '%');
  // Nombre del periodo: "Octubre 2026" si es un mes completo, si no "1 oct al 15 oct 2026"
  function nombrePeriodo(d, h) {
    const a = new Date(d + 'T12:00:00'), b = new Date(h + 'T12:00:00');
    const finMes = new Date(a.getFullYear(), a.getMonth() + 1, 0).getDate();
    if (a.getDate() === 1 && b.getDate() === finMes && d.slice(0, 7) === h.slice(0, 7)) return `${MESES_L[a.getMonth()][0].toUpperCase()}${MESES_L[a.getMonth()].slice(1)} ${a.getFullYear()}`;
    if (d === h) return `${a.getDate()} ${MESES[a.getMonth()]} ${a.getFullYear()}`;
    return `${a.getDate()} ${MESES[a.getMonth()]} al ${b.getDate()} ${MESES[b.getMonth()]} ${b.getFullYear()}`;
  }
  const TIPO_MOV = { retiro: 'Retiro', gasto: 'Gasto', entrada: 'Entrada' };

  // Arma las partes del cierre (las usan Excel y PDF)
  function partesCierre(c, gym) {
    const r = c.resumen, v = r.ventas, it = r.items, ab = r.abonos, cj = r.caja, per = nombrePeriodo(c.desde, c.hasta);
    const salio = r2(cj.retiros + cj.gastos), netoCaja = r2(v.efectivo + ab.efectivo - salio + cj.entradas);
    const kpis = [
      ['Total vendido', dinero(v.total)], ['Tickets', String(v.n)], ['Promedio por día', dinero(v.total / Math.max(1, c.dias))], ['vs periodo anterior', `${pct(v.total, c.anterior.total)} (${dinero(c.anterior.total)})`],
      ['Membresías vendidas', `${dinero(it.membresias)} (${it.membresias_n})`], ['Productos vendidos', dinero(it.productos)], ['Ganancia en productos', dinero(it.utilidad)], ['Abonos cobrados', `${dinero(ab.total)} (${ab.n})`],
      ['Efectivo recibido (neto)', dinero(v.efectivo)], ['Dólares recibidos', `${usd(v.usd)} = ${dinero(v.usd_mxn)}`], ['Tarjeta', dinero(v.tarjeta)], ['Transferencia', dinero(v.transferencia || 0)], ['Fiado (a crédito)', dinero(v.credito)],
      ['Retiros de caja', dinero(cj.retiros)], ['Gastos pagados de caja', dinero(cj.gastos)], ['Entradas de efectivo', dinero(cj.entradas)], ['Ventas canceladas', `${c.canceladas.n} (${dinero(c.canceladas.total)})`],
    ];
    const socios = [
      ['Socios activos hoy', String(c.socios.activos)], ['Activos al cierre del periodo', String(c.socios.activos_fin)], ['Activos al inicio', String(c.socios.activos_inicio)], ['Clientes nuevos', String(c.socios.nuevos)],
      ['Membresías que vencieron', String(c.socios.vencidos)], ['Personas que asistieron', String(c.socios.asistentes)], ['Entradas registradas', String(c.socios.entradas)], ['Clientes en total', String(c.socios.total)],
      ['Cuentas por cobrar', `${dinero(c.por_cobrar)} · ${c.por_cobrar_n} ${c.por_cobrar_n === 1 ? 'cliente' : 'clientes'}`], ['Inventario al costo', dinero(c.inventario.costo)], ['Inventario a la venta', dinero(c.inventario.venta)], ['Productos por acabarse', String(c.inventario.bajos || 0)],
    ];
    const colsDia = [{ t: 'Fecha', ancho: 11 }, { t: 'Día', ancho: 6 }, { t: 'Tickets', ancho: 8, tipo: 'entero' }, { t: 'Total', ancho: 12, tipo: 'dinero' }, { t: 'Membresías', ancho: 12, tipo: 'dinero' }, { t: 'Productos', ancho: 12, tipo: 'dinero' },
      { t: 'Efectivo', ancho: 12, tipo: 'dinero' }, { t: 'Dólares en $', ancho: 12, tipo: 'dinero' }, { t: 'Tarjeta', ancho: 12, tipo: 'dinero' }, { t: 'Transferencia', ancho: 12, tipo: 'dinero' }, { t: 'Crédito', ancho: 11, tipo: 'dinero' }, { t: 'Abonos', ancho: 11, tipo: 'dinero' }, { t: 'Retiros/gastos', ancho: 13, tipo: 'dinero' }, { t: 'Asistencia', ancho: 10, tipo: 'entero' }];
    const filasDia = c.por_dia.map((x) => [fx(x.dia), diaSem(x.dia), x.n, x.total, x.membresias, x.productos, x.efectivo, x.usd_mxn, x.tarjeta, x.transferencia || 0, x.credito, x.abonos, x.caja, x.personas]);
    const totDia = ['TOTAL', '', sumar(c.por_dia, 'n'), sumar(c.por_dia, 'total'), sumar(c.por_dia, 'membresias'), sumar(c.por_dia, 'productos'), sumar(c.por_dia, 'efectivo'), sumar(c.por_dia, 'usd_mxn'), sumar(c.por_dia, 'tarjeta'), sumar(c.por_dia, 'transferencia'), sumar(c.por_dia, 'credito'), sumar(c.por_dia, 'abonos'), sumar(c.por_dia, 'caja'), ''];
    const mejor = c.por_dia.reduce((a, x) => (x.total > (a?.total || 0) ? x : a), null);
    const gn = c.gastos_negocio || [], gnTotal = sumar(gn, 'monto'), costoProd = r2(it.productos - it.utilidad);
    const resultado = r2(v.total - costoProd - gnTotal);
    const gastosKpis = [
      ['Gastos del negocio registrados', `${dinero(gnTotal)} (${gn.length})`], ['Gastos fijos (agua, luz, renta…)', dinero(sumar(gn.filter((x) => x.fijo), 'monto'))], ['Gastos varios', dinero(sumar(gn.filter((x) => !x.fijo), 'monto'))],
      ['Resultado estimado del periodo', dinero(resultado)],
    ];
    return { per, kpis, socios, colsDia, filasDia, totDia, mejor, netoCaja, salio, gastosKpis, resultado, costoProd, gnTotal,
      colsGN: [{ t: 'Fecha', ancho: 11 }, { t: 'Gasto', ancho: 28 }, { t: 'Categoría', ancho: 18 }, { t: 'Tipo', ancho: 9 }, { t: 'Pagado con', ancho: 12 }, { t: 'Monto', ancho: 13, tipo: 'dinero' }],
      filasGN: gn.map((x) => [fx(x.fecha), x.nombre, x.categoria || '', x.fijo ? 'Fijo' : 'Vario', x.pagado_con === 'caja' ? 'Caja' : 'Fuera de caja', r2(x.monto)]), totGN: ['', 'TOTAL', '', '', '', gnTotal],
      colsGNC: [{ t: 'Categoría', ancho: 30 }, { t: 'Pagos', ancho: 10, tipo: 'entero' }, { t: 'Total', ancho: 14, tipo: 'dinero' }],
      filasGNC: (c.gastos_negocio_cat || []).map((x) => [x.categoria, x.n, r2(x.total)]),
      colsMemb: [{ t: 'Plan', ancho: 18 }, { t: 'Promoción', ancho: 24 }, { t: 'Cantidad', ancho: 10, tipo: 'entero' }, { t: 'Importe', ancho: 14, tipo: 'dinero' }],
      filasMemb: c.membresias.map((m) => [m.plan, m.promo, m.n, r2(m.total)]), totMemb: ['TOTAL', '', sumar(c.membresias, 'n'), sumar(c.membresias, 'total')],
      colsProd: [{ t: 'Producto', ancho: 30 }, { t: 'Piezas', ancho: 9, tipo: 'decimal' }, { t: 'Importe', ancho: 13, tipo: 'dinero' }, { t: 'Costo', ancho: 13, tipo: 'dinero' }, { t: 'Ganancia', ancho: 13, tipo: 'dinero' }],
      filasProd: c.productos.map((p) => [p.producto, p.cantidad, r2(p.importe), r2(p.costo), r2(p.utilidad)]), totProd: ['TOTAL', sumar(c.productos, 'cantidad'), sumar(c.productos, 'importe'), sumar(c.productos, 'costo'), sumar(c.productos, 'utilidad')],
      colsGas: [{ t: 'Tipo', ancho: 10 }, { t: 'Categoría', ancho: 30 }, { t: 'Movimientos', ancho: 12, tipo: 'entero' }, { t: 'Total', ancho: 14, tipo: 'dinero' }],
      filasGas: c.gastos.map((g) => [TIPO_MOV[g.tipo] || g.tipo, g.categoria, g.n, r2(g.total)]),
      colsCor: [{ t: 'Turno', ancho: 7, tipo: 'entero' }, { t: 'Cajero', ancho: 18 }, { t: 'Abierto', ancho: 16 }, { t: 'Cerrado', ancho: 16 }, { t: 'Ventas', ancho: 13, tipo: 'dinero' }, { t: 'Diferencia', ancho: 12, tipo: 'dinero' }],
      filasCor: c.cortes.map((x) => [x.id, x.cajero, `${fx(x.abierto)} ${hora(x.abierto)}`, x.cerrado ? `${fx(x.cerrado)} ${hora(x.cerrado)}` : 'Abierto', r2(x.ventas), x.diferencia]),
      totCor: ['', 'TOTAL', '', '', sumar(c.cortes, 'ventas'), sumar(c.cortes, (x) => x.diferencia || 0)],
      colsCaj: [{ t: 'Cajero', ancho: 24 }, { t: 'Tickets', ancho: 10, tipo: 'entero' }, { t: 'Vendido', ancho: 14, tipo: 'dinero' }],
      filasCaj: c.cajeros.map((x) => [x.cajero, x.n, r2(x.total)]) };
  }

  // Cierre de mes en PDF
  window.generarReportePdf = async function (tipo, d, h, { gym, api, departamento, conteo }) {
    gym = gym || 'Mi gimnasio';
    const pieG = `${gym} · Sistema Maxsel Punto de Venta para Gimnasios`, per = nombrePeriodo(d, h);
    if (tipo === 'inventario') {
      const datos = await api(`/api/reportes/excel?tipo=inventario&desde=${d}&hasta=${h}`);
      const l = datos.lista.filter((p) => p.activo && (!departamento || p.area === departamento));
      if (!l.length) throw new Error('No hay productos para ese departamento');
      const grupos = [...new Set(l.map((p) => p.area))];
      const cols = conteo
        ? [{ t: '#', ancho: 4, tipo: 'entero' }, { t: 'Código', ancho: 14 }, { t: 'Producto', ancho: 34 }, { t: 'Sistema', ancho: 8, tipo: 'decimal' }, { t: 'Contado', ancho: 10 }, { t: 'Diferencia', ancho: 10 }]
        : [{ t: 'Código', ancho: 13 }, { t: 'Producto', ancho: 30 }, { t: 'Exist.', ancho: 7, tipo: 'decimal' }, { t: 'Mín.', ancho: 6, tipo: 'decimal' }, { t: 'Costo', ancho: 10, tipo: 'dinero' }, { t: 'Precio', ancho: 10, tipo: 'dinero' }, { t: 'Valor costo', ancho: 11, tipo: 'dinero' }, { t: 'Estado', ancho: 10 }];
      const val = (x) => x.costo * Math.max(0, x.existencia);
      let n = 0;
      descargarPdf(`${conteo ? 'Hoja de conteo' : 'Inventario'} ${departamento || 'todos'} ${hoyR()}`, {
        titulo: `${conteo ? 'Hoja de conteo de inventario' : 'Inventario'} · ${gym}`, pie: pieG,
        subtitulo: `${departamento || 'Todos los departamentos'} · ${l.length} productos · Al ${fx(hoyR())}`,
        secciones: [
          ...(conteo ? [{ texto: 'Cuente lo que hay en anaquel y bodega, anote el total en "Contado" y la diferencia contra el sistema. Después corrija la existencia en Productos.' }]
            : [{ kpis: [['Productos', String(l.length)], ['Piezas', String(sumar(l, 'existencia'))], ['Valor al costo', dinero(sumar(l, val))], ['Valor a la venta', dinero(sumar(l, (x) => x.precio * Math.max(0, x.existencia)))],
              ['Agotados', String(l.filter((x) => x.existencia <= 0).length)], ['Por acabarse', String(l.filter((x) => x.existencia > 0 && x.existencia <= x.minimo).length)]] }]),
          ...grupos.map((g) => { const L = l.filter((x) => x.area === g); return { titulo: `${g} · ${L.length} productos${conteo ? '' : ' · ' + dinero(sumar(L, val))}`, tabla: { columnas: cols,
            filas: L.map((x) => (conteo ? [++n, x.codigo || '', x.nombre, x.existencia, '', ''] : [x.codigo || '', x.nombre, x.existencia, x.minimo, x.costo, x.precio, r2(val(x)), x.existencia <= 0 ? 'AGOTADO' : x.existencia <= x.minimo ? 'Surtir' : 'OK'])),
            totales: conteo ? null : ['', 'TOTAL', sumar(L, 'existencia'), '', '', '', sumar(L, val), ''] } }; }),
          ...(conteo ? [{ texto: 'Contó: ______________________________     Revisó: ______________________________     Fecha: ____________' }] : []),
        ],
      });
      return;
    }
    if (tipo === 'unidades') {
      const c = await api(`/api/reportes/excel?tipo=unidades&desde=${d}&hasta=${h}`), x = partesExtra(c);
      descargarPdf(`Unidades de negocio ${per}`, { titulo: `Unidades de negocio · ${gym}`, subtitulo: `${per} · Cuánto aporta cada unidad al total vendido`, pie: pieG,
        secciones: [{ titulo: `Participación en ${per}`, pastel: x.pastel }, { tabla: { columnas: x.colsUni, filas: x.filasUni, totales: x.totUni } },
          { titulo: 'Comparación con meses anteriores (vendido)', tabla: { columnas: x.colsMes, filas: x.filasMes } },
          { titulo: 'Comparación con meses anteriores (% de cada unidad)', tabla: { columnas: x.colsMesPct, filas: x.filasMesPct } },
          { titulo: 'Ventas por departamento de la tienda', tabla: { columnas: x.colsDep, filas: x.filasDep, totales: x.totDep } }] });
      return;
    }
    if (tipo === 'cuentas') {
      const c = await api(`/api/reportes/excel?tipo=cuentas&desde=${d}&hasta=${h}`), x = partesExtra({ cuentas: c });
      descargarPdf(`Cuentas por pagar ${hoyR()}`, { titulo: `Cuentas por pagar a proveedores · ${gym}`, subtitulo: `Al ${fx(hoyR())} · pagos del ${per}`, pie: pieG,
        secciones: [{ kpis: x.cxKpis }, { titulo: 'Cuentas abiertas (se debe y vencidas)', tabla: { columnas: x.colsCx, filas: x.filasCx, totales: x.totCx } },
          { titulo: `Pagos hechos (${per})`, tabla: { columnas: x.colsCxPag, filas: x.filasCxPag } }] });
      return;
    }
    if (tipo === 'empleados') {
      const c = await api(`/api/reportes/excel?tipo=empleados&desde=${d}&hasta=${h}`), x = partesExtra({ nomina: c });
      if (!(c.empleados || []).length) throw new Error('Todavía no hay empleados registrados');
      descargarPdf(`Empleados y nomina ${per}`, { titulo: `Empleados y nómina · ${gym}`, subtitulo: per, pie: pieG,
        secciones: [{ kpis: x.nomKpis }, { titulo: 'Empleados', tabla: { columnas: x.colsEmp, filas: x.filasEmp, totales: x.totEmp } },
          { titulo: 'Pagos de nómina', tabla: { columnas: x.colsPagos, filas: x.filasPagos, totales: x.totPagos } },
          { titulo: 'Vacaciones, descansos, faltas y permisos', tabla: { columnas: x.colsDias, filas: x.filasDias } }] });
      return;
    }
    if (tipo !== 'cierre') throw new Error('Ese reporte solo está en Excel');
    const c = await api(`/api/reportes/excel?tipo=cierre&desde=${d}&hasta=${h}`);
    const p = partesCierre(c, gym), x = partesExtra(c);
    const r = c.resumen;
    descargarPdf(`Cierre ${p.per.replace(/ al /g, ' a ')}`, {
      titulo: `Cierre de ${p.per} · ${gym || 'Mi gimnasio'}`,
      subtitulo: `Del ${fx(c.desde)} al ${fx(c.hasta)} (${c.dias} días) · Generado el ${fx(c.generado)} ${hora(c.generado)}`,
      pie: `${gym || 'Mi gimnasio'} · Sistema Maxsel Punto de Venta para Gimnasios`,
      secciones: [
        { titulo: 'Resumen de ventas', kpis: p.kpis.slice(0, 8) },
        { titulo: 'Cómo pagaron y dinero de caja', kpis: p.kpis.slice(8, 16), texto: `Neto en efectivo del periodo: ${dinero(p.netoCaja)} (efectivo recibido + abonos en efectivo + entradas - retiros - gastos).${p.mejor && p.mejor.total ? ` Mejor día: ${fx(p.mejor.dia)} con ${dinero(p.mejor.total)}.` : ''}` },
        { titulo: 'Gastos del negocio y resultado', kpis: p.gastosKpis, texto: `Resultado estimado = ventas (${dinero(r.ventas.total)}) - costo de los productos vendidos (${dinero(p.costoProd)}) - gastos registrados en el apartado Gastos (${dinero(p.gnTotal)}). No incluye retiros de caja.` },
        { titulo: 'Socios, cobranza e inventario', kpis: p.socios },
        { titulo: 'Ventas por día', tabla: { columnas: [{ t: 'Fecha', ancho: 10 }, { t: 'Día', ancho: 5 }, { t: 'Tickets', ancho: 7, tipo: 'entero' }, { t: 'Total', ancho: 11, tipo: 'dinero' }, { t: 'Membresías', ancho: 11, tipo: 'dinero' }, { t: 'Productos', ancho: 10, tipo: 'dinero' },
          { t: 'Efectivo', ancho: 11, tipo: 'dinero' }, { t: 'Tarjeta', ancho: 10, tipo: 'dinero' }, { t: 'Transf.', ancho: 9, tipo: 'dinero' }, { t: 'Crédito', ancho: 9, tipo: 'dinero' }, { t: 'Abonos', ancho: 9, tipo: 'dinero' }, { t: 'Ret./gastos', ancho: 10, tipo: 'dinero' }, { t: 'Asist.', ancho: 6, tipo: 'entero' }],
          filas: p.filasDia.map((f) => f.filter((_, i) => i !== 7)), totales: p.totDia.filter((_, i) => i !== 7) } },
        { titulo: 'Unidades de negocio: cuánto aporta cada una', pastel: x.pastel },
        { tabla: { columnas: x.colsUni, filas: x.filasUni, totales: x.totUni } },
        { titulo: 'Comparación con meses anteriores (vendido por unidad)', tabla: { columnas: x.colsMes, filas: x.filasMes } },
        { titulo: 'Comparación con meses anteriores (% de cada unidad)', tabla: { columnas: x.colsMesPct, filas: x.filasMesPct } },
        { titulo: 'Ventas por departamento de la tienda', tabla: { columnas: x.colsDep, filas: x.filasDep, totales: x.totDep } },
        { titulo: 'Membresías vendidas', tabla: { columnas: p.colsMemb, filas: p.filasMemb, totales: p.totMemb } },
        { titulo: 'Productos vendidos', tabla: { columnas: p.colsProd, filas: p.filasProd.slice(0, 40), totales: p.totProd } },
        { titulo: 'Gastos del negocio (fijos y varios)', tabla: { columnas: p.colsGN, filas: p.filasGN, totales: p.totGN } },
        { titulo: 'Gastos por categoría', tabla: { columnas: p.colsGNC, filas: p.filasGNC } },
        { titulo: 'Cuentas por pagar a proveedores', kpis: x.cxKpis },
        ...(x.filasCx.length ? [{ tabla: { columnas: x.colsCx, filas: x.filasCx, totales: x.totCx } }] : []),
        { titulo: 'Empleados y nómina', kpis: x.nomKpis },
        ...(x.filasEmp.length ? [{ tabla: { columnas: x.colsEmp, filas: x.filasEmp, totales: x.totEmp } }] : []),
        ...(x.filasDias.length ? [{ titulo: 'Vacaciones, descansos, faltas y permisos', tabla: { columnas: x.colsDias, filas: x.filasDias } }] : []),
        { titulo: 'Retiros, gastos y entradas de efectivo de la caja', tabla: { columnas: p.colsGas, filas: p.filasGas } },
        { titulo: 'Cortes de caja', tabla: { columnas: p.colsCor, filas: p.filasCor, totales: p.totCor } },
        { titulo: 'Ventas por cajero', tabla: { columnas: p.colsCaj, filas: p.filasCaj } },
      ],
    });
  };

  // Descarga el reporte. api(url) debe regresar el JSON del servidor.
  window.generarReporteExcel = async function (tipo, d, h, { gym, api }) {
    gym = gym || 'Mi gimnasio';
  const datos = await api(`/api/reportes/excel?tipo=${tipo}&desde=${d}&hasta=${h}`);
  const periodo = d === h ? fx(d) : `${fx(d)} al ${fx(h)}`;
  const archivo = (n) => `${n} ${d}${d === h ? '' : ' a ' + h}`;
  if (tipo === 'productos') {
    const l = datos.detalle;
    if (!l.length) throw new Error('No hay ventas de productos en esas fechas');
    descargarExcel(archivo('Venta de productos'), [
      { nombre: 'Detalle', titulo: `Venta de productos · ${gym}`, subtitulo: `Periodo: ${periodo}  ·  Total: ${dinero(sumar(l, 'importe'))}  ·  Ganancia: ${dinero(sumar(l, 'utilidad'))}`,
        columnas: [{ t: 'Fecha', ancho: 11 }, { t: 'Hora', ancho: 7 }, { t: 'Ticket', ancho: 8, tipo: 'entero' }, { t: 'Código', ancho: 16 }, { t: 'Producto', ancho: 30 },
          { t: 'Cantidad', ancho: 9, tipo: 'decimal' }, { t: 'Precio', ancho: 11, tipo: 'dinero' }, { t: 'Importe', ancho: 12, tipo: 'dinero' }, { t: 'Costo unit.', ancho: 11, tipo: 'dinero' },
          { t: 'Ganancia', ancho: 12, tipo: 'dinero' }, { t: 'Forma de pago', ancho: 16 }, { t: 'Cliente', ancho: 24 }, { t: 'Cajero', ancho: 16 }],
        filas: l.map((x) => [fx(x.fecha), hora(x.fecha), x.ticket, x.codigo || '', x.producto, x.cantidad, x.precio, x.importe, x.costo, r2(x.utilidad), x.forma, x.cliente || '', x.cajero || '']),
        totales: ['', '', '', '', 'TOTAL', sumar(l, 'cantidad'), '', sumar(l, 'importe'), '', sumar(l, 'utilidad'), '', '', ''] },
      { nombre: 'Por producto', titulo: `Resumen por producto · ${periodo}`,
        columnas: [{ t: 'Código', ancho: 16 }, { t: 'Producto', ancho: 32 }, { t: 'Piezas vendidas', ancho: 14, tipo: 'decimal' }, { t: 'Importe', ancho: 13, tipo: 'dinero' },
          { t: 'Costo', ancho: 13, tipo: 'dinero' }, { t: 'Ganancia', ancho: 13, tipo: 'dinero' }, { t: 'Existencia actual', ancho: 15, tipo: 'decimal' }],
        filas: datos.resumen.map((x) => [x.codigo || '', x.producto, x.cantidad, r2(x.importe), r2(x.costo), r2(x.utilidad), x.existencia ?? '']),
        totales: ['', 'TOTAL', sumar(datos.resumen, 'cantidad'), sumar(datos.resumen, 'importe'), sumar(datos.resumen, 'costo'), sumar(datos.resumen, 'utilidad'), ''] },
    ]);
  } else if (tipo === 'membresias') {
    const l = datos.detalle;
    if (!l.length) throw new Error('No hay membresías vendidas en esas fechas');
    descargarExcel(archivo('Venta de membresias'), [
      { nombre: 'Detalle', titulo: `Venta de membresías · ${gym}`, subtitulo: `Periodo: ${periodo}  ·  ${l.length} membresías  ·  Total: ${dinero(sumar(l, 'precio'))}`,
        columnas: [{ t: 'Fecha venta', ancho: 11 }, { t: 'Hora', ancho: 7 }, { t: 'Ticket', ancho: 8, tipo: 'entero' }, { t: 'Cliente', ancho: 26 }, { t: 'Teléfono', ancho: 13 },
          { t: 'Plan', ancho: 14 }, { t: 'Promoción', ancho: 22 }, { t: 'Pareja', ancho: 22 }, { t: 'Estudiante', ancho: 10 }, { t: 'Vecino', ancho: 8 },
          { t: 'Desde', ancho: 11 }, { t: 'Hasta', ancho: 11 }, { t: 'Precio', ancho: 12, tipo: 'dinero' }, { t: 'Cajero', ancho: 16 }],
        filas: l.map((x) => [fx(x.fecha), hora(x.fecha), x.ticket, x.cliente, x.telefono || '', x.plan, x.promo, x.pareja, x.estudiante ? 'Sí' : '', x.vecino ? 'Sí' : '', fx(x.inicio), fx(x.fin), x.precio, x.cajero || '']),
        totales: ['', '', '', 'TOTAL', '', '', '', '', '', '', '', '', sumar(l, 'precio'), ''] },
      { nombre: 'Por plan y promoción', titulo: `Resumen de membresías · ${periodo}`,
        columnas: [{ t: 'Plan', ancho: 18 }, { t: 'Promoción', ancho: 26 }, { t: 'Cantidad', ancho: 10, tipo: 'entero' }, { t: 'Importe', ancho: 14, tipo: 'dinero' }],
        filas: datos.resumen.map((x) => [x.plan, x.promo, x.n, r2(x.total)]), totales: ['TOTAL', '', sumar(datos.resumen, 'n'), sumar(datos.resumen, 'total')] },
    ]);
  } else if (tipo === 'asistencias') {
    const l = datos.detalle;
    if (!l.length) throw new Error('No hay asistencias registradas en esas fechas');
    const ORIGEN = { lector: 'Lector facial', manual: 'Manual', simulador: 'Simulador' };
    descargarExcel(archivo('Asistencias'), [
      { nombre: 'Por día', titulo: `Asistencias · ${gym}`, subtitulo: `Periodo: ${periodo}`,
        columnas: [{ t: 'Fecha', ancho: 12 }, { t: 'Personas distintas', ancho: 16, tipo: 'entero' }, { t: 'Entradas', ancho: 11, tipo: 'entero' }, { t: 'Accesos negados', ancho: 15, tipo: 'entero' }],
        filas: datos.por_dia.map((x) => [fx(x.dia), x.personas, x.entradas, x.negados]), totales: ['TOTAL', '', sumar(datos.por_dia, 'entradas'), sumar(datos.por_dia, 'negados')] },
      { nombre: 'Por cliente', titulo: `Asistencia por cliente · ${periodo}`,
        columnas: [{ t: 'No. cliente', ancho: 10, tipo: 'entero' }, { t: 'Cliente', ancho: 30 }, { t: 'Días que vino', ancho: 13, tipo: 'entero' }, { t: 'Entradas', ancho: 10, tipo: 'entero' }, { t: 'Última visita', ancho: 18 }],
        filas: datos.por_cliente.map((x) => [x.id, x.nombre, x.dias, x.entradas, `${fx(x.ultima)} ${hora(x.ultima)}`]) },
      { nombre: 'Por hora', titulo: `Entradas por hora del día · ${periodo}`,
        columnas: [{ t: 'Hora', ancho: 12 }, { t: 'Entradas', ancho: 12, tipo: 'entero' }],
        filas: datos.por_hora.map((x) => [`${x.hora}:00 a ${x.hora}:59`, x.entradas]), totales: ['TOTAL', sumar(datos.por_hora, 'entradas')] },
      { nombre: 'Detalle', titulo: `Registro de accesos · ${periodo}`,
        columnas: [{ t: 'Fecha', ancho: 11 }, { t: 'Hora', ancho: 9 }, { t: 'No. cliente', ancho: 10, tipo: 'entero' }, { t: 'Cliente', ancho: 28 }, { t: 'Resultado', ancho: 11 }, { t: 'Cómo', ancho: 13 }, { t: 'Detalle', ancho: 40 }],
        filas: l.map((x) => [fx(x.fecha), x.fecha.slice(11, 19), x.cliente_id || '', x.cliente, x.resultado === 'permitido' ? 'Entró' : 'Negado', ORIGEN[x.origen] || x.origen || '', x.motivo || '']) },
    ]);
  } else if (tipo === 'ventas') {
    const t = datos.tickets, ok = t.filter((x) => !x.cancelada);
    if (!t.length && !datos.abonos.length) throw new Error('No hay ventas en esas fechas');
    const dias = {};
    for (const x of ok) {
      const k = x.fecha.slice(0, 10), o = dias[k] || (dias[k] = { n: 0, prod: 0, memb: 0, total: 0, ef: 0, usd: 0, usdmxn: 0, tar: 0, trf: 0, cred: 0, abonos: 0 });
      o.n++; o.prod += x.productos; o.memb += x.membresias; o.total += x.total; o.ef += x.pago_efectivo - x.cambio; o.usd += x.pago_usd; o.usdmxn += x.pago_usd * x.tipo_cambio; o.tar += x.pago_tarjeta; o.trf += x.pago_transferencia || 0; o.cred += x.pago_credito;
    }
    for (const a of datos.abonos) { const k = a.fecha.slice(0, 10); (dias[k] || (dias[k] = { n: 0, prod: 0, memb: 0, total: 0, ef: 0, usd: 0, usdmxn: 0, tar: 0, trf: 0, cred: 0, abonos: 0 })).abonos += a.monto; }
    const filasDia = Object.keys(dias).sort().map((k) => { const o = dias[k]; return [fx(k), o.n, r2(o.prod), r2(o.memb), r2(o.total), r2(o.ef), r2(o.usd), r2(o.usdmxn), r2(o.tar), r2(o.trf), r2(o.cred), r2(o.abonos)]; });
    const col = (i) => r2(filasDia.reduce((a, f) => a + f[i], 0));
    descargarExcel(archivo('Ventas totales'), [
      { nombre: 'Resumen por día', titulo: `Ventas totales · ${gym}`, subtitulo: `Periodo: ${periodo}  ·  Total vendido: ${dinero(sumar(ok, 'total'))}  ·  Abonos cobrados: ${dinero(sumar(datos.abonos, 'monto'))}`,
        columnas: [{ t: 'Fecha', ancho: 11 }, { t: 'Tickets', ancho: 8, tipo: 'entero' }, { t: 'Productos', ancho: 12, tipo: 'dinero' }, { t: 'Membresías', ancho: 12, tipo: 'dinero' }, { t: 'Total vendido', ancho: 13, tipo: 'dinero' },
          { t: 'Efectivo (neto)', ancho: 13, tipo: 'dinero' }, { t: 'Dólares (USD)', ancho: 12, tipo: 'dinero' }, { t: 'Dólares en pesos', ancho: 13, tipo: 'dinero' }, { t: 'Tarjeta', ancho: 12, tipo: 'dinero' }, { t: 'Transferencia', ancho: 12, tipo: 'dinero' },
          { t: 'A crédito', ancho: 12, tipo: 'dinero' }, { t: 'Abonos cobrados', ancho: 13, tipo: 'dinero' }],
        filas: filasDia, totales: ['TOTAL', col(1), col(2), col(3), col(4), col(5), col(6), col(7), col(8), col(9), col(10), col(11)] },
      { nombre: 'Tickets', titulo: `Detalle de tickets · ${periodo}`, subtitulo: 'Las ventas canceladas aparecen marcadas y no se suman en los totales.',
        columnas: [{ t: 'Fecha', ancho: 11 }, { t: 'Hora', ancho: 7 }, { t: 'Ticket', ancho: 8, tipo: 'entero' }, { t: 'Turno', ancho: 7, tipo: 'entero' }, { t: 'Cajero', ancho: 15 }, { t: 'Cliente', ancho: 22 },
          { t: 'Detalle', ancho: 40 }, { t: 'Total', ancho: 11, tipo: 'dinero' }, { t: 'Efectivo', ancho: 11, tipo: 'dinero' }, { t: 'Dólares', ancho: 10, tipo: 'dinero' }, { t: 'Tipo cambio', ancho: 10, tipo: 'dinero' },
          { t: 'Tarjeta', ancho: 11, tipo: 'dinero' }, { t: 'Transferencia', ancho: 11, tipo: 'dinero' }, { t: 'Crédito', ancho: 11, tipo: 'dinero' }, { t: 'Cambio', ancho: 10, tipo: 'dinero' }, { t: 'Referencia', ancho: 16 }, { t: 'Estado', ancho: 11 }],
        filas: t.map((x) => [fx(x.fecha), hora(x.fecha), x.id, x.turno_id, x.cajero || '', x.cliente || '', x.detalle || '', x.total, x.pago_efectivo, x.pago_usd, x.tipo_cambio, x.pago_tarjeta, x.pago_transferencia || 0, x.pago_credito, x.cambio, x.referencia || '', x.cancelada ? 'CANCELADA' : 'Pagada']),
        totales: ['', '', '', '', '', '', 'TOTAL (sin canceladas)', sumar(ok, 'total'), sumar(ok, 'pago_efectivo'), sumar(ok, 'pago_usd'), '', sumar(ok, 'pago_tarjeta'), sumar(ok, 'pago_transferencia'), sumar(ok, 'pago_credito'), sumar(ok, 'cambio'), '', ''] },
      { nombre: 'Abonos', titulo: `Abonos a cuentas · ${periodo}`,
        columnas: [{ t: 'Fecha', ancho: 11 }, { t: 'Hora', ancho: 7 }, { t: 'Cliente', ancho: 26 }, { t: 'Monto', ancho: 12, tipo: 'dinero' }, { t: 'Efectivo', ancho: 11, tipo: 'dinero' }, { t: 'Dólares', ancho: 10, tipo: 'dinero' }, { t: 'Tarjeta', ancho: 11, tipo: 'dinero' }, { t: 'Transferencia', ancho: 11, tipo: 'dinero' }, { t: 'Cajero', ancho: 16 }],
        filas: datos.abonos.map((a) => [fx(a.fecha), hora(a.fecha), a.cliente || '', a.monto, a.efectivo, a.usd, a.tarjeta, a.transferencia || 0, a.cajero || '']), totales: ['', '', 'TOTAL', sumar(datos.abonos, 'monto'), '', '', '', '', ''] },
      { nombre: 'Cortes de caja', titulo: `Cortes de caja · ${periodo}`,
        columnas: [{ t: 'Turno', ancho: 7, tipo: 'entero' }, { t: 'Cajero', ancho: 16 }, { t: 'Abierto', ancho: 17 }, { t: 'Cerrado', ancho: 17 }, { t: 'Fondo', ancho: 10, tipo: 'dinero' }, { t: 'Tipo cambio', ancho: 10, tipo: 'dinero' },
          { t: 'Efectivo esperado', ancho: 13, tipo: 'dinero' }, { t: 'Efectivo contado', ancho: 13, tipo: 'dinero' }, { t: 'USD esperado', ancho: 11, tipo: 'dinero' }, { t: 'USD contado', ancho: 11, tipo: 'dinero' },
          { t: 'Tarjeta esperada', ancho: 13, tipo: 'dinero' }, { t: 'Tarjeta contada', ancho: 13, tipo: 'dinero' }, { t: 'Diferencia (pesos)', ancho: 14, tipo: 'dinero' }],
        filas: datos.cortes.map((c) => [c.id, c.cajero, `${fx(c.abierto)} ${hora(c.abierto)}`, c.cerrado ? `${fx(c.cerrado)} ${hora(c.cerrado)}` : 'Abierto', c.fondo_mxn, c.tipo_cambio,
          c.esp_efectivo, c.decl_efectivo, c.esp_usd, c.decl_usd, c.esp_tarjeta, c.decl_tarjeta,
          c.estado === 'cerrado' ? r2((c.decl_efectivo - c.esp_efectivo) + (c.decl_usd - c.esp_usd) * c.tipo_cambio + (c.decl_tarjeta - c.esp_tarjeta)) : '']) },
    ]);
  } else if (tipo === 'cierre') {
    const c = datos, p = partesCierre(c, gym), x = partesExtra(c);
    descargarExcel(`Cierre ${p.per.replace(/ al /g, ' a ')}`, [
      { nombre: 'Resumen', titulo: `Cierre de ${p.per} · ${gym}`, subtitulo: `Del ${fx(c.desde)} al ${fx(c.hasta)} (${c.dias} días) · Generado el ${fx(c.generado)} ${hora(c.generado)}`,
        columnas: [{ t: 'Concepto', ancho: 34 }, { t: 'Valor', ancho: 26 }],
        filas: [['VENTAS', ''], ...p.kpis.slice(0, 8), ['', ''], ['PAGOS Y CAJA', ''], ...p.kpis.slice(8, 16), ['Neto en efectivo del periodo', dinero(p.netoCaja)], ['', ''], ['GASTOS DEL NEGOCIO Y RESULTADO', ''], ...p.gastosKpis, ['', ''], ['CUENTAS POR PAGAR A PROVEEDORES', ''], ...x.cxKpis, ['', ''], ['EMPLEADOS Y NÓMINA', ''], ...x.nomKpis, ['', ''], ['SOCIOS, COBRANZA E INVENTARIO', ''], ...p.socios] },
      { nombre: 'Unidades de negocio', titulo: `Unidades de negocio · ${p.per}`, subtitulo: 'Cuánto aporta cada unidad (membresías y cada departamento de la tienda) al total vendido', columnas: x.colsUni, filas: x.filasUni, totales: x.totUni },
      { nombre: 'Comparativo meses', titulo: 'Vendido por unidad de negocio en los últimos meses', columnas: x.colsMes, filas: x.filasMes },
      { nombre: 'Comparativo %', titulo: 'Porcentaje de cada unidad de negocio por mes', columnas: x.colsMesPct, filas: x.filasMesPct },
      { nombre: 'Departamentos', titulo: `Ventas por departamento · ${p.per}`, columnas: x.colsDep, filas: x.filasDep, totales: x.totDep },
      { nombre: 'Cuentas por pagar', titulo: `Cuentas por pagar a proveedores (abiertas al ${fx(c.generado)})`, columnas: x.colsCx, filas: x.filasCx, totales: x.totCx },
      { nombre: 'Nómina', titulo: `Empleados y nómina · ${p.per}`, columnas: x.colsEmp, filas: x.filasEmp, totales: x.totEmp },
      { nombre: 'Pagos de nómina', titulo: `Pagos de nómina · ${p.per}`, columnas: x.colsPagos, filas: x.filasPagos, totales: x.totPagos },
      { nombre: 'Vacaciones y faltas', titulo: `Vacaciones, descansos, faltas y permisos · ${p.per}`, columnas: x.colsDias, filas: x.filasDias },
      { nombre: 'Gastos del negocio', titulo: `Gastos del negocio (fijos y varios) · ${p.per}`, columnas: p.colsGN, filas: p.filasGN, totales: p.totGN },
      { nombre: 'Gastos por categoría', titulo: `Gastos por categoría · ${p.per}`, columnas: p.colsGNC, filas: p.filasGNC },
      { nombre: 'Por día', titulo: `Ventas por día · ${p.per}`, columnas: p.colsDia, filas: p.filasDia, totales: p.totDia },
      { nombre: 'Membresías', titulo: `Membresías vendidas · ${p.per}`, columnas: p.colsMemb, filas: p.filasMemb, totales: p.totMemb },
      { nombre: 'Productos', titulo: `Productos vendidos · ${p.per}`, columnas: p.colsProd, filas: p.filasProd, totales: p.totProd },
      { nombre: 'Retiros y gastos', titulo: `Retiros, gastos y entradas · ${p.per}`, columnas: p.colsGas, filas: p.filasGas },
      { nombre: 'Cortes', titulo: `Cortes de caja · ${p.per}`, columnas: p.colsCor, filas: p.filasCor, totales: p.totCor },
      { nombre: 'Por cajero', titulo: `Ventas por cajero · ${p.per}`, columnas: p.colsCaj, filas: p.filasCaj },
    ]);
  } else if (tipo === 'gastos') {
    const l = datos.detalle;
    if (!l.length) throw new Error('No hay retiros, gastos ni entradas de efectivo en esas fechas');
    const TIPO = { retiro: 'Retiro', gasto: 'Gasto', entrada: 'Entrada' };
    const tot = (t) => sumar(l.filter((x) => x.tipo === t), 'monto');
    descargarExcel(archivo('Retiros y gastos'), [
      { nombre: 'Detalle', titulo: `Retiros, gastos y entradas de efectivo · ${gym}`, subtitulo: `Periodo: ${periodo}  ·  Retiros: ${dinero(tot('retiro'))}  ·  Gastos: ${dinero(tot('gasto'))}  ·  Entradas: ${dinero(tot('entrada'))}`,
        columnas: [{ t: 'Fecha', ancho: 11 }, { t: 'Hora', ancho: 7 }, { t: 'Turno', ancho: 7, tipo: 'entero' }, { t: 'Tipo', ancho: 9 }, { t: 'Categoría', ancho: 26 }, { t: 'Concepto', ancho: 36 },
          { t: 'Recibió', ancho: 18 }, { t: 'Monto', ancho: 12, tipo: 'dinero' }, { t: 'Cajero', ancho: 16 }],
        filas: l.map((x) => [fx(x.fecha), hora(x.fecha), x.turno_id, TIPO[x.tipo] || x.tipo, x.categoria || '', x.concepto || '', x.recibe || '', x.tipo === 'entrada' ? x.monto : -x.monto, x.cajero || '']),
        totales: ['', '', '', '', '', 'SALIÓ DE CAJA (retiros + gastos)', '', -r2(tot('retiro') + tot('gasto')), ''] },
      { nombre: 'Por categoría', titulo: `Resumen por categoría · ${periodo}`,
        columnas: [{ t: 'Tipo', ancho: 10 }, { t: 'Categoría', ancho: 30 }, { t: 'Movimientos', ancho: 12, tipo: 'entero' }, { t: 'Total', ancho: 14, tipo: 'dinero' }],
        filas: datos.por_categoria.map((x) => [TIPO[x.tipo] || x.tipo, x.categoria, x.n, r2(x.total)]) },
    ]);
  } else if (tipo === 'cortes') {
    const l = datos.cortes;
    if (!l.length) throw new Error('No hay turnos de caja en esas fechas');
    const dif = (c) => (c.estado === 'cerrado' ? r2((c.decl_efectivo - c.esp_efectivo) + (c.decl_usd - c.esp_usd) * c.tipo_cambio + (c.decl_tarjeta - c.esp_tarjeta)) : '');
    descargarExcel(archivo('Cortes de caja'), [
      { nombre: 'Cortes', titulo: `Cortes de caja · ${gym}`, subtitulo: `Periodo: ${periodo}  ·  ${l.length} turnos  ·  Diferencia total: ${dinero(sumar(l, (c) => Number(dif(c)) || 0))}`,
        columnas: [{ t: 'Turno', ancho: 7, tipo: 'entero' }, { t: 'Cajero', ancho: 16 }, { t: 'Abierto', ancho: 17 }, { t: 'Cerrado', ancho: 17 }, { t: 'Fondo', ancho: 10, tipo: 'dinero' },
          { t: 'Ventas', ancho: 12, tipo: 'dinero' }, { t: 'Tickets', ancho: 8, tipo: 'entero' }, { t: 'A crédito', ancho: 11, tipo: 'dinero' }, { t: 'Abonos', ancho: 11, tipo: 'dinero' },
          { t: 'Entradas', ancho: 10, tipo: 'dinero' }, { t: 'Retiros', ancho: 10, tipo: 'dinero' }, { t: 'Gastos', ancho: 10, tipo: 'dinero' },
          { t: 'Efectivo esperado', ancho: 13, tipo: 'dinero' }, { t: 'Efectivo contado', ancho: 13, tipo: 'dinero' }, { t: 'USD esperado', ancho: 11, tipo: 'dinero' }, { t: 'USD contado', ancho: 11, tipo: 'dinero' },
          { t: 'Tarjeta esperada', ancho: 13, tipo: 'dinero' }, { t: 'Tarjeta contada', ancho: 13, tipo: 'dinero' }, { t: 'Diferencia (pesos)', ancho: 14, tipo: 'dinero' }, { t: 'Notas', ancho: 30 }],
        filas: l.map((c) => [c.id, c.cajero, `${fx(c.abierto)} ${hora(c.abierto)}`, c.cerrado ? `${fx(c.cerrado)} ${hora(c.cerrado)}` : 'Abierto', c.fondo_mxn,
          c.r_ventas_total, c.r_ventas_n, c.r_credito, c.r_abonos_total, c.r_entradas, c.r_retiros, c.r_gastos,
          c.estado === 'cerrado' ? c.esp_efectivo : c.r_efectivo, c.decl_efectivo ?? '', c.estado === 'cerrado' ? c.esp_usd : c.r_usd, c.decl_usd ?? '',
          c.estado === 'cerrado' ? c.esp_tarjeta : c.r_tarjeta, c.decl_tarjeta ?? '', dif(c), c.notas || '']),
        totales: ['', 'TOTAL', '', '', '', sumar(l, 'r_ventas_total'), sumar(l, 'r_ventas_n'), sumar(l, 'r_credito'), sumar(l, 'r_abonos_total'), sumar(l, 'r_entradas'), sumar(l, 'r_retiros'), sumar(l, 'r_gastos'),
          '', '', '', '', '', '', sumar(l, (c) => Number(dif(c)) || 0), ''] },
    ]);
  } else if (tipo === 'adeudos') {
    if (!datos.clientes.length) throw new Error('Nadie debe nada en este momento');
    descargarExcel(`Cuentas por cobrar ${hoyR()}`, [
      { nombre: 'Por cliente', titulo: `Cuentas por cobrar · ${gym}`, subtitulo: `Al ${fx(hoyR())}  ·  ${datos.clientes.length} clientes deben  ·  Total: ${dinero(sumar(datos.clientes, 'saldo'))}`,
        columnas: [{ t: 'No. cliente', ancho: 10, tipo: 'entero' }, { t: 'Cliente', ancho: 30 }, { t: 'Teléfono', ancho: 14 }, { t: 'WhatsApp', ancho: 14 }, { t: 'Debe', ancho: 13, tipo: 'dinero' },
          { t: 'Compras sin pagar', ancho: 12, tipo: 'entero' }, { t: 'Debe desde', ancho: 12 }, { t: 'Última compra', ancho: 13 }],
        filas: datos.clientes.map((c) => [c.id, c.nombre, c.telefono || '', c.whatsapp || '', r2(c.saldo), c.ventas, fx(c.desde), fx(c.ultima)]),
        totales: ['', 'TOTAL', '', '', sumar(datos.clientes, 'saldo'), sumar(datos.clientes, 'ventas'), '', ''] },
      { nombre: 'Detalle', titulo: 'Compras pendientes de pago',
        columnas: [{ t: 'Cliente', ancho: 28 }, { t: 'Fecha', ancho: 11 }, { t: 'Hora', ancho: 7 }, { t: 'Ticket', ancho: 8, tipo: 'entero' }, { t: 'Qué compró', ancho: 40 },
          { t: 'Total', ancho: 11, tipo: 'dinero' }, { t: 'Fiado', ancho: 11, tipo: 'dinero' }, { t: 'Pendiente', ancho: 12, tipo: 'dinero' }, { t: 'Cajero', ancho: 16 }],
        filas: datos.detalle.map((x) => [x.cliente, fx(x.fecha), hora(x.fecha), x.ticket, x.detalle || '', x.total, x.pago_credito, x.credito_pendiente, x.cajero || '']),
        totales: ['TOTAL', '', '', '', '', '', '', sumar(datos.detalle, 'credito_pendiente'), ''] },
    ]);
  } else if (tipo === 'socios') {
    const t = datos.hoy, sem = sumarDiasR(t, 7);
    const est = (c) => (!c.fin ? 'Sin membresía' : c.fin < t ? 'Vencida' : c.fin <= sem ? 'Vence pronto' : 'Activa');
    const l = datos.lista.map((c) => ({ ...c, estado: est(c), dias: c.fin ? Math.round((new Date(c.fin + 'T12:00:00') - new Date(t + 'T12:00:00')) / 86400000) : '' }));
    const fila = (c) => [c.id, c.nombre, c.telefono || '', c.whatsapp || '', c.plan || '', fx(c.fin), c.estado, c.dias, c.ultima_visita ? fx(c.ultima_visita) : '', c.estudiante ? 'Sí' : '', c.vecino ? 'Sí' : '', c.bloqueado ? 'Sí' : ''];
    const cols = [{ t: 'No.', ancho: 7, tipo: 'entero' }, { t: 'Cliente', ancho: 30 }, { t: 'Teléfono', ancho: 14 }, { t: 'WhatsApp', ancho: 14 }, { t: 'Último plan', ancho: 14 }, { t: 'Vence', ancho: 11 },
      { t: 'Estado', ancho: 13 }, { t: 'Días restantes', ancho: 12, tipo: 'entero' }, { t: 'Última visita', ancho: 12 }, { t: 'Estudiante', ancho: 10 }, { t: 'Vecino', ancho: 8 }, { t: 'Bloqueado', ancho: 10 }];
    const activos = l.filter((c) => c.estado === 'Activa' || c.estado === 'Vence pronto');
    const pronto = l.filter((c) => c.estado === 'Vence pronto');
    const vencidos = l.filter((c) => c.estado === 'Vencida' && c.fin >= sumarDiasR(t, -60)).sort((a, b) => (a.fin < b.fin ? 1 : -1));
    descargarExcel(`Socios ${t}`, [
      { nombre: 'Activos', titulo: `Socios con membresía activa · ${gym}`, subtitulo: `Al ${fx(t)}  ·  ${activos.length} socios activos`, columnas: cols, filas: activos.map(fila) },
      { nombre: 'Vencen esta semana', titulo: 'Membresías que vencen en los próximos 7 días', subtitulo: 'Para llamarles o mandarles WhatsApp antes de que venzan', columnas: cols, filas: pronto.map(fila) },
      { nombre: 'Vencidos (60 días)', titulo: 'Socios que vencieron en los últimos 60 días', subtitulo: 'Clientes para recuperar', columnas: cols, filas: vencidos.map(fila) },
      { nombre: 'Todos', titulo: 'Todos los clientes', columnas: cols, filas: l.map(fila) },
    ]);
  } else if (tipo === 'inventario') {
    const l = datos.lista.filter((p) => p.activo);
    if (!l.length) throw new Error('No hay productos registrados');
    descargarExcel(`Inventario ${hoyR()}`, [
      { nombre: 'Inventario', titulo: `Inventario de productos · ${gym}`, subtitulo: `Al ${fx(hoyR())}  ·  Valor al costo: ${dinero(sumar(l, (p) => p.costo * Math.max(0, p.existencia)))}  ·  Valor a precio de venta: ${dinero(sumar(l, (p) => p.precio * Math.max(0, p.existencia)))}`,
        columnas: [{ t: 'Departamento', ancho: 18 }, { t: 'Código', ancho: 16 }, { t: 'Producto', ancho: 32 }, { t: 'Existencia', ancho: 11, tipo: 'decimal' }, { t: 'Mínimo', ancho: 9, tipo: 'decimal' }, { t: 'Costo', ancho: 11, tipo: 'dinero' },
          { t: 'Precio', ancho: 11, tipo: 'dinero' }, { t: 'Valor al costo', ancho: 13, tipo: 'dinero' }, { t: 'Valor a la venta', ancho: 14, tipo: 'dinero' }, { t: 'Estado', ancho: 14 }],
        filas: l.map((p) => [p.area || '', p.codigo || '', p.nombre, p.existencia, p.minimo, p.costo, p.precio, r2(p.costo * Math.max(0, p.existencia)), r2(p.precio * Math.max(0, p.existencia)),
          p.existencia <= 0 ? 'AGOTADO' : p.existencia <= p.minimo ? 'Por acabarse' : 'OK']),
        totales: ['', '', 'TOTAL', sumar(l, 'existencia'), '', '', '', sumar(l, (p) => p.costo * Math.max(0, p.existencia)), sumar(l, (p) => p.precio * Math.max(0, p.existencia)), ''] },
    ]);
  } else if (tipo === 'unidades') {
    const x = partesExtra(datos);
    if (!x.filasUni.length && !x.filasMes.some((f) => f[1])) throw new Error('No hay ventas en esas fechas');
    descargarExcel(archivo('Unidades de negocio'), [
      { nombre: 'Unidades', titulo: `Unidades de negocio · ${gym}`, subtitulo: `Periodo: ${periodo} · Cuánto aporta cada unidad al total vendido`, columnas: x.colsUni, filas: x.filasUni, totales: x.totUni },
      { nombre: 'Comparativo meses', titulo: 'Vendido por unidad en los últimos 12 meses', columnas: x.colsMes, filas: x.filasMes },
      { nombre: 'Comparativo %', titulo: 'Porcentaje de cada unidad por mes', columnas: x.colsMesPct, filas: x.filasMesPct },
      { nombre: 'Departamentos', titulo: `Ventas por departamento · ${periodo}`, columnas: x.colsDep, filas: x.filasDep, totales: x.totDep },
    ]);
  } else if (tipo === 'cuentas') {
    const x = partesExtra({ cuentas: datos });
    descargarExcel(archivo('Cuentas por pagar'), [
      { nombre: 'Cuentas abiertas', titulo: `Cuentas por pagar a proveedores · ${gym}`, subtitulo: `Al ${fx(hoyR())} · Se debe: ${dinero(datos.pendiente)} · Vencido: ${dinero(datos.vencido)}`, columnas: x.colsCx, filas: x.filasCx, totales: x.totCx },
      { nombre: 'Pagos', titulo: `Pagos a proveedores · ${periodo}`, columnas: x.colsCxPag, filas: x.filasCxPag },
    ]);
  } else if (tipo === 'empleados') {
    const x = partesExtra({ nomina: datos });
    if (!(datos.empleados || []).length) throw new Error('Todavía no hay empleados registrados');
    descargarExcel(archivo('Empleados y nomina'), [
      { nombre: 'Empleados', titulo: `Empleados y nómina · ${gym}`, subtitulo: `Periodo: ${periodo} · Sueldos pagados: ${dinero(datos.total)} · Nómina mensual estimada: ${dinero(datos.nomina_mensual)}`, columnas: x.colsEmp, filas: x.filasEmp, totales: x.totEmp },
      { nombre: 'Pagos de nómina', titulo: `Pagos de nómina · ${periodo}`, columnas: x.colsPagos, filas: x.filasPagos, totales: x.totPagos },
      { nombre: 'Vacaciones y faltas', titulo: `Vacaciones, descansos, faltas y permisos · ${periodo}`, columnas: x.colsDias, filas: x.filasDias },
    ]);
  } else throw new Error('Reporte desconocido');
  };
})();
