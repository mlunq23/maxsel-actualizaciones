// Comunicación con terminal facial Hikvision (DS-K1T671M y similares) por protocolo ISAPI.
// Usa autenticación HTTP Digest, que es la que trae por defecto el equipo.
import http from 'node:http';
import crypto from 'node:crypto';

const md5 = (s) => crypto.createHash('md5').update(s).digest('hex');

function peticion({ host, port, method, path, headers = {}, body, timeout }) {
  return new Promise((resolve, reject) => {
    // insecureHTTPParser: algunos firmwares de Hikvision mandan encabezados que Node considera inválidos
    const req = http.request({ host, port, method, path, headers, timeout, agent: false, insecureHTTPParser: true }, (res) => {
      const chunks = [];
      res.on('error', (e) => reject(new Error(traducirError(e))));
      res.on('aborted', () => reject(new Error(traducirError({ code: 'ECONNRESET', message: 'aborted' }))));
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
    });
    req.on('timeout', () => req.destroy(new Error('Tiempo de espera agotado: el lector no respondió')));
    req.on('error', (e) => reject(new Error(traducirError(e))));
    if (body) req.write(body);
    req.end();
  });
}

function traducirError(e) {
  if (e.code === 'ECONNRESET' || e.code === 'EPIPE' || /socket hang up|ECONNRESET/i.test(e.message))
    return 'El lector cerró la conexión (ECONNRESET). Si pasa al "Probar conexión", revisa que el puerto sea el HTTP (normalmente 80), no el 8000';
  if (e.code === 'HPE_INVALID_CONSTANT' || /Parse Error/i.test(e.message)) return 'En ese puerto no responde la página web del lector. Usa el puerto HTTP (normalmente 80)';
  if (e.code === 'ECONNREFUSED') return 'Conexión rechazada: revisa la IP/puerto del lector';
  if (e.code === 'EHOSTUNREACH' || e.code === 'ENETUNREACH') return 'No se encuentra el lector en la red';
  if (e.code === 'ETIMEDOUT') return 'Tiempo de espera agotado: el lector no respondió';
  return e.message;
}

function parseAuth(h) {
  const o = {};
  h.replace(/(\w+)=(?:"([^"]*)"|([^,\s]*))/g, (_, k, v1, v2) => { o[k] = v1 ?? v2; });
  return o;
}

// ---------- Lector de multipart (eventos y fotos que manda el equipo) ----------
export function leerMultipart(buf, contentType = '') {
  const m = /boundary="?([^";]+)"?/i.exec(contentType);
  if (!m) return [];
  const sep = Buffer.from('--' + m[1]);
  const partes = [];
  let pos = buf.indexOf(sep);
  while (pos !== -1) {
    const inicio = pos + sep.length;
    if (buf.slice(inicio, inicio + 2).toString() === '--') break;
    const sig = buf.indexOf(sep, inicio);
    let parte = buf.slice(inicio, sig === -1 ? buf.length : sig);
    // quitar \r\n inicial y final
    if (parte.slice(0, 2).toString() === '\r\n') parte = parte.slice(2);
    if (parte.slice(-2).toString() === '\r\n') parte = parte.slice(0, -2);
    const finCab = parte.indexOf('\r\n\r\n');
    if (finCab !== -1) {
      const cab = parte.slice(0, finCab).toString();
      const tipo = (/content-type:\s*([^\r\n;]+)/i.exec(cab) || [])[1] || '';
      const nombre = (/name="([^"]+)"/i.exec(cab) || [])[1] || '';
      partes.push({ nombre, tipo: tipo.toLowerCase(), datos: parte.slice(finCab + 4) });
    }
    pos = sig;
  }
  return partes;
}

const xmlVal = (xml, tag) => (new RegExp(`<${tag}>([^<]*)</${tag}>`).exec(xml) || [])[1];

export class Hikvision {
  constructor({ ip, puerto = 80, usuario = 'admin', password = '', puerta = 1 }) {
    this.host = ip; this.port = Number(puerto) || 80;
    this.user = usuario; this.pass = password; this.puerta = Number(puerta) || 1;
    this.nc = 0;
  }

  // Arma el encabezado de autenticación Digest con el último "reto" que mandó el lector
  firmar(method, path) {
    const a = this.reto;
    if (!a) return null;
    if (a.basic) return 'Basic ' + Buffer.from(`${this.user}:${this.pass}`).toString('base64');
    const qop = a.qop ? (a.qop.split(',').map((x) => x.trim()).includes('auth') ? 'auth' : a.qop.split(',')[0].trim()) : null;
    const nc = (++this.nc).toString(16).padStart(8, '0');
    const cnonce = crypto.randomBytes(8).toString('hex');
    const ha1 = md5(`${this.user}:${a.realm}:${this.pass}`);
    const ha2 = md5(`${method}:${path}`);
    const resp = qop ? md5(`${ha1}:${a.nonce}:${nc}:${cnonce}:${qop}:${ha2}`) : md5(`${ha1}:${a.nonce}:${ha2}`);
    let auth = `Digest username="${this.user}", realm="${a.realm}", nonce="${a.nonce}", uri="${path}", algorithm=MD5, response="${resp}"`;
    if (qop) auth += `, qop=${qop}, nc=${nc}, cnonce="${cnonce}"`;
    if (a.opaque) auth += `, opaque="${a.opaque}"`;
    return auth;
  }

  guardarReto(r) {
    const h = r.headers['www-authenticate'];
    const www = (Array.isArray(h) ? h : [String(h || '')]).join(', ');
    const i = www.search(/digest\s/i); // algunos lectores mandan Basic y Digest juntos: se usa Digest
    this.reto = i >= 0 ? parseAuth(www.slice(i).split(/,\s*basic\s/i)[0]) : { basic: true };
    this.ultimoReto = www.slice(0, 200);
    this.nc = 0;
  }

  async request(method, path, { body, type, timeout = 10000 } = {}) {
    if (!this.host) throw new Error('No se ha configurado la IP del lector');
    const base = { host: this.host, port: this.port, method, path, timeout };
    const conCuerpo = () => {
      const h = {};
      if (body) { h['Content-Type'] = type || 'application/json'; h['Content-Length'] = Buffer.byteLength(body); }
      return h;
    };
    // 1) Si aún no tenemos el reto del lector, lo pedimos SIN mandar el cuerpo (algunos lectores
    //    cortan la conexión si reciben datos antes de autenticarse)
    if (!this.reto) {
      const r0 = await peticion({ ...base, timeout: 10000, headers: body ? { 'Content-Length': 0 } : {} });
      if (r0.status !== 401) {
        if (!body) return r0; // no pide contraseña
      } else this.guardarReto(r0);
    }
    // 2) Petición firmada con el cuerpo; si el reto ya caducó, se renueva y se intenta una vez más
    for (let intento = 0; intento < 2; intento++) {
      const headers = conCuerpo();
      const auth = this.firmar(method, path);
      if (auth) headers.Authorization = auth;
      const r = await peticion({ ...base, headers, body });
      if (r.status !== 401) return r;
      this.guardarReto(r);
    }
    console.log(`[lector] 401 en ${method} ${path.split('?')[0]} · reto: ${this.ultimoReto}`);
    throw new Error('Usuario o contraseña del lector incorrectos (o el equipo bloqueó el acceso por intentos fallidos)');
  }

  // Revisa la respuesta de ISAPI y lanza un error en español si falló
  revisar(r) {
    const txt = r.body.toString();
    let estado = null;
    if (txt.trim().startsWith('{')) {
      try {
        const j = JSON.parse(txt);
        if (j.statusCode !== undefined && j.statusCode !== 1 && j.statusCode !== 0) estado = j.subStatusCode || j.statusString || j.errorMsg;
        if (!estado && r.status >= 400) estado = j.subStatusCode || j.statusString || 'HTTP ' + r.status;
        if (!estado) return j;
      } catch { /* no era JSON */ }
    } else if (txt.includes('<ResponseStatus')) {
      const code = xmlVal(txt, 'statusCode');
      if (code && code !== '1') estado = xmlVal(txt, 'subStatusCode') || xmlVal(txt, 'statusString');
    }
    if (!estado && r.status >= 400) estado = 'HTTP ' + r.status;
    if (estado) { const e = new Error('El lector respondió: ' + estado); e.sub = estado; throw e; }
    return txt;
  }

  async json(method, path, obj, opts) {
    const r = await this.request(method, path, { body: obj ? JSON.stringify(obj) : undefined, type: 'application/json', ...opts });
    return this.revisar(r);
  }

  async info() {
    const r = await this.request('GET', '/ISAPI/System/deviceInfo');
    const t = this.revisar(r);
    return {
      modelo: xmlVal(t, 'model'), nombre: xmlVal(t, 'deviceName'),
      serie: xmlVal(t, 'serialNumber'), firmware: xmlVal(t, 'firmwareVersion'),
    };
  }

  // Alta o modificación de la persona. La vigencia (Valid) es lo que hace que el
  // lector NO abra la puerta cuando la membresía ya venció, aunque no haya red.
  async guardarUsuario({ empleado, nombre, inicio, fin }) {
    const user = {
      employeeNo: String(empleado),
      name: String(nombre).slice(0, 32),
      userType: 'normal',
      Valid: { enable: true, beginTime: inicio, endTime: fin, timeType: 'local' },
      doorRight: String(this.puerta),
      RightPlan: [{ doorNo: this.puerta, planTemplateNo: '1' }],
    };
    const busca = await this.json('POST', '/ISAPI/AccessControl/UserInfo/Search?format=json', {
      UserInfoSearchCond: { searchID: String(Date.now()), searchResultPosition: 0, maxResults: 1, EmployeeNoList: [{ employeeNo: String(empleado) }] },
    });
    const existe = (busca?.UserInfoSearch?.numOfMatches || 0) > 0;
    if (existe) return this.json('PUT', '/ISAPI/AccessControl/UserInfo/Modify?format=json', { UserInfo: user });
    return this.json('POST', '/ISAPI/AccessControl/UserInfo/Record?format=json', { UserInfo: user });
  }

  // Todas las personas registradas en el lector (de 30 en 30)
  async listarUsuarios() {
    const lista = [];
    const id = String(Date.now());
    for (let pos = 0; pos < 20000;) {
      const j = await this.json('POST', '/ISAPI/AccessControl/UserInfo/Search?format=json', {
        UserInfoSearchCond: { searchID: id, searchResultPosition: pos, maxResults: 30 },
      });
      const r = j?.UserInfoSearch || {};
      const pag = r.UserInfo || [];
      lista.push(...pag);
      pos += pag.length;
      if (!pag.length || r.responseStatusStrg !== 'MORE') break;
    }
    return lista;
  }

  // Todas las fotos de la biblioteca de rostros del lector: Map(número de persona → dirección de la foto).
  // Se pide de 30 en 30 en lugar de una por una (mucho más rápido).
  async listarRostros(avance) {
    const mapa = new Map();
    const id = String(Date.now());
    for (let pos = 0; pos < 20000;) {
      const j = await this.json('POST', '/ISAPI/Intelligent/FDLib/FDSearch?format=json', {
        searchID: id, searchResultPosition: pos, maxResults: 30, faceLibType: 'blackFD', FDID: '1',
      }, { timeout: 20000 });
      const pag = j?.MatchList || [];
      for (const m of pag) if (m.FPID && m.faceURL) mapa.set(String(m.FPID), m.faceURL);
      pos += pag.length;
      avance?.(mapa.size);
      if (!pag.length || (j.responseStatusStrg && j.responseStatusStrg !== 'MORE')) break;
      if (!j.responseStatusStrg && pag.length < 30) break;
    }
    return mapa;
  }

  // Dirección de la foto de UNA persona (cuando el lector no deja listar todas)
  async urlRostro(empleado) {
    const j = await this.json('POST', '/ISAPI/Intelligent/FDLib/FDSearch?format=json', {
      searchID: String(Date.now()), searchResultPosition: 0, maxResults: 1, faceLibType: 'blackFD', FDID: '1', FPID: String(empleado),
    });
    const url = j?.MatchList?.[0]?.faceURL || null;
    if (url || String(empleado) === String(Number(empleado)) || isNaN(Number(empleado))) return url;
    return this.urlRostro(String(Number(empleado)));
  }

  // Descarga una foto del lector a partir de su dirección
  async descargarImagen(url) {
    let ultimo = 'la foto no es JPG';
    // algunos firmwares necesitan la parte "@WEB..." de la dirección y otros no
    for (const intento of [...new Set([url, url.replace(/@.*$/, '')])]) {
      try {
        const u = new URL(intento.replace(/&amp;/g, '&'), `http://${this.host}:${this.port}`);
        const r = await this.request('GET', u.pathname + u.search, { timeout: 15000 });
        if (r.status === 200 && r.body.slice(0, 2).toString('hex') === 'ffd8') return r.body;
        ultimo = `HTTP ${r.status}`;
      } catch (e) { ultimo = e.message; }
    }
    throw new Error('No se pudo descargar la foto (' + ultimo + ') ' + String(url).slice(0, 120));
  }

  async descargarRostro(empleado) {
    const url = await this.urlRostro(empleado);
    return url ? this.descargarImagen(url) : null;
  }

  async borrarUsuario(empleado) {
    return this.json('PUT', '/ISAPI/AccessControl/UserInfo/Delete?format=json', {
      UserInfoDelCond: { EmployeeNoList: [{ employeeNo: String(empleado) }] },
    });
  }

  // Sube la foto del rostro (JPG, máximo ~200 KB) a la biblioteca de rostros del equipo
  async guardarRostro(empleado, jpg) {
    const multipart = (meta) => {
      const b = '----gym' + crypto.randomBytes(8).toString('hex');
      const body = Buffer.concat([
        Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="FaceDataRecord"\r\nContent-Type: application/json\r\n\r\n${JSON.stringify(meta)}\r\n`),
        Buffer.from(`--${b}\r\nContent-Disposition: form-data; name="img"; filename="rostro.jpg"\r\nContent-Type: image/jpeg\r\n\r\n`),
        jpg, Buffer.from(`\r\n--${b}--\r\n`),
      ]);
      return { body, type: `multipart/form-data; boundary=${b}` };
    };
    const meta = { faceLibType: 'blackFD', FDID: '1', FPID: String(empleado) };
    // Primero borramos el rostro anterior (si no existe, no importa)
    try {
      await this.json('PUT', '/ISAPI/Intelligent/FDLib/FDSearch/Delete?format=json&FDID=1&faceLibType=blackFD', { FPID: [{ value: String(empleado) }] });
    } catch { /* sin rostro previo */ }
    try {
      const mp = multipart(meta);
      return this.revisar(await this.request('POST', '/ISAPI/Intelligent/FDLib/FaceDataRecord?format=json', { ...mp, timeout: 20000 }));
    } catch (e) {
      // Algunos firmwares usan FDSetUp (alta o reemplazo)
      const mp = multipart(meta);
      try { return this.revisar(await this.request('PUT', '/ISAPI/Intelligent/FDLib/FDSetUp?format=json', { ...mp, timeout: 20000 })); }
      catch { throw traducirRostro(e); }
    }
  }

  // Pide al lector que tome la foto: el cliente se para frente al equipo
  // Pide al lector que tome la foto: el cliente se para frente al equipo.
  // Según el firmware, el lector regresa la foto directo (binary) o una dirección para descargarla (url).
  async capturarRostro() {
    const buscarJpg = (buf) => {
      const i = buf.indexOf(Buffer.from([0xff, 0xd8, 0xff]));
      if (i < 0) return null;
      const f = buf.lastIndexOf(Buffer.from([0xff, 0xd9]));
      return buf.slice(i, f > i ? f + 2 : buf.length);
    };
    const extraer = async (r) => {
      const ct = String(r.headers['content-type'] || '');
      if (ct.includes('multipart')) {
        const img = leerMultipart(r.body, ct).find((p) => p.tipo.includes('image') || p.datos.slice(0, 2).toString('hex') === 'ffd8');
        if (img) return img.datos;
      }
      const jpg = buscarJpg(r.body);
      if (jpg && jpg.length > 1000) return jpg;
      const txt = r.body.toString('latin1');
      const url = xmlVal(txt, 'faceDataUrl') || (/"faceDataUrl"\s*:\s*"([^"]+)"/.exec(txt) || [])[1];
      if (url) {
        const u = new URL(url.replace(/&amp;/g, '&'), `http://${this.host}:${this.port}`);
        const d = await this.request('GET', u.pathname + u.search, { timeout: 15000 });
        return buscarJpg(d.body);
      }
      return null;
    };
    const errores = [];
    // Qué acepta este lector (se guarda en el registro para soporte)
    let cap = '';
    try { cap = (await this.request('GET', '/ISAPI/AccessControl/CaptureFaceData/capabilities', { timeout: 8000 })).body.toString().replace(/\s+/g, ' ').slice(0, 1500); } catch (e) { cap = 'sin capacidades: ' + e.message; }
    console.log('[captura] capacidades: ' + cap);
    if (/contraseña/i.test(cap)) { const e = new Error('El lector rechazó el usuario o la contraseña. Revísalos en Configuración → Lector facial y presiona "Probar conexión".'); e.esLector = true; throw e; }
    const NS = 'version="2.0" xmlns="http://www.isapi.org/ver20/XMLSchema"';
    const soloUrl = /dataType[^<]*opt="url"|>url</.test(cap) && !/binary/.test(cap);
    const variantes = [
      ['url', `<CaptureFaceDataCond ${NS}><captureInfrared>false</captureInfrared><dataType>url</dataType></CaptureFaceDataCond>`, 'application/xml'],
      ['url sin infrarrojo', `<CaptureFaceDataCond ${NS}><dataType>url</dataType></CaptureFaceDataCond>`, 'application/xml'],
      ['url simple', `<?xml version="1.0" encoding="UTF-8"?><CaptureFaceDataCond><captureInfrared>false</captureInfrared><dataType>url</dataType></CaptureFaceDataCond>`, 'application/xml; charset=UTF-8'],
      ['json', JSON.stringify({ CaptureFaceDataCond: { captureInfrared: false, dataType: 'url' } }), 'application/json', '?format=json'],
      ...(soloUrl ? [] : [['binary', `<CaptureFaceDataCond ${NS}><captureInfrared>false</captureInfrared><dataType>binary</dataType></CaptureFaceDataCond>`, 'application/xml']]),
    ];
    for (const [tipo, xml, ctype, qs = ''] of variantes) {
      try {
        let r = await this.request('POST', '/ISAPI/AccessControl/CaptureFaceData' + qs, { body: xml, type: ctype, timeout: 45000 });
        console.log(`[captura] ${tipo}: HTTP ${r.status} ${String(r.headers['content-type'] || '')} ${r.body.length > 600 ? r.body.length + ' bytes' : r.body.toString().replace(/\s+/g, ' ')}`);
        if (r.status >= 400) this.revisar(r);
        let img = await extraer(r);
        // algunos lectores responden "en proceso" y hay que preguntar el avance
        for (let i = 0; !img && i < 25; i++) {
          await new Promise((ok) => setTimeout(ok, 1000));
          r = await this.request('GET', '/ISAPI/AccessControl/CaptureFaceData/Progress', { timeout: 10000 });
          if (r.status >= 400) this.revisar(r);
          img = await extraer(r);
        }
        if (img && img.length > 1000) return img;
        errores.push(`${tipo}: sin foto`);
      } catch (e) {
        errores.push(`${tipo}: ${e.message}`);
        console.log(`[captura] ${tipo}: ${e.message}`);
        // con contraseña rechazada no se insiste (el lector bloquea por intentos fallidos)
        if (/contraseña/i.test(e.message)) break;
        // otros errores que no sean de formato: no tiene caso probar otra variante
        if (!/badParameters|badXmlFormat|badJsonFormat|invalid|notSupport|HTTP 40[0-5]|methodNotAllowed/i.test(e.message)) break;
      }
    }
    const e = new Error('El lector no pudo tomar la foto. Pide al cliente que se pare de frente al lector (a unos 50 cm) e inténtalo otra vez; si sigue fallando usa "Tomar foto con cámara" o "Subir foto". Detalle técnico: ' + errores.join(' | '));
    e.esLector = true;
    throw e;
  }

  // Revisión rápida de lo que soporta el lector (para soporte técnico)
  async diagnostico() {
    const pruebas = [
      ['GET', '/ISAPI/System/deviceInfo'],
      ['GET', '/ISAPI/AccessControl/UserInfo/Count?format=json'],
      ['GET', '/ISAPI/Intelligent/FDLib/Count?format=json'],
      ['GET', '/ISAPI/AccessControl/UserInfo/capabilities?format=json'],
      ['GET', '/ISAPI/Intelligent/FDLib/capabilities?format=json'],
      ['GET', '/ISAPI/AccessControl/CaptureFaceData/capabilities'],
      ['GET', '/ISAPI/AccessControl/AcsEvent/capabilities?format=json'],
      ['GET', '/ISAPI/Event/notification/httpHosts'],
      ['GET', '/ISAPI/System/time'],
      ['POST', '/ISAPI/AccessControl/UserInfo/Search?format=json', { UserInfoSearchCond: { searchID: 'diag', searchResultPosition: 0, maxResults: 1 } }],
      ['POST', '/ISAPI/Intelligent/FDLib/FDSearch?format=json', { searchID: 'diag', searchResultPosition: 0, maxResults: 1, faceLibType: 'blackFD', FDID: '1' }],
    ];
    const lineas = [`Lector ${this.host}:${this.port} · usuario ${this.user}`];
    for (const [m, ruta, cuerpo] of pruebas) {
      try {
        const r = await this.request(m, ruta, { timeout: 8000, ...(cuerpo ? { body: JSON.stringify(cuerpo), type: 'application/json' } : {}) });
        lineas.push(`${r.status} ${m} ${ruta}\n    ${r.body.toString().replace(/\s+/g, ' ').slice(0, 400)}`);
      } catch (e) { lineas.push(`ERROR ${m} ${ruta}: ${e.message}`); }
    }
    return lineas.join('\n');
  }

  async abrirPuerta() {
    const r = await this.request('PUT', `/ISAPI/AccessControl/RemoteControl/door/${this.puerta}`, {
      body: '<RemoteControlDoor version="2.0" xmlns="http://www.isapi.org/ver20/XMLSchema"><cmd>open</cmd></RemoteControlDoor>',
      type: 'application/xml',
    });
    return this.revisar(r);
  }

  // Eventos de acceso (major 5 = control de acceso)
  async eventos(desde, hasta, posicion = 0) {
    const j = await this.json('POST', '/ISAPI/AccessControl/AcsEvent?format=json', {
      AcsEventCond: { searchID: String(Date.now()), searchResultPosition: posicion, maxResults: 30, major: 5, minor: 0, startTime: desde, endTime: hasta },
    });
    return j?.AcsEvent || {};
  }

  // Configura el lector para que mande cada evento al instante a este programa
  async configurarEnvioEventos(ipServidor, puertoServidor) {
    const xml = `<HttpHostNotificationList version="2.0" xmlns="http://www.isapi.org/ver20/XMLSchema"><HttpHostNotification><id>1</id><url>/hik/eventos</url><protocolType>HTTP</protocolType><parameterFormatType>JSON</parameterFormatType><addressingFormatType>ipaddress</addressingFormatType><ipAddress>${ipServidor}</ipAddress><portNo>${puertoServidor}</portNo><httpAuthenticationMethod>none</httpAuthenticationMethod></HttpHostNotification></HttpHostNotificationList>`;
    return this.revisar(await this.request('PUT', '/ISAPI/Event/notification/httpHosts', { body: xml, type: 'application/xml' }));
  }

  // Hora actual del lector, como la tiene él (ej. 2026-10-06T14:55:00-07:00)
  async horaLector() {
    const t = this.revisar(await this.request('GET', '/ISAPI/System/time', { timeout: 8000 }));
    return xmlVal(String(t), 'localTime');
  }

  // Pone la hora del lector igual a la de la computadora
  async sincronizarHora(iso) {
    const actual = this.revisar(await this.request('GET', '/ISAPI/System/time'));
    let xml = String(actual).replace(/<timeMode>[^<]*<\/timeMode>/, '<timeMode>manual</timeMode>');
    xml = xml.replace(/<localTime>[^<]*<\/localTime>/, `<localTime>${iso}</localTime>`);
    return this.revisar(await this.request('PUT', '/ISAPI/System/time', { body: xml, type: 'application/xml' }));
  }
}

function traducirRostro(e) {
  const s = String(e.sub || e.message);
  if (/faceQuality|lowScore|ModelingFailed|modeling/i.test(s)) return new Error('El lector no pudo reconocer bien la cara en la foto. Toma otra foto de frente, con buena luz y sin lentes oscuros ni gorra.');
  if (/size|picture/i.test(s)) return new Error('La foto es demasiado grande o tiene formato inválido.');
  return e;
}

// Códigos de evento del lector que significan "acceso permitido"
// 1 = tarjeta válida, 38 = huella válida, 75 = rostro verificado, otros = combinaciones
export const EVENTOS_OK = new Set([1, 38, 75, 77, 80, 104, 105, 106]);
// Rostro no reconocido / persona desconocida
export const EVENTOS_DESCONOCIDO = new Set([76, 112, 179]);
