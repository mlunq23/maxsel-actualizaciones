// Monitoreo en la nube (Firebase, proyecto maxsel-pos) — SOLO LECTURA para el dueño.
// Qué se sube (pensado para gastar lo mínimo y que quepan cientos de gimnasios en el plan gratis):
//  - gyms/{uid}.hoy y gyms/{uid}/dias/{AAAA-MM-DD}: totales del día. Cada 4 horas y al cerrar el día (23:57).
//  - Cuando el dueño presiona "Actualizar": suena el "timbre" (Realtime Database, timbre/{uid}) y la computadora
//    sube los totales del momento y el reporte pedido (solicitudes/{id}).
// Todo funciona por REST (sin librerías). Si no hay internet, el gimnasio sigue trabajando normal.
import zlib from 'node:zlib';

const FB = {
  apiKey: 'AIzaSyC5z267XDrGrQtndJwbyHZu5SkGNy_EnQY',
  proyecto: 'maxsel-pos',
};
const URL_AUTH = process.env.MAXSEL_FB_AUTH || 'https://identitytoolkit.googleapis.com';
const URL_TOKEN = process.env.MAXSEL_FB_TOKEN || 'https://securetoken.googleapis.com';
const URL_FS = process.env.MAXSEL_FS || 'https://firestore.googleapis.com';
const RAIZ = `projects/${FB.proyecto}/databases/(default)/documents`;
export const URL_PAGINA = 'https://maxsel-pos.web.app/gym';

const PARTE = 700000;               // caracteres por documento (Firestore permite ~1 MB)
const URLS_PERMITIDAS = [/^\/api\/movil\/resumen(\?|$)/, /^\/api\/reportes\/excel\?/];

// ---------- Conversión al formato de Firestore ----------
function aValor(v) {
  if (v === null || v === undefined) return { nullValue: null };
  if (typeof v === 'boolean') return { booleanValue: v };
  if (typeof v === 'number') return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
  if (typeof v === 'string') return { stringValue: v };
  if (v instanceof Date) return { timestampValue: v.toISOString() };
  if (Array.isArray(v)) return { arrayValue: { values: v.map(aValor) } };
  return { mapValue: { fields: aCampos(v) } };
}
const aCampos = (o) => Object.fromEntries(Object.entries(o).filter(([, x]) => x !== undefined).map(([k, x]) => [k, aValor(x)]));
function deValor(v) {
  if (!v) return null;
  if ('nullValue' in v) return null;
  if ('booleanValue' in v) return v.booleanValue;
  if ('integerValue' in v) return Number(v.integerValue);
  if ('doubleValue' in v) return v.doubleValue;
  if ('stringValue' in v) return v.stringValue;
  if ('timestampValue' in v) return v.timestampValue;
  if ('arrayValue' in v) return (v.arrayValue.values || []).map(deValor);
  if ('mapValue' in v) return deCampos(v.mapValue.fields || {});
  return null;
}
const deCampos = (f) => Object.fromEntries(Object.entries(f || {}).map(([k, x]) => [k, deValor(x)]));

class ErrorNube extends Error { constructor(msg, codigo) { super(msg); this.codigo = codigo; } }

async function pedir(url, opciones = {}, tiempo = 20000) {
  const c = new AbortController(); const t = setTimeout(() => c.abort(), tiempo);
  try {
    const r = await fetch(url, { ...opciones, signal: c.signal });
    const txt = await r.text();
    let j = null; try { j = txt ? JSON.parse(txt) : null; } catch { /* no JSON */ }
    if (!r.ok) {
      const m = j?.error?.message || j?.[0]?.error?.message || `HTTP ${r.status}`;
      throw new ErrorNube(m, r.status);
    }
    return j;
  } catch (e) {
    if (e instanceof ErrorNube) throw e;
    throw new ErrorNube(e.name === 'AbortError' ? 'Sin respuesta de internet' : 'Sin conexión a internet', 0);
  } finally { clearTimeout(t); }
}

// ---------- Inicio de sesión (Firebase Auth) ----------
const MENSAJES_AUTH = {
  EMAIL_NOT_FOUND: 'No existe esa cuenta. Pídele a Maxsel que dé de alta el gimnasio en la nube.',
  INVALID_PASSWORD: 'Contraseña incorrecta.', INVALID_LOGIN_CREDENTIALS: 'Correo o contraseña incorrectos.',
  USER_DISABLED: 'La cuenta está desactivada. Comunícate con Maxsel.', TOO_MANY_ATTEMPTS_TRY_LATER: 'Demasiados intentos. Espera unos minutos.',
  INVALID_EMAIL: 'El correo no es válido.', TOKEN_EXPIRED: 'La sesión de la nube caducó, vuelve a conectar.', INVALID_REFRESH_TOKEN: 'La sesión de la nube caducó, vuelve a conectar.',
};
const msgAuth = (e) => MENSAJES_AUTH[String(e.message).split(' ')[0]] || e.message;

export async function iniciarSesion(email, password) {
  try {
    const j = await pedir(`${URL_AUTH}/v1/accounts:signInWithPassword?key=${FB.apiKey}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password, returnSecureToken: true }),
    });
    return { uid: j.localId, refresh: j.refreshToken, token: j.idToken, vence: Date.now() + (Number(j.expiresIn) - 120) * 1000, email: j.email };
  } catch (e) { throw new ErrorNube(msgAuth(e), e.codigo); }
}

// ---------- Cliente de Firestore ----------
export class Nube {
  constructor({ uid, refresh }) { this.uid = uid; this.refresh = refresh; this.token = null; this.vence = 0; }
  async tokenVigente() {
    if (this.token && Date.now() < this.vence) return this.token;
    try {
      const j = await pedir(`${URL_TOKEN}/v1/token?key=${FB.apiKey}`, {
        method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `grant_type=refresh_token&refresh_token=${encodeURIComponent(this.refresh)}`,
      });
      this.token = j.id_token; this.refresh = j.refresh_token || this.refresh; this.vence = Date.now() + (Number(j.expires_in) - 120) * 1000;
      return this.token;
    } catch (e) { throw new ErrorNube(msgAuth(e), e.codigo === 400 ? 401 : e.codigo); }
  }
  async api(ruta, opciones = {}) {
    const tk = await this.tokenVigente();
    return pedir(`${URL_FS}/v1/${ruta}`, { ...opciones, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tk}`, ...(opciones.headers || {}) } });
  }
  doc(ruta) { return `${RAIZ}/gyms/${this.uid}${ruta ? '/' + ruta : ''}`; }
  async leer(ruta) {
    try { const d = await this.api(this.doc(ruta)); return { id: d.name.split('/').pop(), ...deCampos(d.fields) }; }
    catch (e) { if (e.codigo === 404) return null; throw e; }
  }
  // Escritura parcial (solo los campos indicados) + campos con la hora del servidor
  escritura(ruta, datos, { sello = [], completo = false } = {}) {
    const w = { update: { name: this.doc(ruta), fields: aCampos(datos) } };
    if (!completo) w.updateMask = { fieldPaths: Object.keys(datos) };
    if (sello.length) w.updateTransforms = sello.map((fieldPath) => ({ fieldPath, setToServerValue: 'REQUEST_TIME' }));
    return w;
  }
  borrado(ruta) { return { delete: this.doc(ruta) }; }
  async confirmar(writes) { if (writes.length) await this.api(`${RAIZ}:commit`, { method: 'POST', body: JSON.stringify({ writes }) }); }
  async consultar(coleccion, filtro, limite = 20) {
    const q = { structuredQuery: { from: [{ collectionId: coleccion }], limit: limite } };
    if (filtro) q.structuredQuery.where = { fieldFilter: { field: { fieldPath: filtro[0] }, op: filtro[1], value: aValor(filtro[2]) } };
    const r = await this.api(`${this.doc()}:runQuery`, { method: 'POST', body: JSON.stringify(q) });
    return (r || []).filter((x) => x.document).map((x) => ({ id: x.document.name.split('/').pop(), ...deCampos(x.document.fields) }));
  }
}

// ---------- Timbre: escucha en tiempo real cuando el dueño presiona "Actualizar" ----------
// Usa Realtime Database por REST (EventSource): la conexión queda abierta y NO cuesta lecturas.
const URL_RTDB = process.env.MAXSEL_RTDB || 'https://maxsel-pos-default-rtdb.firebaseio.com';
function crearTimbre({ uid, token, alSonar, alEstado, log }) {
  let vivo = true, control = null, espera = 5000, renovar = null;
  async function conectar() {
    if (!vivo) return;
    clearTimeout(renovar);
    let motivo = '';
    try {
      const tk = await token();
      control = new AbortController();
      const r = await fetch(`${URL_RTDB}/timbre/${uid}.json?auth=${encodeURIComponent(tk)}`, { headers: { Accept: 'text/event-stream' }, signal: control.signal });
      if (!r.ok) throw new ErrorNube(r.status === 401 || r.status === 403 ? 'sin permiso' : r.status === 404 ? 'no existe' : `HTTP ${r.status}`, r.status);
      alEstado(true); espera = 5000;
      // El token de acceso dura 1 hora: se vuelve a conectar antes de que caduque
      renovar = setTimeout(() => { motivo = 'renovar'; control?.abort(); }, 50 * 60000); renovar.unref?.();
      const lector = r.body.getReader(), dec = new TextDecoder();
      let buf = '';
      for (;;) {
        const { value, done } = await lector.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf('\n\n')) >= 0) {
          const bloque = buf.slice(0, i); buf = buf.slice(i + 2);
          const ev = /^event: *(.*)$/m.exec(bloque)?.[1]?.trim(), dat = /^data: *(.*)$/m.exec(bloque)?.[1];
          if (ev === 'put' || ev === 'patch') { try { const j = JSON.parse(dat); alSonar(j.path === '/' ? j.data : null); } catch { /* ignora */ } }
          else if (ev === 'auth_revoked') { motivo = 'renovar'; control.abort(); }
          else if (ev === 'cancel') throw new ErrorNube('sin permiso', 403);
        }
      }
    } catch (e) {
      if (motivo !== 'renovar') {
        alEstado(false);
        if (vivo && e.name !== 'AbortError') log(`[nube] timbre: ${e.message} (se reintenta)`);
        espera = Math.min(espera * 2, e.codigo === 404 || e.codigo === 403 ? 30 * 60000 : 5 * 60000);
      }
    }
    clearTimeout(renovar);
    if (!vivo) return;
    const t = setTimeout(conectar, motivo === 'renovar' ? 100 : espera); t.unref?.();
  }
  conectar();
  return { detener() { vivo = false; clearTimeout(renovar); control?.abort(); } };
}

// ---------- Ciclo de sincronización ----------
// Ahorro de la nube: los totales se suben cada 4 horas (y al cerrar el día).
// Lo demás SOLO cuando el dueño presiona "Actualizar": suena el timbre y la computadora contesta en segundos.
// Si el timbre no funciona, la computadora revisa si hay pedidos cada 10 minutos.
const CADA_SUBIDA = 4 * 3600000, CADA_REVISION_SIN_TIMBRE = 10 * 60000, REINTENTO = 5 * 60000;
// datos: { cfg, setCfg, resumenHoy(), ejecutar(url) -> objeto, version, equipo, log }
export function crearSincronizador(datos) {
  const { cfg, setCfg, log = () => {} } = datos;
  const estado = { conectado: false, error: '', ultimaSubida: null, ultimoContacto: null, timbre: false, solicitudesAtendidas: 0, cadaHoras: CADA_SUBIDA / 3600000 };
  let nube = null, reloj = null, timbre = null, corriendo = false, otraVez = false, ultimoCompleto = 0, ultimaRevision = 0, cierreHecho = '', ultimoPedido = '', ultimoTimbre = '', ultimaLimpieza = 0, ultimoErrorLog = '';

  const activo = () => cfg('nube_activo') === '1' && cfg('nube_uid') && cfg('nube_refresh');
  const cliente = () => {
    if (!nube || nube.uid !== cfg('nube_uid')) nube = new Nube({ uid: cfg('nube_uid'), refresh: cfg('nube_refresh') });
    return nube;
  };
  const guardarRefresh = () => { if (nube && nube.refresh && nube.refresh !== cfg('nube_refresh')) setCfg('nube_refresh', nube.refresh); };
  const fechaLocal = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

  // Totales de hoy + historial del día (2 escrituras)
  async function subirHoy(n) {
    const r = datos.resumenHoy();
    await n.confirmar([
      n.escritura('', { hoy: r, app: `Maxsel Gimnasios ${datos.version}`, pc: { equipo: datos.equipo || '' } }, { sello: ['lastSeen'] }),
      n.escritura(`dias/${r.fecha}`, r, { completo: true, sello: ['subido'] }),
    ]);
    estado.ultimaSubida = new Date().toISOString();
  }

  async function atenderSolicitudes(n) {
    const pendientes = await n.consultar('solicitudes', ['estado', 'EQUAL', 'pendiente'], 10);
    for (const s of pendientes) {
      const url = String(s.url || '');
      let resultado, error = '';
      try {
        if (!URLS_PERMITIDAS.some((re) => re.test(url))) throw new Error('Reporte no permitido');
        resultado = await datos.ejecutar(url);
      } catch (e) { error = e.message || String(e); }
      if (error) {
        await n.confirmar([n.escritura(`solicitudes/${s.id}`, { estado: 'error', error }, { sello: ['respondido'] })]);
        continue;
      }
      const comprimido = zlib.gzipSync(Buffer.from(JSON.stringify(resultado))).toString('base64');
      const partes = Math.max(1, Math.ceil(comprimido.length / PARTE));
      const writes = [];
      for (let i = 0; i < partes; i++) writes.push(n.escritura(`solicitudes/${s.id}/partes/${i}`, { d: comprimido.slice(i * PARTE, (i + 1) * PARTE) }, { completo: true }));
      // Firestore acepta ~10 MB por envío: se manda por grupos
      for (let i = 0; i < writes.length; i += 8) await n.confirmar(writes.slice(i, i + 8));
      await n.confirmar([n.escritura(`solicitudes/${s.id}`, { estado: 'listo', partes, comp: 'gzip', bytes: comprimido.length }, { sello: ['respondido'] })]);
      estado.solicitudesAtendidas++;
    }
  }

  // Borra las solicitudes de reportes de más de 2 días (para no llenar la nube)
  async function limpiar(n) {
    const viejas = await n.consultar('solicitudes', ['creadoMs', 'LESS_THAN', Date.now() - 2 * 86400000], 20);
    const writes = [];
    for (const s of viejas) {
      for (let i = 0; i < (s.partes || 0); i++) writes.push(n.borrado(`solicitudes/${s.id}/partes/${i}`));
      writes.push(n.borrado(`solicitudes/${s.id}`));
    }
    for (let i = 0; i < writes.length; i += 400) await n.confirmar(writes.slice(i, i + 400));
  }

  function fallo(e) {
    estado.conectado = false; estado.error = e.message;
    if (e.codigo === 401) { setCfg('nube_activo', '0'); estado.error = e.message + ' (vuelve a conectar en Configuración).'; apagarTimbre(); }
    if (ultimoErrorLog !== e.message) { log('[nube] ' + e.message); ultimoErrorLog = e.message; }
  }
  const bien = () => { estado.conectado = true; estado.error = ''; estado.ultimoContacto = new Date().toISOString(); ultimoErrorLog = ''; };

  // tipo: 'completo' (revisa licencia y sube), 'revision' (sin timbre: solo mira si hay pedido), 'timbre' (el dueño presionó Actualizar)
  async function trabajar(tipo) {
    if (!activo()) return;
    if (corriendo) { if (tipo === 'timbre') otraVez = true; return; }
    corriendo = true;
    try {
      const n = cliente();
      if (tipo === 'timbre') {
        await subirHoy(n);
        await atenderSolicitudes(n);
      } else {
        const gym = await n.leer('');
        guardarRefresh();
        if (!gym) throw new ErrorNube('Este gimnasio no está dado de alta en la nube. Pídele a Maxsel que lo active.', 404);
        estado.nombre = gym.name || '';
        const lic = gym.license || {};
        estado.licencia = lic;
        const licOk = lic.status === 'active' && (!lic.untilMs || lic.untilMs > Date.now());
        if (!licOk) { apagarTimbre(); throw new ErrorNube(lic.status !== 'active' ? 'El monitoreo en la nube está suspendido. Comunícate con Maxsel.' : 'La licencia del monitoreo en la nube venció. Comunícate con Maxsel para renovarla.', 403); }
        const pedido = gym.pedido?.id || '';
        const hayPedido = pedido && pedido !== ultimoPedido;
        if (tipo === 'completo' || hayPedido) await subirHoy(n);
        if (hayPedido) { await atenderSolicitudes(n); ultimoPedido = pedido; }
        if (tipo === 'completo') {
          ultimoCompleto = Date.now();
          if (Date.now() - ultimaLimpieza > 24 * 3600000) { ultimaLimpieza = Date.now(); limpiar(n).catch(() => {}); }
          encenderTimbre();
        }
        ultimaRevision = Date.now();
      }
      guardarRefresh();
      bien();
    } catch (e) {
      fallo(e);
      if (tipo === 'completo') ultimoCompleto = Date.now() - CADA_SUBIDA + REINTENTO;   // reintenta en 5 min
    } finally {
      corriendo = false;
      if (otraVez) { otraVez = false; setTimeout(() => trabajar('timbre'), 500).unref?.(); }
    }
  }

  function encenderTimbre() {
    if (timbre || !activo()) return;
    const n = cliente();
    timbre = crearTimbre({
      uid: n.uid, log,
      token: () => n.tokenVigente(),
      alEstado: (ok) => { estado.timbre = ok; },
      alSonar: (d) => {
        if (!d || !d.id || d.id === ultimoTimbre) return;
        const primero = !ultimoTimbre; ultimoTimbre = d.id;
        // Al conectar llega el último timbre guardado: solo se atiende si es reciente
        if (primero && Date.now() - Number(d.ts || 0) > 5 * 60000) return;
        trabajar('timbre');
      },
    });
  }
  function apagarTimbre() { timbre?.detener(); timbre = null; estado.timbre = false; }

  // Reloj local cada 30 s (no usa internet): decide cuándo subir
  function tic() {
    if (!activo()) return;
    const ahora = Date.now(), d = new Date(), hoy = fechaLocal();
    if (ahora - ultimoCompleto >= CADA_SUBIDA) return trabajar('completo');
    // Cierre del día: a las 23:57 se suben los totales finales
    if (d.getHours() === 23 && d.getMinutes() >= 57 && cierreHecho !== hoy) { cierreHecho = hoy; return trabajar('completo'); }
    if (!estado.timbre && ahora - ultimaRevision >= CADA_REVISION_SIN_TIMBRE) return trabajar('revision');
  }
  function arrancarReloj() { clearInterval(reloj); reloj = setInterval(tic, 30000); reloj.unref?.(); }

  return {
    estado,
    iniciar() { if (activo()) { ultimoCompleto = 0; arrancarReloj(); setTimeout(() => trabajar('completo'), 3000).unref?.(); } },
    ahora() { return trabajar('completo'); },
    detener() { clearInterval(reloj); apagarTimbre(); estado.conectado = false; nube = null; },
    reiniciar() {
      apagarTimbre(); nube = null; ultimoPedido = ''; ultimoTimbre = ''; estado.error = ''; ultimoCompleto = 0;
      arrancarReloj(); setTimeout(() => trabajar('completo'), 500).unref?.();
    },
  };
}
