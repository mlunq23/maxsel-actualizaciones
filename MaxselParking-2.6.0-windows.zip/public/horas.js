'use strict';
// Maxsel 2026: en algunas computadoras Windows el navegador escribe las 12 del día como "00:30 p.m.".
// Aquí se fuerza el reloj de 12 horas (12:30 p.m.) en TODAS las horas del sistema: tickets, reportes, cortes y pantallas.
(() => {
  const P = Date.prototype;
  const conHora = (o) => !o || 'hour' in o || 'timeStyle' in o;
  const opc = (o) => {
    if (o && o.hour12 === false) return o; // reloj de 24 horas a propósito
    const r = { ...(o || {}) }; delete r.hour12; r.hourCycle = 'h12'; return r;
  };
  // Si aun así sale "00:xx" o "0:xx" con a.m./p.m., se corrige a 12:xx
  const doce = (s) => String(s).replace(/(^|[^\d])0?0:(\d\d)(?=[^]*?[ap]\.?\s?m)/gi, '$112:$2');
  for (const k of ['toLocaleTimeString', 'toLocaleString']) {
    const f = P[k];
    P[k] = function (l, o) {
      if (!conHora(o) && k === 'toLocaleString' && o) return f.call(this, l, o);
      return doce(f.call(this, l, opc(o)));
    };
  }
  if (window.Intl && Intl.DateTimeFormat) {
    const DTF = Intl.DateTimeFormat;
    const N = function (l, o) { return new DTF(l, o && 'hour' in o ? opc(o) : o); };
    N.prototype = DTF.prototype; N.supportedLocalesOf = DTF.supportedLocalesOf;
    try { Intl.DateTimeFormat = N; } catch { /* sin cambio */ }
  }
})();
