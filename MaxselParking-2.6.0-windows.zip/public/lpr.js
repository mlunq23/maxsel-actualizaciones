'use strict';
// Maxsel Parking 2.5 — LECTURA DE PLACAS (pre-ingreso)
// La placa leída por la cámara aparece sola en la caja; con F2 la entrada se registra con esa placa.
(() => { const st = document.createElement('style'); st.textContent = `
.lpr-card{border:2px solid var(--pri,#2563eb);background:linear-gradient(180deg,#eef4ff,#fff)}
.lpr-placa{font:800 2.4rem/1 ui-monospace,Consolas,monospace;letter-spacing:.12em;background:#fff;border:3px solid #111;border-radius:10px;padding:.35rem .8rem;display:inline-block;margin:.3rem 0}
.lpr-row{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center}
.lpr-mini{display:flex;gap:.4rem;flex-wrap:wrap;margin-top:.5rem}
.lpr-mini button{font-family:ui-monospace,Consolas,monospace;font-weight:700}
.lpr-nada{color:var(--muted,#64748b);font-size:.9rem}
@keyframes lprIn{from{transform:scale(.96);opacity:.4}to{transform:none;opacity:1}}.lpr-nueva{animation:lprIn .35s ease}`; document.head.appendChild(st); })();

const LPR = { lecturas: [], ultimoId: 0, timer: null };
const lprActivo = () => S.me && S.me.config && S.me.config.lpr_modo && S.me.config.lpr_modo !== 'ninguno' && (can('ingreso_rapido') || can('ingreso_manual'));
const banderaLPR = (r) => (/^mx/i.test(r || '') ? '🇲🇽' : /^us/i.test(r || '') ? '🇺🇸' : '');
function lprBip() { try { const a = lprBip.a || (lprBip.a = new AudioContext()), o = a.createOscillator(), g = a.createGain(); g.gain.value = 0.07; o.frequency.value = 1320; o.connect(g); g.connect(a.destination); o.start(); o.stop(a.currentTime + 0.12); } catch { /* sin sonido */ } }

async function lprRevisar() {
  if (!lprActivo() || S.view !== 'caja' || document.hidden) return;
  try {
    const r = await api('/api/lpr/pendientes');
    LPR.lecturas = r.lecturas || [];
    const top = LPR.lecturas[0];
    if (top && top.id > LPR.ultimoId) { LPR.ultimoId = top.id; lprBip(); }
    lprPintar();
  } catch { /* sin red */ }
}
setInterval(lprRevisar, 2000);

function lprPintar() {
  if (S.view !== 'caja') return;
  let box = $('#lprBox');
  if (!lprActivo()) { box && box.closest('.card').remove(); return; }
  if (!box) {
    const col = $('#camBox')?.closest('.card')?.parentElement || $('.caja > div:last-child');
    if (!col) return;
    col.insertAdjacentHTML('afterbegin', '<div class="card lpr-card"><h3 style="margin-top:0">🔎 Placa detectada</h3><div id="lprBox"></div></div>');
    box = $('#lprBox');
  }
  const [l, ...otras] = LPR.lecturas, nube = S.me.config.lpr_modo === 'nube';
  const html = l ? `<div class="lpr-nueva" data-id="${l.id}"><div class="lpr-placa">${esc(l.placa)}</div> <span style="font-size:1.6rem">${banderaLPR(l.region)}</span>
      <div class="small muted">${l.fuente === 'camara' ? 'Cámara de placas' : 'Leída de la foto'} · ${hora12(l.fecha)}${l.confianza && l.confianza < 1 ? ` · ${Math.round(l.confianza * 100)}% seguro` : ''}</div>
      ${l.cliente ? `<div class="alert ok small" style="margin:.4rem 0">⭐ ${esc(l.cliente)} (${esc(l.tipo_cliente || '')})</div>` : ''}
      ${l.candidatos && l.candidatos.length > 1 ? `<div class="small muted">¿O es? ${l.candidatos.slice(1).map((c) => `<a href="#" onclick="lprUsarOtra(event,'${esc(c)}')">${esc(c)}</a>`).join(' · ')}</div>` : ''}
      <div class="lpr-row" style="margin-top:.5rem">${can('ingreso_rapido') ? '<button class="btn acc" onclick="lprEntrada()">⚡ Dar entrada <span class="kbd">F2</span></button>' : ''}
        ${can('ingreso_manual') ? '<button class="btn" onclick="lprManual()">📝 Manual</button>' : ''}<button class="btn sm ghost" onclick="lprDescartar()">Ignorar</button></div></div>
      ${otras.length ? `<div class="lpr-mini"><span class="small muted">También:</span>${otras.map((o) => `<button class="btn sm" onclick="lprSubir(${o.id})">${esc(o.placa)}</button>`).join('')}</div>` : ''}`
    : `<p class="lpr-nada">${S.me.config.lpr_modo === 'camara' ? 'Esperando placas de la cámara…' : 'Al dar entrada sin placas, el sistema las lee de la foto de la cámara.'}</p>`;
  box.innerHTML = html + (nube && (can('ingreso_rapido') || can('ingreso_manual')) ? '<div style="margin-top:.6rem"><button class="btn sm" onclick="lprLeerAhora()">📷 Leer placa ahora</button></div>' : '');
}
function lprSubir(id) { const i = LPR.lecturas.findIndex((x) => x.id === id); if (i > 0) LPR.lecturas.unshift(...LPR.lecturas.splice(i, 1)); lprPintar(); }
function lprUsarOtra(e, placa) { e.preventDefault(); if (LPR.lecturas[0]) LPR.lecturas[0].placa = placa; lprPintar(); }
async function lprDescartar() { const l = LPR.lecturas.shift(); if (l) post(`/api/lpr/${l.id}/descartar`).catch(() => {}); lprPintar(); focusScan(); }
function lprEntrada() { ingresoRapido(); }
function lprManual() { const l = LPR.lecturas[0]; ingresoManual(l ? { placas: l.placa } : {}); }
async function lprLeerAhora() {
  const b = $('#lprBox button[onclick="lprLeerAhora()"]'); if (b) { b.disabled = true; b.textContent = 'Leyendo…'; }
  try {
    const r = await post('/api/lpr/leer');
    if (!r.ok) return toast(r.error, 'bad');
    if (!r.placa) { toast('No se encontró ninguna placa en la foto', 'warn'); return; }
    toast('Placa leída: ' + r.placa, 'ok'); await lprRevisar();
  } catch (e) { errToast(e); } finally { lprPintar(); }
}
// F2 / Ingreso rápido: si hay una placa detectada, la entrada se registra con ella
{
  const _re = registrarEntrada;
  registrarEntrada = function (body, m) {
    const l = LPR.lecturas[0];
    if (lprActivo() && body && body.modo === 'rapido' && !body.placas && l) {
      body = { ...body, placas: l.placa, lpr_id: l.id };
      LPR.lecturas.shift(); setTimeout(lprPintar, 50);
    }
    return _re(body, m);
  };
}
// Caja: el cuadro de la placa aparece arriba de la cámara
{
  const _vc = VISTAS.caja.render;
  VISTAS.caja.render = function (main) { const r = _vc(main); LPR.lecturas = []; lprPintar(); lprRevisar(); return r; };
}
// Ingreso manual: botón para leer la placa con la cámara
{
  const _im = ingresoManual;
  ingresoManual = async function (pre = {}) {
    const r = await _im(pre);
    if (lprActivo() && S.me.config.lpr_modo === 'nube') {
      for (const id of ['nplacas', 'mplacas']) {
        const inp = document.getElementById(id); if (!inp || inp.dataset.lpr) continue;
        inp.dataset.lpr = '1';
        const b = document.createElement('button'); b.type = 'button'; b.className = 'btn sm'; b.textContent = '📷 Leer placa'; b.style.marginTop = '.3rem';
        b.onclick = async () => {
          b.disabled = true; b.textContent = 'Leyendo…';
          try { const x = await post('/api/lpr/leer'); if (!x.ok) toast(x.error, 'bad'); else if (!x.placa) toast('No se encontró placa en la foto', 'warn'); else { inp.value = x.placa; inp.dispatchEvent(new Event('input')); toast('Placa leída: ' + x.placa, 'ok'); } }
          catch (e) { errToast(e); } finally { b.disabled = false; b.textContent = '📷 Leer placa'; }
        };
        inp.closest('label').appendChild(b);
      }
    }
    return r;
  };
}
// Configuración → Lectura de placas
{
  const _cfg = VISTAS.config.render;
  VISTAS.config.render = async function (main) {
    const r = await _cfg(main);
    const c = S.me.config, cam = $('#bCam')?.closest('.card'); if (!cam) return r;
    cam.querySelectorAll('p').forEach((p) => { if (/No lee placas/.test(p.textContent)) p.innerHTML = p.innerHTML.replace(/No lee placas: sólo guarda la foto\./, 'Para leer las placas sola, vea <b>Lectura de placas</b> abajo.'); });
    const sel = (v, t) => `<option value="${v}" ${c.lpr_modo === v ? 'selected' : ''}>${t}</option>`;
    cam.insertAdjacentHTML('afterend', `<div class="card"><h3>🔎 Lectura de placas (placas mexicanas y americanas)</h3>
      <p class="muted small" style="margin-top:0">La placa leída llega a la caja como <b>pre-ingreso</b>: el cajero solo presiona <span class="kbd">F2</span> y la entrada se registra con esa placa (y si es mesero o pensionado, con su tarifa).</p>
      <div class="grid g3"><label class="f">¿Cómo se leen las placas?<select name="lpr_modo" id="lprModo">${sel('ninguno', 'No leer placas')}${sel('nube', 'Con la foto de mi cámara IP (servicio Plate Recognizer, requiere internet)')}${sel('camara', 'Mi cámara ya lee placas (Hikvision ANPR, Dahua LPR…)')}</select></label>
        <label class="f lprN">Token de Plate Recognizer<input name="lpr_token" type="password" value="${esc(c.lpr_token || '')}" autocomplete="off"></label>
        <label class="f lprN">Regiones (mx = México, us-ca = California, us-az = Arizona…)<input name="lpr_regiones" value="${esc(c.lpr_regiones || 'mx,us-ca')}"></label>
        <label class="f lprN">Confianza mínima para guardar sola la placa (0 a 1)<input name="lpr_min_confianza" type="number" min="0" max="1" step="0.05" value="${esc(c.lpr_min_confianza ?? 0.5)}"></label></div>
      <label class="check lprN" style="margin-top:.5rem"><input type="checkbox" name="lpr_al_ingreso" ${c.lpr_al_ingreso ? 'checked' : ''}> Si dan entrada sin placas, leerlas de la foto de entrada y guardarlas en el boleto</label>
      <div class="paybox lprN small" style="margin-top:.5rem">Cree una cuenta en <b>platerecognizer.com</b> (Snapshot Cloud; tiene prueba gratis) y copie aquí su <b>API Token</b>. Cada foto leída cuenta como una lectura de su plan. Necesita la cámara IP configurada arriba; para mejores resultados apunte la cámara a la placa, a 3–6 m y sin contraluz.</div>
      <div class="paybox lprC small" style="margin-top:.5rem"><b>En la cámara</b> (Evento de placa / ANPR → "Notificar centro de vigilancia" / "HTTP Listening" o "Servidor de plataforma"), ponga esta dirección:
        <div id="lprUrls" class="mono" style="margin:.4rem 0;word-break:break-all">Cargando…</div>
        También sirve para cualquier equipo que mande <span class="mono">…/api/lpr/evento?clave=…&amp;placa=ABC123</span>. <button type="button" class="btn sm" id="lprClave">Cambiar la clave</button></div>
      <div class="row" style="margin-top:.6rem"><button type="button" class="btn lprN" id="lprProbar">🔎 Probar lectura de placa</button><span class="muted small" id="lprRes"></span></div><div id="lprPrev" style="margin-top:.5rem"></div>
      <div id="lprUlt" style="margin-top:.5rem"></div></div>`);
    const ver = () => { const m = $('#lprModo').value; $$('.lprN').forEach((e) => (e.style.display = m === 'nube' ? '' : 'none')); $$('.lprC').forEach((e) => (e.style.display = m === 'camara' ? '' : 'none')); };
    $('#lprModo').onchange = ver; ver();
    const cargar = () => api('/api/lpr/info').then((i) => {
      $('#lprUrls').innerHTML = i.urls.map((u) => esc(u)).join('<br>') || 'Conecte la computadora a la red para ver la dirección.';
      $('#lprUlt').innerHTML = i.ultimas.length ? `<details><summary class="small">Últimas placas leídas (${i.ultimas.length})</summary><div class="tbl-wrap"><table><thead><tr><th>Hora</th><th>Placa</th><th>Origen</th><th>Boleto</th></tr></thead><tbody>${i.ultimas.map((l) => `<tr><td>${fdt(l.fecha)}</td><td class="mono"><b>${esc(l.placa)}</b> ${banderaLPR(l.region)}</td><td>${l.fuente === 'camara' ? 'Cámara de placas' : 'Foto'}${l.confianza && l.confianza < 1 ? ' · ' + Math.round(l.confianza * 100) + '%' : ''}</td><td>${l.ticket_id ? folio(l.ticket_id) : l.descartada ? 'Ignorada' : '—'}</td></tr>`).join('')}</tbody></table></div></details>` : '';
    }).catch(() => {});
    cargar();
    $('#lprClave').onclick = async () => { if (!(await confirmar('Al cambiar la clave tendrá que poner la nueva dirección en la cámara. ¿Continuar?'))) return; await post('/api/lpr/nueva-clave'); cargar(); toast('Clave nueva', 'ok'); };
    $('#lprProbar').onclick = async () => {
      const f = $('#fCfg'), d = formData(f), b = $('#lprProbar');
      b.disabled = true; $('#lprRes').textContent = 'Tomando la foto y leyendo…'; $('#lprPrev').innerHTML = '';
      try {
        await post('/api/config', { camara_tipo: d.camara_tipo, camara_url: d.camara_url, camara_usuario: d.camara_usuario, camara_password: d.camara_password, lpr_modo: d.lpr_modo, lpr_token: d.lpr_token, lpr_regiones: d.lpr_regiones, lpr_min_confianza: d.lpr_min_confianza, lpr_al_ingreso: d.lpr_al_ingreso });
        await recargarMe();
        const x = await post('/api/lpr/leer');
        if (!x.ok) { $('#lprRes').innerHTML = `<b style="color:var(--bad)">${esc(x.error)}</b>`; return; }
        $('#lprRes').innerHTML = x.placa ? `Placa: <b class="mono">${esc(x.placa)}</b> ${banderaLPR(x.region)} · ${Math.round((x.confianza || 0) * 100)}% seguro` : '<b>La foto se tomó pero no se encontró placa.</b> Revise que la cámara vea la placa de frente.';
        if (x.imagen) $('#lprPrev').innerHTML = `<img src="${x.imagen}" alt="Foto de prueba" style="max-width:100%;max-height:260px;border-radius:10px">`;
        cargar();
      } catch (e) { $('#lprRes').innerHTML = `<b style="color:var(--bad)">${esc(e.message)}</b>`; } finally { b.disabled = false; }
    };
    return r;
  };
}
