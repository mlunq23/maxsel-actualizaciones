param([string]$Port, [string]$OnHex, [string]$OffHex, [int]$Ms = 1000)
# Activa un relevador USB tipo LCUS-1 (CH340) por puerto COM: manda "encender", espera y manda "apagar".
function HexBytes([string]$h) {
  $h = $h -replace '[^0-9A-Fa-f]', ''
  [byte[]]$b = for ($i = 0; $i -lt $h.Length; $i += 2) { [Convert]::ToByte($h.Substring($i, 2), 16) }
  return ,$b
}
try {
  $sp = New-Object System.IO.Ports.SerialPort $Port, 9600, 'None', 8, 'One'
  $sp.Open()
  $on = HexBytes $OnHex
  $sp.Write($on, 0, $on.Length)
  Start-Sleep -Milliseconds $Ms
  if ($OffHex) { $off = HexBytes $OffHex; $sp.Write($off, 0, $off.Length) }
  $sp.Close()
  Write-Output 'OK'
} catch {
  Write-Output ("Error en " + $Port + ": " + $_.Exception.Message)
}
