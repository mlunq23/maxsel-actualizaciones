# Lista las impresoras instaladas en Windows (una por línea)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
try { Get-Printer -ErrorAction Stop | Sort-Object Name | ForEach-Object { $_.Name } }
catch { Get-CimInstance Win32_Printer | Sort-Object Name | ForEach-Object { $_.Name } }
