// Permisos que el administrador puede dar o quitar a cada usuario de Maxsel Motel (sin gastos, asistencia, contratos ni depósitos)
export const PERMISOS = [
  { grupo: 'Caja', clave: 'caja', texto: 'Abrir y cerrar su turno de caja y cobrar' },
  { grupo: 'Caja', clave: 'movimientos', texto: 'Registrar ingresos y egresos de caja' },
  { grupo: 'Caja', clave: 'cajon', texto: 'Abrir el cajón de dinero sin cobrar' },
  { grupo: 'Caja', clave: 'ver_corte', texto: 'Ver lo que debería haber al cerrar su turno (si no, el cierre es a ciegas)' },
  { grupo: 'Caja', clave: 'cancelar', texto: 'Cancelar ventas de la tienda' },
  { grupo: 'Caja', clave: 'autorizar', texto: 'Autorizar con su clave: cancelar entradas, egresos de caja, quitar cargos y cambiar el precio del tiempo extra' },
  { grupo: 'Habitaciones', clave: 'registrar', texto: 'Dar entradas, tiempo extra, persona extra, cambiar de habitación y dar salida' },
  { grupo: 'Habitaciones', clave: 'estados', texto: 'Mandar a limpiar, marcar limpia y lista, y dar de alta recamareras' },
  { grupo: 'Habitaciones', clave: 'multas', texto: 'Cargar multas y cargos (daños, blancos) a la cuenta de la habitación' },
  { grupo: 'Tienda', clave: 'vender', texto: 'Vender productos y servicio a la habitación' },
  { grupo: 'Tienda', clave: 'inventario', texto: 'Registrar entradas de mercancía' },
  { grupo: 'Tienda', clave: 'productos', texto: 'Dar de alta, editar y borrar productos y precios' },
  { grupo: 'Mantenimiento', clave: 'mant_reportar', texto: 'Reportar desperfectos con fotos' },
  { grupo: 'Mantenimiento', clave: 'mant_atender', texto: 'Atender reportes y marcarlos como reparados' },
  { grupo: 'Administración', clave: 'reportes', texto: 'Ver reportes de ingresos, rentas, recamareras y cancelaciones' },
  { grupo: 'Administración', clave: 'cortes', texto: 'Ver los cortes de caja de todos los usuarios' },
  { grupo: 'Administración', clave: 'habitaciones', texto: 'Agregar habitaciones, tipos y tarifas' },
  { grupo: 'Administración', clave: 'usuarios', texto: 'Administrar usuarios y sus permisos' },
  { grupo: 'Administración', clave: 'config', texto: 'Configuración del motel, impresora y respaldos' },
  { grupo: 'Administración', clave: 'bitacora', texto: 'Ver la bitácora de todos los movimientos del sistema' },
];
const RECEPCION = ['caja', 'movimientos', 'cajon', 'registrar', 'estados', 'multas', 'vender', 'inventario', 'mant_reportar'];
export const PERMISOS_ROL = {
  admin: PERMISOS.map((p) => p.clave),
  // Gerente: todo menos administrar usuarios y la configuración general
  gerente: PERMISOS.map((p) => p.clave).filter((k) => k !== 'usuarios' && k !== 'config' && k !== 'bitacora'),
  recepcion: RECEPCION,
  monitor: ['reportes', 'cortes'],
  mantenimiento: ['mant_reportar', 'mant_atender'],
};
const VALIDOS = new Set(PERMISOS.map((p) => p.clave));

// Permisos efectivos de un usuario. El administrador siempre tiene todo.
export function permisosDe(u) {
  if (!u) return [];
  if (u.rol === 'admin') return PERMISOS_ROL.admin;
  if (u.permisos) {
    try { const l = JSON.parse(u.permisos); if (Array.isArray(l)) return l.filter((k) => VALIDOS.has(k) && k !== 'usuarios'); } catch { /* usar los del rol */ }
  }
  return PERMISOS_ROL[u.rol] || [];
}
export const limpiarPermisos = (lista) => (Array.isArray(lista) ? [...new Set(lista.filter((k) => VALIDOS.has(k)))] : null);
