// Impresión directa a la impresora de tickets (ESC/POS): corte automático y pulso al cajón de dinero.
// Igual que Maxsel Parking: impresora instalada en Windows (USB) o impresora de red (IP).
import fs from 'node:fs';
import os from 'node:os';
import net from 'node:net';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { cfg } from './db.js';

const HERR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'herramientas');
const ESC = 0x1B, GS = 0x1D;
const CP437 = { 'á': 0xA0, 'é': 0x82, 'í': 0xA1, 'ó': 0xA2, 'ú': 0xA3, 'ñ': 0xA4, 'Ñ': 0xA5, 'ü': 0x81, 'Ü': 0x9A, '¿': 0xA8, '¡': 0xAD, 'É': 0x90, '°': 0xF8, '·': 0xFA };
const SIN_ACENTO = { 'Á': 'A', 'Í': 'I', 'Ó': 'O', 'Ú': 'U', '–': '-', '—': '-', '“': '"', '”': '"', '’': "'", '×': 'x', '✂': '-' };
function cp437(s) {
  const out = [];
  for (const ch of String(s)) {
    const c = ch.charCodeAt(0);
    if (c < 128) out.push(c); else if (CP437[ch] !== undefined) out.push(CP437[ch]); else if (SIN_ACENTO[ch]) out.push(SIN_ACENTO[ch].charCodeAt(0)); else out.push(0x3F);
  }
  return Buffer.from(out);
}

// ops: ['align','center'] ['bold',true] ['big',true] ['text','...'] ['feed',n] ['img', bytesPorRenglón, alto, base64] ['cut']
export function escpos(ops, { cajon = false } = {}) {
  const parts = [Buffer.from([ESC, 0x40, ESC, 0x74, 0x00])];
  if (cajon) parts.push(Buffer.from([ESC, 0x70, 0x00, 0x19, 0xFA]));
  for (const op of ops || []) {
    switch (op[0]) {
      case 'align': parts.push(Buffer.from([ESC, 0x61, { left: 0, center: 1, right: 2 }[op[1]] ?? 0])); break;
      case 'bold': parts.push(Buffer.from([ESC, 0x45, op[1] ? 1 : 0])); break;
      case 'big': parts.push(Buffer.from([GS, 0x21, op[1] ? 0x11 : 0x00])); break;
      case 'size': { const n = Math.min(8, Math.max(1, Number(op[1]) || 1)) - 1; parts.push(Buffer.from([GS, 0x21, (n << 4) | n])); break; } // letra gigante (número de habitación)
      case 'text': parts.push(cp437(String(op[1]).slice(0, 200)), Buffer.from([0x0A])); break;
      case 'feed': parts.push(Buffer.from([ESC, 0x64, Math.min(10, Number(op[1]) || 1)])); break;
      case 'cut': parts.push(Buffer.from([ESC, 0x64, 3, GS, 0x56, cfg('impresora_corte') === 'total' ? 0x41 : 0x42, 0x00])); break; // corte entre original y copia
      case 'img': { // imagen de 1 bit (firmas): GS v 0
        const w = Number(op[1]), h = Number(op[2]), data = Buffer.from(String(op[3]), 'base64');
        if (w > 0 && w <= 72 && h > 0 && h <= 400 && data.length === w * h) parts.push(Buffer.from([GS, 0x76, 0x30, 0, w & 255, w >> 8, h & 255, h >> 8]), data, Buffer.from([0x0A]));
        break;
      }
    }
  }
  // Al final siempre avanza hasta la cuchilla y corta el ticket
  parts.push(Buffer.from([ESC, 0x64, 3, GS, 0x56, cfg('impresora_corte') === 'total' ? 0x41 : 0x42, 0x00]));
  return Buffer.concat(parts);
}

function powershell(script, args, timeout = 20000) {
  return new Promise((ok, mal) => {
    execFile('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(HERR, script), ...args], { timeout, windowsHide: true }, (err, stdout, stderr) => {
      const out = String(stdout || '').trim();
      if (err) return mal(new Error(String(stderr || err.message).trim()));
      if (script === 'imprimir-raw.ps1' && out && !out.endsWith('OK')) return mal(new Error(out));
      ok(out);
    });
  });
}
function enviarIP(buf, ip, puerto) {
  return new Promise((ok, mal) => {
    const s = net.createConnection({ host: ip, port: Number(puerto) || 9100 });
    s.setTimeout(5000);
    s.on('connect', () => s.end(buf));
    s.on('close', (e) => (e ? null : ok()));
    s.on('timeout', () => { s.destroy(); mal(new Error('La impresora de red no respondió (' + ip + ')')); });
    s.on('error', (e) => mal(new Error('Impresora de red: ' + e.message)));
  });
}
export const hayImpresora = () => ['windows', 'ip'].includes(cfg('impresora_tipo'));
export async function enviar(buf) {
  const tipo = cfg('impresora_tipo');
  if (tipo === 'ip') {
    if (!cfg('impresora_ip')) throw new Error('Escriba la IP de la impresora en Configuración → Impresora y cajón');
    return enviarIP(buf, cfg('impresora_ip'), cfg('impresora_puerto'));
  }
  if (tipo === 'windows') {
    if (process.platform !== 'win32') throw new Error('La impresora de Windows solo funciona en Windows');
    if (!cfg('impresora_nombre')) throw new Error('Elija la impresora en Configuración → Impresora y cajón');
    const f = path.join(os.tmpdir(), 'maxsel_hotel_' + crypto.randomBytes(6).toString('hex') + '.bin');
    fs.writeFileSync(f, buf);
    try { await powershell('imprimir-raw.ps1', ['-Printer', cfg('impresora_nombre'), '-File', f]); } finally { fs.rm(f, () => {}); }
    return;
  }
  throw new Error('No hay impresora de tickets configurada');
}
export async function imprimirOps(ops, cajon) {
  if (!hayImpresora()) return { ok: false, sinImpresora: true };
  try { await enviar(escpos(ops, { cajon: cajon && cfg('abrir_cajon') !== '0' })); return { ok: true }; } catch (e) { return { ok: false, error: e.message }; }
}
// Solo el pulso para abrir el cajón (sin imprimir nada)
export async function abrirCajon() {
  if (!hayImpresora() || cfg('abrir_cajon') === '0') return { ok: false, sinImpresora: true };
  try { await enviar(Buffer.from([ESC, 0x40, ESC, 0x70, 0x00, 0x19, 0xFA])); return { ok: true }; } catch (e) { return { ok: false, error: e.message }; }
}
export async function listarImpresoras() {
  if (process.platform !== 'win32') return [];
  const out = await powershell('listar-impresoras.ps1', [], 15000);
  return out.split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
}
