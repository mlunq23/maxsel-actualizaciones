// Maxsel Motel 1.0 — capa del motel (va después de todo lo del motel y reemplaza sus pantallas principales)
// Tablero de habitaciones con reloj, entrada rápida, cuenta de la habitación, tiempo extra, persona extra,
// servicio a la habitación, cambio con diferencia, cancelación con clave y salida.
'use strict';

// ---------- Íconos y textos del motel ----------
Object.assign(P, {
  cochera: '<path d="M3 21V9l9-6 9 6v12"/><path d="M6 21v-8h12v8M6 16h12M6 19h12"/>',
  sauna: '<path d="M4 20h16M6 20v-6h12v6"/><path d="M9 11c-1-1.5 1-2.5 0-4M12 11c-1-1.5 1-2.5 0-4M15 11c-1-1.5 1-2.5 0-4"/>',
  alberca: '<path d="M2 18c2 0 2-1.5 4-1.5S8 18 10 18s2-1.5 4-1.5 2 1.5 4 1.5 2-1.5 4-1.5"/><path d="M8 15V5a2 2 0 0 1 4 0M16 15V5a2 2 0 0 0-4 0M8 9h8"/>',
  sonido: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/>',
  tubo: '<path d="M12 2v20M8 22h8M10 2h4"/>',
  reloj: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  auto: '<path d="M5 16h14M5 16v2M19 16v2M4 16l1.5-5.5A2 2 0 0 1 7.4 9h9.2a2 2 0 0 1 1.9 1.5L20 16"/><circle cx="7.5" cy="13.5" r=".9"/><circle cx="16.5" cy="13.5" r=".9"/>',
  persona: '<circle cx="12" cy="7" r="3.5"/><path d="M5 21a7 7 0 0 1 14 0"/>',
  escoba: '<path d="M15 3 9 14M7 14h5l2 7H4z"/><path d="M7 18h6"/>',
  llave: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3M15 8l2 2"/>',
  salir: '<path d="M10 4H5v16h5M14 8l4 4-4 4M18 12H9"/>',
  mas: '<path d="M12 5v14M5 12h14"/>',
  menos: '<path d="M5 12h14"/>',
  cambio: '<path d="M4 8h13l-3-3M20 16H7l3 3"/>',
  bolsa: '<path d="M5 8h14l-1 13H6z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
  dinero: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="3"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  ticket: '<path d="M4 4h16v16l-3-2-3 2-3-2-3 2-4-2z"/><path d="M8 9h8M8 13h6"/>',
  lapiz: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13 7l4 4"/>',
  alerta: '<path d="M12 3 2 21h20z"/><path d="M12 10v5M12 18v.01"/>',
  buscar: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
});
Object.assign(AMEN, { cochera: 'Cochera', sauna: 'Sauna', alberca: 'Alberca', sonido: 'Sonido', tubo: 'Tubo' });
const LLEGA = { auto: 'En auto', pie: 'A pie', taxi: 'Taxi', moto: 'Moto', app: 'Uber / DiDi' };
const LLEGA_I = { auto: 'auto', pie: 'persona', taxi: 'auto', moto: 'auto', app: 'auto' };
const ESTM = { libre: 'Disponible', ocupada: 'Ocupada', porsalir: 'Por salir', excedida: 'Tiempo excedido', sucia: 'Sucia', limpiando: 'Limpiando', mant: 'Mantenimiento' };
const ORDEN_ESTM = ['libre', 'ocupada', 'porsalir', 'excedida', 'sucia', 'limpiando', 'mant'];
const CONC_M = { hospedaje: 'Hospedaje', hora_extra: 'Tiempo extra', persona_extra: 'Persona extra', tienda: 'Tienda', multa: 'Multa', otro: 'Otro cargo', limpieza: 'Limpieza' };
Object.assign(TIPOS_CARGO, { hora_extra: 'Tiempo extra', persona_extra: 'Persona extra' });

// Menú del motel: sin gastos, asistencia, reservaciones, contratos, visitantes ni huéspedes
VISTAS.splice(0, VISTAS.length, ['hab', 'Habitaciones'], ['caja', 'Caja', 'caja|cortes'], ['tienda', 'Tienda', 'vender'], ['inv', 'Inventario'], ['ent', 'Entradas y placas'],
  ['limp', 'Limpieza', 'estados|reportes'], ['mant', 'Mantenimiento'], ['rep', 'Reportes', 'reportes'], ['cfg', 'Configuración']);

let MT = null, MT_OFF = 0, mFiltro = 'todas', mtTipo = '', mTick = null;
const ahoraS = () => new Date(Date.now() + MT_OFF);
const hmM = (d) => (d ? d.toLocaleTimeString('es-MX', { hour: 'numeric', minute: '2-digit' }) : '');
const diaHora = (s) => { const d = aF(s); if (!d) return '—'; const hoy = ahoraS(), man = new Date(hoy); man.setDate(man.getDate() + 1);
  const dia = d.toDateString() === hoy.toDateString() ? 'hoy' : d.toDateString() === man.toDateString() ? 'mañana' : d.toLocaleDateString('es-MX', { weekday: 'short', day: 'numeric', month: 'short' });
  return dia + ' ' + hmM(d); };
const dur = (ms) => { const t = Math.floor(Math.abs(ms) / 1000), h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = t % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${m}:${String(s).padStart(2, '0')}`; };
const durTxt = (min) => { min = Math.round(Number(min) || 0); const h = Math.floor(min / 60), m = min % 60; return h ? `${h} h ${String(m).padStart(2, '0')} min` : `${m} min`; };
function salidaDe(tf, desde) {
  if (!tf.noche) return new Date(desde.getTime() + tf.horas * 3600000);
  const [a, b] = String(tf.hora_salida || '12:00').split(':').map(Number), s = new Date(desde); s.setHours(a, b || 0, 0, 0);
  if ((s - desde) / 3600000 < 6) s.setDate(s.getDate() + 1); return s;
}
const tarifaTxt = (t) => (t.noche ? `Noche · sale ${hmM(aF('2000-01-01 ' + (t.hora_salida || '12:00') + ':00'))}` : `${t.horas} h`);

function estadoM(h) {
  if (h.estado === 'ocupada' && h.estancia) {
    const e = h.estancia, falta = aF(e.salida_prevista) - ahoraS();
    if (falta < 0 || e.cobros_auto > 0) return 'excedida';
    return falta <= (Number(CFG.motel_aviso_min) || 15) * 60000 ? 'porsalir' : 'ocupada';
  }
  if (h.estado === 'limpieza') return h.limpieza?.estado === 'limpiando' ? 'limpiando' : 'sucia';
  return h.estado === 'mant' ? 'mant' : 'libre';
}

// ---------- Menú: vistas nuevas ----------
{
  const _ir = ir;
  ir = async function (v, ...a) {
    clearInterval(mTick);
    if (v === 'ent' || v === 'limp') {
      vista = v; clearInterval(timer); pintarNav(ir.badge);
      const fn = v === 'ent' ? vEnt : vLimp;
      try { await fn(); } catch (e) { if (e.message) $('#main').innerHTML = `<div class="aviso bad">${esc(e.message)}</div>`; }
      if (v === 'limp') timer = setInterval(() => { if ($('#modal').hidden) fn().catch(() => {}); }, 20000);
      if (window.innerWidth < 760) window.scrollTo(0, 0);
      return;
    }
    const r = await _ir.call(this, v, ...a);
    if (v === 'hab') { clearInterval(timer); timer = setInterval(() => { if ($('#modal').hidden && $('#cobro')?.hidden !== false) vHab().catch(() => {}); }, 15000); }
    return r;
  };
}
// La tienda necesita saber qué habitaciones están ocupadas para "cargar a la habitación"
{
  const _vt = vTienda;
  vTienda = async function (...a) { const r = await _vt.apply(this, a); try { MT = await GET('/api/motel/tablero'); TAB = MT; } catch { /* nada */ } return r; };
}

// ---------- Tablero de habitaciones ----------
vHab = async function () {
  const d = await GET('/api/motel/tablero');
  MT = d; TAB = d; CFG = { ...CFG, ...d.config }; aplicarColores();
  MT_OFF = aF(d.ahora) - new Date();
  const H = d.habitaciones.filter((h) => !mtTipo || String(h.tipo_id) === mtTipo), c = { todas: H.length };
  for (const k of ORDEN_ESTM) c[k] = 0;
  H.forEach((h) => c[estadoM(h)]++);
  const ocup = c.ocupada + c.porsalir + c.excedida;
  ir.badge = { ...(ir.badge || {}), hab: ocup + '/' + d.habitaciones.length, limp: (c.sucia + c.limpiando) || '' }; pintarNav(ir.badge);
  const chips = [['todas', 'Todas'], ...ORDEN_ESTM.map((k) => [k, ESTM[k]])].map(([k, n]) => `<button class="mst ${mFiltro === k ? 'on' : ''}" data-s="${k}" onclick="mFiltro='${k}';vHab()"><b>${c[k]}</b><span>${n}</span></button>`).join('');
  const lista = sortH(H.filter((h) => mFiltro === 'todas' || estadoM(h) === mFiltro));
  const tipos = d.tipos.filter((t) => d.habitaciones.some((h) => h.tipo_id === t.id));
  $('#main').innerHTML = cab('Habitaciones', `${esc(CFG.hotel_nombre)} · <span id="mReloj">${ahoraS().toLocaleTimeString('es-MX', { hour: 'numeric', minute: '2-digit', second: '2-digit' })}</span> · se actualiza sola`,
    puede('habitaciones') ? `<button class="btn" onclick="cfgTab='habs';ir('cfg')">${ico('lapiz')} Habitaciones y tarifas</button>` : '')
    + (tipos.length > 1 ? `<div class="tabs mtipos"><button class="${!mtTipo ? 'on' : ''}" onclick="mtTipo='';vHab()">Todos los tipos</button>${tipos.map((t) => `<button class="${mtTipo === String(t.id) ? 'on' : ''}" onclick="mtTipo='${t.id}';vHab()"><i style="background:${esc(t.color)}"></i>${esc(t.nombre)}</button>`).join('')}</div>` : '')
    + `<div class="mstates">${chips}</div>`
    + (lista.length ? `<div class="mgrid">${lista.map(tarjetaM).join('')}</div>`
      : `<div class="card empty">${d.habitaciones.length ? 'No hay habitaciones con este estado.' : 'Aún no hay habitaciones. ' + (puede('habitaciones') ? 'Agréguelas en Configuración → Habitaciones (primero cree los tipos y tarifas).' : 'Pida al administrador que las agregue.')}</div>`);
  clearInterval(mTick); mTick = setInterval(tickM, 1000);
};
function tarjetaM(h) {
  const st = estadoM(h), e = h.estancia, t = h.tipo, l = h.limpieza, ya = ahoraS();
  let cuerpo = '';
  if (e) {
    const fin = aF(e.salida_prevista), falta = fin - ya;
    cuerpo = `<div class="mt-reloj" data-sal="${esc(e.salida_prevista)}">${falta < 0 ? '+' + dur(falta) : dur(falta)}</div>
      <div class="mt-l">${esc(e.tarifa || '')} · sale ${hmM(fin)}</div>
      <div class="mt-chips">${e.placas ? `<span class="mt-pl">${esc(e.placas)}</span>` : `<span>${ico(LLEGA_I[e.llegada] || 'persona')}${esc(LLEGA[e.llegada] || '')}</span>`}<span>${ico('personas')}${e.personas}</span></div>
      ${e.cobros_auto > 0 ? `<div class="mt-alerta">${ico('alerta')} Excedido · ${e.horas_extra} h extra</div>` : ''}${e.saldo > 0.009 ? `<div class="mt-debe">Debe ${money(e.saldo)}</div>` : ''}`;
  } else if (st === 'sucia') cuerpo = `<div class="mt-reloj chico" data-desde="${esc(l?.sucia || '')}">${l?.sucia ? dur(ya - aF(l.sucia)) : ''}</div><div class="mt-l">${ico('escoba')} Sin limpiar</div>`;
  else if (st === 'limpiando') cuerpo = `<div class="mt-reloj chico" data-desde="${esc(l.inicio)}">${dur(ya - aF(l.inicio))}</div><div class="mt-l">${ico('escoba')} ${esc(l.recamarera || '')}</div>`;
  else if (st === 'mant') cuerpo = `<div class="mt-l">${esc(h.nota || 'En reparación')}</div>${h.reportes ? `<div class="mt-l">${h.reportes} reporte(s)</div>` : ''}`;
  else cuerpo = `<div class="mt-l">${t?.tarifas?.length ? 'Desde ' + money(Math.min(...t.tarifas.map((x) => x.precio))) : 'Sin tarifas'}</div><div class="amen">${(h.amenidades || []).slice(0, 6).map((a) => `<span title="${esc(AMEN[a] || a)}">${ico(a)}</span>`).join('')}</div>`;
  return `<button class="mt s-${st}" style="--t:${esc(t?.color || '#64748b')}" onclick="abrirHab(${h.id})" aria-label="Habitación ${esc(h.numero)}, ${ESTM[st]}">
    <div class="mt-cab"><span class="mt-num">${esc(h.numero)}</span><span class="mt-tipo"><i></i>${esc(t?.nombre || 'Sin tipo')}</span></div>
    <div class="mt-est">${ESTM[st]}</div>${cuerpo}</button>`;
}
function tickM() {
  if (vista !== 'hab' || !$('.mgrid')) { clearInterval(mTick); return; }
  const ya = ahoraS(), r = $('#mReloj'); if (r) r.textContent = ya.toLocaleTimeString('es-MX', { hour: 'numeric', minute: '2-digit', second: '2-digit' });
  let cambio = false;
  document.querySelectorAll('.mt-reloj[data-sal]').forEach((el) => {
    const falta = aF(el.dataset.sal) - ya; el.textContent = falta < 0 ? '+' + dur(falta) : dur(falta);
    const card = el.closest('.mt'), aviso = (Number(CFG.motel_aviso_min) || 15) * 60000;
    if ((falta < 0 && !card.classList.contains('s-excedida')) || (falta >= 0 && falta <= aviso && card.classList.contains('s-ocupada'))) cambio = true;
  });
  document.querySelectorAll('.mt-reloj[data-desde]').forEach((el) => { if (el.dataset.desde) el.textContent = dur(ya - aF(el.dataset.desde)); });
  if (cambio && $('#modal').hidden && $('#cobro')?.hidden !== false) vHab().catch(() => {});
}

// Tocar una habitación
abrirHab = function (id) {
  const h = (MT || TAB)?.habitaciones.find((x) => x.id === id); if (!h) return;
  const st = estadoM(h);
  if (h.estancia) return mCuenta(h.estancia.id);
  if (st === 'libre') return mEntrada(id);
  if (st === 'sucia' || st === 'limpiando') return mLimpiar(id);
  const t = `Habitación ${esc(h.numero)} · ${esc(h.tipo?.nombre || '')}`;
  modal(t, `<div class="aviso">En mantenimiento: <b>${esc(h.nota || 'sin detalle')}</b>${h.reportes ? ` · ${h.reportes} reporte(s) abierto(s). Al marcarlos como reparados en Mantenimiento, la habitación se libera sola.` : ''}</div>`,
    `<button class="btn" onclick="cerrar();ir('mant')">Ver reportes</button><button class="btn op" onclick="estado(${id},'limpieza')">Reparada, mandar a limpiar</button><button class="btn ok op" onclick="estado(${id},'libre')">Reparada y lista</button>`);
};
estado = async function (id, e, nota) { await hacer(() => POST(`/api/habitaciones/${id}/estado`, { estado: e, nota }), { libre: 'Disponible', limpieza: 'Mandada a limpiar', mant: 'En mantenimiento' }[e]); cerrar(); vista === 'limp' ? vLimp() : vHab(); };

// ---------- Limpieza desde el tablero ----------
function mLimpiar(id) {
  const h = MT.habitaciones.find((x) => x.id === id), l = h.limpieza, recs = MT.recamareras;
  const sel = l?.recamarera_id || '';
  modal(`Habitación ${esc(h.numero)} · ${l?.estado === 'limpiando' ? 'limpiando' : 'sucia'}`, `
    <div class="kv"><span>Quedó sucia</span><b>${l?.sucia ? diaHora(l.sucia) + ' · hace ' + durTxt((ahoraS() - aF(l.sucia)) / 60000) : '—'}</b>
      ${l?.inicio ? `<span>Empezó a limpiar</span><b>${diaHora(l.inicio)} · ${esc(l.recamarera || '')} (${durTxt((ahoraS() - aF(l.inicio)) / 60000)})</b>` : ''}</div>
    <div class="lbl">¿Quién la limpia?</div>
    ${recs.length ? `<div class="seg mrec">${recs.map((r) => `<label><input type="radio" name="mRc" value="${r.id}" ${String(sel) === String(r.id) ? 'checked' : ''}><span>${ico('escoba')} ${esc(r.nombre)}</span></label>`).join('')}</div>`
    : `<div class="aviso">Aún no hay recamareras. ${puede('estados') ? `<button class="btn sm" onclick="recModal()">Agregar recamarera</button>` : ''}</div>`}`,
  `<button class="btn op" onclick="mantNuevo(${id})">Reportar desperfecto</button>${l?.estado !== 'limpiando' ? `<button class="btn op" onclick="limpIniciar(${id})">Empezar a limpiar</button>` : ''}<button class="btn ok op" onclick="limpTerminar(${id})">Limpia y lista</button>`);
}
async function limpIniciar(id) {
  const rc = document.querySelector('input[name=mRc]:checked')?.value; if (!rc) return toast('Elija la recamarera', true);
  await hacer(() => POST(`/api/motel/limpieza/${id}/iniciar`, { recamarera_id: rc }), 'Limpiando'); cerrar(); vista === 'limp' ? vLimp() : vHab();
}
async function limpTerminar(id) {
  const rc = document.querySelector('input[name=mRc]:checked')?.value;
  await hacer(() => POST(`/api/motel/limpieza/${id}/terminar`, { recamarera_id: rc || undefined }), 'Habitación limpia y disponible'); cerrar(); vista === 'limp' ? vLimp() : vHab();
}

// ---------- Entrada ----------
let ME = null; // datos de la entrada que se está capturando
function mEntrada(id) {
  const h = MT.habitaciones.find((x) => x.id === id), t = h.tipo;
  if (!t || !t.tarifas.length) return toast('Esta habitación no tiene tipo o tarifas. Configúrelas en Configuración → Tipos y tarifas.', true);
  ME = { id, h, t, tarifa: t.tarifas[0].id, personas: Math.min(2, t.personas_incluidas || 2), llegada: 'auto', desc: null };
  modal(`Entrada · Hab. ${esc(h.numero)} · ${esc(t.nombre)}`, `
    <div class="lbl">Tarifa</div>
    <div class="seg mtar">${t.tarifas.map((x) => `<label style="--c:${esc(t.color)}"><input type="radio" name="meT" value="${esc(x.id)}" ${x.id === ME.tarifa ? 'checked' : ''} onchange="ME.tarifa=this.value;meCalc()"><span>${esc(x.nombre)}</span><b>${money(x.precio)}</b><small>Sale ${diaHora(fechaHoraLocal(salidaDe(x, ahoraS())))}</small></label>`).join('')}</div>
    <div class="mfila">
      <div><div class="lbl">Personas <small class="sub">(incluye ${t.personas_incluidas}${t.precio_persona_extra > 0 ? ` · extra ${money(t.precio_persona_extra)} c/u` : ''})</small></div>
        <div class="mcont"><button type="button" class="btn" onclick="ME.personas=Math.max(1,ME.personas-1);meCalc()" aria-label="Menos">${ico('menos')}</button><b id="meP">${ME.personas}</b><button type="button" class="btn" onclick="ME.personas=Math.min(20,ME.personas+1);meCalc()" aria-label="Más">${ico('mas')}</button></div></div>
      <div style="flex:2"><div class="lbl">Llegó</div><div class="seg mlleg">${Object.entries(LLEGA).map(([k, n]) => `<label><input type="radio" name="meL" value="${k}" ${k === 'auto' ? 'checked' : ''} onchange="ME.llegada=this.value;meCalc()"><span>${ico(LLEGA_I[k])} ${n}</span></label>`).join('')}</div></div>
    </div>
    <div class="f" id="meAuto"><label class="l">Placas${CFG.motel_pide_placas === '1' ? ' *' : ''}<input id="mePl" autocomplete="off" autocapitalize="characters" style="text-transform:uppercase;font-family:var(--fMono);font-size:18px;letter-spacing:.06em" onchange="mePlacas()" placeholder="ABC1234"></label>
      <label class="l">Vehículo (marca, color)<input id="meVe" autocomplete="off" placeholder="Ej. Versa gris"></label></div>
    <div id="mePi"></div>
    <div class="f"><label class="l">Nombre (opcional)<input id="meNo" autocomplete="off"></label><label class="l">Notas<input id="meNt" autocomplete="off"></label></div>
    <div id="meDe"><button type="button" class="btn sm" onclick="meDescuento()">Agregar descuento o cortesía</button></div>
    <div class="seg mcob"><label><input type="radio" name="meC" value="1" checked onchange="meCalc()"><span>${ico('dinero')} Cobrar ahora</span></label><label><input type="radio" name="meC" value="0" onchange="meCalc()"><span>${ico('salir')} Cobrar a la salida</span></label></div>
    <div class="calc" id="meR"></div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" id="meOk" onclick="meOk()">Dar entrada</button>`, true);
  meCalc(); setTimeout(() => $('#mePl')?.focus(), 50);
}
function meDescuento() {
  $('#meDe').innerHTML = `<div class="card" style="padding:12px"><div class="f"><label class="l">Descuento<select id="meDt" onchange="meCalc()"><option value="pct">Porcentaje (%)</option><option value="monto">Cantidad ($)</option></select></label>
    <label class="l">Valor<input id="meDv" type="number" min="0" step="0.01" oninput="meCalc()"></label><label class="l">Motivo *<input id="meDm" placeholder="Ej. cliente frecuente, cortesía del gerente"></label></div></div>`;
}
function meCalc() {
  if (!ME) return;
  const t = ME.t, tf = t.tarifas.find((x) => x.id === ME.tarifa) || t.tarifas[0], ya = ahoraS();
  $('#meP').textContent = ME.personas;
  const ext = Math.max(0, ME.personas - (t.personas_incluidas || 2)), pext = ext * (Number(t.precio_persona_extra) || 0);
  const dv = num('meDv'), desc = dv > 0 ? Math.min(tf.precio, val('meDt') === 'monto' ? dv : tf.precio * dv / 100) : 0;
  const total = tf.precio - desc + pext;
  const sal = salidaDe(tf, ya);
  ME.total = total; ME.tf = tf;
  $('#meAuto').hidden = !['auto', 'moto'].includes(ME.llegada);
  const cobra = document.querySelector('input[name=meC]:checked')?.value !== '0';
  $('#meOk').textContent = cobra ? `Dar entrada y cobrar ${money(total)}` : 'Dar entrada (cobrar al salir)';
  $('#meR').innerHTML = `<span>${esc(tf.nombre)}</span><b>${money(tf.precio)}</b>${pext ? `<span>Persona extra (${ext})</span><b>${money(pext)}</b>` : ''}${desc ? `<span>Descuento</span><b>-${money(desc)}</b>` : ''}
    <span>Total</span><b class="big">${money(total)}</b><span>Sale</span><b>${diaHora(fechaHoraLocal(sal))}</b>`;
}
const fechaHoraLocal = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
async function mePlacas() {
  const pl = val('mePl').toUpperCase().replace(/\s+/g, ''); $('#mePl').value = pl;
  const el = $('#mePi'); el.innerHTML = '';
  if (pl.length < 3) return;
  try {
    const r = await GET('/api/motel/placas/' + encodeURIComponent(pl));
    if (!r.n) return;
    if (r.vehiculo && !val('meVe')) $('#meVe').value = r.vehiculo;
    el.innerHTML = `<div class="aviso ok">${ico('auto')} <b>Ya vino ${r.n} ${r.n === 1 ? 'vez' : 'veces'}</b>${r.ultimas[0] ? ` · la última ${diaHora(r.ultimas[0].fecha)} en la ${esc(r.ultimas[0].numero)} (${esc(r.ultimas[0].tarifa || '')})` : ''}</div>`;
  } catch { /* nada */ }
}
async function meOk() {
  if (!ME) return;
  const cobra = document.querySelector('input[name=meC]:checked')?.value !== '0';
  const b = { habitacion_id: ME.id, tarifa_id: ME.tarifa, personas: ME.personas, llegada: ME.llegada, placas: ['auto', 'moto'].includes(ME.llegada) ? val('mePl') : '', vehiculo: ['auto', 'moto'].includes(ME.llegada) ? val('meVe') : '',
    nombre: val('meNo'), notas: val('meNt'), cobrar: cobra };
  if (num('meDv') > 0) Object.assign(b, { descuento_tipo: val('meDt'), descuento_valor: val('meDv'), descuento_motivo: val('meDm') });
  if (CFG.motel_pide_placas === '1' && ['auto', 'moto'].includes(ME.llegada) && !b.placas) return toast('Escriba las placas', true);
  if (b.descuento_valor && !b.descuento_motivo) return toast('Escriba el motivo del descuento', true);
  let imp = CFG.imprimir_auto !== '0';
  if (cobra && ME.total > 0) {
    const r = await ventanaCobro({ total: ME.total, titulo: `Entrada · Hab. ${ME.h.numero}`, detalle: `${ME.t.nombre} · ${ME.tf.nombre}`, notas: false });
    if (!r) return;
    Object.assign(b, { metodo: 'mixto', partes: r.partes }); imp = r.imprimir;
  }
  const res = await hacer(() => POST('/api/motel/entrada', b), 'Entrada registrada');
  if (res?.pago?.cambio > 0) toast('Entregue de cambio ' + money(res.pago.cambio));
  cerrar(); ME = null; await vHab(); pintarTurno();
  if (imp) mTicket(res.id, 'ENTRADA', res.pago);
}

// ---------- Cuenta de la habitación ----------
async function mCuenta(id) {
  const e = await GET('/api/motel/estancia/' + id), h = e.habitacion, ya = ahoraS(), fin = aF(e.salida_prevista), falta = fin - ya;
  mCuenta.e = e;
  const act = e.activa, est = e.cancelada ? 'Cancelada' : !act ? 'Ya salió' : falta < 0 || e.cobros_auto > 0 ? 'Tiempo excedido' : 'Ocupada';
  const reloj = act ? `<div class="mc-reloj ${falta < 0 ? 'mal' : falta < (Number(CFG.motel_aviso_min) || 15) * 60000 ? 'pronto' : ''}"><small>${falta < 0 ? 'Tiempo excedido' : 'Le quedan'}</small><b data-sal="${esc(e.salida_prevista)}" id="mcR">${falta < 0 ? '+' + dur(falta) : dur(falta)}</b><span>Entró ${diaHora(e.entrada)} · sale ${diaHora(e.salida_prevista)}</span></div>`
    : `<div class="mc-reloj ${e.cancelada ? 'mal' : ''}"><small>${est}</small><b>${durTxt((aF(e.salida_real) - aF(e.entrada)) / 60000)}</b><span>Entró ${diaHora(e.entrada)} · ${e.cancelada ? 'canceló' : 'salió'} ${diaHora(e.salida_real)}</span></div>`;
  const filas = [
    ...e.rentas.filter((r) => r.tipo !== 'cancelada' && r.importe).map((r) => `<tr><td>${{ entrada: 'Entrada', extension: 'Otra tarifa', cambio: 'Diferencia por cambio de habitación', automatico: 'Se cobró otra vez la tarifa (no salió a tiempo)' }[r.tipo] || 'Renta'}</td><td class="sub">${fdt(r.fecha)}</td><td class="n">${money(r.importe)}</td><td></td></tr>`),
    ...(e.descuento > 0 ? [`<tr><td>Descuento · ${esc(e.descuento_motivo || '')}</td><td></td><td class="n">-${money(e.descuento)}</td><td></td></tr>`] : []),
    ...e.cargos.map((c) => `<tr><td>${c.tipo && c.tipo !== 'consumo' ? `<span class="pill ct-${c.tipo}">${TIPOS_CARGO[c.tipo] || c.tipo}</span> ` : ''}${c.cantidad > 1 && c.tipo === 'consumo' ? c.cantidad + ' × ' : ''}${esc(c.descripcion)}</td><td class="sub">${fdt(c.fecha)}</td><td class="n">${money(c.importe)}</td>
      <td>${act && c.tipo && !['consumo'].includes(c.tipo) && !c.venta_id && puede('autorizar') ? `<button class="btn sm bad" onclick="confirmar(this,()=>mCargoQuitar(${c.id},${e.id}))" aria-label="Quitar">${ico('x')}</button>` : ''}</td></tr>`)];
  const acc = act ? `<div class="macc">
      ${puede('vender') ? `<button class="btn op" onclick="mServicio(${e.id})">${ico('bolsa')}Servicio a la habitación</button>` : ''}
      <button class="btn op" onclick="mTiempo(${e.id})">${ico('reloj')}Tiempo extra</button>
      <button class="btn op" onclick="mRenovar(${e.id})">${ico('mas')}Otra tarifa</button>
      <button class="btn op" onclick="mPersona(${e.id})">${ico('persona')}Persona extra</button>
      <button class="btn op" onclick="mCambiar(${e.id})">${ico('cambio')}Cambiar de habitación</button>
      ${puede('caja') ? `<button class="btn op" onclick="mAbono(${e.id})">${ico('dinero')}Cobrar / abono</button>` : ''}
      ${puede('multas') || puede('registrar') ? `<button class="btn op" onclick="mCargo(${e.id})">${ico('alerta')}Multa o cargo</button>` : ''}
      <button class="btn op" onclick="mEditar(${e.id})">${ico('lapiz')}Placas y datos</button></div>` : '';
  modal(`Hab. ${esc(h.numero)} · ${esc(e.tipo?.nombre || '')} <small class="sub">Folio ${esc(e.folio)}</small>`, `
    <div class="mc-cab">${reloj}<div class="kv">
      <span>Tarifa</span><b>${esc(e.tarifa || '')}</b><span>Llegó</span><span>${ico(LLEGA_I[e.llegada] || 'auto')} ${esc(LLEGA[e.llegada] || '—')}</span>
      ${e.placas ? `<span>Placas</span><b class="mono mt-pl">${esc(e.placas)}</b>` : ''}${e.vehiculo ? `<span>Vehículo</span><span>${esc(e.vehiculo)}</span>` : ''}
      ${e.huesped && !/^Placas |^Cliente$/.test(e.huesped) ? `<span>Nombre</span><span>${esc(e.huesped)}</span>` : ''}
      <span>Personas</span><span>${e.personas}${e.personas_extra ? ` (${e.personas_extra} extra)` : ''}</span>
      ${e.visitas > 1 ? `<span>Visitas</span><span>${e.visitas} con estas placas</span>` : ''}
      <span>Recepción</span><span>${esc(e.usuario)}</span>${e.notas ? `<span>Notas</span><span>${esc(e.notas)}</span>` : ''}</div></div>
    ${e.cobros_auto > 0 && act ? `<div class="aviso bad">No salió a tiempo: el sistema ya cargó ${e.horas_extra ? e.horas_extra + ' h de tiempo extra' : e.cobros_auto + ' tarifa(s) más'}. Ya está sumado a la cuenta.</div>` : ''}
    ${e.cancelada ? `<div class="aviso bad"><b>Entrada cancelada</b> · ${esc(e.cancel_motivo || '')} · canceló ${esc(e.cancelo || '')}${e.autorizo && e.autorizo !== e.cancelo ? ', autorizó ' + esc(e.autorizo) : ''}${e.cancel_devuelto ? ' · se devolvieron ' + money(e.cancel_devuelto) : ''}</div>` : ''}
    ${e.cambios.length ? `<div class="sub">${e.cambios.map((c) => `Cambio de la ${esc(c.de_num)} a la ${esc(c.a_num)} · ${fdt(c.fecha)} · ${esc(c.motivo || '')}`).join('<br>')}</div>` : ''}
    ${acc}
    <div><div class="lbl">Cuenta</div><div class="tw"><table><tbody>${filas.join('') || '<tr><td class="empty">Sin cargos.</td></tr>'}</tbody></table></div></div>
    <div><div class="lbl">Pagos</div>${e.pagos.length ? `<div class="tw"><table><tbody>${e.pagos.map((p) => `<tr><td>${fdt(p.fecha)}</td><td>${CONC_M[p.concepto] || p.concepto}</td><td>${MET[p.metodo] || p.metodo}${p.usd ? ' US$' + Number(p.usd).toFixed(2) : ''}</td><td class="sub">${esc(p.nota || '')}</td><td class="n" style="${p.monto < 0 ? 'color:var(--ocup)' : ''}">${money(p.monto)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="sub">Sin pagos.</div>'}</div>
    <div class="calc"><span>Hospedaje</span><b>${money(e.total_hospedaje)}</b><span>Extras y consumos</span><b>${money(e.consumo)}</b><span>Pagado</span><b>${money(e.pagado)}</b><span>${e.saldo > 0.009 ? 'Falta cobrar' : 'Saldo'}</span><b class="big" style="color:${e.saldo > 0.009 ? 'var(--ocup)' : 'var(--libre)'}">${money(e.saldo)}</b></div>`,
  `<button class="btn" onclick="mTicket(${e.id},'${act ? 'CUENTA' : e.cancelada ? 'CANCELADA' : 'SALIDA'}')">${ico('ticket')}Ticket</button>`
    + (act ? `<button class="btn bad op" onclick="mCancelar(${e.id})">Cancelar entrada</button><button class="btn pri op" onclick="mSalida(${e.id})">${ico('salir')}${e.saldo > 0.009 ? 'Cobrar ' + money(e.saldo) + ' y dar salida' : 'Registrar salida'}</button>` : ''), true);
  if (act) { clearInterval(mCuenta.t); mCuenta.t = setInterval(() => { const el = $('#mcR'); if (!el) return clearInterval(mCuenta.t); const f = aF(el.dataset.sal) - ahoraS(); el.textContent = f < 0 ? '+' + dur(f) : dur(f); }, 1000); }
}
verEstancia = mCuenta; // cualquier pantalla vieja que abra la cuenta usa la del motel
const volverCuenta = (id) => `<button class="btn" onclick="mCuenta(${id})">Volver</button>`;
// Cobro opcional: devuelve los datos del pago o null si se canceló. "cuenta" = se carga a la cuenta sin cobrar.
async function cobroOpcional(monto, titulo, detalle) {
  const ahora = document.querySelector('input[name=mxC]:checked')?.value !== 'cuenta';
  if (!ahora || !(monto > 0)) return { cobrar: false, imprimir: false };
  const r = await ventanaCobro({ total: monto, titulo, detalle, notas: false });
  if (!r) return null;
  return { cobrar: true, metodo: 'mixto', partes: r.partes, imprimir: r.imprimir };
}
const segCobro = (def = 'ahora') => `<div class="seg mcob"><label><input type="radio" name="mxC" value="ahora" ${def === 'ahora' ? 'checked' : ''}><span>${ico('dinero')} Cobrar ahora</span></label><label><input type="radio" name="mxC" value="cuenta" ${def === 'cuenta' ? 'checked' : ''}><span>${ico('salir')} Cargar a la cuenta</span></label></div>`;
const terminar = async (id, r, txt, pago, imp) => { if (pago?.cambio > 0) toast('Entregue de cambio ' + money(pago.cambio)); await mCuenta(id); vHab(); pintarTurno(); if (imp) mTicket(id, txt, pago); };

// Tiempo extra por horas
function mTiempo(id) {
  const e = mCuenta.e, p = Number(e.precio_hora_extra) || 0;
  if (!(p > 0) && !puede('autorizar')) return toast('Este tipo de habitación no tiene precio de hora extra. Póngalo en Configuración → Tipos y tarifas.', true);
  modal(`Tiempo extra · Hab. ${esc(e.habitacion.numero)}`, `<div class="lbl">¿Cuántas horas más?</div>
    <div class="seg mhoras">${[1, 2, 3, 4, 5, 6].map((n) => `<label><input type="radio" name="mxH" value="${n}" ${n === 1 ? 'checked' : ''} onchange="mxCalc()"><span>${n} h</span><small>${money(p * n)}</small></label>`).join('')}</div>
    ${puede('autorizar') ? `<label class="l">Precio por hora (solo gerente)<input id="mxP" type="number" min="0" step="0.01" value="${p.toFixed(2)}" oninput="mxCalc()"></label>` : ''}
    ${segCobro()}<div class="calc" id="mxR"></div>`,
  `${volverCuenta(id)}<button class="btn pri" onclick="mTiempoOk(${id})">Agregar tiempo</button>`);
  mxCalc();
}
function mxCalc() {
  const e = mCuenta.e, n = Number(document.querySelector('input[name=mxH]:checked')?.value) || 1, p = $('#mxP') ? num('mxP') : Number(e.precio_hora_extra) || 0;
  const desde = aF(e.salida_prevista) < ahoraS() ? ahoraS() : aF(e.salida_prevista), sal = new Date(desde.getTime() + n * 3600000);
  mxCalc.t = p * n; $('#mxR').innerHTML = `<span>${n} h × ${money(p)}</span><b class="big">${money(p * n)}</b><span>Nueva salida</span><b>${diaHora(fechaHoraLocal(sal))}</b>`;
}
async function mTiempoOk(id) {
  const e = mCuenta.e, n = Number(document.querySelector('input[name=mxH]:checked')?.value) || 1;
  const c = await cobroOpcional(mxCalc.t, `Tiempo extra · Hab. ${e.habitacion.numero}`, `${n} hora(s)`); if (!c) return;
  const r = await hacer(() => POST(`/api/motel/estancia/${id}/tiempo`, { horas: n, precio: $('#mxP') ? val('mxP') : undefined, ...c }), 'Tiempo agregado');
  terminar(id, r, 'TIEMPO EXTRA', r.pago, c.imprimir);
}
// Otra tarifa completa
function mRenovar(id) {
  const e = mCuenta.e, t = e.tipo;
  modal(`Otra tarifa · Hab. ${esc(e.habitacion.numero)}`, `<p class="sub" style="margin-top:0">Se suma otra tarifa completa a partir de la hora de salida${aF(e.salida_prevista) < ahoraS() ? ' (ya pasó: cuenta desde ahora)' : ''}. Sirve también para pasar de horas a noche.</p>
    <div class="seg mtar">${t.tarifas.map((x, i) => `<label style="--c:${esc(t.color)}"><input type="radio" name="mxT" value="${esc(x.id)}" ${(x.id === e.tarifa_id || (!t.tarifas.some((y) => y.id === e.tarifa_id) && !i)) ? 'checked' : ''} onchange="mrCalc()"><span>${esc(x.nombre)}</span><b>${money(x.precio)}</b><small>${tarifaTxt(x)}</small></label>`).join('')}</div>
    ${segCobro()}<div class="calc" id="mxR"></div>`,
  `${volverCuenta(id)}<button class="btn pri" onclick="mRenovarOk(${id})">Agregar tarifa</button>`);
  mrCalc();
}
function mrCalc() {
  const e = mCuenta.e, tf = e.tipo.tarifas.find((x) => x.id === document.querySelector('input[name=mxT]:checked')?.value) || e.tipo.tarifas[0];
  const desde = aF(e.salida_prevista) < ahoraS() ? ahoraS() : aF(e.salida_prevista);
  const sal = salidaDe(tf, desde);
  mrCalc.tf = tf; $('#mxR').innerHTML = `<span>${esc(tf.nombre)}</span><b class="big">${money(tf.precio)}</b><span>Nueva salida</span><b>${diaHora(fechaHoraLocal(sal))}</b>`;
}
async function mRenovarOk(id) {
  const e = mCuenta.e, tf = mrCalc.tf;
  const c = await cobroOpcional(tf.precio, `Otra tarifa · Hab. ${e.habitacion.numero}`, tf.nombre); if (!c) return;
  const r = await hacer(() => POST(`/api/motel/estancia/${id}/renovar`, { tarifa_id: tf.id, ...c }), 'Tarifa agregada');
  terminar(id, r, 'OTRA TARIFA', r.pago, c.imprimir);
}
// Persona extra
function mPersona(id) {
  const e = mCuenta.e, p = Number(e.precio_persona_extra) || 0;
  modal(`Persona extra · Hab. ${esc(e.habitacion.numero)}`, `<div class="lbl">¿Cuántas personas más?</div>
    <div class="seg mhoras">${[1, 2, 3, 4].map((n) => `<label><input type="radio" name="mxN" value="${n}" ${n === 1 ? 'checked' : ''} onchange="$('#mxR').innerHTML='<span>Total</span><b class=big>'+money(${p}*this.value)+'</b>'"><span>${n}</span><small>${money(p * n)}</small></label>`).join('')}</div>
    ${p > 0 ? segCobro() : '<div class="aviso">Este tipo de habitación no cobra persona extra: solo se anota.</div>'}<div class="calc" id="mxR"><span>Total</span><b class="big">${money(p)}</b></div>`,
  `${volverCuenta(id)}<button class="btn pri" onclick="mPersonaOk(${id})">Agregar</button>`);
}
async function mPersonaOk(id) {
  const e = mCuenta.e, n = Number(document.querySelector('input[name=mxN]:checked')?.value) || 1;
  const c = await cobroOpcional((Number(e.precio_persona_extra) || 0) * n, `Persona extra · Hab. ${e.habitacion.numero}`, `${n} persona(s)`); if (!c) return;
  const r = await hacer(() => POST(`/api/motel/estancia/${id}/persona`, { cantidad: n, ...c }), 'Persona extra agregada');
  terminar(id, r, 'PERSONA EXTRA', r.pago, c.imprimir);
}
// Cambio de habitación
function mCambiar(id) {
  const e = mCuenta.e, libres = sortH(MT.habitaciones.filter((h) => estadoM(h) === 'libre'));
  if (!libres.length) return toast('No hay habitaciones disponibles', true);
  const dif = (h) => { const tf = h.tipo?.tarifas.find((t) => t.nombre === e.tarifa); return tf && h.tipo_id !== e.tipo_id ? tf.precio - e.precio : 0; };
  modal(`Cambiar de habitación · ${esc(e.habitacion.numero)}`, `<div class="lbl">Habitación nueva</div>
    <div class="seg mlibres">${libres.map((h) => `<label style="--c:${esc(h.tipo?.color || '#64748b')}"><input type="radio" name="mxH" value="${h.id}" data-dif="${dif(h)}" onchange="mcCalc()"><span>${esc(h.numero)}</span><small>${esc(h.tipo?.nombre || '')}${dif(h) > 0 ? ' · +' + money(dif(h)) : ''}</small></label>`).join('')}</div>
    <label class="l">Motivo *<input id="mxM" placeholder="Ej. no sirve el aire, quiere jacuzzi"></label>
    <div id="mxD"></div>`,
  `${volverCuenta(id)}<button class="btn pri" onclick="mCambiarOk(${id})">Cambiar</button>`);
}
function mcCalc() {
  const i = document.querySelector('input[name=mxH]:checked'), d = Number(i?.dataset.dif) || 0;
  $('#mxD').innerHTML = d > 0 ? `<div class="aviso">La habitación nueva es de un tipo más caro: diferencia de <b>${money(d)}</b>.</div>${segCobro()}` : d < 0 ? '<div class="sub">La nueva es más barata: no se devuelve la diferencia.</div>' : '';
}
async function mCambiarOk(id) {
  const e = mCuenta.e, i = document.querySelector('input[name=mxH]:checked'); if (!i) return toast('Elija la habitación nueva', true);
  if (!val('mxM')) return toast('Escriba el motivo', true);
  const d = Number(i.dataset.dif) || 0, c = d > 0 ? await cobroOpcional(d, `Cambio de habitación`, `Diferencia ${e.habitacion.numero} → nueva`) : { cobrar: false };
  if (!c) return;
  const r = await hacer(() => POST(`/api/motel/estancia/${id}/cambiar`, { habitacion_id: i.value, motivo: val('mxM'), ...c }), 'Habitación cambiada');
  terminar(id, r, 'CAMBIO DE HABITACIÓN', r.pago, c.imprimir);
}
// Abono / cobrar lo que debe
function mAbono(id) {
  const e = mCuenta.e;
  modal(`Cobrar · Hab. ${esc(e.habitacion.numero)}`, `<label class="l">Monto<input id="mxA" type="number" min="0" step="0.01" value="${e.saldo > 0 ? e.saldo.toFixed(2) : ''}"></label><div class="sub">Debe ${money(e.saldo)}</div>`,
    `${volverCuenta(id)}<button class="btn pri" onclick="mAbonoOk(${id})">Cobrar</button>`);
}
async function mAbonoOk(id) {
  const e = mCuenta.e, m = num('mxA'); if (!(m > 0)) return toast('Escriba el monto', true);
  const r0 = await ventanaCobro({ total: m, titulo: `Cobro · Hab. ${e.habitacion.numero}`, notas: false }); if (!r0) return;
  const r = await hacer(() => POST(`/api/estancias/${id}/pago`, { monto: m, metodo: 'mixto', partes: r0.partes }), 'Cobrado');
  terminar(id, r, 'ABONO', r, r0.imprimir);
}
// Multa o cargo
function mCargo(id) {
  const M = multasCfg(), e = mCuenta.e;
  modal(`Multa o cargo · Hab. ${esc(e.habitacion.numero)}`, `<div class="seg mmul">${M.map((m, i) => `<label><input type="radio" name="mxG" value="${i}" onchange="$('#mxD2').value=this.dataset.n;$('#mxM2').value=this.dataset.m" data-n="${esc(m.nombre)}" data-m="${m.monto || ''}"><span>${esc(m.nombre)}</span><small>${m.monto ? money(m.monto) : ''}</small></label>`).join('')}
      <label><input type="radio" name="mxG" value="otro" onchange="$('#mxD2').value='';$('#mxM2').value=''"><span>Otro cargo</span><small>escribir</small></label></div>
    <div class="f"><label class="l">Descripción<input id="mxD2"></label><label class="l">Monto<input id="mxM2" type="number" min="0" step="0.01"></label></div>
    <label class="l">Nota (qué pasó)<input id="mxN2"></label>${segCobro('cuenta')}`,
  `${volverCuenta(id)}<button class="btn pri" onclick="mCargoOk(${id})">Guardar</button>`);
}
async function mCargoOk(id) {
  const e = mCuenta.e, g = document.querySelector('input[name=mxG]:checked')?.value, m = num('mxM2');
  if (!g) return toast('Elija qué se cobra', true); if (!(m > 0)) return toast('Escriba el monto', true);
  const c = await cobroOpcional(m, `Cargo · Hab. ${e.habitacion.numero}`, val('mxD2')); if (!c) return;
  const r = await hacer(() => POST(`/api/estancias/${id}/cargo`, { tipo: g === 'otro' ? 'otro' : 'multa', descripcion: val('mxD2'), cantidad: 1, monto: m, nota: val('mxN2'), ...c }), c.cobrar ? 'Cobrado' : 'Cargado a la cuenta');
  terminar(id, r, 'CARGO', r.pago, c.imprimir);
}
async function mCargoQuitar(cid, id) { await hacer(() => DEL('/api/cargos/' + cid), 'Cargo quitado'); mCuenta(id); vHab(); }
// Placas y datos
function mEditar(id) {
  const e = mCuenta.e;
  modal(`Placas y datos · Hab. ${esc(e.habitacion.numero)}`, `<div class="seg mlleg">${Object.entries(LLEGA).map(([k, n]) => `<label><input type="radio" name="mxL" value="${k}" ${k === (e.llegada || 'auto') ? 'checked' : ''}><span>${ico(LLEGA_I[k])} ${n}</span></label>`).join('')}</div>
    <div class="f"><label class="l">Placas<input id="mxPl" value="${esc(e.placas || '')}" style="text-transform:uppercase;font-family:var(--fMono)"></label><label class="l">Vehículo<input id="mxVe" value="${esc(e.vehiculo || '')}"></label>
      <label class="l">Nombre<input id="mxNo" value="${esc(/^Placas |^Cliente$/.test(e.huesped) ? '' : e.huesped)}"></label><label class="l">Notas<input id="mxNt" value="${esc(e.notas || '')}"></label></div>`,
  `${volverCuenta(id)}<button class="btn pri" onclick="mEditarOk(${id})">Guardar</button>`);
}
async function mEditarOk(id) {
  await hacer(() => PUT('/api/motel/estancia/' + id, { llegada: document.querySelector('input[name=mxL]:checked')?.value, placas: val('mxPl'), vehiculo: val('mxVe'), nombre: val('mxNo'), notas: val('mxNt') }), 'Guardado');
  mCuenta(id); vHab();
}
// Servicio a la habitación (productos de la tienda)
let MS = null;
async function mServicio(id) {
  const e = mCuenta.e, prods = (await GET('/api/productos')).filter((p) => p.servicio || p.existencia > 0);
  MS = { id, e, prods, items: [], area: '', q: '' };
  modal(`Servicio a la habitación · ${esc(e.habitacion.numero)}`, `<div class="ms"><div class="ms-izq"><div class="scan">${ico('buscar')}<input id="msQ" placeholder="Buscar o escanear producto" autocomplete="off" oninput="MS.q=this.value;msPintar()" onkeydown="if(event.key==='Enter'){msEnter();event.preventDefault()}"></div>
      <div class="tabs" id="msA"></div><div class="ms-prods" id="msP"></div></div>
      <div class="ms-der"><div class="lbl">Pedido</div><div id="msL"></div><div class="calc"><span>Total</span><b class="big" id="msT">$0.00</b></div>${segCobro('cuenta')}</div></div>`,
  `${volverCuenta(id)}<button class="btn pri" onclick="mServicioOk()">Guardar pedido</button>`, true);
  msPintar(); setTimeout(() => $('#msQ')?.focus(), 50);
}
function msPintar() {
  const areas = [...new Set(MS.prods.map((p) => p.area || 'Otros'))].sort();
  $('#msA').innerHTML = areas.length > 1 ? [['', 'Todo'], ...areas.map((a) => [a, a])].map(([k, n]) => `<button class="${MS.area === k ? 'on' : ''}" onclick="MS.area=this.dataset.a;msPintar()" data-a="${esc(k)}">${esc(n)}</button>`).join('') : '';
  const q = MS.q.trim().toLowerCase(), l = MS.prods.filter((p) => (!MS.area || (p.area || 'Otros') === MS.area) && (!q || p.nombre.toLowerCase().includes(q) || String(p.codigo || '').toLowerCase() === q));
  $('#msP').innerHTML = l.slice(0, 60).map((p) => `<button class="ms-p" onclick="msAgregar(${p.id})"><b>${esc(p.nombre)}</b><span>${money(p.precio)}</span>${p.servicio ? '' : `<small>${p.existencia} en existencia</small>`}</button>`).join('') || '<div class="sub" style="grid-column:1/-1">No hay productos con existencia. Agréguelos en Inventario.</div>';
  $('#msL').innerHTML = MS.items.length ? MS.items.map((it, i) => `<div class="ms-it"><span>${esc(it.p.nombre)}</span><div class="mcont sm"><button class="btn sm" onclick="msCant(${i},-1)" aria-label="Menos">${ico('menos')}</button><b>${it.c}</b><button class="btn sm" onclick="msCant(${i},1)" aria-label="Más">${ico('mas')}</button></div><b>${money(it.c * it.p.precio)}</b></div>`).join('') : '<div class="sub">Toque los productos para agregarlos.</div>';
  MS.total = MS.items.reduce((s, it) => s + it.c * it.p.precio, 0); $('#msT').textContent = money(MS.total);
}
function msAgregar(pid) { const p = MS.prods.find((x) => x.id === pid), it = MS.items.find((x) => x.p.id === pid); if (it) { if (!p.servicio && it.c >= p.existencia) return toast('Solo hay ' + p.existencia, true); it.c++; } else MS.items.push({ p, c: 1 }); msPintar(); }
function msCant(i, d) { const it = MS.items[i]; it.c += d; if (!it.p.servicio && it.c > it.p.existencia) it.c = it.p.existencia; if (it.c <= 0) MS.items.splice(i, 1); msPintar(); }
function msEnter() { const q = MS.q.trim().toLowerCase(), p = MS.prods.find((x) => String(x.codigo || '').toLowerCase() === q) || (MS.prods.filter((x) => x.nombre.toLowerCase().includes(q)).length === 1 ? MS.prods.find((x) => x.nombre.toLowerCase().includes(q)) : null); if (p) { msAgregar(p.id); $('#msQ').value = ''; MS.q = ''; msPintar(); } }
async function mServicioOk() {
  if (!MS.items.length) return toast('El pedido está vacío', true);
  const e = MS.e, ahora = document.querySelector('input[name=mxC]:checked')?.value !== 'cuenta';
  let r0 = null;
  if (ahora) { r0 = await ventanaCobro({ total: MS.total, titulo: `Servicio · Hab. ${e.habitacion.numero}`, notas: false }); if (!r0) return; }
  const v = await hacer(() => POST('/api/ventas', { items: MS.items.map((it) => ({ producto_id: it.p.id, cantidad: it.c })), metodo: ahora ? 'mixto' : 'habitacion', habitacion_id: ahora ? undefined : e.habitacion_id, partes: r0?.partes, nota: 'Servicio a la habitación ' + e.habitacion.numero }), ahora ? 'Cobrado' : 'Cargado a la cuenta');
  if (v?.cambio > 0) toast('Entregue de cambio ' + money(v.cambio));
  const id = MS.id; MS = null; await mCuenta(id); vHab(); pintarTurno();
  if (!ahora || r0?.imprimir) mComanda(v, e);
}
// Comanda del servicio (para quien lo lleva a la habitación) con el número grande
function mComanda(v, e) {
  const w = W(), num = String(e.habitacion.numero);
  const lineas = [...v.items.map((i) => lin(i.cantidad + ' ' + i.descripcion, money(i.importe))), '-'.repeat(w), lin('TOTAL', money(v.total)), v.metodo === 'habitacion' ? 'Cargado a la cuenta de la habitación' : 'PAGADO', '', fdt(v.fecha) + '  Folio ' + v.folio];
  const ops = async () => [...encOps(), ['align', 'center'], ['text', 'SERVICIO A LA HABITACION'], ['size', 3], ['text', 'HAB. ' + num], ['size', 1], ['align', 'left'], ['text', '-'.repeat(w)], ...lineas.map((l) => ['text', l])];
  imprimirDoc(`<pre class="tk">${esc(encabezado().join('\n'))}\nSERVICIO A LA HABITACIÓN</pre><div class="tk-num">HAB. ${esc(num)}</div><pre class="tk">${esc(lineas.join('\n'))}</pre>`, ancho(), 'Servicio a la habitación', ops);
}
// Salida
async function mSalida(id) {
  const e = mCuenta.e;
  let c = { imprimir: CFG.imprimir_auto !== '0' };
  if (e.saldo > 0.009) {
    const r = await ventanaCobro({ total: e.saldo, titulo: `Salida · Hab. ${e.habitacion.numero}`, detalle: `${e.tarifa || ''}${e.placas ? ' · ' + e.placas : ''}`, notas: false });
    if (!r) return; c = { metodo: 'mixto', partes: r.partes, imprimir: r.imprimir };
  }
  const r = await hacer(() => POST(`/api/motel/estancia/${id}/salida`, c), 'Salida registrada');
  if (r?.pago?.cambio > 0) toast('Entregue de cambio ' + money(r.pago.cambio));
  cerrar(); await vHab(); pintarTurno();
  if (c.imprimir && (r.pago || e.saldo <= 0.009)) mTicket(id, 'SALIDA', r.pago);
}
// Cancelar entrada
function mCancelar(id) {
  const e = mCuenta.e, lim = Number(CFG.motel_cancel_min) || 15, min = Math.floor((ahoraS() - aF(e.entrada)) / 60000);
  const clave = !puede('autorizar');
  modal(`Cancelar entrada · Hab. ${esc(e.habitacion.numero)}`, `
    ${min > lim ? `<div class="aviso bad">Ya pasaron ${min} minutos (el límite es ${lim}). Solo el administrador puede cancelarla; si el cliente ya usó la habitación registre la salida.</div>` : `<div class="aviso">Entró hace ${min} minutos. Se puede cancelar hasta ${lim} minutos después de la entrada.</div>`}
    <div class="lbl">Motivo *</div><div class="seg mmul">${['Se equivocó de habitación', 'El cliente no se quedó', 'Error al registrar', 'Habitación con falla'].map((m) => `<label><input type="radio" name="mxCm" value="${esc(m)}" onchange="$('#mxCo').value=this.value"><span>${esc(m)}</span></label>`).join('')}</div>
    <label class="l">Motivo (escriba o elija)<input id="mxCo"></label>
    ${e.pagado > 0 ? `<label class="row" style="font-weight:600"><input type="checkbox" id="mxDv" checked> Devolver lo cobrado: ${money(e.pagado)}</label>` : ''}
    <div class="seg"><label><input type="radio" name="mxLi" value="1" checked><span>La habitación queda sucia</span></label><label><input type="radio" name="mxLi" value="0"><span>No la usaron: queda disponible</span></label></div>
    ${clave ? `<div class="card autoriza"><div class="lbl">${ico('llave')} Autoriza el gerente o el administrador</div><div class="f"><label class="l">Usuario<input id="mxAu" autocomplete="off" autocapitalize="off"></label><label class="l">Contraseña<input id="mxAp" type="password" autocomplete="new-password"></label></div></div>` : ''}`,
  `${volverCuenta(id)}<button class="btn bad" onclick="mCancelarOk(${id})">Cancelar la entrada</button>`);
}
async function mCancelarOk(id) {
  if (!val('mxCo')) return toast('Escriba el motivo', true);
  const r = await hacer(() => POST(`/api/motel/estancia/${id}/cancelar`, { motivo: val('mxCo'), devolver: $('#mxDv') ? $('#mxDv').checked : false, limpiar: document.querySelector('input[name=mxLi]:checked')?.value !== '0',
    autoriza: $('#mxAu') ? { usuario: val('mxAu'), password: $('#mxAp').value } : undefined }), 'Entrada cancelada');
  if (r.devuelto > 0) toast('Devuelva al cliente ' + money(r.devuelto));
  cerrar(); await vHab(); pintarTurno(); mTicket(id, 'CANCELADA');
}

// ---------- Ticket del motel: el número de la habitación sale GRANDE (para la cámara) ----------
async function mTicket(id, titulo, pago) {
  const e = await GET('/api/motel/estancia/' + id), w = W(), num = String(e.habitacion.numero), grande = CFG.motel_numero_grande !== '0';
  const L = [lin(titulo, 'Folio ' + e.folio), lin('Tipo', e.tipo?.nombre || ''), lin('Tarifa', e.tarifa || ''), lin('Entrada', fdt(e.entrada)),
    e.activa ? lin('Salida', fdt(e.salida_prevista)) : lin(e.cancelada ? 'Cancelada' : 'Salió', fdt(e.salida_real)),
    ...(e.placas ? [lin('Placas', e.placas)] : []), ...(e.vehiculo ? [lin('Vehículo', e.vehiculo.slice(0, 24))] : []), lin('Personas', String(e.personas)), '-'.repeat(w),
    ...e.rentas.filter((r) => r.importe > 0).map((r) => lin(r.tipo === 'cambio' ? 'Diferencia cambio hab.' : r.tipo === 'entrada' ? 'Hospedaje' : 'Otra tarifa', money(r.importe))),
    ...(e.descuento > 0 ? [lin('Descuento', '-' + money(e.descuento))] : []),
    ...e.cargos.map((c) => lin((c.cantidad > 1 && c.tipo === 'consumo' ? c.cantidad + ' ' : '') + c.descripcion, money(c.importe))), '-'.repeat(w),
    lin('TOTAL', money(e.total_hospedaje + e.consumo)), lin('PAGADO', money(e.pagado)), ...(e.saldo > 0.009 ? [lin('FALTA COBRAR', money(e.saldo))] : []), ...lineasPago(pago),
    ...(e.cancelada ? ['', ...wrapT('Motivo: ' + (e.cancel_motivo || '')), ...(e.cancel_devuelto ? [lin('Devuelto', money(e.cancel_devuelto))] : [])] : []), '', CFG.ticket_pie || ''];
  const ops = async () => [...encOps(), ...(grande ? [['align', 'center'], ['bold', true], ['text', 'HABITACION'], ['size', num.length > 3 ? 3 : 4], ['text', num], ['size', 1], ['bold', false], ['align', 'left']] : [['text', lin('Habitación', num)]]), ['text', '-'.repeat(w)], ...L.map((l) => ['text', l])];
  imprimirDoc(`<pre class="tk">${esc(encabezado().join('\n'))}</pre>${grande ? `<div class="tk-num"><small>HABITACIÓN</small>${esc(num)}</div>` : `<pre class="tk">${esc(lin('Habitación', num))}</pre>`}<pre class="tk">${esc('-'.repeat(w) + '\n' + L.join('\n'))}</pre>`, ancho(), 'Ticket · Hab. ' + num, ops);
}
imprimirEstancia = (id, titulo, pago) => mTicket(id, titulo, pago);

// ---------- Cambiar mi PIN / contraseña desde el menú (sin entrar a Configuración) ----------
{
  const _marco = marco;
  marco = function (...a) {
    const r = _marco.apply(this, a);
    $('.pie button[onclick="salir()"]')?.insertAdjacentHTML('beforebegin', `<button class="pie-pin" onclick="miPin()" title="Cambiar mi PIN o contraseña">${ico('llave')} Cambiar mi PIN</button>`);
    return r;
  };
}
function miPin() {
  modal(`Cambiar mi PIN · ${esc(YO.nombre)}`, `<p class="sub" style="margin-top:0">Puede usar solo números o letras y números. Mínimo 6.</p>
    <div class="stack" style="gap:10px"><label class="l">PIN o contraseña actual<input id="mpA" type="password" autocomplete="current-password"></label>
    <label class="l">PIN o contraseña nueva<input id="mpN" type="password" autocomplete="new-password" oninput="mpRev()"></label>
    <label class="l">Escríbala otra vez<input id="mpC" type="password" autocomplete="new-password" oninput="mpRev()" onkeydown="if(event.key==='Enter')miPinOk()"></label>
    <label class="row" style="font-weight:600"><input type="checkbox" onchange="document.querySelectorAll('#mpA,#mpN,#mpC').forEach((i)=>i.type=this.checked?'text':'password')"> Mostrar</label><div id="mpM" class="sub"></div></div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="miPinOk()">Cambiar</button>`);
  setTimeout(() => $('#mpA')?.focus(), 50);
}
function mpRev() {
  const n = $('#mpN').value, c = $('#mpC').value, el = $('#mpM');
  el.innerHTML = !n ? '' : n.length < 6 ? '<span class="malo">Faltan ' + (6 - n.length) + ' caracteres</span>' : c && c !== n ? '<span class="malo">No coinciden</span>' : c ? '<span style="color:var(--libre);font-weight:700">Coinciden</span>' : '';
}
async function miPinOk() {
  const n = $('#mpN').value;
  if (n.length < 6) return toast('El PIN nuevo debe tener al menos 6 caracteres', true);
  if (n !== $('#mpC').value) return toast('El PIN nuevo no coincide', true);
  await hacer(() => POST('/api/mi-password', { actual: $('#mpA').value, nueva: n }), 'PIN cambiado');
  cerrar();
}

// ---------- Plumas de entrada / salida y visitas (Uber, taxi, carro, a pie) ----------
const MEDIOS = { uber: 'Uber / DiDi', taxi: 'Taxi', auto: 'En carro', pie: 'A pie', moto: 'Moto', repartidor: 'Repartidor', otro: 'Otro' };
const MEDIO_I = { uber: 'auto', taxi: 'auto', auto: 'auto', pie: 'persona', moto: 'auto', repartidor: 'bolsa', otro: 'persona' };
P.pluma = '<path d="M3 20h4M5 20V9"/><rect x="3" y="7" width="4" height="3" rx="1"/><path d="M7 8.5h14"/><path d="M10 8.5v1.5M13 8.5v1.5M16 8.5v1.5M19 8.5v1.5"/>';
let PLUMAS = { entrada: false, salida: false };
const avisoPluma = (r) => { if (!r?.pluma) return; if (r.pluma.ok) toast(`Pluma de ${r.pluma.pluma} abierta`); else toast('No abrió la pluma: ' + r.pluma.error, true); };
{
  const _vh = vHab;
  vHab = async function (...a) {
    try { PLUMAS = await GET('/api/motel/plumas'); } catch { /* sin plumas */ }
    await _vh.apply(this, a);
    const acc = $('#main .top .row'); if (!acc || !puede('registrar')) return;
    acc.insertAdjacentHTML('afterbegin', `<button class="btn" onclick="visitaGeneral()">${ico('personas')} Visita / Uber</button>`
      + (PLUMAS.entrada ? `<button class="btn" onclick="plumaManual('entrada')">${ico('pluma')} Abrir pluma entrada</button>` : '')
      + (PLUMAS.salida ? `<button class="btn" onclick="plumaManual('salida')">${ico('pluma')} Abrir pluma salida</button>` : ''));
  };
  // Las tarjetas ocupadas muestran cuántas visitas están adentro
  const _tm = tarjetaM;
  tarjetaM = function (h) { let html = _tm(h); const n = h.estancia?.visitas_dentro; if (n) html = html.replace('</button>', `<div class="mt-vis">${ico('personas')} ${n} visita${n === 1 ? '' : 's'} adentro</div></button>`); return html; };
}
// Abrir la pluma a mano: siempre con motivo (queda en reportes)
function plumaManual(cual) {
  const oc = sortH((MT?.habitaciones || []).filter((h) => h.estancia));
  const motivos = cual === 'entrada' ? ['Uber / DiDi a dejar', 'Taxi a dejar', 'Proveedor', 'Empleado', 'Repartidor', 'Otro'] : ['Sale Uber / DiDi', 'Sale taxi', 'Proveedor', 'Empleado', 'Repartidor', 'Otro'];
  modal(`Abrir pluma de ${cual}`, `<div class="lbl">¿Por qué se abre?</div><div class="seg mmul">${motivos.map((m, i) => `<label><input type="radio" name="plM" value="${esc(m)}" ${i ? '' : 'checked'}><span>${esc(m)}</span></label>`).join('')}</div>
    <div class="f"><label class="l">Habitación (opcional)<select id="plH"><option value="">—</option>${oc.map((h) => `<option value="${h.id}">${esc(h.numero)}${h.estancia.placas ? ' · ' + esc(h.estancia.placas) : ''}</option>`).join('')}</select></label><label class="l">Nota<input id="plN" placeholder="Opcional"></label></div>
    <div class="sub">Cada vez que se abre a mano queda anotado con su motivo y quién la abrió (Reportes → Plumas).</div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="plumaManualOk('${cual}')">${ico('pluma')} Abrir pluma</button>`);
}
async function plumaManualOk(cual) {
  const m = document.querySelector('input[name=plM]:checked')?.value || 'Otro';
  await hacer(() => POST('/api/motel/pluma', { pluma: cual, motivo: m + (val('plN') ? ' · ' + val('plN') : ''), habitacion_id: val('plH') || undefined }), `Pluma de ${cual} abierta`);
  cerrar();
}
// Visita a una habitación: llega o se va (desde el tablero, eligiendo la habitación)
function visitaGeneral() {
  const oc = sortH((MT?.habitaciones || []).filter((h) => h.estancia));
  if (!oc.length) return toast('No hay habitaciones ocupadas', true);
  visitaModal(null, oc);
}
function visitaModal(eid, oc) {
  const e = eid ? mCuenta.e : null;
  modal(`Visita${e ? ' · Hab. ' + esc(e.habitacion.numero) : ''}`, `
    <div class="seg mcob"><label><input type="radio" name="viT" value="llega" checked onchange="viCalc()"><span>${ico('mas')} Llega una visita</span></label><label><input type="radio" name="viT" value="sale" onchange="viCalc()"><span>${ico('salir')} La visita se va</span></label></div>
    ${oc ? `<div class="lbl">Habitación</div><div class="seg mlibres">${oc.map((h) => `<label style="--c:${esc(h.tipo?.color || '#64748b')}"><input type="radio" name="viH" value="${h.estancia.id}"><span>${esc(h.numero)}</span><small>${h.estancia.visitas_dentro ? h.estancia.visitas_dentro + ' adentro' : esc(h.estancia.placas || '')}</small></label>`).join('')}</div>` : ''}
    <div class="lbl">¿Cómo llega o se va?</div><div class="seg mlleg">${Object.entries(MEDIOS).map(([k, n], i) => `<label><input type="radio" name="viM" value="${k}" ${i ? '' : 'checked'} onchange="viCalc()"><span>${ico(MEDIO_I[k])} ${n}</span></label>`).join('')}</div>
    <div class="f" id="viPl"><label class="l">Placas (opcional)<input id="viP" style="text-transform:uppercase;font-family:var(--fMono)"></label><label class="l">Nota<input id="viN" placeholder="Ej. nombre, color del carro"></label></div>
    <div class="sub" id="viR"></div>`,
  `${eid ? volverCuenta(eid) : '<button class="btn" onclick="cerrar()">Cancelar</button>'}<button class="btn pri" id="viOk" onclick="visitaOk(${eid || 0})">Registrar</button>`);
  viCalc();
}
function viCalc() {
  const t = document.querySelector('input[name=viT]:checked')?.value, cual = t === 'llega' ? 'entrada' : 'salida', on = PLUMAS[cual] && CFG.pluma_auto_visitas !== '0';
  $('#viOk').innerHTML = on ? `${ico('pluma')} Registrar y abrir pluma de ${cual}` : 'Registrar';
  $('#viR').textContent = on ? `Al registrar se abre la pluma de ${cual}.` : (PLUMAS[cual] ? '' : `La pluma de ${cual} no está configurada.`);
}
async function visitaOk(eid) {
  const id = eid || document.querySelector('input[name=viH]:checked')?.value; if (!id) return toast('Elija la habitación', true);
  const r = await hacer(() => POST(`/api/motel/estancia/${id}/visita`, { tipo: document.querySelector('input[name=viT]:checked').value, medio: document.querySelector('input[name=viM]:checked').value, placas: val('viP'), nota: val('viN') }), 'Visita registrada');
  avisoPluma(r);
  if (eid) mCuenta(eid); else cerrar();
  vHab();
}
// En la cuenta: botón Visita / Uber y la lista de visitas
{
  const _mc = mCuenta;
  mCuenta = async function (id, ...a) {
    await _mc.call(this, id, ...a);
    const e = mCuenta.e; if (!e) return;
    if (e.activa) $('#modal .macc')?.insertAdjacentHTML('afterbegin', `<button class="btn op" onclick="visitaModal(${e.id})">${ico('personas')}Visita / Uber${e.visitas_dentro ? ` (${e.visitas_dentro} adentro)` : ''}</button>`);
    if ((e.visitas_lista || []).length) $('#modal .calc')?.insertAdjacentHTML('beforebegin', `<div><div class="lbl">Visitas</div><div class="tw"><table><tbody>${e.visitas_lista.map((v) => `<tr><td>${fdt(v.fecha)}</td><td>${v.tipo === 'llega' ? 'Llegó' : 'Se fue'}</td><td>${esc(MEDIOS[v.medio] || v.medio)}</td><td>${esc(v.placas || '')} <span class="sub">${esc(v.nota || '')}</span></td></tr>`).join('')}</tbody></table></div></div>`);
  };
  verEstancia = mCuenta;
}
// Entrada y salida: avisan si abrió la pluma
{
  const _api = api;
  api = async function (m, u, b) {
    const r = await _api.call(this, m, u, b);
    if (m === 'POST' && /\/api\/motel\/(entrada|estancia\/\d+\/salida)$/.test(u)) setTimeout(() => avisoPluma(r), 1500);
    return r;
  };
}
