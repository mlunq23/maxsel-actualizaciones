// Maxsel Motel 1.1 — Actualizar el sistema por internet (Configuración → Respaldos y licencia), igual que Maxsel POS
{
  const _cr = cResp;
  cResp = async function () {
    await _cr();
    if (typeof cfgTab !== 'undefined' && cfgTab !== 'resp') return;
    const st = $('#cfgc .stack'); if (!st || $('#updCard')) return;
    st.insertAdjacentHTML('afterbegin', `<div class="card" id="updCard"><div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
      <h2 style="margin:0">Actualizaciones</h2><button class="btn pri" onclick="updBuscar()">⟳ Buscar actualización</button></div>
      <div id="updInfo" class="sub" style="margin-top:8px">${CFG.upd_disponible ? `Hay una versión nueva: <b>${esc(CFG.upd_disponible)}</b>. Toque "Buscar actualización".` : 'Necesita internet. La información del motel (entradas, ventas, licencia y respaldos) no se toca al actualizar.'}</div></div>`);
  };
}
async function updBuscar() {
  const box = $('#updInfo'); box.innerHTML = 'Buscando…';
  try {
    const v = await GET('/api/actualizacion');
    CFG.upd_disponible = v.hay ? v.disponible : ''; pintarAvisoUpd();
    box.innerHTML = v.hay
      ? `<div class="aviso ok" style="margin:0"><b>Hay una versión nueva: ${esc(v.disponible)}</b> (tiene la ${esc(v.instalada)}).${v.notas ? `<br>${esc(v.notas)}` : ''}
         <div style="margin-top:10px"><button class="btn ok" onclick="updInstalar(this)">Instalar ahora</button></div>
         <div class="sub" style="margin-top:6px">Tarda menos de un minuto. El sistema se reinicia solo; los demás usuarios deben volver a entrar.</div></div>`
      : `Ya tiene la versión más reciente (<b>${esc(v.instalada)}</b>).`;
  } catch (e) { box.innerHTML = `<span style="color:var(--ocup)">${esc(e.message)}</span>`; }
}
async function updInstalar(b) {
  b.disabled = true; b.textContent = 'Descargando e instalando…';
  try {
    const r = await POST('/api/actualizacion/instalar');
    modal('Sistema actualizado', `<p>Se instaló la versión <b>${esc(r.a)}</b> (antes ${esc(r.de)}).</p>
      <p>${r.servicio ? 'El sistema se está reiniciando. En unos segundos toque "Volver a entrar".' : 'Cierre el sistema y vuelva a abrirlo.'}</p>`,
    '<button class="btn pri" onclick="location.reload()">Volver a entrar</button>');
  } catch (e) { b.disabled = false; b.textContent = 'Instalar ahora'; toast(e.message, true); }
}
// Aviso al administrador: un punto en "Configuración" cuando hay versión nueva
function pintarAvisoUpd() {
  if (!YO || YO.rol !== 'admin') return;
  ir.badge = { ...(ir.badge || {}), cfg: CFG.upd_disponible ? '1' : '' };
  try { pintarNav(ir.badge); } catch { /* nada */ }
}
{
  const _pn = pintarNav;
  pintarNav = function (b) { if (YO?.rol === 'admin' && CFG?.upd_disponible) b = { ...(b || {}), cfg: '1' }; return _pn(b); };
}
