// Maxsel Motel — horas en formato de 12 h siempre correctas (12:30 p.m. al mediodía, 12:30 a.m. a medianoche).
// Algunos navegadores de Windows con español de México muestran "00:30 p.m."; aquí la hora se arma a mano
// y ya no depende del navegador ni de la configuración regional de la computadora.
(() => {
  const p2 = (n) => String(n).padStart(2, '0');
  const esEs = (loc) => loc == null || /^es/i.test(Array.isArray(loc) ? loc[0] || '' : String(loc));
  const hora = (d, o) => {
    const h24 = d.getHours(), h = h24 % 12 || 12, ap = h24 < 12 ? 'a.m.' : 'p.m.';
    const hh = o && o.hour === '2-digit' ? p2(h) : String(h);
    const seg = !o || o.second ? ':' + p2(d.getSeconds()) : '';
    return `${hh}:${p2(d.getMinutes())}${seg} ${ap}`;
  };
  const tl = Date.prototype.toLocaleTimeString, ts = Date.prototype.toLocaleString;
  Date.prototype.toLocaleTimeString = function (loc, o) {
    if (isNaN(this) || !esEs(loc) || (o && (o.hour12 === false || o.hourCycle === 'h23' || !o.hour))) return tl.call(this, loc, o);
    return hora(this, o);
  };
  Date.prototype.toLocaleString = function (loc, o) {
    if (isNaN(this) || !esEs(loc) || o) return ts.call(this, loc, o);
    return this.toLocaleDateString(loc || 'es-MX') + ', ' + hora(this);
  };
})();
