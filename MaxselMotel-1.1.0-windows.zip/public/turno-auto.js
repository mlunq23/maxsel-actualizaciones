'use strict';
// Maxsel Motel: el ticket se imprime solo al cobrar, y si la caja está cerrada se abre sola la ventana de "Abrir turno"
// (al terminar de abrirlo, sigue el cobro donde se quedó).
const turnoListo = () => CFG.exigir_turno === '0' || !!(YO && YO.turno) || !puede('caja');
async function asegurarTurno() {
  if (turnoListo()) return true;
  try { await pintarTurno(); } catch { /* sin red */ } // por si el turno se abrió en otra ventana
  if (turnoListo()) return true;
  // Si el cobro viene de una ventana (registro, abono, visita, depósito…) se guarda tal cual para regresar a ella
  const m = $('#modal');
  const guardado = !m.hidden && m.firstChild ? { nodos: [...m.childNodes], sucio: m.dataset.sucio } : null;
  if (guardado) m.replaceChildren();
  const regresar = () => {
    if (!guardado) return;
    m.replaceChildren(...guardado.nodos);
    if (guardado.sucio !== undefined) m.dataset.sucio = guardado.sucio;
    m.hidden = false;
  };
  toast('Su caja está cerrada: abra su turno para poder cobrar');
  abrirTurno();
  return new Promise((ok) => {
    const vig = setInterval(async () => {
      if (YO && YO.turno) {
        // Ya se abrió: si quedó a la vista el comprobante de apertura (sin impresora), se cierra y sigue el cobro
        clearInterval(vig);
        if (!m.hidden && /apertura/i.test($('#modal h3')?.textContent || '')) cerrar();
        if (m.hidden) regresar();
        return ok(true);
      }
      if (!m.hidden) return; // sigue capturando el fondo o el tipo de cambio
      clearInterval(vig);
      try { await pintarTurno(); } catch { /* sin red */ }
      const sigue = !!(YO && YO.turno);
      regresar();
      ok(sigue);
    }, 250);
  });
}
{
  const _vc = ventanaCobro, _ok = vcOk;
  const auto = () => CFG.imprimir_auto !== '0';
  // Ticket automático: "Cobrar" siempre imprime (se puede apagar en Configuración → Caja)
  vcOk = function (imp) { return _ok(auto() ? true : imp); };
  const abrirVentana = (o) => {
    const r = _vc(o);
    if (auto()) {
      document.querySelector('#cobro .vc-b[onclick="vcOk(false)"]')?.remove();
      const p = document.querySelector('#cobro .vc-b.pri'); if (p) p.innerHTML = '<kbd>F1</kbd>Cobrar e imprimir ticket';
    }
    return r;
  };
  // Cualquier ventana de cobro (tienda, registro, abonos, salida, visitas, depósitos, cargos) revisa primero que haya turno abierto
  ventanaCobro = function (o) {
    if (turnoListo()) return abrirVentana(o);
    return asegurarTurno().then((sigue) => (sigue ? abrirVentana(o) : null));
  };
}
// Devolución del depósito: no usa la ventana de cobro pero saca dinero de la caja, también pide el turno
if (typeof liquidarOk === 'function') {
  const _liq = liquidarOk;
  liquidarOk = async function (...a) {
    if (num('lD') > 0 && !(await asegurarTurno())) return;
    return _liq.apply(this, a);
  };
}
