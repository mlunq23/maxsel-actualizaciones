// Maxsel Motel 1.0 — limpieza y recamareras, entradas por placas, reportes, caja/corte y configuración
'use strict';

// ======================================================================
// Limpieza
// ======================================================================
let lDesde = hoyISO(), lHasta = hoyISO();
async function vLimp() {
  const [d, hist, recs] = await Promise.all([GET('/api/motel/tablero'), GET(`/api/motel/limpiezas?desde=${lDesde}&hasta=${lHasta}`), GET('/api/motel/recamareras?todas=1')]);
  MT = d; TAB = d; MT_OFF = aF(d.ahora) - new Date();
  const sucias = sortH(d.habitaciones.filter((h) => h.estado === 'limpieza')), ya = ahoraS();
  const hoyRec = {}; for (const l of hist) { const k = l.recamarera || 'Sin anotar', x = hoyRec[k] || (hoyRec[k] = { n: 0, m: 0 }); x.n++; x.m += l.minutos || 0; }
  ir.badge = { ...(ir.badge || {}), limp: sucias.length || '' }; pintarNav(ir.badge);
  $('#main').innerHTML = cab('Limpieza', 'Habitaciones sucias, quién las limpia y cuánto tarda', puede('estados') ? `<button class="btn" onclick="recModal()">${ico('mas')} Agregar recamarera</button>` : '')
    + `<div class="card" style="margin-bottom:16px"><h2>Por limpiar ahora · ${sucias.length}</h2>${sucias.length ? `<div class="mgrid">${sucias.map(tarjetaM).join('')}</div>` : '<div class="empty">No hay habitaciones sucias. ¡Todo limpio!</div>'}</div>
    <div class="cols"><div class="card"><h2>Recamareras</h2><div class="tw"><table><thead><tr><th>Nombre</th><th class="n">Limpiezas</th><th class="n">Promedio</th><th></th></tr></thead><tbody>
      ${recs.map((r) => { const x = hoyRec[r.nombre]; return `<tr><td><b>${esc(r.nombre)}</b>${r.activo ? '' : ' <span class="pill">Baja</span>'}<div class="sub">${esc(r.telefono || '')}</div></td><td class="n">${x?.n || 0}</td><td class="n">${x ? durTxt(x.m / x.n) : '—'}</td><td>${puede('estados') ? `<button class="btn sm" onclick="recModal(${r.id})">Editar</button>` : ''}</td></tr>`; }).join('') || '<tr><td colspan="4" class="empty">Agregue a las recamareras para saber quién limpia cada habitación.</td></tr>'}</tbody></table></div>
      <div class="sub">Limpiezas y promedio del periodo elegido abajo.</div></div>
    <div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h2 style="margin:0">Limpiezas terminadas</h2><div class="row"><input type="date" id="ld" value="${lDesde}" style="width:auto"><input type="date" id="lh" value="${lHasta}" style="width:auto"><button class="btn sm" onclick="lDesde=val('ld');lHasta=val('lh');vLimp()">Ver</button></div></div>
      <div class="tw"><table><thead><tr><th>Hab.</th><th>Recamarera</th><th>Quedó sucia</th><th>Empezó</th><th>Terminó</th><th class="n">Tardó</th></tr></thead><tbody>
      ${hist.map((l) => `<tr><td><b>${esc(l.numero)}</b></td><td>${esc(l.recamarera || '—')}</td><td>${fdt(l.sucia)}</td><td>${l.inicio ? fdt(l.inicio) : '—'}</td><td>${fdt(l.fin)}</td><td class="n">${l.minutos != null ? durTxt(l.minutos) : '—'}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">Sin limpiezas en esas fechas.</td></tr>'}</tbody></table></div></div></div>`;
  void ya;
  clearInterval(mTick); mTick = setInterval(() => { if (vista !== 'limp') return clearInterval(mTick); document.querySelectorAll('.mt-reloj[data-desde]').forEach((el) => { if (el.dataset.desde) el.textContent = dur(ahoraS() - aF(el.dataset.desde)); }); }, 1000);
}
async function recModal(id) {
  const r = id ? (await GET('/api/motel/recamareras?todas=1')).find((x) => x.id === id) : { nombre: '', telefono: '', activo: 1 };
  modal(id ? 'Editar recamarera' : 'Agregar recamarera', `<div class="f"><label class="l">Nombre<input id="rcN" value="${esc(r.nombre)}"></label><label class="l">Teléfono<input id="rcT" value="${esc(r.telefono || '')}" inputmode="tel"></label></div>
    ${id ? `<label class="row" style="font-weight:600"><input type="checkbox" id="rcA" ${r.activo ? 'checked' : ''}> Trabaja aquí (quítela si ya no trabaja; su historial se conserva)</label>` : ''}`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="recOk(${id || 0})">Guardar</button>`);
}
async function recOk(id) {
  const b = { nombre: val('rcN'), telefono: val('rcT'), activo: $('#rcA') ? $('#rcA').checked : true };
  await hacer(() => (id ? PUT('/api/motel/recamareras/' + id, b) : POST('/api/motel/recamareras', b)), 'Guardado'); cerrar();
  if (vista === 'limp') vLimp(); else if (vista === 'cfg') vCfg(); else vHab();
}

// ======================================================================
// Entradas y placas (historial)
// ======================================================================
let eDesde = hoyISO(), eHasta = hoyISO(), eBus = '';
async function vEnt() {
  const l = await GET(`/api/motel/entradas?desde=${eDesde}&hasta=${eHasta}&q=${encodeURIComponent(eBus)}`);
  vEnt.l = l;
  const ok = l.filter((e) => !e.cancelada), tot = ok.reduce((s, e) => s + e.total, 0);
  const estado = (e) => (e.cancelada ? '<span class="pill p-bad">Cancelada</span>' : e.activa ? '<span class="pill p-ok">Adentro</span>' : '<span class="pill">Salió</span>');
  const durE = (e) => durTxt(((e.salida_real ? aF(e.salida_real) : ahoraS()) - aF(e.entrada)) / 60000);
  $('#main').innerHTML = cab('Entradas y placas', 'Todas las rentas con su placa, tarifa y lo que pagaron', `<button class="btn" onclick="excelEntradas()">Exportar a Excel</button>`)
    + `<div class="card" style="margin-bottom:16px"><div class="row"><div class="scan" style="flex:1;min-width:220px">${ico('buscar')}<input id="eQ" value="${esc(eBus)}" placeholder="Buscar placas, vehículo, habitación o folio" style="border:0;flex:1;font-size:16px;background:none" onkeydown="if(event.key==='Enter'){eBus=this.value;vEnt()}"></div>
      <button class="btn pri" onclick="eBus=val('eQ');vEnt()">Buscar</button>${eBus ? `<button class="btn" onclick="eBus='';vEnt()">Quitar búsqueda</button>` : `<input type="date" id="ed" value="${eDesde}" style="width:auto"><input type="date" id="eh" value="${eHasta}" style="width:auto"><button class="btn" onclick="eDesde=val('ed');eHasta=val('eh');vEnt()">Ver fechas</button>`}</div>
      <div class="sub" style="margin-top:8px">${eBus ? `Resultados de "${esc(eBus)}" (todas las fechas)` : `Del ${fd(eDesde)} al ${fd(eHasta)}`} · ${ok.length} entrada(s) · ${money(tot)}${l.length !== ok.length ? ` · ${l.length - ok.length} cancelada(s)` : ''}</div></div>
    <div class="card"><div class="tw"><table><thead><tr><th>Folio</th><th>Hab.</th><th>Tarifa</th><th>Placas</th><th>Vehículo</th><th>Entró</th><th>Salió</th><th class="n">Tiempo</th><th class="n">Total</th><th></th></tr></thead><tbody>
    ${l.map((e) => `<tr class="click" onclick="mCuenta(${e.id})"><td class="mono">${esc(e.folio)}</td><td><b>${esc(e.numero)}</b><div class="sub">${esc(e.tipo_nombre || '')}</div></td><td>${esc(e.tarifa || '')}${e.horas_extra ? `<div class="sub">+${e.horas_extra} h extra</div>` : ''}</td>
      <td>${e.placas ? `<span class="mt-pl">${esc(e.placas)}</span>` : `<span class="sub">${esc(LLEGA[e.llegada] || '')}</span>`}</td><td>${esc(e.vehiculo || '')}</td><td>${fdt(e.entrada)}</td><td>${e.salida_real ? fdt(e.salida_real) : '—'}</td><td class="n">${durE(e)}</td><td class="n">${money(e.total)}${e.saldo > 0.009 ? `<div class="sub" style="color:var(--ocup)">debe ${money(e.saldo)}</div>` : ''}</td><td>${estado(e)}</td></tr>`).join('') || '<tr><td colspan="10" class="empty">Sin entradas.</td></tr>'}</tbody></table></div></div>`;
  $('#eQ')?.focus();
}
function excelEntradas() {
  const l = vEnt.l || [];
  descargarArchivo(XLSX.libro([{ nombre: 'Entradas', filas: [[{ v: `${CFG.hotel_nombre} · Entradas ${eBus ? 'búsqueda ' + eBus : 'del ' + fd(eDesde) + ' al ' + fd(eHasta)}`, s: 't' }], [],
    H_('Folio', 'Habitación', 'Tipo', 'Tarifa', 'Llegó', 'Placas', 'Vehículo', 'Personas', 'Entrada', 'Salida', 'Minutos', 'Horas extra', 'Hospedaje', 'Extras y consumos', 'Total', 'Pagado', 'Estado', 'Recepción', 'Motivo cancelación'),
    ...l.map((e) => [e.folio, e.numero, e.tipo_nombre || '', e.tarifa || '', LLEGA[e.llegada] || '', e.placas || '', e.vehiculo || '', e.personas, fdt(e.entrada), e.salida_real ? fdt(e.salida_real) : '', Math.round(((e.salida_real ? aF(e.salida_real) : ahoraS()) - aF(e.entrada)) / 60000),
      e.horas_extra || 0, M_(e.total_hospedaje), M_(e.consumo), M_(e.total), M_(e.pagado), e.cancelada ? 'Cancelada' : e.activa ? 'Adentro' : 'Salió', e.usuario || '', e.cancel_motivo || ''])] }]), `Entradas ${eBus || eDesde + ' a ' + eHasta}.xlsx`);
}

// ======================================================================
// Reportes del motel
// ======================================================================
const RANGOS = () => { const h = new Date(), f = (d) => fechaHoraLocal(d).slice(0, 10), a = new Date(h); a.setDate(a.getDate() - 1);
  const l = new Date(h); l.setDate(l.getDate() - ((l.getDay() + 6) % 7)); const m1 = new Date(h.getFullYear(), h.getMonth(), 1), pm1 = new Date(h.getFullYear(), h.getMonth() - 1, 1), pm2 = new Date(h.getFullYear(), h.getMonth(), 0);
  return [['Hoy', f(h), f(h)], ['Ayer', f(a), f(a)], ['Esta semana', f(l), f(h)], ['Este mes', f(m1), f(h)], ['Mes pasado', f(pm1), f(pm2)]]; };
const barras = (lista, etq, valor, fmt = (v) => v) => { const mx = Math.max(1, ...lista.map(valor)); return `<div class="mbar">${lista.map((x) => `<div title="${esc(etq(x))}: ${esc(String(fmt(valor(x))))}"><i style="height:${Math.round(valor(x) / mx * 100)}%"></i><small>${esc(etq(x))}</small></div>`).join('')}</div>`; };
vRep = async function () {
  const d = await GET(`/api/motel/reporte?desde=${rDesde}&hasta=${rHasta}`); vRep.d = d;
  const R = d.resumen, rg = RANGOS(), pm = R.porMetodo;
  const kpi = (t, v, s = '') => `<div class="kpi"><span>${t}</span><b>${v}</b>${s ? `<div class="sub">${s}</div>` : ''}</div>`;
  const tabla = (cols, filas, vacio = 'Sin datos.') => `<div class="tw"><table><thead><tr>${cols.map((c) => `<th${c.startsWith('$') ? ' class="n"' : ''}>${c.replace(/^\$/, '')}</th>`).join('')}</tr></thead><tbody>${filas.join('') || `<tr><td colspan="${cols.length}" class="empty">${vacio}</td></tr>`}</tbody></table></div>`;
  const tr = (...c) => `<tr>${c.map((x, i) => `<td${i && /^[\d$\-−]|^\d/.test(String(x).replace(/<[^>]+>/g, '')) ? ' class="n"' : ''}>${x}</td>`).join('')}</tr>`;
  const maxHab = Math.max(1, ...d.porHabitacion.map((h) => h.ingreso));
  $('#main').innerHTML = cab('Reportes', `Del ${fd(d.desde)} al ${fd(d.hasta)} · ${d.habitaciones} habitaciones`, `<button class="btn" onclick="pdfReporteM()">Imprimir / PDF</button><button class="btn pri" onclick="excelReporteM()">Exportar a Excel</button>`)
    + `<div class="card" style="margin-bottom:16px"><div class="row">${rg.map(([n, a, b]) => `<button class="btn sm ${rDesde === a && rHasta === b ? 'pri' : ''}" onclick="rDesde='${a}';rHasta='${b}';vRep()">${n}</button>`).join('')}
      <input type="date" id="rd" value="${rDesde}" style="width:auto"><input type="date" id="rh" value="${rHasta}" style="width:auto"><button class="btn sm" onclick="rDesde=val('rd');rHasta=val('rh');vRep()">Ver</button></div></div>
    <div class="kpis">${kpi('Entradas', R.entradas, `${R.canceladas ? R.canceladas + ' cancelada(s) · ' : ''}rotación ${R.rotacion} por hab. al día`)}${kpi('Generado', money(R.generado), 'rentas, extras y tienda')}${kpi('Cobrado', money(R.cobrado), R.devoluciones ? 'devoluciones ' + money(R.devoluciones) : 'en caja, tarjeta y transferencia')}${kpi('Ocupación', R.ocupacion + '%', 'de las horas posibles')}</div>
    <div class="kpis">${kpi('Hospedaje', money(R.hospedaje))}${kpi('Tiempo extra', money(R.tiempo_extra.t), R.tiempo_extra.n + ' h')}${kpi('Persona extra', money(R.persona_extra.t), R.persona_extra.n + ' persona(s)')}${kpi('Tienda y servicio', money(R.tienda.t), 'utilidad ' + money(R.tienda.utilidad))}</div>
    <div class="kpis">${kpi('Ticket promedio', money(R.ticket_promedio), 'por entrada')}${kpi('Tiempo promedio', durTxt(R.duracion_promedio), 'de estancia')}${kpi('Multas y cargos', money(R.multas.t + R.otros.t))}${kpi('Descuentos', money(R.descuentos.total), R.descuentos.n + ' descuento(s)')}</div>
    <div class="cols">
      <div class="card"><h2>Rentas por tarifa</h2>${tabla(['Tipo', 'Tarifa', '$Entradas', '$Importe'], d.porTarifa.map((x) => tr(esc(x.tipo), esc(x.tarifa), x.n, money(x.importe))))}</div>
      <div class="card"><h2>Por tipo de habitación</h2>${tabla(['Tipo', '$Entradas', '$Hospedaje', '$Extras'], Object.entries(d.porTipo).map(([k, x]) => tr(esc(k), x.n, money(x.importe), money(x.extras))))}
        <h2 style="margin-top:14px">Cómo llegaron</h2><div class="kv">${Object.entries(d.llegada).map(([k, n]) => `<span>${esc(LLEGA[k] || k)}</span><b>${n}</b>`).join('') || '<span>—</span><b></b>'}</div></div>
      <div class="card"><h2>Formas de pago</h2><div class="kv"><span>Efectivo</span><b>${money(pm.efectivo)}</b><span>Dólares (en pesos)</span><b>${money(pm.dolares)}${R.usd ? ' · US$' + R.usd.toFixed(2) : ''}</b><span>Tarjeta</span><b>${money(pm.tarjeta)}</b><span>Transferencia</span><b>${money(pm.transferencia)}</b><span>Total cobrado</span><b>${money(R.cobrado)}</b></div>
        <h2 style="margin-top:14px">Por recepcionista</h2>${tabla(['Usuario', '$Entr.', '$Canc.', '$Cobrado'], Object.entries(d.porUsuario).map(([k, x]) => tr(esc(k), x.entradas, x.canceladas ? `<b style="color:var(--ocup)">${x.canceladas}</b>` : 0, money(x.cobrado))))}</div>
    </div>
    <div class="card" style="margin-top:16px"><h2>Entradas por hora del día</h2>${barras(d.porHora.map((n, i) => ({ i, n })), (x) => String(x.i), (x) => x.n)}<div class="sub">Sirve para saber a qué horas poner más personal.</div></div>
    ${d.porDia.length > 1 ? `<div class="card" style="margin-top:16px"><h2>Por día</h2>${barras(d.porDia, (x) => x.fecha.slice(8), (x) => x.ingreso, money)}${tabla(['Día', '$Entradas', '$Ingreso'], d.porDia.map((x) => tr(fd(x.fecha), x.n, money(x.ingreso))))}</div>` : ''}
    <div class="card" style="margin-top:16px"><h2>Por habitación</h2>${tabla(['Hab.', 'Tipo', '$Entradas', '$Horas ocupada', '$Ingreso', ''], d.porHabitacion.map((h) => tr(`<b>${esc(h.numero)}</b>`, esc(h.tipo), h.n, h.horas.toFixed(1), money(h.ingreso), `<div class="mbarra"><i style="width:${Math.round(h.ingreso / maxHab * 100)}%"></i></div>`)))}</div>
    <div class="cols" style="margin-top:16px">
      <div class="card"><h2>Recamareras</h2>${tabla(['Recamarera', '$Limpiezas', '$Promedio', '$Más rápida', '$Más lenta'], Object.entries(d.limpiezas.porRecamarera).map(([k, x]) => tr(esc(k), x.n, durTxt(x.promedio), durTxt(x.min), durTxt(x.max))))}
        <div class="sub">Espera promedio desde que queda sucia hasta que empiezan a limpiar: <b>${durTxt(d.limpiezas.espera_promedio)}</b> · pendientes ahora: ${d.limpiezas.pendientes}</div></div>
      <div class="card"><h2>Productos más vendidos</h2>${tabla(['Producto', '$Cant.', '$Venta', '$Utilidad'], d.productos.slice(0, 15).map((p) => tr(esc(p.descripcion), p.cantidad, money(p.importe), money(p.importe - (p.costo || 0)))))}
        ${d.porSurtir.length ? `<div class="aviso" style="margin-top:10px"><b>Por surtir:</b> ${d.porSurtir.map((p) => `${esc(p.nombre)} (${p.existencia})`).join(', ')}</div>` : ''}</div>
    </div>
    ${(d.plumas || []).length || (d.visitas || []).length ? `<div class="cols" style="margin-top:16px"><div class="card"><h2>Plumas</h2>${tabla(['Pluma', 'Cómo', '$Veces', '$No abrió'], d.plumas.map((x) => tr(x.pluma === 'entrada' ? 'Entrada' : 'Salida', x.modo, x.n, x.fallas)))}
        ${d.plumasManual.length ? `<h2 style="margin-top:14px">Abiertas a mano · ${d.plumasManual.length}</h2>${tabla(['Fecha', 'Pluma', 'Motivo', 'Hab.', 'Usuario'], d.plumasManual.map((x) => tr(fdt(x.fecha), x.pluma === 'entrada' ? 'Entrada' : 'Salida', esc(x.motivo || ''), esc(x.numero || ''), esc(x.usuario || ''))))}` : ''}</div>
      <div class="card"><h2>Visitas a las habitaciones</h2>${tabla(['Movimiento', 'Cómo', '$Veces'], d.visitas.map((x) => tr(x.tipo === 'llega' ? 'Llegaron' : 'Se fueron', esc(MEDIOS[x.medio] || x.medio), x.n)))}</div></div>` : ''}
    <div class="card" style="margin-top:16px;${d.canceladas.length ? 'border-color:var(--ocup)' : ''}"><h2>Entradas canceladas · ${d.canceladas.length}</h2>${tabla(['Fecha', 'Hab.', 'Tarifa', 'Placas', 'Motivo', 'Canceló', 'Autorizó', '$Devuelto'], d.canceladas.map((c) => `<tr class="click" onclick="mCuenta(${c.id})"><td>${fdt(c.fecha)}</td><td><b>${esc(c.numero)}</b></td><td>${esc(c.tarifa || '')}</td><td>${esc(c.placas || '')}</td><td>${esc(c.motivo || '')}</td><td>${esc(c.usuario || '')}</td><td>${esc(c.autorizo || '')}</td><td class="n">${money(c.devuelto)}</td></tr>`), 'Ninguna.')}
      <div class="sub">Revise las cancelaciones: es donde más se puede perder dinero.</div></div>
    ${d.cambios.length ? `<div class="card" style="margin-top:16px"><h2>Cambios de habitación · ${d.cambios.length}</h2>${tabla(['Fecha', 'De', 'A', 'Motivo', 'Usuario'], d.cambios.map((c) => tr(fdt(c.fecha), esc(c.de_num || ''), esc(c.a_num || ''), esc(c.motivo || ''), esc(c.usuario || ''))))}</div>` : ''}
    ${R.descuentos.n ? `<div class="card" style="margin-top:16px"><h2>Descuentos · ${money(R.descuentos.total)}</h2>${tabla(['Fecha', 'Hab.', 'Motivo', 'Usuario', '$Descuento'], R.descuentos.lista.map((x) => tr(fdt(x.fecha), esc(x.numero || ''), esc(x.descuento_motivo || ''), esc(x.usuario || ''), money(x.descuento))))}</div>` : ''}
    <div class="card" style="margin-top:16px"><h2>Cortes de caja</h2>${tabla(['Turno', 'Usuario', 'Abrió', 'Cerró', '$Entradas', '$Cobrado', '$Diferencia'], d.turnos.map((t) => tr(t.id, esc(t.usuario || ''), fdt(t.apertura), t.cierre ? fdt(t.cierre) : 'Abierto', t.entradas, money(t.cobrado), t.dif ? `<span style="color:${t.dif.mxn < 0 ? 'var(--ocup)' : 'inherit'}">${money(t.dif.mxn)}</span>` : '—')))}</div>`;
};
function excelReporteM() {
  const d = vRep.d, R = d.resumen; if (!d) return;
  const res = [[{ v: `${CFG.hotel_nombre} · Reporte del ${fd(d.desde)} al ${fd(d.hasta)}`, s: 't' }], [], H_('Concepto', 'Cuántos', 'Importe'),
    ['Entradas', R.entradas, M_(R.hospedaje)], ['Tiempo extra (horas)', R.tiempo_extra.n, M_(R.tiempo_extra.t)], ['Personas extra', R.persona_extra.n, M_(R.persona_extra.t)], ['Multas y cargos', R.multas.n + R.otros.n, M_(R.multas.t + R.otros.t)],
    ['Tienda y servicio a la habitación', R.tienda.n, M_(R.tienda.t)], [B_('Total generado'), '', BM_(R.generado)], ['Total cobrado', '', M_(R.cobrado)], ['Devoluciones por cancelación', R.canceladas, M_(R.devoluciones)], ['Descuentos', R.descuentos.n, M_(R.descuentos.total)],
    [], ['Ocupación %', R.ocupacion], ['Rotación (entradas por habitación al día)', R.rotacion], ['Ticket promedio', '', M_(R.ticket_promedio)], ['Tiempo promedio de estancia (min)', R.duracion_promedio],
    [], [S_('FORMAS DE PAGO'), S_(''), S_('')], ...Object.entries(R.porMetodo).map(([k, v]) => [MET[k], '', M_(v)])];
  descargarArchivo(XLSX.libro([{ nombre: 'Resumen', filas: res },
    { nombre: 'Por tarifa', filas: [H_('Tipo', 'Tarifa', 'Entradas', 'Importe'), ...d.porTarifa.map((x) => [x.tipo, x.tarifa, x.n, M_(x.importe)])] },
    { nombre: 'Por habitación', filas: [H_('Habitación', 'Tipo', 'Entradas', 'Horas ocupada', 'Ingreso'), ...d.porHabitacion.map((h) => [h.numero, h.tipo, h.n, h.horas, M_(h.ingreso)])] },
    { nombre: 'Por día', filas: [H_('Día', 'Entradas', 'Ingreso'), ...d.porDia.map((x) => [x.fecha, x.n, M_(x.ingreso)])] },
    { nombre: 'Por hora', filas: [H_('Hora', 'Entradas'), ...d.porHora.map((n, i) => [i + ':00', n])] },
    { nombre: 'Recepcionistas', filas: [H_('Usuario', 'Entradas', 'Cancelaciones', 'Cobrado'), ...Object.entries(d.porUsuario).map(([k, x]) => [k, x.entradas, x.canceladas, M_(x.cobrado)])] },
    { nombre: 'Recamareras', filas: [H_('Recamarera', 'Limpiezas', 'Promedio (min)', 'Más rápida', 'Más lenta'), ...Object.entries(d.limpiezas.porRecamarera).map(([k, x]) => [k, x.n, x.promedio, x.min, x.max])] },
    { nombre: 'Cancelaciones', filas: [H_('Fecha', 'Folio', 'Habitación', 'Tarifa', 'Placas', 'Motivo', 'Canceló', 'Autorizó', 'Devuelto'), ...d.canceladas.map((c) => [fdt(c.fecha), c.folio, c.numero, c.tarifa || '', c.placas || '', c.motivo || '', c.usuario || '', c.autorizo || '', M_(c.devuelto)])] },
    { nombre: 'Productos', filas: [H_('Producto', 'Cantidad', 'Venta', 'Costo', 'Utilidad'), ...d.productos.map((p) => [p.descripcion, p.cantidad, M_(p.importe), M_(p.costo), M_(p.importe - (p.costo || 0))])] },
    { nombre: 'Cortes', filas: [H_('Turno', 'Usuario', 'Abrió', 'Cerró', 'Entradas', 'Cobrado', 'Diferencia pesos'), ...d.turnos.map((t) => [t.id, t.usuario || '', fdt(t.apertura), t.cierre ? fdt(t.cierre) : 'Abierto', t.entradas, M_(t.cobrado), t.dif ? M_(t.dif.mxn) : ''])] },
  ]), `Reporte motel ${d.desde} a ${d.hasta}.xlsx`);
}
function pdfReporteM() {
  const d = vRep.d, R = d.resumen; if (!d) return;
  const t = (tit, cols, filas) => filas.length ? `<h3>${tit}</h3><table><thead><tr>${cols.map((c) => `<th${c.startsWith('$') ? ' class="n"' : ''}>${c.replace(/^\$/, '')}</th>`).join('')}</tr></thead><tbody>${filas.join('')}</tbody></table>` : '';
  const f = (...c) => `<tr>${c.map((x, i) => `<td${i ? ' class="n"' : ''}>${x}</td>`).join('')}</tr>`;
  imprimirDoc(`<div class="rep"><div class="rep-enc"><b>${esc(CFG.hotel_nombre)}</b><span>Reporte del motel · del ${fd(d.desde)} al ${fd(d.hasta)}</span></div>
    <div class="rep-tot"><div><small>Entradas</small><b>${R.entradas}</b></div><div><small>Generado</small><b>${money(R.generado)}</b></div><div><small>Cobrado</small><b>${money(R.cobrado)}</b></div><div><small>Ocupación</small><b>${R.ocupacion}%</b></div></div>
    <div class="rep-2"><div>${t('Resumen', ['Concepto', '$Importe'], [f('Hospedaje', money(R.hospedaje)), f(`Tiempo extra (${R.tiempo_extra.n} h)`, money(R.tiempo_extra.t)), f(`Persona extra (${R.persona_extra.n})`, money(R.persona_extra.t)), f('Multas y cargos', money(R.multas.t + R.otros.t)), f('Tienda y servicio', money(R.tienda.t)), f('Descuentos', '-' + money(R.descuentos.total)), f('Devoluciones', '-' + money(R.devoluciones))])}</div>
      <div>${t('Formas de pago', ['Forma', '$Importe'], Object.entries(R.porMetodo).map(([k, v]) => f(MET[k], money(v))))}</div></div>
    ${t('Rentas por tarifa', ['Tipo · tarifa', '$Entradas', '$Importe'], d.porTarifa.map((x) => f(esc(x.tipo + ' · ' + x.tarifa), x.n, money(x.importe))))}
    ${t('Por habitación', ['Habitación', '$Entradas', '$Horas', '$Ingreso'], d.porHabitacion.map((h) => f(esc(h.numero + ' · ' + h.tipo), h.n, h.horas.toFixed(1), money(h.ingreso))))}
    ${t('Por recepcionista', ['Usuario', '$Entr.', '$Canc.', '$Cobrado'], Object.entries(d.porUsuario).map(([k, x]) => f(esc(k), x.entradas, x.canceladas, money(x.cobrado))))}
    ${t('Recamareras', ['Recamarera', '$Limpiezas', '$Promedio'], Object.entries(d.limpiezas.porRecamarera).map(([k, x]) => f(esc(k), x.n, durTxt(x.promedio))))}
    ${t('Cancelaciones', ['Fecha · hab.', '$Motivo', '$Autorizó', '$Devuelto'], d.canceladas.map((c) => f(fdt(c.fecha) + ' · ' + esc(c.numero), esc(c.motivo || ''), esc(c.autorizo || ''), money(c.devuelto))))}
    <div class="rep-pie">Impreso ${new Date().toLocaleString('es-MX')} · Maxsel Motel</div></div>`, 'carta', 'Reporte del motel');
}

// ======================================================================
// Caja: el corte muestra entradas por tarifa, tiempo extra, persona extra y cancelaciones
// ======================================================================
let mcjDesde = hoyISO(), mcjHasta = hoyISO();
vCaja = async function () {
  const r = await GET('/api/turno'); TURNO = r;
  let html = '';
  if (!r.turno) html = `<div class="card" style="max-width:520px"><h2>Su caja está cerrada</h2><p class="sub">Para cobrar entradas, tiempo extra o tienda primero abra su turno con el fondo de caja.</p>${puede('caja') ? '<button class="btn pri" onclick="abrirTurno()">Abrir turno</button>' : ''}</div>`;
  else {
    const t = r.turno, p = r.pagos, e = r.esperado, m = r.motel || {}, c = r.conceptos;
    html = `<div class="kpis"><div class="kpi"><span>Fondo inicial</span><b>${money(t.fondo_mxn)}</b><div class="sub">${t.fondo_usd ? 'más US$' + t.fondo_usd.toFixed(2) + ' · ' : ''}abrió ${fdt(t.apertura)}</div></div>
      <div class="kpi"><span>Cobrado en el turno</span><b>${money(r.cobrado)}</b><div class="sub">${m.entradas || 0} entrada(s) · dólar a $${Number(t.tipo_cambio).toFixed(2)}</div></div>
      ${e ? `<div class="kpi"><span>Debe haber en efectivo</span><b>${money(e.mxn)}</b><div class="sub">${e.usd ? 'y US$' + e.usd.toFixed(2) + ' · ' : ''}en el cajón</div></div><div class="kpi"><span>Tarjeta y transferencia</span><b>${money(e.tarjeta + e.transferencia)}</b><div class="sub">tarjeta ${money(e.tarjeta)} · transf. ${money(e.transferencia)}</div></div>`
      : '<div class="kpi"><span>Cierre a ciegas</span><b>—</b><div class="sub">Al cerrar, cuente el dinero; el sistema calcula la diferencia.</div></div>'}</div>
      <div class="row" style="margin-bottom:16px">${puede('movimientos') ? `<button class="btn" onclick="movModal('ingreso')">Registrar ingreso a caja</button><button class="btn" onclick="movModal('retiro')">Registrar egreso de caja</button>` : ''}
        ${puede('cajon') ? '<button class="btn" onclick="abrirCajonBtn()">Abrir cajón</button>' : ''}${puede('config') ? '<button class="btn" onclick="tcModal()">Cambiar tipo de cambio</button>' : ''}
        <button class="btn" onclick="imprimirCorte2(TURNO,'CORTE PARCIAL (X)')">Imprimir corte parcial</button><button class="btn" onclick="excelCorte(${t.id})">Corte en Excel</button><button class="btn pri" onclick="cerrarTurno()">Cerrar turno</button></div>
      <div class="cols"><div class="card"><h2>Entradas por tarifa</h2><div class="tw"><table><thead><tr><th>Tipo · tarifa</th><th class="n">Entradas</th><th class="n">Importe</th></tr></thead><tbody>
        ${(m.porTarifa || []).map((x) => `<tr><td>${esc(x.tipo)} · ${esc(x.tarifa)}</td><td class="n">${x.n}</td><td class="n">${money(x.importe)}</td></tr>`).join('') || '<tr><td colspan="3" class="empty">Aún no hay entradas en este turno.</td></tr>'}</tbody></table></div></div>
        <div class="card"><h2>Cobros por concepto</h2><div class="kv"><span>Hospedaje</span><b>${money(m.hospedaje)}</b><span>Tiempo extra (${m.tiempo_extra?.horas || 0} h)</span><b>${money(m.tiempo_extra?.cobrado)}</b><span>Persona extra (${m.persona_extra?.n || 0})</span><b>${money(m.persona_extra?.cobrado)}</b>
          <span>Tienda y servicio</span><b>${money(m.tienda?.cobrado)}</b><span>Multas y cargos</span><b>${money(m.otros)}</b>${m.canceladas?.n ? `<span style="color:var(--ocup)">Cancelaciones (${m.canceladas.n})</span><b style="color:var(--ocup)">-${money(m.canceladas.devuelto)}</b>` : ''}</div></div>
        <div class="card"><h2>Por forma de pago</h2><div class="kv"><span>Efectivo (neto)</span><b>${money(p.efectivo)}</b><span>Dólares</span><b>US$${p.usd.toFixed(2)} → ${money(p.dolares)}</b><span>Cambio por dólares</span><b>${money(p.cambio)}</b><span>Tarjeta</span><b>${money(p.tarjeta)}</b><span>Transferencia</span><b>${money(p.transferencia)}</b></div></div></div>
      <div class="card" style="margin-top:16px"><h2>Ingresos y egresos de caja</h2><div class="tw"><table><thead><tr><th>Hora</th><th>Tipo</th><th>Motivo</th><th>Autorizó</th><th class="n">Monto</th></tr></thead><tbody>
        ${r.lista_mov.map((x) => `<tr><td>${fdt(x.fecha)}</td><td><span class="pill ${x.tipo === 'ingreso' ? 'p-ok' : 'p-bad'}">${x.tipo === 'ingreso' ? 'Ingreso' : 'Egreso'}</span></td><td>${esc(x.motivo)}</td><td>${esc(x.autorizo || '')}</td><td class="n">${x.moneda === 'USD' ? 'US$' + x.monto.toFixed(2) : money(x.monto)}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">Sin movimientos.</td></tr>'}</tbody></table></div></div>`;
  }
  if (puede('cortes')) {
    const l = await GET(`/api/turnos?desde=${mcjDesde}&hasta=${mcjHasta}`);
    html += `<div class="card" style="margin-top:16px"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h2 style="margin:0">Cortes de caja</h2><div class="row"><input type="date" id="cjd" value="${mcjDesde}" style="width:auto"><input type="date" id="cjh" value="${mcjHasta}" style="width:auto"><button class="btn sm" onclick="mcjDesde=val('cjd');mcjHasta=val('cjh');vCaja()">Ver</button></div></div>
      <div class="tw"><table><thead><tr><th>Turno</th><th>Usuario</th><th>Abrió</th><th>Cerró</th><th class="n">Entradas</th><th class="n">Cobrado</th><th class="n">Dif. pesos</th><th></th></tr></thead><tbody>
      ${l.map((x) => `<tr><td class="mono">${x.turno.id}</td><td>${esc(x.turno.usuario)}</td><td>${fdt(x.turno.apertura)}</td><td>${x.turno.cierre ? fdt(x.turno.cierre) : '<span class="pill p-ok">Abierto</span>'}</td><td class="n">${x.motel?.entradas || 0}</td><td class="n">${money(x.cobrado)}</td>
        <td class="n" style="color:${x.dif && x.dif.mxn < 0 ? 'var(--ocup)' : 'inherit'}">${x.dif ? money(x.dif.mxn) : '—'}</td><td><button class="btn sm" onclick="reimprimirCorte(${x.turno.id})">Ticket</button> <button class="btn sm" onclick="excelCorte(${x.turno.id})">Excel</button></td></tr>`).join('') || '<tr><td colspan="8" class="empty">Sin turnos en esas fechas.</td></tr>'}</tbody></table></div></div>`;
  }
  $('#main').innerHTML = cab('Caja', r.turno ? `Turno de ${esc(YO.nombre)}` : 'Turno, fondo, entradas y salidas de dinero') + html;
};
imprimirCorte2 = function (r, titulo) {
  const antes = CFG.ticket_ancho; CFG.ticket_ancho = '80';
  try {
    const t = r.turno, p = r.pagos, c = r.conceptos, m = r.motel || {}, w = W(), us = (x) => 'US$' + Number(x || 0).toFixed(2), raya = '-'.repeat(w), doble = '='.repeat(w);
    const L = [...encabezado(), titulo, raya, lin('Turno ' + t.id, t.usuario || YO.nombre), lin('Abrió', fdt(t.apertura)), ...(t.cierre ? [lin('Cerró', fdt(t.cierre))] : []), lin('Dólar', '$' + Number(t.tipo_cambio).toFixed(2)), doble,
      `ENTRADAS (${m.entradas || 0})`, ...(m.porTarifa || []).map((x) => lin(`${x.n} ${x.tipo} ${x.tarifa}`, money(x.importe))), raya,
      lin('Hospedaje cobrado', money(m.hospedaje)), lin(`Tiempo extra (${m.tiempo_extra?.horas || 0} h)`, money(m.tiempo_extra?.cobrado)), lin(`Persona extra (${m.persona_extra?.n || 0})`, money(m.persona_extra?.cobrado)),
      lin(`Tienda y servicio (${m.tienda?.n || 0})`, money(m.tienda?.cobrado)), ...(m.otros ? [lin('Multas y cargos', money(m.otros))] : []), ...(m.canceladas?.n ? [lin(`Devuelto por cancelación (${m.canceladas.n})`, '-' + money(m.canceladas.devuelto))] : []),
      doble, lin('TOTAL COBRADO', money(r.cobrado)), raya, 'FORMAS DE PAGO', lin('Efectivo', money(p.efectivo))];
    if (p.usd) L.push(lin(`Dólares ${us(p.usd)}`, money(p.dolares)), lin('  Cambio dado en pesos', '-' + money(p.cambio)));
    if (p.tarjeta) L.push(lin('Tarjeta', money(p.tarjeta)));
    if (p.transferencia) L.push(lin('Transferencia', money(p.transferencia)));
    L.push(raya, 'CAJA', lin('Fondo inicial', money(t.fondo_mxn) + (t.fondo_usd ? ' + ' + us(t.fondo_usd) : '')));
    if (r.movimientos.ing_mxn || r.movimientos.ing_usd) L.push(lin('Ingresos a caja', money(r.movimientos.ing_mxn) + (r.movimientos.ing_usd ? ' ' + us(r.movimientos.ing_usd) : '')));
    if (r.movimientos.ret_mxn || r.movimientos.ret_usd) L.push(lin('Egresos de caja', '-' + money(r.movimientos.ret_mxn) + (r.movimientos.ret_usd ? ' ' + us(r.movimientos.ret_usd) : '')));
    if (r.esperado) L.push(lin('DEBE HABER pesos', money(r.esperado.mxn)), ...(r.esperado.usd ? [lin('DEBE HABER dólares', us(r.esperado.usd))] : []));
    if (t.estado === 'cerrado') {
      L.push(lin('Contado pesos', money(t.decl_mxn)), lin('Contado dólares', us(t.decl_usd)), lin('Contado tarjeta', money(t.decl_tarjeta)), lin('Contado transferencia', money(t.decl_transferencia)));
      if (r.dif) L.push(lin('DIFERENCIA pesos', money(r.dif.mxn)), lin('DIFERENCIA dólares', us(r.dif.usd)), '(sobra + / falta -)');
      if (t.notas) L.push(...wrapT('Notas: ' + t.notas));
    }
    L.push('', '', '_'.repeat(30), 'Firma cajero', '', '', '_'.repeat(30), 'Firma supervisor', '', 'Impreso ' + new Date().toLocaleString('es-MX'));
    imprimir(L, titulo.toLowerCase().replace(/^\w/, (x) => x.toUpperCase()));
  } finally { CFG.ticket_ancho = antes; }
};
excelCorte = async function (id) {
  const r = await hacer(() => GET(`/api/turnos/${id}/detalle`)), t = r.turno, p = r.pagos, m = r.motel || {}, d = r.detalle;
  const res = [[{ v: `${CFG.hotel_nombre} · Corte de turno ${t.id}`, s: 't' }], ['Usuario', t.usuario || ''], ['Abrió', fdt(t.apertura)], ['Cerró', t.cierre ? fdt(t.cierre) : 'Abierto'], ['Tipo de cambio', M_(t.tipo_cambio)], [],
    H_('Entradas por tarifa', 'Cuántas', 'Importe'), ...(m.porTarifa || []).map((x) => [x.tipo + ' · ' + x.tarifa, x.n, M_(x.importe)]), [B_('Total entradas'), m.entradas || 0, ''], [],
    H_('Cobros', '', 'Importe'), ['Hospedaje', '', M_(m.hospedaje)], [`Tiempo extra (${m.tiempo_extra?.horas || 0} h)`, '', M_(m.tiempo_extra?.cobrado)], [`Persona extra (${m.persona_extra?.n || 0})`, '', M_(m.persona_extra?.cobrado)],
    ['Tienda y servicio', '', M_(m.tienda?.cobrado)], ['Multas y cargos', '', M_(m.otros)], ['Devoluciones por cancelación', m.canceladas?.n || 0, M_(-(m.canceladas?.devuelto || 0))], [B_('Total cobrado'), '', BM_(r.cobrado)], [],
    H_('Formas de pago', '', 'Importe'), ['Efectivo (neto)', '', M_(p.efectivo)], ['Dólares (en pesos)', U_(p.usd), M_(p.dolares)], ['Tarjeta', '', M_(p.tarjeta)], ['Transferencia', '', M_(p.transferencia)], [],
    H_('Caja', 'Dólares', 'Pesos'), ['Fondo inicial', U_(t.fondo_usd), M_(t.fondo_mxn)], ['Ingresos a caja', U_(r.movimientos.ing_usd), M_(r.movimientos.ing_mxn)], ['Egresos de caja', U_(r.movimientos.ret_usd), M_(r.movimientos.ret_mxn)],
    ...(r.esperado ? [['Debe haber', U_(r.esperado.usd), BM_(r.esperado.mxn)]] : []), ...(t.estado === 'cerrado' ? [['Contado', U_(t.decl_usd), M_(t.decl_mxn)]] : []), ...(r.dif ? [['Diferencia (sobra + / falta -)', U_(r.dif.usd), BM_(r.dif.mxn)]] : [])];
  descargarArchivo(XLSX.libro([{ nombre: 'Resumen', filas: res },
    { nombre: 'Cobros', filas: [H_('Fecha', 'Concepto', 'Habitación', 'Método', 'Monto', 'Dólares', 'Nota', 'Usuario'), ...d.pagos.map((x) => [fdt(x.fecha), CONC_M[x.concepto] || x.concepto, x.numero || '', MET[x.metodo] || x.metodo, M_(x.monto), x.usd ? U_(x.usd) : '', x.nota || '', x.usuario || ''])] },
    { nombre: 'Tienda', filas: [H_('Folio', 'Fecha', 'Producto', 'Cantidad', 'Precio', 'Importe', 'Pago', 'Habitación'), ...d.ventas.map((x) => [x.folio, fdt(x.fecha), x.descripcion, x.cantidad, M_(x.precio), M_(x.importe), MET[x.metodo] || x.metodo, x.numero || ''])] },
    { nombre: 'Ingresos y egresos', filas: [H_('Fecha', 'Tipo', 'Moneda', 'Monto', 'Motivo'), ...r.movimientos_caja.map((x) => [fdt(x.fecha), x.tipo === 'ingreso' ? 'Ingreso' : 'Egreso', x.moneda, x.moneda === 'USD' ? U_(x.monto) : M_(x.monto), x.motivo || ''])] }]),
  `Corte turno ${t.id} - ${String(t.apertura).slice(0, 10)}.xlsx`);
};
pdfCorte = excelCorte;

// ======================================================================
// Configuración del motel
// ======================================================================
vCfg = async function () {
  CFG = await GET('/api/config'); aplicarColores();
  const tabs = [['motel', 'Motel y reglas', 'config'], ['tarifas', 'Tipos y tarifas', 'habitaciones'], ['habs', 'Habitaciones', 'habitaciones'], ['recam', 'Recamareras', 'estados'], ['plumas', 'Plumas', 'config'], ['impresora', 'Impresora y caja', 'config'],
    ['usuarios', 'Usuarios y permisos', 'usuarios'], ['mant', 'Portal de mantenimiento', 'usuarios'], ['remoto', 'Monitoreo remoto'], ['resp', 'Respaldos y licencia', 'config'], ['bita', 'Bitácora', 'bitacora'], ['pass', 'Mi contraseña']]
    .filter(([k, , perm]) => (perm ? puede(perm) : true) && !(k === 'remoto' && YO.rol === 'mantenimiento'));
  if (!tabs.find((t) => t[0] === cfgTab)) cfgTab = tabs[0][0];
  $('#main').innerHTML = cab('Configuración', '') + `<div class="tabs">${tabs.map(([k, n]) => `<button class="${cfgTab === k ? 'on' : ''}" onclick="cfgTab='${k}';vCfg()">${n}</button>`).join('')}</div><div id="cfgc"></div>`;
  const fn = { motel: cMotel, plumas: cPlumas, tarifas: cTarifas, habs: cHabsM, recam: cRecam, impresora: async () => { await cImpresora(); $('#iV')?.closest('label')?.remove(); }, usuarios: cUsers, mant: cMantPortal, remoto: cRemoto, resp: cResp, bita: cBitacora, pass: cPass }[cfgTab];
  await fn();
};
const chk = (id, on, txt) => `<label class="row" style="font-weight:600"><input type="checkbox" id="${id}" ${on ? 'checked' : ''}> ${txt}</label>`;
function cMotel() {
  $('#cfgc').innerHTML = `<div class="stack"><div class="card"><h2>Datos del motel (salen en el ticket)</h2><div class="f">
      <label class="l">Nombre<input id="cfN" value="${esc(CFG.hotel_nombre)}"></label><label class="l">Dirección<input id="cfD" value="${esc(CFG.hotel_direccion)}"></label>
      <label class="l">Teléfono<input id="cfT" value="${esc(CFG.hotel_telefono)}"></label><label class="l">Mensaje al final del ticket<input id="cfP" value="${esc(CFG.ticket_pie)}"></label></div></div>
    <div class="card"><h2>Tiempo y salidas</h2><div class="f">
      <label class="l">Al pasar la hora de salida<select id="cfV"><option value="hora">Cobrar hora extra (cada hora que pase)</option><option value="tarifa">Cobrar otra vez la misma tarifa</option><option value="nada">Solo avisar en pantalla</option></select></label>
      <label class="l">Tolerancia antes de cobrar (minutos)<input id="cfTo" type="number" min="0" max="120" value="${esc(CFG.motel_tolerancia)}"></label>
      <label class="l">Avisar "por salir" (minutos antes)<input id="cfAv" type="number" min="0" max="240" value="${esc(CFG.motel_aviso_min)}"></label>
      <label class="l">Se puede cancelar una entrada hasta (minutos)<input id="cfCa" type="number" min="0" max="600" value="${esc(CFG.motel_cancel_min)}"></label></div>
      <div class="stack" style="gap:6px;margin-top:10px">${chk('cfPl', CFG.motel_pide_placas === '1', 'Las placas son obligatorias cuando llegan en auto')}${chk('cfSu', CFG.motel_salida_limpieza !== '0', 'Al dar salida la habitación queda sucia (para que la limpien antes de rentarla)')}
        ${chk('cfNg', CFG.motel_numero_grande !== '0', 'Imprimir el número de la habitación GRANDE en el ticket (para que se vea en la cámara)')}</div>
      <div class="sub" style="margin-top:8px">Cancelar una entrada siempre pide la clave de un gerente o del administrador. El tiempo extra y la persona extra se cobran con los precios de cada tipo de habitación (pestaña Tipos y tarifas).</div></div>
    <div class="card"><h2>Descuentos y multas</h2><div class="f"><label class="l">Descuento máximo de gerente y administrador (%)<input id="cfDp" type="number" min="0" max="100" value="${esc(CFG.desc_max_pct)}"></label>
      <label class="l">Descuento máximo en pesos (0 = sin límite)<input id="cfDm" type="number" min="0" value="${esc(CFG.desc_max_monto)}"></label></div>
      <div class="sub">El descuento de cada recepcionista se pone en Usuarios y permisos.</div>
      <label class="l" style="margin-top:10px">Multas y cargos (uno por renglón: nombre: monto)<textarea id="cfMu" rows="5">${esc(CFG.multas_lista)}</textarea></label></div>
    <div><button class="btn pri" onclick="cMotelOk()">Guardar</button></div></div>`;
  $('#cfV').value = CFG.motel_vencido || 'hora';
}
async function cMotelOk() {
  await hacer(() => PUT('/api/config', { hotel_nombre: val('cfN') || 'Mi Motel', hotel_direccion: val('cfD'), hotel_telefono: val('cfT'), ticket_pie: val('cfP'), motel_vencido: val('cfV'), motel_tolerancia: val('cfTo') || '0',
    motel_aviso_min: val('cfAv') || '0', motel_cancel_min: val('cfCa') || '0', motel_pide_placas: $('#cfPl').checked ? '1' : '0', motel_salida_limpieza: $('#cfSu').checked ? '1' : '0', motel_numero_grande: $('#cfNg').checked ? '1' : '0',
    desc_max_pct: val('cfDp') || '0', desc_max_monto: val('cfDm') || '0', multas_lista: $('#cfMu').value }), 'Guardado');
  CFG = await GET('/api/config'); marco(); pintarTurno(); vCfg();
}
// ---------- Tipos de habitación y tarifas ----------
let TIPOS = [];
async function cTarifas() {
  TIPOS = await GET('/api/motel/tipos'); const habs = await GET('/api/habitaciones');
  $('#cfgc').innerHTML = `<div class="stack"><div class="row" style="justify-content:space-between"><p class="sub" style="margin:0">Cada tipo de habitación tiene sus tarifas (por horas o por noche), el precio de la hora extra y de la persona extra. El precio es el mismo todos los días.</p><button class="btn pri" onclick="tipoModal()">${ico('mas')} Agregar tipo</button></div>
    <div class="mtipos-l">${TIPOS.map((t) => `<div class="card mtipo" style="border-top:6px solid ${esc(t.color)}"><div class="row" style="justify-content:space-between"><h2 style="margin:0">${esc(t.nombre)}</h2><button class="btn sm" onclick="tipoModal(${t.id})">Editar</button></div>
      <div class="sub">${esc(t.descripcion || '')} · ${habs.filter((h) => h.tipo_id === t.id).length} habitación(es)</div>
      <div class="tw"><table><tbody>${t.tarifas.map((x) => `<tr><td><b>${esc(x.nombre)}</b></td><td class="sub">${tarifaTxt(x)}</td><td class="n"><b>${money(x.precio)}</b></td></tr>`).join('')}</tbody></table></div>
      <div class="kv" style="margin-top:8px"><span>Hora extra</span><b>${t.precio_hora_extra > 0 ? money(t.precio_hora_extra) : 'No cobra'}</b><span>Persona extra</span><b>${t.precio_persona_extra > 0 ? money(t.precio_persona_extra) + ' (incluye ' + t.personas_incluidas + ')' : 'No cobra'}</b></div></div>`).join('') || '<div class="card empty">Agregue los tipos de habitación: Sencilla, Jacuzzi, Suite…</div>'}</div></div>`;
}
let TT = [];
function tipoModal(id) {
  const t = id ? TIPOS.find((x) => x.id === id) : { nombre: '', descripcion: '', color: '#2563eb', tarifas: [{ nombre: '3 horas', horas: 3, precio: '' }, { nombre: 'Noche', noche: 1, hora_salida: '12:00', precio: '' }], precio_hora_extra: '', precio_persona_extra: '', personas_incluidas: 2, orden: 0 };
  TT = t.tarifas.map((x) => ({ ...x }));
  modal(id ? 'Editar tipo de habitación' : 'Nuevo tipo de habitación', `<div class="f"><label class="l">Nombre<input id="tyN" value="${esc(t.nombre)}" placeholder="Sencilla, Jacuzzi, Suite…"></label><label class="l">Descripción<input id="tyD" value="${esc(t.descripcion || '')}" placeholder="Ej. cama king, jacuzzi y cochera"></label>
      <label class="l">Color en el tablero<input id="tyC" type="color" value="${esc(t.color)}"></label><label class="l">Orden<input id="tyO" type="number" value="${t.orden || 0}"></label></div>
    <div class="lbl">Tarifas</div><div id="tyT"></div><button class="btn sm" type="button" onclick="TT.push({nombre:'',horas:3,precio:''});tyPintar()">${ico('mas')} Agregar tarifa por horas</button> <button class="btn sm" type="button" onclick="TT.push({nombre:'Noche',noche:1,hora_salida:'12:00',precio:''});tyPintar()">${ico('mas')} Agregar noche</button>
    <div class="f" style="margin-top:12px"><label class="l">Precio de la hora extra<input id="tyH" type="number" min="0" step="0.01" value="${t.precio_hora_extra || ''}" placeholder="0 = no cobra"></label>
      <label class="l">Personas incluidas<input id="tyI" type="number" min="1" max="20" value="${t.personas_incluidas || 2}"></label><label class="l">Precio por persona extra<input id="tyP" type="number" min="0" step="0.01" value="${t.precio_persona_extra || ''}" placeholder="0 = no cobra"></label></div>`,
  `${id ? `<button class="btn bad" onclick="confirmar(this,()=>tipoBorrar(${id}))">Quitar tipo</button>` : ''}<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="tipoOk(${id || 0})">Guardar</button>`, true);
  tyPintar();
}
function tyPintar() {
  $('#tyT').innerHTML = TT.map((x, i) => `<div class="mtar-f"><input placeholder="${x.noche ? 'Noche' : 'Ej. 3 horas'}" value="${esc(x.nombre || '')}" oninput="TT[${i}].nombre=this.value">
    ${x.noche ? `<label class="sub">Sale a las <input type="time" value="${esc(x.hora_salida || '12:00')}" oninput="TT[${i}].hora_salida=this.value"></label>` : `<label class="sub"><input type="number" min="0.5" max="72" step="0.5" value="${x.horas || ''}" oninput="TT[${i}].horas=this.value;if(!TT[${i}].nombre||/^\\d/.test(TT[${i}].nombre)){TT[${i}].nombre=this.value+' horas';this.closest('.mtar-f').querySelector('input').value=TT[${i}].nombre}"> horas</label>`}
    <label class="sub">$ <input type="number" min="0" step="0.01" value="${x.precio}" oninput="TT[${i}].precio=this.value"></label><button class="btn sm bad" type="button" onclick="TT.splice(${i},1);tyPintar()" aria-label="Quitar">${ico('x')}</button></div>`).join('');
}
async function tipoOk(id) {
  const b = { nombre: val('tyN'), descripcion: val('tyD'), color: val('tyC'), orden: val('tyO'), tarifas: TT, precio_hora_extra: val('tyH'), personas_incluidas: val('tyI'), precio_persona_extra: val('tyP') };
  await hacer(() => (id ? PUT('/api/motel/tipos/' + id, b) : POST('/api/motel/tipos', b)), 'Guardado'); cerrar(); cTarifas();
}
async function tipoBorrar(id) { await hacer(() => DEL('/api/motel/tipos/' + id), 'Tipo quitado'); cerrar(); cTarifas(); }
// ---------- Habitaciones ----------
let HABS_M = [];
async function cHabsM() {
  [HABS_M, TIPOS] = await Promise.all([GET('/api/habitaciones'), GET('/api/motel/tipos')]);
  const tn = (id) => TIPOS.find((t) => t.id === id);
  $('#cfgc').innerHTML = `<div class="stack"><div class="row" style="justify-content:space-between"><span class="sub">${HABS_M.length} habitación(es)</span><div class="row"><button class="btn" onclick="habVarias()">Agregar varias</button><button class="btn pri" onclick="habModal()">${ico('mas')} Agregar una</button></div></div>
    ${TIPOS.length ? '' : '<div class="aviso">Primero cree los tipos de habitación y sus tarifas (pestaña Tipos y tarifas).</div>'}
    <div class="card"><div class="tw"><table><thead><tr><th>Número</th><th>Tipo</th><th>Piso</th><th>Incluye</th><th>Estado</th><th></th></tr></thead><tbody>
    ${sortH(HABS_M).map((h) => `<tr><td><b style="font-size:17px">${esc(h.numero)}</b>${h.nombre ? `<div class="sub">${esc(h.nombre)}</div>` : ''}</td><td>${tn(h.tipo_id) ? `<span class="pill" style="--b:${esc(tn(h.tipo_id).color)}22;--c:${esc(tn(h.tipo_id).color)}">${esc(tn(h.tipo_id).nombre)}</span>` : '<span class="pill p-bad">Sin tipo</span>'}</td><td>${esc(h.piso || '')}</td>
      <td><div class="amen">${(h.amenidades || []).map((a) => `<span title="${esc(AMEN[a] || a)}">${ico(a)}</span>`).join('')}</div></td><td>${{ libre: 'Disponible', ocupada: 'Ocupada', limpieza: 'Sucia', mant: 'Mantenimiento' }[h.estado]}</td>
      <td><button class="btn sm" onclick="habModal(${h.id})">Editar</button></td></tr>`).join('') || '<tr><td colspan="6" class="empty">Sin habitaciones.</td></tr>'}</tbody></table></div></div></div>`;
}
const AMEN_M = ['cochera', 'jacuzzi', 'sauna', 'alberca', 'tv', 'ac', 'ventilador', 'wifi', 'agua', 'sonido', 'minibar', 'refri', 'tubo'];
const amenCk = (sel = []) => `<div class="mamen">${AMEN_M.map((a) => `<label><input type="checkbox" name="hbA" value="${a}" ${sel.includes(a) ? 'checked' : ''}><span>${ico(a)} ${esc(AMEN[a] || a)}</span></label>`).join('')}</div>`;
const selTipo = (id, sel) => `<select id="${id}">${TIPOS.map((t) => `<option value="${t.id}" ${t.id === sel ? 'selected' : ''}>${esc(t.nombre)}</option>`).join('')}</select>`;
function habModal(id) {
  const h = id ? HABS_M.find((x) => x.id === id) : { numero: '', nombre: '', piso: '', tipo_id: TIPOS[0]?.id, amenidades: ['cochera', 'tv', 'ac', 'wifi', 'agua'], capacidad: 2 };
  if (!TIPOS.length) return toast('Primero cree los tipos de habitación', true);
  modal(id ? `Habitación ${esc(h.numero)}` : 'Nueva habitación', `<div class="f"><label class="l">Número<input id="hbN" value="${esc(h.numero)}"></label><label class="l">Tipo${selTipo('hbT', h.tipo_id)}</label>
    <label class="l">Nombre o tema (opcional)<input id="hbNo" value="${esc(h.nombre || '')}" placeholder="Ej. Suite Roma"></label><label class="l">Piso o zona (opcional)<input id="hbP" value="${esc(h.piso || '')}"></label></div>
    <div class="lbl">Qué incluye</div>${amenCk(h.amenidades)}`,
  `${id ? `<button class="btn bad" onclick="confirmar(this,()=>habBorrarM(${id}))">Borrar</button>` : ''}<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="habOkM(${id || 0})">Guardar</button>`);
}
const amenSel = () => [...document.querySelectorAll('input[name=hbA]:checked')].map((x) => x.value);
async function habOkM(id) {
  const b = { numero: val('hbN'), nombre: val('hbNo'), piso: val('hbP'), tipo_id: val('hbT'), amenidades: amenSel(), capacidad: 2 };
  await hacer(() => (id ? PUT('/api/motel/habitaciones/' + id, b) : POST('/api/motel/habitaciones', b)), 'Guardado'); cerrar(); cHabsM();
}
async function habBorrarM(id) { await hacer(() => DEL('/api/habitaciones/' + id), 'Habitación borrada'); cerrar(); cHabsM(); }
function habVarias() {
  if (!TIPOS.length) return toast('Primero cree los tipos de habitación', true);
  modal('Agregar varias habitaciones', `<div class="f"><label class="l">Del número<input id="hvD" type="number" min="0" value="1" oninput="hvPrev()"></label><label class="l">Al número<input id="hvH" type="number" min="0" value="10" oninput="hvPrev()"></label>
      <label class="l">Letra o prefijo (opcional)<input id="hvP" placeholder="Ej. A → A1, A2…" oninput="hvPrev()"></label><label class="l">Tipo${selTipo('hvT')}</label></div>
    <label class="l">O escríbalas separadas por coma<input id="hvL" placeholder="Ej. 1, 2, 3, 10A, Suite Roma" oninput="hvPrev()"></label>
    <div class="lbl">Qué incluyen</div>${amenCk(['cochera', 'tv', 'ac', 'wifi', 'agua'])}<div class="sub" id="hvR"></div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="habVariasOk()">Agregar</button>`);
  hvPrev();
}
function hvLista() {
  if (val('hvL')) return val('hvL').split(',').map((x) => x.trim()).filter(Boolean);
  const a = parseInt(val('hvD')), b = parseInt(val('hvH')); if (isNaN(a) || isNaN(b) || b < a || b - a > 499) return [];
  return Array.from({ length: b - a + 1 }, (_, i) => val('hvP') + (a + i));
}
function hvPrev() { const l = hvLista(); $('#hvR').textContent = l.length ? `Se agregarán ${l.length}: ${l.slice(0, 12).join(', ')}${l.length > 12 ? '…' : ''}` : 'Revise los números'; }
async function habVariasOk() {
  const l = hvLista(); if (!l.length) return toast('Revise los números', true);
  const r = await hacer(() => POST('/api/motel/habitaciones/lote', { numeros: l, tipo_id: val('hvT'), amenidades: amenSel() }));
  toast(`Se agregaron ${r.creadas}${r.saltadas.length ? ` · ya existían: ${r.saltadas.join(', ')}` : ''}`); cerrar(); cHabsM();
}
// ---------- Recamareras (en configuración) ----------
async function cRecam() {
  const recs = await GET('/api/motel/recamareras?todas=1');
  $('#cfgc').innerHTML = `<div class="card" style="max-width:640px"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h2 style="margin:0">Recamareras</h2><button class="btn pri" onclick="recModal()">${ico('mas')} Agregar</button></div>
    <div class="tw"><table><tbody>${recs.map((r) => `<tr><td><b>${esc(r.nombre)}</b> ${r.activo ? '' : '<span class="pill">Baja</span>'}</td><td>${esc(r.telefono || '')}</td><td><button class="btn sm" onclick="recModal(${r.id})">Editar</button></td></tr>`).join('') || '<tr><td class="empty">Sin recamareras.</td></tr>'}</tbody></table></div>
    <p class="sub">Al mandar a limpiar una habitación se elige quién la limpia; en Reportes y en Limpieza ve cuántas limpió cada una y cuánto tardó.</p></div>`;
}

// ======================================================================
// Monitoreo remoto: dirección web de Tailscale (Funnel). Solo esta computadora lleva Tailscale;
// el dueño abre https://....ts.net en cualquier celular, sin instalar nada.
// ======================================================================
cRemoto = async function () {
  const ips = CFG._ips || [], loc = ips.filter((i) => !i.tailscale), p = CFG._puerto, admin = puede('admin');
  $('#cfgc').innerHTML = `<div class="stack">
    <div class="card web-card"><h2>${ico('wifi')} Dirección web para ver el motel desde cualquier celular</h2>
      <p class="sub" style="margin-top:0">Con <b>Tailscale</b> instalado <b>solo en esta computadora</b>, el motel tiene una dirección segura (https://…ts.net) que se abre en cualquier celular o computadora, sin instalar ninguna aplicación ni VPN.</p>
      <div id="webEst"><div class="sub">Revisando Tailscale…</div></div></div>
    <div class="card"><h2>Desde el celular, en el WiFi del motel</h2>${loc.map((i) => `<div class="codigo" style="font-size:18px">http://${esc(i.ip)}:${p}</div>`).join('') || '<div class="empty">Sin red local.</div>'}<p class="sub">Entre con un usuario de tipo <b>Monitoreo</b> (solo ver) o Recepción.</p></div>
    ${admin ? `<div class="card"><h2>Otra opción: No-IP / DDNS</h2>
      <p class="sub" style="margin-top:0">Solo si no puede usar la dirección web de Tailscale. Requiere abrir el puerto ${p} en el módem e IP pública. La conexión NO va cifrada.</p>
      <label class="row" style="font-weight:600"><input type="checkbox" id="pi" ${CFG.permitir_internet === '1' ? 'checked' : ''}> Permitir conexiones desde internet</label>
      <div style="margin-top:10px"><button class="btn" onclick="internetOk()">Guardar</button></div></div>` : ''}</div>`;
  webPintar();
};
async function webPintar(extra = '') {
  const el = $('#webEst'); if (!el) return;
  let w; try { w = await GET('/api/remoto/web'); } catch (e) { el.innerHTML = `<div class="aviso bad">${esc(e.message)}</div>`; return; }
  const pasos = (n, txt, ok) => `<li class="${ok ? 'ok' : ''}"><span>${ok ? '✓' : n}</span><div>${txt}</div></li>`;
  const quien = `<label class="l" style="max-width:520px;margin-top:12px">¿Quién puede entrar por la dirección web?<select id="webRol" onchange="webRol()"><option value="dueno" ${w.roles !== 'todos' ? 'selected' : ''}>Solo el dueño: administrador, gerente y monitoreo (recomendado)</option><option value="todos" ${w.roles === 'todos' ? 'selected' : ''}>Todos los usuarios</option></select></label>`;
  if (w.activo) {
    const msg = encodeURIComponent(`Monitoreo de ${CFG.hotel_nombre}: ${w.url}\nEntre con su usuario y contraseña. En el menú del navegador elija "Agregar a pantalla de inicio".`);
    el.innerHTML = `${extra}<div class="aviso ok"><b>La dirección web está ACTIVA.</b> Ábrala en el celular del dueño (Chrome o Safari) y entre con su usuario:</div>
      <div class="codigo web-url" id="webUrl">${esc(w.url)}</div>
      <div class="row"><button class="btn pri" onclick="copiarTexto('${esc(w.url)}')">Copiar dirección</button><a class="btn" href="https://wa.me/?text=${msg}" target="_blank" rel="noopener">Enviar por WhatsApp</a>
        <button class="btn bad" onclick="confirmar(this,webDesactivar)">Desactivar</button></div>
      <p class="sub">En el celular: menú del navegador → <b>"Agregar a pantalla de inicio"</b> para que quede como una aplicación. Esta computadora debe estar encendida y con internet.</p>${quien}`;
    return;
  }
  el.innerHTML = `${extra}<ol class="web-pasos">
      ${pasos(1, `Instale Tailscale <b>solo en esta computadora</b>: entre a <b>tailscale.com/download</b> → Windows. ${w.instalado ? '' : '<span class="malo">(todavía no está instalado)</span>'}`, w.instalado)}
      ${pasos(2, `Inicie sesión en Tailscale con una cuenta de Google del motel (clic en el icono de Tailscale junto al reloj → Log in). ${w.conectado ? `Conectado${w.cuenta ? ' como <b>' + esc(w.cuenta) + '</b>' : ''}.` : w.instalado ? '<span class="malo">(no ha iniciado sesión)</span>' : ''}`, w.conectado)}
      ${pasos(3, 'Cambie la contraseña del administrador (no deje admin123): la dirección queda en internet. ' + (w.clave_default ? '<span class="malo">(sigue siendo admin123: Configuración → Mi contraseña)</span>' : ''), !w.clave_default)}
      ${pasos(4, 'Presione <b>Activar dirección web</b>. La primera vez Tailscale pide aprobarlo: se abre una página, entre con la misma cuenta y presione <b>Enable</b>; luego regrese y presione otra vez Activar.', false)}</ol>
    <div class="row"><button class="btn pri" id="webBtn" onclick="webActivar(this)" ${w.conectado ? '' : 'disabled'}>Activar dirección web</button><button class="btn" onclick="webPintar()">Volver a revisar</button></div>
    ${w.error ? `<div class="sub" style="margin-top:8px">${esc(w.error)}</div>` : ''}${quien}`;
}
async function webActivar(b) {
  b.disabled = true; b.textContent = 'Activando… (puede tardar un minuto)';
  try {
    const r = await POST('/api/remoto/web/activar');
    if (r.aprobar) {
      window.open(r.aprobar, '_blank', 'noopener');
      return webPintar(`<div class="aviso">Falta aprobarlo una sola vez en Tailscale. Se abrió la página; si no se abrió, <a href="${esc(r.aprobar)}" target="_blank" rel="noopener"><b>toque aquí</b></a>. Entre con la cuenta del motel, presione <b>Enable</b> y regrese a presionar <b>Activar dirección web</b>.</div>`);
    }
    toast('Dirección web activada'); webPintar();
  } catch (e) { toast(e.message, true); webPintar(`<div class="aviso bad">${esc(e.message)}</div>`); }
}
async function webDesactivar() { await hacer(() => POST('/api/remoto/web/desactivar'), 'Dirección web desactivada'); webPintar(); }
async function webRol() { await hacer(() => PUT('/api/config', { web_roles: val('webRol') }), 'Guardado'); }
function copiarTexto(t) { (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast('Copiado')).catch(() => { const r = document.createRange(), el = $('#webUrl'); if (el) { r.selectNodeContents(el); getSelection().removeAllRanges(); getSelection().addRange(r); } toast('Seleccionado: presione Ctrl+C'); }); }

// ---------- Configuración → Plumas ----------
function cPlumas() {
  const bloque = (k, cual) => `<div class="card"><h2>${ico('pluma')} Pluma de ${cual}</h2><div class="f">
      <label class="l">Relevador<select id="${k}T" onchange="plTipo('${k}')"><option value="ninguna">No hay pluma</option><option value="shelly">Shelly Gen3 / Gen2 / Plus (recomendado)</option><option value="shelly1">Shelly Gen1 (modelo viejo)</option><option value="url">ESP32 / Arduino / otro (dirección web)</option></select></label>
      <label class="l" id="${k}IL">IP del relevador<input id="${k}I" value="${esc(CFG[k + '_ip'] || '')}" placeholder="192.168.1.60"></label>
      <label class="l" id="${k}UL">Dirección que abre la pluma<input id="${k}U" value="${esc(CFG[k + '_url'] || '')}" placeholder="http://192.168.1.60/abrir"></label>
      <label class="l" id="${k}SL">Segundos que se activa el relevador<input id="${k}S" type="number" min="0.2" max="30" step="0.1" value="${esc(CFG[k + '_seg'] || '1')}"></label></div>
    <div class="row" style="margin-top:10px"><button class="btn" onclick="plProbar('${cual}')">Probar (abrir ahora)</button><span class="sub" id="${k}R"></span></div></div>`;
  $('#cfgc').innerHTML = `<div class="stack"><p class="sub" style="margin:0">Las plumas se abren con un relevador en la red del motel (por ejemplo un Shelly 1 Gen3 conectado al botón de la pluma). Póngale IP fija al relevador en el módem.</p>
    ${bloque('pluma_e', 'entrada')}${bloque('pluma_s', 'salida')}
    <div class="card"><h2>¿Cuándo se abren solas?</h2><div class="stack" style="gap:6px">
      ${chk('plAE', CFG.pluma_auto_entrada !== '0', 'Abrir la pluma de ENTRADA al dar entrada a una habitación (al imprimir el ticket)')}
      ${chk('plAS', CFG.pluma_auto_salida !== '0', 'Abrir la pluma de SALIDA al registrar la salida de la habitación')}
      ${chk('plAV', CFG.pluma_auto_visitas !== '0', 'Abrir la pluma al registrar una visita: entrada cuando llega (Uber, taxi, carro, a pie) y salida cuando se va')}</div>
      <div class="sub" style="margin-top:8px">En Habitaciones también hay botones para abrirlas a mano; siempre piden el motivo y quedan en Reportes → Plumas.</div></div>
    <div><button class="btn pri" onclick="cPlumasOk()">Guardar</button></div></div>`;
  for (const k of ['pluma_e', 'pluma_s']) { $('#' + k + 'T').value = CFG[k + '_tipo'] || 'ninguna'; plTipo(k); }
}
function plTipo(k) { const t = val(k + 'T'); $('#' + k + 'IL').hidden = !['shelly', 'shelly1'].includes(t); $('#' + k + 'UL').hidden = t !== 'url'; $('#' + k + 'SL').hidden = t === 'ninguna' || t === 'url'; }
const plDatos = () => { const o = {}; for (const k of ['pluma_e', 'pluma_s']) Object.assign(o, { [k + '_tipo']: val(k + 'T'), [k + '_ip']: val(k + 'I'), [k + '_url']: val(k + 'U'), [k + '_seg']: val(k + 'S') || '1' }); return o; };
async function cPlumasOk() {
  await hacer(() => PUT('/api/config', { ...plDatos(), pluma_auto_entrada: $('#plAE').checked ? '1' : '0', pluma_auto_salida: $('#plAS').checked ? '1' : '0', pluma_auto_visitas: $('#plAV').checked ? '1' : '0' }), 'Guardado');
  CFG = await GET('/api/config');
}
async function plProbar(cual) {
  await PUT('/api/config', plDatos()); CFG = await GET('/api/config');
  const el = $('#' + (cual === 'entrada' ? 'pluma_e' : 'pluma_s') + 'R'); el.textContent = 'Abriendo…';
  try { const r = await POST('/api/motel/pluma/probar', { pluma: cual }); el.innerHTML = r.ok ? '<b style="color:var(--libre)">Abrió correctamente</b>' : `<span class="malo">${esc(r.error)}</span>`; }
  catch (e) { el.innerHTML = `<span class="malo">${esc(e.message)}</span>`; }
}
