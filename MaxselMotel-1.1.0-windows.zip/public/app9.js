// Maxsel Motel 1.8 — Tienda estilo punto de venta (tickets en espera, teclas F, verificador de precios)
// y ventana de cobro moderna para la tienda y para todos los cobros del motel
'use strict';

// ======================================================================
// Ventana de cobro (se abre solo al presionar Cobrar / Pagar)
// ======================================================================
const MET_COBRO = [
  ['efectivo', 'Efectivo', 'E', '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M6 9v.01M18 15v.01"/>'],
  ['dolares', 'Dólares', 'D', '<path d="M12 2v20M17 6.5c-1-1.3-2.7-2-5-2-3 0-4.5 1.5-4.5 3.5 0 4.5 10 2.5 10 7.5 0 2-1.8 3.5-5 3.5-2.4 0-4.2-.8-5.3-2.2"/>'],
  ['tarjeta', 'Tarjeta', 'T', '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h4"/>'],
  ['transferencia', 'Transferencia', 'R', '<path d="M4 8h13l-3-3M20 16H7l3 3"/>'],
  ['mixto', 'Mixto', 'M', '<circle cx="9" cy="9" r="5"/><circle cx="15" cy="15" r="5"/>'],
  ['habitacion', 'Cargar a habitación', 'H', '<path d="M3 21V8l9-5 9 5v13"/><path d="M9 21v-7h6v7"/>'],
];
let VC = null;
function ventanaCobro(o) {
  return new Promise((ok) => {
    const tc = tcHoy(), hab = (o.habitaciones || []).length > 0;
    VC = { ...o, tc, ok, metodo: 'efectivo', nota: '' };
    let el = $('#cobro'); if (!el) { el = document.createElement('div'); el.id = 'cobro'; document.body.appendChild(el); }
    const mets = MET_COBRO.filter((m) => m[0] !== 'habitacion' || hab);
    el.innerHTML = `<div class="vc" role="dialog" aria-modal="true" aria-label="Cobrar">
      <div class="vc-main"><div class="vc-cab"><span>${esc(o.titulo || 'Cobrar')}</span>${o.detalle ? `<small>${esc(o.detalle)}</small>` : ''}</div>
        <div class="vc-total" id="vcT">${money(o.total)}</div><div class="vc-usd">US$${(Math.ceil(o.total / tc * 100) / 100).toFixed(2)} · dólar a $${tc}</div>
        <div class="vc-mets">${mets.map(([k, n, t, svg]) => `<button type="button" data-m="${k}" onclick="vcMetodo('${k}')"><svg viewBox="0 0 24 24">${svg}</svg><span>${n}</span><kbd>${t}</kbd></button>`).join('')}</div>
        <div class="vc-zona" id="vcZ"></div></div>
      <div class="vc-lado"><button class="vc-b pri" onclick="vcOk(true)"><kbd>F1</kbd>Cobrar e imprimir</button><button class="vc-b" onclick="vcOk(false)"><kbd>F2</kbd>Cobrar sin imprimir</button><button class="vc-b" onclick="vcCancelar()"><kbd>Esc</kbd>Cancelar</button>
        ${o.notas !== false ? `<button class="vc-b sm" onclick="vcNota()"><kbd>F4</kbd>Nota</button><input id="vcNi" class="vc-nota" placeholder="Nota de la venta" hidden autocomplete="off">` : ''}
        ${o.articulos !== undefined ? `<div class="vc-art"><span>Total de artículos</span><b>${o.articulos}</b></div>` : ''}
        <div class="vc-art" id="vcRes"></div></div></div>`;
    el.hidden = false;
    vcMetodo(o.metodo || 'efectivo');
  });
}
const BILLETES = [20, 50, 100, 200, 500, 1000], BILL_USD = [1, 5, 10, 20, 50, 100];
function vcMetodo(m) {
  if (!VC) return;
  VC.metodo = m; document.querySelectorAll('.vc-mets button').forEach((b) => b.classList.toggle('on', b.dataset.m === m));
  const T = VC.total, z = $('#vcZ'), campo = (id, label, extra = '') => `<label class="vc-campo"><span>${label}</span><input id="${id}" type="number" min="0" step="0.01" inputmode="decimal" oninput="vcCalc()" ${extra}></label>`;
  if (m === 'efectivo') z.innerHTML = `${campo('vcPa', 'Pagó con (pesos)', `placeholder="${T.toFixed(2)}"`)}<div class="vc-bill"><button type="button" onclick="vcBill(0)">Exacto</button>${BILLETES.map((b) => `<button type="button" onclick="vcBill(${b})">$${b}</button>`).join('')}</div>`;
  else if (m === 'dolares') z.innerHTML = `${campo('vcPa', 'Dólares recibidos (US$)', `placeholder="${(Math.ceil(T / VC.tc * 100) / 100).toFixed(2)}"`)}<div class="vc-bill"><button type="button" onclick="vcBill(0)">Exacto</button>${BILL_USD.map((b) => `<button type="button" onclick="vcBill(${b})">US$${b}</button>`).join('')}</div>`;
  else if (m === 'tarjeta' || m === 'transferencia') z.innerHTML = `<div class="vc-fijo"><span>Se cobra con ${m === 'tarjeta' ? 'tarjeta' : 'transferencia'}</span><b>${money(T)}</b></div><label class="vc-campo"><span>${m === 'tarjeta' ? 'Últimos 4 dígitos / autorización (opcional)' : 'Folio o referencia (opcional)'}</span><input id="vcRef" autocomplete="off"></label>`;
  else if (m === 'mixto') z.innerHTML = `<div class="vc-mix">${campo('vcEf', 'Efectivo (pesos)')}${campo('vcUs', 'Dólares (US$)')}${campo('vcTa', 'Tarjeta')}${campo('vcTr', 'Transferencia')}</div>`;
  else z.innerHTML = `<label class="vc-campo"><span>Cargar a la cuenta de</span><select id="vcHab">${VC.habitaciones.map((h) => `<option value="${h.id}">${esc(h.numero)} · ${esc(h.estancia.huesped)}</option>`).join('')}</select></label><div class="sub">Se suma a la cuenta del huésped y se cobra al salir.</div>`;
  vcCalc();
  setTimeout(() => z.querySelector('input,select')?.focus(), 0);
}
function vcBill(b) {
  const i = $('#vcPa'); if (!i) return;
  if (!b) i.value = VC.metodo === 'dolares' ? (Math.ceil(VC.total / VC.tc * 100) / 100).toFixed(2) : VC.total.toFixed(2);
  else i.value = ((parseFloat(i.value) || 0) + b).toFixed(2); // como en caja: se van sumando los billetes que da el cliente
  vcCalc(); i.focus();
}
function vcRecibido() {
  const m = VC.metodo, T = VC.total, g = (id) => parseFloat($('#' + id)?.value) || 0;
  if (m === 'efectivo') { const p = g('vcPa') || T; return { partes: { efectivo: p }, total: p }; }
  if (m === 'dolares') { const u = g('vcPa') || Math.ceil(T / VC.tc * 100) / 100; return { partes: { usd: u }, total: u * VC.tc, usd: u }; }
  if (m === 'tarjeta') return { partes: { tarjeta: T }, total: T };
  if (m === 'transferencia') return { partes: { transferencia: T }, total: T };
  if (m === 'mixto') { const p = { efectivo: g('vcEf'), usd: g('vcUs'), tarjeta: g('vcTa'), transferencia: g('vcTr') }; return { partes: p, total: p.efectivo + p.usd * VC.tc + p.tarjeta + p.transferencia, usd: p.usd }; }
  return { partes: null, total: T };
}
function vcCalc() {
  if (!VC) return;
  const r = vcRecibido(), T = VC.total, falta = T - r.total, el = $('#vcRes');
  if (VC.metodo === 'habitacion') { el.innerHTML = '<span>Se carga a la habitación</span>'; return; }
  el.innerHTML = falta > 0.009 ? `<span>Faltan</span><b class="malo">${money(falta)}</b>` : `<span>Cambio</span><b class="cambio">${money(r.total - T)}</b>${r.usd ? `<small>Recibe US$${r.usd.toFixed(2)} = ${money(r.usd * VC.tc)}</small>` : ''}`;
}
function vcNota() { const i = $('#vcNi'); if (!i) return; i.hidden = false; i.focus(); }
function vcCancelar() { const v = VC; VC = null; $('#cobro').hidden = true; v?.ok(null); }
function vcOk(imprimirT) {
  if (!VC) return;
  const r = vcRecibido(), T = VC.total;
  if (VC.metodo !== 'habitacion' && r.total + 0.009 < T) { toast('Faltan ' + money(T - r.total), true); return; }
  if (VC.metodo === 'mixto' && (r.partes.tarjeta + r.partes.transferencia) > T + 0.009) { toast('Lo de tarjeta y transferencia no puede pasar del total', true); return; }
  VC.nota = $('#vcNi')?.value.trim() || '';
  const ref = $('#vcRef')?.value.trim(), v = VC, nota = [v.nota, ref ? (v.metodo === 'tarjeta' ? 'Tarjeta ' : 'Ref. ') + ref : ''].filter(Boolean).join(' · ');
  VC = null; $('#cobro').hidden = true;
  v.ok({ metodo: v.metodo === 'habitacion' ? 'habitacion' : 'mixto', partes: r.partes, habitacion_id: $('#vcHab')?.value, imprimir: imprimirT, nota, cambio: Math.max(0, r.total - T), recibido: r.total });
}
document.addEventListener('keydown', (e) => {
  if (!VC || $('#cobro')?.hidden) return;
  const k = e.key, enCampo = document.activeElement?.closest?.('#cobro') && /INPUT|SELECT/.test(document.activeElement.tagName) && document.activeElement.type !== 'number';
  if (k === 'F1' || (k === 'Enter' && document.activeElement?.id !== 'vcNi')) { e.preventDefault(); e.stopPropagation(); vcOk(true); return; }
  if (k === 'F2') { e.preventDefault(); e.stopPropagation(); vcOk(false); return; }
  if (k === 'Escape') { e.preventDefault(); e.stopPropagation(); vcCancelar(); return; }
  if (k === 'F4') { e.preventDefault(); e.stopPropagation(); vcNota(); return; }
  if (!enCampo && k.length === 1 && /[a-z]/i.test(k)) {
    const m = MET_COBRO.find((x) => x[2] === k.toUpperCase() && document.querySelector(`.vc-mets button[data-m="${x[0]}"]`));
    e.preventDefault(); if (m) vcMetodo(m[0]);
  }
}, true);

// ======================================================================
// Cobros del motel: el pago ya no se llena en la ventana; al presionar el botón se abre la ventana de cobro
// ======================================================================
{
  const _sel = selPago;
  selPago = function (id, vacio, modo = '', monto = '') {
    if (modo !== '') return _sel(id, vacio, modo, monto);
    const h = (k) => `<input type="hidden" id="${id}_${k}">`;
    return `<input type="hidden" id="${id}" value="mixto" data-monto="${monto}" data-modo="">${h('ef')}${h('us')}${h('ta')}${h('tr')}<div class="vc-aviso">Al guardar se abre la ventana de cobro</div><small id="${id}_h" hidden></small>`;
  };
}
const llenarPago = (id, r) => { const p = r.partes || {}; for (const [k, c] of [['ef', 'efectivo'], ['us', 'usd'], ['ta', 'tarjeta'], ['tr', 'transferencia']]) { const el = $(`#${id}_${k}`); if (el) el.value = p[c] || ''; } };
let SIN_IMPRIMIR = false;
{
  const _imp = imprimir; imprimir = function (...a) { if (SIN_IMPRIMIR) return; return _imp(...a); };
  const _doc = imprimirDoc; imprimirDoc = function (...a) { if (SIN_IMPRIMIR) return; return _doc(...a); };
}
// Qué cobro pide cada botón: [campo del pago, de dónde sale el monto, título]
const COBROS = {
  rOk: () => [['rF', num('rA'), 'Registro: anticipo', $('.mbox h3')?.textContent], ['rDepF', num('rDep'), 'Depósito en garantía']],
  extOk: () => [['xF', num('xP'), 'Extensión / cambio de renta']],
  pagoOk: () => [['aF', num('aM'), document.querySelector('input[name=aT]:checked')?.value === 'anticipo' ? 'Anticipo' : 'Abono a la cuenta']],
  salidaOk: () => [['sF', Number($('#sF')?.dataset.monto) || 0, 'Liquidación al salir']],
  visOk: () => [['vPf', num('vC'), 'Cobro de visita', 'Visitante: ' + val('vN')]],
  depOk: () => [['dF', num('dM'), 'Depósito en garantía']],
  cargoOk: () => (document.querySelector('input[name=cgCo]:checked')?.value === 'ahora' ? [['cgF', num('cgTot'), val('cgD') || 'Multa o cuota']] : []),
};
for (const [fn, lista] of Object.entries(COBROS)) {
  const orig = window[fn]; if (typeof orig !== 'function') continue;
  window[fn] = async function (...args) {
    let imp = true;
    for (const [id, monto, titulo, detalle] of lista()) {
      if (!$('#' + id) || !(monto > 0)) continue;
      const r = await ventanaCobro({ total: monto, titulo, detalle, notas: false });
      if (!r) return;
      llenarPago(id, r); imp = imp && r.imprimir;
    }
    SIN_IMPRIMIR = !imp;
    try { return await orig.apply(this, args); } finally { setTimeout(() => { SIN_IMPRIMIR = false; }, 1500); }
  };
}

// ======================================================================
// Tienda estilo punto de venta
// ======================================================================
// Las ventas del día solo las ve el gerente o el administrador (los cajeros no)
const verVentas = () => YO && (YO.rol === 'admin' || YO.rol === 'gerente' || puede('reportes'));
let TICKETS = [{ items: [] }], TK = 0, SEL = -1, ULTIMA = null;
carrito = TICKETS[0].items;
const totalT = (t) => t.items.reduce((s, l) => s + l.cantidad * l.precio, 0), artT = (t) => t.items.reduce((s, l) => s + l.cantidad, 0);
async function vTienda() {
  [PRODS, TAB] = await Promise.all([GET('/api/productos'), GET('/api/tablero')]);
  pintarTienda(await GET('/api/ventas'));
}
function pintarTienda(ventas) {
  if (ventas) pintarTienda.v = ventas; ventas = pintarTienda.v || [];
  carrito = TICKETS[TK].items;
  if (SEL >= carrito.length) SEL = carrito.length - 1;
  const AREAS = [...new Set(PRODS.map((p) => p.area || 'Sin área'))].sort((a, b) => a.localeCompare(b, 'es'));
  const ps = PRODS.filter((p) => !tArea || (p.area || 'Sin área') === tArea), tot = totalT(TICKETS[TK]), hoyT = ventas.filter((v) => !v.cancelada).reduce((s, v) => s + v.total, 0);
  const T = (k, n, f, cls = '') => `<button class="pk ${cls}" onclick="${f}"><kbd>${k}</kbd><span>${n}</span></button>`;
  $('#main').innerHTML = `<div class="pv">
    <div class="pv-top"><div class="pv-tks"><button class="on">Venta actual${carrito.length ? ` <small>${money(tot)}</small>` : ''}</button></div>
      ${verVentas() ? `<div class="pv-hoy">Ventas de hoy <b>${money(hoyT)}</b> · ${ventas.filter((v) => !v.cancelada).length} tickets</div>` : ''}</div>
    <div class="pv-teclas">${T('F10', 'Buscar producto', 'tBuscar()')}${T('F9', 'Verificar precio', 'tVerificar()')}${T('*', 'Cantidad', "tCantidad()")}${T('Supr', 'Quitar artículo', 'tQuitar()')}${T('F11', 'Reimprimir último', 'tReimprimir()')}${verVentas() ? T('F3', 'Ventas del día', 'tVentasDia()') : ''}</div>
    <div class="pv-cuerpo">
      <div class="pv-izq"><div class="scan">${ico('scan')}<input id="qP" placeholder="Escanee el código o escriba cantidad*código (ej. 3*7501055300075)" autocomplete="off"><span class="sub">Listo para escanear</span></div>
        <div class="pv-tabla"><table><thead><tr><th>Código</th><th>Descripción</th><th class="n">Precio</th><th class="n">Cant.</th><th class="n">Importe</th><th></th></tr></thead><tbody>
        ${carrito.map((l, i) => `<tr class="${i === SEL ? 'sel' : ''}" onclick="SEL=${i};pintarTienda()"><td class="mono">${esc(l.codigo || '')}</td><td><b>${esc(l.nombre)}</b></td><td class="n">${money(l.precio)}</td>
          <td class="n"><span class="qty"><button onclick="event.stopPropagation();cant(${i},-1)" aria-label="Quitar uno">−</button><b>${l.cantidad}</b><button onclick="event.stopPropagation();cant(${i},1)" aria-label="Agregar uno">+</button></span></td><td class="n"><b>${money(l.cantidad * l.precio)}</b></td>
          <td><button class="x" onclick="event.stopPropagation();SEL=${i};tQuitar()" aria-label="Quitar">×</button></td></tr>`).join('') || `<tr><td colspan="6" class="pv-vacio">${ico('scan')}<div>Escanee un producto o tóquelo en la lista de la derecha</div></td></tr>`}</tbody></table></div>
        <div class="pv-pie"><div><span>${artT(TICKETS[TK])} artículo(s)</span></div><div class="pv-total"><span>Total</span><b>${money(tot)}</b></div>
          <button class="pv-cobrar" ${carrito.length ? '' : 'disabled'} onclick="cobrar()"><kbd>F12</kbd> Cobrar</button></div></div>
      <div class="pv-der"><div class="chips areas"><button class="chip ${!tArea ? 'on' : ''}" onclick="tArea='';pintarTienda()">Todo</button>${AREAS.map((a) => `<button class="chip ${tArea === a ? 'on' : ''}" data-a="${esc(a)}" onclick="tArea=this.dataset.a;pintarTienda()">${esc(a)}</button>`).join('')}</div>
        <div class="prods">${ps.map((p) => `<button class="prod ${p.servicio ? 'serv' : ''}" ${!p.servicio && p.existencia <= 0 ? 'disabled' : ''} onclick="agregar(${p.id})"><span>${esc(p.nombre)}</span><b>${money(p.precio)}</b><small>${p.servicio ? 'Servicio' : p.existencia <= 0 ? 'Agotado' : 'Quedan ' + p.existencia}</small></button>`).join('') || '<div class="empty">Sin productos. Agréguelos en Inventario.</div>'}</div></div></div></div>`;
  const qp = $('#qP');
  qp.onkeydown = (e) => {
    if (e.key === 'Enter') { e.preventDefault(); tEscaneo(qp.value); qp.value = ''; return; }
    if (!qp.value && (e.key === '+' || e.key === '-')) { e.preventDefault(); if (SEL >= 0) cant(SEL, e.key === '+' ? 1 : -1); return; }
    if (!qp.value && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) { e.preventDefault(); if (carrito.length) { SEL = Math.max(0, Math.min(carrito.length - 1, SEL + (e.key === 'ArrowUp' ? -1 : 1))); pintarTienda(); } }
  };
  const a = document.activeElement; if (!a || a === document.body || a.tagName === 'BUTTON') qp.focus();
}
// "3*código" agrega 3; un código exacto agrega 1; un texto busca por nombre
function tEscaneo(t) {
  t = String(t || '').trim(); if (!t) return;
  let c = 1; const m = t.match(/^(\d+(?:\.\d+)?)\s*[*xX]\s*(.+)$/); if (m) { c = parseFloat(m[1]) || 1; t = m[2].trim(); }
  const p = PRODS.find((x) => x.codigo && x.codigo === t);
  if (p) return agregar(p.id, c);
  const l = PRODS.filter((x) => x.nombre.toLowerCase().includes(t.toLowerCase()));
  if (l.length === 1) return agregar(l[0].id, c);
  if (l.length > 1) return tBuscar(t);
  toast('No hay producto con el código ' + t, true); beep(220);
}
function beep(f = 880) { try { const a = beep.a || (beep.a = new AudioContext()), o = a.createOscillator(), g = a.createGain(); g.gain.value = 0.08; o.frequency.value = f; o.connect(g); g.connect(a.destination); o.start(); o.stop(a.currentTime + 0.08); } catch { /* sin sonido */ } }
function agregar(id, c = 1) {
  const p = PRODS.find((x) => x.id === id); if (!p) return;
  const i = carrito.findIndex((x) => x.producto_id === id), ya = i >= 0 ? carrito[i].cantidad : 0;
  if (!p.servicio && ya + c > p.existencia) { toast(`Solo hay ${p.existencia} de ${p.nombre}`, true); beep(220); return; }
  if (i >= 0) { carrito[i].cantidad = +(ya + c).toFixed(3); SEL = i; } else { carrito.push({ producto_id: id, nombre: p.nombre, codigo: p.codigo, precio: p.precio, cantidad: c }); SEL = carrito.length - 1; }
  beep(); qProd = ''; pintarTienda(); $('#qP')?.focus();
}
function cant(i, d) {
  const l = carrito[i]; if (!l) return; const p = PRODS.find((x) => x.id === l.producto_id);
  if (d > 0 && !p?.servicio && l.cantidad + d > (p?.existencia ?? 0)) return toast('No hay más existencia', true);
  l.cantidad = +(l.cantidad + d).toFixed(3); if (l.cantidad <= 0) carrito.splice(i, 1);
  pintarTienda(); $('#qP')?.focus();
}
function tQuitar() { if (SEL < 0 || !carrito[SEL]) return toast('Seleccione el artículo a quitar', true); carrito.splice(SEL, 1); SEL = Math.min(SEL, carrito.length - 1); pintarTienda(); }
function tCantidad() {
  if (SEL < 0 || !carrito[SEL]) return toast('Seleccione un artículo del ticket', true);
  const l = carrito[SEL];
  modal('Cantidad', `<label class="l">${esc(l.nombre)}<input id="tcN" type="number" min="0" step="any" value="${l.cantidad}"></label>`, '<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="tCantidadOk()">Aceptar</button>');
  const i = $('#tcN'); i.select(); i.onkeydown = (e) => { if (e.key === 'Enter') tCantidadOk(); };
}
function tCantidadOk() {
  const l = carrito[SEL], c = parseFloat(val('tcN')), p = PRODS.find((x) => x.id === l.producto_id);
  if (!p?.servicio && c > (p?.existencia ?? 0)) return toast(`Solo hay ${p.existencia}`, true);
  if (!(c > 0)) carrito.splice(SEL, 1); else l.cantidad = c;
  cerrar(); pintarTienda();
}
function tkNuevo() { if (!carrito.length) return toast('Este ticket está vacío'); TICKETS.push({ items: [] }); TK = TICKETS.length - 1; SEL = -1; pintarTienda(); toast('El ticket anterior quedó en espera'); }
function tkIr(i) { TK = i; SEL = TICKETS[i].items.length - 1; pintarTienda(); }
function tkCerrar() { TICKETS.splice(TK, 1); if (!TICKETS.length) TICKETS.push({ items: [] }); TK = Math.min(TK, TICKETS.length - 1); SEL = -1; }
function tBuscar(q = '') {
  modal('Buscar producto', `<input id="bqP" placeholder="Nombre, código o área" value="${esc(q)}" autocomplete="off" oninput="tBuscarPintar()"><div class="tw" style="max-height:420px;margin-top:10px"><table><thead><tr><th>Código</th><th>Producto</th><th>Área</th><th class="n">Precio</th><th class="n">Existencia</th></tr></thead><tbody id="bqL"></tbody></table></div>`, '<button class="btn" onclick="cerrar()">Cerrar</button>', true);
  tBuscarPintar(); $('#bqP').focus();
  $('#bqP').onkeydown = (e) => { if (e.key === 'Enter') { const f = $('#bqL tr[data-id]'); if (f) { cerrar(); agregar(Number(f.dataset.id)); } } };
}
function tBuscarPintar() {
  const q = val('bqP').toLowerCase(), l = PRODS.filter((p) => (p.nombre + ' ' + (p.codigo || '') + ' ' + (p.area || '')).toLowerCase().includes(q)).slice(0, 100);
  $('#bqL').innerHTML = l.map((p) => `<tr class="click" data-id="${p.id}" onclick="cerrar();agregar(${p.id})"><td class="mono">${esc(p.codigo || '')}</td><td><b>${esc(p.nombre)}</b></td><td>${esc(p.area || '')}</td><td class="n">${money(p.precio)}</td><td class="n">${p.existencia}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">No se encontró.</td></tr>';
}
function tVerificar() {
  modal('Verificador de precios', `<div class="scan">${ico('scan')}<input id="vpC" placeholder="Escanee el producto" autocomplete="off"></div><div id="vpR" class="vp-res"><span class="sub">Escanee un código para ver su precio sin agregarlo al ticket.</span></div>`, '<button class="btn" onclick="cerrar()">Cerrar</button>');
  const i = $('#vpC'); i.focus();
  i.onkeydown = (e) => { if (e.key !== 'Enter') return; const c = i.value.trim(), p = PRODS.find((x) => x.codigo === c) || PRODS.find((x) => x.nombre.toLowerCase().includes(c.toLowerCase()));
    $('#vpR').innerHTML = p ? `<b>${esc(p.nombre)}</b><div class="vp-precio">${money(p.precio)}</div><span class="sub">${esc(p.area || '')} · quedan ${p.existencia}</span>` : `<span class="malo">No existe el producto ${esc(c)}</span>`; i.value = ''; };
}
function tVentasDia() {
  const v = pintarTienda.v || [];
  modal('Ventas de hoy', `<div class="tw" style="max-height:460px"><table><thead><tr><th>Folio</th><th>Hora</th><th>Productos</th><th>Pago</th><th class="n">Total</th><th></th></tr></thead><tbody>
    ${v.map((x) => `<tr style="${x.cancelada ? 'opacity:.5;text-decoration:line-through' : ''}"><td class="mono">${x.folio}</td><td>${fdt(x.fecha)}</td><td>${x.items.map((i) => i.cantidad + ' ' + esc(i.descripcion)).join(', ')}${x.nota ? `<div class="sub">${esc(x.nota)}</div>` : ''}</td><td>${MET[x.metodo] || x.metodo}${x.numero ? ' ' + esc(x.numero) : ''}</td><td class="n">${money(x.total)}</td>
      <td>${!x.cancelada && puede('cancelar') ? `<button class="btn sm bad" onclick="confirmar(this,()=>cancelarVenta(${x.id}))">Cancelar</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">Aún no hay ventas hoy.</td></tr>'}</tbody></table></div>`, '<button class="btn" onclick="cerrar()">Cerrar</button>', true);
}
async function cancelarVenta(id) { await hacer(() => POST(`/api/ventas/${id}/cancelar`), 'Venta cancelada'); cerrar(); vTienda(); }
function ticketTienda(v, nota) {
  const w = W();
  return [...encabezado(), 'VENTA  Folio ' + v.folio, fdt(v.fecha), '-'.repeat(w), ...v.items.map((i) => lin(i.cantidad + ' ' + i.descripcion, money(i.importe))), '-'.repeat(w), lin('TOTAL', money(v.total)),
    ...(v.metodo === 'habitacion' ? ['Cargado a la habitación ' + v.numero] : lineasPago({ total: v.recibido, usd: v.pago?.usd, tc: v.pago?.tc, cambio: v.cambio })), ...(nota ? wrapT('Nota: ' + nota) : []), '', CFG.ticket_pie || ''];
}
function tReimprimir() { if (!ULTIMA) return toast('Aún no hay ventas en esta sesión', true); imprimir(ticketTienda(ULTIMA.v, ULTIMA.nota)); }
async function cobrar() {
  if (!carrito.length) return toast('El ticket está vacío', true);
  const tot = totalT(TICKETS[TK]), oc = sortH((TAB?.habitaciones || []).filter((h) => h.estado === 'ocupada' && h.estancia));
  const r = await ventanaCobro({ total: tot, titulo: 'Cobrar venta', articulos: artT(TICKETS[TK]), habitaciones: oc });
  if (!r) { $('#qP')?.focus(); return; }
  const hab = r.metodo === 'habitacion';
  const v = await hacer(() => POST('/api/ventas', { items: carrito.map(({ producto_id, cantidad }) => ({ producto_id, cantidad })), metodo: hab ? 'habitacion' : 'mixto', habitacion_id: hab ? r.habitacion_id : undefined, partes: hab ? undefined : r.partes, nota: r.nota }), hab ? 'Cargado a la habitación' : 'Venta cobrada');
  ULTIMA = { v, nota: r.nota };
  if (!hab && v.cambio > 0) toast('Cambio: ' + money(v.cambio));
  tkCerrar(); await vTienda(); pintarTurno();
  if (r.imprimir) imprimir(ticketTienda(v, r.nota));
}
// Teclas de la tienda
document.addEventListener('keydown', (e) => {
  if (vista !== 'tienda' || !$('.pv') || !$('#modal').hidden || (VC && !$('#cobro').hidden)) return;
  const k = e.key, acc = { F12: cobrar, F10: () => tBuscar(), F9: tVerificar, F11: tReimprimir, F3: () => verVentas() && tVentasDia() }[k];
  if (acc) { e.preventDefault(); e.stopPropagation(); acc(); return; }
  if (k === 'Delete' && !$('#qP').value) { e.preventDefault(); tQuitar(); return; }
  if (k === '*' && !$('#qP').value) { e.preventDefault(); tCantidad(); }
});

// ======================================================================
// Configuración → Portal de mantenimiento (celular del personal de mantenimiento)
// ======================================================================
async function cMantPortal() {
  const ips = CFG._ips || [], loc = ips.filter((i) => !i.tailscale), ts = ips.filter((i) => i.tailscale), p = CFG._puerto || 3080;
  const U = (await GET('/api/usuarios').catch(() => [])).filter((u) => u.rol === 'mantenimiento');
  const url = (i) => `http://${i.ip}:${p}`;
  $('#cfgc').innerHTML = `<div class="stack">
    <div class="card"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px"><h2 style="margin:0">Portal de mantenimiento en el celular</h2><button class="btn" onclick="imprimirPortalMant()">Imprimir instrucciones para el personal</button></div>
      <p class="sub">El personal de mantenimiento entra desde su celular, ve los reportes con fotos, los atiende y los marca como reparados con foto del arreglo. Al marcarlo reparado, la habitación se libera sola.</p>
      <div class="lbl">Dirección para abrir en el celular (conectado al WiFi del motel)</div>
      ${loc.map((i) => `<div class="codigo" style="font-size:22px">${esc(url(i))}</div>`).join('') || '<div class="aviso bad">Esta computadora no está conectada a la red. Conéctela al módem del motel.</div>'}
      ${ts.length ? `<div class="lbl" style="margin-top:10px">Desde fuera del motel (con Tailscale en el celular)</div>${ts.map((i) => `<div class="codigo" style="font-size:18px">${esc(url(i))}</div>`).join('')}` : ''}</div>
    <div class="card"><h2>Pasos para dejarlo funcionando</h2><ol class="pasos">
      <li><b>Cree un usuario de tipo Mantenimiento</b> para cada persona. <button class="btn sm pri" onclick="nuevoUsuarioMant()">Crear usuario de mantenimiento</button></li>
      <li>En el celular de esa persona, <b>conéctese al WiFi del motel</b> (el mismo de esta computadora).</li>
      <li>Abra <b>Chrome</b> (Android) o <b>Safari</b> (iPhone) y escriba la dirección de arriba${loc[0] ? `: <b class="mono">${esc(url(loc[0]))}</b>` : ''}.</li>
      <li>Entre con el <b>usuario y contraseña</b> que creó en el paso 1. Solo verá el panel de mantenimiento.</li>
      <li>Déjelo como app: en Android, menú <b>⋮ → Agregar a la pantalla principal</b>; en iPhone, botón <b>Compartir → Agregar a inicio</b>.</li>
      <li>Si no abre: revise que el celular esté en el WiFi del motel (no con datos) y que esta computadora esté encendida con el sistema abierto. Si sigue sin abrir, permita el puerto ${p} en el Firewall de Windows.</li></ol></div>
    <div class="card"><h2>Cómo se usa</h2><ol class="pasos">
      <li><b>Recepción reporta</b>: en Habitaciones toque la habitación → <b>Reportar desperfecto</b>, o en Mantenimiento → Reportar desperfecto. Escriba qué falla, la prioridad y tome fotos.</li>
      <li><b>Mantenimiento recibe</b> el reporte en su celular y toca <b>Empezar a atender</b>.</li>
      <li>Al terminar toca <b>Marcar como reparado</b>, toma foto del arreglo y anota el costo de material (se registra como gasto).</li>
      <li>La habitación pasa sola a limpieza o a lista, y todo queda en el historial con fotos de antes y después.</li></ol></div>
    <div class="card"><h2>Usuarios de mantenimiento · ${U.length}</h2>${U.length ? `<div class="kv">${U.map((u) => `<span><b>${esc(u.nombre)}</b></span><span class="mono">${esc(u.usuario)} ${u.activo ? '<span class="pill p-ok">Activo</span>' : '<span class="pill p-bad">Inactivo</span>'}</span>`).join('')}</div>` : '<div class="empty">Todavía no hay usuarios de mantenimiento. Créelos con el botón del paso 1.</div>'}</div></div>`;
}
async function nuevoUsuarioMant() {
  PERMS = PERMS || await GET('/api/permisos'); cUsers.l = cUsers.l || await GET('/api/usuarios');
  userModal(); $('#uR').value = 'mantenimiento'; permisosRol();
}
function imprimirPortalMant() {
  const loc = (CFG._ips || []).filter((i) => !i.tailscale), p = CFG._puerto || 3080;
  imprimirDoc(`<div class="rep"><div class="rep-enc"><b>${esc(CFG.hotel_nombre)}</b><span>PORTAL DE MANTENIMIENTO</span><span>Instrucciones para el personal</span></div>
    <h3>Cómo entrar desde su celular</h3><ol style="font-size:15px;line-height:1.8"><li>Conéctese al WiFi del motel.</li><li>Abra Chrome o Safari y escriba:<div style="font-size:26px;font-weight:800;margin:6px 0">${loc.map((i) => `http://${esc(i.ip)}:${p}`).join('<br>') || '(pida la dirección en recepción)'}</div></li>
      <li>Entre con su usuario: ____________________ &nbsp; contraseña: ____________________</li><li>Agréguelo a la pantalla de inicio para abrirlo como app.</li></ol>
    <h3>Cómo atender un reporte</h3><ol style="font-size:15px;line-height:1.8"><li>Abra el reporte y vea las fotos del desperfecto.</li><li>Toque <b>Empezar a atender</b>.</li><li>Al terminar toque <b>Marcar como reparado</b>, tome foto del arreglo y anote el costo del material.</li></ol></div>`, 'carta', 'Portal de mantenimiento');
}
