// Maxsel Motel 1.6 — Gastos por secciones: movimientos, empleados, proveedores y gastos fijos; nómina y lista de raya
'use strict';
let gTab = 'mov', gBajas = false, EMPS = [], PROVS = [];
const PERIODO_PAGO = { semanal: 'Semanal', catorcenal: 'Catorcenal', quincenal: 'Quincenal', mensual: 'Mensual' };
// Qué datos pide cada clasificación
function tipoGrupo(grupo) {
  const t = String(grupo || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  if (/nomina|personal|emplead|sueld/.test(t)) return 'empleado';
  if (/impuesto|gobierno|fiscal|sat|imss/.test(t)) return 'impuesto';
  if (/otro/.test(t)) return 'otro';
  return 'proveedor';
}
const mesActual = () => new Date().toLocaleDateString('es-MX', { month: 'long', year: 'numeric' });

// ---------- Secciones de Gastos ----------
{
  const _vGastos = vGastos;
  vGastos = async function () {
    if (gTab === 'mov') await _vGastos();
    else $('#main').innerHTML = cab('Gastos', { emp: 'Empleados: datos, sueldo e historial de pagos', prov: 'Proveedores: datos e historial de pagos', fijos: 'Luz, agua, internet, lavandería, publicidad… con aviso de vencimiento', cxp: 'Lo que se les debe a los proveedores y cuándo vence' }[gTab], gTab === 'emp' ? `${puede('personal') ? '<button class="btn" onclick="nominaModal()">Pagar nómina</button><button class="btn pri" onclick="empModal()">Agregar empleado</button>' : ''}`
      : gTab === 'prov' ? '<button class="btn pri" onclick="provModal()">Agregar proveedor</button>' : gTab === 'cxp' ? '<button class="btn pri" onclick="cxpModal()">Nueva cuenta por pagar</button>' : '');
    const nF = (typeof AVISOS !== 'undefined' ? AVISOS.length : 0);
    const nC = (typeof CXP_AV !== 'undefined' ? CXP_AV.length : 0);
    const T = [['mov', 'Gastos'], ...(puede('personal') ? [['emp', 'Empleados'], ['prov', 'Proveedores']] : []), ...(puede('cuentas_pagar') ? [['cxp', 'Cuentas por pagar' + (nC ? ` (${nC})` : '')]] : []), ['fijos', 'Gastos fijos' + (nF ? ` (${nF})` : '')]];
    $('#main .top')?.insertAdjacentHTML('afterend', `<div class="tabs" style="margin-bottom:14px">${T.map(([k, n]) => `<button class="${gTab === k ? 'on' : ''}" onclick="gTab='${k}';vGastos()">${n}</button>`).join('')}</div>`);
    const zona = (html) => $('#main .tabs').insertAdjacentHTML('afterend', html);
    if (gTab === 'fijos') { try { FIJOS = await GET('/api/gastos-fijos'); } catch { FIJOS = []; } zona(tarjetasFijos()); }
    if (gTab === 'emp') { EMPS = await GET('/api/empleados' + (gBajas ? '?todos=1' : '')); zona(tablaEmpleados()); }
    if (gTab === 'prov') { PROVS = await GET('/api/proveedores' + (gBajas ? '?todos=1' : '')); zona(tablaProveedores()); }
    if (gTab === 'cxp') zona(await tablaCxp());
  };
}
function tablaEmpleados() {
  const tot = EMPS.filter((e) => e.activo).reduce((s, e) => s + e.pagado.t, 0);
  return `<div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px;flex-wrap:wrap"><h2 style="margin:0">${EMPS.filter((e) => e.activo).length} empleado(s) activos · pagado este mes ${money(tot)}</h2>
    <label class="row" style="font-weight:600;font-size:13px"><input type="checkbox" ${gBajas ? 'checked' : ''} onchange="gBajas=this.checked;vGastos()"> Ver también los dados de baja</label></div>
    <div class="tw"><table><thead><tr><th>Nombre</th><th>Puesto</th><th>Teléfono</th><th>Ingreso</th><th class="n">Sueldo</th><th class="n">Pagado este mes</th><th></th></tr></thead><tbody>
    ${EMPS.map((e) => `<tr class="click" style="${e.activo ? '' : 'opacity:.55'}" onclick="verEmpleado(${e.id})"><td><b>${esc(e.nombre)}</b>${e.activo ? '' : ' <span class="pill">Baja</span>'}</td><td>${esc(e.puesto || '')}</td><td>${esc(e.telefono || '')}</td><td>${e.ingreso ? fd(e.ingreso) : ''}</td>
      <td class="n">${e.sueldo ? money(e.sueldo) + `<div class="sub">${PERIODO_PAGO[e.periodo_pago] || ''}</div>` : '—'}</td><td class="n">${money(e.pagado.t)}<div class="sub">${e.pagado.n} pago(s)</div></td>
      <td><button class="btn sm" onclick="event.stopPropagation();gastoModal({empleado_id:${e.id}})">Registrar pago</button></td></tr>`).join('') || '<tr><td colspan="7" class="empty">Agregue a sus empleados para llevar el control de nómina, bonos y pagos.</td></tr>'}</tbody></table></div></div>`;
}
function tablaProveedores() {
  return `<div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px;flex-wrap:wrap"><h2 style="margin:0">${PROVS.filter((x) => x.activo).length} proveedor(es)</h2>
    <label class="row" style="font-weight:600;font-size:13px"><input type="checkbox" ${gBajas ? 'checked' : ''} onchange="gBajas=this.checked;vGastos()"> Ver también los dados de baja</label></div>
    <div class="tw"><table><thead><tr><th>Proveedor</th><th>Qué surte</th><th>Contacto</th><th>Teléfono</th><th class="n">Pagado este mes</th><th></th></tr></thead><tbody>
    ${PROVS.map((x) => `<tr class="click" style="${x.activo ? '' : 'opacity:.55'}" onclick="verProveedor(${x.id})"><td><b>${esc(x.nombre)}</b>${x.activo ? '' : ' <span class="pill">Baja</span>'}${x.rfc ? `<div class="sub">RFC ${esc(x.rfc)}</div>` : ''}</td><td>${esc(x.surte || '')}</td><td>${esc(x.contacto || '')}</td><td>${esc(x.telefono || '')}</td>
      <td class="n">${money(x.pagado.t)}<div class="sub">${x.pagado.n} pago(s)</div></td><td><button class="btn sm" onclick="event.stopPropagation();gastoModal({proveedor_id:${x.id}})">Registrar pago</button></td></tr>`).join('') || '<tr><td colspan="6" class="empty">Agregue a sus proveedores (tienda, mantenimiento, contador…).</td></tr>'}</tbody></table></div></div>`;
}

// ---------- Empleados ----------
function empModal(id) {
  const e = id ? EMPS.find((x) => x.id === id) || verEmpleado.e : { nombre: '', puesto: '', telefono: '', ingreso: hoyISO(), sueldo: '', periodo_pago: 'semanal', nss: '', rfc: '', curp: '', domicilio: '', emergencia: '', notas: '', activo: 1 };
  const I = (k, n, extra = '') => `<label class="l">${n}<input id="em_${k}" value="${esc(e[k] ?? '')}" ${extra}></label>`;
  modal(id ? 'Editar empleado' : 'Nuevo empleado', `<div class="f">${I('nombre', 'Nombre completo')}${I('puesto', 'Puesto', 'placeholder="Recepción, camarista, mantenimiento…"')}${I('telefono', 'Teléfono', 'inputmode="tel"')}
    <label class="l">Fecha de ingreso<input id="em_ingreso" type="date" value="${esc(e.ingreso || '')}"></label>
    <label class="l">Sueldo<input id="em_sueldo" type="number" min="0" step="0.01" value="${e.sueldo || ''}"></label>
    <label class="l">Se le paga<select id="em_periodo_pago">${Object.entries(PERIODO_PAGO).map(([k, n]) => `<option value="${k}" ${k === e.periodo_pago ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
    ${I('nss', 'Número de Seguro Social (IMSS)')}${I('rfc', 'RFC')}${I('curp', 'CURP')}</div>
    <div class="f">${I('domicilio', 'Domicilio')}${I('emergencia', 'En caso de emergencia avisar a', 'placeholder="Nombre y teléfono"')}</div>${I('notas', 'Notas')}
    ${id ? `<label class="row" style="font-weight:600"><input type="checkbox" id="em_activo" ${e.activo ? 'checked' : ''}> Trabaja actualmente (quítelo para darlo de baja; su historial se conserva)</label>` : ''}`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="empOk(${id || 0})">Guardar</button>`, true);
}
async function empOk(id) {
  const b = Object.fromEntries(['nombre', 'puesto', 'telefono', 'ingreso', 'sueldo', 'periodo_pago', 'nss', 'rfc', 'curp', 'domicilio', 'emergencia', 'notas'].map((k) => [k, val('em_' + k)]));
  if (id) b.activo = $('#em_activo').checked;
  await hacer(() => (id ? PUT('/api/empleados/' + id, b) : POST('/api/empleados', b)), 'Empleado guardado'); cerrar(); gTab = 'emp'; vGastos();
}
async function verEmpleado(id) {
  const e = await GET('/api/empleados/' + id); verEmpleado.e = e;
  modal(`${esc(e.nombre)}${e.activo ? '' : ' · BAJA'}`, `<div class="cols" style="gap:12px"><div class="kv"><span>Puesto</span><b>${esc(e.puesto || '—')}</b><span>Teléfono</span><span>${esc(e.telefono || '—')}</span><span>Ingreso</span><span>${e.ingreso ? fd(e.ingreso) : '—'}</span>
      <span>Sueldo</span><b>${e.sueldo ? money(e.sueldo) + ' ' + (PERIODO_PAGO[e.periodo_pago] || '').toLowerCase() : '—'}</b><span>IMSS</span><span>${esc(e.nss || '—')}</span><span>RFC</span><span>${esc(e.rfc || '—')}</span><span>CURP</span><span>${esc(e.curp || '—')}</span>
      <span>Domicilio</span><span>${esc(e.domicilio || '—')}</span><span>Emergencia</span><span>${esc(e.emergencia || '—')}</span>${e.notas ? `<span>Notas</span><span>${esc(e.notas)}</span>` : ''}</div>
    <div><div class="lbl">Total pagado (histórico)</div><div class="big" style="font-size:24px;font-weight:700">${money(e.total)}</div><div class="kv" style="margin-top:6px">${Object.entries(e.porTipo).map(([k, v]) => `<span>${esc(k)}</span><b>${money(v)}</b>`).join('')}</div></div></div>
    <div class="lbl" style="margin-top:10px">Historial de pagos</div><div class="tw" style="max-height:300px"><table><thead><tr><th>Fecha</th><th>Folio</th><th>Tipo</th><th>Periodo</th><th>Método</th><th class="n">Monto</th></tr></thead><tbody>
    ${e.pagos.map((g) => `<tr class="click" onclick="verGasto(${g.id})"><td>${fdt(g.fecha)}</td><td class="mono">${esc(g.folio)}</td><td>${esc(g.categoria || '')}</td><td>${esc(g.periodo || '')}</td><td>${MET[g.metodo] || ''}</td><td class="n">${money(g.monto)}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">Sin pagos.</td></tr>'}</tbody></table></div>`,
  `<button class="btn" onclick="empModal(${id})">Editar datos</button><button class="btn" onclick="imprimirFichaEmp()">Imprimir ficha</button><button class="btn pri" onclick="gastoModal({empleado_id:${id}})">Registrar pago</button>`, true);
}
function imprimirFichaEmp() {
  const e = verEmpleado.e;
  imprimirDoc(`<div class="rep"><div class="rep-enc"><b>${esc(CFG.hotel_nombre)}</b><span>Ficha de empleado</span></div>
    <h3>${esc(e.nombre)}</h3><table><tbody>${[['Puesto', e.puesto], ['Teléfono', e.telefono], ['Fecha de ingreso', e.ingreso ? fd(e.ingreso) : ''], ['Sueldo', e.sueldo ? money(e.sueldo) + ' ' + (PERIODO_PAGO[e.periodo_pago] || '').toLowerCase() : ''], ['Seguro Social', e.nss], ['RFC', e.rfc], ['CURP', e.curp], ['Domicilio', e.domicilio], ['Emergencia', e.emergencia], ['Notas', e.notas]].map(([k, v]) => `<tr><td style="width:30%"><b>${k}</b></td><td>${esc(v || '')}</td></tr>`).join('')}</tbody></table>
    <h3>Pagos · total ${money(e.total)}</h3><table><thead><tr><th>Fecha</th><th>Tipo</th><th>Periodo</th><th class="n">Monto</th></tr></thead><tbody>${e.pagos.map((g) => `<tr><td>${fdt(g.fecha)}</td><td>${esc(g.categoria || '')}</td><td>${esc(g.periodo || '')}</td><td class="n">${money(g.monto)}</td></tr>`).join('')}</tbody></table>
    <div class="rep-pie">Impreso ${new Date().toLocaleString('es-MX')}</div></div>`, 'carta', 'Ficha de ' + e.nombre);
}

// ---------- Proveedores ----------
function provModal(id) {
  const x = id ? PROVS.find((p) => p.id === id) || verProveedor.x : { nombre: '', contacto: '', telefono: '', correo: '', rfc: '', surte: '', banco: '', cuenta: '', notas: '', activo: 1 };
  const I = (k, n, extra = '') => `<label class="l">${n}<input id="pv_${k}" value="${esc(x[k] ?? '')}" ${extra}></label>`;
  modal(id ? 'Editar proveedor' : 'Nuevo proveedor', `<div class="f">${I('nombre', 'Nombre o razón social')}${I('surte', 'Qué surte / servicio', 'placeholder="Refrescos, blancos, plomería, contabilidad…"')}${I('contacto', 'Persona de contacto')}${I('telefono', 'Teléfono', 'inputmode="tel"')}
    ${I('correo', 'Correo')}${I('rfc', 'RFC (para facturas)')}${I('banco', 'Banco')}${I('cuenta', 'Cuenta o CLABE para transferir')}</div>${I('notas', 'Notas')}
    ${id ? `<label class="row" style="font-weight:600"><input type="checkbox" id="pv_activo" ${x.activo ? 'checked' : ''}> Proveedor activo</label>` : ''}`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="provOk(${id || 0})">Guardar</button>`, true);
}
async function provOk(id) {
  const b = Object.fromEntries(['nombre', 'surte', 'contacto', 'telefono', 'correo', 'rfc', 'banco', 'cuenta', 'notas'].map((k) => [k, val('pv_' + k)]));
  if (id) b.activo = $('#pv_activo').checked;
  await hacer(() => (id ? PUT('/api/proveedores/' + id, b) : POST('/api/proveedores', b)), 'Proveedor guardado'); cerrar(); gTab = 'prov'; vGastos();
}
async function verProveedor(id) {
  const x = await GET('/api/proveedores/' + id); verProveedor.x = x;
  modal(esc(x.nombre), `<div class="cols" style="gap:12px"><div class="kv"><span>Surte</span><b>${esc(x.surte || '—')}</b><span>Contacto</span><span>${esc(x.contacto || '—')}</span><span>Teléfono</span><span>${esc(x.telefono || '—')}</span><span>Correo</span><span>${esc(x.correo || '—')}</span>
      <span>RFC</span><span>${esc(x.rfc || '—')}</span><span>Banco</span><span>${esc(x.banco || '—')}</span><span>Cuenta</span><span>${esc(x.cuenta || '—')}</span>${x.notas ? `<span>Notas</span><span>${esc(x.notas)}</span>` : ''}</div>
    <div><div class="lbl">Total pagado (histórico)</div><div style="font-size:24px;font-weight:700">${money(x.total)}</div><div class="kv" style="margin-top:6px">${Object.entries(x.porTipo).map(([k, v]) => `<span>${esc(k)}</span><b>${money(v)}</b>`).join('')}</div></div></div>
    <div class="lbl" style="margin-top:10px">Historial de pagos</div><div class="tw" style="max-height:300px"><table><thead><tr><th>Fecha</th><th>Folio</th><th>Concepto</th><th>Factura</th><th>Método</th><th class="n">Monto</th></tr></thead><tbody>
    ${x.pagos.map((g) => `<tr class="click" onclick="verGasto(${g.id})"><td>${fdt(g.fecha)}</td><td class="mono">${esc(g.folio)}</td><td>${esc(g.concepto)}</td><td>${esc(g.factura || '')}</td><td>${MET[g.metodo] || ''}</td><td class="n">${money(g.monto)}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">Sin pagos.</td></tr>'}</tbody></table></div>`,
  `<button class="btn" onclick="provModal(${id})">Editar datos</button><button class="btn pri" onclick="gastoModal({proveedor_id:${id}})">Registrar pago</button>`, true);
}

// ---------- Nuevo gasto: pide los datos según la clasificación ----------
async function gastoModal(pre = {}) {
  if (!TAB) TAB = await GET('/api/tablero');
  const [emps, provs] = await Promise.all([GET('/api/empleados/lista').catch(() => []), GET('/api/proveedores/lista').catch(() => [])]);
  gastoModal.emps = emps; gastoModal.provs = provs;
  const C = clasif(), catNom = C.find((g) => tipoGrupo(g.grupo) === 'empleado')?.conceptos[0], catProv = C.find((g) => /proveedor/i.test(g.grupo))?.conceptos[0];
  const cat0 = pre.categoria || (pre.empleado_id ? catNom : pre.proveedor_id ? catProv : (gGrupo ? C.find((g) => g.grupo === gGrupo)?.conceptos[0] : '')) || '';
  modal('Nuevo gasto', `<div class="f"><label class="l">Clasificación del gasto${selCategoria('xCa', cat0)}</label><label class="l" style="grid-column:span 2">Concepto<input id="xCo" placeholder="Se llena solo; puede cambiarlo"></label></div>
    <div id="xSec" class="xsec"></div>
    <div class="f"><label class="l">Monto<input id="xMo" type="number" min="0" step="0.01"></label>
    <label class="l">Método de pago${selPago('xFp', null, 'sindolar')}</label><label class="l">Habitación (opcional)<select id="xHa"><option value="">—</option>${sortH(TAB.habitaciones).map((h) => `<option value="${h.id}">${esc(h.numero)}</option>`).join('')}</select></label>
    <label class="l">Entrega el dinero<input id="xEn" value="${esc(YO.nombre)}"></label><label class="l">Recibe el dinero<input id="xRe" placeholder="Empleado, proveedor, contador…"></label></div>
    <label class="l">Nota<input id="xNo"></label>
    <div class="cols" style="gap:12px">${padHTML('fEnt', 'Firma de quien entrega')}${padHTML('fRec', 'Firma de quien recibe')}</div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="gastoOk()">Guardar e imprimir</button>`, true);
  padIniciar('fEnt'); padIniciar('fRec');
  $('#xCa').addEventListener('change', () => gastoSec());
  gastoSec(pre);
}
function gastoSec(pre = {}) {
  const g = grupoSel('xCa'), cat = val('xCa'), tipo = tipoGrupo(g), el = $('#xSec'), E = gastoModal.emps, P = gastoModal.provs;
  const antes = { e: val('xEm'), p: val('xPv'), per: val('xPer'), fac: val('xFac') };
  if (tipo === 'empleado') el.innerHTML = `<div class="f"><label class="l">Empleado<select id="xEm" onchange="gastoAuto()"><option value="">— Elija —</option>${E.map((e) => `<option value="${e.id}">${esc(e.nombre)}${e.puesto ? ' · ' + esc(e.puesto) : ''}</option>`).join('')}</select>${E.length ? '' : '<small class="sub">Aún no hay empleados: agréguelos en Gastos → Empleados.</small>'}</label>
    <label class="l">Periodo que se paga<input id="xPer" placeholder="Ej. Semana del 6 al 12 de octubre"></label></div>`;
  else if (tipo === 'impuesto') el.innerHTML = `<div class="f"><label class="l">Periodo que se paga<input id="xPer" value="${esc(mesActual())}"></label><label class="l">Folio o línea de captura<input id="xFac" placeholder="Del comprobante de pago"></label></div>`;
  else if (tipo === 'proveedor') el.innerHTML = `<div class="f"><label class="l">Proveedor${P.length ? '' : ' (agréguelos en Gastos → Proveedores)'}<select id="xPv" onchange="gastoAuto()"><option value="">— Sin proveedor —</option>${P.map((x) => `<option value="${x.id}">${esc(x.nombre)}${x.surte ? ' · ' + esc(x.surte) : ''}</option>`).join('')}</select></label>
    <label class="l">Número de factura o nota<input id="xFac"></label>${/honorario|contador|abogado/i.test(g + cat) ? `<label class="l">Periodo<input id="xPer" value="${esc(mesActual())}"></label>` : ''}</div>`;
  else el.innerHTML = '';
  el.hidden = !el.innerHTML;
  // Al pagar a un empleado o un impuesto no hace falta la habitación (queda opcional para compras y mantenimiento)
  const hab = $('#xHa')?.closest('label'); if (hab) { hab.hidden = tipo === 'empleado' || tipo === 'impuesto'; if (hab.hidden) $('#xHa').value = ''; }
  const set = (id, v) => { const x = document.getElementById(id); if (x && v) x.value = v; };
  set('xEm', pre.empleado_id || antes.e); set('xPv', pre.proveedor_id || antes.p); set('xPer', antes.per); set('xFac', antes.fac);
  gastoAuto();
}
// Llena concepto, recibe y (en nómina) el sueldo
function gastoAuto() {
  const cat = val('xCa'), e = gastoModal.emps.find((x) => String(x.id) === val('xEm')), p = gastoModal.provs.find((x) => String(x.id) === val('xPv')), per = val('xPer');
  const quien = e?.nombre || p?.nombre || '';
  const co = $('#xCo'); if (!co.dataset.t) co.value = [cat, quien, per].filter(Boolean).join(' · ');
  co.oninput = () => (co.dataset.t = 1);
  if (quien) $('#xRe').value = quien;
  if (e && /n[oó]mina|sueldo/i.test(cat) && e.sueldo && !num('xMo')) $('#xMo').value = e.sueldo;
}
async function gastoOk() {
  const r = await hacer(() => POST('/api/gastos', { concepto: val('xCo'), categoria: val('xCa'), grupo: grupoSel('xCa'), monto: val('xMo'), metodo: val('xFp'), habitacion_id: val('xHa'), entrega: val('xEn'), recibe: val('xRe'), nota: val('xNo'),
    empleado_id: val('xEm'), proveedor_id: val('xPv'), factura: val('xFac'), periodo: val('xPer'), firma_entrega: padValor('fEnt'), firma_recibe: padValor('fRec'), autoriza: $('#gaAu') ? { usuario: val('gaAu'), password: $('#gaAp').value } : undefined }), 'Gasto guardado');
  if (vista === 'gastos') vGastos(); imprimirGasto(r.id);
}

// ---------- Pagar nómina a todos + lista de raya ----------
async function nominaModal() {
  const E = (await GET('/api/empleados')).filter((e) => e.activo);
  if (!E.length) return toast('Primero agregue a sus empleados', true);
  nominaModal.E = E;
  const hoy = new Date(), ini = new Date(hoy); ini.setDate(hoy.getDate() - 6);
  const per = `Semana del ${ini.toLocaleDateString('es-MX', { day: 'numeric', month: 'short' })} al ${hoy.toLocaleDateString('es-MX', { day: 'numeric', month: 'short', year: 'numeric' })}`;
  const n = (k, id, v = '') => `<input type="number" min="0" step="0.01" id="nm_${k}_${id}" value="${v}" oninput="nominaCalc()" style="width:92px">`;
  modal('Pagar nómina', `<div class="f"><label class="l">Periodo que se paga<input id="nmPer" value="${esc(per)}"></label><label class="l">Método de pago${selPago('nmMe', null, 'sindolar')}</label></div>
    <label class="row" style="font-weight:600"><input type="checkbox" id="nmFu"> Se pagó por fuera (no sale del dinero de la caja del turno)</label>
    <div class="tw nomgrid"><table><thead><tr><th><input type="checkbox" checked onchange="document.querySelectorAll('.nmchk').forEach((c)=>c.checked=this.checked);nominaCalc()"></th><th>Empleado</th><th class="n">Sueldo</th><th class="n">Bono puntualidad</th><th class="n">Otros bonos</th><th class="n">Días festivos</th><th class="n">Tiempo extra</th><th class="n">Descuento</th><th class="n">Total</th></tr></thead><tbody>
    ${E.map((e) => `<tr><td><input type="checkbox" class="nmchk" data-id="${e.id}" checked onchange="nominaCalc()"></td><td><b>${esc(e.nombre)}</b><div class="sub">${esc(e.puesto || '')} · ${PERIODO_PAGO[e.periodo_pago] || ''}</div></td>
      <td class="n">${n('su', e.id, e.sueldo || '')}</td><td class="n">${n('pu', e.id)}</td><td class="n">${n('bo', e.id)}</td><td class="n">${n('fe', e.id)}</td><td class="n">${n('ex', e.id)}</td><td class="n">${n('de', e.id)}<div class="sub" id="nm_as_${e.id}"></div></td><td class="n"><b id="nm_t_${e.id}"></b></td></tr>`).join('')}</tbody></table></div>
    <div class="calc"><span>Empleados</span><b id="nmN"></b><span>Total de la nómina</span><b class="big" id="nmT"></b></div>
    <div class="sub">Se registra un gasto por cada concepto y empleado, y se imprime la lista de raya para que firmen. El descuento se resta del sueldo.</div>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="nominaOk()">Registrar nómina e imprimir lista de raya</button>`, true);
  $('#modal .mbox').classList.add('extra'); nominaCalc();
}
function nominaLineas() {
  return [...document.querySelectorAll('.nmchk')].filter((c) => c.checked).map((c) => {
    const id = c.dataset.id, g = (k) => num(`nm_${k}_${id}`), su = Math.max(0, g('su') - g('de'));
    const ds = $(`#nm_de_${id}`)?.dataset || {};
    return { empleado_id: Number(id), sueldo: su, puntualidad: g('pu'), bono: g('bo'), festivos: g('fe'), extra: g('ex'), descuento: g('de'), bruto: g('su'), total: su + g('pu') + g('bo') + g('fe') + g('ex'),
      retardos: Number(ds.ret) || 0, faltas: Number(ds.fal) || 0, desc_retardos: Number(ds.dr) || 0, desc_faltas: Number(ds.df) || 0 };
  });
}
function nominaCalc() {
  for (const e of nominaModal.E) { const el = $('#nm_t_' + e.id); if (el) el.textContent = ''; }
  const L = nominaLineas(); for (const l of L) $('#nm_t_' + l.empleado_id).textContent = money(l.total);
  $('#nmN').textContent = L.length; $('#nmT').textContent = money(L.reduce((s, l) => s + l.total, 0));
}
async function nominaOk() {
  const L = nominaLineas(), per = val('nmPer');
  const r = await hacer(() => POST('/api/nomina', { periodo: per, metodo: val('nmMe'), fuera_de_caja: $('#nmFu').checked, lineas: L }), 'Nómina registrada');
  toast(`Nómina registrada: ${r.gastos} pago(s)`); pintarTurno();
  listaRaya(L, per); if (vista === 'gastos') { gTab = 'emp'; vGastos(); }
}
function listaRaya(L, per) {
  const E = Object.fromEntries(nominaModal.E.map((e) => [e.id, e])), T = (k) => L.reduce((s, l) => s + l[k], 0);
  imprimirDoc(`<div class="rep"><div class="rep-enc"><b>${esc(CFG.hotel_nombre)}</b><span>LISTA DE RAYA</span><span>${esc(per)}</span></div>
    <table class="raya"><thead><tr><th>Empleado</th><th class="n">Sueldo</th><th class="n">Bonos</th><th class="n">Festivos / extra</th><th class="n">Descuento</th><th class="n">Total</th><th style="width:28%">Firma de recibido</th></tr></thead><tbody>
    ${L.map((l) => `<tr><td><b>${esc(E[l.empleado_id]?.nombre || '')}</b><div style="font-size:9px">${esc(E[l.empleado_id]?.puesto || '')}</div></td><td class="n">${money(l.bruto)}</td><td class="n">${money(l.puntualidad + l.bono)}</td><td class="n">${money(l.festivos + l.extra)}</td><td class="n">${l.descuento ? '-' + money(l.descuento) : ''}</td><td class="n"><b>${money(l.total)}</b></td><td class="firma"></td></tr>`).join('')}
    <tr class="t"><td>TOTAL (${L.length})</td><td class="n">${money(T('bruto'))}</td><td class="n">${money(T('puntualidad') + T('bono'))}</td><td class="n">${money(T('festivos') + T('extra'))}</td><td class="n">${T('descuento') ? '-' + money(T('descuento')) : ''}</td><td class="n">${money(T('total'))}</td><td></td></tr></tbody></table>
    <div class="rep-firmas"><div><span></span>Elaboró · ${esc(YO.nombre)}</div><div><span></span>Autorizó</div></div>
    <div class="rep-pie">Impreso ${new Date().toLocaleString('es-MX')}</div></div>`, 'carta', 'Lista de raya');
}

// ---------- Reportes: pagos por empleado y proveedor ----------
{
  const _vRep = vRep;
  vRep = async function () {
    await _vRep();
    const d = vRep.d; if (!d || !d.gastos) return;
    const pe = d.gastos.porEmpleado || [], pp = d.gastos.porProveedor || [];
    if (!pe.length && !pp.length) return;
    const card = [...document.querySelectorAll('#main .card')].find((c) => c.querySelector('h2')?.textContent.startsWith('Gastos por clasificación'));
    card?.closest('.cols')?.insertAdjacentHTML('afterend', `<div class="cols"><div class="card"><h2>Pagos por empleado</h2>${pe.length ? `<div class="kv">${pe.map((x) => `<span>${esc(x.nombre)} (${x.n})</span><b>${money(x.t)}</b>`).join('')}</div>` : '<div class="empty">Sin pagos a empleados.</div>'}</div>
      <div class="card"><h2>Pagos por proveedor</h2>${pp.length ? `<div class="kv">${pp.map((x) => `<span>${esc(x.nombre)} (${x.n})</span><b>${money(x.t)}</b>`).join('')}</div>` : '<div class="empty">Sin pagos a proveedores.</div>'}</div></div>`);
  };
}
