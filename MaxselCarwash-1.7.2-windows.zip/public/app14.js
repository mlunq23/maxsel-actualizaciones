// Maxsel Carwash 1.2 — Pantalla del cliente (segundo monitor), datos de Maxsel en el ticket y monitoreo en la nube
'use strict';

// ======================================================================
// Pantalla del cliente: la caja manda lo que se cobra y la pantalla (/pantalla) lo muestra al instante
// ======================================================================
let PANT_HOLD = 0, PANT_T = null, PANT_ULT = '';
function pantEnviar(d, inmediato) {
  if (d.estado === 'espera' && Date.now() < PANT_HOLD) return;   // deja ver el cambio unos segundos
  const s = JSON.stringify(d);
  clearTimeout(PANT_T);
  if (s === PANT_ULT) return;
  const ir = () => { PANT_ULT = s; fetch('/api/pantalla', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: s, credentials: 'same-origin' }).catch(() => {}); };
  if (inmediato) ir(); else PANT_T = setTimeout(ir, 160);
}
const pantItems = (items) => items.map((l) => {
  const p = prodDe(l.producto_id);
  return { paquete: p?.paquete || null, nombre: l.nombre, incluye: p?.incluye || '', cantidad: l.cantidad, importe: +(l.cantidad * l.precio).toFixed(2), color: esPaq(p) ? colorPaq(p) : null };
});
function pantVenta() {
  const tk = TICKETS[TK];
  if (!tk || !tk.items.length) return pantEnviar({ estado: 'espera' });
  pantEnviar({ estado: 'venta', items: pantItems(tk.items), total: +totalT(tk).toFixed(2), placas: tk.placas || '', vehiculo: tk.vehiculo || '' });
}
{
  const _pt = pintarTienda;
  pintarTienda = function (...a) { const r = _pt(...a); pantVenta(); const pl = $('#cwPl'); if (pl) pl.addEventListener('change', pantVenta); return r; };
  const _vc = vcCalc;
  vcCalc = function () {
    _vc();
    if (!VC || vista !== 'tienda') return;
    const tk = TICKETS[TK], m = VC.metodo, r = vcRecibido();
    const escrito = m === 'efectivo' || m === 'dolares' ? !!$('#vcPa')?.value : m === 'mixto' ? r.total > 0 : true;
    pantEnviar({ estado: 'cobro', items: pantItems(tk.items), total: +VC.total.toFixed(2), placas: tk.placas || '', vehiculo: tk.vehiculo || '', metodo: m, tc: VC.tc,
      recibido: escrito ? +r.total.toFixed(2) : 0, usd: escrito ? +(r.usd || 0) : 0 });
  };
  const _vx = vcCancelar;
  vcCancelar = function () { _vx(); if (vista === 'tienda') { PANT_ULT = ''; pantVenta(); } };
  const _cob = cobrar;
  cobrar = async function () {
    const antes = ULTIMA;
    await _cob();
    if (ULTIMA && ULTIMA !== antes) {
      const v = ULTIMA.v; PANT_HOLD = Date.now() + 12000;
      pantEnviar({ estado: 'pagado', folio: v.folio, total: v.total, recibido: v.recibido, cambio: v.cambio, usd: Number(v.pago?.usd) || 0, tc: Number(v.pago?.tc) || 0 }, true);
    }
  };
}

// ======================================================================
// Configuración → Paquetes, cámara y pantalla
// ======================================================================
{
  const _cc = cCarwash;
  cCarwash = function () {
    _cc();
    const stack = $('#cfgc .stack'); if (!stack) return;
    stack.lastElementChild.insertAdjacentHTML('beforebegin', `<div class="card"><h2>Pantalla del cliente (segundo monitor)</h2>
      <p class="sub" style="margin-top:0">El cliente ve el paquete que está pagando, lo que incluye, los productos extra, el total, con cuánto paga, el cambio y, si paga en dólares, el total en dólares y su equivalencia en pesos.</p>
      <div class="row" style="gap:10px;flex-wrap:wrap"><button class="btn pri" onclick="window.open('/pantalla','pantalla_cliente','width=1280,height=760')">Abrir la pantalla del cliente</button>
        <span class="sub">Arrástrela al segundo monitor y toque "Pantalla completa". También se abre con el icono <b>"Pantalla del cliente Maxsel Carwash"</b> del escritorio (se abre sola en el segundo monitor).</span></div>
      <div class="row" style="gap:18px;align-items:flex-start;flex-wrap:wrap;margin-top:14px">
        <div class="cw-logoprev" id="plPrev">${CFG.cw_logo_pantalla ? `<img src="${CFG.cw_logo_pantalla}" alt="Logo">` : '<span class="sub">Sin logo del negocio</span>'}</div>
        <div class="stack" style="gap:8px;flex:1;min-width:240px"><label class="btn" style="cursor:pointer;justify-content:center">Elegir el logo del negocio (PNG transparente o JPG)<input type="file" accept="image/*" hidden onchange="pantLogo(this.files[0])"></label>
          ${CFG.cw_logo_pantalla ? '<button class="btn bad" onclick="confirmar(this,pantLogoQuitar)">Quitar el logo</button>' : ''}
          <span class="sub">Se ve a color arriba de la pantalla. El logo de Maxsel sale abajo, chico. Funciona mejor un PNG con fondo transparente.</span></div></div>
      <div class="f" style="margin-top:10px"><label class="l">Mensaje de bienvenida<input id="pBv" value="${esc(CFG.cw_pantalla_bienvenida || '')}" maxlength="80"></label>
        <label class="l">Mensaje al terminar de cobrar<input id="pGr" value="${esc(CFG.cw_pantalla_gracias || '')}" maxlength="120"></label></div>
      <label class="row" style="font-weight:600;margin-top:8px"><input type="checkbox" id="pMn" ${CFG.cw_pantalla_menu !== '0' ? 'checked' : ''}> Mientras no hay venta, mostrar los paquetes con sus precios (menú)</label>
      <div style="margin-top:10px"><button class="btn pri" onclick="pantOk()">Guardar pantalla</button></div></div>
    `);
  };
}
async function pantOk() {
  await hacer(() => PUT('/api/config', { cw_pantalla_bienvenida: val('pBv') || '¡Bienvenido!', cw_pantalla_gracias: val('pGr'), cw_pantalla_menu: $('#pMn').checked ? '1' : '0' }), 'Pantalla guardada');
  CFG = await GET('/api/config');
}
async function maxselOk() { await hacer(() => PUT('/api/config', { maxsel_contacto: $('#mxC').value.trim() }), 'Guardado'); CFG = await GET('/api/config'); LOGO_MAXSEL_OPS = null; }
// El logo del negocio se guarda a color y con su transparencia (PNG), reducido para que la pantalla cargue rápido
async function pantLogo(f) {
  if (!f) return;
  try {
    const url = await new Promise((ok, mal) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = mal; r.readAsDataURL(f); });
    const img = await new Promise((ok, mal) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => mal(new Error('No se pudo leer la imagen')); i.src = url; });
    // Recorta los bordes vacíos (transparentes o blancos) para que el logo no se vea chico ni chueco
    const c0 = document.createElement('canvas'); c0.width = img.width; c0.height = img.height; const x0 = c0.getContext('2d'); x0.drawImage(img, 0, 0);
    const d = x0.getImageData(0, 0, img.width, img.height).data; let a = img.width, b = img.height, cMax = 0, dMax = 0;
    for (let y = 0; y < img.height; y++) for (let x = 0; x < img.width; x++) { const k = (y * img.width + x) * 4; const vacio = d[k + 3] < 16 || (d[k] > 245 && d[k + 1] > 245 && d[k + 2] > 245); if (!vacio) { if (x < a) a = x; if (y < b) b = y; if (x > cMax) cMax = x; if (y > dMax) dMax = y; } }
    if (cMax <= a || dMax <= b) { a = 0; b = 0; cMax = img.width - 1; dMax = img.height - 1; }
    const w0 = cMax - a + 1, h0 = dMax - b + 1, esc2 = Math.min(1, 700 / w0, 260 / h0), w = Math.round(w0 * esc2), h = Math.round(h0 * esc2);
    const c = document.createElement('canvas'); c.width = w; c.height = h; c.getContext('2d').drawImage(c0, a, b, w0, h0, 0, 0, w, h);
    let png = c.toDataURL('image/png');
    if (png.length > 390000) png = c.toDataURL('image/webp', 0.9);
    if (png.length > 390000) throw new Error('El logo es muy pesado. Use una imagen más sencilla.');
    await hacer(() => PUT('/api/config', { cw_logo_pantalla: png }), 'Logo guardado');
    CFG = await GET('/api/config'); cCarwash();
  } catch (e) { toast(e.message, true); }
}
async function pantLogoQuitar() { await hacer(() => PUT('/api/config', { cw_logo_pantalla: '' }), 'Logo quitado'); CFG = await GET('/api/config'); cCarwash(); }

// ======================================================================
// Configuración → Monitoreo en la nube (como el gimnasio): https://maxsel-pos.web.app/carwash
// ======================================================================
async function cNube() {
  const e = await GET('/api/nube/estado');
  const ok = e.activo && e.conectado;
  const lic = e.licencia || {};
  $('#cfgc').innerHTML = `<div class="stack"><div class="card"><h2>Monitoreo en la nube desde el celular</h2>
      <p class="sub" style="margin-top:0">El dueño ve desde cualquier celular o computadora con internet los carros lavados, la venta del día, los paquetes, las formas de pago y todos los reportes, en <b class="mono">${esc(e.pagina)}</b>. No se instala nada en el celular (se puede agregar a la pantalla de inicio como app).</p>
      ${e.activo ? `<div class="aviso ${ok ? '' : 'bad'}" style="margin-bottom:10px">${ok ? `${icoCW('ok')}Conectado a la nube${e.nombre ? ' como <b>' + esc(e.nombre) + '</b>' : ''} · cuenta ${esc(e.email)}` : `No se pudo conectar: ${esc(e.error || 'revisando…')}`}</div>
        <div class="kv"><span>Última subida de totales</span><b>${e.ultimaSubida ? fdt(e.ultimaSubida.replace('T', ' ').slice(0, 19)) : '—'}</b>
          <span>Botón "Actualizar" del dueño</span><b>${e.timbre ? 'Responde al instante' : 'Se revisa cada 10 minutos'}</b>
          <span>Reportes atendidos</span><b>${e.solicitudesAtendidas || 0}</b>
          ${lic.until ? `<span>Monitoreo vigente hasta</span><b>${esc(lic.until)}</b>` : ''}</div>
        <div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap"><button class="btn pri" onclick="nubeSubir()">Subir los totales ahora</button><button class="btn bad" onclick="confirmar(this,nubeDesconectar)">Desconectar</button></div>`
      : `<div class="f"><label class="l">Correo de la cuenta (se lo da Maxsel)<input id="nE" type="email" value="${esc(e.email || '')}" autocomplete="off"></label><label class="l">Contraseña<input id="nP" type="password" autocomplete="new-password"></label></div>
        <button class="btn pri" style="margin-top:10px" onclick="nubeConectar()">Conectar</button>`}</div>
    <div class="card"><h2>Cómo funciona</h2><ol class="pasos">
      <li>La computadora sube los totales del día <b>cada 4 horas</b> y al cerrar el día (11:57 pm).</li>
      <li>En el celular, el botón <b>"Actualizar ahora"</b> le avisa a esta computadora y en segundos llegan los totales del momento.</li>
      <li><b>"Actualizar reporte"</b> pide el reporte completo de hoy, la semana, el mes o de una fecha a otra (paquetes, horas pico, cajeros, cancelaciones, clientes, productos y utilidad), con Excel y PDF.</li>
      <li>Si esta computadora está apagada o sin internet, el celular muestra lo último que se subió y la hora.</li>
      <li>El autolavado trabaja igual aunque no haya internet.</li></ol></div></div>`;
}
async function nubeConectar() {
  const b = event?.target; if (b) { b.disabled = true; b.textContent = 'Conectando…'; }
  try { await hacer(() => POST('/api/nube/conectar', { email: val('nE'), password: $('#nP').value }), 'Conectado a la nube'); } catch { /* ya avisó */ }
  cNube();
}
async function nubeDesconectar() { await hacer(() => POST('/api/nube/desconectar'), 'Desconectado'); cNube(); }
async function nubeSubir() { await hacer(() => POST('/api/nube/subir'), 'Totales subidos'); cNube(); }

// ======================================================================
// Menú con íconos (una sola familia de íconos de línea)
// ======================================================================
const ICONO_VISTA = { tienda: 'car', caja: 'caja', inv: 'caja2', gastos: 'recibo', asis: 'reloj', rep: 'grafica', cfg: 'ajustes' };
pintarNav = function (badge = {}) {
  const lista = VISTAS.filter((v) => (!v[2] || puede(v[2])) && !(v[0] === 'contratos' && CFG.modulo_contratos === '0'));
  $('#nav').innerHTML = lista.map(([k, n]) => `<button class="${vista === k ? 'on' : ''}" onclick="ir('${k}')" ${vista === k ? 'aria-current="page"' : ''}>${icoCW(ICONO_VISTA[k] || 'ajustes', '')}<span>${n}</span>${badge[k] ? `<span class="cnt">${badge[k]}</span>` : ''}</button>`).join('');
};
