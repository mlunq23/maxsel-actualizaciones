// Maxsel Carwash 1.7 — igual que Maxsel Tech y Maxsel Abarrotes:
//  · "¿Olvidó su contraseña?" en la pantalla de entrada
//  · Reiniciar ventas: oculto (7 toques seguidos en la versión, al final de Configuración) y solo con la contraseña de Maxsel
//  · Monitoreo por internet solo con Tailscale Funnel, en pocos pasos
'use strict';

// ---------- Recuperar contraseña ----------
{
  const _pl = pantallaLogin;
  pantallaLogin = function () {
    _pl();
    const f = $('#flog'); if (!f || $('#lgOlv')) return;
    f.insertAdjacentHTML('beforeend', '<div style="text-align:center;margin-top:12px"><a href="#" id="lgOlv" style="font-size:14px">¿Olvidó su contraseña?</a></div>');
    $('#lgOlv').onclick = (e) => { e.preventDefault(); recuperarVer(); };
  };
}
function recuperarVer() {
  modal('Recuperar contraseña', `<div class="aviso" style="margin-top:0">Un <b>administrador</b> puede ponerle contraseña nueva a cualquier usuario. Si nadie recuerda la del administrador, llame a <b>Maxsel</b> (WhatsApp 664 337 5433) para que lo haga con su clave.</div>
    <label class="l">Usuario que olvidó su contraseña<input id="rcU" autocapitalize="off" autocomplete="off" value="${esc(val('lu'))}"></label>
    <label class="l">Contraseña de un administrador (o clave de Maxsel)<input id="rcA" type="password" autocomplete="off"></label>
    <label class="l">Contraseña nueva<input id="rcN1" type="password" autocomplete="new-password"></label>
    <label class="l">Repita la contraseña nueva<input id="rcN2" type="password" autocomplete="new-password"></label>
    <div id="rcErr"></div>`,
  '<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" id="rcOk" onclick="recuperarOk()">Cambiar contraseña</button>');
  if (val('rcU')) $('#rcA').focus();
  $('#rcN2').addEventListener('keydown', (e) => { if (e.key === 'Enter') recuperarOk(); });
}
async function recuperarOk() {
  const err = (m) => { $('#rcErr').innerHTML = `<div class="aviso bad">${esc(m)}</div>`; };
  if (!val('rcU')) return err('Escriba el usuario');
  if ($('#rcN1').value.length < 6) return err('La contraseña nueva debe tener al menos 6 caracteres');
  if ($('#rcN1').value !== $('#rcN2').value) return err('Las contraseñas nuevas no coinciden');
  const b = $('#rcOk'); b.disabled = true;
  try {
    const r = await POST('/api/recuperar-contrasena', { usuario: val('rcU'), autoriza: $('#rcA').value, nueva: $('#rcN1').value });
    cerrar(); pantallaLogin(); $('#lu').value = r.usuario; $('#lp').focus();
    toast('Listo. Entre con la contraseña nueva de ' + r.usuario);
  } catch (e) { b.disabled = false; err(e.message); $('#rcA').value = ''; }
}

// ---------- Versión al final de Configuración + reinicio oculto ----------
{
  const _vc = vCfg;
  let toques = [];
  vCfg = async function () {
    await _vc();
    const m = $('#main'); if (!m || $('#verPie')) return;
    m.insertAdjacentHTML('beforeend', `<div id="verPie" style="text-align:center;color:var(--mut,#8a8f98);font-size:12.5px;margin:30px 0 10px;user-select:none;cursor:default">Maxsel Carwash · versión ${esc(CFG._version || '')} · Maxsel Sistemas de Punto de Venta</div>`);
    $('#verPie').addEventListener('click', () => {
      const t = Date.now(); toques = toques.filter((x) => t - x < 4000); toques.push(t);
      if (toques.length >= 7) { toques = []; reinicioVer(); }
    });
  };
}
function reinicioVer() {
  modal('🔒 Reiniciar el sistema · solo Maxsel', `<div class="aviso bad" style="margin-top:0">Borra las <b>ventas, lavados, turnos y cortes de caja</b> (por ejemplo, las ventas de prueba de la instalación), gastos, depósitos, asistencia y comisiones. Los folios vuelven a empezar en 1.<br>
    <b>No se borran:</b> paquetes, precios, productos, lavadores, usuarios, configuración ni la licencia. Antes de borrar se guarda un respaldo.</div>
    <label class="row" style="gap:8px;margin:6px 0"><input type="checkbox" id="riS"> También los socios de membresía (mensual ilimitado)</label>
    <label class="row" style="gap:8px;margin:6px 0 12px"><input type="checkbox" id="riE"> También poner en cero las existencias de la tienda</label>
    <label class="l">Contraseña de Maxsel<input id="riP" type="password" autocomplete="off" placeholder="Solo la conoce Maxsel"></label>`,
  '<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn bad" id="riOk" onclick="reinicioOk(this)">Borrar y reiniciar</button>');
  $('#riP').focus();
  $('#riP').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); reinicioOk($('#riOk')); } });
}
function reinicioOk(b) {
  if (!$('#riP').value) return toast('Escriba la contraseña de Maxsel', true);
  confirmar(b, async () => {
    b.disabled = true; b.textContent = 'Borrando…';
    try {
      const r = await POST('/api/maxsel/reiniciar', { pass: $('#riP').value, socios: $('#riS').checked, existencias: $('#riE').checked });
      modal('Sistema reiniciado', `<p>Quedó en ceros: sin ventas, lavados ni cortes, y los folios empiezan en 1.</p><p class="sub">Lo de antes quedó respaldado en <span class="mono">${esc(r.respaldo || '')}</span> (Configuración → Respaldos).</p>`,
        '<button class="btn pri" onclick="location.reload()">Listo</button>');
    } catch (e) { b.disabled = false; b.textContent = 'Borrar y reiniciar'; $('#riP').value = ''; $('#riP').focus(); toast(e.message, true); }
  });
}

// ---------- Monitoreo por internet (Tailscale Funnel) ----------
async function funnelUI(msg) {
  const c = $('#cfgc'); if (!c) return;
  const ips = (CFG._ips || []).filter((i) => !i.tailscale), p = CFG._puerto || 3070, adm = YO?.rol === 'admin';
  c.innerHTML = `<div class="stack"><div class="card"><h2>Monitoreo por internet</h2><div class="sub">Revisando Tailscale…</div></div></div>`;
  let e; try { e = await GET('/api/funnel'); } catch (er) { e = { error: er.message }; }
  const paso = (n, ok, tit, cuerpo) => `<div style="display:flex;gap:14px;align-items:flex-start;padding:12px 0;border-top:1px solid var(--lin,#e5e7eb)">
      <div style="flex:none;width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;${ok ? 'background:#1a9150;color:#fff' : 'background:#fbe9dd;color:#cd6628'}">${ok ? '✓' : n}</div>
      <div style="flex:1;min-width:0"><b style="font-size:16px">${tit}</b><div style="margin-top:4px">${cuerpo}</div></div></div>`;
  const pol = e.poliza || { activa: true }, fv = (f) => f.split('-').reverse().join('/');
  const listo = e.activo && e.url && pol.activa;
  const cajaPol = pol.activa
    ? `<div class="aviso ok" style="margin:0 0 10px">🛡️ <b>Póliza de mantenimiento vigente</b>${pol.vence ? ` hasta el <b>${fv(pol.vence)}</b>${pol.dias != null && pol.dias <= 30 ? ` · quedan ${pol.dias} día(s): renuévela con Maxsel para no perder el acceso` : ''}` : ' (sin vencimiento)'}. Incluye el monitoreo por internet.</div>`
    : `<div class="aviso bad" style="margin:0 0 10px">🔒 <b>${pol.incluida ? 'Póliza vencida' : 'Monitoreo por internet no incluido'}</b><br>${esc(pol.motivo || '')}<br><span class="sub">Cuando Maxsel le mande su licencia nueva, péguela en Configuración → Respaldos y licencia → Renovar licencia.</span></div>`;
  c.innerHTML = `<div class="stack">
    ${msg ? `<div class="aviso ${msg.bad ? 'bad' : 'ok'}" style="margin:0">${msg.t}</div>` : ''}
    <div class="card"><h2 style="margin-top:0">Ver el autolavado desde el celular, en cualquier lugar</h2>${cajaPol}
      <p class="sub" style="margin-top:0">Con <b>Tailscale Funnel</b> el dueño abre una dirección segura (https) en el navegador del celular, <b>sin instalar nada en el teléfono</b> y sin abrir puertos en el módem. Desde internet <b>solo se puede ver</b> (ventas, cortes, reportes); cobrar o cambiar algo solo se hace en la computadora del negocio.</p>
      ${listo ? `<div class="aviso ok" style="margin:6px 0 10px"><b>Listo: el acceso por internet está encendido.</b> Abra esta dirección en el celular y entre con un usuario <b>Administrador</b>, <b>Gerente</b> o <b>Monitoreo</b>:</div>
        <div style="display:flex;gap:18px;align-items:center;flex-wrap:wrap">
          <div style="flex:none;border:1px solid var(--lin,#e5e7eb);border-radius:12px;padding:6px;background:#fff;line-height:0">${typeof qrSVG === 'function' ? qrSVG(e.url, 5, 2) : ''}</div>
          <div style="flex:1;min-width:240px"><div style="font-weight:700;margin-bottom:6px">Escanee el código con la cámara del celular</div>
            <div class="codigo" style="font-size:17px;letter-spacing:0;word-break:break-all">${esc(e.url)}</div></div></div>
        <div class="row" style="gap:8px;margin-top:10px;flex-wrap:wrap"><button class="btn pri" onclick="funnelCopiar('${esc(e.url)}')">Copiar dirección</button>
          <a class="btn" href="https://wa.me/?text=${encodeURIComponent('Monitoreo de ' + (CFG.hotel_nombre || 'el autolavado') + ': ' + e.url)}" target="_blank" rel="noopener">Mandar por WhatsApp</a>
          ${adm ? '<button class="btn bad" onclick="funnelCambiar(false,this)">Apagar acceso por internet</button>' : ''}</div>
        <p class="sub">En el celular: ábrala en Chrome o Safari y agréguela a la pantalla de inicio para usarla como app.</p>` : ''}
      ${e.error ? `<div class="aviso bad">${esc(e.error)}</div>` : `
      ${paso(1, e.instalado, 'Instalar Tailscale en esta computadora', e.instalado ? 'Ya está instalado.' : `Es gratis. Descárguelo, instálelo con “Siguiente” y regrese aquí.<div style="margin-top:8px"><a class="btn pri" href="https://tailscale.com/download/windows" target="_blank" rel="noopener">Descargar Tailscale</a> <button class="btn" onclick="funnelUI()">Ya lo instalé</button></div>`)}
      ${paso(2, e.conectado, 'Iniciar sesión en Tailscale', e.conectado ? `Conectado como <b class="mono">${esc(e.nombre)}</b>.` : (e.instalado ? `Use una cuenta de Google o Microsoft del negocio (la misma siempre).<div style="margin-top:8px">${adm ? '<button class="btn pri" onclick="funnelSesion(this)">Iniciar sesión</button> ' : ''}<button class="btn" onclick="funnelUI()">Ya inicié sesión</button></div>` : 'Primero haga el paso 1.'))}
      ${paso(3, e.activo && pol.activa, 'Encender el acceso por internet', !pol.activa ? 'Disponible con la póliza de mantenimiento vigente.' : e.activo ? 'Encendido.' : (e.conectado ? (adm ? `Un solo botón. La primera vez Tailscale le pide permitir “Funnel” en su cuenta: se abre una página, toque <b>Enable</b> y vuelva a tocar este botón.<div style="margin-top:8px"><button class="btn ok" onclick="funnelCambiar(true,this)">Encender acceso por internet</button></div>` : 'Pídale al administrador que lo encienda.') : 'Primero haga los pasos anteriores.'))}`}
    </div>
    <div class="card"><h2>En el WiFi del negocio</h2>${ips.map((i) => `<div class="codigo" style="font-size:18px">http://${esc(i.ip)}:${p}</div>`).join('') || '<div class="empty">Sin red local.</div>'}
      <p class="sub">Desde un celular o computadora conectados al mismo WiFi. Entre con un usuario de tipo <b>Monitoreo</b> (solo ver).</p></div></div>`;
}
async function funnelCambiar(activar, b) {
  if (b) { b.disabled = true; b.textContent = activar ? 'Encendiendo… (hasta 30 segundos)' : 'Apagando…'; }
  try {
    const r = await POST('/api/funnel', { activar });
    if (r.habilitar) {
      window.open(r.habilitar, '_blank');
      return funnelUI({ t: `Tailscale pide permitir <b>Funnel</b> en su cuenta (solo la primera vez). Se abrió la página: toque <b>Enable</b> y luego vuelva a tocar “Encender acceso por internet”.<div style="margin-top:6px"><a href="${esc(r.habilitar)}" target="_blank" rel="noopener">Abrir la página otra vez</a></div>` });
    }
    funnelUI({ t: activar ? 'Acceso por internet encendido.' : 'Acceso por internet apagado.' });
  } catch (e) { funnelUI({ t: esc(e.message), bad: true }); }
}
async function funnelSesion(b) {
  b.disabled = true; b.textContent = 'Abriendo…';
  try {
    const r = await POST('/api/funnel', { sesion: true });
    if (r.enlace) { window.open(r.enlace, '_blank'); return funnelUI({ t: `Se abrió la página de Tailscale. Inicie sesión y luego toque “Ya inicié sesión”.<div style="margin-top:6px"><a href="${esc(r.enlace)}" target="_blank" rel="noopener">Abrir la página otra vez</a></div>` }); }
    if (r.error) return funnelUI({ t: esc(r.error), bad: true });
    funnelUI();
  } catch (e) { funnelUI({ t: esc(e.message), bad: true }); }
}
function funnelCopiar(u) {
  const ok = () => toast('Dirección copiada');
  if (navigator.clipboard) navigator.clipboard.writeText(u).then(ok, () => prompt('Copie la dirección:', u)); else prompt('Copie la dirección:', u);
}
