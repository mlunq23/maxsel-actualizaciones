'use strict';
// Maxsel 2026: Gastos, Asistencia, Membresías y Lavadores son módulos aparte. Se encienden o apagan desde la licencia que entrega Maxsel.
const modOn = (k) => !(YO && YO.licencia && YO.licencia.modulos && YO.licencia.modulos[k] === false);
{
  const quitar = () => {
    const fuera = [];
    if (!modOn('gastos')) fuera.push('gastos');
    if (!modOn('asistencia')) fuera.push('asis');
    if (!modOn('membresias')) fuera.push('mem');
    if (!modOn('lavadores')) fuera.push('lav');
    for (let i = VISTAS.length - 1; i >= 0; i--) if (fuera.includes(VISTAS[i][0])) VISTAS.splice(i, 1);
  };
  const _pn = pintarNav;
  pintarNav = function (...a) { quitar(); return _pn.apply(this, a); };
  const _ir = ir;
  ir = function (v, ...a) {
    const k = { gastos: 'gastos', asis: 'asistencia', mem: 'membresias', lav: 'lavadores' }[v];
    if (k && !modOn(k)) { toast(`El módulo de ${{ gastos: 'Gastos', asistencia: 'Asistencia', membresias: 'Membresías', lavadores: 'Lavadores' }[k]} no está incluido en su licencia. Comuníquese con Maxsel.`, true); return; }
    return _ir.call(this, v, ...a);
  };
  if (typeof gastoModal === 'function') {
    const _g = gastoModal;
    gastoModal = function (...a) { if (!modOn('gastos')) return toast('El módulo de Gastos no está incluido en su licencia. Comuníquese con Maxsel.', true); return _g.apply(this, a); };
  }
  if (typeof avisosGastos === 'function') { const _a = avisosGastos; avisosGastos = function (...a) { return modOn('gastos') ? _a.apply(this, a) : []; }; }
  // Membresías apagadas: el punto de venta no busca socios por placas ni muestra el aviso de membresía
  if (typeof memBanner === 'function') {
    const o = { memBanner, memPorPlacas, memSync, cargarPlanes };
    cargarPlanes = async function (...a) { if (modOn('membresias')) return o.cargarPlanes.apply(this, a); MPLANES = []; return MPLANES; };
    memBanner = function (...a) { return modOn('membresias') ? o.memBanner.apply(this, a) : ''; };
    memPorPlacas = async function (...a) { if (modOn('membresias')) return o.memPorPlacas.apply(this, a); };
    memSync = function (...a) { if (modOn('membresias')) return o.memSync.apply(this, a); };
  }
}
