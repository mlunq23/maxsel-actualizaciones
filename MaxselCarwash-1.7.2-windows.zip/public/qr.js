// Código QR (hecho por Maxsel, sin librerías): qrSVG('https://…', 6) → <svg> para escanear con la cámara del celular.
// Modo de bytes (UTF-8), corrección de errores nivel M, versiones 1 a 10 (hasta ~210 letras).
'use strict';
const qrSVG = (() => {
  // [total de palabras, corrección por bloque, [bloques, datos], [bloques, datos]]
  const TAB = [null, [26, 10, [1, 16]], [44, 16, [1, 28]], [70, 26, [1, 44]], [100, 18, [2, 32]], [134, 24, [2, 43]], [172, 16, [4, 27]],
    [196, 18, [4, 31]], [242, 22, [2, 38], [2, 39]], [292, 22, [3, 36], [2, 37]], [346, 26, [4, 43], [1, 44]]];
  const ALIN = [null, [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]];
  const EXP = new Array(512), LOG = new Array(256);
  for (let i = 0, x = 1; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 256) x ^= 0x11d; }
  for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
  const mul = (a, b) => (a && b ? EXP[LOG[a] + LOG[b]] : 0);
  function rs(datos, n) {
    let g = [1];
    for (let i = 0; i < n; i++) { const h = new Array(g.length + 1).fill(0); for (let j = 0; j < g.length; j++) { h[j] ^= g[j]; h[j + 1] ^= mul(g[j], EXP[i]); } g = h; }
    const r = datos.concat(new Array(n).fill(0));
    for (let i = 0; i < datos.length; i++) { const c = r[i]; if (c) for (let j = 0; j < g.length; j++) r[i + j] ^= mul(g[j], c); }
    return r.slice(datos.length);
  }
  const formato = (m) => { const d = (0 << 3) | m; let r = d; for (let i = 0; i < 10; i++) r = (r << 1) ^ ((r >>> 9) * 0x537); return ((d << 10) | r) ^ 0x5412; }; // nivel M = 00
  const versionBits = (v) => { let r = v; for (let i = 0; i < 12; i++) r = (r << 1) ^ ((r >>> 11) * 0x1f25); return (v << 12) | r; };
  const MASK = [(r, c) => (r + c) % 2 === 0, (r) => r % 2 === 0, (r, c) => c % 3 === 0, (r, c) => (r + c) % 3 === 0,
    (r, c) => (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0, (r, c) => ((r * c) % 2) + ((r * c) % 3) === 0,
    (r, c) => (((r * c) % 2) + ((r * c) % 3)) % 2 === 0, (r, c) => (((r + c) % 2) + ((r * c) % 3)) % 2 === 0];

  function matriz(texto) {
    const bytes = Array.from(new TextEncoder().encode(texto));
    let ver = 1;
    for (; ver <= 10; ver++) { const t = TAB[ver], cap = t[2][0] * t[2][1] + (t[3] ? t[3][0] * t[3][1] : 0); if (4 + (ver < 10 ? 8 : 16) + bytes.length * 8 <= cap * 8) break; }
    if (ver > 10) throw new Error('Texto demasiado largo para el código QR');
    const t = TAB[ver], ndatos = t[2][0] * t[2][1] + (t[3] ? t[3][0] * t[3][1] : 0);
    // bits de datos
    const bits = []; const pon = (v, n) => { for (let i = n - 1; i >= 0; i--) bits.push((v >>> i) & 1); };
    pon(4, 4); pon(bytes.length, ver < 10 ? 8 : 16); for (const b of bytes) pon(b, 8);
    for (let i = 0; i < 4 && bits.length < ndatos * 8; i++) bits.push(0);
    while (bits.length % 8) bits.push(0);
    const cw = []; for (let i = 0; i < bits.length; i += 8) cw.push(parseInt(bits.slice(i, i + 8).join(''), 2));
    for (let p = 0; cw.length < ndatos; p++) cw.push(p % 2 ? 0x11 : 0xec);
    // bloques + corrección, intercalados
    const bloques = []; let k = 0;
    for (const g of [t[2], t[3]]) if (g) for (let b = 0; b < g[0]; b++) { const d = cw.slice(k, k + g[1]); k += g[1]; bloques.push({ d, e: rs(d, t[1]) }); }
    const fin = [], maxd = Math.max(...bloques.map((b) => b.d.length));
    for (let i = 0; i < maxd; i++) for (const b of bloques) if (i < b.d.length) fin.push(b.d[i]);
    for (let i = 0; i < t[1]; i++) for (const b of bloques) fin.push(b.e[i]);
    // matriz con patrones fijos
    const n = ver * 4 + 17, M = Array.from({ length: n }, () => new Array(n).fill(null)), fijo = Array.from({ length: n }, () => new Array(n).fill(false));
    const set = (r, c, v) => { if (r >= 0 && c >= 0 && r < n && c < n) { M[r][c] = v; fijo[r][c] = true; } };
    const buscador = (r0, c0) => { for (let r = -1; r <= 7; r++) for (let c = -1; c <= 7; c++) set(r0 + r, c0 + c, r >= 0 && r <= 6 && c >= 0 && c <= 6 && (r === 0 || r === 6 || c === 0 || c === 6 || (r >= 2 && r <= 4 && c >= 2 && c <= 4))); };
    buscador(0, 0); buscador(0, n - 7); buscador(n - 7, 0);
    for (let i = 8; i < n - 8; i++) { set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
    const A = ALIN[ver];
    const ult = A[A.length - 1];
    for (const r of A) for (const c of A) { if ((r === 6 && c === 6) || (r === 6 && c === ult) || (r === ult && c === 6)) continue; for (let y = -2; y <= 2; y++) for (let x = -2; x <= 2; x++) set(r + y, c + x, Math.max(Math.abs(y), Math.abs(x)) !== 1); }
    // reservar formato y versión
    for (let i = 0; i < 9; i++) if (i !== 6) { set(8, i, false); set(i, 8, false); }
    for (let i = 0; i < 8; i++) { set(8, n - 1 - i, false); set(n - 1 - i, 8, false); }
    set(n - 8, 8, true); // módulo oscuro
    if (ver >= 7) { const v = versionBits(ver); for (let i = 0; i < 18; i++) { const b = ((v >> i) & 1) === 1, a = Math.floor(i / 3), c = n - 11 + (i % 3); set(a, c, b); set(c, a, b); } }
    // datos en zigzag
    const dbits = []; for (const b of fin) for (let i = 7; i >= 0; i--) dbits.push((b >> i) & 1);
    let idx = 0, arriba = true;
    for (let c = n - 1; c > 0; c -= 2) {
      if (c === 6) c--;
      for (let i = 0; i < n; i++) { const r = arriba ? n - 1 - i : i; for (const cc of [c, c - 1]) if (!fijo[r][cc]) { M[r][cc] = idx < dbits.length ? dbits[idx] === 1 : false; idx++; } }
      arriba = !arriba;
    }
    // elegir la mejor máscara
    let mejor = null, mejorP = Infinity;
    for (let m = 0; m < 8; m++) {
      const X = M.map((f, r) => f.map((v, c) => (fijo[r][c] ? v : v !== MASK[m](r, c))));
      const f = formato(m), b = (i) => ((f >>> i) & 1) === 1;
      for (let i = 0; i <= 5; i++) X[i][8] = b(i);
      X[7][8] = b(6); X[8][8] = b(7); X[8][7] = b(8);
      for (let i = 9; i < 15; i++) X[8][14 - i] = b(i);
      for (let i = 0; i < 8; i++) X[8][n - 1 - i] = b(i);
      for (let i = 8; i < 15; i++) X[n - 15 + i][8] = b(i);
      const p = penal(X, n); if (p < mejorP) { mejorP = p; mejor = X; }
    }
    return mejor;
  }
  function penal(X, n) {
    let p = 0;
    for (let r = 0; r < n; r++) for (const lin of [(i) => X[r][i], (i) => X[i][r]]) {
      let cuenta = 1;
      for (let i = 1; i < n; i++) { if (lin(i) === lin(i - 1)) { cuenta++; if (i === n - 1 && cuenta >= 5) p += cuenta - 2; } else { if (cuenta >= 5) p += cuenta - 2; cuenta = 1; } }
      for (let i = 0; i + 10 < n; i++) {
        const s = Array.from({ length: 11 }, (_, k) => (lin(i + k) ? 1 : 0)).join('');
        if (s === '10111010000' || s === '00001011101') p += 40;
      }
    }
    for (let r = 0; r < n - 1; r++) for (let c = 0; c < n - 1; c++) { const v = X[r][c]; if (v === X[r][c + 1] && v === X[r + 1][c] && v === X[r + 1][c + 1]) p += 3; }
    let osc = 0; for (const f of X) for (const v of f) if (v) osc++;
    p += Math.floor(Math.abs(osc * 100 / (n * n) - 50) / 5) * 10;
    return p;
  }
  return function (texto, celda = 6, margen = 4) {
    const X = matriz(texto), n = X.length, t = (n + margen * 2) * celda;
    let d = '';
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (X[r][c]) d += `M${(c + margen) * celda},${(r + margen) * celda}h${celda}v${celda}h-${celda}z`;
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${t}" height="${t}" viewBox="0 0 ${t} ${t}" shape-rendering="crispEdges" role="img" aria-label="Código QR"><rect width="100%" height="100%" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
  };
})();
if (typeof module === 'object' && module.exports) module.exports = qrSVG;
