// Maxsel Carwash 1.5 — LAVADORES, TIEMPO DE LAVADO Y COMISIONES
// En la caja se elige "¿Quién lo lava?" (se ve quién está libre y hasta qué hora está ocupado cada uno).
// Se puede elegir a uno ocupado (si ya terminó) o liberarlo a mano. Cada carro le genera su comisión
// (por paquete o un monto fijo por carro, si se encienden) y se le paga desde la caja como gasto.
'use strict';
document.head.insertAdjacentHTML('beforeend', `<style>
.lav-bar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:8px 0;padding:8px 10px;border:1px solid var(--line);border-radius:12px;background:var(--panel)}
.lav-bar.falta{border-color:var(--ocup);box-shadow:0 0 0 3px var(--ocupBg)}
.lav-bar .lav-t{font-size:12px;font-weight:800;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-right:2px}
.lav-op{display:inline-flex;align-items:stretch;border-radius:10px;overflow:hidden;border:2px solid var(--line);background:#fff}
.lav-op.lib{border-color:color-mix(in srgb,var(--libre) 55%,#fff)}.lav-op.ocu{border-color:color-mix(in srgb,var(--limp) 60%,#fff)}
.lav-op.on{border-color:var(--acc,#cd6628);box-shadow:0 0 0 3px color-mix(in srgb,var(--acc,#cd6628) 25%,transparent)}
.lav-op>button{border:0;background:transparent;cursor:pointer;font:inherit;color:inherit}
.lav-ch{display:flex;flex-direction:column;align-items:flex-start;padding:6px 12px;min-height:48px;justify-content:center;text-align:left}
.lav-ch b{font-size:15px;line-height:1.1}.lav-ch small{font-size:12px;font-weight:700}
.lav-op.lib .lav-ch small{color:var(--libre)}.lav-op.ocu .lav-ch small{color:var(--limp)}
.lav-op.on .lav-ch{background:color-mix(in srgb,var(--acc,#cd6628) 12%,#fff)}
.lav-lib{padding:0 10px;font-size:12px!important;font-weight:700;border-left:1px solid var(--line)!important;color:var(--muted)!important;min-width:48px}
.lav-lib:hover{background:var(--libreBg)!important;color:var(--libre)!important}
.lav-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px}
.lav-card{border:1px solid var(--line);border-radius:14px;padding:14px;background:var(--panel);display:flex;flex-direction:column;gap:8px;border-top:6px solid var(--libre)}
.lav-card.ocu{border-top-color:var(--limp)}
.lav-card h3{margin:0;font-size:18px;display:flex;justify-content:space-between;align-items:center;gap:8px}
.lav-card .lav-hasta{font-size:24px;font-weight:800}
.lav-card .lav-num{display:flex;gap:14px;font-size:13px;color:var(--muted)}.lav-card .lav-num b{color:var(--ink,#111);font-size:15px}
.lav-rad{width:20px!important;height:20px!important;min-height:0!important;flex:none;margin:0;padding:0}
#lcMod .row{gap:8px;align-items:center;flex-wrap:wrap}
.lav-op{max-width:100%}
.prod.poco small{color:var(--ocup);font-weight:800}
@media (max-width:600px){.lav-ch{padding:6px 9px}.lav-ch b{font-size:14px}}
</style>`);
ICW.lavador = '<circle cx="9" cy="7" r="4"/><path d="M3 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2"/><path d="M19 3s-3 3.5-3 5.5a3 3 0 0 0 6 0C22 6.5 19 3 19 3z"/>';
ICONO_VISTA.lav = 'lavador';
VISTAS.splice(Math.max(1, VISTAS.findIndex((v) => v[0] === 'tienda') + 1), 0, ['lav', 'Lavadores', 'vender|comisiones|lavadores']);
let LAVS = [], LAVS_COM = false, lavTab = 'tablero', lavDesde = '', lavHasta = '', LAVDAT = null;
const hoyL = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const lavOn = () => CFG.cw_lavadores !== '0' && (typeof modOn !== 'function' || modOn('lavadores')); // 1.7.2: módulo de la licencia
const faltanMin = (f) => Math.max(0, Math.round((aF(f) - new Date()) / 60000));
async function cargarLavs() {
  try { const r = await GET('/api/lavadores/estado'); LAVS = r.lavadores || []; LAVS_COM = !!r.comisiones; } catch { /* sin red */ }
  return LAVS;
}

// ---------- En la caja: "¿Quién lo lava?" ----------
function barraLav() {
  if (!lavOn() || !LAVS.length) return '';
  const tk = TICKETS[TK]; if (tk.lavador && !LAVS.some((l) => l.id === tk.lavador)) tk.lavador = null;
  return `<div class="lav-bar" id="lavBar"><span class="lav-t">¿Quién lo lava?</span>${LAVS.map((l) => `<span class="lav-op ${l.libre ? 'lib' : 'ocu'} ${tk.lavador === l.id ? 'on' : ''}">
    <button class="lav-ch" onclick="lavElegir(${l.id})" aria-pressed="${tk.lavador === l.id}"><b>${esc(l.nombre)}</b><small>${l.libre ? 'Libre' : 'Ocupado hasta ' + hora12(l.lavando.hasta)}</small></button>
    ${l.libre ? '' : `<button class="lav-lib" onclick="lavLiberar(${l.id})" title="Ya terminó: dejarlo libre">Liberar</button>`}</span>`).join('')}</div>`;
}
function pintarBarraLav() {
  if (vista !== 'tienda') return;
  const html = barraLav(), ya = $('#lavBar');
  if (ya) { if (html) ya.outerHTML = html; else ya.remove(); return; }
  const ref = $('.cw-pantalla'); if (ref && html) ref.insertAdjacentHTML('afterend', html);
}
function lavElegir(id) {
  const tk = TICKETS[TK], l = LAVS.find((x) => x.id === id);
  tk.lavador = tk.lavador === id ? null : id;
  if (tk.lavador && l && !l.libre) toast(`${l.nombre} estaba ocupado: al cobrar se da por terminado su carro anterior`);
  pintarBarraLav();
}
async function lavLiberar(id) {
  await hacer(() => POST(`/api/lavadores/${id}/liberar`, {}), 'Lavador libre');
  await cargarLavs();
  if (vista === 'tienda') pintarBarraLav(); else if (vista === 'lav') vLav();
}
{
  const _pt = pintarTienda;
  pintarTienda = function (...a) {
    const r = _pt(...a);
    pintarBarraLav();
    // Aromatizantes, trapos y demás productos: avisa cuando ya quedan pocos
    document.querySelectorAll('.prods .prod').forEach((b) => {
      const id = Number((b.getAttribute('onclick') || '').match(/agregar\((\d+)\)/)?.[1]), p = id && prodDe(id);
      if (p && !p.servicio && p.existencia > 0 && p.existencia <= (p.minimo || 0)) { b.classList.add('poco'); const s = b.querySelector('small'); if (s) s.textContent = '¡Quedan ' + p.existencia + '!'; }
    });
    return r;
  };
  const _vt = vTienda;
  vTienda = async function (...a) {
    const r = await _vt(...a);
    if (lavOn()) cargarLavs().then(pintarBarraLav);
    return r;
  };
  // Cada 30 segundos se actualiza quién está libre
  setInterval(() => { if (vista === 'tienda' && lavOn() && document.visibilityState !== 'hidden') cargarLavs().then(pintarBarraLav); }, 30000);
  const _cb = cobrar;
  cobrar = async function (...a) {
    const tk = TICKETS[TK];
    if (carrito.length && lavOn() && CFG.cw_pedir_lavador === '1' && LAVS.length && paqsCarrito(carrito).length && !tk.lavador) {
      toast('Elija quién va a lavar el carro', true);
      const b = $('#lavBar'); if (b) { b.classList.add('falta'); b.scrollIntoView({ block: 'nearest' }); setTimeout(() => b.classList.remove('falta'), 2500); }
      return;
    }
    return _cb.apply(this, a);
  };
  // Al cobrar se manda el lavador elegido
  const _api = api;
  api = async function (metodo, url, body) {
    let lav = false;
    if (metodo === 'POST' && url === '/api/ventas' && body && TICKETS[TK]?.lavador) { body = { ...body, lavador_id: TICKETS[TK].lavador }; lav = true; }
    const r = await _api(metodo, url, body);
    if (lav || (metodo === 'POST' && url === '/api/ventas')) cargarLavs();
    return r;
  };
}

// ---------- Vista "Lavadores" ----------
{
  const _ir = ir;
  ir = async function (v) {
    if (v !== 'lav') return _ir(v);
    vista = v; clearInterval(timer); pintarNav(ir.badge);
    try { await vLav(); } catch (e) { if (e.message) $('#main').innerHTML = `<div class="aviso bad">${esc(e.message)}</div>`; }
    timer = setInterval(() => { if (vista === 'lav' && lavTab === 'tablero' && $('#modal').hidden) vLav().catch(() => {}); }, 20000);
    if (window.innerWidth < 760) window.scrollTo(0, 0);
  };
}
async function vLav() {
  if (!lavDesde) lavDesde = lavHasta = hoyL();
  const tabs = [['tablero', 'Quién está libre', 'vender|comisiones|lavadores'], ['com', 'Comisiones', 'comisiones|lavadores|reportes'], ['cfg', 'Lavadores, tiempos y comisiones', 'lavadores']].filter((t) => puede(t[2]));
  if (!tabs.some((t) => t[0] === lavTab)) lavTab = tabs[0][0];
  await cargarLavs();
  if (lavTab === 'com') LAVDAT = await GET(`/api/comisiones?desde=${lavDesde}&hasta=${lavHasta}`);
  $('#main').innerHTML = cab('Lavadores', 'Quién está libre, sus carros del día y sus comisiones', lavTab === 'com' ? `<label class="l">Desde<input type="date" value="${lavDesde}" onchange="lavDesde=this.value;vLav()"></label><label class="l">Hasta<input type="date" value="${lavHasta}" onchange="lavHasta=this.value;vLav()"></label><button class="btn" onclick="lavImprimirLista()">Imprimir lista</button>` : '')
    + `<div class="tabs" style="margin-bottom:14px">${tabs.map(([k, n]) => `<button class="${lavTab === k ? 'on' : ''}" onclick="lavTab='${k}';vLav()">${n}</button>`).join('')}</div><div id="lavc"></div>`;
  if (!lavOn()) $('#lavc').insertAdjacentHTML('beforebegin', '<div class="aviso" style="margin-bottom:12px">"¿Quién lo lava?" está apagado en la caja. Se enciende en la pestaña <b>Lavadores, tiempos y comisiones</b>.</div>');
  ({ tablero: lavTablero, com: lavComisiones, cfg: lavConfig })[lavTab]();
}
function lavTablero() {
  if (!LAVS.length) {
    $('#lavc').innerHTML = `<div class="empty">Todavía no hay lavadores. ${puede('lavadores') ? '<button class="btn pri sm" onclick="lavTab=\'cfg\';vLav()">Dar de alta a los lavadores</button>' : 'Pida al administrador que los dé de alta.'}</div>`;
    return;
  }
  const libres = LAVS.filter((l) => l.libre).length;
  $('#lavc').innerHTML = `<div class="sub" style="margin-bottom:10px"><b>${libres}</b> libre(s) de ${LAVS.length} · se actualiza solo cada 20 segundos</div><div class="lav-grid">${LAVS.map((l) => `<div class="lav-card ${l.libre ? '' : 'ocu'}">
    <h3>${esc(l.nombre)} <span class="pill ${l.libre ? 'p-ok' : 'p-warn'}">${l.libre ? 'Libre' : 'Lavando'}</span></h3>
    ${l.libre ? '<div class="sub">Listo para el siguiente carro</div>' : `<div><div class="sub">Termina aprox.</div><div class="lav-hasta">${hora12(l.lavando.hasta)} <small class="sub">(${faltanMin(l.lavando.hasta) ? 'faltan ' + faltanMin(l.lavando.hasta) + ' min' : 'ya casi'})</small></div>
      <div>${esc(l.lavando.descripcion || '')}${l.lavando.placas ? ` · <b class="mono">${esc(l.lavando.placas)}</b>` : ''}${l.lavando.vehiculo ? ' · ' + esc(l.lavando.vehiculo) : ''}</div><div class="sub">Folio ${esc(l.lavando.folio || '')} · empezó ${hora12(l.lavando.inicio)}</div></div>`}
    <div class="lav-num"><span>Carros hoy <b>${l.carros_hoy}</b></span>${LAVS_COM ? `<span>Comisión hoy <b>${money(l.comision_hoy)}</b></span><span>Por pagar <b>${money(l.pendiente)}</b></span>` : ''}</div>
    ${l.libre ? '' : `<button class="btn" onclick="lavLiberar(${l.id})">Ya terminó: dejarlo libre</button>`}</div>`).join('')}</div>`;
}
function lavComisiones() {
  const D = LAVDAT, per = D.desde === D.hasta ? fd(D.desde) : `${fd(D.desde)} al ${fd(D.hasta)}`;
  const pagar = puede('comisiones');
  const lavOpts = (sel) => LAVS.map((l) => `<option value="${l.id}" ${l.id === sel ? 'selected' : ''}>${esc(l.nombre)}</option>`).join('');
  $('#lavc').innerHTML = `${D.activo ? '' : `<div class="aviso" style="margin-bottom:12px">Las comisiones están apagadas: aquí solo se cuentan los carros de cada lavador.${puede('lavadores') ? ' <button class="btn sm" onclick="lavTab=\'cfg\';vLav()">Encender comisiones</button>' : ''}</div>`}
    <div class="stack">
    ${D.porPagar.length ? `<div class="card"><h2>Comisiones por pagar</h2><p class="sub" style="margin-top:0">Todo lo que se le debe a cada lavador (de cualquier día). Al pagar sale de la caja como gasto <b>Comisiones a lavadores</b> y entra al corte.</p>
      <div class="tw"><table><thead><tr><th>Lavador</th><th class="n">Carros</th><th>De los días</th><th class="n">A pagar</th><th></th></tr></thead><tbody>
      ${D.porPagar.map((x) => `<tr><td><b>${esc(x.nombre)}</b></td><td class="n">${x.carros}</td><td>${x.desde === x.hasta ? fd(x.desde) : fd(x.desde) + ' al ' + fd(x.hasta)}</td><td class="n"><b>${money(x.monto)}</b></td>
        <td>${pagar ? `<button class="btn pri sm" onclick="lavPagar(${x.id})">Pagar</button>` : ''}</td></tr>`).join('')}</tbody></table></div></div>` : D.activo ? '<div class="card"><h2>Comisiones por pagar</h2><div class="empty">No se le debe nada a ningún lavador.</div></div>' : ''}
    <div class="card"><h2>Por lavador · ${per}</h2><div class="tw"><table><thead><tr><th>Lavador</th><th class="n">Carros</th><th class="n">Minutos</th><th class="n">Vendido</th>${D.activo || D.total.generada ? '<th class="n">Comisión</th><th class="n">Pagada</th><th class="n">Pendiente</th>' : ''}</tr></thead><tbody>
      ${D.lavadores.map((x) => `<tr><td><b>${esc(x.nombre)}</b></td><td class="n">${x.carros}</td><td class="n">${x.minutos}</td><td class="n">${money(x.vendido)}</td>${D.activo || D.total.generada ? `<td class="n">${money(x.generada)}</td><td class="n">${money(x.pagada)}</td><td class="n"><b>${money(x.pendiente)}</b></td>` : ''}</tr>`).join('') || '<tr><td colspan="7" class="empty">No hay carros con lavador en estas fechas.</td></tr>'}
      ${D.lavadores.length > 1 ? `<tr><td><b>Total</b></td><td class="n"><b>${D.total.carros}</b></td><td></td><td></td>${D.activo || D.total.generada ? `<td class="n"><b>${money(D.total.generada)}</b></td><td class="n">${money(D.total.pagada)}</td><td class="n"><b>${money(D.total.pendiente)}</b></td>` : ''}</tr>` : ''}</tbody></table></div></div>
    <div class="card"><h2>Cada carro · ${per}</h2><div class="tw" style="max-height:460px"><table><thead><tr><th>Hora</th><th>Folio</th><th>Lavador</th><th>Qué se lavó</th><th>Placas</th><th class="n">Min.</th><th class="n">Comisión</th><th>Estado</th></tr></thead><tbody>
      ${D.detalle.map((x) => `<tr><td>${fdt(x.inicio)}</td><td class="mono">${esc(x.folio || '')}</td>
        <td>${x.pagado || !puede('vender') ? esc(x.lavador) : `<select onchange="lavCambiar(${x.id},this.value)" aria-label="Cambiar lavador">${lavOpts(x.empleado_id)}${LAVS.some((l) => l.id === x.empleado_id) ? '' : `<option selected>${esc(x.lavador)}</option>`}</select>`}</td>
        <td>${esc(x.descripcion || '')}</td><td class="mono">${esc(x.placas || '')}</td><td class="n">${x.minutos}</td><td class="n">${money(x.comision)}</td>
        <td>${x.comision > 0 ? (x.pagado ? `<span class="pill p-ok">Pagada</span>${x.gasto_folio ? ` <small class="sub">gasto ${esc(x.gasto_folio)}</small>` : ''}` : '<span class="pill p-warn">Por pagar</span>') : '<span class="sub">—</span>'}</td></tr>`).join('') || '<tr><td colspan="8" class="empty">Sin carros.</td></tr>'}</tbody></table></div></div>
    ${D.pagos.length ? `<div class="card"><h2>Pagos de comisiones · ${per}</h2><div class="tw"><table><thead><tr><th>Fecha</th><th>Folio del gasto</th><th>Lavador</th><th>Concepto</th><th>Pagó</th><th class="n">Monto</th></tr></thead><tbody>
      ${D.pagos.map((g) => `<tr><td>${fdt(g.fecha)}</td><td class="mono">${esc(g.folio)}</td><td>${esc(g.recibe || '')}</td><td>${esc(g.concepto)}</td><td>${esc(g.usuario || '')}</td><td class="n"><b>${money(g.monto)}</b></td></tr>`).join('')}</tbody></table></div></div>` : ''}</div>`;
}
async function lavCambiar(id, lav) {
  await hacer(() => POST(`/api/lavados/${id}/cambiar`, { lavador_id: Number(lav) }), 'Lavador cambiado');
  vLav();
}
function lavPagar(empId) {
  const x = LAVDAT.porPagar.find((p) => p.id === empId); if (!x) return;
  modal('Pagar comisiones a ' + esc(x.nombre), `<div class="kv" style="margin-bottom:10px"><span>Carros</span><b>${x.carros}</b><span>De los días</span><b>${x.desde === x.hasta ? fd(x.desde) : fd(x.desde) + ' al ' + fd(x.hasta)}</b><span>A pagar</span><b style="font-size:22px">${money(x.monto)}</b></div>
    <div class="f"><label class="l">Cómo se le paga<select id="lpM"><option value="efectivo">Efectivo (sale de la caja)</option><option value="transferencia">Transferencia</option></select></label>
    <label class="l">Nota (opcional)<input id="lpN" maxlength="200" placeholder="Ej. Pago del día"></label></div>
    <label class="row" style="margin-top:8px"><input type="checkbox" id="lpF"> Se le pagó por fuera (no sale del efectivo de mi caja)</label>
    <p class="sub">Queda registrado como gasto <b>Comisiones a lavadores</b> a nombre de ${esc(x.nombre)}${YO.turno ? ' y entra al corte de su turno' : ''}.</p>`,
  `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="lavPagarOk(${empId})">Pagar ${money(x.monto)}</button>`);
}
async function lavPagarOk(empId) {
  const r = await hacer(() => POST('/api/comisiones/pagar', { empleado_id: empId, metodo: val('lpM'), nota: val('lpN'), fuera_de_caja: $('#lpF').checked }), 'Comisión pagada');
  cerrar(); pintarTurno?.();
  lavComprobante(r);
  vLav();
}
// Comprobante para que firme el lavador
function lavComprobante(r) {
  const w = W(), raya = '-'.repeat(w);
  const lineas = [r.lavador.toUpperCase(), 'Comisiones de lavado', raya, lin('Folio gasto', r.folio), lin('Fecha', new Date().toLocaleString('es-MX', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })), lin('Periodo', r.periodo), lin('Carros', String(r.carros)), raya, lin('PAGADO', money(r.monto)), '', '', '_'.repeat(Math.min(w, 28)), 'Firma de recibido'];
  const html = `<pre class="tk">${esc([...encabezado(), ...lineas].join('\n'))}</pre>`;
  imprimirDoc(html, ancho(), 'Comprobante de comisión', () => [...encOps(), ...lineas.map((l) => ['text', l])]);
}
function lavImprimirLista() {
  const D = LAVDAT; if (!D) return;
  const per = D.desde === D.hasta ? fd(D.desde) : `${fd(D.desde)} al ${fd(D.hasta)}`;
  const t = (c, f) => `<table class="cw-pdf-t"><thead><tr>${c.map((x) => `<th>${x}</th>`).join('')}</tr></thead><tbody>${f.map((r) => `<tr>${r.map((x) => `<td>${x}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${c.length}">Sin datos</td></tr>`}</tbody></table>`;
  imprimirDoc(`<div class="cw-pdf"><div class="cw-pdf-cab"><div><h1>${esc(CFG.hotel_nombre)}</h1><div>Lavadores y comisiones · ${per}</div></div><div style="text-align:right">Impreso ${new Date().toLocaleString('es-MX')}<br>Maxsel Carwash</div></div>
    <h2>Por lavador</h2>${t(['Lavador', 'Carros', 'Minutos', 'Vendido', 'Comisión', 'Pagada', 'Pendiente', 'Firma'], D.lavadores.map((x) => [esc(x.nombre), x.carros, x.minutos, money(x.vendido), money(x.generada), money(x.pagada), `<b>${money(x.pendiente)}</b>`, '']))}
    <h2>Por pagar (todos los días)</h2>${t(['Lavador', 'Carros', 'De los días', 'A pagar'], D.porPagar.map((x) => [esc(x.nombre), x.carros, x.desde === x.hasta ? fd(x.desde) : fd(x.desde) + ' al ' + fd(x.hasta), `<b>${money(x.monto)}</b>`]))}
    <h2>Cada carro</h2>${t(['Hora', 'Folio', 'Lavador', 'Qué se lavó', 'Placas', 'Comisión', 'Estado'], D.detalle.map((x) => [fdt(x.inicio), esc(x.folio || ''), esc(x.lavador), esc(x.descripcion || ''), esc(x.placas || ''), money(x.comision), x.comision > 0 ? (x.pagado ? 'Pagada' : 'Por pagar') : '—']))}</div>`, 'carta', 'Lavadores y comisiones');
}
async function lavConfig() {
  const [lista, emps] = await Promise.all([GET('/api/lavadores'), GET('/api/lavadores/empleados').catch(() => [])]);
  if (!PRODS.length) PRODS = await GET('/api/productos').catch(() => []);
  const servs = PRODS.filter((p) => p.servicio && !/^MEM-/.test(p.codigo || '')).sort((a, b) => (a.paquete ? 0 : 1) - (b.paquete ? 0 : 1) || String(a.paquete || a.nombre).localeCompare(String(b.paquete || b.nombre), 'es', { numeric: true }));
  const otros = emps.filter((e) => !e.lavador);
  const ch = (k, def = '1') => ((CFG[k] ?? def) === '1' ? 'checked' : '');
  $('#lavc').innerHTML = `<div class="stack">
    <div class="card"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px"><h2 style="margin:0">Lavadores</h2><div class="row" style="gap:6px">
      ${otros.length ? `<select id="lvE" aria-label="Empleado"><option value="">Un empleado que ya existe…</option>${otros.map((e) => `<option value="${e.id}">${esc(e.nombre)}${e.puesto ? ' · ' + esc(e.puesto) : ''}</option>`).join('')}</select><button class="btn sm" onclick="lavMarcar()">Hacerlo lavador</button>` : ''}
      <button class="btn pri sm" onclick="lavModal()">Agregar lavador</button></div></div>
      <div class="tw" style="margin-top:10px"><table><thead><tr><th>Nombre</th><th>Teléfono</th><th>Estado</th><th></th></tr></thead><tbody>
      ${lista.map((l) => `<tr><td><b>${esc(l.nombre)}</b></td><td>${esc(l.telefono || '')}</td><td>${l.activo ? '<span class="pill p-ok">Activo</span>' : '<span class="pill">De baja</span>'}</td>
        <td class="row" style="gap:6px;justify-content:flex-end"><button class="btn sm" onclick="lavModal(${l.id})">Editar</button>${l.activo ? `<button class="btn sm bad" onclick="confirmar(this,()=>lavActivo(${l.id},false))">Dar de baja</button>` : `<button class="btn sm" onclick="lavActivo(${l.id},true)">Reactivar</button>`}</td></tr>`).join('') || '<tr><td colspan="4" class="empty">Agregue a sus lavadores para poder asignarles los carros en la caja.</td></tr>'}</tbody></table></div></div>
    <div class="card"><h2>En la caja</h2>
      <label class="row" style="font-weight:600"><input type="checkbox" id="lcOn" ${ch('cw_lavadores')}> Mostrar "¿Quién lo lava?" al vender un paquete (se ve quién está libre)</label>
      <label class="row" style="font-weight:600;margin-top:8px"><input type="checkbox" id="lcPe" ${ch('cw_pedir_lavador', '0')}> No dejar cobrar un paquete sin elegir lavador</label>
      <div class="f" style="margin-top:8px"><label class="l">Minutos de lavado si el paquete no tiene su tiempo<input id="lcMi" type="number" min="1" style="max-width:160px" value="${esc(CFG.cw_minutos_lavado || '30')}"></label></div>
      <p class="sub">Cuando pasa el tiempo del paquete, el lavador queda libre solo. Si terminó antes, tóquelo en <b>Liberar</b>; también se puede elegir a uno ocupado (se da por terminado su carro anterior).</p></div>
    <div class="card"><h2>Comisiones</h2>
      <label class="row" style="font-weight:600"><input type="checkbox" id="lcCo" ${ch('cw_comisiones', '0')} onchange="$('#lcMod').hidden=!this.checked"> Pagar comisión a los lavadores por cada carro</label>
      <div id="lcMod" ${CFG.cw_comisiones === '1' ? '' : 'hidden'} style="margin-top:8px">
        <label class="row"><input type="radio" class="lav-rad" name="lcM" value="paquete" ${CFG.cw_comision_modo !== 'fijo' ? 'checked' : ''}> Según el paquete que lave (se pone abajo en cada paquete: pesos o % del precio)</label>
        <label class="row" style="margin-top:4px"><input type="radio" class="lav-rad" name="lcM" value="fijo" ${CFG.cw_comision_modo === 'fijo' ? 'checked' : ''}> El mismo monto por cada carro: <input id="lcFi" type="number" min="0" step="0.01" value="${esc(CFG.cw_comision_fija || '0')}" style="width:100px"></label>
        <p class="sub">Lo que se le debe a cada lavador aparece en <b>Comisiones</b>; al pagarle sale de la caja como gasto.</p></div></div>
    <div class="card"><h2>Tiempo y comisión de cada paquete y servicio</h2><p class="sub" style="margin-top:0">Los precios y lo que incluye cada paquete se cambian en <b>Paquetes y productos</b>.</p>
      <div class="tw"><table><thead><tr><th>Paquete / servicio</th><th class="n">Precio</th><th>Minutos</th><th>Comisión</th><th>Valor</th></tr></thead><tbody>
      ${servs.map((p) => `<tr data-id="${p.id}"><td>${p.paquete ? `<span class="cw-mini" style="--pc:${colorPaq(p)}">P${esc(p.paquete)}</span> ` : ''}<b>${esc(p.nombre)}</b></td><td class="n">${money(p.precio)}</td>
        <td><input class="lcMi" type="number" min="0" step="1" value="${p.minutos || ''}" placeholder="${p.paquete ? esc(CFG.cw_minutos_lavado || '30') : '0'}" style="width:80px" aria-label="Minutos"></td>
        <td><select class="lcT" aria-label="Tipo de comisión"><option value="">Sin comisión</option><option value="monto" ${p.com_tipo === 'monto' ? 'selected' : ''}>Pesos</option><option value="porc" ${p.com_tipo === 'porc' ? 'selected' : ''}>% del precio</option></select></td>
        <td><input class="lcV" type="number" min="0" step="0.01" value="${p.com_valor || ''}" style="width:90px" aria-label="Valor de la comisión"></td></tr>`).join('') || '<tr><td colspan="5" class="empty">No hay paquetes.</td></tr>'}</tbody></table></div></div>
    <div><button class="btn pri" onclick="lavConfigOk()">Guardar</button></div></div>`;
}
async function lavConfigOk() {
  const productos = [...document.querySelectorAll('#lavc tr[data-id]')].map((tr) => ({ id: Number(tr.dataset.id), minutos: tr.querySelector('.lcMi').value, com_tipo: tr.querySelector('.lcT').value, com_valor: tr.querySelector('.lcV').value }));
  if (productos.some((p) => p.com_tipo === 'porc' && Number(p.com_valor) > 100)) return toast('La comisión no puede ser más del 100%', true);
  await hacer(() => PUT('/api/lavadores/config', { cw_lavadores: $('#lcOn').checked ? '1' : '0', cw_pedir_lavador: $('#lcPe').checked ? '1' : '0', cw_minutos_lavado: String(Math.max(1, parseInt(val('lcMi')) || 30)),
    cw_comisiones: $('#lcCo').checked ? '1' : '0', cw_comision_modo: document.querySelector('input[name=lcM]:checked')?.value || 'paquete', cw_comision_fija: String(Math.max(0, Number(val('lcFi')) || 0)), productos }), 'Guardado');
  CFG = await GET('/api/config'); PRODS = await GET('/api/productos').catch(() => PRODS); vLav();
}
function lavModal(id) {
  GET('/api/lavadores').then((lista) => {
    const l = id ? lista.find((x) => x.id === id) : { nombre: '', telefono: '' };
    modal(id ? 'Editar lavador' : 'Nuevo lavador', `<div class="f"><label class="l">Nombre<input id="lvN" value="${esc(l.nombre)}" maxlength="100"></label><label class="l">Teléfono (opcional)<input id="lvT" value="${esc(l.telefono || '')}" maxlength="30"></label></div>`,
      `<button class="btn" onclick="cerrar()">Cancelar</button><button class="btn pri" onclick="lavModalOk(${id || 0})">Guardar</button>`);
    $('#lvN').focus();
  });
}
async function lavModalOk(id) {
  const b = { nombre: val('lvN'), telefono: val('lvT') };
  await hacer(() => (id ? PUT('/api/lavadores/' + id, b) : POST('/api/lavadores', b)), 'Lavador guardado'); cerrar(); vLav();
}
async function lavActivo(id, on) { await hacer(() => PUT('/api/lavadores/' + id, { activo: on }), on ? 'Lavador reactivado' : 'Lavador dado de baja'); vLav(); }
async function lavMarcar() {
  const id = Number(val('lvE')); if (!id) return toast('Elija el empleado', true);
  await hacer(() => PUT('/api/lavadores/' + id, { lavador: true, activo: true }), 'Ahora es lavador'); vLav();
}

// ---------- Reportes: pestaña "Lavadores y comisiones" ----------
function rLav() {
  const L = R.lavadores || { lavadores: [], total: {}, sinLavador: 0 }, t = L.total || {};
  $('#repc').innerHTML = `<div class="kpis">${kpi('Carros con lavador', t.carros || 0, L.sinLavador ? `${L.sinLavador} sin lavador asignado` : '')}${L.activo || t.generada ? kpi('Comisión generada', money(t.generada)) + kpi('Pagada', money(t.pagada)) + kpi('Por pagar', money(t.pendiente), '', '', t.pendiente ? 'var(--ocup)' : '') : ''}</div>
    <div class="card" style="margin-top:12px"><h2>Por lavador</h2><div class="tw"><table><thead><tr><th>Lavador</th><th class="n">Carros</th><th class="n">Minutos</th><th class="n">Promedio por carro</th><th class="n">Vendido</th><th class="n">Comisión</th><th class="n">Pagada</th><th class="n">Pendiente</th></tr></thead><tbody>
    ${L.lavadores.map((x) => `<tr><td><b>${esc(x.nombre)}</b></td><td class="n">${x.carros}</td><td class="n">${x.minutos}</td><td class="n">${x.carros ? Math.round(x.minutos / x.carros) + ' min' : '—'}</td><td class="n">${money(x.vendido)}</td><td class="n">${money(x.generada)}</td><td class="n">${money(x.pagada)}</td><td class="n"><b>${money(x.pendiente)}</b></td></tr>`).join('') || '<tr><td colspan="8" class="empty">No hay carros con lavador en estas fechas. Los lavadores se dan de alta en el menú <b>Lavadores</b>.</td></tr>'}</tbody></table></div>
    ${puede('comisiones|lavadores') ? '<button class="btn" style="margin-top:10px" onclick="lavTab=\'com\';lavDesde=rDesde;lavHasta=rHasta;ir(\'lav\')">Ver cada carro y pagar comisiones</button>' : ''}</div>`;
}
