// Póliza de mantenimiento: el monitoreo por internet (Tailscale Funnel) se activa y vence desde la LICENCIA.
// La licencia normal (CW1-…) puede traer al final un bloque firmado con la fecha en que vence el acceso por internet:
//   [0x4E 'N'][2 bytes: días desde 2020-01-01, 65535 = sin vencimiento][firma Ed25519 de "MXNUBE" + equipo(10) + días(2)]
// Las licencias sin ese bloque NO incluyen el monitoreo por internet. (El monitoreo en la nube de Firebase no depende de esto.)
// Se lee aparte de licencia.js para que llegue también con la actualización por internet (licencia.js no se actualiza así).
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DATA_DIR, hoy } from './db.js';

const DIR = path.dirname(fileURLToPath(import.meta.url));
const LIC_FILE = path.join(DATA_DIR, 'licencia.txt');
const PREFIJO = /^CW1-?/i;
const B32 = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
const DIA0 = Date.UTC(2020, 0, 1);
function b32dec(s) {
  s = String(s).toUpperCase().replace(/[^0-9A-Z]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1');
  const out = []; let bits = 0, val = 0;
  for (const ch of s) { const i = B32.indexOf(ch); if (i < 0) throw new Error(); val = (val << 5) | i; bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } }
  return Buffer.from(out);
}
let _clave = null;
function clavePublica() {
  if (_clave !== null) return _clave;
  try { _clave = (/CLAVE_PUBLICA = '([^']+)'/.exec(fs.readFileSync(path.join(DIR, 'licencia.js'), 'utf8')) || [])[1] || ''; } catch { _clave = ''; }
  return _clave;
}
const fecha = (d) => new Date(DIA0 + d * 86400000).toISOString().slice(0, 10);

export function leerPoliza(clave) {
  const pub = clavePublica();
  if (!pub || pub.startsWith('__')) return process.env.MAXSEL_SIN_NUBE ? { incluida: false, activa: false, vence: null, motivo: 'Modo desarrollo sin póliza' } : { incluida: true, activa: true, vence: null, motivo: '' };
  const no = { incluida: false, activa: false, vence: null, motivo: 'Su licencia no incluye el monitoreo por internet. Contrate la póliza de mantenimiento con Maxsel (WhatsApp 664 337 5433).' };
  try {
    const buf = b32dec(String(clave || '').trim().replace(PREFIJO, ''));
    if (buf.length < 14 + 64 || (buf[0] !== 1 && buf[0] !== 2)) return no;
    const nl = buf[13], base = 14 + nl + (buf[0] === 2 ? 1 : 0) + 64;
    if (buf.length < base + 3 + 64 || buf[base] !== 0x4e) return no;
    const eq = buf.subarray(1, 11), dias = buf.readUInt16BE(base + 1), firma = buf.subarray(base + 3, base + 3 + 64);
    const k = crypto.createPublicKey({ key: Buffer.from(pub, 'base64'), format: 'der', type: 'spki' });
    if (!crypto.verify(null, Buffer.concat([Buffer.from('MXNUBE'), eq, buf.subarray(base + 1, base + 3)]), k, firma)) return no;
    if (dias === 65535) return { incluida: true, activa: true, vence: null, motivo: '' };
    const vence = fecha(dias);
    if (vence < hoy()) return { incluida: true, activa: false, vence, motivo: `La póliza de mantenimiento venció el ${vence.split('-').reverse().join('/')}: el monitoreo por internet está apagado. Renuévela con Maxsel (WhatsApp 664 337 5433).` };
    return { incluida: true, activa: true, vence, motivo: '' };
  } catch { return no; }
}
export function poliza() {
  let clave = ''; try { clave = fs.readFileSync(LIC_FILE, 'utf8').trim(); } catch { /* sin archivo */ }
  const p = leerPoliza(clave);
  p.dias = p.vence ? Math.ceil((new Date(p.vence + 'T23:59:59') - new Date()) / 86400000) : null;
  return p;
}

// Byte de módulos de la licencia (la firma ya la revisó licencia.js). 255 = licencia vieja con todo.
export function bitsModulos() {
  let clave = ''; try { clave = fs.readFileSync(LIC_FILE, 'utf8').trim(); } catch { return 255; }
  try {
    const buf = b32dec(clave.replace(PREFIJO, ''));
    if (buf[0] !== 2) return 255;
    return buf[14 + buf[13]];
  } catch { return 255; }
}
